module fakeram45_1r1w_64x64 (
  input clk,
  input re_in,
  input [5:0] r_addr_in,
  input we_in,
  input [5:0] w_addr_in,
  input [63:0] wd_in,
  input [63:0] w_mask_in,
  output reg [63:0] rd_out
);
  reg [63:0] mem [0:63];
  always @(posedge clk) begin
    if (we_in) mem[w_addr_in] <= (wd_in & w_mask_in) | (mem[w_addr_in] & ~w_mask_in);
    if (re_in) rd_out <= (we_in && r_addr_in == w_addr_in) ? {64{1'bx}} : mem[r_addr_in];
  end
endmodule
