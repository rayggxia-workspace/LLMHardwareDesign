module hpy_partial_fixed(input src, output pad_a,pad_b,dst); assign pad_a=src; assign pad_b=src; assign dst=src; endmodule
