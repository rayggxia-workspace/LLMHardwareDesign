module hpy_cut_fixture (inout a,b); endmodule
