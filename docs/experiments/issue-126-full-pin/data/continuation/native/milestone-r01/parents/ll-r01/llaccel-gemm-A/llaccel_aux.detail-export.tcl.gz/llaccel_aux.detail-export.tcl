read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/r03/llaccel_aux-A/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/ll-r01/llaccel-gemm-A/llaccel_aux.detailed.lef}
