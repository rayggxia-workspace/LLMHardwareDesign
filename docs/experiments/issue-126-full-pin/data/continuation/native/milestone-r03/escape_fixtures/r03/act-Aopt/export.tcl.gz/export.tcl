read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/full-controls-r04/act-Aopt/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/r03/act-Aopt/leaf_detail.lef}
