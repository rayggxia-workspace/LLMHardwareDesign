read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/r01/gemm-A/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/ll-r01/llaccel-gemm-A/gemm.detailed.lef}
