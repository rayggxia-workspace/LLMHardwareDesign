read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/r03/mxu-A/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/mxu.detailed.lef}
