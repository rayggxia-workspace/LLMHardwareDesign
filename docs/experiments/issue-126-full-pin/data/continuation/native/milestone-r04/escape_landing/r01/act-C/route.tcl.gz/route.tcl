read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_timing_models/r04/act-C/timing.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/r04/act-C/routed.odb}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10

proc snapshot_parent {prefix} {
 set b [ord::get_db_block];set f [open $prefix.pins.tsv w];puts $f "pin\tdirection\tuse\tnet\tlayer\tx0\ty0\tx1\ty1"
 foreach t [$b getBTerms] {foreach p [$t getBPins] {foreach s [$p getBoxes] {
  puts $f [join [list [$t getName] [$t getIoType] [$t getSigType] [[$t getNet] getName] [[$s getTechLayer] getName] [$s xMin] [$s yMin] [$s xMax] [$s yMax]] "\t"]
 }}};close $f
 set f [open $prefix.pdn.tsv w]
 foreach n [$b getNets] {foreach sw [$n getSWires] {foreach s [$sw getWires] {
  if {[$s isVia]} {set v [$s getTechVia];if {$v eq "NULL"} {set v [$s getBlockVia]};set layer [$v getName]} else {set layer [[$s getTechLayer] getName]}
  puts $f [list [$n getName] $layer [$s isVia] [$s xMin] [$s yMin] [$s xMax] [$s yMax]]
 }}};close $f
}
snapshot_parent {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/before}
place_pin -pin_name {r_data[195]} -layer metal10 -location {172.895 374.47} -pin_size {.8 .8}
set net [[ord::get_db_block] findNet {r_data[195]}];set wire [$net getWire];if {$wire eq "NULL"} {error "Expected original offending signal route"};odb::dbWire_destroy $wire
global_route -allow_congestion -guide_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/route.guide} -congestion_report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/congestion.rpt}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/global.odb}
detailed_route -output_drc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/route.drc} -verbose 1
snapshot_parent {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/after}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/routed.odb}
check_power_grid -net VDD -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/VDD.final.rpt}
check_power_grid -net VSS -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/VSS.final.rpt}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/act-escape-r04/code/export_access.tcl}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r01/act-C/wrapper.lef}
