read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef
read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_act.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_act.lib}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_mxu.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_mxu.lib}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_opentpu_aux.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_opentpu_aux.lib}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_gemm.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_gemm.lib}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_vector.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_vector.lib}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_llaccel_aux.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/p126_llaccel_aux.lib}
read_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/common-topology-r02/base_construction.v}
link_design hpy_common_base_construction
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/native_endpoints.tsv} w]
puts $f "kind\tinstance\tpin\tnet\tdirection\tlayer"
foreach n [$b getNets] {
 foreach it [$n getITerms] {
  if {[$it getSigType] in {POWER GROUND}} {continue}
  set layers {};foreach box [[$it getMTerm] getMPins] {foreach r [$box getGeometry] {lappend layers [[$r getTechLayer] getName]}}
  puts $f [join [list ITERM [[$it getInst] getName] [[$it getMTerm] getName] [$n getName] [$it getIoType] [join [lsort -unique $layers] ,]] "\t"]
 }
 foreach bt [$n getBTerms] {puts $f [join [list BTERM {} [$bt getName] [$n getName] [$bt getIoType] {}] "\t"]}
}
close $f
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/linked_unplaced_NOT_BASE.odb}
exec python3 -B {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/common-link-r01/code/verify_common_native.py} {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/common-topology-r02} {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/native_endpoints.tsv} {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_native_link/r01/graph_check.json}
