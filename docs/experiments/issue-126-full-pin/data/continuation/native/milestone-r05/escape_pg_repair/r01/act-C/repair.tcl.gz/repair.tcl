read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/r04/act-C/routed.odb}

set block [ord::get_db_block]; set u [$block getDbUnitsPerMicron]
# Snapshot objects that this limited repair has no authority to change.
set instance_signature {};foreach i [$block getInsts] {lappend instance_signature [list [$i getName] [[$i getMaster] getName] [$i getOrient] [$i getLocation]]}
set stripe_signature {};set groups [dict create];set rows [dict create]
foreach supply {VDD VSS} {
 foreach sw [[$block findNet $supply] getSWires] {foreach b [$sw getWires] {
  if {![$b isVia]} {lappend stripe_signature [list $supply [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]];continue}
  lassign [$b getViaXY] x y;set key [list $supply $x $y];dict lappend groups $key $b
  set via [$b getTechVia];if {$via eq "NULL"} {set via [$b getBlockVia]};if {$via eq "NULL"} {error "Unresolved via"}
  foreach s [$via getBoxes] {if {[[$s getTechLayer] getName] eq "metal10"} {dict lappend rows $key [list [$via getName] [expr {[$s xMin]+$x}] [expr {[$s yMin]+$y}] [expr {[$s xMax]+$x}] [expr {[$s yMax]+$y}]]}}
 }}
}
set marker {}
foreach v {145.75 366.07 146.37 366.87} {lappend marker [expr {round($v*$u)}]}
lassign $marker x0 y0 x1 y1
set eligible {}
dict for {key landings} $rows {
 if {[lindex $key 0] ne "VDD"} {continue}
 foreach q $landings {
  lassign $q name a b c d
  if {$a<$x1+$u && $c>$x0-$u && $b<$y1+$u && $d>$y0-$u} {lappend eligible $key;break}
 }
}
if {[llength $eligible]<1 || [llength $eligible]>2} {error "Repair not bounded to 1-2 new parent PG sites: $eligible"}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_pg_repair/r01/act-C/removed_parent_pg_sites.tsv} w]
puts $f "net\tx_dbu\ty_dbu\tvia_name\tx0\ty0\tx1\ty1"
foreach key $eligible {
 foreach row [dict get $rows $key] {puts $f "[join $key \t]\t[join $row \t]"}
 foreach box [dict get $groups $key] {odb::dbSBox_destroy $box}
}
close $f
set after {};foreach i [$block getInsts] {lappend after [list [$i getName] [[$i getMaster] getName] [$i getOrient] [$i getLocation]]}
if {$after ne $instance_signature} {error "Instance/master pose changed"}
set after {};foreach supply {VDD VSS} {foreach sw [[$block findNet $supply] getSWires] {foreach b [$sw getWires] {
 if {![$b isVia]} {lappend after [list $supply [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}
}}}
if {$after ne $stripe_signature} {error "Parent PG stripe changed"}
puts "ORIGINAL_MASTER_INSTANCE_POSE_AND_ALL_NONVIA_PG_STRIPES_UNCHANGED"
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_pg_repair/r01/act-C/repaired.odb}
check_power_grid -net VDD -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_pg_repair/r01/act-C/VDD.rpt}
check_power_grid -net VSS -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_pg_repair/r01/act-C/VSS.rpt}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/act-escape-pg-r01/code/export_access.tcl}
