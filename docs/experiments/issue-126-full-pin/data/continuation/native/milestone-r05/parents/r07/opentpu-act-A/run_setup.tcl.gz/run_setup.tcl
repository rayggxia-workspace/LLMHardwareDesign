read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/p126_opentpu_aux_A.lef}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/p126_act_A.lef}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/p126_mxu_A.lef}
read_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/parent-inputs-opentpu-act-r04/parent.v}
link_design hpy_pinxy_opentpu_controlled_parent
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/parent-inputs-opentpu-act-r04/setup.tcl}
parent_contract {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/pre_model}
exec python3 -B {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/parent-r07/code/verify_parent_graph.py} {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/parent-inputs-opentpu-act-r04/contract.json} {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/parent-inputs-opentpu-act-r04/endpoints.json} {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/pre_model.endpoints.tsv} --out {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/pre_model.graph_check.json}
cut_rows -halo_width_x 2 -halo_width_y 2
add_global_connection -net VDD -inst_pattern {.*} -pin_pattern {^VDD$} -power
add_global_connection -net VSS -inst_pattern {.*} -pin_pattern {^VSS$} -ground
global_connect
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name parent_grid -voltage_domains CORE -pins metal10
add_pdn_stripe -grid parent_grid -layer metal1 -width 0.17 -pitch 2.4 -offset 0 -followpins
add_pdn_stripe -grid parent_grid -layer metal4 -width 0.48 -pitch 56 -offset 2
add_pdn_stripe -grid parent_grid -layer metal7 -width 1.40 -pitch 30 -offset 2
add_pdn_stripe -grid parent_grid -layer metal10 -width 1.40 -pitch 30 -offset 2
add_pdn_connect -grid parent_grid -layers {metal1 metal4}
add_pdn_connect -grid parent_grid -layers {metal4 metal7}
add_pdn_connect -grid parent_grid -layers {metal7 metal10}
define_pdn_grid -name macro_pg_0 -voltage_domains CORE -macro -instances {hpy_auxiliary} -grid_over_pg_pins -halo {2 2 2 2}
add_pdn_connect -grid macro_pg_0 -layers {metal7 metal10}
define_pdn_grid -name macro_pg_1 -voltage_domains CORE -macro -instances {u_slice.u_act} -grid_over_pg_pins -halo {2 2 2 2}
add_pdn_connect -grid macro_pg_1 -layers {metal7 metal10}
define_pdn_grid -name macro_pg_2 -voltage_domains CORE -macro -instances {u_slice.u_mxu} -grid_over_pg_pins -halo {2 2 2 2}
add_pdn_connect -grid macro_pg_2 -layers {metal7 metal10}
pdngen -failed_via_report {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/parents/r07/opentpu-act-A/failed_vias.rpt}
set llhd_macro_instances {hpy_auxiliary u_slice.u_act u_slice.u_mxu}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/parent-r07/code/filter_parent_pg.tcl}
create_clock -name parent_route_classification_only -period 2.5 [get_ports clk]
