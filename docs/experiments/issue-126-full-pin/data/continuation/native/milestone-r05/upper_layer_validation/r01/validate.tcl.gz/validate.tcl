read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_layer_probe/r01/routed.odb}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_layer_validation/r01/independent.drc}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/common-prep-r01/code/export_access.tcl}
help repair_timing
help repair_design
help detailed_placement
help remove_fillers
puts "INDEPENDENT_UPPER_TOY_READBACK_EXECUTED"
