read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/access-r03/mxu-C/clean.odb}
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r01/mxu_access/net_ndr.tsv} w];puts $f "net\tsig_type\tNDR"
foreach n [$b getNets] {set d [$n getNonDefaultRule];if {$d ne "NULL"} {puts $f [join [list [$n getName] [$n getSigType] [$d getName]] "\t"]}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r01/mxu_access/NDR_rules.tsv} w];puts $f "rule\thard_spacing\tlayer\twidth_dbu\tspacing_dbu"
foreach d [[ord::get_db_tech] getNonDefaultRules] {
 set hard UNKNOWN;catch {set hard [$d getHardSpacing]}
 foreach lr [$d getLayerRules] {puts $f [join [list [$d getName] $hard [[$lr getLayer] getName] [$lr getWidth] [$lr getSpacing]] "\t"]}
};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r01/mxu_access/drivers.tsv} w];puts $f "pin\tmaster\tmaster_type\twidth_dbu\tnet\tinst_dont_touch\tnet_dont_touch\tBTerms\tITerms"
set i [$b findInst {place10281}];if {$i eq "NULL"} {error "Unknown actual driver"}
set it [$i findITerm {Z}];set m [$i getMaster];set n [$it getNet];set idt UNKNOWN;set ndt UNKNOWN;catch {set idt [$i isDoNotTouch]};catch {set ndt [$n isDoNotTouch]}
puts $f [join [list {place10281/Z} [$m getName] [$m getType] [$m getWidth] [$n getName] $idt $ndt [llength [$n getBTerms]] [llength [$n getITerms]]] "\t"]
close $f
puts "READ_ONLY_NDR_DRIVER_AUDIT_FINISHED"
