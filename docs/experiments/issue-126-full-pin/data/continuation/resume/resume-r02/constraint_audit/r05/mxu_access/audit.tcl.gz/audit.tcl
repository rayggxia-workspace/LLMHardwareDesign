read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/access-r03/mxu-C/clean.odb}
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r05/mxu_access/net_ndr.tsv} w];puts $f "net\tsig_type\tNDR"
foreach n [$b getNets] {set d [$n getNonDefaultRule];if {$d ne "NULL"} {puts $f [join [list [$n getName] [$n getSigType] [$d getName]] "\t"]}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r05/mxu_access/NDR_rules.tsv} w];puts $f "rule\thard_spacing\tlayer\twidth_dbu\tspacing_dbu"
set rules [concat [[ord::get_db_tech] getNonDefaultRules] [$b getNonDefaultRules]]
foreach d $rules {
 set hard UNKNOWN;catch {set hard [$d getHardSpacing]}
 foreach ly [[ord::get_db_tech] getLayers] {set lr [$d getLayerRule $ly];if {$lr ne "NULL"} {puts $f [join [list [$d getName] $hard [$ly getName] [$lr getWidth] [$lr getSpacing]] "\t"]}}
};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r05/mxu_access/drivers.tsv} w];puts $f "pin\tmaster\tmaster_type\twidth_dbu\tnet\tinst_dont_touch\tnet_dont_touch\tBTerms\tITerms"
set i [$b findInst {place10281}];if {$i eq "NULL"} {set i [$b findInst {place10281}]};if {$i eq "NULL"} {error "Unknown actual driver"}
set it [$i findITerm {Z}];set m [$i getMaster];set n [$it getNet];set idt UNKNOWN;set ndt UNKNOWN;catch {set idt [$i isDoNotTouch]};catch {set ndt [$n isDoNotTouch]}
puts $f [join [list {place10281/Z} [$m getName] [$m getType] [$m getWidth] [$n getName] $idt $ndt [llength [$n getBTerms]] [llength [$n getITerms]]] "\t"]
close $f
set profiles [dict create];set itr [odb::dbWirePathItr];set wp [odb::dbWirePath];set ps [odb::dbWirePathShape]
foreach n [$b getNets] {
 set d [$n getNonDefaultRule];set w [$n getWire];if {$d eq "NULL" || $w eq "NULL"} {continue}
 $itr begin $w
 while {[$itr getNextPath $wp]} {while {[$itr getNextShape $ps]} {
  set s [odb::dbWirePathShape_shape_get $ps];if {[$s isVia]} {continue}
  set ly [$s getTechLayer];set lr [$d getLayerRule $ly];set nominal UNKNOWN
  if {$lr ne "NULL"} {set nominal [$lr getWidth]}
  set width [expr {min([$s xMax]-[$s xMin],[$s yMax]-[$s yMin])}]
  dict incr profiles [list [$n getName] [$d getName] [$ly getName] $width $nominal]
 }}
}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r05/mxu_access/NDR_wire_width_profiles.tsv} w]
puts $f "net\tNDR\tlayer\tmin_box_dimension_dbu\tNDR_nominal_width_dbu\tshape_count"
dict for {k v} $profiles {puts $f [join [list {*}$k $v] "\t"]};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r05/mxu_access/cell_tools.txt} w];foreach c {replace_cell size_cell filler_placement remove_fillers detailed_placement} {puts $f [list $c [info commands $c]];if {[llength [info commands $c]]} {catch {help $c} h;puts $f $h}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r05/mxu_access/candidate_masters.tsv} w];puts $f "master\ttype\twidth_dbu\theight_dbu";foreach l [[ord::get_db] getLibs] {foreach m [$l getMasters] {if {[regexp {^(BUF_X[1248]|XOR2_X[124]|DFF.*|FILLCELL_.*)$} [$m getName]]} {puts $f [join [list [$m getName] [$m getType] [$m getWidth] [$m getHeight]] "\t"]}}};close $f
puts "READ_ONLY_NDR_DRIVER_AUDIT_FINISHED"
