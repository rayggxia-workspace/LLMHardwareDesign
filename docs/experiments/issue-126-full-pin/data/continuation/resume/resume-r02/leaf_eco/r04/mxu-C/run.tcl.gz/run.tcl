proc cell_cost {file} {
 set b [ord::get_db_block];set u [$b getDbUnitsPerMicron];set f [open $file w]
 puts $f "instance\tmaster\ttype\tarea_um2\tx_dbu\ty_dbu"
 foreach i [$b getInsts] {set m [$i getMaster];lassign [$i getLocation] x y;puts $f [join [list [$i getName] [$m getName] [$m getType] [expr {[$m getWidth]*double([$m getHeight])/($u*$u)}] $x $y] "\t"]};close $f
}
# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x40.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x64.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x72.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x96.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/access-r03/mxu-C/clean.odb}
read_sdc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/flow/results/nangate45/parallel_opentpu_mxu/base/6_final.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/trials/access-r03/mxu-C/extracted.spef}
set b [ord::get_db_block];set u [$b getDbUnitsPerMicron];set prior_OBS [lsort [$b getObstructions]];set new_ECO_OBS {}
set access_reservations {};source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/trial-inputs-mxu-access-r03/access_reservations.tcl}
foreach row $access_reservations {lassign $row ly x0 y0 x1 y1;set c {};foreach v [list $x0 $y0 $x1 $y1] {lappend c [expr {round($v*$u)}]};lappend new_ECO_OBS [odb::dbObstruction_create $b [[ord::get_db_tech] findLayer $ly] {*}$c]}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/before}
cell_cost {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/before.cell_cost.tsv}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/before.setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/before.hold.txt}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
read_guides {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/trials/access-r03/mxu-C/route.guide}
if {![stage begin_incremental {global_route -start_incremental}]} {close $stages;exit 1}
if {![stage cell_repair {set b [ord::get_db_block];set filler_masters {};foreach i [$b getInsts] {set m [$i getMaster];if {[$m getType] eq "CORE_SPACER"} {lappend filler_masters [$m getName]}};set filler_masters [lsort -unique $filler_masters];if {![llength $filler_masters]} {error "Original filler master set missing"};proc terminal_contract {inst} {set result {};foreach it [$inst getITerms] {set n [$it getNet];lappend result [list [[$it getMTerm] getName] [[$it getMTerm] getIoType] [expr {$n eq "NULL" ? "NULL" : [$n getName]}]]};return [lsort $result]};remove_fillers;set i [$b findInst {place10281}];if {$i eq "NULL" || [[$i getMaster] getName] ne {BUF_X1}} {error "Exact targeted source master changed"};set prior [terminal_contract $i];replace_cell {place10281} {BUF_X2};set i [$b findInst {place10281}];if {[terminal_contract $i] ne $prior || [[$i getMaster] getName] ne {BUF_X2}} {error "Replacement changed terminal semantics"}}]} {close $stages;exit 1}
if {![stage legalization {detailed_placement -incremental;check_placement -verbose;filler_placement -prefix PINXY_CAP_FILL_ $filler_masters;global_connect;check_placement -verbose}]} {close $stages;exit 1}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
if {![stage global_route {global_route -end_incremental -guide_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/route.guide} -congestion_report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/congestion.rpt}}]} {close $stages;exit 1}
if {![stage detailed_route {detailed_route -output_drc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/route.drc} -verbose 1;foreach ob $new_ECO_OBS {odb::dbObstruction_destroy $ob};if {[lsort [[ord::get_db_block] getObstructions]] ne $prior_OBS} {error "Original OBS changed"};write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/routed.odb}}]} {close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/after}
cell_cost {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/after.cell_cost.tsv}
stage VDD {check_power_grid -net VDD -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/VDD.rpt}}
stage VSS {check_power_grid -net VSS -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/VSS.rpt}}
stage whole_signal_geometry {source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/targeted-cap-r04/code/export_access.tcl}}
stage rcx {define_process_corner -ext_model_index 0 X;set_extraction_rules_file /OpenROAD-flow-scripts/flow/platforms/nangate45/rcx_patterns.rules;extract_parasitics;write_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/extracted.spef};read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/extracted.spef}}
stage sta {report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/setup.txt};report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/hold.txt};report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/checks.txt};check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/constraint_coverage.txt};report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/parasitic_coverage.txt}}
close $stages
