read_db {/public/home/yuzelu/PingyangHuang/issue-55/full-block-integration-20261023T103718349596Z/runs/auxiliary-route-llaccel-abc-logic-4c-01/flow/results/nangate45/hpy_llaccel_aux/base/5_route_connected.odb}
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r01/ll_original/net_ndr.tsv} w];puts $f "net\tsig_type\tNDR"
foreach n [$b getNets] {set d [$n getNonDefaultRule];if {$d ne "NULL"} {puts $f [join [list [$n getName] [$n getSigType] [$d getName]] "\t"]}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r01/ll_original/NDR_rules.tsv} w];puts $f "rule\thard_spacing\tlayer\twidth_dbu\tspacing_dbu"
foreach d [[ord::get_db_tech] getNonDefaultRules] {
 set hard UNKNOWN;catch {set hard [$d getHardSpacing]}
 foreach lr [$d getLayerRules] {puts $f [join [list [$d getName] $hard [[$lr getLayer] getName] [$lr getWidth] [$lr getSpacing]] "\t"]}
};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/constraint_audit/r01/ll_original/drivers.tsv} w];puts $f "pin\tmaster\tmaster_type\twidth_dbu\tnet\tinst_dont_touch\tnet_dont_touch\tBTerms\tITerms"
close $f
puts "READ_ONLY_NDR_DRIVER_AUDIT_FINISHED"
