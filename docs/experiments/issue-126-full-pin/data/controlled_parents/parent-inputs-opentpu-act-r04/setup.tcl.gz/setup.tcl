initialize_floorplan -die_area {0 0 2228.735000 3409.335000} -core_area {10 10 2218.735000 3399.335000} -site FreePDK45_38x28_10R_NP_162NW_34O
source /OpenROAD-flow-scripts/flow/platforms/nangate45/make_tracks.tcl
place_macro -macro_name {hpy_auxiliary} -location {80.080000 80.080000} -orientation R0 -exact
place_macro -macro_name {u_slice.u_act} -location {80.080000 2228.800000} -orientation R0 -exact
place_macro -macro_name {u_slice.u_mxu} -location {486.360000 2228.800000} -orientation R0 -exact
set b [ord::get_db_block]
set row [lindex [$b getRows] 0]
lassign [$row getOrigin] tie_x tie_y
set tie_site [[$row getSite] getWidth]
set i [$b findInst top_constant_0]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_1]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_2]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_3]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_4]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_5]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_6]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_7]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_8]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_9]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_10]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_11]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_12]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_13]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_14]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_15]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_16]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_17]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_18]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_19]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_20]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_21]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_22]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_23]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_24]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_25]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_26]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_27]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_28]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_29]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_30]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_31]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_32]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_33]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_34]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_35]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
set i [$b findInst top_constant_36]
$i setOrient [$row getOrient]
$i setLocation $tie_x $tie_y
$i setPlacementStatus FIRM
set tie_x [expr {$tie_x+[[$i getMaster] getWidth]+$tie_site}]
foreach i [[ord::get_db_block] getInsts] {$i setPlacementStatus FIRM}
place_pin -pin_name {clk} -layer metal6 -location {20.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {sys_rst} -layer metal5 -location {0.070000 20.230000} -pin_size {0.14 0.14}
place_pin -pin_name {rst} -layer metal5 -location {2228.665000 20.230000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[0]} -layer metal5 -location {0.070000 21.350000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[1]} -layer metal5 -location {2228.665000 21.350000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[2]} -layer metal5 -location {0.070000 22.470000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[3]} -layer metal5 -location {2228.665000 22.470000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[4]} -layer metal6 -location {20.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[5]} -layer metal5 -location {0.070000 23.590000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[6]} -layer metal5 -location {2228.665000 23.590000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[7]} -layer metal6 -location {21.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[8]} -layer metal6 -location {21.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[9]} -layer metal6 -location {22.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[10]} -layer metal6 -location {22.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[11]} -layer metal6 -location {23.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[12]} -layer metal6 -location {23.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[13]} -layer metal6 -location {24.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[14]} -layer metal6 -location {24.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[15]} -layer metal5 -location {0.070000 24.710000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[16]} -layer metal5 -location {2228.665000 24.710000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[17]} -layer metal5 -location {0.070000 25.830000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[18]} -layer metal5 -location {2228.665000 25.830000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[19]} -layer metal5 -location {0.070000 26.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[20]} -layer metal5 -location {2228.665000 26.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[21]} -layer metal6 -location {25.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[22]} -layer metal5 -location {0.070000 28.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[23]} -layer metal5 -location {2228.665000 28.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[24]} -layer metal5 -location {0.070000 29.190000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[25]} -layer metal5 -location {2228.665000 29.190000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[26]} -layer metal5 -location {0.070000 30.310000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[27]} -layer metal5 -location {2228.665000 30.310000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[28]} -layer metal5 -location {0.070000 31.430000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[29]} -layer metal5 -location {2228.665000 31.430000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[30]} -layer metal5 -location {0.070000 32.550000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[31]} -layer metal5 -location {2228.665000 32.550000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[32]} -layer metal5 -location {0.070000 33.670000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[33]} -layer metal5 -location {2228.665000 33.670000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[34]} -layer metal5 -location {0.070000 34.790000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[35]} -layer metal5 -location {2228.665000 34.790000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[36]} -layer metal5 -location {0.070000 35.910000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[37]} -layer metal5 -location {2228.665000 35.910000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[38]} -layer metal5 -location {0.070000 37.030000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[39]} -layer metal5 -location {2228.665000 37.030000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[40]} -layer metal5 -location {0.070000 38.150000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[41]} -layer metal5 -location {2228.665000 38.150000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[42]} -layer metal5 -location {0.070000 39.270000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[43]} -layer metal5 -location {2228.665000 39.270000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[44]} -layer metal5 -location {0.070000 40.390000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[45]} -layer metal5 -location {2228.665000 40.390000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[46]} -layer metal5 -location {0.070000 41.510000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[47]} -layer metal5 -location {2228.665000 41.510000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[48]} -layer metal5 -location {0.070000 42.630000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[49]} -layer metal5 -location {2228.665000 42.630000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[50]} -layer metal5 -location {0.070000 43.750000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[51]} -layer metal5 -location {2228.665000 43.750000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[52]} -layer metal5 -location {0.070000 44.870000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[53]} -layer metal5 -location {2228.665000 44.870000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[54]} -layer metal5 -location {0.070000 45.990000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[55]} -layer metal5 -location {2228.665000 45.990000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[56]} -layer metal5 -location {0.070000 47.110000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[57]} -layer metal5 -location {2228.665000 47.110000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[58]} -layer metal5 -location {0.070000 48.230000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[59]} -layer metal5 -location {2228.665000 48.230000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[60]} -layer metal5 -location {0.070000 49.350000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[61]} -layer metal5 -location {2228.665000 49.350000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[62]} -layer metal5 -location {0.070000 50.470000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[63]} -layer metal5 -location {2228.665000 50.470000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[64]} -layer metal5 -location {0.070000 51.590000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[65]} -layer metal5 -location {2228.665000 51.590000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[66]} -layer metal5 -location {0.070000 52.710000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[67]} -layer metal5 -location {2228.665000 52.710000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[68]} -layer metal5 -location {0.070000 53.830000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[69]} -layer metal5 -location {2228.665000 53.830000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[70]} -layer metal5 -location {0.070000 54.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[71]} -layer metal5 -location {2228.665000 54.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[72]} -layer metal5 -location {0.070000 56.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[73]} -layer metal5 -location {2228.665000 56.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[74]} -layer metal5 -location {0.070000 57.190000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[75]} -layer metal5 -location {2228.665000 57.190000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[76]} -layer metal5 -location {0.070000 58.310000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[77]} -layer metal6 -location {25.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[78]} -layer metal6 -location {26.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[79]} -layer metal6 -location {26.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[80]} -layer metal6 -location {28.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[81]} -layer metal6 -location {28.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[82]} -layer metal6 -location {29.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[83]} -layer metal6 -location {29.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[84]} -layer metal6 -location {30.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[85]} -layer metal6 -location {30.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[86]} -layer metal6 -location {31.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[87]} -layer metal6 -location {31.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[88]} -layer metal6 -location {32.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[89]} -layer metal6 -location {32.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[90]} -layer metal6 -location {33.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[91]} -layer metal6 -location {33.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[92]} -layer metal6 -location {34.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[93]} -layer metal6 -location {34.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[94]} -layer metal6 -location {35.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[95]} -layer metal5 -location {2228.665000 58.310000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[96]} -layer metal5 -location {0.070000 59.430000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[97]} -layer metal5 -location {2228.665000 59.430000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[98]} -layer metal5 -location {0.070000 60.550000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[99]} -layer metal5 -location {2228.665000 60.550000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[100]} -layer metal5 -location {0.070000 61.670000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[101]} -layer metal5 -location {2228.665000 61.670000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[102]} -layer metal5 -location {0.070000 62.790000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[103]} -layer metal5 -location {2228.665000 62.790000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[104]} -layer metal5 -location {0.070000 63.910000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[105]} -layer metal5 -location {2228.665000 63.910000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[106]} -layer metal5 -location {0.070000 65.030000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[107]} -layer metal5 -location {2228.665000 65.030000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[108]} -layer metal5 -location {0.070000 66.150000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[109]} -layer metal5 -location {2228.665000 66.150000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[110]} -layer metal5 -location {0.070000 67.270000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[111]} -layer metal6 -location {35.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[112]} -layer metal6 -location {37.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[113]} -layer metal6 -location {37.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[114]} -layer metal6 -location {38.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[115]} -layer metal6 -location {38.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[116]} -layer metal6 -location {39.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[117]} -layer metal6 -location {39.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[118]} -layer metal6 -location {40.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[119]} -layer metal6 -location {40.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[120]} -layer metal6 -location {41.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[121]} -layer metal6 -location {41.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[122]} -layer metal6 -location {42.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[123]} -layer metal6 -location {42.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[124]} -layer metal6 -location {43.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[125]} -layer metal6 -location {43.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[126]} -layer metal6 -location {44.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[127]} -layer metal6 -location {44.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[128]} -layer metal6 -location {46.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[129]} -layer metal6 -location {46.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[130]} -layer metal6 -location {47.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[131]} -layer metal6 -location {47.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[132]} -layer metal6 -location {48.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[133]} -layer metal6 -location {48.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[134]} -layer metal6 -location {49.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[135]} -layer metal6 -location {49.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[136]} -layer metal6 -location {50.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[137]} -layer metal6 -location {50.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[138]} -layer metal6 -location {51.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[139]} -layer metal6 -location {51.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[140]} -layer metal6 -location {52.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[141]} -layer metal6 -location {52.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[142]} -layer metal6 -location {53.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[143]} -layer metal6 -location {53.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[144]} -layer metal6 -location {54.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[145]} -layer metal6 -location {54.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[146]} -layer metal6 -location {56.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[147]} -layer metal6 -location {56.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[148]} -layer metal6 -location {57.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[149]} -layer metal6 -location {57.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[150]} -layer metal6 -location {58.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[151]} -layer metal6 -location {58.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[152]} -layer metal6 -location {59.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[153]} -layer metal6 -location {59.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[154]} -layer metal6 -location {60.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[155]} -layer metal6 -location {60.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[156]} -layer metal6 -location {61.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[157]} -layer metal6 -location {61.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[158]} -layer metal6 -location {62.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[159]} -layer metal6 -location {62.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[160]} -layer metal6 -location {63.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[161]} -layer metal6 -location {63.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[162]} -layer metal6 -location {65.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[163]} -layer metal6 -location {65.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[164]} -layer metal6 -location {66.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[165]} -layer metal6 -location {66.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[166]} -layer metal6 -location {67.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[167]} -layer metal6 -location {67.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[168]} -layer metal6 -location {68.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[169]} -layer metal6 -location {68.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[170]} -layer metal6 -location {69.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[171]} -layer metal6 -location {69.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[172]} -layer metal6 -location {70.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[173]} -layer metal6 -location {70.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[174]} -layer metal6 -location {71.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[175]} -layer metal6 -location {71.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[176]} -layer metal6 -location {72.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[177]} -layer metal6 -location {72.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[178]} -layer metal6 -location {74.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[179]} -layer metal6 -location {74.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[180]} -layer metal6 -location {75.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[181]} -layer metal6 -location {75.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[182]} -layer metal6 -location {76.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[183]} -layer metal6 -location {76.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[184]} -layer metal6 -location {77.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[185]} -layer metal6 -location {77.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[186]} -layer metal6 -location {78.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[187]} -layer metal5 -location {2228.665000 67.270000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[188]} -layer metal5 -location {0.070000 68.390000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[189]} -layer metal5 -location {2228.665000 68.390000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[190]} -layer metal5 -location {0.070000 69.510000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[191]} -layer metal5 -location {2228.665000 69.510000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[192]} -layer metal5 -location {0.070000 70.630000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[193]} -layer metal5 -location {2228.665000 70.630000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[194]} -layer metal5 -location {0.070000 71.750000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[195]} -layer metal5 -location {2228.665000 71.750000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[196]} -layer metal5 -location {0.070000 72.870000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[197]} -layer metal5 -location {2228.665000 72.870000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[198]} -layer metal5 -location {0.070000 73.990000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[199]} -layer metal5 -location {2228.665000 73.990000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[200]} -layer metal5 -location {0.070000 75.110000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[201]} -layer metal5 -location {2228.665000 75.110000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[202]} -layer metal5 -location {0.070000 76.230000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[203]} -layer metal5 -location {2228.665000 76.230000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[204]} -layer metal5 -location {0.070000 77.350000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[205]} -layer metal5 -location {2228.665000 77.350000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[206]} -layer metal5 -location {0.070000 78.470000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[207]} -layer metal5 -location {2228.665000 78.470000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[208]} -layer metal5 -location {0.070000 79.590000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[209]} -layer metal5 -location {2228.665000 79.590000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[210]} -layer metal5 -location {0.070000 80.710000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[211]} -layer metal5 -location {2228.665000 80.710000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[212]} -layer metal5 -location {0.070000 81.830000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[213]} -layer metal5 -location {2228.665000 81.830000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[214]} -layer metal5 -location {0.070000 82.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[215]} -layer metal5 -location {2228.665000 82.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[216]} -layer metal5 -location {0.070000 84.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[217]} -layer metal5 -location {2228.665000 84.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[218]} -layer metal5 -location {0.070000 85.190000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[219]} -layer metal5 -location {2228.665000 85.190000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[220]} -layer metal5 -location {0.070000 86.310000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[221]} -layer metal5 -location {2228.665000 86.310000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[222]} -layer metal5 -location {0.070000 87.430000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[223]} -layer metal5 -location {2228.665000 87.430000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[224]} -layer metal5 -location {0.070000 88.550000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[225]} -layer metal5 -location {2228.665000 88.550000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[226]} -layer metal5 -location {0.070000 89.670000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[227]} -layer metal5 -location {2228.665000 89.670000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[228]} -layer metal5 -location {0.070000 90.790000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[229]} -layer metal5 -location {2228.665000 90.790000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[230]} -layer metal5 -location {0.070000 91.910000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[231]} -layer metal5 -location {2228.665000 91.910000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[232]} -layer metal5 -location {0.070000 93.030000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[233]} -layer metal5 -location {2228.665000 93.030000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[234]} -layer metal5 -location {0.070000 94.150000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[235]} -layer metal5 -location {2228.665000 94.150000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[236]} -layer metal5 -location {0.070000 95.270000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[237]} -layer metal5 -location {2228.665000 95.270000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[238]} -layer metal5 -location {0.070000 96.390000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[239]} -layer metal5 -location {2228.665000 96.390000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[240]} -layer metal5 -location {0.070000 97.510000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[241]} -layer metal5 -location {2228.665000 97.510000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[242]} -layer metal5 -location {0.070000 98.630000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[243]} -layer metal5 -location {2228.665000 98.630000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[244]} -layer metal5 -location {0.070000 99.750000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[245]} -layer metal5 -location {2228.665000 99.750000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[246]} -layer metal5 -location {0.070000 100.870000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[247]} -layer metal5 -location {2228.665000 100.870000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[248]} -layer metal5 -location {0.070000 101.990000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[249]} -layer metal5 -location {2228.665000 101.990000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[250]} -layer metal6 -location {78.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[251]} -layer metal6 -location {79.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[252]} -layer metal6 -location {79.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[253]} -layer metal6 -location {80.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[254]} -layer metal6 -location {80.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {rinit[255]} -layer metal6 -location {81.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_start} -layer metal6 -location {81.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[0]} -layer metal6 -location {82.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[1]} -layer metal6 -location {82.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[2]} -layer metal6 -location {84.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[3]} -layer metal5 -location {0.070000 103.110000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[4]} -layer metal5 -location {2228.665000 103.110000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[5]} -layer metal5 -location {0.070000 104.230000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[6]} -layer metal5 -location {2228.665000 104.230000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[7]} -layer metal5 -location {0.070000 105.350000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[8]} -layer metal5 -location {2228.665000 105.350000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[9]} -layer metal5 -location {0.070000 106.470000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[10]} -layer metal5 -location {2228.665000 106.470000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[11]} -layer metal5 -location {0.070000 107.590000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[12]} -layer metal5 -location {2228.665000 107.590000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[13]} -layer metal5 -location {0.070000 108.710000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[14]} -layer metal5 -location {2228.665000 108.710000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[15]} -layer metal5 -location {0.070000 109.830000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[16]} -layer metal5 -location {2228.665000 109.830000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[17]} -layer metal5 -location {0.070000 110.950000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[18]} -layer metal5 -location {2228.665000 110.950000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[19]} -layer metal5 -location {0.070000 112.070000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[20]} -layer metal5 -location {2228.665000 112.070000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[21]} -layer metal5 -location {0.070000 113.190000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[22]} -layer metal5 -location {2228.665000 113.190000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[23]} -layer metal5 -location {0.070000 114.310000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[24]} -layer metal5 -location {2228.665000 114.310000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[25]} -layer metal5 -location {0.070000 115.430000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[26]} -layer metal5 -location {2228.665000 115.430000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[27]} -layer metal5 -location {0.070000 116.550000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[28]} -layer metal5 -location {2228.665000 116.550000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[29]} -layer metal5 -location {0.070000 117.670000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[30]} -layer metal5 -location {2228.665000 117.670000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_addr[31]} -layer metal5 -location {0.070000 118.790000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[0]} -layer metal5 -location {2228.665000 118.790000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[1]} -layer metal5 -location {0.070000 119.910000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[2]} -layer metal5 -location {2228.665000 119.910000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[3]} -layer metal5 -location {0.070000 121.030000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[4]} -layer metal5 -location {2228.665000 121.030000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[5]} -layer metal5 -location {0.070000 122.150000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[6]} -layer metal5 -location {2228.665000 122.150000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[7]} -layer metal5 -location {0.070000 123.270000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[8]} -layer metal5 -location {2228.665000 123.270000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[9]} -layer metal5 -location {0.070000 124.390000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[10]} -layer metal5 -location {2228.665000 124.390000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[11]} -layer metal5 -location {0.070000 125.510000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[12]} -layer metal5 -location {2228.665000 125.510000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[13]} -layer metal5 -location {0.070000 126.630000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[14]} -layer metal5 -location {2228.665000 126.630000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[15]} -layer metal5 -location {0.070000 127.750000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[16]} -layer metal5 -location {2228.665000 127.750000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[17]} -layer metal5 -location {0.070000 128.870000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[18]} -layer metal5 -location {2228.665000 128.870000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[19]} -layer metal5 -location {0.070000 129.990000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[20]} -layer metal5 -location {2228.665000 129.990000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[21]} -layer metal5 -location {0.070000 131.110000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[22]} -layer metal5 -location {2228.665000 131.110000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[23]} -layer metal5 -location {0.070000 132.230000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[24]} -layer metal5 -location {2228.665000 132.230000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[25]} -layer metal5 -location {0.070000 133.350000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[26]} -layer metal5 -location {2228.665000 133.350000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[27]} -layer metal5 -location {0.070000 134.470000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[28]} -layer metal5 -location {2228.665000 134.470000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[29]} -layer metal5 -location {0.070000 135.590000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[30]} -layer metal5 -location {2228.665000 135.590000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_n[31]} -layer metal5 -location {0.070000 136.710000} -pin_size {0.14 0.14}
place_pin -pin_name {ld_busy} -layer metal5 -location {2228.665000 136.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdy} -layer metal5 -location {0.070000 137.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdy} -layer metal5 -location {2228.665000 137.830000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_rdy} -layer metal5 -location {0.070000 138.950000} -pin_size {0.14 0.14}
place_pin -pin_name {wr_idle} -layer metal5 -location {2228.665000 138.950000} -pin_size {0.14 0.14}
place_pin -pin_name {rd_idle} -layer metal5 -location {0.070000 140.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_req} -layer metal5 -location {2228.665000 140.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_we} -layer metal5 -location {0.070000 141.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[0]} -layer metal5 -location {2228.665000 141.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[1]} -layer metal5 -location {0.070000 142.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[2]} -layer metal5 -location {2228.665000 142.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[3]} -layer metal5 -location {0.070000 143.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[4]} -layer metal5 -location {2228.665000 143.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[5]} -layer metal5 -location {0.070000 144.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[6]} -layer metal5 -location {2228.665000 144.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[7]} -layer metal5 -location {0.070000 145.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[8]} -layer metal5 -location {2228.665000 145.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[9]} -layer metal5 -location {0.070000 146.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[10]} -layer metal5 -location {2228.665000 146.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[11]} -layer metal5 -location {0.070000 147.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[12]} -layer metal5 -location {2228.665000 147.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[13]} -layer metal5 -location {0.070000 149.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[14]} -layer metal5 -location {2228.665000 149.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[15]} -layer metal5 -location {0.070000 150.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[16]} -layer metal5 -location {2228.665000 150.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[17]} -layer metal5 -location {0.070000 151.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[18]} -layer metal5 -location {2228.665000 151.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[19]} -layer metal5 -location {0.070000 152.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[20]} -layer metal5 -location {2228.665000 152.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[21]} -layer metal5 -location {0.070000 153.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[22]} -layer metal5 -location {2228.665000 153.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[23]} -layer metal5 -location {0.070000 154.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[24]} -layer metal5 -location {2228.665000 154.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[25]} -layer metal5 -location {0.070000 155.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[26]} -layer metal5 -location {2228.665000 155.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[27]} -layer metal5 -location {0.070000 156.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[28]} -layer metal5 -location {2228.665000 156.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[29]} -layer metal5 -location {0.070000 157.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[30]} -layer metal5 -location {2228.665000 157.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_addr[31]} -layer metal5 -location {0.070000 159.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[0]} -layer metal5 -location {2228.665000 159.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[1]} -layer metal5 -location {0.070000 160.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[2]} -layer metal5 -location {2228.665000 160.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[3]} -layer metal5 -location {0.070000 161.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[4]} -layer metal5 -location {2228.665000 161.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[5]} -layer metal5 -location {0.070000 162.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[6]} -layer metal5 -location {2228.665000 162.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[7]} -layer metal5 -location {0.070000 163.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[8]} -layer metal5 -location {2228.665000 163.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[9]} -layer metal5 -location {0.070000 164.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[10]} -layer metal5 -location {2228.665000 164.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[11]} -layer metal5 -location {0.070000 165.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[12]} -layer metal5 -location {2228.665000 165.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[13]} -layer metal5 -location {0.070000 166.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[14]} -layer metal5 -location {2228.665000 166.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[15]} -layer metal5 -location {0.070000 168.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[16]} -layer metal5 -location {2228.665000 168.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[17]} -layer metal5 -location {0.070000 169.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[18]} -layer metal5 -location {2228.665000 169.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[19]} -layer metal5 -location {0.070000 170.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[20]} -layer metal5 -location {2228.665000 170.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[21]} -layer metal5 -location {0.070000 171.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[22]} -layer metal5 -location {2228.665000 171.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[23]} -layer metal5 -location {0.070000 172.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[24]} -layer metal5 -location {2228.665000 172.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[25]} -layer metal5 -location {0.070000 173.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[26]} -layer metal5 -location {2228.665000 173.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[27]} -layer metal5 -location {0.070000 174.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[28]} -layer metal5 -location {2228.665000 174.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[29]} -layer metal5 -location {0.070000 175.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[30]} -layer metal5 -location {2228.665000 175.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_wdata[31]} -layer metal5 -location {0.070000 177.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_be[0]} -layer metal5 -location {2228.665000 177.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_be[1]} -layer metal5 -location {0.070000 178.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_be[2]} -layer metal5 -location {2228.665000 178.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_be[3]} -layer metal5 -location {0.070000 179.270000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_req} -layer metal5 -location {2228.665000 179.270000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[0]} -layer metal5 -location {0.070000 180.390000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[1]} -layer metal5 -location {2228.665000 180.390000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[2]} -layer metal5 -location {0.070000 181.510000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[3]} -layer metal5 -location {2228.665000 181.510000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[4]} -layer metal5 -location {0.070000 182.630000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[5]} -layer metal5 -location {2228.665000 182.630000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[6]} -layer metal5 -location {0.070000 183.750000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[7]} -layer metal5 -location {2228.665000 183.750000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[8]} -layer metal5 -location {0.070000 184.870000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[9]} -layer metal5 -location {2228.665000 184.870000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[10]} -layer metal5 -location {0.070000 185.990000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[11]} -layer metal5 -location {2228.665000 185.990000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[12]} -layer metal5 -location {0.070000 187.110000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[13]} -layer metal5 -location {2228.665000 187.110000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[14]} -layer metal5 -location {0.070000 188.230000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[15]} -layer metal5 -location {2228.665000 188.230000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[16]} -layer metal5 -location {0.070000 189.350000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[17]} -layer metal5 -location {2228.665000 189.350000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[18]} -layer metal5 -location {0.070000 190.470000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[19]} -layer metal5 -location {2228.665000 190.470000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[20]} -layer metal5 -location {0.070000 191.590000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[21]} -layer metal5 -location {2228.665000 191.590000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[22]} -layer metal5 -location {0.070000 192.710000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[23]} -layer metal5 -location {2228.665000 192.710000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[24]} -layer metal5 -location {0.070000 193.830000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[25]} -layer metal5 -location {2228.665000 193.830000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[26]} -layer metal5 -location {0.070000 194.950000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[27]} -layer metal5 -location {2228.665000 194.950000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[28]} -layer metal5 -location {0.070000 196.070000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[29]} -layer metal5 -location {2228.665000 196.070000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[30]} -layer metal5 -location {0.070000 197.190000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_addr[31]} -layer metal5 -location {2228.665000 197.190000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[0]} -layer metal5 -location {0.070000 198.310000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[1]} -layer metal5 -location {2228.665000 198.310000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[2]} -layer metal5 -location {0.070000 199.430000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[3]} -layer metal5 -location {2228.665000 199.430000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[4]} -layer metal5 -location {0.070000 200.550000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[5]} -layer metal5 -location {2228.665000 200.550000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[6]} -layer metal5 -location {0.070000 201.670000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[7]} -layer metal5 -location {2228.665000 201.670000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[8]} -layer metal5 -location {0.070000 202.790000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[9]} -layer metal5 -location {2228.665000 202.790000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[10]} -layer metal5 -location {0.070000 203.910000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[11]} -layer metal5 -location {2228.665000 203.910000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[12]} -layer metal5 -location {0.070000 205.030000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[13]} -layer metal5 -location {2228.665000 205.030000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[14]} -layer metal5 -location {0.070000 206.150000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[15]} -layer metal5 -location {2228.665000 206.150000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[16]} -layer metal5 -location {0.070000 207.270000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[17]} -layer metal5 -location {2228.665000 207.270000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[18]} -layer metal5 -location {0.070000 208.390000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[19]} -layer metal5 -location {2228.665000 208.390000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[20]} -layer metal5 -location {0.070000 209.510000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[21]} -layer metal5 -location {2228.665000 209.510000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[22]} -layer metal5 -location {0.070000 210.630000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[23]} -layer metal5 -location {2228.665000 210.630000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[24]} -layer metal5 -location {0.070000 211.750000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[25]} -layer metal5 -location {2228.665000 211.750000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[26]} -layer metal5 -location {0.070000 212.870000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[27]} -layer metal5 -location {2228.665000 212.870000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[28]} -layer metal5 -location {0.070000 213.990000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[29]} -layer metal5 -location {2228.665000 213.990000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[30]} -layer metal5 -location {0.070000 215.110000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_wdata[31]} -layer metal5 -location {2228.665000 215.110000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_be[0]} -layer metal5 -location {0.070000 216.230000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_be[1]} -layer metal5 -location {2228.665000 216.230000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_be[2]} -layer metal5 -location {0.070000 217.350000} -pin_size {0.14 0.14}
place_pin -pin_name {sw_be[3]} -layer metal5 -location {2228.665000 217.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rvalid} -layer metal5 -location {0.070000 218.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[0]} -layer metal5 -location {2228.665000 218.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[1]} -layer metal5 -location {0.070000 219.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[2]} -layer metal5 -location {2228.665000 219.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[3]} -layer metal5 -location {0.070000 220.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[4]} -layer metal5 -location {2228.665000 220.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[5]} -layer metal5 -location {0.070000 221.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[6]} -layer metal5 -location {2228.665000 221.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[7]} -layer metal5 -location {0.070000 222.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[8]} -layer metal5 -location {2228.665000 222.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[9]} -layer metal5 -location {0.070000 224.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[10]} -layer metal5 -location {2228.665000 224.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[11]} -layer metal5 -location {0.070000 225.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[12]} -layer metal5 -location {2228.665000 225.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[13]} -layer metal5 -location {0.070000 226.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[14]} -layer metal5 -location {2228.665000 226.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[15]} -layer metal5 -location {0.070000 227.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[16]} -layer metal5 -location {2228.665000 227.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[17]} -layer metal5 -location {0.070000 228.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[18]} -layer metal5 -location {2228.665000 228.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[19]} -layer metal5 -location {0.070000 229.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[20]} -layer metal5 -location {2228.665000 229.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[21]} -layer metal5 -location {0.070000 230.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[22]} -layer metal5 -location {2228.665000 230.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[23]} -layer metal5 -location {0.070000 231.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[24]} -layer metal5 -location {2228.665000 231.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[25]} -layer metal5 -location {0.070000 233.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[26]} -layer metal5 -location {2228.665000 233.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[27]} -layer metal5 -location {0.070000 234.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[28]} -layer metal5 -location {2228.665000 234.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[29]} -layer metal5 -location {0.070000 235.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[30]} -layer metal5 -location {2228.665000 235.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[31]} -layer metal5 -location {0.070000 236.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[32]} -layer metal5 -location {2228.665000 236.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[33]} -layer metal5 -location {0.070000 237.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[34]} -layer metal5 -location {2228.665000 237.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[35]} -layer metal5 -location {0.070000 238.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[36]} -layer metal5 -location {2228.665000 238.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[37]} -layer metal5 -location {0.070000 239.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[38]} -layer metal5 -location {2228.665000 239.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[39]} -layer metal5 -location {0.070000 240.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[40]} -layer metal5 -location {2228.665000 240.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[41]} -layer metal5 -location {0.070000 241.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[42]} -layer metal5 -location {2228.665000 241.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[43]} -layer metal5 -location {0.070000 243.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[44]} -layer metal5 -location {2228.665000 243.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[45]} -layer metal5 -location {0.070000 244.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[46]} -layer metal5 -location {2228.665000 244.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[47]} -layer metal5 -location {0.070000 245.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[48]} -layer metal5 -location {2228.665000 245.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[49]} -layer metal5 -location {0.070000 246.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[50]} -layer metal5 -location {2228.665000 246.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[51]} -layer metal5 -location {0.070000 247.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[52]} -layer metal5 -location {2228.665000 247.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[53]} -layer metal5 -location {0.070000 248.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[54]} -layer metal5 -location {2228.665000 248.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[55]} -layer metal5 -location {0.070000 249.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[56]} -layer metal5 -location {2228.665000 249.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[57]} -layer metal5 -location {0.070000 250.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[58]} -layer metal5 -location {2228.665000 250.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[59]} -layer metal5 -location {0.070000 252.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[60]} -layer metal5 -location {2228.665000 252.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[61]} -layer metal5 -location {0.070000 253.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[62]} -layer metal5 -location {2228.665000 253.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[63]} -layer metal5 -location {0.070000 254.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[64]} -layer metal5 -location {2228.665000 254.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[65]} -layer metal5 -location {0.070000 255.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[66]} -layer metal5 -location {2228.665000 255.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[67]} -layer metal5 -location {0.070000 256.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[68]} -layer metal5 -location {2228.665000 256.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[69]} -layer metal5 -location {0.070000 257.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[70]} -layer metal5 -location {2228.665000 257.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[71]} -layer metal5 -location {0.070000 258.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[72]} -layer metal5 -location {2228.665000 258.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[73]} -layer metal5 -location {0.070000 259.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[74]} -layer metal5 -location {2228.665000 259.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[75]} -layer metal5 -location {0.070000 261.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[76]} -layer metal5 -location {2228.665000 261.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[77]} -layer metal5 -location {0.070000 262.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[78]} -layer metal5 -location {2228.665000 262.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[79]} -layer metal5 -location {0.070000 263.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[80]} -layer metal5 -location {2228.665000 263.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[81]} -layer metal5 -location {0.070000 264.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[82]} -layer metal5 -location {2228.665000 264.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[83]} -layer metal5 -location {0.070000 265.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[84]} -layer metal5 -location {2228.665000 265.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[85]} -layer metal5 -location {0.070000 266.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[86]} -layer metal5 -location {2228.665000 266.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[87]} -layer metal5 -location {0.070000 267.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[88]} -layer metal5 -location {2228.665000 267.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[89]} -layer metal5 -location {0.070000 268.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[90]} -layer metal5 -location {2228.665000 268.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[91]} -layer metal5 -location {0.070000 269.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[92]} -layer metal5 -location {2228.665000 269.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[93]} -layer metal5 -location {0.070000 271.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[94]} -layer metal5 -location {2228.665000 271.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[95]} -layer metal5 -location {0.070000 272.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[96]} -layer metal5 -location {2228.665000 272.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[97]} -layer metal5 -location {0.070000 273.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[98]} -layer metal5 -location {2228.665000 273.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[99]} -layer metal5 -location {0.070000 274.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[100]} -layer metal5 -location {2228.665000 274.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[101]} -layer metal5 -location {0.070000 275.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[102]} -layer metal5 -location {2228.665000 275.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[103]} -layer metal5 -location {0.070000 276.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[104]} -layer metal5 -location {2228.665000 276.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[105]} -layer metal5 -location {0.070000 277.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[106]} -layer metal5 -location {2228.665000 277.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[107]} -layer metal5 -location {0.070000 278.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[108]} -layer metal5 -location {2228.665000 278.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[109]} -layer metal5 -location {0.070000 280.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[110]} -layer metal5 -location {2228.665000 280.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[111]} -layer metal5 -location {0.070000 281.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[112]} -layer metal5 -location {2228.665000 281.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[113]} -layer metal5 -location {0.070000 282.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[114]} -layer metal5 -location {2228.665000 282.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[115]} -layer metal5 -location {0.070000 283.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[116]} -layer metal5 -location {2228.665000 283.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[117]} -layer metal5 -location {0.070000 284.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[118]} -layer metal5 -location {2228.665000 284.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[119]} -layer metal5 -location {0.070000 285.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[120]} -layer metal5 -location {2228.665000 285.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[121]} -layer metal5 -location {0.070000 286.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[122]} -layer metal5 -location {2228.665000 286.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[123]} -layer metal5 -location {0.070000 287.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[124]} -layer metal5 -location {2228.665000 287.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[125]} -layer metal5 -location {0.070000 289.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[126]} -layer metal5 -location {2228.665000 289.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[127]} -layer metal5 -location {0.070000 290.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[128]} -layer metal5 -location {2228.665000 290.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[129]} -layer metal5 -location {0.070000 291.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[130]} -layer metal5 -location {2228.665000 291.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[131]} -layer metal5 -location {0.070000 292.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[132]} -layer metal5 -location {2228.665000 292.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[133]} -layer metal5 -location {0.070000 293.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[134]} -layer metal5 -location {2228.665000 293.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[135]} -layer metal5 -location {0.070000 294.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[136]} -layer metal5 -location {2228.665000 294.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[137]} -layer metal5 -location {0.070000 295.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[138]} -layer metal5 -location {2228.665000 295.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[139]} -layer metal5 -location {0.070000 296.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[140]} -layer metal5 -location {2228.665000 296.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[141]} -layer metal5 -location {0.070000 297.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[142]} -layer metal5 -location {2228.665000 297.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[143]} -layer metal5 -location {0.070000 299.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[144]} -layer metal5 -location {2228.665000 299.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[145]} -layer metal5 -location {0.070000 300.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[146]} -layer metal5 -location {2228.665000 300.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[147]} -layer metal5 -location {0.070000 301.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[148]} -layer metal5 -location {2228.665000 301.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[149]} -layer metal5 -location {0.070000 302.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[150]} -layer metal5 -location {2228.665000 302.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[151]} -layer metal5 -location {0.070000 303.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[152]} -layer metal5 -location {2228.665000 303.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[153]} -layer metal5 -location {0.070000 304.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[154]} -layer metal5 -location {2228.665000 304.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[155]} -layer metal5 -location {0.070000 305.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[156]} -layer metal5 -location {2228.665000 305.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[157]} -layer metal5 -location {0.070000 306.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[158]} -layer metal5 -location {2228.665000 306.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[159]} -layer metal5 -location {0.070000 308.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[160]} -layer metal5 -location {2228.665000 308.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[161]} -layer metal5 -location {0.070000 309.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[162]} -layer metal5 -location {2228.665000 309.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[163]} -layer metal5 -location {0.070000 310.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[164]} -layer metal5 -location {2228.665000 310.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[165]} -layer metal5 -location {0.070000 311.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[166]} -layer metal5 -location {2228.665000 311.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[167]} -layer metal5 -location {0.070000 312.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[168]} -layer metal5 -location {2228.665000 312.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[169]} -layer metal5 -location {0.070000 313.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[170]} -layer metal5 -location {2228.665000 313.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[171]} -layer metal5 -location {0.070000 314.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[172]} -layer metal5 -location {2228.665000 314.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[173]} -layer metal5 -location {0.070000 315.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[174]} -layer metal5 -location {2228.665000 315.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[175]} -layer metal5 -location {0.070000 317.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[176]} -layer metal5 -location {2228.665000 317.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[177]} -layer metal5 -location {0.070000 318.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[178]} -layer metal5 -location {2228.665000 318.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[179]} -layer metal5 -location {0.070000 319.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[180]} -layer metal5 -location {2228.665000 319.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[181]} -layer metal5 -location {0.070000 320.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[182]} -layer metal5 -location {2228.665000 320.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[183]} -layer metal5 -location {0.070000 321.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[184]} -layer metal5 -location {2228.665000 321.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[185]} -layer metal5 -location {0.070000 322.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[186]} -layer metal5 -location {2228.665000 322.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[187]} -layer metal5 -location {0.070000 323.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[188]} -layer metal5 -location {2228.665000 323.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[189]} -layer metal5 -location {0.070000 324.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[190]} -layer metal5 -location {2228.665000 324.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[191]} -layer metal5 -location {0.070000 325.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[192]} -layer metal5 -location {2228.665000 325.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[193]} -layer metal5 -location {0.070000 327.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[194]} -layer metal5 -location {2228.665000 327.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[195]} -layer metal5 -location {0.070000 328.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[196]} -layer metal5 -location {2228.665000 328.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[197]} -layer metal5 -location {0.070000 329.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[198]} -layer metal5 -location {2228.665000 329.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[199]} -layer metal5 -location {0.070000 330.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[200]} -layer metal5 -location {2228.665000 330.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[201]} -layer metal5 -location {0.070000 331.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[202]} -layer metal5 -location {2228.665000 331.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[203]} -layer metal5 -location {0.070000 332.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[204]} -layer metal5 -location {2228.665000 332.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[205]} -layer metal5 -location {0.070000 333.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[206]} -layer metal5 -location {2228.665000 333.830000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[207]} -layer metal5 -location {0.070000 334.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[208]} -layer metal5 -location {2228.665000 334.950000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[209]} -layer metal5 -location {0.070000 336.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[210]} -layer metal5 -location {2228.665000 336.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[211]} -layer metal5 -location {0.070000 337.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[212]} -layer metal5 -location {2228.665000 337.190000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[213]} -layer metal5 -location {0.070000 338.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[214]} -layer metal5 -location {2228.665000 338.310000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[215]} -layer metal5 -location {0.070000 339.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[216]} -layer metal5 -location {2228.665000 339.430000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[217]} -layer metal5 -location {0.070000 340.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[218]} -layer metal5 -location {2228.665000 340.550000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[219]} -layer metal5 -location {0.070000 341.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[220]} -layer metal5 -location {2228.665000 341.670000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[221]} -layer metal5 -location {0.070000 342.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[222]} -layer metal5 -location {2228.665000 342.790000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[223]} -layer metal5 -location {0.070000 343.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[224]} -layer metal5 -location {2228.665000 343.910000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[225]} -layer metal5 -location {0.070000 345.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[226]} -layer metal5 -location {2228.665000 345.030000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[227]} -layer metal5 -location {0.070000 346.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[228]} -layer metal5 -location {2228.665000 346.150000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[229]} -layer metal5 -location {0.070000 347.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[230]} -layer metal5 -location {2228.665000 347.270000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[231]} -layer metal5 -location {0.070000 348.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[232]} -layer metal5 -location {2228.665000 348.390000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[233]} -layer metal5 -location {0.070000 349.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[234]} -layer metal5 -location {2228.665000 349.510000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[235]} -layer metal5 -location {0.070000 350.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[236]} -layer metal5 -location {2228.665000 350.630000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[237]} -layer metal5 -location {0.070000 351.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[238]} -layer metal5 -location {2228.665000 351.750000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[239]} -layer metal5 -location {0.070000 352.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[240]} -layer metal5 -location {2228.665000 352.870000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[241]} -layer metal5 -location {0.070000 353.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[242]} -layer metal5 -location {2228.665000 353.990000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[243]} -layer metal5 -location {0.070000 355.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[244]} -layer metal5 -location {2228.665000 355.110000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[245]} -layer metal5 -location {0.070000 356.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[246]} -layer metal5 -location {2228.665000 356.230000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[247]} -layer metal5 -location {0.070000 357.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[248]} -layer metal5 -location {2228.665000 357.350000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[249]} -layer metal5 -location {0.070000 358.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[250]} -layer metal5 -location {2228.665000 358.470000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[251]} -layer metal5 -location {0.070000 359.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[252]} -layer metal5 -location {2228.665000 359.590000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[253]} -layer metal5 -location {0.070000 360.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[254]} -layer metal5 -location {2228.665000 360.710000} -pin_size {0.14 0.14}
place_pin -pin_name {a_rdata[255]} -layer metal5 -location {0.070000 361.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_req} -layer metal5 -location {2228.665000 361.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_tag} -layer metal5 -location {0.070000 362.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_we} -layer metal5 -location {2228.665000 362.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[0]} -layer metal5 -location {0.070000 364.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[1]} -layer metal5 -location {2228.665000 364.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[2]} -layer metal5 -location {0.070000 365.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[3]} -layer metal5 -location {2228.665000 365.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[4]} -layer metal5 -location {0.070000 366.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[5]} -layer metal5 -location {2228.665000 366.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[6]} -layer metal5 -location {0.070000 367.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wmask[7]} -layer metal5 -location {2228.665000 367.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[0]} -layer metal5 -location {0.070000 368.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[1]} -layer metal5 -location {2228.665000 368.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[2]} -layer metal5 -location {0.070000 369.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[3]} -layer metal5 -location {2228.665000 369.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[4]} -layer metal5 -location {0.070000 370.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[5]} -layer metal5 -location {2228.665000 370.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[6]} -layer metal5 -location {0.070000 371.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[7]} -layer metal5 -location {2228.665000 371.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[8]} -layer metal5 -location {0.070000 373.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[9]} -layer metal5 -location {2228.665000 373.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[10]} -layer metal5 -location {0.070000 374.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[11]} -layer metal5 -location {2228.665000 374.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[12]} -layer metal5 -location {0.070000 375.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[13]} -layer metal5 -location {2228.665000 375.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[14]} -layer metal5 -location {0.070000 376.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[15]} -layer metal5 -location {2228.665000 376.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[16]} -layer metal5 -location {0.070000 377.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[17]} -layer metal5 -location {2228.665000 377.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[18]} -layer metal5 -location {0.070000 378.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[19]} -layer metal5 -location {2228.665000 378.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[20]} -layer metal5 -location {0.070000 379.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[21]} -layer metal5 -location {2228.665000 379.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[22]} -layer metal5 -location {0.070000 380.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[23]} -layer metal5 -location {2228.665000 380.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[24]} -layer metal5 -location {0.070000 381.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[25]} -layer metal5 -location {2228.665000 381.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[26]} -layer metal5 -location {0.070000 383.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[27]} -layer metal5 -location {2228.665000 383.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[28]} -layer metal5 -location {0.070000 384.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[29]} -layer metal5 -location {2228.665000 384.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[30]} -layer metal5 -location {0.070000 385.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[31]} -layer metal5 -location {2228.665000 385.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[32]} -layer metal5 -location {0.070000 386.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[33]} -layer metal5 -location {2228.665000 386.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[34]} -layer metal5 -location {0.070000 387.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[35]} -layer metal5 -location {2228.665000 387.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[36]} -layer metal5 -location {0.070000 388.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[37]} -layer metal5 -location {2228.665000 388.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[38]} -layer metal5 -location {0.070000 389.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[39]} -layer metal5 -location {2228.665000 389.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[40]} -layer metal5 -location {0.070000 390.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[41]} -layer metal5 -location {2228.665000 390.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[42]} -layer metal5 -location {0.070000 392.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[43]} -layer metal5 -location {2228.665000 392.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[44]} -layer metal5 -location {0.070000 393.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[45]} -layer metal5 -location {2228.665000 393.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[46]} -layer metal5 -location {0.070000 394.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[47]} -layer metal5 -location {2228.665000 394.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[48]} -layer metal5 -location {0.070000 395.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[49]} -layer metal5 -location {2228.665000 395.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[50]} -layer metal5 -location {0.070000 396.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[51]} -layer metal5 -location {2228.665000 396.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[52]} -layer metal5 -location {0.070000 397.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[53]} -layer metal5 -location {2228.665000 397.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[54]} -layer metal5 -location {0.070000 398.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[55]} -layer metal5 -location {2228.665000 398.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[56]} -layer metal5 -location {0.070000 399.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[57]} -layer metal5 -location {2228.665000 399.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[58]} -layer metal5 -location {0.070000 401.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[59]} -layer metal5 -location {2228.665000 401.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[60]} -layer metal5 -location {0.070000 402.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[61]} -layer metal5 -location {2228.665000 402.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[62]} -layer metal5 -location {0.070000 403.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[63]} -layer metal5 -location {2228.665000 403.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[64]} -layer metal5 -location {0.070000 404.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[65]} -layer metal5 -location {2228.665000 404.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[66]} -layer metal5 -location {0.070000 405.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[67]} -layer metal5 -location {2228.665000 405.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[68]} -layer metal5 -location {0.070000 406.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[69]} -layer metal5 -location {2228.665000 406.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[70]} -layer metal5 -location {0.070000 407.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[71]} -layer metal5 -location {2228.665000 407.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[72]} -layer metal5 -location {0.070000 408.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[73]} -layer metal5 -location {2228.665000 408.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[74]} -layer metal5 -location {0.070000 409.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[75]} -layer metal5 -location {2228.665000 409.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[76]} -layer metal5 -location {0.070000 411.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[77]} -layer metal5 -location {2228.665000 411.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[78]} -layer metal5 -location {0.070000 412.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[79]} -layer metal5 -location {2228.665000 412.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[80]} -layer metal5 -location {0.070000 413.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[81]} -layer metal5 -location {2228.665000 413.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[82]} -layer metal5 -location {0.070000 414.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[83]} -layer metal5 -location {2228.665000 414.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[84]} -layer metal5 -location {0.070000 415.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[85]} -layer metal5 -location {2228.665000 415.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[86]} -layer metal5 -location {0.070000 416.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[87]} -layer metal5 -location {2228.665000 416.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[88]} -layer metal5 -location {0.070000 417.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[89]} -layer metal5 -location {2228.665000 417.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[90]} -layer metal5 -location {0.070000 418.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[91]} -layer metal5 -location {2228.665000 418.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[92]} -layer metal5 -location {0.070000 420.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[93]} -layer metal5 -location {2228.665000 420.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[94]} -layer metal5 -location {0.070000 421.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[95]} -layer metal5 -location {2228.665000 421.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[96]} -layer metal5 -location {0.070000 422.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[97]} -layer metal5 -location {2228.665000 422.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[98]} -layer metal5 -location {0.070000 423.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[99]} -layer metal5 -location {2228.665000 423.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[100]} -layer metal5 -location {0.070000 424.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[101]} -layer metal5 -location {2228.665000 424.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[102]} -layer metal5 -location {0.070000 425.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[103]} -layer metal5 -location {2228.665000 425.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[104]} -layer metal5 -location {0.070000 426.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[105]} -layer metal5 -location {2228.665000 426.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[106]} -layer metal5 -location {0.070000 427.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[107]} -layer metal5 -location {2228.665000 427.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[108]} -layer metal5 -location {0.070000 429.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[109]} -layer metal5 -location {2228.665000 429.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[110]} -layer metal6 -location {84.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[111]} -layer metal6 -location {85.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[112]} -layer metal6 -location {85.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[113]} -layer metal6 -location {86.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[114]} -layer metal6 -location {86.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[115]} -layer metal6 -location {87.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[116]} -layer metal6 -location {87.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[117]} -layer metal6 -location {88.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[118]} -layer metal6 -location {88.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[119]} -layer metal6 -location {89.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[120]} -layer metal6 -location {89.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[121]} -layer metal6 -location {90.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[122]} -layer metal6 -location {90.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[123]} -layer metal6 -location {91.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[124]} -layer metal6 -location {91.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[125]} -layer metal6 -location {93.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[126]} -layer metal6 -location {93.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[127]} -layer metal6 -location {94.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[128]} -layer metal6 -location {94.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[129]} -layer metal6 -location {95.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[130]} -layer metal6 -location {95.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[131]} -layer metal6 -location {96.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[132]} -layer metal6 -location {96.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[133]} -layer metal6 -location {97.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[134]} -layer metal6 -location {97.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[135]} -layer metal6 -location {98.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[136]} -layer metal6 -location {98.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[137]} -layer metal6 -location {99.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[138]} -layer metal6 -location {99.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[139]} -layer metal6 -location {100.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[140]} -layer metal6 -location {100.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[141]} -layer metal6 -location {102.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[142]} -layer metal6 -location {102.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[143]} -layer metal6 -location {103.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[144]} -layer metal6 -location {103.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[145]} -layer metal6 -location {104.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[146]} -layer metal6 -location {104.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[147]} -layer metal6 -location {105.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[148]} -layer metal6 -location {105.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[149]} -layer metal6 -location {106.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[150]} -layer metal6 -location {106.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[151]} -layer metal6 -location {107.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[152]} -layer metal6 -location {107.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[153]} -layer metal6 -location {108.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[154]} -layer metal6 -location {108.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[155]} -layer metal6 -location {109.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[156]} -layer metal6 -location {109.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[157]} -layer metal6 -location {110.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[158]} -layer metal6 -location {110.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[159]} -layer metal6 -location {112.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[160]} -layer metal6 -location {112.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[161]} -layer metal6 -location {113.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[162]} -layer metal6 -location {113.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[163]} -layer metal6 -location {114.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[164]} -layer metal6 -location {114.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[165]} -layer metal6 -location {115.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[166]} -layer metal6 -location {115.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[167]} -layer metal6 -location {116.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[168]} -layer metal6 -location {116.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[169]} -layer metal6 -location {117.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[170]} -layer metal6 -location {117.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[171]} -layer metal6 -location {118.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[172]} -layer metal6 -location {118.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[173]} -layer metal6 -location {119.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[174]} -layer metal6 -location {119.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[175]} -layer metal6 -location {121.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[176]} -layer metal6 -location {121.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[177]} -layer metal6 -location {122.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[178]} -layer metal6 -location {122.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[179]} -layer metal6 -location {123.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[180]} -layer metal6 -location {123.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[181]} -layer metal6 -location {124.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[182]} -layer metal6 -location {124.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[183]} -layer metal6 -location {125.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[184]} -layer metal6 -location {125.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[185]} -layer metal6 -location {126.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[186]} -layer metal6 -location {126.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[187]} -layer metal6 -location {127.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[188]} -layer metal6 -location {127.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[189]} -layer metal6 -location {128.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[190]} -layer metal6 -location {128.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[191]} -layer metal6 -location {130.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[192]} -layer metal6 -location {130.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[193]} -layer metal6 -location {131.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[194]} -layer metal6 -location {131.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[195]} -layer metal6 -location {132.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[196]} -layer metal6 -location {132.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[197]} -layer metal6 -location {133.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[198]} -layer metal6 -location {133.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[199]} -layer metal6 -location {134.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[200]} -layer metal6 -location {134.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[201]} -layer metal6 -location {135.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[202]} -layer metal6 -location {135.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[203]} -layer metal6 -location {136.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[204]} -layer metal6 -location {136.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[205]} -layer metal6 -location {137.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[206]} -layer metal6 -location {137.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[207]} -layer metal6 -location {138.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[208]} -layer metal6 -location {138.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[209]} -layer metal6 -location {140.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[210]} -layer metal6 -location {140.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[211]} -layer metal6 -location {141.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[212]} -layer metal6 -location {141.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[213]} -layer metal6 -location {142.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[214]} -layer metal6 -location {142.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[215]} -layer metal6 -location {143.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[216]} -layer metal6 -location {143.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[217]} -layer metal6 -location {144.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[218]} -layer metal6 -location {144.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[219]} -layer metal6 -location {145.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[220]} -layer metal6 -location {145.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[221]} -layer metal6 -location {146.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[222]} -layer metal6 -location {146.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[223]} -layer metal6 -location {147.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[224]} -layer metal6 -location {147.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[225]} -layer metal6 -location {149.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[226]} -layer metal6 -location {149.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[227]} -layer metal6 -location {150.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[228]} -layer metal6 -location {150.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[229]} -layer metal6 -location {151.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[230]} -layer metal6 -location {151.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[231]} -layer metal6 -location {152.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[232]} -layer metal6 -location {152.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[233]} -layer metal6 -location {153.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[234]} -layer metal6 -location {153.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[235]} -layer metal6 -location {154.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[236]} -layer metal6 -location {154.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[237]} -layer metal6 -location {155.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[238]} -layer metal6 -location {155.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[239]} -layer metal6 -location {156.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[240]} -layer metal6 -location {156.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[241]} -layer metal6 -location {158.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[242]} -layer metal6 -location {158.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[243]} -layer metal6 -location {159.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[244]} -layer metal6 -location {159.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[245]} -layer metal6 -location {160.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[246]} -layer metal6 -location {160.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[247]} -layer metal6 -location {161.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[248]} -layer metal6 -location {161.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[249]} -layer metal6 -location {162.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[250]} -layer metal6 -location {162.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[251]} -layer metal6 -location {163.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[252]} -layer metal6 -location {163.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[253]} -layer metal6 -location {164.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[254]} -layer metal6 -location {164.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_wdata[255]} -layer metal6 -location {165.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[0]} -layer metal6 -location {165.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[1]} -layer metal6 -location {166.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[2]} -layer metal6 -location {166.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[3]} -layer metal6 -location {168.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[4]} -layer metal6 -location {168.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[5]} -layer metal6 -location {169.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[6]} -layer metal6 -location {169.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[7]} -layer metal6 -location {170.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[8]} -layer metal6 -location {170.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[9]} -layer metal6 -location {171.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[10]} -layer metal6 -location {171.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[11]} -layer metal6 -location {172.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[12]} -layer metal6 -location {172.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[13]} -layer metal6 -location {173.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[14]} -layer metal6 -location {173.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[15]} -layer metal6 -location {174.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[16]} -layer metal6 -location {174.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[17]} -layer metal6 -location {175.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[18]} -layer metal6 -location {175.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[19]} -layer metal6 -location {177.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[20]} -layer metal6 -location {177.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[21]} -layer metal6 -location {178.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[22]} -layer metal6 -location {178.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[23]} -layer metal6 -location {179.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[24]} -layer metal6 -location {179.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[25]} -layer metal6 -location {180.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[26]} -layer metal6 -location {180.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[27]} -layer metal6 -location {181.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[28]} -layer metal6 -location {181.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[29]} -layer metal6 -location {182.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[30]} -layer metal6 -location {182.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_addr[31]} -layer metal6 -location {183.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_par} -layer metal6 -location {183.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rvalid} -layer metal6 -location {184.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rtag} -layer metal6 -location {184.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[0]} -layer metal6 -location {186.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[1]} -layer metal6 -location {186.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[2]} -layer metal6 -location {187.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[3]} -layer metal6 -location {187.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[4]} -layer metal6 -location {188.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[5]} -layer metal6 -location {188.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[6]} -layer metal6 -location {189.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[7]} -layer metal5 -location {0.070000 430.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[8]} -layer metal5 -location {2228.665000 430.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[9]} -layer metal5 -location {0.070000 431.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[10]} -layer metal5 -location {2228.665000 431.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[11]} -layer metal5 -location {0.070000 432.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[12]} -layer metal5 -location {2228.665000 432.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[13]} -layer metal5 -location {0.070000 433.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[14]} -layer metal5 -location {2228.665000 433.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[15]} -layer metal5 -location {0.070000 434.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[16]} -layer metal5 -location {2228.665000 434.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[17]} -layer metal5 -location {0.070000 435.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[18]} -layer metal5 -location {2228.665000 435.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[19]} -layer metal5 -location {0.070000 436.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[20]} -layer metal5 -location {2228.665000 436.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[21]} -layer metal5 -location {0.070000 437.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[22]} -layer metal5 -location {2228.665000 437.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[23]} -layer metal5 -location {0.070000 439.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[24]} -layer metal5 -location {2228.665000 439.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[25]} -layer metal5 -location {0.070000 440.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[26]} -layer metal5 -location {2228.665000 440.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[27]} -layer metal5 -location {0.070000 441.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[28]} -layer metal5 -location {2228.665000 441.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[29]} -layer metal5 -location {0.070000 442.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[30]} -layer metal5 -location {2228.665000 442.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[31]} -layer metal5 -location {0.070000 443.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[32]} -layer metal5 -location {2228.665000 443.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[33]} -layer metal5 -location {0.070000 444.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[34]} -layer metal5 -location {2228.665000 444.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[35]} -layer metal5 -location {0.070000 445.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[36]} -layer metal5 -location {2228.665000 445.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[37]} -layer metal5 -location {0.070000 446.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[38]} -layer metal5 -location {2228.665000 446.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[39]} -layer metal5 -location {0.070000 448.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[40]} -layer metal5 -location {2228.665000 448.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[41]} -layer metal5 -location {0.070000 449.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[42]} -layer metal5 -location {2228.665000 449.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[43]} -layer metal5 -location {0.070000 450.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[44]} -layer metal5 -location {2228.665000 450.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[45]} -layer metal5 -location {0.070000 451.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[46]} -layer metal5 -location {2228.665000 451.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[47]} -layer metal5 -location {0.070000 452.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[48]} -layer metal5 -location {2228.665000 452.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[49]} -layer metal5 -location {0.070000 453.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[50]} -layer metal5 -location {2228.665000 453.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[51]} -layer metal5 -location {0.070000 454.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[52]} -layer metal5 -location {2228.665000 454.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[53]} -layer metal5 -location {0.070000 455.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[54]} -layer metal5 -location {2228.665000 455.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[55]} -layer metal5 -location {0.070000 457.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[56]} -layer metal5 -location {2228.665000 457.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[57]} -layer metal5 -location {0.070000 458.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[58]} -layer metal5 -location {2228.665000 458.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[59]} -layer metal5 -location {0.070000 459.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[60]} -layer metal5 -location {2228.665000 459.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[61]} -layer metal5 -location {0.070000 460.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[62]} -layer metal5 -location {2228.665000 460.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[63]} -layer metal5 -location {0.070000 461.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[64]} -layer metal5 -location {2228.665000 461.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[65]} -layer metal5 -location {0.070000 462.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[66]} -layer metal5 -location {2228.665000 462.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[67]} -layer metal5 -location {0.070000 463.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[68]} -layer metal5 -location {2228.665000 463.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[69]} -layer metal5 -location {0.070000 464.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[70]} -layer metal5 -location {2228.665000 464.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[71]} -layer metal5 -location {0.070000 465.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[72]} -layer metal5 -location {2228.665000 465.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[73]} -layer metal5 -location {0.070000 467.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[74]} -layer metal5 -location {2228.665000 467.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[75]} -layer metal5 -location {0.070000 468.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[76]} -layer metal5 -location {2228.665000 468.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[77]} -layer metal5 -location {0.070000 469.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[78]} -layer metal5 -location {2228.665000 469.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[79]} -layer metal5 -location {0.070000 470.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[80]} -layer metal5 -location {2228.665000 470.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[81]} -layer metal5 -location {0.070000 471.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[82]} -layer metal5 -location {2228.665000 471.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[83]} -layer metal5 -location {0.070000 472.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[84]} -layer metal5 -location {2228.665000 472.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[85]} -layer metal5 -location {0.070000 473.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[86]} -layer metal5 -location {2228.665000 473.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[87]} -layer metal5 -location {0.070000 474.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[88]} -layer metal5 -location {2228.665000 474.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[89]} -layer metal5 -location {0.070000 476.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[90]} -layer metal5 -location {2228.665000 476.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[91]} -layer metal5 -location {0.070000 477.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[92]} -layer metal5 -location {2228.665000 477.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[93]} -layer metal5 -location {0.070000 478.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[94]} -layer metal5 -location {2228.665000 478.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[95]} -layer metal5 -location {0.070000 479.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[96]} -layer metal5 -location {2228.665000 479.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[97]} -layer metal5 -location {0.070000 480.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[98]} -layer metal5 -location {2228.665000 480.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[99]} -layer metal5 -location {0.070000 481.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[100]} -layer metal5 -location {2228.665000 481.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[101]} -layer metal5 -location {0.070000 482.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[102]} -layer metal5 -location {2228.665000 482.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[103]} -layer metal5 -location {0.070000 483.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[104]} -layer metal5 -location {2228.665000 483.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[105]} -layer metal5 -location {0.070000 485.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[106]} -layer metal5 -location {2228.665000 485.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[107]} -layer metal5 -location {0.070000 486.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[108]} -layer metal5 -location {2228.665000 486.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[109]} -layer metal5 -location {0.070000 487.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[110]} -layer metal5 -location {2228.665000 487.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[111]} -layer metal5 -location {0.070000 488.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[112]} -layer metal5 -location {2228.665000 488.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[113]} -layer metal5 -location {0.070000 489.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[114]} -layer metal5 -location {2228.665000 489.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[115]} -layer metal5 -location {0.070000 490.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[116]} -layer metal5 -location {2228.665000 490.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[117]} -layer metal5 -location {0.070000 491.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[118]} -layer metal5 -location {2228.665000 491.750000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[119]} -layer metal5 -location {0.070000 492.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[120]} -layer metal5 -location {2228.665000 492.870000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[121]} -layer metal5 -location {0.070000 493.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[122]} -layer metal5 -location {2228.665000 493.990000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[123]} -layer metal5 -location {0.070000 495.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[124]} -layer metal5 -location {2228.665000 495.110000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[125]} -layer metal5 -location {0.070000 496.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[126]} -layer metal5 -location {2228.665000 496.230000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[127]} -layer metal5 -location {0.070000 497.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[128]} -layer metal5 -location {2228.665000 497.350000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[129]} -layer metal5 -location {0.070000 498.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[130]} -layer metal5 -location {2228.665000 498.470000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[131]} -layer metal5 -location {0.070000 499.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[132]} -layer metal5 -location {2228.665000 499.590000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[133]} -layer metal5 -location {0.070000 500.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[134]} -layer metal5 -location {2228.665000 500.710000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[135]} -layer metal5 -location {0.070000 501.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[136]} -layer metal5 -location {2228.665000 501.830000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[137]} -layer metal5 -location {0.070000 502.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[138]} -layer metal5 -location {2228.665000 502.950000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[139]} -layer metal5 -location {0.070000 504.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[140]} -layer metal5 -location {2228.665000 504.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[141]} -layer metal5 -location {0.070000 505.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[142]} -layer metal5 -location {2228.665000 505.190000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[143]} -layer metal5 -location {0.070000 506.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[144]} -layer metal5 -location {2228.665000 506.310000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[145]} -layer metal5 -location {0.070000 507.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[146]} -layer metal5 -location {2228.665000 507.430000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[147]} -layer metal5 -location {0.070000 508.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[148]} -layer metal5 -location {2228.665000 508.550000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[149]} -layer metal5 -location {0.070000 509.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[150]} -layer metal5 -location {2228.665000 509.670000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[151]} -layer metal5 -location {0.070000 510.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[152]} -layer metal5 -location {2228.665000 510.790000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[153]} -layer metal5 -location {0.070000 511.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[154]} -layer metal5 -location {2228.665000 511.910000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[155]} -layer metal5 -location {0.070000 513.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[156]} -layer metal5 -location {2228.665000 513.030000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[157]} -layer metal5 -location {0.070000 514.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[158]} -layer metal5 -location {2228.665000 514.150000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[159]} -layer metal5 -location {0.070000 515.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[160]} -layer metal5 -location {2228.665000 515.270000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[161]} -layer metal5 -location {0.070000 516.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[162]} -layer metal5 -location {2228.665000 516.390000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[163]} -layer metal5 -location {0.070000 517.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[164]} -layer metal5 -location {2228.665000 517.510000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[165]} -layer metal5 -location {0.070000 518.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[166]} -layer metal5 -location {2228.665000 518.630000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[167]} -layer metal6 -location {189.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[168]} -layer metal6 -location {190.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[169]} -layer metal6 -location {190.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[170]} -layer metal6 -location {191.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[171]} -layer metal6 -location {191.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[172]} -layer metal6 -location {192.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[173]} -layer metal6 -location {192.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[174]} -layer metal6 -location {193.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[175]} -layer metal6 -location {193.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[176]} -layer metal6 -location {194.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[177]} -layer metal6 -location {194.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[178]} -layer metal6 -location {196.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[179]} -layer metal6 -location {196.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[180]} -layer metal6 -location {197.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[181]} -layer metal6 -location {197.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[182]} -layer metal6 -location {198.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[183]} -layer metal6 -location {198.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[184]} -layer metal6 -location {199.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[185]} -layer metal6 -location {199.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[186]} -layer metal6 -location {200.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[187]} -layer metal6 -location {200.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[188]} -layer metal6 -location {201.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[189]} -layer metal6 -location {201.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[190]} -layer metal6 -location {202.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[191]} -layer metal6 -location {202.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[192]} -layer metal6 -location {203.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[193]} -layer metal6 -location {203.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[194]} -layer metal6 -location {205.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[195]} -layer metal6 -location {205.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[196]} -layer metal6 -location {206.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[197]} -layer metal6 -location {206.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[198]} -layer metal6 -location {207.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[199]} -layer metal6 -location {207.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[200]} -layer metal6 -location {208.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[201]} -layer metal6 -location {208.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[202]} -layer metal6 -location {209.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[203]} -layer metal6 -location {209.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[204]} -layer metal6 -location {210.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[205]} -layer metal6 -location {210.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[206]} -layer metal6 -location {211.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[207]} -layer metal6 -location {211.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[208]} -layer metal6 -location {212.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[209]} -layer metal6 -location {212.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[210]} -layer metal6 -location {214.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[211]} -layer metal6 -location {214.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[212]} -layer metal6 -location {215.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[213]} -layer metal6 -location {215.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[214]} -layer metal6 -location {216.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[215]} -layer metal6 -location {216.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[216]} -layer metal6 -location {217.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[217]} -layer metal6 -location {217.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[218]} -layer metal6 -location {218.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[219]} -layer metal6 -location {218.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[220]} -layer metal6 -location {219.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[221]} -layer metal6 -location {219.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[222]} -layer metal6 -location {220.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[223]} -layer metal6 -location {220.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[224]} -layer metal6 -location {221.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[225]} -layer metal6 -location {221.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[226]} -layer metal6 -location {222.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[227]} -layer metal6 -location {222.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[228]} -layer metal6 -location {224.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[229]} -layer metal6 -location {224.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[230]} -layer metal6 -location {225.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[231]} -layer metal6 -location {225.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[232]} -layer metal6 -location {226.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[233]} -layer metal6 -location {226.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[234]} -layer metal6 -location {227.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[235]} -layer metal6 -location {227.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[236]} -layer metal6 -location {228.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[237]} -layer metal6 -location {228.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[238]} -layer metal6 -location {229.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[239]} -layer metal6 -location {229.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[240]} -layer metal6 -location {230.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[241]} -layer metal6 -location {230.815000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[242]} -layer metal6 -location {231.935000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[243]} -layer metal6 -location {231.935000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[244]} -layer metal6 -location {233.055000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[245]} -layer metal6 -location {233.055000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[246]} -layer metal6 -location {234.175000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[247]} -layer metal6 -location {234.175000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[248]} -layer metal6 -location {235.295000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[249]} -layer metal6 -location {235.295000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[250]} -layer metal6 -location {236.415000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[251]} -layer metal6 -location {236.415000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[252]} -layer metal6 -location {237.535000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[253]} -layer metal6 -location {237.535000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[254]} -layer metal6 -location {238.655000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {b_rdata[255]} -layer metal6 -location {238.655000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {halted} -layer metal6 -location {239.775000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {error} -layer metal6 -location {239.775000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {wait_to} -layer metal6 -location {240.895000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {a_inval} -layer metal6 -location {240.895000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[0]} -layer metal6 -location {242.015000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[1]} -layer metal6 -location {242.015000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[2]} -layer metal6 -location {243.135000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[3]} -layer metal6 -location {243.135000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[4]} -layer metal6 -location {244.255000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[5]} -layer metal6 -location {244.255000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[6]} -layer metal6 -location {245.375000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[7]} -layer metal6 -location {245.375000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[8]} -layer metal6 -location {246.495000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[9]} -layer metal6 -location {246.495000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[10]} -layer metal6 -location {247.615000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[11]} -layer metal6 -location {247.615000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[12]} -layer metal6 -location {248.735000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[13]} -layer metal6 -location {248.735000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[14]} -layer metal6 -location {249.855000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[15]} -layer metal6 -location {249.855000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[16]} -layer metal6 -location {250.975000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[17]} -layer metal6 -location {250.975000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[18]} -layer metal6 -location {252.095000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[19]} -layer metal6 -location {252.095000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[20]} -layer metal6 -location {253.215000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[21]} -layer metal6 -location {253.215000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[22]} -layer metal6 -location {254.335000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[23]} -layer metal6 -location {254.335000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[24]} -layer metal6 -location {255.455000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[25]} -layer metal6 -location {255.455000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[26]} -layer metal6 -location {256.575000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[27]} -layer metal6 -location {256.575000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[28]} -layer metal6 -location {257.695000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[29]} -layer metal6 -location {257.695000 3409.265000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[30]} -layer metal6 -location {258.815000 0.070000} -pin_size {0.14 0.14}
place_pin -pin_name {icount[31]} -layer metal6 -location {258.815000 3409.265000} -pin_size {0.14 0.14}
