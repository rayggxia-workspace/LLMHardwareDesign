read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/leaf_detail.lef}
read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_timing_models/r02/gemm-C/timing.lib}
read_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/fixture.v}
link_design escape_fixture
initialize_floorplan -die_area {0 0 1336.52 1336.52} -core_area {10 10 1326.52 1326.52} -site FreePDK45_38x28_10R_NP_162NW_34O
source /OpenROAD-flow-scripts/flow/platforms/nangate45/make_tracks.tcl
place_macro -macro_name u_macro -location {89.6 89.6} -orientation R0 -exact
cut_rows -halo_width_x 2 -halo_width_y 2
add_global_connection -net VDD -inst_pattern {.*} -pin_pattern {^VDD$} -power
add_global_connection -net VSS -inst_pattern {.*} -pin_pattern {^VSS$} -ground
global_connect
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name parent_grid -voltage_domains CORE -pins metal10
add_pdn_stripe -grid parent_grid -layer metal1 -width 0.17 -pitch 2.4 -offset 0 -followpins
add_pdn_stripe -grid parent_grid -layer metal4 -width 0.48 -pitch 56 -offset 2
add_pdn_stripe -grid parent_grid -layer metal7 -width 1.40 -pitch 30 -offset 2
add_pdn_stripe -grid parent_grid -layer metal10 -width 1.40 -pitch 30 -offset 2
add_pdn_connect -grid parent_grid -layers {metal1 metal4}
add_pdn_connect -grid parent_grid -layers {metal4 metal7}
add_pdn_connect -grid parent_grid -layers {metal7 metal10}
define_pdn_grid -name macro_pg -voltage_domains CORE -macro -instances u_macro -grid_over_pg_pins -halo {2 2 2 2}
add_pdn_connect -grid macro_pg -layers {metal7 metal10}
pdngen -failed_via_report {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/failed_vias.rpt}
set llhd_macro_instances {u_macro}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/all-block-access-r03/code/filter_parent_pg.tcl}
check_power_grid -net VDD -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/VDD.initial.rpt}
check_power_grid -net VSS -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/VSS.initial.rpt}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/placed.odb}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r01/gemm-C/parent_M10_PG.tsv} w]
puts $f "x0\ty0\tx1\ty1"
foreach n [[ord::get_db_block] getNets] {foreach sw [$n getSWires] {foreach s [$sw getWires] {
if {[$s isVia]} {set v [$s getTechVia];if {$v eq "NULL"} {set v [$s getBlockVia]};lassign [$s getViaXY] x y;foreach b [$v getBoxes] {if {[[$b getTechLayer] getName] eq "metal10"} {puts $f [join [list [expr {[$b xMin]+$x}] [expr {[$b yMin]+$y}] [expr {[$b xMax]+$x}] [expr {[$b yMax]+$y}]] "\t"]}}} elseif {[[$s getTechLayer] getName] eq "metal10"} {puts $f [join [list [$s xMin] [$s yMin] [$s xMax] [$s yMax]] "\t"]}
}}}
close $f
