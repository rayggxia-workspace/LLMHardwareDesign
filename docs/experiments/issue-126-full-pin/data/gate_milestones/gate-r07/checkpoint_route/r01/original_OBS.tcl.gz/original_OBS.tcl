proc obs_contract {ob} {set bb [$ob getBBox];return [list [$ob getId] [[$bb getTechLayer] getName] [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax]]}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/access-r03/opentpu_aux-C/clean.odb}
set original_obs {};foreach ob [[ord::get_db_block] getObstructions] {lappend original_obs [obs_contract $ob]};set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/checkpoint_route/r01/original_OBS_contract.tcl} w];puts $f [list set original_obs $original_obs];close $f
