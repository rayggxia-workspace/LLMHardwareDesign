read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/eco_views/r02/gemm-C/clean.odb}
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_audit/r01/diode_masters.tsv} w]
puts $f "master\ttype\twidth_dbu\theight_dbu\tpins"
foreach lib [[ord::get_db] getLibs] {foreach m [$lib getMasters] {if {[regexp -nocase {antenna|diode} [$m getName]]} {set pins {};foreach t [$m getMTerms] {lappend pins [list [$t getName] [$t getIoType] [$t getSigType]]};puts $f [join [list [$m getName] [$m getType] [$m getWidth] [$m getHeight] $pins] "\t"]}}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_audit/r01/installed_antenna_API.txt} w];foreach pattern {odb::dbTechLayer_*Antenna* odb::dbMTerm_*Antenna* est::*parasitic* ant::*} {puts $f [list $pattern [info commands $pattern]]};close $f
check_antennas -report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_audit/r01/native_antenna_report.txt}
puts "READ_ONLY_NATIVE_ANTENNA_CHECK_EXECUTED_NOT_FULL_DECK_QUALIFICATION"
