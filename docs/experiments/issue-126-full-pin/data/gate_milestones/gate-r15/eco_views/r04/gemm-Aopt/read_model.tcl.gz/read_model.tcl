read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/eco_views/r04/gemm-Aopt/timing.lib}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/eco_views/r04/gemm-Aopt/model_pins.tsv} w];puts $f "pin\tdirection";foreach p [get_lib_pins -of_objects [get_lib_cells *]] {puts $f "[get_full_name $p]\t[get_property $p direction]"};close $f
