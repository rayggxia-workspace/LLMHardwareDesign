read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/checkpoint_route/r01/routed.odb}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/output_chain_resume/r02/opentpu_aux-C/original_status.tcl} w];puts $f {set original_status [dict create]};set fillers {}
foreach i [[ord::get_db_block] getInsts] {if {[[$i getMaster] getType] eq "CORE_SPACER"} {lappend fillers [[$i getMaster] getName]} else {puts $f [list dict set original_status [$i getName] [$i getPlacementStatus]]}};puts $f [list set filler_masters [lsort -unique $fillers]];close $f
