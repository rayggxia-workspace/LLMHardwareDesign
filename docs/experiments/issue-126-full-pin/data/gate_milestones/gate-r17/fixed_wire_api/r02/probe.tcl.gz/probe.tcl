read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_layer_probe/r01/model/research12.tech.lef}
read_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/fixed_wire_api/r02/probe.v}
link_design fixed_probe
initialize_floorplan -die_area {0 0 100 100} -core_area {0 0 100 100} -site FreePDK45_38x28_10R_NP_162NW_34O
make_tracks
place_pin -pin_name a -layer metal10 -location {19.295 19.27} -pin_size {.8 .8}
set b [ord::get_db_block];set bt [$b findBTerm a];set net [$bt getNet];set ly [[ord::get_db_tech] findLayer metal10]
set w [odb::dbWire_create $net];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $ly FIXED;$enc addPoint 38590 38540;$enc addPoint 38590 102540;$enc end
set bp [odb::dbBPin_create $bt];$bp setPlacementStatus FIRM;odb::dbBox_create $bp $ly 37790 101740 39390 103340
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/fixed_wire_api/r02/fixed.odb}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/fixed_wire_api/r02/fixed.def}
puts "ACTUAL_FIXED_DBWIRE_AND_TWO_BPIN_RECTS_CREATED"
