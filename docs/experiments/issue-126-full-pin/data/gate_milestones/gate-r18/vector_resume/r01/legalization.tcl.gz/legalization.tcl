# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/legalization.stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

proc cell_cost {file} {
 set b [ord::get_db_block];set u [$b getDbUnitsPerMicron];set f [open $file w]
 puts $f "instance\tmaster\ttype\tarea_um2\tx_dbu\ty_dbu"
 foreach i [$b getInsts] {set m [$i getMaster];lassign [$i getLocation] x y;puts $f [join [list [$i getName] [$m getName] [$m getType] [expr {[$m getWidth]*double([$m getHeight])/($u*$u)}] $x $y] "\t"]};close $f
}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/timing_repaired_NOT_LEGALIZED_OR_ROUTED.odb}
set anchors {};foreach i [[ord::get_db_block] getInsts] {if {[[$i getMaster] getType] in {BLOCK CORE_WELLTAP}} {lappend anchors [list $i [$i getLocation] [$i getOrient] [$i getPlacementStatus]];$i setPlacementStatus FIRM}}
if {![stage independent_legalization {detailed_placement -use_diamond_legalizer}]} {close $stages;exit 1}
foreach row $anchors {lassign $row i xy ori status;if {[$i getLocation] ne $xy || [$i getOrient] ne $ori} {error "Original macro/welltap anchor moved"};$i setPlacementStatus $status}
if {![stage placement_check {check_placement -verbose}]} {close $stages;exit 1}
add_global_connection -net VDD -inst_pattern {.*} -pin_pattern {^VDD$} -power
add_global_connection -net VSS -inst_pattern {.*} -pin_pattern {^VSS$} -ground
global_connect
if {![stage original_filler_master_restore {filler_placement -prefix PINXY_VECTOR_FILL_ {FILLCELL_X1 FILLCELL_X16 FILLCELL_X2 FILLCELL_X32 FILLCELL_X4 FILLCELL_X8};global_connect;check_placement -verbose}]} {close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/placed}
cell_cost {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/actual_final.cell_cost.tsv}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/placed_NOT_ROUTED.odb}
close $stages
