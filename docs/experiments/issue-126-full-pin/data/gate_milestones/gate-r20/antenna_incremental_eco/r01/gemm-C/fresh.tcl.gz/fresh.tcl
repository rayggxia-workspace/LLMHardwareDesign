read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_incremental_eco/r01/gemm-C/routed.odb}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_incremental_eco/r01/gemm-C/independent.drc}
