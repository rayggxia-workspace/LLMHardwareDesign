read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_diode_eco/r01/gemm-C/routed.odb}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/passive_load_equivalence/r01/gemm/electrical_targets.tsv} w]
puts $f "instance\tmaster\toutput_pin\tnet\tload_ITerms\tports\tlocation_dbu"
foreach name {_328822_ _332783_} {set i [[ord::get_db_block] findInst $name];if {$i eq "NULL"} {error "Missing actual violating cell"};set t [$i findITerm ZN];set n [$t getNet];puts $f [join [list $name [[$i getMaster] getName] ZN [$n getName] [llength [$n getITerms]] [llength [$n getBTerms]] [$i getLocation]] "\t"]};close $f
