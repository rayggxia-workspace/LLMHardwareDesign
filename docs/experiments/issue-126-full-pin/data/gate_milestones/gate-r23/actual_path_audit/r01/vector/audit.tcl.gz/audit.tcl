read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/routed.odb}
read_sdc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/vec-physical-01/flow/results/nangate45/llhd_vec_original/base/6_final.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/extracted.spef}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/setup.txt}
report_checks -path_delay max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 12 -endpoint_path_count 1 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/setup_paths.txt}
report_checks -path_delay max -format json -group_path_count 12 -endpoint_path_count 1 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/setup_paths.json}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/hold.txt}
report_checks -path_delay min -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 12 -endpoint_path_count 1 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/hold_paths.txt}
report_checks -path_delay min -format json -group_path_count 12 -endpoint_path_count 1 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/hold_paths.json}
report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/checks.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/parasitic_coverage.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r01/vector/constraint_coverage.txt}
