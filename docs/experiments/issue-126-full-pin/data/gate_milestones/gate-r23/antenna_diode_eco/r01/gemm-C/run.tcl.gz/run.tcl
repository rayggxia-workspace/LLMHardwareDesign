# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
# Actual library diode ECO. No deletion/relaxation of antenna or placement rules.
# The Python driver prepends the unchanged stage/fingerprint helpers and libraries.
proc original_functional_contract {file} {
  set f [open $file w]
  foreach i [[ord::get_db_block] getInsts] {
    if {[[$i getMaster] getType] eq "CORE_SPACER" || [string match PINXY_ANT_* [$i getName]]} {continue}
    puts $f [list CELL [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {
      set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
      puts $f [list TERM [$i getName] [[$t getMTerm] getName] [$t getIoType] [$t getSigType] $nn]
    }
  };close $f
}
proc obstruction_contract {} {
  set rows {}
  foreach ob [[ord::get_db_block] getObstructions] {
    set r [$ob getBBox]
    lappend rows [list [$ob getId] [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]
  };return [lsort $rows]
}
read_db $::env(PINXY_DIODE_SOURCE)
read_sdc $::env(PINXY_DIODE_SDC)
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
set b [ord::get_db_block];set u [$b getDbUnitsPerMicron]
set dm [[ord::get_db] findMaster ANTENNA_X1]
if {$dm eq "NULL" || [$dm getType] ne "CORE_ANTENNACELL"} {error "Missing real ANTENNA_X1 master/type"}
set a [$dm findMTerm A]
if {$a eq "NULL" || [$a getIoType] ne "INPUT"} {error "Actual diode A is not an input"}
foreach mt [$dm getMTerms] {
  if {[$mt getSigType] ni {POWER GROUND} && ([$mt getName] ne "A" || [$mt getIoType] ne "INPUT")} {error "Unexpected diode signal terminal"}
}
foreach i [$b getInsts] {if {[string match PINXY_ANT_* [$i getName]]} {error "Source already contains this ECO prefix"}}
fingerprint $out/before
original_functional_contract $out/before.original.tsv
set original_obs [obstruction_contract]
set filler_masters {};set original_status {}
foreach i [$b getInsts] {
  set m [$i getMaster]
  if {[$m getType] eq "CORE_SPACER"} {lappend filler_masters [$m getName];continue}
  lappend original_status [list $i [$i getPlacementStatus]]
}
set filler_masters [lsort -unique $filler_masters]
if {![llength $filler_masters]} {error "Missing original filler master set"}
if {![stage actual_diode_insert {
  remove_fillers
  # Freeze all old functional cells for this ECO's legalizer, then restore status.
  foreach row $original_status {lassign $row i status;if {$status ni {LOCKED FIRM COVER}} {$i setPlacementStatus FIRM}}
  set requested_nets {};source $::env(PINXY_DIODE_REQUESTS)
  set f [open $out/diode_receivers.tsv w]
  puts $f "diode\tnet\treceiver_instance\treceiver_pin\treceiver_bbox_dbu\tinitial_x_dbu\tinitial_y_dbu\tmaster"
  set count 0;set diode_cells {}
  foreach row $requested_nets {
    lassign $row name cx cy
    set n [$b findNet $name]
    if {$n eq "NULL" || [$n getSigType] in {POWER GROUND}} {error "Missing actual signal net $name"}
    set best {};set best_distance Inf
    foreach t [$n getITerms] {
      if {[$t getIoType] ne "INPUT" || [$t getSigType] in {POWER GROUND}} {continue}
      set i [$t getInst];set bb [$i getBBox]
      set x [expr {([$bb xMin]+[$bb xMax])/2.0}];set y [expr {([$bb yMin]+[$bb yMax])/2.0}]
      set distance [expr {abs($x-$cx)+abs($y-$cy)}]
      if {$distance<$best_distance} {set best $t;set best_distance $distance}
    }
    if {$best eq ""} {error "No verified receiver for $name; do not invent one"}
    set receiver [$best getInst];set bb [$receiver getBBox]
    set x [$bb xMax];set y [$bb yMin]
    set inst [odb::dbInst_create $b $dm [format PINXY_ANT_%04d $count]]
    if {$inst eq "NULL"} {error "Cannot create actual diode"}
    $inst setLocation $x $y;$inst setPlacementStatus PLACED
    [$inst findITerm A] connect $n
    lappend diode_cells $inst
    puts $f [join [list [$inst getName] $name [$receiver getName] [[$best getMTerm] getName] [list [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax]] $x $y [$dm getName]] "\t"]
    incr count
  };close $f
  if {$count!=636} {error "Unexpected count $count"}
  write_db $out/inserted_NOT_LEGALIZED_OR_ROUTED.odb
}]} {close $stages;exit 1}
if {![stage diode_legalization {
  detailed_placement -use_diamond_legalizer
  check_placement -verbose
  foreach row $original_status {lassign $row i status;$i setPlacementStatus $status}
  original_functional_contract $out/placed.original.tsv
  set f [open $out/before.original.tsv r];set old [read $f];close $f
  set f [open $out/placed.original.tsv r];set current [read $f];close $f
  if {$old ne $current} {error "Original cell pose/master/terminal relation changed"}
  filler_placement -prefix PINXY_ANT_FILL_ $filler_masters
  add_global_connection -net VDD -inst_pattern {^PINXY_ANT_[0-9]+$} -pin_pattern {^VDD$} -power
  add_global_connection -net VSS -inst_pattern {^PINXY_ANT_[0-9]+$} -pin_pattern {^VSS$} -ground
  global_connect
  check_placement -verbose
  set f [open $out/diode_placed.tsv w];puts $f "diode\tnet\tx_dbu\ty_dbu\torientation\twidth_dbu\theight_dbu\tVDD\tVSS"
  foreach i $diode_cells {
    set n [[$i findITerm A] getNet];set vp [[$i findITerm VDD] getNet];set vg [[$i findITerm VSS] getNet]
    if {$vp eq "NULL" || $vg eq "NULL" || [$vp getName] ne "VDD" || [$vg getName] ne "VSS"} {error "Diode PG not connected"}
    lassign [$i getLocation] x y
    puts $f [join [list [$i getName] [$n getName] $x $y [$i getOrient] [$dm getWidth] [$dm getHeight] [$vp getName] [$vg getName]] "\t"]
  };close $f
  write_db $out/placed_NOT_ROUTED.odb
}]} {close $stages;exit 1}
set temporary_obs {};set access_reservations {};source $::env(PINXY_DIODE_RESERVATIONS)
foreach row $access_reservations {
  lassign $row ly x0 y0 x1 y1;set coords {}
  foreach v [list $x0 $y0 $x1 $y1] {lappend coords [expr {round($v*$u)}]}
  lappend temporary_obs [odb::dbObstruction_create $b [[ord::get_db_tech] findLayer $ly] {*}$coords]
}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
if {![stage full_signal_clock_rip {
  foreach n [$b getNets] {if {[$n getSigType] ni {POWER GROUND}} {set w [$n getWire];if {$w ne "NULL"} {odb::dbWire_destroy $w}}}
}]} {close $stages;exit 1}
if {![stage global_route {global_route -guide_file $out/route.guide -congestion_report_file $out/congestion.rpt}]} {close $stages;exit 1}
if {![stage detailed_route {detailed_route -output_drc $out/route.drc -verbose 1}]} {close $stages;exit 1}
if {![stage preserve_original_views {
  foreach ob $temporary_obs {odb::dbObstruction_destroy $ob}
  if {[obstruction_contract] ne $original_obs} {error "Original OBS changed"}
  original_functional_contract $out/after.original.tsv
  fingerprint $out/after
  set f [open $out/before.original.tsv r];set old [read $f];close $f
  set f [open $out/after.original.tsv r];set current [read $f];close $f
  if {$old ne $current} {error "Original cell/endpoint contract changed"}
  write_db $out/routed.odb
  write_def $out/routed.def
  write_verilog $out/mapped.v
}]} {close $stages;exit 1}
report_wire_length -detailed_route -summary -file $out/wire_length.csv
stage VDD {check_power_grid -net VDD -error_file $out/VDD.rpt}
stage VSS {check_power_grid -net VSS -error_file $out/VSS.rpt}
stage whole_signal_geometry {source $::env(PINXY_DIODE_EXPORT_ACCESS)}
stage rcx {
  define_process_corner -ext_model_index 0 X
  set_extraction_rules_file /OpenROAD-flow-scripts/flow/platforms/nangate45/rcx_patterns.rules
  extract_parasitics;write_spef $out/extracted.spef;read_spef $out/extracted.spef
}
stage sta {
  report_worst_slack -max -digits 6 > $out/setup.txt
  report_worst_slack -min -digits 6 > $out/hold.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $out/checks.txt
  check_setup -verbose > $out/constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $out/parasitic_coverage.txt
}
close $stages
