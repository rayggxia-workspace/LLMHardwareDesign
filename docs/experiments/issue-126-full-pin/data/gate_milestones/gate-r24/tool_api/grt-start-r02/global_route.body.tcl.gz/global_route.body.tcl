
  sta::parse_key_args "global_route" args  keys {-guide_file -congestion_iterations -congestion_report_file  -grid_origin -critical_nets_percentage -res_aware_nets_percentage  -congestion_report_iter_step  -skip_large_fanout_nets -snapshot_batched_width
         }  flags {-allow_congestion -resistance_aware -infinite_cap -verbose -start_incremental  -end_incremental -use_cugr}

  sta::check_argc_eq0 "global_route" $args

  if { ![ord::db_has_tech] } {
    utl::error GRT 51 "Missing dbTech."
  }

  if { [ord::get_db_block] == "NULL" } {
    utl::error GRT 52 "Missing dbBlock."
  }

  # Only update the use_cugr flag when not in incremental start/end mode.
  # During -start_incremental / -end_incremental, preserve the flag that was
  # set during the initial global_route call.
  set is_inc_start [info exists flags(-start_incremental)]
  set is_inc_end [info exists flags(-end_incremental)]
  set is_incremental_bracket [expr { $is_inc_start || $is_inc_end }]
  if { !$is_incremental_bracket } {
    grt::set_use_cugr [info exists flags(-use_cugr)]
  }

  grt::set_verbose [info exists flags(-verbose)]

  if { [info exists keys(-grid_origin)] } {
    set origin $keys(-grid_origin)
    if { [llength $origin] == 2 } {
      lassign $origin origin_x origin_y
      grt::set_grid_origin $origin_x $origin_y
    } else {
      utl::error GRT 55 "Wrong number of arguments for origin."
    }
  } else {
    grt::set_grid_origin 0 0
  }

  if { [info exists keys(-congestion_iterations)] } {
    set iterations $keys(-congestion_iterations)
    sta::check_positive_integer "-congestion_iterations" $iterations
    grt::set_congestion_iterations $iterations
  } elseif { [info exists flags(-use_cugr)] } {
    # CUGR's rip-up and re-route loop saturates around iteration 5, and
    # each iteration runs a full 3D maze pass, so the default budget is
    # tighter than FastRoute's 50.
    grt::set_congestion_iterations 5
  } else {
    grt::set_congestion_iterations 50
  }

  if { [info exists keys(-congestion_report_file)] } {
    set file_name $keys(-congestion_report_file)
    grt::set_congestion_report_file $file_name
  }

  if { [info exists keys(-congestion_report_iter_step)] } {
    set steps $keys(-congestion_report_iter_step)
    grt::set_congestion_report_iter_step $steps
  } else {
    grt::set_congestion_report_iter_step 0
  }

  if { [info exists keys(-critical_nets_percentage)] } {
    set percentage $keys(-critical_nets_percentage)
    sta::check_percent "-critical_nets_percentage" $percentage
    grt::set_critical_nets_percentage $percentage
  }

  if { [info exists keys(-skip_large_fanout_nets)] } {
    set fanout $keys(-skip_large_fanout_nets)
    sta::check_positive_integer "-skip_large_fanout_nets" $fanout
    grt::set_skip_large_fanout $fanout
  }

  set allow_congestion [info exists flags(-allow_congestion)]
  grt::set_allow_congestion $allow_congestion

  set resistance_aware [info exists flags(-resistance_aware)]
  grt::set_resistance_aware $resistance_aware

  if { [info exists keys(-res_aware_nets_percentage)] } {
    set res_aware_percentage $keys(-res_aware_nets_percentage)
    sta::check_percent "-res_aware_nets_percentage" $res_aware_percentage
    grt::set_res_aware_nets_percentage $res_aware_percentage
  }

  if { [info exists keys(-snapshot_batched_width)] } {
    set snapshot_batched_width $keys(-snapshot_batched_width)
    sta::check_positive_integer "-snapshot_batched_width"  $snapshot_batched_width
  } else {
    set snapshot_batched_width 0
  }
  grt::set_snapshot_batched_width $snapshot_batched_width

  set infinite_cap [info exists flags(-infinite_cap)]
  grt::set_infinite_cap $infinite_cap

  set start_incremental [info exists flags(-start_incremental)]
  set end_incremental [info exists flags(-end_incremental)]

  if { $start_incremental && $end_incremental } {
    utl::error GRT 295 "Only one of -start_incremental or -end_incremental can be used."
  } elseif { $start_incremental } {
    grt::start_incremental
  } elseif { $end_incremental } {
    grt::end_incremental
  } else {
    grt::global_route
  }

  if { [info exists keys(-guide_file)] } {
    set out_file $keys(-guide_file)
    write_guides $out_file
  }
