
  sta::parse_key_args "set_routing_layers" args  keys {-signal -clock} flags {} ;# checker off

  sta::check_argc_eq0 "set_routing_layers" $args

  if { [info exists keys(-signal)] } {
    define_layer_range $keys(-signal)
  }

  if { [info exists keys(-clock)] } {
    define_clock_layer_range $keys(-clock)
  }
