read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_integration/r01/C/fixed_prewires_NOT_FROZEN.odb}
set b [ord::get_db_block];set tech [ord::get_db_tech];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_adaptation_trial/r02/base_boundary.tsv} w]
set d [$b getDieArea];puts $f [join [list DIE [$d xMin] [$d yMin] [$d xMax] [$d yMax] [$b getDbUnitsPerMicron]] "\t"]
set found 0;foreach via [$tech getVias] {if {[$via getName] eq "via10_0"} {incr found;foreach box [$via getBoxes] {puts $f [join [list VIA10 [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]] "\t"]}}};if {$found!=1} {error "Actual boundary via10_0 missing/ambiguous"};close $f
