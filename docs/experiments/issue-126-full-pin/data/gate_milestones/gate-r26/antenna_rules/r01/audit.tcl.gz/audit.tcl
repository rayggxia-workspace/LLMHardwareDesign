read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/eco_views/r02/gemm-C/clean.odb}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_rules/r01/layer_rule_presence.tsv} w];puts $f "layer\trouting_level\thas_default_antenna_rule\thas_oxide2_rule"
foreach ly [[ord::get_db_tech] getLayers] {if {[$ly getRoutingLevel]>0} {puts $f [join [list [$ly getName] [$ly getRoutingLevel] [$ly hasDefaultAntennaRule] [$ly hasOxide2AntennaRule]] "\t"]}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_rules/r01/installed_rule_methods.txt} w];foreach pattern {odb::dbTechLayerAntennaRule_* odb::dbMTerm_*Ant* odb::dbAntenna*} {puts $f [list $pattern [lsort [info commands $pattern]]]};close $f
check_antennas -verbose -report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/antenna_rules/r01/native_verbose_report.txt}
puts "ANTENNA_RULE_PRESENCE_AUDIT_NOT_REPAIR"
