set original_obs {}
