# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

# Move existing proven identity buffers on private output chains only.
# No net split, new buffer, master swap, protocol change or timing exception.
proc net_drivers_sinks {net} {
  set drivers {};set sinks {};set unsupported 0
  foreach t [$net getITerms] {
    if {[$t getSigType] in {POWER GROUND}} {continue}
    switch [$t getIoType] {OUTPUT {lappend drivers $t} INPUT {lappend sinks $t} default {set unsupported 1}}
  }
  return [list $drivers $sinks $unsupported]
}
proc connection_contract {file} {
  set f [open $file w]
  foreach i [[ord::get_db_block] getInsts] {
    if {[[$i getMaster] getType] eq "CORE_SPACER"} {continue}
    puts $f [list CELL [$i getName] [[$i getMaster] getName]]
    foreach t [$i getITerms] {
      set n [$t getNet];set name NULL;if {$n ne "NULL"} {set name [$n getName]}
      puts $f [list TERM [$i getName] [[$t getMTerm] getName] [$t getIoType] [$t getSigType] $name]
    }
  };close $f
}
proc nonselected_pose_contract {file} {
  set f [open $file w]
  foreach i [[ord::get_db_block] getInsts] {
    if {[[$i getMaster] getType] eq "CORE_SPACER" || [dict exists $::selected_buffers [$i getName]]} {continue}
    puts $f [list [$i getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
  };close $f
}
proc obs_snapshot {} {
  set result {}
  foreach ob [[ord::get_db_block] getObstructions] {set bb [$ob getBBox];lappend result [list [$ob getId] [[$bb getTechLayer] getName] [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax]]}
  return [lsort $result]
}

read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x40.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x64.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x72.lib}
read_liberty {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/memory-model/macros/fakeram45_1r1w_64x96.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/routed.odb}
read_sdc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/flow/results/nangate45/parallel_opentpu_mxu/base/6_final.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/before}
connection_contract {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/before.connections.tsv}
set original_obs [obs_snapshot];set b [ord::get_db_block];set u [$b getDbUnitsPerMicron]
set access_reservations {};source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/inputs/trial-inputs-mxu-access-r03/access_reservations.tcl}
set temporary_obs {};foreach row $access_reservations {lassign $row ly x0 y0 x1 y1;set coords {};foreach v [list $x0 $y0 $x1 $y1] {lappend coords [expr {round($v*$u)}]};lappend temporary_obs [odb::dbObstruction_create $b [[ord::get_db_tech] findLayer $ly] {*}$coords]}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
read_guides {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/leaf_eco/r04/mxu-C/route.guide}
if {![stage begin_incremental {global_route -start_incremental}]} {close $stages;exit 1}
if {![stage reserve_M6_escape_and_rip_actual_target {set bt [$b findBTerm {act_data[12]}];if {$bt eq "NULL"} {error "Missing original MXU pin"}
set boxes {};foreach bp [$bt getBPins] {foreach box [$bp getBoxes] {lappend boxes $box}}
if {[llength $boxes]!=1} {error "Original MXU pin is not one rectangle"};set box [lindex $boxes 0]
if {[[$box getTechLayer] getName] ne "metal6" || [$box xMax]-[$box xMin]!=280 || [$box yMax]-[$box yMin]!=280} {error "Original M6 pin layer or size changed"}
# Temporary routing keepout only, not a claim that all spacing rules are .14um.
set gap 280;set thick 280;set a [expr {[$box xMin]-$gap}];set c [expr {[$box yMin]-$gap}];set d [expr {[$box xMax]+$gap}];set e [expr {[$box yMax]+$gap}]
set ring [list [list [expr {$a-$thick}] [expr {$c-$thick}] $a [expr {$e+$thick}]] [list $d [expr {$c-$thick}] [expr {$d+$thick}] [expr {$e+$thick}]] [list $a [expr {$c-$thick}] $d $c] [list $a $e $d [expr {$e+$thick}]]]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/proposed_temporary_M6_ring.tsv} w];puts $f "layer\tx0\ty0\tx1\ty1"
foreach rect $ring {puts $f [join [list metal6 {*}$rect] "\t"];lappend temporary_obs [odb::dbObstruction_create $b [[ord::get_db_tech] findLayer metal6] {*}$rect]};close $f
set n [$bt getNet];set wire [$n getWire];if {$wire eq "NULL"} {error "Original target wire missing"};odb::dbWire_destroy $wire
set_nets_to_route [list [$n getName]]}]} {close $stages;exit 1}
if {![stage incremental_global_route {global_route -end_incremental -guide_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/route.guide} -congestion_report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/congestion.rpt}}]} {catch {write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/failed_global.odb}};close $stages;exit 1}
if {![stage detailed_route {detailed_route -output_drc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/route.drc} -verbose 1}]} {catch {write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/failed_detail.odb}};close $stages;exit 1}
foreach ob $temporary_obs {odb::dbObstruction_destroy $ob}
if {[obs_snapshot] ne $original_obs} {error "Original OBS changed"}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/after}
connection_contract {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/after.connections.tsv}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/routed.odb}
write_abstract_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/abstract.lef}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/detailed.lef}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/routed.def}
write_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/mapped.v}
stage VDD {check_power_grid -net VDD -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/VDD.rpt}}
stage VSS {check_power_grid -net VSS -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/VSS.rpt}}
stage whole_signal_geometry {source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/mxu-escape-r02-8b4a80a/code/export_access.tcl}}
report_wire_length -detailed_route -summary -file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/wire_length.csv}
stage rcx {define_process_corner -ext_model_index 0 X;set_extraction_rules_file /OpenROAD-flow-scripts/flow/platforms/nangate45/rcx_patterns.rules;extract_parasitics;write_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/extracted.spef};read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/extracted.spef}}
stage sta {report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/setup.txt};report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/hold.txt};report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/checks.txt};check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/constraint_coverage.txt};report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_route/r02/mxu-C/parasitic_coverage.txt}}
close $stages
