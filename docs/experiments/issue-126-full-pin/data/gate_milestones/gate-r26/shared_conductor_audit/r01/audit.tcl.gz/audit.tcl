read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_integration/r01/C/fixed_prewires_NOT_FROZEN.odb}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/shared_conductor_audit/r01/native_checkpoint.def}
