read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_adaptation_trial/r02/opentpu/failed_global.odb}
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_tool_diagnosis/r01/failed_checkpoint_guides.tsv} w]
puts $f "net\tDB_guide_count_or_minus1_unsupported\thas_native_wire"
foreach n [$b getNets] {set count -1;if {![catch {$n getGuides} gs]} {set count [llength $gs]};puts $f [join [list [$n getName] $count [expr {[$n getWire] ne "NULL"}]] "\t"]};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_tool_diagnosis/r01/guide_native_capabilities.txt} w];puts $f [info commands odb::dbGuide_*];catch {puts $f [list HAVE_ROUTES [grt::have_routes]]};close $f
if {[catch {write_guides {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_tool_diagnosis/r01/recovered_from_failed.guide}} message]} {set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_tool_diagnosis/r01/guide_recovery.error.txt} w];puts $f $message;close $f}
