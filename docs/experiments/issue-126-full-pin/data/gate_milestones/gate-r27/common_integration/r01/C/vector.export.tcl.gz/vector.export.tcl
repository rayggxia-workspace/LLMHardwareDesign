read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/access-r03/vector-C/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_integration/r01/C/vector.actual_detail.lef}
