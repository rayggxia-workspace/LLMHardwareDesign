set buffer_models [dict create]
dict set buffer_models {BUF_X1} {A Z}
dict set buffer_models {BUF_X16} {A Z}
dict set buffer_models {BUF_X2} {A Z}
dict set buffer_models {BUF_X32} {A Z}
dict set buffer_models {BUF_X4} {A Z}
dict set buffer_models {BUF_X8} {A Z}
dict set buffer_models {CLKBUF_X1} {A Z}
dict set buffer_models {CLKBUF_X2} {A Z}
dict set buffer_models {CLKBUF_X3} {A Z}
