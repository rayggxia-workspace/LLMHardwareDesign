read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_route/r01/opentpu_aux-C/routed.odb}
set_routing_layers -signal metal2-metal8 -clock metal4-metal8
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_route/r01/opentpu_aux-C/independent.drc}
