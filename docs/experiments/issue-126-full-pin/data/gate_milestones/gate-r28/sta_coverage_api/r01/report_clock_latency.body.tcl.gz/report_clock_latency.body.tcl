 global errorCode errorInfo; set redirect [parse_redirect_args args]; set code [catch { global sta_report_default_digits

  parse_key_args "report_clock_" args  keys {-clocks -scenes -digits}  flags {-include_internal_latency}
  check_argc_eq0 "report_clock_latency" $args

  set scenes [parse_scenes_or_all keys]
  if [info exists keys(-clocks)] {
    set clks [get_clocks_warn "-clocks" $keys(-clocks)]
  } else {
    set clks [get_scene_clocks $scenes]
  }
  set include_internal_latency [info exists flags(-include_internal_latency)]
  if [info exists keys(-digits)] {
    set digits $keys(-digits)
    check_positive_integer "-digits" $digits
  } else {
    set digits $sta_report_default_digits
  }
  if { $clks != {} } {
    report_clk_latency $clks $scenes $include_internal_latency $digits
  } } ret ]; if {$redirect} { redirect_file_end }; if {$code == 1} {return -code $code -errorcode $errorCode -errorinfo $errorInfo $ret} else {return $ret} 