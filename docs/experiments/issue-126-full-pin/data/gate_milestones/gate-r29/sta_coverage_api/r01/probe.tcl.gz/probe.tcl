set audit_out {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/sta_coverage_api/r01}

puts [list ACTUAL_EXECUTABLE [info nameofexecutable]]
puts [exec sha256sum [info nameofexecutable]]
foreach pattern {*pulse* *period* *gating* *skew* *check* *clock*} {
 puts [list NATIVE_STA_COMMANDS $pattern [lsort [info commands sta::$pattern]]]
}
foreach c {report_check_types report_checks check_setup report_clock_properties report_clock_min_period report_clock_skew report_clock_latency report_pulse_width_checks report_clock_gating_checks report_min_period_checks} {
 puts [list NATIVE_COMMAND_AVAILABLE $c [expr {[llength [info commands $c]]>0}]]
 puts [list HELP_BEGIN $c];set code [catch {help $c} error];puts [list HELP_END $c $code $error]
 if {![catch {info body $c} body]} {set f [open $audit_out/$c.body.tcl w];puts -nonewline $f $body;close $f}
}
set lib /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
puts [list ACTUAL_TYPICAL_LIB_SHA [exec sha256sum $lib]]
set f [open $lib r];set text [read $f];close $f
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling recovery_rising recovery_falling removal_rising removal_falling setup_rising setup_falling hold_rising hold_falling} {
 set pattern [format {timing_type\s*:\s*%s\s*;} $name]
 puts [list TYPICAL_LIB_TIMING_TYPE_DECLARATIONS $name [regexp -all $pattern $text]]
}
puts {NO_DESIGN_LOADED_NO_CLOCK_OR_TIMING_PASS_INFERRED}
