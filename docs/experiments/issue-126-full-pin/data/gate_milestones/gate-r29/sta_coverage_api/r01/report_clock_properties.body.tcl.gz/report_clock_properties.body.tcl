 global errorCode errorInfo; set redirect [parse_redirect_args args]; set code [catch { check_argc_eq0or1 "report_clock_properties" $args
  update_generated_clks
  report_line "Clock                   Period          Waveform"
  report_line "----------------------------------------------------"
  if { [llength $args] == 0 } {
    foreach clk [all_clocks] {
      report_clock1 $clk
    }
  } else {
    foreach clk [get_clocks_warn "clock_name" [lindex $args 0]] {
      report_clock1 $clk
    }
  } } ret ]; if {$redirect} { redirect_file_end }; if {$code == 1} {return -code $code -errorcode $errorCode -errorinfo $errorInfo $ret} else {return $ret} 