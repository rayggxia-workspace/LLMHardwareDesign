read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/routed.odb}
read_sdc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/vec-physical-01/flow/results/nangate45/llhd_vec_original/base/6_final.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/extracted.spef}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/hold.txt}
report_check_types -min_pulse_width -min_period -max_skew -clock_gating_setup -clock_gating_hold -min_slew -min_capacitance -min_fanout -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/extended_checks_all_not_only_violators.txt}
report_clock_properties > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/actual_clock_properties.txt}
report_clock_min_period -include_port_paths > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/derived_path_min_period_NOT_LIBERTY_RULE.txt}
report_clock_skew -setup -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/setup_clock_skew.txt}
report_clock_skew -hold -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/hold_clock_skew.txt}
report_clock_latency -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/clock_latency.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/constraint_coverage.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/parasitic_coverage.txt}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/vector/loaded_library_check_definitions.tsv} w];puts $f "source	sha256	timing_type	declarations"
set source {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib};set digest [lindex [exec sha256sum $source] 0];set libf [open $source r];set content [read $libf];close $libf
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling} {set pattern [format {timing_type\s*:\s*%s\s*;} $name];puts $f [join [list $source $digest $name [regexp -all $pattern $content]] "\t"]}
close $f
puts {SOURCE_BOUND_EXTENDED_CHECKS_EXECUTED_NOT_FULL_QUALIFICATION}
