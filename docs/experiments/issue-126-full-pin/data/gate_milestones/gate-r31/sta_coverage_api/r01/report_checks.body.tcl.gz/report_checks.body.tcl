 global errorCode errorInfo; set redirect [parse_redirect_args args]; set code [catch { global sta_report_unconstrained_paths
  parse_report_path_options "report_checks" args "full" 0
  set path_ends [find_timing_paths_cmd "report_checks" args]
  report_path_ends $path_ends } ret ]; if {$redirect} { redirect_file_end }; if {$code == 1} {return -code $code -errorcode $errorCode -errorinfo $errorInfo $ret} else {return $ret} 