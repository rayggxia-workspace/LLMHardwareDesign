
  sta::parse_key_args "set_global_routing_region_adjustment" args  keys {-layer -adjustment} flags {}

  if { ![ord::db_has_tech] } {
    utl::error GRT 47 "Missing dbTech."
  }
  set tech [ord::get_db_tech]
  set lef_units [$tech getDbUnitsPerMicron]

  if { [info exists keys(-layer)] } {
    set layer $keys(-layer)
  } else {
    utl::error GRT 48 "Command set_global_routing_region_adjustment is missing -layer argument."
  }

  if { [info exists keys(-adjustment)] } {
    set adjustment $keys(-adjustment)
  } else {
    utl::error GRT 49  "Command set_global_routing_region_adjustment is missing -adjustment argument."
  }

  sta::check_argc_eq1 "set_global_routing_region_adjustment" $args
  set region [lindex $args 0]
  if { [llength $region] == 4 } {
    lassign $region lower_x lower_y upper_x upper_y
    sta::check_positive_float "lower_left_x" $lower_x
    sta::check_positive_float "lower_left_y" $lower_y
    sta::check_positive_float "upper_right_x" $upper_x
    sta::check_positive_float "upper_right_y" $upper_y
    sta::check_positive_float "-adjustment" $adjustment

    set layer_idx [grt::parse_layer_name $layer]
    grt::check_routing_layer $layer_idx

    set lower_x [expr { int($lower_x * $lef_units) }]
    set lower_y [expr { int($lower_y * $lef_units) }]
    set upper_x [expr { int($upper_x * $lef_units) }]
    set upper_y [expr { int($upper_y * $lef_units) }]

    grt::check_region $lower_x $lower_y $upper_x $upper_y

    grt::add_region_adjustment $lower_x $lower_y $upper_x $upper_y $layer_idx $adjustment
  } else {
    utl::error GRT 50  "Command set_global_routing_region_adjustment needs four arguments to define a region: lower_x lower_y upper_x upper_y."
  }
