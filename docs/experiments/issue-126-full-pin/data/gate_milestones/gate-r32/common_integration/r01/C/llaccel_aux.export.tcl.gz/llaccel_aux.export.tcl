read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/llsys-pg-r03/llaccel_aux-C/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_integration/r01/C/llaccel_aux.actual_detail.lef}
