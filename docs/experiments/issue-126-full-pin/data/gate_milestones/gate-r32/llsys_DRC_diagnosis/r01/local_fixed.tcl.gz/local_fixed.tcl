read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/llsys-pg-r03/llaccel_aux-C/clean.odb}
set b [ord::get_db_block];if {[$b getDbUnitsPerMicron]!=2000} {error "DBU mismatch"}
set windows [list {3624660 1363340 3632720 1371380} {2952570 1363340 2960720 1371520} {3709970 1157580 3718250 1165600} {2952660 1363520 2960850 1371660}]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_DRC_diagnosis/r01/actual_PG_and_OBS_local.tsv} w];puts $f "net\tlayer\tx0\ty0\tx1\ty1\tkind\towner\tmarker_ids"
proc local_box {nn layer x0 y0 x1 y1 kind owner} {
 global f windows;set hits {};set index 0
 foreach w $windows {lassign $w a c d e;if {$x0<=$d && $x1>=$a && $y0<=$e && $y1>=$c} {lappend hits $index};incr index}
 if {[llength $hits]} {puts $f [join [list $nn $layer $x0 $y0 $x1 $y1 $kind $owner [join $hits ,]] "\t"]}
}
proc local_shape {nn r kind owner {dx 0} {dy 0}} {local_box $nn [[$r getTechLayer] getName] [expr {[$r xMin]+$dx}] [expr {[$r yMin]+$dy}] [expr {[$r xMax]+$dx}] [expr {[$r yMax]+$dy}] $kind $owner}
foreach name {VDD VSS} {
 set n [$b findNet $name];if {$n eq "NULL"} {error "Original fixed PG missing"}
 foreach sw [$n getSWires] {foreach s [$sw getWires] {
  if {[$s isVia]} {set v [$s getTechVia];if {$v eq "NULL"} {set v [$s getBlockVia]};lassign [$s getViaXY] x y;foreach r [$v getBoxes] {local_shape $name $r PG_VIA {} $x $y}} else {local_shape $name $s PG_WIRE {}}
 }}
}
foreach ob [$b getObstructions] {local_shape UNOWNED_BLOCK_OBS [$ob getBBox] BLOCK_OBS {}}
foreach i [$b getInsts] {
 set m [$i getMaster];if {[$m getType] ne "BLOCK"} {continue}
 set bb [$i getBBox];set relevant 0
 foreach w $windows {lassign $w a c d e;if {[$bb xMin]<=$d && [$bb xMax]>=$a && [$bb yMin]<=$e && [$bb yMax]>=$c} {set relevant 1}}
 if {!$relevant} {continue};lassign [$m getOrigin] ox oy
 if {[$i getOrient] eq "R0" && $ox==0 && $oy==0} {lassign [$i getLocation] x y;foreach ob [$m getObstructions] {local_shape UNOWNED_MACRO_OBS $ob MACRO_OBS [$i getName] $x $y}} else {local_box UNKNOWN_TRANSFORM UNKNOWN [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax] UNCHECKED_MACRO_TRANSFORM [$i getName]}
};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_DRC_diagnosis/r01/actual_layer_rules.tsv} w];puts $f "layer\twidth_DBU\tspacing_DBU\tpitch_x_DBU\tpitch_y_DBU"
foreach ly [[ord::get_db_tech] getLayers] {puts $f [join [list [$ly getName] [$ly getWidth] [$ly getSpacing] [$ly getPitchX] [$ly getPitchY]] "\t"]};close $f
puts {ACTUAL_LOCAL_FIXED_PG_AND_OBS_READ_ONLY_EXPORTED_NOT_RULE_PASS}
