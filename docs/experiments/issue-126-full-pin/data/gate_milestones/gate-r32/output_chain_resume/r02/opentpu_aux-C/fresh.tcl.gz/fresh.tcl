read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/output_chain_resume/r02/opentpu_aux-C/routed.odb}
set_routing_layers -signal metal2-metal8 -clock metal4-metal8
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/output_chain_resume/r02/opentpu_aux-C/independent.drc}
