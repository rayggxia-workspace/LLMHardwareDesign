read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/act-access-r03/act-C/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/common_integration/r01/C/act.actual_detail.lef}
