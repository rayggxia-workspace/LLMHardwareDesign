read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_1024x128.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_128x128.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_4096x32.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_512x31.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_patch_route/r02/opentpu_aux-C/routed.odb}
read_sdc {/public/home/yuzelu/PingyangHuang/issue-55/full-block-integration-20261023T103718349596Z/runs/auxiliary-route-opentpu-4c-01/flow/results/nangate45/hpy_opentpu_aux/base/5_1_grt.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_patch_route/r02/opentpu_aux-C/extracted.spef}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/hold.txt}
report_check_types -min_pulse_width -min_period -max_skew -clock_gating_setup -clock_gating_hold -min_slew -min_capacitance -min_fanout -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/extended_checks_all_not_only_violators.txt}
report_clock_properties > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/actual_clock_properties.txt}
report_clock_min_period -include_port_paths > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/derived_path_min_period_NOT_LIBERTY_RULE.txt}
report_clock_skew -setup -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/setup_clock_skew.txt}
report_clock_skew -hold -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/hold_clock_skew.txt}
report_clock_latency -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/clock_latency.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/constraint_coverage.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/parasitic_coverage.txt}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/extended_sta/r01/opentpu_aux/loaded_library_check_definitions.tsv} w];puts $f "source	sha256	timing_type	declarations"
set source {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib};set digest [lindex [exec sha256sum $source] 0];set libf [open $source r];set content [read $libf];close $libf
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling} {set pattern [format {timing_type\s*:\s*%s\s*;} $name];puts $f [join [list $source $digest $name [regexp -all $pattern $content]] "\t"]}
set source {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_1024x128.lib};set digest [lindex [exec sha256sum $source] 0];set libf [open $source r];set content [read $libf];close $libf
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling} {set pattern [format {timing_type\s*:\s*%s\s*;} $name];puts $f [join [list $source $digest $name [regexp -all $pattern $content]] "\t"]}
set source {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_128x128.lib};set digest [lindex [exec sha256sum $source] 0];set libf [open $source r];set content [read $libf];close $libf
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling} {set pattern [format {timing_type\s*:\s*%s\s*;} $name];puts $f [join [list $source $digest $name [regexp -all $pattern $content]] "\t"]}
set source {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_4096x32.lib};set digest [lindex [exec sha256sum $source] 0];set libf [open $source r];set content [read $libf];close $libf
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling} {set pattern [format {timing_type\s*:\s*%s\s*;} $name];puts $f [join [list $source $digest $name [regexp -all $pattern $content]] "\t"]}
set source {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_512x31.lib};set digest [lindex [exec sha256sum $source] 0];set libf [open $source r];set content [read $libf];close $libf
foreach name {min_pulse_width minimum_period clock_gating_setup_rising clock_gating_setup_falling clock_gating_hold_rising clock_gating_hold_falling} {set pattern [format {timing_type\s*:\s*%s\s*;} $name];puts $f [join [list $source $digest $name [regexp -all $pattern $content]] "\t"]}
close $f
puts {SOURCE_BOUND_EXTENDED_CHECKS_EXECUTED_NOT_FULL_QUALIFICATION}
