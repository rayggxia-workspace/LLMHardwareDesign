 global errorCode errorInfo; set redirect [parse_redirect_args args]; set code [catch { global sta_report_default_digits

  parse_key_args "report_clock_skew" args  keys {-clocks -corner -scenes -digits}  flags {-setup -hold -include_internal_latency}
  check_argc_eq0 "report_clock_skew" $args

  if { [info exists flags(-setup)] && [info exists flags(-hold)] } {
    sta_error 516 "report_clock_skew -setup and -hold are mutually exclusive options."
  } elseif { [info exists flags(-setup)] } {
    set setup_hold "setup"
  } elseif { [info exists flags(-hold)] } {
    set setup_hold "hold"
  } else {
    set setup_hold "setup"
  }

  set scenes [parse_scenes_or_all keys]
  if [info exists keys(-clocks)] {
    puts "clks1 = [get_object_names $clks]"
  } else {
    set clks [get_scene_clocks $scenes]
  }

  set include_internal_latency [info exists flags(-include_internal_latency)]
  if [info exists keys(-digits)] {
    set digits $keys(-digits)
    check_positive_integer "-digits" $digits
  } else {
    set digits $sta_report_default_digits
  }
  if { $clks != {} } {
    report_clk_skew $clks $scenes $setup_hold $include_internal_latency $digits
  } } ret ]; if {$redirect} { redirect_file_end }; if {$code == 1} {return -code $code -errorcode $errorCode -errorinfo $errorInfo $ret} else {return $ret} 