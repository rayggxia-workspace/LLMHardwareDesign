# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_adaptation_trial/r02/llaccel/placed_adapter_NOT_SYSTEM.odb}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_layer_probe/r01/model/research12.setRC.tcl}
set b [ord::get_db_block];set m10 [[ord::get_db_tech] findLayer metal10]
proc save_obs {file} {set f [open $file w];foreach ob [[ord::get_db_block] getObstructions] {set r [$ob getBBox];puts $f [list [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]};close $f}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/before.OBS.tsv}
if {[$b findNet {w000001}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000001}];set olds {}
set bt [$b findBTerm {src[257]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[257]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[258]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[258]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 5734540;$enc addPoint 4480190 5798540;$enc end
if {[$b findNet {w000002}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000002}];set olds {}
set bt [$b findBTerm {src[259]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[259]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[260]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[260]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 5734540;$enc addPoint 4486590 5798540;$enc end
if {[$b findNet {w000003}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000003}];set olds {}
set bt [$b findBTerm {src[261]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[261]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[262]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[262]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 5734540;$enc addPoint 4499390 5798540;$enc end
if {[$b findNet {w000004}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000004}];set olds {}
set bt [$b findBTerm {src[263]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[263]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[264]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[264]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 5734540;$enc addPoint 4505790 5798540;$enc end
if {[$b findNet {w000005}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000005}];set olds {}
set bt [$b findBTerm {src[265]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[265]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[266]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[266]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 5734540;$enc addPoint 4512190 5798540;$enc end
if {[$b findNet {w000006}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000006}];set olds {}
set bt [$b findBTerm {src[267]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[267]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[268]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[268]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 5734540;$enc addPoint 4518590 5798540;$enc end
if {[$b findNet {w000007}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000007}];set olds {}
set bt [$b findBTerm {src[269]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[269]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[270]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[270]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 5734540;$enc addPoint 4531390 5798540;$enc end
if {[$b findNet {w000008}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000008}];set olds {}
set bt [$b findBTerm {src[271]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[271]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[272]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[272]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 5734540;$enc addPoint 4537790 5798540;$enc end
if {[$b findNet {w000009}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000009}];set olds {}
set bt [$b findBTerm {src[273]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[273]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[274]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[274]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 5734540;$enc addPoint 4544190 5798540;$enc end
if {[$b findNet {w000010}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000010}];set olds {}
set bt [$b findBTerm {src[275]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[275]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[276]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[276]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 5734540;$enc addPoint 4563390 5798540;$enc end
if {[$b findNet {w000011}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000011}];set olds {}
set bt [$b findBTerm {src[277]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[277]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[278]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[278]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 5734540;$enc addPoint 4569790 5798540;$enc end
if {[$b findNet {w000012}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000012}];set olds {}
set bt [$b findBTerm {src[279]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[279]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[280]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[280]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 5734540;$enc addPoint 4576190 5798540;$enc end
if {[$b findNet {w000013}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000013}];set olds {}
set bt [$b findBTerm {src[281]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[281]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[282]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[282]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 5734540;$enc addPoint 4595390 5798540;$enc end
if {[$b findNet {w000014}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000014}];set olds {}
set bt [$b findBTerm {src[283]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[283]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[284]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[284]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 5734540;$enc addPoint 4601790 5798540;$enc end
if {[$b findNet {w000015}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000015}];set olds {}
set bt [$b findBTerm {src[285]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[285]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[286]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[286]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 5734540;$enc addPoint 4608190 5798540;$enc end
if {[$b findNet {w000016}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000016}];set olds {}
set bt [$b findBTerm {src[287]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[287]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[288]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[288]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 5734540;$enc addPoint 4620990 5798540;$enc end
if {[$b findNet {w000017}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000017}];set olds {}
set bt [$b findBTerm {src[289]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[289]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[290]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[290]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 5734540;$enc addPoint 4627390 5798540;$enc end
if {[$b findNet {w000018}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000018}];set olds {}
set bt [$b findBTerm {src[291]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[291]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[292]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[292]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 5734540;$enc addPoint 4633790 5798540;$enc end
if {[$b findNet {w000019}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000019}];set olds {}
set bt [$b findBTerm {src[293]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[293]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[294]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[294]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 5734540;$enc addPoint 4652990 5798540;$enc end
if {[$b findNet {w000020}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000020}];set olds {}
set bt [$b findBTerm {src[295]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[295]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[296]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[296]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 5734540;$enc addPoint 4659390 5798540;$enc end
if {[$b findNet {w000021}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000021}];set olds {}
set bt [$b findBTerm {src[297]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[297]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[298]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[298]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 5734540;$enc addPoint 4665790 5798540;$enc end
if {[$b findNet {w000022}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000022}];set olds {}
set bt [$b findBTerm {src[299]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[299]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[300]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[300]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 5734540;$enc addPoint 4684990 5798540;$enc end
if {[$b findNet {w000023}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000023}];set olds {}
set bt [$b findBTerm {src[301]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[301]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[302]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[302]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 5664140;$enc addPoint 4620990 5728140;$enc end
if {[$b findNet {w000024}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000024}];set olds {}
set bt [$b findBTerm {src[303]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[303]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[304]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[304]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 5734540;$enc addPoint 4691390 5798540;$enc end
if {[$b findNet {w000025}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000025}];set olds {}
set bt [$b findBTerm {src[305]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[305]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[306]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[306]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 5734540;$enc addPoint 4697790 5798540;$enc end
if {[$b findNet {w000026}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000026}];set olds {}
set bt [$b findBTerm {src[307]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[307]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[308]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[308]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 5734540;$enc addPoint 4710590 5798540;$enc end
if {[$b findNet {w000027}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000027}];set olds {}
set bt [$b findBTerm {src[309]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[309]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[310]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[310]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 5734540;$enc addPoint 4716990 5798540;$enc end
if {[$b findNet {w000028}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000028}];set olds {}
set bt [$b findBTerm {src[311]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[311]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[312]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[312]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 5664140;$enc addPoint 4652990 5728140;$enc end
if {[$b findNet {w000029}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000029}];set olds {}
set bt [$b findBTerm {src[313]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[313]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[314]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[314]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 5734540;$enc addPoint 4723390 5798540;$enc end
if {[$b findNet {w000030}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000030}];set olds {}
set bt [$b findBTerm {src[315]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[315]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[316]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[316]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 5664140;$enc addPoint 4665790 5728140;$enc end
if {[$b findNet {w000031}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000031}];set olds {}
set bt [$b findBTerm {src[317]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[317]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[318]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[318]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 5734540;$enc addPoint 4742590 5798540;$enc end
if {[$b findNet {w000032}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000032}];set olds {}
set bt [$b findBTerm {src[319]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[319]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[320]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[320]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 5734540;$enc addPoint 4748990 5798540;$enc end
if {[$b findNet {w000033}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000033}];set olds {}
set bt [$b findBTerm {src[321]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[321]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[322]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[322]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 5926540;$enc addPoint 4480190 5990540;$enc end
if {[$b findNet {w000034}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000034}];set olds {}
set bt [$b findBTerm {src[323]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[323]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[324]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[324]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 5926540;$enc addPoint 4486590 5990540;$enc end
if {[$b findNet {w000035}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000035}];set olds {}
set bt [$b findBTerm {src[325]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[325]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[326]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[326]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 5926540;$enc addPoint 4499390 5990540;$enc end
if {[$b findNet {w000036}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000036}];set olds {}
set bt [$b findBTerm {src[327]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[327]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[328]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[328]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 5926540;$enc addPoint 4505790 5990540;$enc end
if {[$b findNet {w000037}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000037}];set olds {}
set bt [$b findBTerm {src[329]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[329]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[330]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[330]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 5926540;$enc addPoint 4512190 5990540;$enc end
if {[$b findNet {w000038}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000038}];set olds {}
set bt [$b findBTerm {src[331]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[331]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[332]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[332]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 5926540;$enc addPoint 4518590 5990540;$enc end
if {[$b findNet {w000039}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000039}];set olds {}
set bt [$b findBTerm {src[333]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[333]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[334]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[334]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 5926540;$enc addPoint 4531390 5990540;$enc end
if {[$b findNet {w000040}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000040}];set olds {}
set bt [$b findBTerm {src[335]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[335]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[336]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[336]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 5926540;$enc addPoint 4537790 5990540;$enc end
if {[$b findNet {w000041}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000041}];set olds {}
set bt [$b findBTerm {src[337]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[337]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[338]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[338]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 5926540;$enc addPoint 4544190 5990540;$enc end
if {[$b findNet {w000042}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000042}];set olds {}
set bt [$b findBTerm {src[339]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[339]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[340]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[340]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 5926540;$enc addPoint 4563390 5990540;$enc end
if {[$b findNet {w000043}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000043}];set olds {}
set bt [$b findBTerm {src[341]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[341]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[342]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[342]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 5926540;$enc addPoint 4569790 5990540;$enc end
if {[$b findNet {w000044}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000044}];set olds {}
set bt [$b findBTerm {src[343]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[343]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[344]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[344]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 5926540;$enc addPoint 4576190 5990540;$enc end
if {[$b findNet {w000045}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000045}];set olds {}
set bt [$b findBTerm {src[345]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[345]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[346]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[346]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 5926540;$enc addPoint 4595390 5990540;$enc end
if {[$b findNet {w000046}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000046}];set olds {}
set bt [$b findBTerm {src[347]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[347]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[348]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[348]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 5926540;$enc addPoint 4601790 5990540;$enc end
if {[$b findNet {w000047}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000047}];set olds {}
set bt [$b findBTerm {src[349]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[349]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[350]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[350]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 5926540;$enc addPoint 4608190 5990540;$enc end
if {[$b findNet {w000048}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000048}];set olds {}
set bt [$b findBTerm {src[351]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[351]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[352]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[352]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 5926540;$enc addPoint 4620990 5990540;$enc end
if {[$b findNet {w000049}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000049}];set olds {}
set bt [$b findBTerm {src[353]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[353]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[354]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[354]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 5926540;$enc addPoint 4627390 5990540;$enc end
if {[$b findNet {w000050}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000050}];set olds {}
set bt [$b findBTerm {src[355]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[355]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[356]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[356]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 5926540;$enc addPoint 4633790 5990540;$enc end
if {[$b findNet {w000051}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000051}];set olds {}
set bt [$b findBTerm {src[357]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[357]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[358]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[358]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 5926540;$enc addPoint 4652990 5990540;$enc end
if {[$b findNet {w000052}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000052}];set olds {}
set bt [$b findBTerm {src[359]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[359]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[360]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[360]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 5926540;$enc addPoint 4659390 5990540;$enc end
if {[$b findNet {w000053}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000053}];set olds {}
set bt [$b findBTerm {src[361]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[361]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[362]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[362]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 5926540;$enc addPoint 4665790 5990540;$enc end
if {[$b findNet {w000054}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000054}];set olds {}
set bt [$b findBTerm {src[363]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[363]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[364]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[364]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 5926540;$enc addPoint 4684990 5990540;$enc end
if {[$b findNet {w000055}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000055}];set olds {}
set bt [$b findBTerm {src[365]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[365]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[366]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[366]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 5856140;$enc addPoint 4620990 5920140;$enc end
if {[$b findNet {w000056}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000056}];set olds {}
set bt [$b findBTerm {src[367]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[367]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[368]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[368]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 5926540;$enc addPoint 4691390 5990540;$enc end
if {[$b findNet {w000057}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000057}];set olds {}
set bt [$b findBTerm {src[369]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[369]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[370]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[370]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 5926540;$enc addPoint 4697790 5990540;$enc end
if {[$b findNet {w000058}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000058}];set olds {}
set bt [$b findBTerm {src[371]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[371]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[372]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[372]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 5926540;$enc addPoint 4710590 5990540;$enc end
if {[$b findNet {w000059}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000059}];set olds {}
set bt [$b findBTerm {src[373]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[373]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[374]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[374]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 5926540;$enc addPoint 4716990 5990540;$enc end
if {[$b findNet {w000060}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000060}];set olds {}
set bt [$b findBTerm {src[375]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[375]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[376]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[376]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 5856140;$enc addPoint 4652990 5920140;$enc end
if {[$b findNet {w000061}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000061}];set olds {}
set bt [$b findBTerm {src[377]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[377]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[378]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[378]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 5926540;$enc addPoint 4723390 5990540;$enc end
if {[$b findNet {w000062}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000062}];set olds {}
set bt [$b findBTerm {src[379]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[379]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[380]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[380]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 5856140;$enc addPoint 4665790 5920140;$enc end
if {[$b findNet {w000063}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000063}];set olds {}
set bt [$b findBTerm {src[381]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[381]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[382]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[382]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 5926540;$enc addPoint 4742590 5990540;$enc end
if {[$b findNet {w000064}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000064}];set olds {}
set bt [$b findBTerm {src[383]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[383]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[384]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[384]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 5926540;$enc addPoint 4748990 5990540;$enc end
if {[$b findNet {w000065}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000065}];set olds {}
set bt [$b findBTerm {src[385]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[385]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[386]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[386]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 6118540;$enc addPoint 4480190 6182540;$enc end
if {[$b findNet {w000066}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000066}];set olds {}
set bt [$b findBTerm {src[387]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[387]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[388]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[388]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 6118540;$enc addPoint 4486590 6182540;$enc end
if {[$b findNet {w000067}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000067}];set olds {}
set bt [$b findBTerm {src[389]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[389]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[390]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[390]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 6118540;$enc addPoint 4499390 6182540;$enc end
if {[$b findNet {w000068}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000068}];set olds {}
set bt [$b findBTerm {src[391]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[391]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[392]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[392]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 6118540;$enc addPoint 4505790 6182540;$enc end
if {[$b findNet {w000069}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000069}];set olds {}
set bt [$b findBTerm {src[393]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[393]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[394]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[394]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 6118540;$enc addPoint 4512190 6182540;$enc end
if {[$b findNet {w000070}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000070}];set olds {}
set bt [$b findBTerm {src[395]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[395]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[396]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[396]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 6118540;$enc addPoint 4518590 6182540;$enc end
if {[$b findNet {w000071}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000071}];set olds {}
set bt [$b findBTerm {src[397]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[397]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[398]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[398]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 6118540;$enc addPoint 4531390 6182540;$enc end
if {[$b findNet {w000072}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000072}];set olds {}
set bt [$b findBTerm {src[399]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[399]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[400]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[400]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 6118540;$enc addPoint 4537790 6182540;$enc end
if {[$b findNet {w000073}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000073}];set olds {}
set bt [$b findBTerm {src[401]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[401]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[402]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[402]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 6118540;$enc addPoint 4544190 6182540;$enc end
if {[$b findNet {w000074}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000074}];set olds {}
set bt [$b findBTerm {src[403]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[403]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[404]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[404]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 6118540;$enc addPoint 4563390 6182540;$enc end
if {[$b findNet {w000075}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000075}];set olds {}
set bt [$b findBTerm {src[405]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[405]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[406]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[406]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 6118540;$enc addPoint 4569790 6182540;$enc end
if {[$b findNet {w000076}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000076}];set olds {}
set bt [$b findBTerm {src[407]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[407]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[408]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[408]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 6118540;$enc addPoint 4576190 6182540;$enc end
if {[$b findNet {w000077}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000077}];set olds {}
set bt [$b findBTerm {src[409]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[409]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[410]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[410]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 6118540;$enc addPoint 4595390 6182540;$enc end
if {[$b findNet {w000078}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000078}];set olds {}
set bt [$b findBTerm {src[411]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[411]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[412]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[412]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 6118540;$enc addPoint 4601790 6182540;$enc end
if {[$b findNet {w000079}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000079}];set olds {}
set bt [$b findBTerm {src[413]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[413]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[414]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[414]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 6118540;$enc addPoint 4608190 6182540;$enc end
if {[$b findNet {w000080}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000080}];set olds {}
set bt [$b findBTerm {src[415]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[415]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[416]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[416]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6118540;$enc addPoint 4620990 6182540;$enc end
if {[$b findNet {w000081}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000081}];set olds {}
set bt [$b findBTerm {src[417]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[417]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[418]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[418]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 6118540;$enc addPoint 4627390 6182540;$enc end
if {[$b findNet {w000082}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000082}];set olds {}
set bt [$b findBTerm {src[419]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[419]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[420]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[420]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 6118540;$enc addPoint 4633790 6182540;$enc end
if {[$b findNet {w000083}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000083}];set olds {}
set bt [$b findBTerm {src[421]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[421]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[422]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[422]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6118540;$enc addPoint 4652990 6182540;$enc end
if {[$b findNet {w000084}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000084}];set olds {}
set bt [$b findBTerm {src[423]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[423]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[424]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[424]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 6118540;$enc addPoint 4659390 6182540;$enc end
if {[$b findNet {w000085}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000085}];set olds {}
set bt [$b findBTerm {src[425]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[425]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[426]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[426]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6118540;$enc addPoint 4665790 6182540;$enc end
if {[$b findNet {w000086}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000086}];set olds {}
set bt [$b findBTerm {src[427]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[427]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[428]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[428]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 6118540;$enc addPoint 4684990 6182540;$enc end
if {[$b findNet {w000087}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000087}];set olds {}
set bt [$b findBTerm {src[429]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[429]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[430]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[430]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6048140;$enc addPoint 4620990 6112140;$enc end
if {[$b findNet {w000088}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000088}];set olds {}
set bt [$b findBTerm {src[431]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[431]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[432]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[432]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 6118540;$enc addPoint 4691390 6182540;$enc end
if {[$b findNet {w000089}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000089}];set olds {}
set bt [$b findBTerm {src[433]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[433]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[434]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[434]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 6118540;$enc addPoint 4697790 6182540;$enc end
if {[$b findNet {w000090}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000090}];set olds {}
set bt [$b findBTerm {src[435]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[435]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[436]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[436]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 6118540;$enc addPoint 4710590 6182540;$enc end
if {[$b findNet {w000091}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000091}];set olds {}
set bt [$b findBTerm {src[437]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[437]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[438]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[438]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 6118540;$enc addPoint 4716990 6182540;$enc end
if {[$b findNet {w000092}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000092}];set olds {}
set bt [$b findBTerm {src[439]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[439]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[440]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[440]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6048140;$enc addPoint 4652990 6112140;$enc end
if {[$b findNet {w000093}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000093}];set olds {}
set bt [$b findBTerm {src[441]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[441]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[442]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[442]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 6118540;$enc addPoint 4723390 6182540;$enc end
if {[$b findNet {w000094}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000094}];set olds {}
set bt [$b findBTerm {src[443]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[443]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[444]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[444]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6048140;$enc addPoint 4665790 6112140;$enc end
if {[$b findNet {w000095}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000095}];set olds {}
set bt [$b findBTerm {src[445]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[445]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[446]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[446]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 6118540;$enc addPoint 4742590 6182540;$enc end
if {[$b findNet {w000096}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000096}];set olds {}
set bt [$b findBTerm {src[447]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[447]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[448]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[448]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 6118540;$enc addPoint 4748990 6182540;$enc end
if {[$b findNet {w000097}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000097}];set olds {}
set bt [$b findBTerm {src[449]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[449]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[450]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[450]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 6310540;$enc addPoint 4480190 6374540;$enc end
if {[$b findNet {w000098}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000098}];set olds {}
set bt [$b findBTerm {src[451]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[451]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[452]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[452]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 6310540;$enc addPoint 4486590 6374540;$enc end
if {[$b findNet {w000099}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000099}];set olds {}
set bt [$b findBTerm {src[453]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[453]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[454]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[454]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 6310540;$enc addPoint 4499390 6374540;$enc end
if {[$b findNet {w000100}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000100}];set olds {}
set bt [$b findBTerm {src[455]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[455]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[456]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[456]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 6310540;$enc addPoint 4505790 6374540;$enc end
if {[$b findNet {w000101}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000101}];set olds {}
set bt [$b findBTerm {src[457]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[457]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[458]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[458]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 6310540;$enc addPoint 4512190 6374540;$enc end
if {[$b findNet {w000102}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000102}];set olds {}
set bt [$b findBTerm {src[459]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[459]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[460]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[460]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 6310540;$enc addPoint 4518590 6374540;$enc end
if {[$b findNet {w000103}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000103}];set olds {}
set bt [$b findBTerm {src[461]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[461]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[462]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[462]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 6310540;$enc addPoint 4531390 6374540;$enc end
if {[$b findNet {w000104}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000104}];set olds {}
set bt [$b findBTerm {src[463]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[463]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[464]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[464]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 6310540;$enc addPoint 4537790 6374540;$enc end
if {[$b findNet {w000105}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000105}];set olds {}
set bt [$b findBTerm {src[465]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[465]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[466]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[466]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 6310540;$enc addPoint 4544190 6374540;$enc end
if {[$b findNet {w000106}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000106}];set olds {}
set bt [$b findBTerm {src[467]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[467]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[468]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[468]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 6310540;$enc addPoint 4563390 6374540;$enc end
if {[$b findNet {w000107}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000107}];set olds {}
set bt [$b findBTerm {src[469]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[469]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[470]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[470]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 6310540;$enc addPoint 4569790 6374540;$enc end
if {[$b findNet {w000108}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000108}];set olds {}
set bt [$b findBTerm {src[471]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[471]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[472]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[472]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 6310540;$enc addPoint 4576190 6374540;$enc end
if {[$b findNet {w000109}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000109}];set olds {}
set bt [$b findBTerm {src[473]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[473]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[474]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[474]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 6310540;$enc addPoint 4595390 6374540;$enc end
if {[$b findNet {w000110}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000110}];set olds {}
set bt [$b findBTerm {src[475]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[475]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[476]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[476]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 6310540;$enc addPoint 4601790 6374540;$enc end
if {[$b findNet {w000111}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000111}];set olds {}
set bt [$b findBTerm {src[477]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[477]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[478]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[478]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 6310540;$enc addPoint 4608190 6374540;$enc end
if {[$b findNet {w000112}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000112}];set olds {}
set bt [$b findBTerm {src[479]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[479]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[480]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[480]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6310540;$enc addPoint 4620990 6374540;$enc end
if {[$b findNet {w000113}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000113}];set olds {}
set bt [$b findBTerm {src[481]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[481]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[482]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[482]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 6310540;$enc addPoint 4627390 6374540;$enc end
if {[$b findNet {w000114}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000114}];set olds {}
set bt [$b findBTerm {src[483]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[483]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[484]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[484]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 6310540;$enc addPoint 4633790 6374540;$enc end
if {[$b findNet {w000115}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000115}];set olds {}
set bt [$b findBTerm {src[485]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[485]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[486]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[486]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6310540;$enc addPoint 4652990 6374540;$enc end
if {[$b findNet {w000116}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000116}];set olds {}
set bt [$b findBTerm {src[487]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[487]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[488]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[488]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 6310540;$enc addPoint 4659390 6374540;$enc end
if {[$b findNet {w000117}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000117}];set olds {}
set bt [$b findBTerm {src[489]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[489]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[490]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[490]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6310540;$enc addPoint 4665790 6374540;$enc end
if {[$b findNet {w000118}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000118}];set olds {}
set bt [$b findBTerm {src[491]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[491]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[492]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[492]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 6310540;$enc addPoint 4684990 6374540;$enc end
if {[$b findNet {w000119}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000119}];set olds {}
set bt [$b findBTerm {src[493]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[493]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[494]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[494]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6240140;$enc addPoint 4620990 6304140;$enc end
if {[$b findNet {w000120}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000120}];set olds {}
set bt [$b findBTerm {src[495]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[495]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[496]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[496]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 6310540;$enc addPoint 4691390 6374540;$enc end
if {[$b findNet {w000121}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000121}];set olds {}
set bt [$b findBTerm {src[497]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[497]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[498]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[498]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 6310540;$enc addPoint 4697790 6374540;$enc end
if {[$b findNet {w000122}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000122}];set olds {}
set bt [$b findBTerm {src[499]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[499]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[500]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[500]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 6310540;$enc addPoint 4710590 6374540;$enc end
if {[$b findNet {w000123}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000123}];set olds {}
set bt [$b findBTerm {src[501]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[501]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[502]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[502]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 6310540;$enc addPoint 4716990 6374540;$enc end
if {[$b findNet {w000124}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000124}];set olds {}
set bt [$b findBTerm {src[503]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[503]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[504]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[504]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6240140;$enc addPoint 4652990 6304140;$enc end
if {[$b findNet {w000125}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000125}];set olds {}
set bt [$b findBTerm {src[505]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[505]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[506]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[506]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 6310540;$enc addPoint 4723390 6374540;$enc end
if {[$b findNet {w000126}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000126}];set olds {}
set bt [$b findBTerm {src[507]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[507]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[508]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[508]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6240140;$enc addPoint 4665790 6304140;$enc end
if {[$b findNet {w000127}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000127}];set olds {}
set bt [$b findBTerm {src[509]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[509]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[510]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[510]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 6310540;$enc addPoint 4742590 6374540;$enc end
if {[$b findNet {w000128}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000128}];set olds {}
set bt [$b findBTerm {src[511]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[511]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[512]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[512]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 6310540;$enc addPoint 4748990 6374540;$enc end
if {[$b findNet {w000129}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000129}];set olds {}
set bt [$b findBTerm {src[513]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[513]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[514]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[514]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 6502540;$enc addPoint 4480190 6566540;$enc end
if {[$b findNet {w000130}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000130}];set olds {}
set bt [$b findBTerm {src[515]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[515]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[516]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[516]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 6502540;$enc addPoint 4486590 6566540;$enc end
if {[$b findNet {w000131}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000131}];set olds {}
set bt [$b findBTerm {src[517]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[517]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[518]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[518]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 6502540;$enc addPoint 4499390 6566540;$enc end
if {[$b findNet {w000132}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000132}];set olds {}
set bt [$b findBTerm {src[519]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[519]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[520]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[520]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 6502540;$enc addPoint 4505790 6566540;$enc end
if {[$b findNet {w000133}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000133}];set olds {}
set bt [$b findBTerm {src[521]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[521]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[522]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[522]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 6502540;$enc addPoint 4512190 6566540;$enc end
if {[$b findNet {w000134}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000134}];set olds {}
set bt [$b findBTerm {src[523]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[523]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[524]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[524]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 6502540;$enc addPoint 4518590 6566540;$enc end
if {[$b findNet {w000135}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000135}];set olds {}
set bt [$b findBTerm {src[525]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[525]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[526]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[526]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 6502540;$enc addPoint 4531390 6566540;$enc end
if {[$b findNet {w000136}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000136}];set olds {}
set bt [$b findBTerm {src[527]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[527]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[528]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[528]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 6502540;$enc addPoint 4537790 6566540;$enc end
if {[$b findNet {w000137}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000137}];set olds {}
set bt [$b findBTerm {src[529]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[529]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[530]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[530]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 6502540;$enc addPoint 4544190 6566540;$enc end
if {[$b findNet {w000138}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000138}];set olds {}
set bt [$b findBTerm {src[531]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[531]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[532]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[532]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 6502540;$enc addPoint 4563390 6566540;$enc end
if {[$b findNet {w000139}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000139}];set olds {}
set bt [$b findBTerm {src[533]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[533]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[534]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[534]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 6502540;$enc addPoint 4569790 6566540;$enc end
if {[$b findNet {w000140}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000140}];set olds {}
set bt [$b findBTerm {src[535]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[535]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[536]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[536]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 6502540;$enc addPoint 4576190 6566540;$enc end
if {[$b findNet {w000141}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000141}];set olds {}
set bt [$b findBTerm {src[537]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[537]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[538]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[538]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 6502540;$enc addPoint 4595390 6566540;$enc end
if {[$b findNet {w000142}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000142}];set olds {}
set bt [$b findBTerm {src[539]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[539]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[540]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[540]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 6502540;$enc addPoint 4601790 6566540;$enc end
if {[$b findNet {w000143}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000143}];set olds {}
set bt [$b findBTerm {src[541]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[541]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[542]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[542]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 6502540;$enc addPoint 4608190 6566540;$enc end
if {[$b findNet {w000144}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000144}];set olds {}
set bt [$b findBTerm {src[543]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[543]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[544]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[544]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6502540;$enc addPoint 4620990 6566540;$enc end
if {[$b findNet {w000145}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000145}];set olds {}
set bt [$b findBTerm {src[545]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[545]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[546]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[546]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 6502540;$enc addPoint 4627390 6566540;$enc end
if {[$b findNet {w000146}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000146}];set olds {}
set bt [$b findBTerm {src[547]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[547]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[548]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[548]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 6502540;$enc addPoint 4633790 6566540;$enc end
if {[$b findNet {w000147}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000147}];set olds {}
set bt [$b findBTerm {src[549]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[549]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[550]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[550]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6502540;$enc addPoint 4652990 6566540;$enc end
if {[$b findNet {w000148}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000148}];set olds {}
set bt [$b findBTerm {src[551]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[551]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[552]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[552]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 6502540;$enc addPoint 4659390 6566540;$enc end
if {[$b findNet {w000149}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000149}];set olds {}
set bt [$b findBTerm {src[553]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[553]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[554]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[554]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6502540;$enc addPoint 4665790 6566540;$enc end
if {[$b findNet {w000150}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000150}];set olds {}
set bt [$b findBTerm {src[555]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[555]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[556]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[556]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 6502540;$enc addPoint 4684990 6566540;$enc end
if {[$b findNet {w000151}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000151}];set olds {}
set bt [$b findBTerm {src[557]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[557]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[558]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[558]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6432140;$enc addPoint 4620990 6496140;$enc end
if {[$b findNet {w000152}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000152}];set olds {}
set bt [$b findBTerm {src[559]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[559]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[560]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[560]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 6502540;$enc addPoint 4691390 6566540;$enc end
if {[$b findNet {w000153}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000153}];set olds {}
set bt [$b findBTerm {src[561]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[561]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[562]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[562]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 6502540;$enc addPoint 4697790 6566540;$enc end
if {[$b findNet {w000154}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000154}];set olds {}
set bt [$b findBTerm {src[563]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[563]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[564]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[564]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 6502540;$enc addPoint 4710590 6566540;$enc end
if {[$b findNet {w000155}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000155}];set olds {}
set bt [$b findBTerm {src[565]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[565]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[566]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[566]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 6502540;$enc addPoint 4716990 6566540;$enc end
if {[$b findNet {w000156}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000156}];set olds {}
set bt [$b findBTerm {src[567]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[567]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[568]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[568]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6432140;$enc addPoint 4652990 6496140;$enc end
if {[$b findNet {w000157}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000157}];set olds {}
set bt [$b findBTerm {src[569]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[569]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[570]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[570]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 6502540;$enc addPoint 4723390 6566540;$enc end
if {[$b findNet {w000158}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000158}];set olds {}
set bt [$b findBTerm {src[571]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[571]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[572]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[572]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6432140;$enc addPoint 4665790 6496140;$enc end
if {[$b findNet {w000159}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000159}];set olds {}
set bt [$b findBTerm {src[573]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[573]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[574]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[574]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 6502540;$enc addPoint 4742590 6566540;$enc end
if {[$b findNet {w000160}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000160}];set olds {}
set bt [$b findBTerm {src[575]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[575]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[576]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[576]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 6502540;$enc addPoint 4748990 6566540;$enc end
if {[$b findNet {w000161}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000161}];set olds {}
set bt [$b findBTerm {src[577]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[577]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[578]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[578]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 6694540;$enc addPoint 4480190 6758540;$enc end
if {[$b findNet {w000162}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000162}];set olds {}
set bt [$b findBTerm {src[579]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[579]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[580]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[580]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 6694540;$enc addPoint 4486590 6758540;$enc end
if {[$b findNet {w000163}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000163}];set olds {}
set bt [$b findBTerm {src[581]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[581]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[582]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[582]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 6694540;$enc addPoint 4499390 6758540;$enc end
if {[$b findNet {w000164}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000164}];set olds {}
set bt [$b findBTerm {src[583]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[583]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[584]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[584]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 6694540;$enc addPoint 4505790 6758540;$enc end
if {[$b findNet {w000165}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000165}];set olds {}
set bt [$b findBTerm {src[585]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[585]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[586]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[586]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 6694540;$enc addPoint 4512190 6758540;$enc end
if {[$b findNet {w000166}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000166}];set olds {}
set bt [$b findBTerm {src[587]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[587]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[588]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[588]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 6694540;$enc addPoint 4518590 6758540;$enc end
if {[$b findNet {w000167}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000167}];set olds {}
set bt [$b findBTerm {src[589]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[589]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[590]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[590]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 6694540;$enc addPoint 4531390 6758540;$enc end
if {[$b findNet {w000168}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000168}];set olds {}
set bt [$b findBTerm {src[591]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[591]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[592]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[592]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 6694540;$enc addPoint 4537790 6758540;$enc end
if {[$b findNet {w000169}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000169}];set olds {}
set bt [$b findBTerm {src[593]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[593]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[594]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[594]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 6694540;$enc addPoint 4544190 6758540;$enc end
if {[$b findNet {w000170}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000170}];set olds {}
set bt [$b findBTerm {src[595]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[595]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[596]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[596]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 6694540;$enc addPoint 4563390 6758540;$enc end
if {[$b findNet {w000171}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000171}];set olds {}
set bt [$b findBTerm {src[597]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[597]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[598]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[598]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 6694540;$enc addPoint 4569790 6758540;$enc end
if {[$b findNet {w000172}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000172}];set olds {}
set bt [$b findBTerm {src[599]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[599]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[600]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[600]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 6694540;$enc addPoint 4576190 6758540;$enc end
if {[$b findNet {w000173}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000173}];set olds {}
set bt [$b findBTerm {src[601]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[601]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[602]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[602]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 6694540;$enc addPoint 4595390 6758540;$enc end
if {[$b findNet {w000174}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000174}];set olds {}
set bt [$b findBTerm {src[603]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[603]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[604]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[604]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 6694540;$enc addPoint 4601790 6758540;$enc end
if {[$b findNet {w000175}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000175}];set olds {}
set bt [$b findBTerm {src[605]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[605]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[606]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[606]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 6694540;$enc addPoint 4608190 6758540;$enc end
if {[$b findNet {w000176}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000176}];set olds {}
set bt [$b findBTerm {src[607]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[607]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[608]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[608]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6694540;$enc addPoint 4620990 6758540;$enc end
if {[$b findNet {w000177}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000177}];set olds {}
set bt [$b findBTerm {src[609]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[609]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[610]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[610]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 6694540;$enc addPoint 4627390 6758540;$enc end
if {[$b findNet {w000178}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000178}];set olds {}
set bt [$b findBTerm {src[611]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[611]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[612]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[612]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 6694540;$enc addPoint 4633790 6758540;$enc end
if {[$b findNet {w000179}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000179}];set olds {}
set bt [$b findBTerm {src[613]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[613]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[614]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[614]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6694540;$enc addPoint 4652990 6758540;$enc end
if {[$b findNet {w000180}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000180}];set olds {}
set bt [$b findBTerm {src[615]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[615]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[616]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[616]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 6694540;$enc addPoint 4659390 6758540;$enc end
if {[$b findNet {w000181}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000181}];set olds {}
set bt [$b findBTerm {src[617]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[617]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[618]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[618]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6694540;$enc addPoint 4665790 6758540;$enc end
if {[$b findNet {w000182}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000182}];set olds {}
set bt [$b findBTerm {src[619]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[619]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[620]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[620]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 6694540;$enc addPoint 4684990 6758540;$enc end
if {[$b findNet {w000183}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000183}];set olds {}
set bt [$b findBTerm {src[621]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[621]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[622]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[622]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6624140;$enc addPoint 4620990 6688140;$enc end
if {[$b findNet {w000184}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000184}];set olds {}
set bt [$b findBTerm {src[623]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[623]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[624]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[624]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 6694540;$enc addPoint 4691390 6758540;$enc end
if {[$b findNet {w000185}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000185}];set olds {}
set bt [$b findBTerm {src[625]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[625]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[626]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[626]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 6694540;$enc addPoint 4697790 6758540;$enc end
if {[$b findNet {w000186}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000186}];set olds {}
set bt [$b findBTerm {src[627]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[627]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[628]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[628]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 6694540;$enc addPoint 4710590 6758540;$enc end
if {[$b findNet {w000187}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000187}];set olds {}
set bt [$b findBTerm {src[629]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[629]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[630]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[630]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 6694540;$enc addPoint 4716990 6758540;$enc end
if {[$b findNet {w000188}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000188}];set olds {}
set bt [$b findBTerm {src[631]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[631]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[632]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[632]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6624140;$enc addPoint 4652990 6688140;$enc end
if {[$b findNet {w000189}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000189}];set olds {}
set bt [$b findBTerm {src[633]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[633]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[634]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[634]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 6694540;$enc addPoint 4723390 6758540;$enc end
if {[$b findNet {w000190}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000190}];set olds {}
set bt [$b findBTerm {src[635]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[635]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[636]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[636]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6624140;$enc addPoint 4665790 6688140;$enc end
if {[$b findNet {w000191}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000191}];set olds {}
set bt [$b findBTerm {src[637]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[637]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[638]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[638]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 6694540;$enc addPoint 4742590 6758540;$enc end
if {[$b findNet {w000192}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000192}];set olds {}
set bt [$b findBTerm {src[639]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[639]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[640]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[640]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 6694540;$enc addPoint 4748990 6758540;$enc end
if {[$b findNet {w000193}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000193}];set olds {}
set bt [$b findBTerm {src[641]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[641]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[642]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[642]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 6886540;$enc addPoint 4480190 6950540;$enc end
if {[$b findNet {w000194}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000194}];set olds {}
set bt [$b findBTerm {src[643]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[643]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[644]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[644]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 6886540;$enc addPoint 4486590 6950540;$enc end
if {[$b findNet {w000195}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000195}];set olds {}
set bt [$b findBTerm {src[645]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[645]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[646]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[646]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 6886540;$enc addPoint 4499390 6950540;$enc end
if {[$b findNet {w000196}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000196}];set olds {}
set bt [$b findBTerm {src[647]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[647]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[648]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[648]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 6886540;$enc addPoint 4505790 6950540;$enc end
if {[$b findNet {w000197}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000197}];set olds {}
set bt [$b findBTerm {src[649]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[649]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[650]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[650]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 6886540;$enc addPoint 4512190 6950540;$enc end
if {[$b findNet {w000198}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000198}];set olds {}
set bt [$b findBTerm {src[651]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[651]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[652]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[652]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 6886540;$enc addPoint 4518590 6950540;$enc end
if {[$b findNet {w000199}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000199}];set olds {}
set bt [$b findBTerm {src[653]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[653]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[654]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[654]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 6886540;$enc addPoint 4531390 6950540;$enc end
if {[$b findNet {w000200}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000200}];set olds {}
set bt [$b findBTerm {src[655]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[655]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[656]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[656]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 6886540;$enc addPoint 4537790 6950540;$enc end
if {[$b findNet {w000201}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000201}];set olds {}
set bt [$b findBTerm {src[657]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[657]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[658]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[658]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 6886540;$enc addPoint 4544190 6950540;$enc end
if {[$b findNet {w000202}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000202}];set olds {}
set bt [$b findBTerm {src[659]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[659]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[660]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[660]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 6886540;$enc addPoint 4563390 6950540;$enc end
if {[$b findNet {w000203}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000203}];set olds {}
set bt [$b findBTerm {src[661]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[661]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[662]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[662]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 6886540;$enc addPoint 4569790 6950540;$enc end
if {[$b findNet {w000204}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000204}];set olds {}
set bt [$b findBTerm {src[663]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[663]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[664]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[664]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 6886540;$enc addPoint 4576190 6950540;$enc end
if {[$b findNet {w000205}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000205}];set olds {}
set bt [$b findBTerm {src[665]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[665]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[666]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[666]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 6886540;$enc addPoint 4595390 6950540;$enc end
if {[$b findNet {w000206}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000206}];set olds {}
set bt [$b findBTerm {src[667]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[667]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[668]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[668]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 6886540;$enc addPoint 4601790 6950540;$enc end
if {[$b findNet {w000207}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000207}];set olds {}
set bt [$b findBTerm {src[669]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[669]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[670]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[670]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 6886540;$enc addPoint 4608190 6950540;$enc end
if {[$b findNet {w000208}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000208}];set olds {}
set bt [$b findBTerm {src[671]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[671]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[672]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[672]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6886540;$enc addPoint 4620990 6950540;$enc end
if {[$b findNet {w000209}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000209}];set olds {}
set bt [$b findBTerm {src[673]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[673]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[674]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[674]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 6886540;$enc addPoint 4627390 6950540;$enc end
if {[$b findNet {w000210}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000210}];set olds {}
set bt [$b findBTerm {src[675]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[675]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[676]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[676]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 6886540;$enc addPoint 4633790 6950540;$enc end
if {[$b findNet {w000211}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000211}];set olds {}
set bt [$b findBTerm {src[677]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[677]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[678]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[678]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6886540;$enc addPoint 4652990 6950540;$enc end
if {[$b findNet {w000212}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000212}];set olds {}
set bt [$b findBTerm {src[679]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[679]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[680]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[680]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 6886540;$enc addPoint 4659390 6950540;$enc end
if {[$b findNet {w000213}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000213}];set olds {}
set bt [$b findBTerm {src[681]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[681]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[682]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[682]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6886540;$enc addPoint 4665790 6950540;$enc end
if {[$b findNet {w000214}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000214}];set olds {}
set bt [$b findBTerm {src[683]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[683]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[684]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[684]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 6886540;$enc addPoint 4684990 6950540;$enc end
if {[$b findNet {w000215}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000215}];set olds {}
set bt [$b findBTerm {src[685]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[685]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[686]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[686]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 6816140;$enc addPoint 4620990 6880140;$enc end
if {[$b findNet {w000216}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000216}];set olds {}
set bt [$b findBTerm {src[687]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[687]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[688]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[688]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 6886540;$enc addPoint 4691390 6950540;$enc end
if {[$b findNet {w000217}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000217}];set olds {}
set bt [$b findBTerm {src[689]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[689]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[690]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[690]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 6886540;$enc addPoint 4697790 6950540;$enc end
if {[$b findNet {w000218}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000218}];set olds {}
set bt [$b findBTerm {src[691]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[691]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[692]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[692]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 6886540;$enc addPoint 4710590 6950540;$enc end
if {[$b findNet {w000219}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000219}];set olds {}
set bt [$b findBTerm {src[693]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[693]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[694]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[694]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 6886540;$enc addPoint 4716990 6950540;$enc end
if {[$b findNet {w000220}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000220}];set olds {}
set bt [$b findBTerm {src[695]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[695]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[696]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[696]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 6816140;$enc addPoint 4652990 6880140;$enc end
if {[$b findNet {w000221}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000221}];set olds {}
set bt [$b findBTerm {src[697]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[697]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[698]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[698]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 6886540;$enc addPoint 4723390 6950540;$enc end
if {[$b findNet {w000222}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000222}];set olds {}
set bt [$b findBTerm {src[699]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[699]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[700]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[700]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 6816140;$enc addPoint 4665790 6880140;$enc end
if {[$b findNet {w000223}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000223}];set olds {}
set bt [$b findBTerm {src[701]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[701]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[702]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[702]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 6886540;$enc addPoint 4742590 6950540;$enc end
if {[$b findNet {w000224}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000224}];set olds {}
set bt [$b findBTerm {src[703]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[703]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[704]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[704]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 6886540;$enc addPoint 4748990 6950540;$enc end
if {[$b findNet {w000225}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000225}];set olds {}
set bt [$b findBTerm {src[705]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[705]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[706]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[706]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4480190 7078540;$enc addPoint 4480190 7142540;$enc end
if {[$b findNet {w000226}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000226}];set olds {}
set bt [$b findBTerm {src[707]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[707]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[708]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[708]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4486590 7078540;$enc addPoint 4486590 7142540;$enc end
if {[$b findNet {w000227}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000227}];set olds {}
set bt [$b findBTerm {src[709]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[709]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[710]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[710]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4499390 7078540;$enc addPoint 4499390 7142540;$enc end
if {[$b findNet {w000228}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000228}];set olds {}
set bt [$b findBTerm {src[711]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[711]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[712]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[712]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4505790 7078540;$enc addPoint 4505790 7142540;$enc end
if {[$b findNet {w000229}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000229}];set olds {}
set bt [$b findBTerm {src[713]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[713]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[714]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[714]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4512190 7078540;$enc addPoint 4512190 7142540;$enc end
if {[$b findNet {w000230}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000230}];set olds {}
set bt [$b findBTerm {src[715]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[715]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[716]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[716]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4518590 7078540;$enc addPoint 4518590 7142540;$enc end
if {[$b findNet {w000231}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000231}];set olds {}
set bt [$b findBTerm {src[717]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[717]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[718]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[718]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4531390 7078540;$enc addPoint 4531390 7142540;$enc end
if {[$b findNet {w000232}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000232}];set olds {}
set bt [$b findBTerm {src[719]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[719]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[720]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[720]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4537790 7078540;$enc addPoint 4537790 7142540;$enc end
if {[$b findNet {w000233}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000233}];set olds {}
set bt [$b findBTerm {src[721]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[721]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[722]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[722]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4544190 7078540;$enc addPoint 4544190 7142540;$enc end
if {[$b findNet {w000234}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000234}];set olds {}
set bt [$b findBTerm {src[723]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[723]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[724]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[724]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4563390 7078540;$enc addPoint 4563390 7142540;$enc end
if {[$b findNet {w000235}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000235}];set olds {}
set bt [$b findBTerm {src[725]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[725]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[726]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[726]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4569790 7078540;$enc addPoint 4569790 7142540;$enc end
if {[$b findNet {w000236}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000236}];set olds {}
set bt [$b findBTerm {src[727]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[727]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[728]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[728]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4576190 7078540;$enc addPoint 4576190 7142540;$enc end
if {[$b findNet {w000237}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000237}];set olds {}
set bt [$b findBTerm {src[729]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[729]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[730]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[730]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4595390 7078540;$enc addPoint 4595390 7142540;$enc end
if {[$b findNet {w000238}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000238}];set olds {}
set bt [$b findBTerm {src[731]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[731]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[732]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[732]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4601790 7078540;$enc addPoint 4601790 7142540;$enc end
if {[$b findNet {w000239}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000239}];set olds {}
set bt [$b findBTerm {src[733]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[733]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[734]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[734]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4608190 7078540;$enc addPoint 4608190 7142540;$enc end
if {[$b findNet {w000240}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000240}];set olds {}
set bt [$b findBTerm {src[735]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[735]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[736]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[736]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 7078540;$enc addPoint 4620990 7142540;$enc end
if {[$b findNet {w000241}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000241}];set olds {}
set bt [$b findBTerm {src[737]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[737]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[738]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[738]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4627390 7078540;$enc addPoint 4627390 7142540;$enc end
if {[$b findNet {w000242}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000242}];set olds {}
set bt [$b findBTerm {src[739]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[739]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[740]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[740]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4633790 7078540;$enc addPoint 4633790 7142540;$enc end
if {[$b findNet {w000243}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000243}];set olds {}
set bt [$b findBTerm {src[741]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[741]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[742]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[742]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 7078540;$enc addPoint 4652990 7142540;$enc end
if {[$b findNet {w000244}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000244}];set olds {}
set bt [$b findBTerm {src[743]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[743]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[744]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[744]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4659390 7078540;$enc addPoint 4659390 7142540;$enc end
if {[$b findNet {w000245}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000245}];set olds {}
set bt [$b findBTerm {src[745]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[745]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[746]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[746]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 7078540;$enc addPoint 4665790 7142540;$enc end
if {[$b findNet {w000246}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000246}];set olds {}
set bt [$b findBTerm {src[747]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[747]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[748]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[748]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4684990 7078540;$enc addPoint 4684990 7142540;$enc end
if {[$b findNet {w000247}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000247}];set olds {}
set bt [$b findBTerm {src[749]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[749]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[750]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[750]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4620990 7008140;$enc addPoint 4620990 7072140;$enc end
if {[$b findNet {w000248}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000248}];set olds {}
set bt [$b findBTerm {src[751]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[751]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[752]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[752]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4691390 7078540;$enc addPoint 4691390 7142540;$enc end
if {[$b findNet {w000249}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000249}];set olds {}
set bt [$b findBTerm {src[753]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[753]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[754]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[754]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4697790 7078540;$enc addPoint 4697790 7142540;$enc end
if {[$b findNet {w000250}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000250}];set olds {}
set bt [$b findBTerm {src[755]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[755]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[756]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[756]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4710590 7078540;$enc addPoint 4710590 7142540;$enc end
if {[$b findNet {w000251}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000251}];set olds {}
set bt [$b findBTerm {src[757]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[757]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[758]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[758]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4716990 7078540;$enc addPoint 4716990 7142540;$enc end
if {[$b findNet {w000252}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000252}];set olds {}
set bt [$b findBTerm {src[759]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[759]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[760]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[760]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4652990 7008140;$enc addPoint 4652990 7072140;$enc end
if {[$b findNet {w000253}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000253}];set olds {}
set bt [$b findBTerm {src[761]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[761]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[762]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[762]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4723390 7078540;$enc addPoint 4723390 7142540;$enc end
if {[$b findNet {w000254}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000254}];set olds {}
set bt [$b findBTerm {src[763]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[763]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[764]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[764]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4665790 7008140;$enc addPoint 4665790 7072140;$enc end
if {[$b findNet {w000255}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000255}];set olds {}
set bt [$b findBTerm {src[765]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[765]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[766]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[766]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4742590 7078540;$enc addPoint 4742590 7142540;$enc end
if {[$b findNet {w000256}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {w000256}];set olds {}
set bt [$b findBTerm {src[767]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[767]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[768]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[768]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w;$enc newPath $m10 FIXED;$enc addPoint 4748990 7078540;$enc addPoint 4748990 7142540;$enc end
if {[$b findNet {adapter_edge_0}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_0}];set olds {}
set bt [$b findBTerm {src[0]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[0]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_1}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_1}];set olds {}
set bt [$b findBTerm {src[1]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[1]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_2}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_2}];set olds {}
set bt [$b findBTerm {src[2]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[2]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_3}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_3}];set olds {}
set bt [$b findBTerm {src[3]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[3]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_4}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_4}];set olds {}
set bt [$b findBTerm {src[4]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[4]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_5}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_5}];set olds {}
set bt [$b findBTerm {src[5]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[5]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_6}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_6}];set olds {}
set bt [$b findBTerm {src[6]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[6]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_7}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_7}];set olds {}
set bt [$b findBTerm {src[7]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[7]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_8}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_8}];set olds {}
set bt [$b findBTerm {src[8]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[8]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_9}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_9}];set olds {}
set bt [$b findBTerm {src[9]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[9]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_10}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_10}];set olds {}
set bt [$b findBTerm {src[10]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[10]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_11}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_11}];set olds {}
set bt [$b findBTerm {src[11]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[11]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_12}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_12}];set olds {}
set bt [$b findBTerm {src[12]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[12]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_13}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_13}];set olds {}
set bt [$b findBTerm {src[13]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[13]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_14}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_14}];set olds {}
set bt [$b findBTerm {src[14]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[14]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_15}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_15}];set olds {}
set bt [$b findBTerm {src[15]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[15]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_16}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_16}];set olds {}
set bt [$b findBTerm {src[16]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[16]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_17}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_17}];set olds {}
set bt [$b findBTerm {src[17]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[17]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_18}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_18}];set olds {}
set bt [$b findBTerm {src[18]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[18]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_19}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_19}];set olds {}
set bt [$b findBTerm {src[19]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[19]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_20}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_20}];set olds {}
set bt [$b findBTerm {src[20]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[20]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_21}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_21}];set olds {}
set bt [$b findBTerm {src[21]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[21]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_22}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_22}];set olds {}
set bt [$b findBTerm {src[22]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[22]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_23}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_23}];set olds {}
set bt [$b findBTerm {src[23]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[23]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_24}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_24}];set olds {}
set bt [$b findBTerm {src[24]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[24]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_25}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_25}];set olds {}
set bt [$b findBTerm {src[25]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[25]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_26}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_26}];set olds {}
set bt [$b findBTerm {src[26]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[26]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_27}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_27}];set olds {}
set bt [$b findBTerm {src[27]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[27]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_28}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_28}];set olds {}
set bt [$b findBTerm {src[28]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[28]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_29}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_29}];set olds {}
set bt [$b findBTerm {src[29]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[29]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_30}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_30}];set olds {}
set bt [$b findBTerm {src[30]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[30]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_31}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_31}];set olds {}
set bt [$b findBTerm {src[31]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[31]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_32}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_32}];set olds {}
set bt [$b findBTerm {src[32]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[32]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_33}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_33}];set olds {}
set bt [$b findBTerm {src[33]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[33]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_34}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_34}];set olds {}
set bt [$b findBTerm {src[34]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[34]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_35}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_35}];set olds {}
set bt [$b findBTerm {src[35]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[35]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_36}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_36}];set olds {}
set bt [$b findBTerm {src[36]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[36]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_37}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_37}];set olds {}
set bt [$b findBTerm {src[37]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[37]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_38}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_38}];set olds {}
set bt [$b findBTerm {src[38]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[38]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_39}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_39}];set olds {}
set bt [$b findBTerm {src[39]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[39]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_40}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_40}];set olds {}
set bt [$b findBTerm {src[40]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[40]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_41}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_41}];set olds {}
set bt [$b findBTerm {src[41]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[41]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_42}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_42}];set olds {}
set bt [$b findBTerm {src[42]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[42]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_43}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_43}];set olds {}
set bt [$b findBTerm {src[43]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[43]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_44}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_44}];set olds {}
set bt [$b findBTerm {src[44]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[44]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_45}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_45}];set olds {}
set bt [$b findBTerm {src[45]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[45]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_46}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_46}];set olds {}
set bt [$b findBTerm {src[46]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[46]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_47}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_47}];set olds {}
set bt [$b findBTerm {src[47]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[47]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_48}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_48}];set olds {}
set bt [$b findBTerm {src[48]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[48]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_49}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_49}];set olds {}
set bt [$b findBTerm {src[49]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[49]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_50}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_50}];set olds {}
set bt [$b findBTerm {src[50]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[50]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_51}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_51}];set olds {}
set bt [$b findBTerm {src[51]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[51]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_52}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_52}];set olds {}
set bt [$b findBTerm {src[52]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[52]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_53}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_53}];set olds {}
set bt [$b findBTerm {src[53]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[53]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_54}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_54}];set olds {}
set bt [$b findBTerm {src[54]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[54]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_55}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_55}];set olds {}
set bt [$b findBTerm {src[55]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[55]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_56}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_56}];set olds {}
set bt [$b findBTerm {src[56]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[56]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_57}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_57}];set olds {}
set bt [$b findBTerm {src[57]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[57]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_58}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_58}];set olds {}
set bt [$b findBTerm {src[58]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[58]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_59}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_59}];set olds {}
set bt [$b findBTerm {src[59]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[59]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_60}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_60}];set olds {}
set bt [$b findBTerm {src[60]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[60]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_61}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_61}];set olds {}
set bt [$b findBTerm {src[61]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[61]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_62}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_62}];set olds {}
set bt [$b findBTerm {src[62]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[62]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_63}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_63}];set olds {}
set bt [$b findBTerm {src[63]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[63]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_64}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_64}];set olds {}
set bt [$b findBTerm {src[64]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[64]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_65}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_65}];set olds {}
set bt [$b findBTerm {src[65]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[65]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_66}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_66}];set olds {}
set bt [$b findBTerm {src[66]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[66]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_67}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_67}];set olds {}
set bt [$b findBTerm {src[67]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[67]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_68}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_68}];set olds {}
set bt [$b findBTerm {src[68]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[68]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_69}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_69}];set olds {}
set bt [$b findBTerm {src[69]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[69]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_70}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_70}];set olds {}
set bt [$b findBTerm {src[70]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[70]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_71}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_71}];set olds {}
set bt [$b findBTerm {src[71]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[71]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_72}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_72}];set olds {}
set bt [$b findBTerm {src[72]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[72]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_73}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_73}];set olds {}
set bt [$b findBTerm {src[73]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[73]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_74}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_74}];set olds {}
set bt [$b findBTerm {src[74]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[74]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_75}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_75}];set olds {}
set bt [$b findBTerm {src[75]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[75]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_76}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_76}];set olds {}
set bt [$b findBTerm {src[76]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[76]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_77}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_77}];set olds {}
set bt [$b findBTerm {src[77]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[77]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_78}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_78}];set olds {}
set bt [$b findBTerm {src[78]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[78]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_79}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_79}];set olds {}
set bt [$b findBTerm {src[79]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[79]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_80}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_80}];set olds {}
set bt [$b findBTerm {src[80]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[80]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_81}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_81}];set olds {}
set bt [$b findBTerm {src[81]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[81]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_82}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_82}];set olds {}
set bt [$b findBTerm {src[82]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[82]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_83}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_83}];set olds {}
set bt [$b findBTerm {src[83]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[83]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_84}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_84}];set olds {}
set bt [$b findBTerm {src[84]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[84]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_85}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_85}];set olds {}
set bt [$b findBTerm {src[85]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[85]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_86}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_86}];set olds {}
set bt [$b findBTerm {src[86]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[86]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_87}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_87}];set olds {}
set bt [$b findBTerm {src[87]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[87]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_88}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_88}];set olds {}
set bt [$b findBTerm {src[88]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[88]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_89}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_89}];set olds {}
set bt [$b findBTerm {src[89]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[89]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_90}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_90}];set olds {}
set bt [$b findBTerm {src[90]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[90]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_91}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_91}];set olds {}
set bt [$b findBTerm {src[91]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[91]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_92}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_92}];set olds {}
set bt [$b findBTerm {src[92]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[92]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_93}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_93}];set olds {}
set bt [$b findBTerm {src[93]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[93]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_94}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_94}];set olds {}
set bt [$b findBTerm {src[94]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[94]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_95}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_95}];set olds {}
set bt [$b findBTerm {src[95]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[95]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_96}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_96}];set olds {}
set bt [$b findBTerm {src[96]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[96]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_97}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_97}];set olds {}
set bt [$b findBTerm {src[97]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[97]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_98}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_98}];set olds {}
set bt [$b findBTerm {src[98]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[98]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_99}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_99}];set olds {}
set bt [$b findBTerm {src[99]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[99]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_100}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_100}];set olds {}
set bt [$b findBTerm {src[100]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[100]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_101}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_101}];set olds {}
set bt [$b findBTerm {src[101]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[101]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_102}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_102}];set olds {}
set bt [$b findBTerm {src[102]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[102]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_103}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_103}];set olds {}
set bt [$b findBTerm {src[103]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[103]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_104}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_104}];set olds {}
set bt [$b findBTerm {src[104]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[104]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_105}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_105}];set olds {}
set bt [$b findBTerm {src[105]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[105]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_106}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_106}];set olds {}
set bt [$b findBTerm {src[106]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[106]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_107}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_107}];set olds {}
set bt [$b findBTerm {src[107]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[107]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_108}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_108}];set olds {}
set bt [$b findBTerm {src[108]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[108]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_109}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_109}];set olds {}
set bt [$b findBTerm {src[109]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[109]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_110}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_110}];set olds {}
set bt [$b findBTerm {src[110]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[110]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_111}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_111}];set olds {}
set bt [$b findBTerm {src[111]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[111]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_112}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_112}];set olds {}
set bt [$b findBTerm {src[112]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[112]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_113}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_113}];set olds {}
set bt [$b findBTerm {src[113]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[113]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_114}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_114}];set olds {}
set bt [$b findBTerm {src[114]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[114]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_115}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_115}];set olds {}
set bt [$b findBTerm {src[115]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[115]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_116}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_116}];set olds {}
set bt [$b findBTerm {src[116]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[116]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_117}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_117}];set olds {}
set bt [$b findBTerm {src[117]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[117]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_118}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_118}];set olds {}
set bt [$b findBTerm {src[118]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[118]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_119}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_119}];set olds {}
set bt [$b findBTerm {src[119]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[119]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_120}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_120}];set olds {}
set bt [$b findBTerm {src[120]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[120]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_121}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_121}];set olds {}
set bt [$b findBTerm {src[121]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[121]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_122}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_122}];set olds {}
set bt [$b findBTerm {src[122]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[122]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_123}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_123}];set olds {}
set bt [$b findBTerm {src[123]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[123]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_124}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_124}];set olds {}
set bt [$b findBTerm {src[124]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[124]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_125}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_125}];set olds {}
set bt [$b findBTerm {src[125]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[125]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_126}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_126}];set olds {}
set bt [$b findBTerm {src[126]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[126]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_127}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_127}];set olds {}
set bt [$b findBTerm {src[127]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[127]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_128}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_128}];set olds {}
set bt [$b findBTerm {src[128]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[128]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_129}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_129}];set olds {}
set bt [$b findBTerm {src[129]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[129]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_130}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_130}];set olds {}
set bt [$b findBTerm {src[130]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[130]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_131}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_131}];set olds {}
set bt [$b findBTerm {src[131]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[131]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_132}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_132}];set olds {}
set bt [$b findBTerm {src[132]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[132]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_133}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_133}];set olds {}
set bt [$b findBTerm {src[133]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[133]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_134}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_134}];set olds {}
set bt [$b findBTerm {src[134]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[134]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_135}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_135}];set olds {}
set bt [$b findBTerm {src[135]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[135]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_136}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_136}];set olds {}
set bt [$b findBTerm {src[136]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[136]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_137}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_137}];set olds {}
set bt [$b findBTerm {src[137]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[137]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_138}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_138}];set olds {}
set bt [$b findBTerm {src[138]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[138]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_139}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_139}];set olds {}
set bt [$b findBTerm {src[139]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[139]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_140}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_140}];set olds {}
set bt [$b findBTerm {src[140]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[140]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_141}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_141}];set olds {}
set bt [$b findBTerm {src[141]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[141]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_142}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_142}];set olds {}
set bt [$b findBTerm {src[142]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[142]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_143}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_143}];set olds {}
set bt [$b findBTerm {src[143]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[143]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_144}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_144}];set olds {}
set bt [$b findBTerm {src[144]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[144]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_145}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_145}];set olds {}
set bt [$b findBTerm {src[145]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[145]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_146}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_146}];set olds {}
set bt [$b findBTerm {src[146]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[146]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_147}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_147}];set olds {}
set bt [$b findBTerm {src[147]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[147]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_148}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_148}];set olds {}
set bt [$b findBTerm {src[148]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[148]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_149}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_149}];set olds {}
set bt [$b findBTerm {src[149]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[149]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_150}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_150}];set olds {}
set bt [$b findBTerm {src[150]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[150]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_151}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_151}];set olds {}
set bt [$b findBTerm {src[151]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[151]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_152}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_152}];set olds {}
set bt [$b findBTerm {src[152]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[152]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_153}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_153}];set olds {}
set bt [$b findBTerm {src[153]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[153]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_154}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_154}];set olds {}
set bt [$b findBTerm {src[154]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[154]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_155}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_155}];set olds {}
set bt [$b findBTerm {src[155]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[155]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_156}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_156}];set olds {}
set bt [$b findBTerm {src[156]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[156]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_157}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_157}];set olds {}
set bt [$b findBTerm {src[157]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[157]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_158}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_158}];set olds {}
set bt [$b findBTerm {src[158]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[158]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_159}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_159}];set olds {}
set bt [$b findBTerm {src[159]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[159]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_160}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_160}];set olds {}
set bt [$b findBTerm {src[160]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[160]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_161}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_161}];set olds {}
set bt [$b findBTerm {src[161]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[161]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_162}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_162}];set olds {}
set bt [$b findBTerm {src[162]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[162]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_163}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_163}];set olds {}
set bt [$b findBTerm {src[163]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[163]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_164}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_164}];set olds {}
set bt [$b findBTerm {src[164]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[164]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_165}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_165}];set olds {}
set bt [$b findBTerm {src[165]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[165]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_166}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_166}];set olds {}
set bt [$b findBTerm {src[166]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[166]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_167}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_167}];set olds {}
set bt [$b findBTerm {src[167]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[167]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_168}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_168}];set olds {}
set bt [$b findBTerm {src[168]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[168]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_169}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_169}];set olds {}
set bt [$b findBTerm {src[169]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[169]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_170}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_170}];set olds {}
set bt [$b findBTerm {src[170]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[170]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_171}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_171}];set olds {}
set bt [$b findBTerm {src[171]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[171]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_172}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_172}];set olds {}
set bt [$b findBTerm {src[172]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[172]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_173}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_173}];set olds {}
set bt [$b findBTerm {src[173]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[173]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_174}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_174}];set olds {}
set bt [$b findBTerm {src[174]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[174]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_175}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_175}];set olds {}
set bt [$b findBTerm {src[175]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[175]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_176}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_176}];set olds {}
set bt [$b findBTerm {src[176]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[176]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_177}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_177}];set olds {}
set bt [$b findBTerm {src[177]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[177]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_178}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_178}];set olds {}
set bt [$b findBTerm {src[178]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[178]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_179}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_179}];set olds {}
set bt [$b findBTerm {src[179]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[179]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_180}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_180}];set olds {}
set bt [$b findBTerm {src[180]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[180]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_181}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_181}];set olds {}
set bt [$b findBTerm {src[181]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[181]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_182}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_182}];set olds {}
set bt [$b findBTerm {src[182]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[182]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_183}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_183}];set olds {}
set bt [$b findBTerm {src[183]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[183]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_184}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_184}];set olds {}
set bt [$b findBTerm {src[184]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[184]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_185}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_185}];set olds {}
set bt [$b findBTerm {src[185]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[185]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_186}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_186}];set olds {}
set bt [$b findBTerm {src[186]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[186]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_187}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_187}];set olds {}
set bt [$b findBTerm {src[187]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[187]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_188}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_188}];set olds {}
set bt [$b findBTerm {src[188]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[188]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_189}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_189}];set olds {}
set bt [$b findBTerm {src[189]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[189]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_190}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_190}];set olds {}
set bt [$b findBTerm {src[190]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[190]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_191}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_191}];set olds {}
set bt [$b findBTerm {src[191]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[191]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_192}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_192}];set olds {}
set bt [$b findBTerm {src[192]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[192]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_193}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_193}];set olds {}
set bt [$b findBTerm {src[193]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[193]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_194}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_194}];set olds {}
set bt [$b findBTerm {src[194]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[194]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_195}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_195}];set olds {}
set bt [$b findBTerm {src[195]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[195]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_196}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_196}];set olds {}
set bt [$b findBTerm {src[196]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[196]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_197}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_197}];set olds {}
set bt [$b findBTerm {src[197]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[197]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_198}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_198}];set olds {}
set bt [$b findBTerm {src[198]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[198]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_199}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_199}];set olds {}
set bt [$b findBTerm {src[199]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[199]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_200}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_200}];set olds {}
set bt [$b findBTerm {src[200]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[200]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_201}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_201}];set olds {}
set bt [$b findBTerm {src[201]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[201]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_202}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_202}];set olds {}
set bt [$b findBTerm {src[202]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[202]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_203}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_203}];set olds {}
set bt [$b findBTerm {src[203]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[203]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_204}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_204}];set olds {}
set bt [$b findBTerm {src[204]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[204]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_205}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_205}];set olds {}
set bt [$b findBTerm {src[205]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[205]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_206}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_206}];set olds {}
set bt [$b findBTerm {src[206]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[206]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_207}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_207}];set olds {}
set bt [$b findBTerm {src[207]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[207]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_208}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_208}];set olds {}
set bt [$b findBTerm {src[208]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[208]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_209}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_209}];set olds {}
set bt [$b findBTerm {src[209]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[209]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_210}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_210}];set olds {}
set bt [$b findBTerm {src[210]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[210]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_211}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_211}];set olds {}
set bt [$b findBTerm {src[211]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[211]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_212}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_212}];set olds {}
set bt [$b findBTerm {src[212]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[212]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_213}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_213}];set olds {}
set bt [$b findBTerm {src[213]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[213]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_214}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_214}];set olds {}
set bt [$b findBTerm {src[214]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[214]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_215}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_215}];set olds {}
set bt [$b findBTerm {src[215]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[215]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_216}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_216}];set olds {}
set bt [$b findBTerm {src[216]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[216]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_217}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_217}];set olds {}
set bt [$b findBTerm {src[217]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[217]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_218}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_218}];set olds {}
set bt [$b findBTerm {src[218]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[218]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_219}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_219}];set olds {}
set bt [$b findBTerm {src[219]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[219]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_220}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_220}];set olds {}
set bt [$b findBTerm {src[220]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[220]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_221}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_221}];set olds {}
set bt [$b findBTerm {src[221]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[221]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_222}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_222}];set olds {}
set bt [$b findBTerm {src[222]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[222]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_223}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_223}];set olds {}
set bt [$b findBTerm {src[223]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[223]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_224}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_224}];set olds {}
set bt [$b findBTerm {src[224]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[224]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_225}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_225}];set olds {}
set bt [$b findBTerm {src[225]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[225]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_226}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_226}];set olds {}
set bt [$b findBTerm {src[226]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[226]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_227}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_227}];set olds {}
set bt [$b findBTerm {src[227]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[227]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_228}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_228}];set olds {}
set bt [$b findBTerm {src[228]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[228]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_229}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_229}];set olds {}
set bt [$b findBTerm {src[229]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[229]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_230}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_230}];set olds {}
set bt [$b findBTerm {src[230]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[230]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_231}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_231}];set olds {}
set bt [$b findBTerm {src[231]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[231]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_232}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_232}];set olds {}
set bt [$b findBTerm {src[232]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[232]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_233}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_233}];set olds {}
set bt [$b findBTerm {src[233]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[233]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_234}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_234}];set olds {}
set bt [$b findBTerm {src[234]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[234]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_235}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_235}];set olds {}
set bt [$b findBTerm {src[235]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[235]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_236}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_236}];set olds {}
set bt [$b findBTerm {src[236]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[236]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_237}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_237}];set olds {}
set bt [$b findBTerm {src[237]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[237]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_238}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_238}];set olds {}
set bt [$b findBTerm {src[238]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[238]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_239}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_239}];set olds {}
set bt [$b findBTerm {src[239]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[239]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_240}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_240}];set olds {}
set bt [$b findBTerm {src[240]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[240]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_241}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_241}];set olds {}
set bt [$b findBTerm {src[241]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[241]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_242}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_242}];set olds {}
set bt [$b findBTerm {src[242]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[242]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_243}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_243}];set olds {}
set bt [$b findBTerm {src[243]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[243]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_244}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_244}];set olds {}
set bt [$b findBTerm {src[244]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[244]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_245}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_245}];set olds {}
set bt [$b findBTerm {src[245]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[245]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_246}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_246}];set olds {}
set bt [$b findBTerm {src[246]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[246]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_247}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_247}];set olds {}
set bt [$b findBTerm {src[247]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[247]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_248}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_248}];set olds {}
set bt [$b findBTerm {src[248]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[248]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_249}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_249}];set olds {}
set bt [$b findBTerm {src[249]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[249]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_250}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_250}];set olds {}
set bt [$b findBTerm {src[250]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[250]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_251}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_251}];set olds {}
set bt [$b findBTerm {src[251]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[251]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_252}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_252}];set olds {}
set bt [$b findBTerm {src[252]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[252]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_253}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_253}];set olds {}
set bt [$b findBTerm {src[253]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[253]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_254}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_254}];set olds {}
set bt [$b findBTerm {src[254]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[254]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_255}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_255}];set olds {}
set bt [$b findBTerm {src[255]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[255]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_256}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_256}];set olds {}
set bt [$b findBTerm {dst[256]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[256]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
$n setSigType CLOCK
if {[$b findNet {adapter_edge_769}] ne "NULL"} {error "Quotient name collision"}
set n [odb::dbNet_create $b {adapter_edge_769}];set olds {}
set bt [$b findBTerm {src[769]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[769]}];lappend olds [$bt getNet];$bt disconnect;$bt connect $n
foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]]!=0 || [llength [$old getITerms]]!=0 || [$old getWire] ne "NULL"} {error "Unexpected residual old adapter net"};odb::dbNet_destroy $old}
$n setSigType CLOCK
if {[llength [$b getNets]]!=514 || [llength [$b getBTerms]]!=1540 || [llength [$b getInsts]]!=0} {error "Quotient native object count mismatch"}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/preconnected_adapter_NOT_SYSTEM.odb}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/preconnected_adapter.def}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/before}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
if {![stage global_route {global_route -guide_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/route.guide} -congestion_report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/congestion.rpt}}]} {catch {write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/failed_global.odb}};catch {write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/failed_global.def}};close $stages;exit 1}
if {![stage detailed_route {detailed_route -output_drc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/route.drc} -verbose 1;write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/routed_adapter_NOT_SYSTEM.odb};write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/routed_adapter.def}}]} {close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/after}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/after.OBS.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/preconnected-upper-r01/code/export_access.tcl}
report_wire_length -detailed_route -summary -file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_preconnected/r01/llaccel/wire_length.csv}
close $stages
