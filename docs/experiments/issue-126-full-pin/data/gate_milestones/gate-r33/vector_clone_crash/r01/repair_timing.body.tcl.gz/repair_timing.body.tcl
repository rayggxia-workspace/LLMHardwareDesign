
  # `-phases` is the public spelling listed in -help / define_cmd_args.
  # `-policy` and `-policies` are accepted-but-undocumented aliases for the
  # same phase sequence; only one of the three may be supplied per call.
  sta::parse_key_args "repair_timing" args  keys {-setup_margin -hold_margin -slack_margin  -libraries -max_utilization -max_buffer_percent -sequence  -phases -policy -policies -path_group  -recover_power -repair_tns -max_passes -max_iterations -max_repairs_per_pass}  flags {-setup -hold -allow_setup_violations -skip_pin_swap -skip_gate_cloning  -skip_size_down -skip_buffering -skip_buffer_removal -skip_buffer_to_inverters  -skip_last_gasp -skip_vt_swap -skip_crit_vt_swap -skip_crpr  -match_cell_footprint -verbose}

  set setup [info exists flags(-setup)]
  set hold [info exists flags(-hold)]

  if { !$setup && !$hold } {
    set setup 1
    set hold 1
  }

  if { [info exists keys(-slack_margin)] } {
    utl::warn RSZ 76 "-slack_margin is deprecated. Use -setup_margin/-hold_margin"
    if { !$setup && $hold } {
      set setup_margin 0.0
      set hold_margin [rsz::parse_time_margin_arg "-slack_margin" keys]
    } else {
      set setup_margin [rsz::parse_time_margin_arg "-slack_margin" keys]
      set hold_margin 0.0
    }
  } else {
    set setup_margin [rsz::parse_time_margin_arg "-setup_margin" keys]
    set hold_margin [rsz::parse_time_margin_arg "-hold_margin" keys]
  }

  if { [info exists keys(-sequence)] } {
    set sequence $keys(-sequence)
  } else {
    set sequence ""
  }

  # Resolve -phases / -policy / -policies aliases to a single `phases` value.
  # All three carry identical semantics; rejecting more than one prevents
  # silent precedence surprises if the user mixes spellings.
  set phases ""
  set phase_alias_count 0
  foreach alias_key {-phases -policy -policies} {
    if { [info exists keys($alias_key)] } {
      incr phase_alias_count
      set phases $keys($alias_key)
    }
  }
  if { $phase_alias_count > 1 } {
    utl::error RSZ 222  "specify at most one of -phases / -policy / -policies"
  }

  # Unknown names warn and resolve to "", which repairs every path group.
  set path_group ""
  if { [info exists keys(-path_group)] } {
    set path_group [rsz::resolve_path_group $keys(-path_group)]
  }

  set allow_setup_violations [info exists flags(-allow_setup_violations)]
  set skip_pin_swap [info exists flags(-skip_pin_swap)]
  set skip_gate_cloning [info exists flags(-skip_gate_cloning)]
  set skip_size_down_fanout [info exists flags(-skip_size_down)]
  set skip_buffering [info exists flags(-skip_buffering)]
  set skip_buffer_removal [info exists flags(-skip_buffer_removal)]
  set skip_buffer_to_inverters [info exists flags(-skip_buffer_to_inverters)]
  set skip_last_gasp [info exists flags(-skip_last_gasp)]
  set skip_vt_swap [info exists flags(-skip_vt_swap)]
  set skip_crit_vt_swap [info exists flags(-skip_crit_vt_swap)]
  set skip_crpr [info exists flags(-skip_crpr)]
  rsz::set_max_utilization [rsz::parse_max_util keys]
  set max_buffer_percent 20
  if { [info exists keys(-max_buffer_percent)] } {
    set max_buffer_percent $keys(-max_buffer_percent)
    sta::check_percent "-max_buffer_percent" $max_buffer_percent
  }
  set max_buffer_percent [expr $max_buffer_percent / 100.0]

  set repair_tns_end_percent 1.0
  if { [info exists keys(-repair_tns)] } {
    set repair_tns_end_percent $keys(-repair_tns)
    sta::check_percent "-repair_tns" $repair_tns_end_percent
    set repair_tns_end_percent [expr $repair_tns_end_percent / 100.0]
  }

  set recover_power_percent -1
  if { [info exists keys(-recover_power)] } {
    set recover_power_percent $keys(-recover_power)
    sta::check_percent "-recover_power" $recover_power_percent
    set recover_power_percent [expr $recover_power_percent / 100.0]
  }

  set verbose 0
  if { [info exists flags(-verbose)] } {
    set verbose 1
  }

  set max_passes 10000
  if { [info exists keys(-max_passes)] } {
    set max_passes $keys(-max_passes)
  }

  set max_iterations -1
  if { [info exists keys(-max_iterations)] } {
    set max_iterations $keys(-max_iterations)
  }

  set match_cell_footprint [info exists flags(-match_cell_footprint)]
  if { [design_is_routed] } {
    est::set_parasitics_src "detailed_routing"
  }

  set max_repairs_per_pass 1
  if { [info exists keys(-max_repairs_per_pass)] } {
    set max_repairs_per_pass $keys(-max_repairs_per_pass)
  }

  sta::check_argc_eq0 "repair_timing" $args
  est::check_parasitics

  set recovered_power 0
  set repaired_setup 0
  set repaired_hold 0
  if { $recover_power_percent >= 0 } {
    set recovered_power [rsz::recover_power $recover_power_percent $match_cell_footprint $verbose]
  } else {
    # Restore the command-entry CRPR setting after setup and hold repair.
    set entry_crpr_enabled [sta::crpr_enabled]
    set repair_crpr_enabled [expr { $entry_crpr_enabled && !$skip_crpr }]
    try {
      if { $setup } {
        if { $skip_crpr } {
          utl::info RSZ 225 "CRPR disabled during setup repair."
        }
        if { [sta::crpr_enabled] != $repair_crpr_enabled } {
          sta::set_crpr_enabled $repair_crpr_enabled
        }
        set repaired_setup [rsz::repair_setup $setup_margin $repair_tns_end_percent $max_passes  $max_iterations $max_repairs_per_pass $match_cell_footprint $verbose  $sequence $phases $path_group  $skip_pin_swap $skip_gate_cloning $skip_size_down_fanout $skip_buffering  $skip_buffer_removal $skip_buffer_to_inverters $skip_last_gasp $skip_vt_swap  $skip_crit_vt_swap]
      }
      if { $hold } {
        if { $skip_crpr } {
          utl::info RSZ 226 "CRPR disabled during hold repair."
        }
        if { [sta::crpr_enabled] != $repair_crpr_enabled } {
          sta::set_crpr_enabled $repair_crpr_enabled
        }
        set repaired_hold [rsz::repair_hold $setup_margin $hold_margin  $allow_setup_violations $max_buffer_percent $max_passes  $max_iterations $match_cell_footprint $verbose $path_group]
      }
    } finally {
      if { [sta::crpr_enabled] != $entry_crpr_enabled } {
        sta::set_crpr_enabled $entry_crpr_enabled
      }
    }
  }

  return [expr $recovered_power || $repaired_setup || $repaired_hold]
