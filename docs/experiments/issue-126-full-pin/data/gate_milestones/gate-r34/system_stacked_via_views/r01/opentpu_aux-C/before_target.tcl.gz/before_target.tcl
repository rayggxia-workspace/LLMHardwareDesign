read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_patch_route/r02/opentpu_aux-C/routed.odb}
set ::env(PINXY_ACCESS_ALL) 0
set ::env(PINXY_ACCESS_NET_NAMES) {_215139_}
set ::env(PINXY_ACCESS_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/before_actual_target.tsv.gz}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/physical-views-and-grid-r31/code/export_access.tcl}
