read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/finalized/access-r03/gemm-C/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm-r02/gemm-C/leaf_detail.lef}
