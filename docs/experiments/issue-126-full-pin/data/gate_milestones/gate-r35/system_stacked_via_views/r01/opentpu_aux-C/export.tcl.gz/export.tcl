read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_1024x128.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_128x128.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_4096x32.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_512x31.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/clean.odb}
write_abstract_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/abstract.lef}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/detailed.lef}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/clean.def}
write_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/clean.v}
set b [ord::get_db_block];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/pins.tsv} w];puts $f "pin\tdirection\tuse\tnet\tlayer\tx0\ty0\tx1\ty1";foreach p [$b getBTerms] {foreach bp [$p getBPins] {foreach r [$bp getBoxes] {puts $f [join [list [$p getName] [$p getIoType] [$p getSigType] [[$p getNet] getName] [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]] "\t"]}}};close $f
read_sdc {/public/home/yuzelu/PingyangHuang/issue-55/full-block-integration-20261023T103718349596Z/runs/auxiliary-route-opentpu-4c-01/flow/results/nangate45/hpy_opentpu_aux/base/5_1_grt.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_route/r01/opentpu_aux-C/extracted.spef}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/hold.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/parasitic_coverage.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/constraint_coverage.txt}
write_timing_model {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/timing.lib}
set ::env(PINXY_ACCESS_ALL) 0
set ::env(PINXY_ACCESS_NET_NAMES) {_215139_}
set ::env(PINXY_ACCESS_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/after_actual_target.tsv.gz}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/physical-views-and-grid-r31/code/export_access.tcl}
report_check_types -min_pulse_width -min_period -max_skew -clock_gating_setup -clock_gating_hold -min_slew -min_capacitance -min_fanout -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_views/r01/opentpu_aux-C/current_source_extended_checks_all.txt}
