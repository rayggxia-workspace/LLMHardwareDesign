# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

proc cell_cost {file} {
 set b [ord::get_db_block];set u [$b getDbUnitsPerMicron];set f [open $file w]
 puts $f "instance\tmaster\ttype\tarea_um2\tx_dbu\ty_dbu"
 foreach i [$b getInsts] {set m [$i getMaster];lassign [$i getLocation] x y;puts $f [join [list [$i getName] [$m getName] [$m getType] [expr {[$m getWidth]*double([$m getHeight])/($u*$u)}] $x $y] "\t"]};close $f
}
read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_resume/r01/routed.odb}
read_sdc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/vec-physical-01/flow/results/nangate45/llhd_vec_original/base/6_final.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/before}
cell_cost {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/before.cell_cost.tsv}
if {![stage strip_only_signal_clock_routes_in_memory_before_placement {set current [info body repair_timing];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/actual_repair_timing.body.tcl} w];puts -nonewline $f $current;close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/actual_context_transition.txt} w]
puts $f [exec sha256sum [info nameofexecutable]]
set original [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_crash/r02/repair_timing.body.tcl} r];set recorded [read $original];close $original
if {$current ne $recorded} {error "Installed repair_timing differs from source-bound capability body"}
set predicate [namespace qualifiers [namespace origin repair_timing]]::design_is_routed
if {![llength [info commands $predicate]]} {set predicate design_is_routed}
if {![llength [info commands $predicate]]} {error "Cannot resolve native routed predicate; stop before repair"}
puts $f [list NATIVE_PREDICATE $predicate BEFORE [$predicate]]
set removed 0;set b [ord::get_db_block]
foreach n [$b getNets] {
 if {[$n getSigType] ni {SIGNAL CLOCK}} {continue}
 set w [$n getWire];if {$w ne "NULL"} {odb::dbWire_destroy $w;incr removed}
}
puts $f [list REMOVED_ONLY_SIGNAL_CLOCK_DBWIRES $removed AFTER [$predicate]];close $f
if {$removed<=0 || [$predicate]} {error "Native design still routed; refuse the same unintended detailed estimator path"}
}]} {close $stages;exit 1}
if {![stage remove_only_fillers_before_estimation {remove_fillers}]} {close $stages;exit 1}
if {![stage placement_estimator {estimate_parasitics -placement}]} {close $stages;exit 1}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/HEURISTIC_before.setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/HEURISTIC_before.hold.txt}
if {![stage setup_with_gate_cloning {repair_timing -setup -skip_pin_swap -skip_buffer_removal -skip_buffer_to_inverters -max_passes 20 -max_iterations 10000 -max_utilization 85 -verbose;write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/gate_repaired_NOT_LEGALIZED_OR_ROUTED.odb}}]} {close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/after}
cell_cost {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/after.cell_cost.tsv}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/HEURISTIC_after.setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/HEURISTIC_after.hold.txt}
write_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_probe/r03/gate_repaired_NOT_QUALIFIED.v}
close $stages
