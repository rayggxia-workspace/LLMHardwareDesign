read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/diode_views/r01/gemm-C/clean.odb}
write_abstract_lef -bloat_factor 0 {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_fixtures/gemm658-r02/gemm-C/leaf_detail.lef}
