set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/vector_clone_crash/r02/repair_timing.body.tcl} w];puts -nonewline $f [info body repair_timing];close $f
help repair_timing
