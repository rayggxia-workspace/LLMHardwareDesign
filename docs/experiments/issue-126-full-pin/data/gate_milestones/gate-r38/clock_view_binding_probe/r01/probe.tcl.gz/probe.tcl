read_lef /OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_views/r01/mxu-C/abstract.lef}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/clock_view_binding_probe/r01/native_clock_types.tsv} w];puts $f "stage	MTerm_USE	ITerm_USE	net_USE"
proc clock_type {label} {global f;set m [[ord::get_db] findMaster {llhd_opentpu_mxu}];set mt [$m findMTerm clk];set it NULL;set ns NULL;set b [ord::get_db_block];if {$b ne "NULL"} {set i [$b findInst u_macro];if {$i ne "NULL"} {set t [$i findITerm clk];set it [$t getSigType];set n [$t getNet];if {$n ne "NULL"} {set ns [$n getSigType]}}};puts $f [join [list $label [$mt getSigType] $it $ns] "	"]}
clock_type after_LEF
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_escape_views/r01/mxu-C/timing.lib}
clock_type after_Liberty
read_verilog {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/clock_view_binding_probe/r01/fixture.v}
link_design mxu_clock_probe
clock_type after_link_design
create_clock -name clk -period 2.5000 [get_ports {clk}]
clock_type after_original_create_clock
close $f
