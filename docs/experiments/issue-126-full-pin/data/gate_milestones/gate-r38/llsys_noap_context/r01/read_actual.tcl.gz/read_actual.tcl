set ::env(PINXY_AUDIT_ODB) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_actual_via_tips/r02/routed.odb}
set ::env(PINXY_AUDIT_PIN) bit_1025
set ::env(PINXY_AUDIT_BOX) {702770 2123440 711980 2133400}
set ::env(PINXY_AUDIT_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_noap_context/r01/all_actual_local_metal_PG_OBS.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/llsys-noap-context-r01/audit_parent_region.tcl}
set b [ord::get_db_block];set bt [$b findBTerm bit_1025];set net [$bt getNet]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_noap_context/r01/actual_target_via_definitions.tsv} w]
puts $f "via	kind	x	y	layer	x0	y0	x1	y1"
set itr [odb::dbWirePathItr];set path [odb::dbWirePath];set ps [odb::dbWirePathShape]
$itr begin [$net getWire]
while {[$itr getNextPath $path]} {while {[$itr getNextShape $ps]} {
 set s [odb::dbWirePathShape_shape_get $ps];if {![$s isVia]} {continue}
 set kind TECH;set via [$s getTechVia];if {$via eq "NULL"} {set kind BLOCK;set via [$s getVia]}
 lassign [$s getViaXY] x y
 foreach box [$via getBoxes] {puts $f [join [list [$via getName] $kind $x $y [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]] "	"]}
}};close $f
puts {ACTUAL_BIT_1025_VIA_DEFINITIONS_READ_ONLY}
