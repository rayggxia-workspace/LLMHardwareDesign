read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_adaptation_trial/r02/opentpu/placed_adapter_NOT_SYSTEM.odb}
set b [ord::get_db_block];set tech [ord::get_db_tech]
puts "ACTUAL_APPEND_COMMANDS [info commands ::odb::*Wire*append*]"
foreach name {HPY_APPEND_A HPY_APPEND_B HPY_APPEND_C} {if {[$b findNet $name] ne "NULL"} {error "Probe name collision"}}
set na [odb::dbNet_create $b HPY_APPEND_A];set nb [odb::dbNet_create $b HPY_APPEND_B];set nc [odb::dbNet_create $b HPY_APPEND_C]
set a [odb::dbWire_create $na];set e [odb::dbWireEncoder];$e begin $a;$e newPath [$tech findLayer metal10] FIXED;$e addPoint 200000 200000;$e addPoint 200000 264000;$e end
set bb [odb::dbWire_create $nb];$e begin $bb;$e newPath [$tech findLayer metal10] ROUTED;$e addPoint 200000 200000;$e addTechVia [$tech findVia via10_0];$e addPoint 206400 200000;$e end
set c [odb::dbWire_create $nc]
$c append $a
$c append $bb
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_wire_append_api/r02/native_append.def}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_wire_append_api/r02/actual_shapes.tsv} w];puts $f "net\tkind\tlayer\tx0\ty0\tx1\ty1"
foreach n [list $na $nb $nc] {
 set itr [odb::dbWirePathItr];set path [odb::dbWirePath];set ps [odb::dbWirePathShape];$itr begin [$n getWire]
 while {[$itr getNextPath $path]} {while {[$itr getNextShape $ps]} {
  set s [odb::dbWirePathShape_shape_get $ps]
  if {[$s isVia]} {
   set v [$s getTechVia];if {$v eq "NULL"} {set v [$s getVia]};lassign [$s getViaXY] x y
   foreach box [$v getBoxes] {puts $f [join [list [$n getName] VIA [[$box getTechLayer] getName] [expr {[$box xMin]+$x}] [expr {[$box yMin]+$y}] [expr {[$box xMax]+$x}] [expr {[$box yMax]+$y}]] "\t"]}
  } else {puts $f [join [list [$n getName] WIRE [[$s getTechLayer] getName] [$s xMin] [$s yMin] [$s xMax] [$s yMax]] "\t"]}
 }}
};close $f
puts "ACTUAL_OPCODE_APPEND_EXECUTED_REQUIRES_COUNTER_AND_FIXED_STATUS_CHECK"
