 global errorCode errorInfo; set redirect [parse_redirect_args args]; set code [catch { parse_key_args "report_min_clock_period" args  keys {-clocks} flags {-include_port_paths} 0
  
  if { [info exists keys(-clocks)] } {
    set clks [get_clocks $keys(-clocks)]
  } else {
    set clks [sort_by_name [all_clocks]]
  }
  set include_port_paths [info exists flags(-include_port_paths)]

  foreach clk $clks {
    set min_period [find_clk_min_period $clk $include_port_paths]
    if { $min_period == 0.0 } {
      set min_period 0
      set fmax "INF"
    } else {
      # max frequency in MHz
      set fmax [expr 1.0e-6 / $min_period]
    }
    report_line "[get_name $clk] period_min = [format_time $min_period 2] fmax = [format %.2f $fmax]"
  } } ret ]; if {$redirect} { redirect_file_end }; if {$code == 1} {return -code $code -errorcode $errorCode -errorinfo $errorInfo $ret} else {return $ret} 