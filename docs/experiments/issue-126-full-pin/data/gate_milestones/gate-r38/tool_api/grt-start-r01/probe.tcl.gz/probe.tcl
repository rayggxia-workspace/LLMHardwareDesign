puts {NATIVE_GRT_COMMANDS_BEGIN}
foreach c [lsort [info commands grt::*]] {puts $c}
puts {NATIVE_GRT_COMMANDS_END}
foreach c {global_route set_routing_layers set_global_routing_layer_adjustment set_global_routing_region_adjustment} {
  puts "COMMAND_BODY $c"
  if {[catch {info body $c} body]} {puts $body} else {puts $body}
  catch {help $c}
}
catch {help *grid*}
foreach p {/OpenROAD-flow-scripts/tools/OpenROAD/src/grt/src/GlobalRouter.cpp /OpenROAD-flow-scripts/tools/OpenROAD/src/grt/src/Grid.cpp /OpenROAD-flow-scripts/tools/OpenROAD/src/grt/src/GlobalRouter.tcl} {
  puts [list SOURCE_AVAILABLE $p [file exists $p]]
}
