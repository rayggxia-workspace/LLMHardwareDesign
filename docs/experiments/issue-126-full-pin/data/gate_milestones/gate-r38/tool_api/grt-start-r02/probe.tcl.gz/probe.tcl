set probe_out {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/tool_api/grt-start-r02}
puts {NATIVE_GRT_COMMANDS_BEGIN}
foreach c [lsort [info commands grt::*]] {puts $c}
puts {NATIVE_GRT_COMMANDS_END}
foreach c {global_route set_routing_layers set_global_routing_layer_adjustment set_global_routing_region_adjustment} {
  puts "COMMAND_BODY $c"
  if {![catch {info body $c} body]} {
    set f [open $probe_out/$c.body.tcl w];puts -nonewline $f $body;close $f
    puts [list BODY_COMPLETE $c [info complete $body]]
  } else {puts $body}
  catch {help $c}
}
puts [list ACTUAL_EXECUTABLE [info nameofexecutable]]
catch {puts [exec sha256sum [info nameofexecutable]]}
catch {help *grid*}
foreach p {/OpenROAD-flow-scripts/tools/OpenROAD/src/grt/src/GlobalRouter.cpp /OpenROAD-flow-scripts/tools/OpenROAD/src/grt/src/Grid.cpp /OpenROAD-flow-scripts/tools/OpenROAD/src/grt/src/GlobalRouter.tcl} {
  puts [list SOURCE_AVAILABLE $p [file exists $p]]
}
