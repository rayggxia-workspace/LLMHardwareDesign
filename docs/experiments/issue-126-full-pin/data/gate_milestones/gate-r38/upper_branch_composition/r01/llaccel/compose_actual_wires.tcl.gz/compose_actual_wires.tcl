# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/composition_stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/routed_770_BRANCHES_NOT_SYSTEM.odb}
proc save_obs {file} {set f [open $file w];foreach ob [[ord::get_db_block] getObstructions] {set r [$ob getBBox];puts $f [list [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]};close $f}
set b [ord::get_db_block];set m10 [[ord::get_db_tech] findLayer metal10];if {[$m10 getWidth]!=1600} {error "Actual FIXED width differs"}
if {![stage exact_native_opcode_composition {if {[$b findNet {w000001}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000001}];set olds {}
set bt [$b findBTerm {src[257]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[257]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[258]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[258]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 5734540;$enc addPoint 4480190 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000002}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000002}];set olds {}
set bt [$b findBTerm {src[259]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[259]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[260]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[260]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 5734540;$enc addPoint 4486590 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000003}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000003}];set olds {}
set bt [$b findBTerm {src[261]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[261]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[262]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[262]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 5734540;$enc addPoint 4499390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000004}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000004}];set olds {}
set bt [$b findBTerm {src[263]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[263]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[264]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[264]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 5734540;$enc addPoint 4505790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000005}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000005}];set olds {}
set bt [$b findBTerm {src[265]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[265]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[266]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[266]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 5734540;$enc addPoint 4512190 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000006}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000006}];set olds {}
set bt [$b findBTerm {src[267]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[267]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[268]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[268]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 5734540;$enc addPoint 4518590 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000007}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000007}];set olds {}
set bt [$b findBTerm {src[269]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[269]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[270]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[270]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 5734540;$enc addPoint 4531390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000008}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000008}];set olds {}
set bt [$b findBTerm {src[271]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[271]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[272]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[272]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 5734540;$enc addPoint 4537790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000009}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000009}];set olds {}
set bt [$b findBTerm {src[273]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[273]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[274]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[274]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 5734540;$enc addPoint 4544190 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000010}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000010}];set olds {}
set bt [$b findBTerm {src[275]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[275]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[276]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[276]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 5734540;$enc addPoint 4563390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000011}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000011}];set olds {}
set bt [$b findBTerm {src[277]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[277]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[278]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[278]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 5734540;$enc addPoint 4569790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000012}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000012}];set olds {}
set bt [$b findBTerm {src[279]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[279]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[280]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[280]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 5734540;$enc addPoint 4576190 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000013}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000013}];set olds {}
set bt [$b findBTerm {src[281]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[281]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[282]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[282]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 5734540;$enc addPoint 4595390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000014}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000014}];set olds {}
set bt [$b findBTerm {src[283]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[283]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[284]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[284]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 5734540;$enc addPoint 4601790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000015}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000015}];set olds {}
set bt [$b findBTerm {src[285]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[285]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[286]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[286]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 5734540;$enc addPoint 4608190 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000016}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000016}];set olds {}
set bt [$b findBTerm {src[287]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[287]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[288]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[288]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 5734540;$enc addPoint 4620990 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000017}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000017}];set olds {}
set bt [$b findBTerm {src[289]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[289]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[290]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[290]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 5734540;$enc addPoint 4627390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000018}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000018}];set olds {}
set bt [$b findBTerm {src[291]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[291]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[292]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[292]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 5734540;$enc addPoint 4633790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000019}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000019}];set olds {}
set bt [$b findBTerm {src[293]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[293]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[294]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[294]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 5734540;$enc addPoint 4652990 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000020}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000020}];set olds {}
set bt [$b findBTerm {src[295]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[295]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[296]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[296]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 5734540;$enc addPoint 4659390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000021}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000021}];set olds {}
set bt [$b findBTerm {src[297]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[297]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[298]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[298]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 5734540;$enc addPoint 4665790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000022}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000022}];set olds {}
set bt [$b findBTerm {src[299]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[299]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[300]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[300]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 5734540;$enc addPoint 4684990 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000023}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000023}];set olds {}
set bt [$b findBTerm {src[301]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[301]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[302]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[302]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 5664140;$enc addPoint 4620990 5728140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000024}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000024}];set olds {}
set bt [$b findBTerm {src[303]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[303]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[304]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[304]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 5734540;$enc addPoint 4691390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000025}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000025}];set olds {}
set bt [$b findBTerm {src[305]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[305]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[306]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[306]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 5734540;$enc addPoint 4697790 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000026}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000026}];set olds {}
set bt [$b findBTerm {src[307]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[307]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[308]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[308]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 5734540;$enc addPoint 4710590 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000027}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000027}];set olds {}
set bt [$b findBTerm {src[309]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[309]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[310]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[310]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 5734540;$enc addPoint 4716990 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000028}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000028}];set olds {}
set bt [$b findBTerm {src[311]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[311]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[312]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[312]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 5664140;$enc addPoint 4652990 5728140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000029}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000029}];set olds {}
set bt [$b findBTerm {src[313]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[313]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[314]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[314]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 5734540;$enc addPoint 4723390 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000030}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000030}];set olds {}
set bt [$b findBTerm {src[315]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[315]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[316]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[316]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 5664140;$enc addPoint 4665790 5728140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000031}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000031}];set olds {}
set bt [$b findBTerm {src[317]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[317]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[318]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[318]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 5734540;$enc addPoint 4742590 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000032}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000032}];set olds {}
set bt [$b findBTerm {src[319]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[319]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[320]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[320]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 5734540;$enc addPoint 4748990 5798540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000033}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000033}];set olds {}
set bt [$b findBTerm {src[321]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[321]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[322]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[322]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 5926540;$enc addPoint 4480190 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000034}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000034}];set olds {}
set bt [$b findBTerm {src[323]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[323]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[324]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[324]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 5926540;$enc addPoint 4486590 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000035}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000035}];set olds {}
set bt [$b findBTerm {src[325]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[325]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[326]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[326]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 5926540;$enc addPoint 4499390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000036}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000036}];set olds {}
set bt [$b findBTerm {src[327]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[327]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[328]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[328]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 5926540;$enc addPoint 4505790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000037}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000037}];set olds {}
set bt [$b findBTerm {src[329]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[329]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[330]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[330]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 5926540;$enc addPoint 4512190 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000038}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000038}];set olds {}
set bt [$b findBTerm {src[331]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[331]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[332]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[332]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 5926540;$enc addPoint 4518590 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000039}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000039}];set olds {}
set bt [$b findBTerm {src[333]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[333]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[334]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[334]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 5926540;$enc addPoint 4531390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000040}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000040}];set olds {}
set bt [$b findBTerm {src[335]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[335]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[336]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[336]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 5926540;$enc addPoint 4537790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000041}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000041}];set olds {}
set bt [$b findBTerm {src[337]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[337]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[338]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[338]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 5926540;$enc addPoint 4544190 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000042}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000042}];set olds {}
set bt [$b findBTerm {src[339]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[339]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[340]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[340]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 5926540;$enc addPoint 4563390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000043}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000043}];set olds {}
set bt [$b findBTerm {src[341]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[341]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[342]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[342]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 5926540;$enc addPoint 4569790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000044}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000044}];set olds {}
set bt [$b findBTerm {src[343]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[343]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[344]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[344]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 5926540;$enc addPoint 4576190 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000045}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000045}];set olds {}
set bt [$b findBTerm {src[345]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[345]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[346]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[346]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 5926540;$enc addPoint 4595390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000046}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000046}];set olds {}
set bt [$b findBTerm {src[347]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[347]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[348]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[348]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 5926540;$enc addPoint 4601790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000047}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000047}];set olds {}
set bt [$b findBTerm {src[349]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[349]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[350]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[350]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 5926540;$enc addPoint 4608190 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000048}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000048}];set olds {}
set bt [$b findBTerm {src[351]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[351]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[352]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[352]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 5926540;$enc addPoint 4620990 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000049}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000049}];set olds {}
set bt [$b findBTerm {src[353]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[353]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[354]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[354]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 5926540;$enc addPoint 4627390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000050}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000050}];set olds {}
set bt [$b findBTerm {src[355]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[355]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[356]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[356]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 5926540;$enc addPoint 4633790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000051}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000051}];set olds {}
set bt [$b findBTerm {src[357]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[357]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[358]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[358]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 5926540;$enc addPoint 4652990 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000052}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000052}];set olds {}
set bt [$b findBTerm {src[359]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[359]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[360]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[360]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 5926540;$enc addPoint 4659390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000053}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000053}];set olds {}
set bt [$b findBTerm {src[361]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[361]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[362]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[362]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 5926540;$enc addPoint 4665790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000054}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000054}];set olds {}
set bt [$b findBTerm {src[363]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[363]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[364]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[364]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 5926540;$enc addPoint 4684990 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000055}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000055}];set olds {}
set bt [$b findBTerm {src[365]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[365]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[366]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[366]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 5856140;$enc addPoint 4620990 5920140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000056}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000056}];set olds {}
set bt [$b findBTerm {src[367]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[367]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[368]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[368]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 5926540;$enc addPoint 4691390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000057}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000057}];set olds {}
set bt [$b findBTerm {src[369]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[369]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[370]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[370]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 5926540;$enc addPoint 4697790 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000058}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000058}];set olds {}
set bt [$b findBTerm {src[371]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[371]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[372]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[372]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 5926540;$enc addPoint 4710590 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000059}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000059}];set olds {}
set bt [$b findBTerm {src[373]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[373]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[374]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[374]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 5926540;$enc addPoint 4716990 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000060}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000060}];set olds {}
set bt [$b findBTerm {src[375]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[375]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[376]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[376]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 5856140;$enc addPoint 4652990 5920140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000061}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000061}];set olds {}
set bt [$b findBTerm {src[377]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[377]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[378]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[378]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 5926540;$enc addPoint 4723390 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000062}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000062}];set olds {}
set bt [$b findBTerm {src[379]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[379]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[380]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[380]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 5856140;$enc addPoint 4665790 5920140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000063}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000063}];set olds {}
set bt [$b findBTerm {src[381]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[381]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[382]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[382]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 5926540;$enc addPoint 4742590 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000064}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000064}];set olds {}
set bt [$b findBTerm {src[383]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[383]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[384]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[384]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 5926540;$enc addPoint 4748990 5990540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000065}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000065}];set olds {}
set bt [$b findBTerm {src[385]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[385]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[386]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[386]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 6118540;$enc addPoint 4480190 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000066}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000066}];set olds {}
set bt [$b findBTerm {src[387]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[387]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[388]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[388]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 6118540;$enc addPoint 4486590 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000067}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000067}];set olds {}
set bt [$b findBTerm {src[389]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[389]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[390]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[390]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 6118540;$enc addPoint 4499390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000068}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000068}];set olds {}
set bt [$b findBTerm {src[391]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[391]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[392]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[392]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 6118540;$enc addPoint 4505790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000069}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000069}];set olds {}
set bt [$b findBTerm {src[393]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[393]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[394]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[394]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 6118540;$enc addPoint 4512190 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000070}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000070}];set olds {}
set bt [$b findBTerm {src[395]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[395]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[396]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[396]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 6118540;$enc addPoint 4518590 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000071}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000071}];set olds {}
set bt [$b findBTerm {src[397]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[397]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[398]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[398]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 6118540;$enc addPoint 4531390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000072}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000072}];set olds {}
set bt [$b findBTerm {src[399]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[399]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[400]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[400]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 6118540;$enc addPoint 4537790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000073}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000073}];set olds {}
set bt [$b findBTerm {src[401]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[401]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[402]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[402]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 6118540;$enc addPoint 4544190 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000074}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000074}];set olds {}
set bt [$b findBTerm {src[403]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[403]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[404]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[404]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 6118540;$enc addPoint 4563390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000075}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000075}];set olds {}
set bt [$b findBTerm {src[405]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[405]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[406]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[406]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 6118540;$enc addPoint 4569790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000076}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000076}];set olds {}
set bt [$b findBTerm {src[407]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[407]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[408]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[408]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 6118540;$enc addPoint 4576190 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000077}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000077}];set olds {}
set bt [$b findBTerm {src[409]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[409]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[410]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[410]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 6118540;$enc addPoint 4595390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000078}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000078}];set olds {}
set bt [$b findBTerm {src[411]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[411]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[412]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[412]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 6118540;$enc addPoint 4601790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000079}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000079}];set olds {}
set bt [$b findBTerm {src[413]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[413]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[414]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[414]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 6118540;$enc addPoint 4608190 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000080}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000080}];set olds {}
set bt [$b findBTerm {src[415]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[415]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[416]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[416]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6118540;$enc addPoint 4620990 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000081}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000081}];set olds {}
set bt [$b findBTerm {src[417]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[417]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[418]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[418]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 6118540;$enc addPoint 4627390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000082}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000082}];set olds {}
set bt [$b findBTerm {src[419]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[419]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[420]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[420]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 6118540;$enc addPoint 4633790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000083}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000083}];set olds {}
set bt [$b findBTerm {src[421]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[421]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[422]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[422]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6118540;$enc addPoint 4652990 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000084}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000084}];set olds {}
set bt [$b findBTerm {src[423]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[423]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[424]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[424]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 6118540;$enc addPoint 4659390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000085}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000085}];set olds {}
set bt [$b findBTerm {src[425]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[425]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[426]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[426]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6118540;$enc addPoint 4665790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000086}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000086}];set olds {}
set bt [$b findBTerm {src[427]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[427]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[428]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[428]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 6118540;$enc addPoint 4684990 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000087}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000087}];set olds {}
set bt [$b findBTerm {src[429]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[429]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[430]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[430]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6048140;$enc addPoint 4620990 6112140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000088}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000088}];set olds {}
set bt [$b findBTerm {src[431]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[431]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[432]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[432]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 6118540;$enc addPoint 4691390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000089}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000089}];set olds {}
set bt [$b findBTerm {src[433]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[433]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[434]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[434]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 6118540;$enc addPoint 4697790 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000090}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000090}];set olds {}
set bt [$b findBTerm {src[435]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[435]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[436]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[436]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 6118540;$enc addPoint 4710590 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000091}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000091}];set olds {}
set bt [$b findBTerm {src[437]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[437]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[438]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[438]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 6118540;$enc addPoint 4716990 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000092}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000092}];set olds {}
set bt [$b findBTerm {src[439]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[439]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[440]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[440]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6048140;$enc addPoint 4652990 6112140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000093}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000093}];set olds {}
set bt [$b findBTerm {src[441]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[441]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[442]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[442]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 6118540;$enc addPoint 4723390 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000094}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000094}];set olds {}
set bt [$b findBTerm {src[443]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[443]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[444]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[444]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6048140;$enc addPoint 4665790 6112140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000095}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000095}];set olds {}
set bt [$b findBTerm {src[445]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[445]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[446]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[446]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 6118540;$enc addPoint 4742590 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000096}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000096}];set olds {}
set bt [$b findBTerm {src[447]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[447]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[448]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[448]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 6118540;$enc addPoint 4748990 6182540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000097}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000097}];set olds {}
set bt [$b findBTerm {src[449]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[449]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[450]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[450]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 6310540;$enc addPoint 4480190 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000098}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000098}];set olds {}
set bt [$b findBTerm {src[451]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[451]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[452]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[452]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 6310540;$enc addPoint 4486590 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000099}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000099}];set olds {}
set bt [$b findBTerm {src[453]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[453]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[454]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[454]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 6310540;$enc addPoint 4499390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000100}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000100}];set olds {}
set bt [$b findBTerm {src[455]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[455]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[456]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[456]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 6310540;$enc addPoint 4505790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000101}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000101}];set olds {}
set bt [$b findBTerm {src[457]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[457]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[458]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[458]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 6310540;$enc addPoint 4512190 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000102}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000102}];set olds {}
set bt [$b findBTerm {src[459]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[459]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[460]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[460]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 6310540;$enc addPoint 4518590 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000103}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000103}];set olds {}
set bt [$b findBTerm {src[461]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[461]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[462]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[462]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 6310540;$enc addPoint 4531390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000104}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000104}];set olds {}
set bt [$b findBTerm {src[463]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[463]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[464]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[464]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 6310540;$enc addPoint 4537790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000105}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000105}];set olds {}
set bt [$b findBTerm {src[465]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[465]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[466]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[466]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 6310540;$enc addPoint 4544190 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000106}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000106}];set olds {}
set bt [$b findBTerm {src[467]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[467]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[468]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[468]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 6310540;$enc addPoint 4563390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000107}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000107}];set olds {}
set bt [$b findBTerm {src[469]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[469]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[470]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[470]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 6310540;$enc addPoint 4569790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000108}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000108}];set olds {}
set bt [$b findBTerm {src[471]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[471]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[472]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[472]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 6310540;$enc addPoint 4576190 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000109}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000109}];set olds {}
set bt [$b findBTerm {src[473]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[473]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[474]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[474]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 6310540;$enc addPoint 4595390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000110}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000110}];set olds {}
set bt [$b findBTerm {src[475]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[475]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[476]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[476]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 6310540;$enc addPoint 4601790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000111}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000111}];set olds {}
set bt [$b findBTerm {src[477]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[477]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[478]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[478]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 6310540;$enc addPoint 4608190 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000112}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000112}];set olds {}
set bt [$b findBTerm {src[479]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[479]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[480]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[480]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6310540;$enc addPoint 4620990 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000113}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000113}];set olds {}
set bt [$b findBTerm {src[481]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[481]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[482]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[482]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 6310540;$enc addPoint 4627390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000114}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000114}];set olds {}
set bt [$b findBTerm {src[483]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[483]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[484]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[484]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 6310540;$enc addPoint 4633790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000115}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000115}];set olds {}
set bt [$b findBTerm {src[485]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[485]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[486]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[486]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6310540;$enc addPoint 4652990 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000116}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000116}];set olds {}
set bt [$b findBTerm {src[487]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[487]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[488]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[488]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 6310540;$enc addPoint 4659390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000117}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000117}];set olds {}
set bt [$b findBTerm {src[489]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[489]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[490]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[490]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6310540;$enc addPoint 4665790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000118}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000118}];set olds {}
set bt [$b findBTerm {src[491]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[491]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[492]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[492]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 6310540;$enc addPoint 4684990 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000119}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000119}];set olds {}
set bt [$b findBTerm {src[493]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[493]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[494]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[494]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6240140;$enc addPoint 4620990 6304140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000120}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000120}];set olds {}
set bt [$b findBTerm {src[495]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[495]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[496]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[496]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 6310540;$enc addPoint 4691390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000121}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000121}];set olds {}
set bt [$b findBTerm {src[497]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[497]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[498]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[498]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 6310540;$enc addPoint 4697790 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000122}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000122}];set olds {}
set bt [$b findBTerm {src[499]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[499]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[500]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[500]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 6310540;$enc addPoint 4710590 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000123}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000123}];set olds {}
set bt [$b findBTerm {src[501]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[501]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[502]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[502]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 6310540;$enc addPoint 4716990 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000124}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000124}];set olds {}
set bt [$b findBTerm {src[503]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[503]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[504]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[504]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6240140;$enc addPoint 4652990 6304140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000125}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000125}];set olds {}
set bt [$b findBTerm {src[505]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[505]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[506]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[506]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 6310540;$enc addPoint 4723390 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000126}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000126}];set olds {}
set bt [$b findBTerm {src[507]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[507]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[508]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[508]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6240140;$enc addPoint 4665790 6304140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000127}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000127}];set olds {}
set bt [$b findBTerm {src[509]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[509]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[510]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[510]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 6310540;$enc addPoint 4742590 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000128}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000128}];set olds {}
set bt [$b findBTerm {src[511]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[511]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[512]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[512]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 6310540;$enc addPoint 4748990 6374540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000129}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000129}];set olds {}
set bt [$b findBTerm {src[513]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[513]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[514]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[514]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 6502540;$enc addPoint 4480190 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000130}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000130}];set olds {}
set bt [$b findBTerm {src[515]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[515]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[516]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[516]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 6502540;$enc addPoint 4486590 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000131}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000131}];set olds {}
set bt [$b findBTerm {src[517]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[517]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[518]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[518]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 6502540;$enc addPoint 4499390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000132}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000132}];set olds {}
set bt [$b findBTerm {src[519]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[519]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[520]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[520]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 6502540;$enc addPoint 4505790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000133}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000133}];set olds {}
set bt [$b findBTerm {src[521]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[521]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[522]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[522]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 6502540;$enc addPoint 4512190 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000134}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000134}];set olds {}
set bt [$b findBTerm {src[523]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[523]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[524]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[524]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 6502540;$enc addPoint 4518590 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000135}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000135}];set olds {}
set bt [$b findBTerm {src[525]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[525]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[526]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[526]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 6502540;$enc addPoint 4531390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000136}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000136}];set olds {}
set bt [$b findBTerm {src[527]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[527]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[528]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[528]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 6502540;$enc addPoint 4537790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000137}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000137}];set olds {}
set bt [$b findBTerm {src[529]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[529]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[530]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[530]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 6502540;$enc addPoint 4544190 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000138}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000138}];set olds {}
set bt [$b findBTerm {src[531]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[531]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[532]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[532]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 6502540;$enc addPoint 4563390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000139}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000139}];set olds {}
set bt [$b findBTerm {src[533]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[533]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[534]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[534]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 6502540;$enc addPoint 4569790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000140}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000140}];set olds {}
set bt [$b findBTerm {src[535]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[535]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[536]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[536]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 6502540;$enc addPoint 4576190 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000141}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000141}];set olds {}
set bt [$b findBTerm {src[537]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[537]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[538]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[538]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 6502540;$enc addPoint 4595390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000142}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000142}];set olds {}
set bt [$b findBTerm {src[539]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[539]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[540]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[540]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 6502540;$enc addPoint 4601790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000143}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000143}];set olds {}
set bt [$b findBTerm {src[541]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[541]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[542]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[542]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 6502540;$enc addPoint 4608190 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000144}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000144}];set olds {}
set bt [$b findBTerm {src[543]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[543]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[544]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[544]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6502540;$enc addPoint 4620990 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000145}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000145}];set olds {}
set bt [$b findBTerm {src[545]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[545]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[546]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[546]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 6502540;$enc addPoint 4627390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000146}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000146}];set olds {}
set bt [$b findBTerm {src[547]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[547]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[548]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[548]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 6502540;$enc addPoint 4633790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000147}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000147}];set olds {}
set bt [$b findBTerm {src[549]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[549]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[550]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[550]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6502540;$enc addPoint 4652990 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000148}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000148}];set olds {}
set bt [$b findBTerm {src[551]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[551]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[552]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[552]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 6502540;$enc addPoint 4659390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000149}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000149}];set olds {}
set bt [$b findBTerm {src[553]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[553]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[554]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[554]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6502540;$enc addPoint 4665790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000150}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000150}];set olds {}
set bt [$b findBTerm {src[555]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[555]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[556]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[556]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 6502540;$enc addPoint 4684990 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000151}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000151}];set olds {}
set bt [$b findBTerm {src[557]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[557]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[558]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[558]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6432140;$enc addPoint 4620990 6496140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000152}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000152}];set olds {}
set bt [$b findBTerm {src[559]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[559]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[560]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[560]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 6502540;$enc addPoint 4691390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000153}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000153}];set olds {}
set bt [$b findBTerm {src[561]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[561]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[562]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[562]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 6502540;$enc addPoint 4697790 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000154}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000154}];set olds {}
set bt [$b findBTerm {src[563]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[563]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[564]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[564]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 6502540;$enc addPoint 4710590 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000155}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000155}];set olds {}
set bt [$b findBTerm {src[565]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[565]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[566]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[566]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 6502540;$enc addPoint 4716990 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000156}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000156}];set olds {}
set bt [$b findBTerm {src[567]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[567]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[568]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[568]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6432140;$enc addPoint 4652990 6496140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000157}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000157}];set olds {}
set bt [$b findBTerm {src[569]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[569]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[570]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[570]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 6502540;$enc addPoint 4723390 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000158}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000158}];set olds {}
set bt [$b findBTerm {src[571]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[571]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[572]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[572]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6432140;$enc addPoint 4665790 6496140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000159}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000159}];set olds {}
set bt [$b findBTerm {src[573]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[573]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[574]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[574]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 6502540;$enc addPoint 4742590 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000160}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000160}];set olds {}
set bt [$b findBTerm {src[575]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[575]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[576]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[576]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 6502540;$enc addPoint 4748990 6566540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000161}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000161}];set olds {}
set bt [$b findBTerm {src[577]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[577]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[578]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[578]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 6694540;$enc addPoint 4480190 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000162}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000162}];set olds {}
set bt [$b findBTerm {src[579]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[579]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[580]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[580]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 6694540;$enc addPoint 4486590 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000163}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000163}];set olds {}
set bt [$b findBTerm {src[581]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[581]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[582]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[582]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 6694540;$enc addPoint 4499390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000164}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000164}];set olds {}
set bt [$b findBTerm {src[583]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[583]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[584]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[584]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 6694540;$enc addPoint 4505790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000165}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000165}];set olds {}
set bt [$b findBTerm {src[585]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[585]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[586]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[586]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 6694540;$enc addPoint 4512190 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000166}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000166}];set olds {}
set bt [$b findBTerm {src[587]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[587]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[588]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[588]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 6694540;$enc addPoint 4518590 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000167}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000167}];set olds {}
set bt [$b findBTerm {src[589]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[589]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[590]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[590]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 6694540;$enc addPoint 4531390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000168}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000168}];set olds {}
set bt [$b findBTerm {src[591]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[591]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[592]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[592]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 6694540;$enc addPoint 4537790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000169}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000169}];set olds {}
set bt [$b findBTerm {src[593]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[593]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[594]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[594]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 6694540;$enc addPoint 4544190 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000170}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000170}];set olds {}
set bt [$b findBTerm {src[595]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[595]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[596]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[596]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 6694540;$enc addPoint 4563390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000171}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000171}];set olds {}
set bt [$b findBTerm {src[597]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[597]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[598]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[598]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 6694540;$enc addPoint 4569790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000172}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000172}];set olds {}
set bt [$b findBTerm {src[599]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[599]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[600]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[600]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 6694540;$enc addPoint 4576190 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000173}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000173}];set olds {}
set bt [$b findBTerm {src[601]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[601]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[602]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[602]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 6694540;$enc addPoint 4595390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000174}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000174}];set olds {}
set bt [$b findBTerm {src[603]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[603]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[604]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[604]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 6694540;$enc addPoint 4601790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000175}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000175}];set olds {}
set bt [$b findBTerm {src[605]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[605]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[606]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[606]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 6694540;$enc addPoint 4608190 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000176}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000176}];set olds {}
set bt [$b findBTerm {src[607]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[607]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[608]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[608]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6694540;$enc addPoint 4620990 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000177}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000177}];set olds {}
set bt [$b findBTerm {src[609]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[609]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[610]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[610]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 6694540;$enc addPoint 4627390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000178}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000178}];set olds {}
set bt [$b findBTerm {src[611]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[611]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[612]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[612]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 6694540;$enc addPoint 4633790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000179}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000179}];set olds {}
set bt [$b findBTerm {src[613]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[613]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[614]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[614]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6694540;$enc addPoint 4652990 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000180}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000180}];set olds {}
set bt [$b findBTerm {src[615]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[615]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[616]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[616]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 6694540;$enc addPoint 4659390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000181}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000181}];set olds {}
set bt [$b findBTerm {src[617]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[617]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[618]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[618]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6694540;$enc addPoint 4665790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000182}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000182}];set olds {}
set bt [$b findBTerm {src[619]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[619]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[620]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[620]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 6694540;$enc addPoint 4684990 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000183}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000183}];set olds {}
set bt [$b findBTerm {src[621]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[621]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[622]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[622]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6624140;$enc addPoint 4620990 6688140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000184}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000184}];set olds {}
set bt [$b findBTerm {src[623]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[623]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[624]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[624]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 6694540;$enc addPoint 4691390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000185}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000185}];set olds {}
set bt [$b findBTerm {src[625]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[625]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[626]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[626]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 6694540;$enc addPoint 4697790 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000186}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000186}];set olds {}
set bt [$b findBTerm {src[627]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[627]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[628]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[628]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 6694540;$enc addPoint 4710590 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000187}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000187}];set olds {}
set bt [$b findBTerm {src[629]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[629]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[630]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[630]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 6694540;$enc addPoint 4716990 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000188}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000188}];set olds {}
set bt [$b findBTerm {src[631]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[631]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[632]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[632]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6624140;$enc addPoint 4652990 6688140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000189}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000189}];set olds {}
set bt [$b findBTerm {src[633]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[633]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[634]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[634]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 6694540;$enc addPoint 4723390 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000190}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000190}];set olds {}
set bt [$b findBTerm {src[635]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[635]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[636]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[636]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6624140;$enc addPoint 4665790 6688140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000191}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000191}];set olds {}
set bt [$b findBTerm {src[637]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[637]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[638]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[638]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 6694540;$enc addPoint 4742590 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000192}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000192}];set olds {}
set bt [$b findBTerm {src[639]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[639]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[640]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[640]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 6694540;$enc addPoint 4748990 6758540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000193}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000193}];set olds {}
set bt [$b findBTerm {src[641]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[641]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[642]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[642]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 6886540;$enc addPoint 4480190 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000194}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000194}];set olds {}
set bt [$b findBTerm {src[643]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[643]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[644]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[644]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 6886540;$enc addPoint 4486590 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000195}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000195}];set olds {}
set bt [$b findBTerm {src[645]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[645]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[646]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[646]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 6886540;$enc addPoint 4499390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000196}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000196}];set olds {}
set bt [$b findBTerm {src[647]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[647]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[648]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[648]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 6886540;$enc addPoint 4505790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000197}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000197}];set olds {}
set bt [$b findBTerm {src[649]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[649]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[650]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[650]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 6886540;$enc addPoint 4512190 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000198}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000198}];set olds {}
set bt [$b findBTerm {src[651]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[651]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[652]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[652]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 6886540;$enc addPoint 4518590 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000199}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000199}];set olds {}
set bt [$b findBTerm {src[653]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[653]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[654]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[654]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 6886540;$enc addPoint 4531390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000200}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000200}];set olds {}
set bt [$b findBTerm {src[655]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[655]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[656]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[656]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 6886540;$enc addPoint 4537790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000201}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000201}];set olds {}
set bt [$b findBTerm {src[657]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[657]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[658]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[658]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 6886540;$enc addPoint 4544190 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000202}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000202}];set olds {}
set bt [$b findBTerm {src[659]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[659]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[660]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[660]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 6886540;$enc addPoint 4563390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000203}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000203}];set olds {}
set bt [$b findBTerm {src[661]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[661]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[662]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[662]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 6886540;$enc addPoint 4569790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000204}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000204}];set olds {}
set bt [$b findBTerm {src[663]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[663]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[664]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[664]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 6886540;$enc addPoint 4576190 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000205}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000205}];set olds {}
set bt [$b findBTerm {src[665]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[665]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[666]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[666]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 6886540;$enc addPoint 4595390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000206}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000206}];set olds {}
set bt [$b findBTerm {src[667]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[667]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[668]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[668]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 6886540;$enc addPoint 4601790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000207}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000207}];set olds {}
set bt [$b findBTerm {src[669]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[669]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[670]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[670]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 6886540;$enc addPoint 4608190 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000208}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000208}];set olds {}
set bt [$b findBTerm {src[671]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[671]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[672]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[672]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6886540;$enc addPoint 4620990 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000209}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000209}];set olds {}
set bt [$b findBTerm {src[673]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[673]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[674]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[674]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 6886540;$enc addPoint 4627390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000210}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000210}];set olds {}
set bt [$b findBTerm {src[675]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[675]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[676]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[676]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 6886540;$enc addPoint 4633790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000211}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000211}];set olds {}
set bt [$b findBTerm {src[677]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[677]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[678]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[678]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6886540;$enc addPoint 4652990 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000212}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000212}];set olds {}
set bt [$b findBTerm {src[679]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[679]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[680]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[680]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 6886540;$enc addPoint 4659390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000213}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000213}];set olds {}
set bt [$b findBTerm {src[681]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[681]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[682]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[682]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6886540;$enc addPoint 4665790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000214}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000214}];set olds {}
set bt [$b findBTerm {src[683]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[683]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[684]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[684]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 6886540;$enc addPoint 4684990 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000215}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000215}];set olds {}
set bt [$b findBTerm {src[685]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[685]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[686]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[686]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 6816140;$enc addPoint 4620990 6880140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000216}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000216}];set olds {}
set bt [$b findBTerm {src[687]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[687]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[688]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[688]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 6886540;$enc addPoint 4691390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000217}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000217}];set olds {}
set bt [$b findBTerm {src[689]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[689]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[690]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[690]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 6886540;$enc addPoint 4697790 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000218}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000218}];set olds {}
set bt [$b findBTerm {src[691]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[691]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[692]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[692]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 6886540;$enc addPoint 4710590 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000219}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000219}];set olds {}
set bt [$b findBTerm {src[693]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[693]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[694]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[694]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 6886540;$enc addPoint 4716990 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000220}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000220}];set olds {}
set bt [$b findBTerm {src[695]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[695]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[696]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[696]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 6816140;$enc addPoint 4652990 6880140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000221}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000221}];set olds {}
set bt [$b findBTerm {src[697]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[697]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[698]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[698]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 6886540;$enc addPoint 4723390 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000222}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000222}];set olds {}
set bt [$b findBTerm {src[699]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[699]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[700]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[700]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 6816140;$enc addPoint 4665790 6880140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000223}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000223}];set olds {}
set bt [$b findBTerm {src[701]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[701]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[702]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[702]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 6886540;$enc addPoint 4742590 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000224}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000224}];set olds {}
set bt [$b findBTerm {src[703]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[703]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[704]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[704]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 6886540;$enc addPoint 4748990 6950540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000225}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000225}];set olds {}
set bt [$b findBTerm {src[705]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[705]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[706]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[706]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4480190 7078540;$enc addPoint 4480190 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000226}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000226}];set olds {}
set bt [$b findBTerm {src[707]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[707]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[708]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[708]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4486590 7078540;$enc addPoint 4486590 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000227}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000227}];set olds {}
set bt [$b findBTerm {src[709]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[709]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[710]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[710]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4499390 7078540;$enc addPoint 4499390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000228}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000228}];set olds {}
set bt [$b findBTerm {src[711]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[711]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[712]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[712]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4505790 7078540;$enc addPoint 4505790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000229}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000229}];set olds {}
set bt [$b findBTerm {src[713]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[713]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[714]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[714]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4512190 7078540;$enc addPoint 4512190 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000230}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000230}];set olds {}
set bt [$b findBTerm {src[715]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[715]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[716]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[716]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4518590 7078540;$enc addPoint 4518590 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000231}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000231}];set olds {}
set bt [$b findBTerm {src[717]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[717]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[718]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[718]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4531390 7078540;$enc addPoint 4531390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000232}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000232}];set olds {}
set bt [$b findBTerm {src[719]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[719]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[720]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[720]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4537790 7078540;$enc addPoint 4537790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000233}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000233}];set olds {}
set bt [$b findBTerm {src[721]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[721]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[722]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[722]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4544190 7078540;$enc addPoint 4544190 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000234}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000234}];set olds {}
set bt [$b findBTerm {src[723]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[723]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[724]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[724]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4563390 7078540;$enc addPoint 4563390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000235}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000235}];set olds {}
set bt [$b findBTerm {src[725]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[725]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[726]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[726]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4569790 7078540;$enc addPoint 4569790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000236}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000236}];set olds {}
set bt [$b findBTerm {src[727]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[727]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[728]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[728]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4576190 7078540;$enc addPoint 4576190 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000237}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000237}];set olds {}
set bt [$b findBTerm {src[729]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[729]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[730]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[730]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4595390 7078540;$enc addPoint 4595390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000238}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000238}];set olds {}
set bt [$b findBTerm {src[731]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[731]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[732]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[732]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4601790 7078540;$enc addPoint 4601790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000239}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000239}];set olds {}
set bt [$b findBTerm {src[733]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[733]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[734]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[734]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4608190 7078540;$enc addPoint 4608190 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000240}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000240}];set olds {}
set bt [$b findBTerm {src[735]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[735]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[736]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[736]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 7078540;$enc addPoint 4620990 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000241}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000241}];set olds {}
set bt [$b findBTerm {src[737]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[737]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[738]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[738]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4627390 7078540;$enc addPoint 4627390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000242}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000242}];set olds {}
set bt [$b findBTerm {src[739]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[739]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[740]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[740]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4633790 7078540;$enc addPoint 4633790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000243}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000243}];set olds {}
set bt [$b findBTerm {src[741]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[741]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[742]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[742]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 7078540;$enc addPoint 4652990 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000244}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000244}];set olds {}
set bt [$b findBTerm {src[743]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[743]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[744]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[744]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4659390 7078540;$enc addPoint 4659390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000245}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000245}];set olds {}
set bt [$b findBTerm {src[745]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[745]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[746]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[746]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 7078540;$enc addPoint 4665790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000246}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000246}];set olds {}
set bt [$b findBTerm {src[747]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[747]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[748]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[748]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4684990 7078540;$enc addPoint 4684990 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000247}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000247}];set olds {}
set bt [$b findBTerm {src[749]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[749]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[750]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[750]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4620990 7008140;$enc addPoint 4620990 7072140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000248}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000248}];set olds {}
set bt [$b findBTerm {src[751]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[751]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[752]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[752]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4691390 7078540;$enc addPoint 4691390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000249}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000249}];set olds {}
set bt [$b findBTerm {src[753]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[753]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[754]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[754]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4697790 7078540;$enc addPoint 4697790 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000250}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000250}];set olds {}
set bt [$b findBTerm {src[755]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[755]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[756]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[756]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4710590 7078540;$enc addPoint 4710590 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000251}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000251}];set olds {}
set bt [$b findBTerm {src[757]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[757]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[758]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[758]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4716990 7078540;$enc addPoint 4716990 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000252}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000252}];set olds {}
set bt [$b findBTerm {src[759]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[759]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[760]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[760]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4652990 7008140;$enc addPoint 4652990 7072140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000253}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000253}];set olds {}
set bt [$b findBTerm {src[761]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[761]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[762]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[762]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4723390 7078540;$enc addPoint 4723390 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000254}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000254}];set olds {}
set bt [$b findBTerm {src[763]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[763]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[764]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[764]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4665790 7008140;$enc addPoint 4665790 7072140;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000255}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000255}];set olds {}
set bt [$b findBTerm {src[765]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[765]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[766]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[766]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4742590 7078540;$enc addPoint 4742590 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {w000256}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {w000256}];set olds {}
set bt [$b findBTerm {src[767]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[767]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[768]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[768]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
set tmp [odb::dbNet_create $b HPY_FIXED_STAGING];set tw [odb::dbWire_create $tmp];set enc [odb::dbWireEncoder];$enc begin $tw;$enc newPath $m10 FIXED;$enc addPoint 4748990 7078540;$enc addPoint 4748990 7142540;$enc end;$nw append $tw;odb::dbNet_destroy $tmp
if {[$b findNet {adapter_edge_0}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_0}];set olds {}
set bt [$b findBTerm {src[0]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[0]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_1}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_1}];set olds {}
set bt [$b findBTerm {src[1]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[1]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_2}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_2}];set olds {}
set bt [$b findBTerm {src[2]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[2]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_3}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_3}];set olds {}
set bt [$b findBTerm {src[3]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[3]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_4}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_4}];set olds {}
set bt [$b findBTerm {src[4]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[4]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_5}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_5}];set olds {}
set bt [$b findBTerm {src[5]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[5]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_6}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_6}];set olds {}
set bt [$b findBTerm {src[6]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[6]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_7}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_7}];set olds {}
set bt [$b findBTerm {src[7]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[7]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_8}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_8}];set olds {}
set bt [$b findBTerm {src[8]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[8]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_9}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_9}];set olds {}
set bt [$b findBTerm {src[9]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[9]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_10}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_10}];set olds {}
set bt [$b findBTerm {src[10]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[10]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_11}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_11}];set olds {}
set bt [$b findBTerm {src[11]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[11]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_12}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_12}];set olds {}
set bt [$b findBTerm {src[12]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[12]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_13}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_13}];set olds {}
set bt [$b findBTerm {src[13]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[13]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_14}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_14}];set olds {}
set bt [$b findBTerm {src[14]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[14]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_15}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_15}];set olds {}
set bt [$b findBTerm {src[15]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[15]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_16}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_16}];set olds {}
set bt [$b findBTerm {src[16]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[16]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_17}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_17}];set olds {}
set bt [$b findBTerm {src[17]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[17]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_18}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_18}];set olds {}
set bt [$b findBTerm {src[18]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[18]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_19}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_19}];set olds {}
set bt [$b findBTerm {src[19]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[19]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_20}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_20}];set olds {}
set bt [$b findBTerm {src[20]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[20]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_21}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_21}];set olds {}
set bt [$b findBTerm {src[21]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[21]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_22}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_22}];set olds {}
set bt [$b findBTerm {src[22]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[22]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_23}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_23}];set olds {}
set bt [$b findBTerm {src[23]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[23]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_24}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_24}];set olds {}
set bt [$b findBTerm {src[24]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[24]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_25}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_25}];set olds {}
set bt [$b findBTerm {src[25]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[25]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_26}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_26}];set olds {}
set bt [$b findBTerm {src[26]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[26]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_27}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_27}];set olds {}
set bt [$b findBTerm {src[27]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[27]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_28}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_28}];set olds {}
set bt [$b findBTerm {src[28]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[28]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_29}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_29}];set olds {}
set bt [$b findBTerm {src[29]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[29]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_30}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_30}];set olds {}
set bt [$b findBTerm {src[30]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[30]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_31}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_31}];set olds {}
set bt [$b findBTerm {src[31]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[31]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_32}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_32}];set olds {}
set bt [$b findBTerm {src[32]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[32]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_33}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_33}];set olds {}
set bt [$b findBTerm {src[33]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[33]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_34}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_34}];set olds {}
set bt [$b findBTerm {src[34]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[34]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_35}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_35}];set olds {}
set bt [$b findBTerm {src[35]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[35]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_36}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_36}];set olds {}
set bt [$b findBTerm {src[36]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[36]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_37}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_37}];set olds {}
set bt [$b findBTerm {src[37]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[37]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_38}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_38}];set olds {}
set bt [$b findBTerm {src[38]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[38]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_39}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_39}];set olds {}
set bt [$b findBTerm {src[39]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[39]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_40}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_40}];set olds {}
set bt [$b findBTerm {src[40]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[40]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_41}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_41}];set olds {}
set bt [$b findBTerm {src[41]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[41]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_42}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_42}];set olds {}
set bt [$b findBTerm {src[42]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[42]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_43}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_43}];set olds {}
set bt [$b findBTerm {src[43]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[43]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_44}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_44}];set olds {}
set bt [$b findBTerm {src[44]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[44]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_45}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_45}];set olds {}
set bt [$b findBTerm {src[45]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[45]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_46}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_46}];set olds {}
set bt [$b findBTerm {src[46]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[46]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_47}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_47}];set olds {}
set bt [$b findBTerm {src[47]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[47]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_48}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_48}];set olds {}
set bt [$b findBTerm {src[48]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[48]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_49}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_49}];set olds {}
set bt [$b findBTerm {src[49]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[49]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_50}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_50}];set olds {}
set bt [$b findBTerm {src[50]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[50]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_51}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_51}];set olds {}
set bt [$b findBTerm {src[51]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[51]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_52}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_52}];set olds {}
set bt [$b findBTerm {src[52]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[52]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_53}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_53}];set olds {}
set bt [$b findBTerm {src[53]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[53]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_54}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_54}];set olds {}
set bt [$b findBTerm {src[54]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[54]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_55}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_55}];set olds {}
set bt [$b findBTerm {src[55]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[55]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_56}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_56}];set olds {}
set bt [$b findBTerm {src[56]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[56]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_57}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_57}];set olds {}
set bt [$b findBTerm {src[57]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[57]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_58}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_58}];set olds {}
set bt [$b findBTerm {src[58]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[58]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_59}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_59}];set olds {}
set bt [$b findBTerm {src[59]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[59]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_60}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_60}];set olds {}
set bt [$b findBTerm {src[60]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[60]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_61}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_61}];set olds {}
set bt [$b findBTerm {src[61]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[61]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_62}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_62}];set olds {}
set bt [$b findBTerm {src[62]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[62]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_63}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_63}];set olds {}
set bt [$b findBTerm {src[63]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[63]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_64}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_64}];set olds {}
set bt [$b findBTerm {src[64]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[64]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_65}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_65}];set olds {}
set bt [$b findBTerm {src[65]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[65]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_66}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_66}];set olds {}
set bt [$b findBTerm {src[66]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[66]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_67}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_67}];set olds {}
set bt [$b findBTerm {src[67]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[67]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_68}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_68}];set olds {}
set bt [$b findBTerm {src[68]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[68]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_69}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_69}];set olds {}
set bt [$b findBTerm {src[69]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[69]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_70}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_70}];set olds {}
set bt [$b findBTerm {src[70]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[70]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_71}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_71}];set olds {}
set bt [$b findBTerm {src[71]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[71]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_72}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_72}];set olds {}
set bt [$b findBTerm {src[72]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[72]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_73}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_73}];set olds {}
set bt [$b findBTerm {src[73]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[73]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_74}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_74}];set olds {}
set bt [$b findBTerm {src[74]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[74]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_75}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_75}];set olds {}
set bt [$b findBTerm {src[75]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[75]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_76}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_76}];set olds {}
set bt [$b findBTerm {src[76]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[76]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_77}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_77}];set olds {}
set bt [$b findBTerm {src[77]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[77]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_78}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_78}];set olds {}
set bt [$b findBTerm {src[78]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[78]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_79}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_79}];set olds {}
set bt [$b findBTerm {src[79]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[79]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_80}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_80}];set olds {}
set bt [$b findBTerm {src[80]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[80]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_81}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_81}];set olds {}
set bt [$b findBTerm {src[81]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[81]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_82}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_82}];set olds {}
set bt [$b findBTerm {src[82]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[82]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_83}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_83}];set olds {}
set bt [$b findBTerm {src[83]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[83]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_84}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_84}];set olds {}
set bt [$b findBTerm {src[84]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[84]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_85}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_85}];set olds {}
set bt [$b findBTerm {src[85]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[85]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_86}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_86}];set olds {}
set bt [$b findBTerm {src[86]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[86]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_87}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_87}];set olds {}
set bt [$b findBTerm {src[87]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[87]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_88}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_88}];set olds {}
set bt [$b findBTerm {src[88]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[88]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_89}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_89}];set olds {}
set bt [$b findBTerm {src[89]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[89]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_90}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_90}];set olds {}
set bt [$b findBTerm {src[90]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[90]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_91}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_91}];set olds {}
set bt [$b findBTerm {src[91]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[91]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_92}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_92}];set olds {}
set bt [$b findBTerm {src[92]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[92]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_93}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_93}];set olds {}
set bt [$b findBTerm {src[93]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[93]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_94}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_94}];set olds {}
set bt [$b findBTerm {src[94]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[94]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_95}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_95}];set olds {}
set bt [$b findBTerm {src[95]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[95]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_96}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_96}];set olds {}
set bt [$b findBTerm {src[96]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[96]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_97}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_97}];set olds {}
set bt [$b findBTerm {src[97]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[97]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_98}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_98}];set olds {}
set bt [$b findBTerm {src[98]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[98]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_99}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_99}];set olds {}
set bt [$b findBTerm {src[99]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[99]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_100}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_100}];set olds {}
set bt [$b findBTerm {src[100]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[100]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_101}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_101}];set olds {}
set bt [$b findBTerm {src[101]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[101]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_102}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_102}];set olds {}
set bt [$b findBTerm {src[102]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[102]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_103}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_103}];set olds {}
set bt [$b findBTerm {src[103]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[103]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_104}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_104}];set olds {}
set bt [$b findBTerm {src[104]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[104]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_105}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_105}];set olds {}
set bt [$b findBTerm {src[105]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[105]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_106}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_106}];set olds {}
set bt [$b findBTerm {src[106]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[106]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_107}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_107}];set olds {}
set bt [$b findBTerm {src[107]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[107]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_108}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_108}];set olds {}
set bt [$b findBTerm {src[108]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[108]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_109}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_109}];set olds {}
set bt [$b findBTerm {src[109]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[109]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_110}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_110}];set olds {}
set bt [$b findBTerm {src[110]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[110]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_111}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_111}];set olds {}
set bt [$b findBTerm {src[111]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[111]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_112}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_112}];set olds {}
set bt [$b findBTerm {src[112]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[112]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_113}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_113}];set olds {}
set bt [$b findBTerm {src[113]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[113]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_114}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_114}];set olds {}
set bt [$b findBTerm {src[114]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[114]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_115}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_115}];set olds {}
set bt [$b findBTerm {src[115]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[115]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_116}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_116}];set olds {}
set bt [$b findBTerm {src[116]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[116]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_117}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_117}];set olds {}
set bt [$b findBTerm {src[117]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[117]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_118}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_118}];set olds {}
set bt [$b findBTerm {src[118]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[118]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_119}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_119}];set olds {}
set bt [$b findBTerm {src[119]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[119]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_120}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_120}];set olds {}
set bt [$b findBTerm {src[120]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[120]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_121}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_121}];set olds {}
set bt [$b findBTerm {src[121]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[121]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_122}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_122}];set olds {}
set bt [$b findBTerm {src[122]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[122]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_123}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_123}];set olds {}
set bt [$b findBTerm {src[123]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[123]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_124}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_124}];set olds {}
set bt [$b findBTerm {src[124]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[124]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_125}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_125}];set olds {}
set bt [$b findBTerm {src[125]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[125]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_126}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_126}];set olds {}
set bt [$b findBTerm {src[126]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[126]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_127}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_127}];set olds {}
set bt [$b findBTerm {src[127]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[127]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_128}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_128}];set olds {}
set bt [$b findBTerm {src[128]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[128]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_129}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_129}];set olds {}
set bt [$b findBTerm {src[129]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[129]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_130}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_130}];set olds {}
set bt [$b findBTerm {src[130]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[130]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_131}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_131}];set olds {}
set bt [$b findBTerm {src[131]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[131]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_132}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_132}];set olds {}
set bt [$b findBTerm {src[132]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[132]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_133}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_133}];set olds {}
set bt [$b findBTerm {src[133]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[133]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_134}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_134}];set olds {}
set bt [$b findBTerm {src[134]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[134]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_135}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_135}];set olds {}
set bt [$b findBTerm {src[135]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[135]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_136}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_136}];set olds {}
set bt [$b findBTerm {src[136]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[136]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_137}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_137}];set olds {}
set bt [$b findBTerm {src[137]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[137]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_138}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_138}];set olds {}
set bt [$b findBTerm {src[138]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[138]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_139}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_139}];set olds {}
set bt [$b findBTerm {src[139]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[139]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_140}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_140}];set olds {}
set bt [$b findBTerm {src[140]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[140]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_141}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_141}];set olds {}
set bt [$b findBTerm {src[141]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[141]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_142}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_142}];set olds {}
set bt [$b findBTerm {src[142]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[142]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_143}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_143}];set olds {}
set bt [$b findBTerm {src[143]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[143]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_144}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_144}];set olds {}
set bt [$b findBTerm {src[144]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[144]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_145}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_145}];set olds {}
set bt [$b findBTerm {src[145]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[145]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_146}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_146}];set olds {}
set bt [$b findBTerm {src[146]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[146]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_147}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_147}];set olds {}
set bt [$b findBTerm {src[147]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[147]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_148}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_148}];set olds {}
set bt [$b findBTerm {src[148]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[148]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_149}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_149}];set olds {}
set bt [$b findBTerm {src[149]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[149]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_150}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_150}];set olds {}
set bt [$b findBTerm {src[150]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[150]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_151}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_151}];set olds {}
set bt [$b findBTerm {src[151]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[151]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_152}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_152}];set olds {}
set bt [$b findBTerm {src[152]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[152]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_153}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_153}];set olds {}
set bt [$b findBTerm {src[153]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[153]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_154}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_154}];set olds {}
set bt [$b findBTerm {src[154]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[154]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_155}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_155}];set olds {}
set bt [$b findBTerm {src[155]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[155]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_156}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_156}];set olds {}
set bt [$b findBTerm {src[156]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[156]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_157}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_157}];set olds {}
set bt [$b findBTerm {src[157]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[157]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_158}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_158}];set olds {}
set bt [$b findBTerm {src[158]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[158]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_159}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_159}];set olds {}
set bt [$b findBTerm {src[159]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[159]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_160}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_160}];set olds {}
set bt [$b findBTerm {src[160]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[160]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_161}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_161}];set olds {}
set bt [$b findBTerm {src[161]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[161]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_162}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_162}];set olds {}
set bt [$b findBTerm {src[162]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[162]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_163}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_163}];set olds {}
set bt [$b findBTerm {src[163]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[163]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_164}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_164}];set olds {}
set bt [$b findBTerm {src[164]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[164]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_165}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_165}];set olds {}
set bt [$b findBTerm {src[165]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[165]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_166}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_166}];set olds {}
set bt [$b findBTerm {src[166]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[166]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_167}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_167}];set olds {}
set bt [$b findBTerm {src[167]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[167]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_168}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_168}];set olds {}
set bt [$b findBTerm {src[168]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[168]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_169}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_169}];set olds {}
set bt [$b findBTerm {src[169]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[169]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_170}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_170}];set olds {}
set bt [$b findBTerm {src[170]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[170]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_171}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_171}];set olds {}
set bt [$b findBTerm {src[171]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[171]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_172}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_172}];set olds {}
set bt [$b findBTerm {src[172]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[172]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_173}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_173}];set olds {}
set bt [$b findBTerm {src[173]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[173]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_174}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_174}];set olds {}
set bt [$b findBTerm {src[174]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[174]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_175}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_175}];set olds {}
set bt [$b findBTerm {src[175]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[175]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_176}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_176}];set olds {}
set bt [$b findBTerm {src[176]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[176]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_177}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_177}];set olds {}
set bt [$b findBTerm {src[177]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[177]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_178}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_178}];set olds {}
set bt [$b findBTerm {src[178]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[178]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_179}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_179}];set olds {}
set bt [$b findBTerm {src[179]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[179]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_180}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_180}];set olds {}
set bt [$b findBTerm {src[180]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[180]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_181}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_181}];set olds {}
set bt [$b findBTerm {src[181]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[181]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_182}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_182}];set olds {}
set bt [$b findBTerm {src[182]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[182]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_183}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_183}];set olds {}
set bt [$b findBTerm {src[183]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[183]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_184}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_184}];set olds {}
set bt [$b findBTerm {src[184]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[184]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_185}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_185}];set olds {}
set bt [$b findBTerm {src[185]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[185]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_186}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_186}];set olds {}
set bt [$b findBTerm {src[186]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[186]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_187}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_187}];set olds {}
set bt [$b findBTerm {src[187]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[187]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_188}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_188}];set olds {}
set bt [$b findBTerm {src[188]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[188]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_189}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_189}];set olds {}
set bt [$b findBTerm {src[189]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[189]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_190}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_190}];set olds {}
set bt [$b findBTerm {src[190]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[190]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_191}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_191}];set olds {}
set bt [$b findBTerm {src[191]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[191]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_192}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_192}];set olds {}
set bt [$b findBTerm {src[192]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[192]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_193}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_193}];set olds {}
set bt [$b findBTerm {src[193]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[193]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_194}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_194}];set olds {}
set bt [$b findBTerm {src[194]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[194]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_195}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_195}];set olds {}
set bt [$b findBTerm {src[195]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[195]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_196}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_196}];set olds {}
set bt [$b findBTerm {src[196]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[196]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_197}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_197}];set olds {}
set bt [$b findBTerm {src[197]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[197]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_198}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_198}];set olds {}
set bt [$b findBTerm {src[198]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[198]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_199}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_199}];set olds {}
set bt [$b findBTerm {src[199]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[199]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_200}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_200}];set olds {}
set bt [$b findBTerm {src[200]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[200]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_201}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_201}];set olds {}
set bt [$b findBTerm {src[201]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[201]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_202}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_202}];set olds {}
set bt [$b findBTerm {src[202]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[202]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_203}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_203}];set olds {}
set bt [$b findBTerm {src[203]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[203]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_204}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_204}];set olds {}
set bt [$b findBTerm {src[204]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[204]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_205}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_205}];set olds {}
set bt [$b findBTerm {src[205]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[205]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_206}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_206}];set olds {}
set bt [$b findBTerm {src[206]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[206]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_207}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_207}];set olds {}
set bt [$b findBTerm {src[207]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[207]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_208}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_208}];set olds {}
set bt [$b findBTerm {src[208]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[208]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_209}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_209}];set olds {}
set bt [$b findBTerm {src[209]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[209]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_210}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_210}];set olds {}
set bt [$b findBTerm {src[210]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[210]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_211}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_211}];set olds {}
set bt [$b findBTerm {src[211]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[211]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_212}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_212}];set olds {}
set bt [$b findBTerm {src[212]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[212]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_213}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_213}];set olds {}
set bt [$b findBTerm {src[213]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[213]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_214}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_214}];set olds {}
set bt [$b findBTerm {src[214]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[214]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_215}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_215}];set olds {}
set bt [$b findBTerm {src[215]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[215]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_216}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_216}];set olds {}
set bt [$b findBTerm {src[216]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[216]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_217}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_217}];set olds {}
set bt [$b findBTerm {src[217]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[217]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_218}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_218}];set olds {}
set bt [$b findBTerm {src[218]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[218]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_219}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_219}];set olds {}
set bt [$b findBTerm {src[219]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[219]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_220}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_220}];set olds {}
set bt [$b findBTerm {src[220]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[220]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_221}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_221}];set olds {}
set bt [$b findBTerm {src[221]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[221]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_222}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_222}];set olds {}
set bt [$b findBTerm {src[222]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[222]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_223}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_223}];set olds {}
set bt [$b findBTerm {src[223]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[223]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_224}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_224}];set olds {}
set bt [$b findBTerm {src[224]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[224]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_225}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_225}];set olds {}
set bt [$b findBTerm {src[225]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[225]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_226}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_226}];set olds {}
set bt [$b findBTerm {src[226]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[226]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_227}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_227}];set olds {}
set bt [$b findBTerm {src[227]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[227]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_228}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_228}];set olds {}
set bt [$b findBTerm {src[228]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[228]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_229}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_229}];set olds {}
set bt [$b findBTerm {src[229]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[229]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_230}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_230}];set olds {}
set bt [$b findBTerm {src[230]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[230]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_231}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_231}];set olds {}
set bt [$b findBTerm {src[231]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[231]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_232}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_232}];set olds {}
set bt [$b findBTerm {src[232]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[232]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_233}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_233}];set olds {}
set bt [$b findBTerm {src[233]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[233]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_234}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_234}];set olds {}
set bt [$b findBTerm {src[234]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[234]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_235}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_235}];set olds {}
set bt [$b findBTerm {src[235]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[235]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_236}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_236}];set olds {}
set bt [$b findBTerm {src[236]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[236]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_237}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_237}];set olds {}
set bt [$b findBTerm {src[237]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[237]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_238}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_238}];set olds {}
set bt [$b findBTerm {src[238]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[238]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_239}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_239}];set olds {}
set bt [$b findBTerm {src[239]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[239]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_240}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_240}];set olds {}
set bt [$b findBTerm {src[240]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[240]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_241}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_241}];set olds {}
set bt [$b findBTerm {src[241]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[241]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_242}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_242}];set olds {}
set bt [$b findBTerm {src[242]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[242]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_243}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_243}];set olds {}
set bt [$b findBTerm {src[243]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[243]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_244}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_244}];set olds {}
set bt [$b findBTerm {src[244]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[244]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_245}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_245}];set olds {}
set bt [$b findBTerm {src[245]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[245]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_246}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_246}];set olds {}
set bt [$b findBTerm {src[246]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[246]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_247}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_247}];set olds {}
set bt [$b findBTerm {src[247]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[247]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_248}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_248}];set olds {}
set bt [$b findBTerm {src[248]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[248]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_249}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_249}];set olds {}
set bt [$b findBTerm {src[249]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[249]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_250}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_250}];set olds {}
set bt [$b findBTerm {src[250]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[250]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_251}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_251}];set olds {}
set bt [$b findBTerm {src[251]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[251]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_252}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_252}];set olds {}
set bt [$b findBTerm {src[252]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[252]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_253}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_253}];set olds {}
set bt [$b findBTerm {src[253]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[253]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_254}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_254}];set olds {}
set bt [$b findBTerm {src[254]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[254]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_255}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_255}];set olds {}
set bt [$b findBTerm {src[255]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[255]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
if {[$b findNet {adapter_edge_256}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_256}];set olds {}
set bt [$b findBTerm {dst[256]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {src[256]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
$n setSigType CLOCK
if {[$b findNet {adapter_edge_769}] ne "NULL"} {error "Canonical net name collision"}
set n [odb::dbNet_create $b {adapter_edge_769}];set olds {}
set bt [$b findBTerm {src[769]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set bt [$b findBTerm {dst[769]}];set old [$bt getNet];if {[llength [$old getBTerms]]>2 || [llength [$old getITerms]] || [$old getWire] eq "NULL"} {error "Unexpected routed old branch"};lappend olds $old;$bt disconnect;$bt connect $n
set nw [odb::dbWire_create $n];foreach old [lsort -unique $olds] {if {[llength [$old getBTerms]] || [llength [$old getITerms]]} {error "Original branch terms not fully rebound"};$nw append [$old getWire];if {[llength [$old getBTerms]]} {error "Append changed original ownership"};odb::dbNet_destroy $old}
$n setSigType CLOCK
if {[llength [$b getNets]]!=514 || [llength [$b getBTerms]]!=1540 || [llength [$b getInsts]]} {error "Final actual graph counts wrong"}}]} {catch {write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/failed_composition.odb}};close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/after_composition}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/after_composition.OBS.tsv}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/routed_adapter_NOT_SYSTEM.odb}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/routed_adapter.def}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/upper-branches-compose-r01/code/export_access.tcl}
report_wire_length -detailed_route -summary -file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/wire_length.csv}
close $stages
