# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_adaptation_trial/r02/opentpu/failed_global.odb}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_layer_probe/r01/model/research12.setRC.tcl}
set b [ord::get_db_block];if {[llength [$b getInsts]]} {error "Unexpected FEOL instances"}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/before}
proc save_obs {file} {set f [open $file w];foreach ob [[ord::get_db_block] getObstructions] {set r [$ob getBBox];puts $f [list [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]};close $f}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/before.OBS.tsv}
if {![stage export_existing_failed_GRT_guides {set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/native_guide_inventory.tsv} w];puts $f "net\tguide_count";set count 0;foreach n [$b getNets] {set guides [$n getGuides];if {![llength $guides]} {error "Missing original DB guides"};incr count;puts $f "[$n getName]\t[llength $guides]"};close $f;if {$count!=770} {error "Not all original 770 nets"};write_guides {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/original_FAILED_GRT.guide}}]} {close $stages;exit 1}
if {[$b getDbUnitsPerMicron]!=2000} {error "Unexpected actual DBU: do not apply assumed grid phase"}
if {![stage global_route_grid_phase_half {global_route -grid_origin {2850 2850} -congestion_iterations 50 -verbose -guide_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/grid_phase_half.guide} -congestion_report_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/congestion.rpt};write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/global_grid_phase_half.odb};write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/actual_guide_grid_NOT_ROUTED.def}}]} {catch {write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/failed_grid_phase_half.odb};write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/failed_guide_grid_NOT_ROUTED.def}};close $stages;exit 1}
if {![stage detailed_route {detailed_route -output_drc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/route.drc} -verbose 1;write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/routed_adapter_NOT_SYSTEM.odb};write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/routed_adapter.def}}]} {catch {write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/failed_detail.odb}};close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/after}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/after.OBS.tsv}
stage all770_native_geometry_export {source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/physical-views-and-grid-r31/code/export_access.tcl}}
report_wire_length -detailed_route -summary -file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_grid_phase/r01/opentpu/wire_length.csv}
close $stages
