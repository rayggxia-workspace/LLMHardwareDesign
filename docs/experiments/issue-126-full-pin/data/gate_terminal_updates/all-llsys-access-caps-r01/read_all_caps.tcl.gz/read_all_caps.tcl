read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_tip_views/r01/llaccel_aux-C/clean.odb}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/all_llsys_actual_access_caps/r01/native_tracks.tcl}

set b [ord::get_db_block]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/all_llsys_actual_access_caps/r01/all13507_actual_own_via_candidates.tsv} w]
puts $f "pin\tnet\tlayer\tx0\ty0\tx1\ty1\taligned_preferred\tcandidate_x\tcandidate_y\tdistance_DBU\tvia\tcap_x0\tcap_y0\tcap_x1\tcap_y1\tstatus"
set itr [odb::dbWirePathItr];set path [odb::dbWirePath];set ps [odb::dbWirePathShape]
foreach bt [$b getBTerms] {
 if {[$bt getSigType] in {POWER GROUND}} {continue}
 set boxes {};foreach p [$bt getBPins] {foreach box [$p getBoxes] {lappend boxes $box}}
 if {[llength $boxes]!=1} {error "Current original signal pin is not exactly one rectangle"}
 set box [lindex $boxes 0];set layer [[$box getTechLayer] getName]
 if {$layer ni {metal5 metal6} || [$box xMax]-[$box xMin]!=280 || [$box yMax]-[$box yMin]!=280} {error "Original layer/size mismatch"}
 set x [expr {([$box xMin]+[$box xMax])/2}];set y [expr {([$box yMin]+[$box yMax])/2}]
 set axis [expr {$layer eq "metal5" ? "Y" : "X"}];set coord [expr {$axis eq "Y" ? $y : $x}]
 lassign [dict get $tracks ${layer}${axis}] offset pitch
 set aligned [expr {($coord-$offset)%$pitch==0}]
 set n [$bt getNet];set best {};set bd 10001
 if {!$aligned && [$n getWire] ne "NULL"} {
  $itr begin [$n getWire]
  while {[$itr getNextPath $path]} {while {[$itr getNextShape $ps]} {
   set s [odb::dbWirePathShape_shape_get $ps];if {![$s isVia]} {continue}
   set via [$s getTechVia];if {$via eq "NULL"} {set via [$s getVia]}
   lassign [$s getViaXY] vx vy;set distance [expr {abs($vx-$x)+abs($vy-$y)}]
   if {$distance>10000 || $distance>=$bd} {continue}
   lassign [dict get $tracks metal6X] xo xp;lassign [dict get $tracks metal5Y] yo yp
   if {($vx-$xo)%$xp!=0 || ($vy-$yo)%$yp!=0} {continue}
   foreach cap [$via getBoxes] {
    if {[[$cap getTechLayer] getName] ne $layer} {continue}
    if {[$cap xMin]>-140 || [$cap yMin]>-140 || [$cap xMax]<140 || [$cap yMax]<140} {continue}
    set bd $distance;set best [list $vx $vy $distance [$via getName] [expr {$vx+[$cap xMin]}] [expr {$vy+[$cap yMin]}] [expr {$vx+[$cap xMax]}] [expr {$vy+[$cap yMax]}]]
   }
  }}
 }
 if {$aligned} {set status KEEP_ALREADY_TRACK_CENTERED} elseif {[llength $best]} {set status ACTUAL_OWN_VIA_GEOMETRIC_CANDIDATE_NOT_AP_VALIDATED} else {set status KEEP_NO_BOUNDED_OWN_VIA_FOUND}
 if {![llength $best]} {set best [list {} {} {} {} {} {} {} {}]}
 puts $f [join [concat [list [$bt getName] [$n getName] $layer [$box xMin] [$box yMin] [$box xMax] [$box yMax] $aligned] $best [list $status]] "\t"]
}
close $f
puts ALL13507_NATIVE_OWN_VIA_INVENTORY_READ_ONLY_NOT_REPAIR
