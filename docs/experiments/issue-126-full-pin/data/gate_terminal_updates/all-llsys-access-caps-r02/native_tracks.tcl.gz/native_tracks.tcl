set tracks [dict create {metal5X} {190 560} {metal5Y} {140 560} {metal6X} {190 560} {metal6Y} {140 560}]
