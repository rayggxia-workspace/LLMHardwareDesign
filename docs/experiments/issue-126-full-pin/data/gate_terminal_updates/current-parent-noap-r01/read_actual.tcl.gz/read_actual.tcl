set ::env(PINXY_AUDIT_ODB) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_tip_views/r01/llaccel_aux-C/clean.odb}
set ::env(PINXY_AUDIT_PIN) {bit_1073}
set ::env(PINXY_AUDIT_BOX) {588180 943220 612460 967500}
set ::env(PINXY_AUDIT_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/current_parent_noap_context/r01/all_actual_local_metal_PG_OBS.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/current-noap-r01/audit_parent_region.tcl}
set block [ord::get_db_block]
set ::env(PINXY_ACCESS_NET_NAMES) {bit_1073}
set ::env(PINXY_ACCESS_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/current_parent_noap_context/r01/actual_error_complete_net.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/current-noap-r01/export_access.tcl}
