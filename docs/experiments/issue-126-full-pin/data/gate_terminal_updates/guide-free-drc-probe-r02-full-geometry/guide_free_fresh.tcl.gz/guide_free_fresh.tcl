read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/guide_free_DRC_probe/r02/guide_metadata_removed_NOT_QUALIFIED.odb}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/guide_free_DRC_probe/r02/guide_free.drc}
