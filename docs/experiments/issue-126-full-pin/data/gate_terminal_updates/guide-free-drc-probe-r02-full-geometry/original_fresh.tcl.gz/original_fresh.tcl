read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_neighbors/r01/llaccel/routed_770_BRANCHES_NOT_SYSTEM.odb}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/guide_free_DRC_probe/r02/original.drc}
