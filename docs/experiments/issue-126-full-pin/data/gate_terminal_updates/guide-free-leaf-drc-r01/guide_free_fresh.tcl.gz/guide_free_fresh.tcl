read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/guide_free_leaf_DRC/r01/guide_metadata_removed_NOT_QUALIFIED.odb}
set_routing_layers -signal metal2-metal8 -clock metal4-metal8
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/guide_free_leaf_DRC/r01/guide_free.drc}
