read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_access_tip/r01/routed.odb}
read_sdc {/public/home/yuzelu/PingyangHuang/issue-55/full-block-integration-20261023T103718349596Z/runs/auxiliary-route-llaccel-abc-logic-4c-01/flow/results/nangate45/hpy_llaccel_aux/base/5_1_grt.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_access_tip/r01/extracted.spef}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/setup.txt}
report_checks -path_delay max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 12 -endpoint_path_count 1 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/setup_paths.txt}
report_checks -path_delay max -format json -group_path_count 12 -endpoint_path_count 1 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/setup_paths.json}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/hold.txt}
report_checks -path_delay min -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 12 -endpoint_path_count 1 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/hold_paths.txt}
report_checks -path_delay min -format json -group_path_count 12 -endpoint_path_count 1 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/hold_paths.json}
report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/checks.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/parasitic_coverage.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/llaccel_aux/constraint_coverage.txt}
