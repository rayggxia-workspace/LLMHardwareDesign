read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_tip_views/r01/llaccel_aux-C/clean.odb}
set b [ord::get_db_block]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_residual_pin_audit/r01/all87_actual_net_classes.tsv} w];puts $f "pin	net	use	internal_ITerms	top_BTerms	has_native_wire	actual_top_names"
set g [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_residual_pin_audit/r01/all87_actual_internal_endpoints.tsv} w];puts $g "pin	net	instance	port	layer	x0	y0	x1	y1"
foreach pin {bit_1052 bit_1100 bit_1103 bit_1172 bit_1312092 bit_1312322 bit_1313134 bit_1313281 bit_1313368 bit_1313385 bit_1352369 bit_1352802 bit_1352844 bit_1352850 bit_1353041 bit_1381973 bit_1382130 bit_1382933 bit_1382959 bit_1382985 bit_1383461 bit_1383480 bit_1383668 bit_1385294 bit_1385431 bit_1385555 bit_1385650 bit_1385685 bit_1389324 bit_1389434 bit_1389474 bit_1389521 bit_1391439 bit_1391725 bit_2691 bit_2695 bit_2697 bit_2819 bit_3144 bit_3183 bit_329 bit_3464 bit_3552 bit_3596 bit_3696 bit_3735 bit_3876 bit_410 bit_4145 bit_4182 bit_4243 bit_4449 bit_4581 bit_4587 bit_5222 bit_5233 bit_5342 bit_5382 bit_5416 bit_5423 bit_5575 bit_5660 bit_5661 bit_5686 bit_5777 bit_6354 bit_6357 bit_6492 bit_6539 bit_6705 bit_6777 bit_7032 bit_7033 bit_7153 bit_7193 bit_7211 bit_7215 bit_724 bit_7256 bit_7382 bit_785 bit_830 bit_954 bit_955 bit_959 bit_975 bit_994} {
 set bt [$b findBTerm $pin];if {$bt eq "NULL"} {error "Residual original pin missing"};set n [$bt getNet]
 set names {};foreach term [$n getBTerms] {lappend names [$term getName]}
 puts $f [join [list $pin [$n getName] [$bt getSigType] [llength [$n getITerms]] [llength [$n getBTerms]] [expr {[$n getWire] ne "NULL"}] [join $names {;}]] "	"]
 foreach it [$n getITerms] {foreach geometry [$it getGeometries] {
  lassign $geometry ly z;puts $g [join [list $pin [$n getName] [[$it getInst] getName] [[$it getMTerm] getName] [$ly getName] [$z xMin] [$z yMin] [$z xMax] [$z yMax]] "	"]
 }}
};close $f;close $g
puts ACTUAL_ALL87_NET_{/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_residual_pin_audit/r01/all87_actual_internal_endpoints.tsv}_READ_ONLY_NOT_ACCESS_PASS
