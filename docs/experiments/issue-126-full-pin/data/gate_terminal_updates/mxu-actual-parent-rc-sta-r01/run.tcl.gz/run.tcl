read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_parent/r01/mxu-C/actual_child_timing.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_parent/r01/mxu-C/upgraded_parent_NOT_SYSTEM.odb}
read_sdc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-7/parallel-blocks-wave2-06/mxu-cap20/flow/results/nangate45/parallel_opentpu_mxu/base/6_final.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
puts BEGIN_ACTUAL_NATIVE_UNITS;report_units;puts END_ACTUAL_NATIVE_UNITS
set clocks [all_clocks];if {[llength $clocks]!=1 || [llength [get_ports clk]]!=1} {error "Original clock interface contract mismatch"}
set clk [lindex $clocks 0];set period [get_property $clk period]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/native_original_clock_period.txt} w];puts $f $period;close $f
set in {};set clock_ports [get_ports clk];foreach p [all_inputs] {if {[lsearch -exact $clock_ports $p]<0} {lappend in $p}}
set_input_delay -clock $clk -max [expr {.2*$period}] $in
set_input_delay -clock $clk -min [expr {.05*$period}] $in
set_output_delay -clock $clk -max [expr {.2*$period}] [all_outputs]
set_output_delay -clock $clk -min [expr {.05*$period}] [all_outputs]
set_driving_cell -lib_cell BUF_X4 -pin Z $in
set_input_transition .05 [get_ports clk]
write_sdc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/research_interface.sdc}
define_process_corner -ext_model_index 0 X
set_extraction_rules_file /OpenROAD-flow-scripts/flow/platforms/nangate45/rcx_patterns.rules
extract_parasitics
write_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/extracted.spef}
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/extracted.spef}
report_wire_length -detailed_route -summary -file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/wire_length.csv}
set_load 2 [all_outputs]
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.hold.txt}
report_tns -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.setup_tns.txt}
report_tns -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.hold_tns.txt}
report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.checks.txt}
report_checks -path_delay min_max -group_path_count 12 -endpoint_path_count 1 -fields {capacitance slew fanout} -format full_clock_expanded -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.critical.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.constraint_coverage.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load2.parasitic_coverage.txt}
set_load 10 [all_outputs]
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.hold.txt}
report_tns -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.setup_tns.txt}
report_tns -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.hold_tns.txt}
report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.checks.txt}
report_checks -path_delay min_max -group_path_count 12 -endpoint_path_count 1 -fields {capacitance slew fanout} -format full_clock_expanded -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.critical.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.constraint_coverage.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load10.parasitic_coverage.txt}
set_load 50 [all_outputs]
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.setup.txt}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.hold.txt}
report_tns -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.setup_tns.txt}
report_tns -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.hold_tns.txt}
report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.checks.txt}
report_checks -path_delay min_max -group_path_count 12 -endpoint_path_count 1 -fields {capacitance slew fanout} -format full_clock_expanded -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.critical.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.constraint_coverage.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_parent_rc_sta/r01/load50.parasitic_coverage.txt}
