read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_via_tip/r01/routed.odb}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_fresh/r01/independent.drc}
