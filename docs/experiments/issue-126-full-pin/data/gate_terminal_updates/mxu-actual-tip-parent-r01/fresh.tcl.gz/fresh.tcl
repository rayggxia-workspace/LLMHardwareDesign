read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_parent/r01/mxu-C/upgraded_parent_NOT_SYSTEM.odb}
proc parent_terms {file} {
 set f [open $file w];puts $f "pin\tdirection\tuse\tnet\tlayer\tx0\ty0\tx1\ty1"
 set b [ord::get_db_block];set inst [$b findInst u_macro]
 foreach it [$inst getITerms] {
  set n [$it getNet];if {$n eq "NULL"} {set nn NULL} else {set nn [$n getName]}
  foreach g [$it getGeometries] {set layer [lindex $g 0];set r [lindex $g 1];puts $f [join [list [[$it getMTerm] getName] [$it getIoType] [$it getSigType] $nn [$layer getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]] "\t"]}
 };close $f
}
parent_terms {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_parent/r01/mxu-C/persisted.child_terms.tsv}
set_routing_layers -signal metal2-metal10 -clock metal4-metal10
drt::check_drc -output_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_parent/r01/mxu-C/independent.drc}
