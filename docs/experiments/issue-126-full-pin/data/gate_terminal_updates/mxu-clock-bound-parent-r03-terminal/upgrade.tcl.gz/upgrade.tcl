# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

proc parent_terms {file} {
 set f [open $file w];puts $f "pin\tdirection\tuse\tnet\tlayer\tx0\ty0\tx1\ty1"
 set b [ord::get_db_block];set inst [$b findInst u_macro]
 foreach it [$inst getITerms] {
  set n [$it getNet];if {$n eq "NULL"} {set nn NULL} else {set nn [$n getName]}
  foreach g [$it getGeometries] {set layer [lindex $g 0];set r [lindex $g 1];puts $f [join [list [[$it getMTerm] getName] [$it getIoType] [$it getSigType] $nn [$layer getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]] "\t"]}
 };close $f
}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_landing/r02/mxu-C/routed.odb}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/before}
parent_terms {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/before.child_terms.tsv}
set b [ord::get_db_block];set inst [$b findInst u_macro];set old_xy [$inst getLocation];set old_ori [$inst getOrient]
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/actual_child.lef}
if {![stage upgrade_to_actual_source_view {set replacement [[ord::get_db] findMaster {p126_mxu_M6_escape_r01}];if {$replacement eq "NULL"} {error "New actual child master missing"};if {![$inst swapMaster $replacement]} {error "Native macro view swap rejected"};if {[$inst getLocation] ne $old_xy || [$inst getOrient] ne $old_ori} {error "Original macro pose changed"};write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/upgraded_parent_NOT_SYSTEM.odb}}]} {close $stages;exit 1}
if {![stage bind_current_source_timing_model {read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/actual_child_timing.lib}}]} {close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/after}
parent_terms {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/after.child_terms.tsv}
stage VDD {check_power_grid -net VDD -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/VDD.rpt}}
stage VSS {check_power_grid -net VSS -error_file {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/escape_view_recheck/r03/mxu-C/VSS.rpt}}
stage all_parent_signal_geometry {source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/mxu-clock-bound-parent-r03/export_access.tcl}}
close $stages
