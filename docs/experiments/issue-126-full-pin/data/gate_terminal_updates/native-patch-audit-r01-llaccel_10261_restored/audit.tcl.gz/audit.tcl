read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/owned_cap_wire_restore/r01/routed.odb}
if {[[ord::get_db_block] getDbUnitsPerMicron]!=2000} {error "Source units differ from verified model"}
set ::env(PINXY_PATCH_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/llaccel_10261_restored/patch_rectangles.tsv}
set ::env(PINXY_PATCH_COUNTS) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/llaccel_10261_restored/patch_counts.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/r53-patch-audit-and-owned-views-r01/export_patch_rects.tcl}
