read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_actual_via_tips/r02/routed.odb}
if {[[ord::get_db_block] getDbUnitsPerMicron]!=2000} {error "Source units differ from verified model"}
set ::env(PINXY_PATCH_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/llaccel_stable/patch_rectangles.tsv}
set ::env(PINXY_PATCH_COUNTS) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/llaccel_stable/patch_counts.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/r53-patch-audit-and-owned-views-r01/export_patch_rects.tcl}
