read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/mxu_actual_tip_parent/r01/mxu-C/upgraded_parent_NOT_SYSTEM.odb}
if {[[ord::get_db_block] getDbUnitsPerMicron]!=2000} {error "Source units differ from verified model"}
set ::env(PINXY_PATCH_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/mxu_parent/patch_rectangles.tsv}
set ::env(PINXY_PATCH_COUNTS) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/mxu_parent/patch_counts.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/r53-patch-audit-and-owned-views-r01/export_patch_rects.tcl}
