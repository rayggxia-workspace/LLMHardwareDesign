read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_route/r01/opentpu_aux-C/routed.odb}
if {[[ord::get_db_block] getDbUnitsPerMicron]!=2000} {error "Source units differ from verified model"}
set ::env(PINXY_PATCH_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/opentpu_aux/patch_rectangles.tsv}
set ::env(PINXY_PATCH_COUNTS) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_patch_audit/r01/opentpu_aux/patch_counts.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/r53-patch-audit-and-owned-views-r01/export_patch_rects.tcl}
