
  sta::parse_key_args "generate_ram" args  keys { -mask_size -word_size -num_words -column_mux_ratio
           -storage_cell -tristate_cell -inv_cell -rw_ports
           -r_ports -w_ports -use_latch -power_net_name
           -ground_net_name -routing_layer -ver_layer
           -hor_layer -filler_cells -tapcell -max_tap_dist
           -write_behavioral_verilog } flags {}

  sta::check_argc_eq0 "generate_ram" $args

  # Check for valid design
  if { [ord::get_db_block] != "NULL" } {
    utl::error RAM 20 "A design is already loaded. Cannot generate RAM"
  }

  set ram_netlist_args [list  -word_size $keys(-word_size)  -num_words $keys(-num_words)]

  if { [info exists keys(-rw_ports)] } {
    lappend ram_netlist_args -rw_ports $keys(-rw_ports)
  }

  if { [info exists keys(-r_ports)] } {
    lappend ram_netlist_args -r_ports $keys(-r_ports)
  }

  if { [info exists keys(-w_ports)] } {
    lappend ram_netlist_args -w_ports $keys(-w_ports)
  }

  if { [info exists keys(-mask_size)] } {
    lappend ram_netlist_args -mask_size $keys(-mask_size)
  }

  if { [info exists keys(-storage_cell)] } {
    lappend ram_netlist_args -storage_cell $keys(-storage_cell)
  }

  if { [info exists keys(-tristate_cell)] } {
    lappend ram_netlist_args -tristate_cell $keys(-tristate_cell)
  }

  if { [info exists keys(-inv_cell)] } {
    lappend ram_netlist_args -inv_cell $keys(-inv_cell)
  }

  if { [info exists keys(-tapcell)] } {
    lappend ram_netlist_args -tapcell $keys(-tapcell)
  }

  if { [info exists keys(-max_tap_dist)] } {
    lappend ram_netlist_args -max_tap_dist $keys(-max_tap_dist)
  }

  if { [info exists keys(-column_mux_ratio)] } {
    lappend ram_netlist_args -column_mux_ratio $keys(-column_mux_ratio)
  }

  if { [info exists keys(-write_behavioral_verilog)] } {
    set behavioral_verilog_file $keys(-write_behavioral_verilog)
    ram::set_behavioral_verilog_filename $behavioral_verilog_file
  }

  if { [info exists keys(-use_latch)] } {
    lappend ram_netlist_args -use_latch $keys(-use_latch)
  }

  generate_ram_netlist {*}$ram_netlist_args

  ord::design_created

  set power_net_name "VDD"
  if { [info exists keys(-power_net_name)] } {
    set power_net_name $keys(-power_net_name)
  }

  set power_net_name [string trim $power_net_name]
  if { $power_net_name eq "" } {
    utl::error RAM 40 "The -power_net_name argument cannot be empty."
  }

  set ground_net_name "VSS"
  if { [info exists keys(-ground_net_name)] } {
    set ground_net_name $keys(-ground_net_name)
  }

  set ground_net_name [string trim $ground_net_name]
  if { $ground_net_name eq "" } {
    utl::error RAM 41 "The -ground_net_name argument cannot be empty."
  }

  if { [info exists keys(-routing_layer)] } {
    set routing_layer $keys(-routing_layer)
  } else {
    utl::error RAM 9 "The -routing_layer argument must be specified."
  }

  if { [llength $routing_layer] != 2 } {
    utl::error RAM 12 "-routing_layer is not a list of 2 values"
  } else {
    lassign $routing_layer route_name route_width
    set route_width [ord::microns_to_dbu $route_width]
  }

  if { [info exists keys(-ver_layer)] } {
    set ver_layer $keys(-ver_layer)
  } else {
    utl::error RAM 13 "The -ver_layer argument must be specified."
  }

  if { [llength $ver_layer] != 3 } {
    utl::error RAM 14 "-ver_layer is not a list of 2 values"
  } else {
    lassign $ver_layer ver_name ver_width ver_pitch
    set ver_width [ord::microns_to_dbu $ver_width]
    set ver_pitch [ord::microns_to_dbu $ver_pitch]
  }

  if { [info exists keys(-hor_layer)] } {
    set hor_layer $keys(-hor_layer)
  } else {
    utl::error RAM 15 "The -hor_layer argument must be specified."
  }

  if { [llength $hor_layer] != 3 } {
    utl::error RAM 17 "-hor_layer is not a list of 2 values"
  } else {
    lassign $hor_layer hor_name hor_width hor_pitch
    set hor_width [ord::microns_to_dbu $hor_width]
    set hor_pitch [ord::microns_to_dbu $hor_pitch]
  }

  if { [info exists keys(-filler_cells)] } {
    set filler_cells $keys(-filler_cells)
  } else {
    utl::error RAM 18 "The -filler_cells argument must be specified."
  }

  ram::ram_pdngen $power_net_name $ground_net_name  $route_name $route_width  $ver_name $ver_width $ver_pitch $hor_name $hor_width $hor_pitch

  make_tracks -x_offset 0 -y_offset 0

  ram::ram_pinplacer $ver_name $hor_name

  ram::ram_filler $filler_cells

  ram::ram_routing
