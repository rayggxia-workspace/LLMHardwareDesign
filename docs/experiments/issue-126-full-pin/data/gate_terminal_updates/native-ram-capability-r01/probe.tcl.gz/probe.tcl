read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_ram_capability/r01/capability.tsv} w]
puts $f "item\tvalue"
puts $f "generate_ram_present\t[expr {[llength [info commands generate_ram]]==1}]"
puts $f "ram_namespace_commands\t[info commands ram::*]"
close $f
if {[llength [info commands generate_ram]]} {
 help generate_ram
 set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/native_ram_capability/r01/generate_ram.body.tcl} w]
 if {[catch {info body generate_ram} body]} {puts $f NATIVE_COMPILED_ENTRY_NO_TCL_BODY} else {puts -nonewline $f $body}
 close $f
}
