module RAM64x64 (
  clk,
  D,
  Q,
  addr_w,
  addr_r0,
  we
);
  input clk;
  input [63:0] D;
  output reg [63:0] Q;
  input [5:0] addr_w;
  input [5:0] addr_r0;
  input [63:0] we;

  // memory array declaration
  reg [63:0] mem[0:63];

  // write logic
  integer i;
  always @(posedge clk) begin
    for (i = 0; i < 64; i = i + 1) begin
      if (we[i]) begin
        mem[addr_w][i*1 +:1] <= D[i*1 +:1];
      end
    end
  end

  // read logic
  always @(*) begin
    Q = mem[addr_r0];
  end

endmodule
