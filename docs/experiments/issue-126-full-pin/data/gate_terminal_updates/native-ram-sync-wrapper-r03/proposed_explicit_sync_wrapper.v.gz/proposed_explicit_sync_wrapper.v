module gate (
 input clk, input re_in, input [5:0] r_addr_in,
 input we_in, input [5:0] w_addr_in,
 input [63:0] wd_in, input [63:0] w_mask_in,
 output reg [63:0] rd_out
);
 wire [63:0] asynchronous_q;
 wire [63:0] qualified_write_mask = {64{we_in}} & w_mask_in;
 RAM64x64 core (.clk(clk), .D(wd_in), .Q(asynchronous_q),
 .addr_w(w_addr_in), .addr_r0(r_addr_in), .we(qualified_write_mask));
 always @(posedge clk) begin
  if (re_in) rd_out <= (we_in && r_addr_in == w_addr_in) ? {64{1'bx}} : asynchronous_q;
 end
endmodule
