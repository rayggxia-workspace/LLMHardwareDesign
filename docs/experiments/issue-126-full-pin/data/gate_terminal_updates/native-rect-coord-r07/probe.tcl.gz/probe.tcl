read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
set b [ord::get_db_block];set n [$b findNet HPY_PATCH_RECT_OPCODE];set w [$n getWire]
if {[$w length]!=7 || [$w getOpcode 3]!=14} {error "Known source differs"}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/wire_shape_coverage_API/r07/native_all_shapes.tsv} w];puts $f "stage\tstatus\tvalue"
foreach i {2 3} {
 set status [catch {$w getCoord $i} value];puts $f [join [list native_getCoord_$i $status $value] "\t"]
}
set d [odb::dbWireDecoder];$d begin $w
for {set i 0} {$i<3} {incr i} {set op [$d next]}
set l [$d getLayer];puts $f [join [list native_RECT_layer 0 [$l getName]] "\t"]
close $f
