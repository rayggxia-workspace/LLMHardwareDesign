read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
set b [ord::get_db_block];set n [$b findNet HPY_PATCH_RECT_OPCODE]
if {$n eq "NULL"} {error "Closed known RECT probe net missing"}
puts "ACTUAL_DECODER_ENUM_VARS [lsort [info vars ::odb::*WireDecoder*]]"
foreach name [lsort [info vars ::odb::*WireDecoder*]] {puts "ENUM_VALUE $name [set $name]"}
set d [odb::dbWireDecoder];$d begin [$n getWire]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/wire_shape_coverage_API/r03/native_all_shapes.tsv} w];puts $f "stage\tstatus\tvalue"
for {set i 0} {$i<3} {incr i} {
 set op [$d next];puts $f [join [list opcode_$i 0 $op] "\t"]
 if {$i==1} {set status [catch {$d getPoint} value];puts $f [join [list native_point $status $value] "\t"]}
 if {$i==2} {
  set status [catch {$d getRect} value];puts $f [join [list native_rect $status $value] "\t"]
  set status [catch {$d getLayer} value];if {!$status} {set value [$value getName]}
  puts $f [join [list native_layer $status $value] "\t"]
 }
};close $f
