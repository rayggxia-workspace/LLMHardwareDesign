read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
set b [ord::get_db_block];set n [$b findNet HPY_PATCH_RECT_OPCODE];set w [$n getWire]
if {[$w length]!=7 || [$w getOpcode 3]!=14} {error "Known closed native RECT payload differs"}
set s [odb::dbShape];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/wire_shape_coverage_API/r06/native_all_shapes.tsv} w];puts $f "stage\tstatus\tvalue"
set status [catch {set s [$w getShape 3]} value];puts $f [join [list native_getShape $status $value] "\t"]
if {!$status} {
 set layer [$s getTechLayer]
 puts $f [join [list actual_shape 0 [list [$layer getName] [$s xMin] [$s yMin] [$s xMax] [$s yMax] [$s isVia]]] "\t"]
};close $f
