read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
set b [ord::get_db_block];set n [$b findNet HPY_PATCH_RECT_OPCODE]
if {$n eq "NULL"} {error "Known native RECT probe missing"}
set w [$n getWire];set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/wire_shape_coverage_API/r04/native_all_shapes.tsv} w];puts $f "stage\tstatus\tvalue"
puts "NATIVE_INT_REFERENCE_HELPERS [lsort [concat [info commands ::odb::*intp*] [info commands ::odb::*intArray*]]]"
set status [catch {$w length} count];puts $f [join [list wire_length_API $status $count] "\t"]
if {!$status && [string is integer -strict $count] && $count>0 && $count<=64} {
 for {set i 0} {$i<$count} {incr i} {
  foreach method {getOpcode getData} {
   set status [catch {$w $method $i} value]
   puts $f [join [list ${method}_$i $status $value] "\t"]
  }
 }
};close $f
