read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef}
read_lef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_tip_views/r01/llaccel_aux-C/detailed.lef}
read_liberty {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/llsys_parent_tip_views/r01/llaccel_aux-C/timing.lib}
set m [[ord::get_db] findMaster {llaccel_aux}];if {$m eq "NULL"} {error "Source macro missing"}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/obs_union_compaction/r01/original.pins.tsv} w];puts $f "pin	direction	use	layer	x0	y0	x1	y1"
foreach mt [$m getMTerms] {foreach p [$mt getMPins] {foreach z [$p getGeometry] {puts $f [join [list [$mt getName] [$mt getIoType] [$mt getSigType] [[$z getTechLayer] getName] [$z xMin] [$z yMin] [$z xMax] [$z yMax]] "	"]}}};close $f
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/obs_union_compaction/r01/original.size.tsv} w];puts $f [list [$m getWidth] [$m getHeight] [$m getOrigin]];close $f
