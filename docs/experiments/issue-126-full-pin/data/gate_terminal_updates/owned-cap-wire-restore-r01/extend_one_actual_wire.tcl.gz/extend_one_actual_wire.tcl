set b [ord::get_db_block];set n [$b findNet bit_433]
if {$n eq "NULL" || [llength [$n getBTerms]]!=1 || [llength [$n getITerms]]!=1} {error "Actual failed-net endpoint contract changed"}
set it [lindex [$n getITerms] 0]
if {[[$it getInst] getName] ne "place86173" || [[$it getMTerm] getName] ne "Z"} {error "Original peer changed"}
set itr [odb::dbWirePathItr];set path [odb::dbWirePath];set ps [odb::dbWirePathShape]
set records {};set changed 0;set nw 0;$itr begin [$n getWire]
while {[$itr getNextPath $path]} {while {[$itr getNextShape $ps]} {
 set s [odb::dbWirePathShape_shape_get $ps]
 if {[$s isVia]} {
  set kind TECH;set via [$s getTechVia];if {$via eq "NULL"} {set kind BLOCK;set via [$s getVia]}
  set bottom {};set level 1000
  foreach box [$via getBoxes] {set ly [$box getTechLayer];set lev [$ly getRoutingLevel];if {$lev>0 && $lev<$level} {set level $lev;set bottom $ly}}
  if {$bottom eq ""} {error "No real via bottom"};lassign [$s getViaXY] x y
  lappend records [list VIA $bottom $kind $via $x $y]
 } else {
  incr nw;set ly [$s getTechLayer];set layer [$ly getName];set z [list [$s xMin] [$s yMin] [$s xMax] [$s yMax]]
  if {$layer eq "metal5" && $z eq {3975490 2411220 3975910 2411500}} {set z {3975490 2411220 3976140 2411500};incr changed}
  lassign $z x0 y0 x1 y1;set width [$ly getWidth];set dx [expr {$x1-$x0}];set dy [expr {$y1-$y0}]
  if {min($dx,$dy)!=$width || $dx==$dy || $width%2} {error "Non-default/square source wire requires distinct implementation"}
  if {$dx>$dy} {set xy [list [expr {$x0+$width/2}] [expr {($y0+$y1)/2}] [expr {$x1-$width/2}] [expr {($y0+$y1)/2}]]} else {set xy [list [expr {($x0+$x1)/2}] [expr {$y0+$width/2}] [expr {($x0+$x1)/2}] [expr {$y1-$width/2}]]}
  lappend records [list WIRE $ly {*}$xy]
 }
}}
if {$nw!=28 || $changed!=1} {error "Exact one-wire preflight failed"}
odb::dbWire_destroy [$n getWire];set wire [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $wire
foreach rec $records {
 set kind [lindex $rec 0];$enc newPath [lindex $rec 1] ROUTED
 if {$kind eq "WIRE"} {lassign [lrange $rec 2 end] x y xx yy;$enc addPoint $x $y;$enc addPoint $xx $yy} else {
  lassign [lrange $rec 2 end] kind via x y;$enc addPoint $x $y
  if {$kind eq "TECH"} {$enc addTechVia $via} else {$enc addVia $via}
 }
};$enc end
puts EXACT_ONE_REAL_M5_WIRE_EXTENDED_NO_PIN_OR_VIA_MOVED
