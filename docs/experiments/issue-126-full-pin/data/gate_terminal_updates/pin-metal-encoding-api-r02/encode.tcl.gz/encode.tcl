read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_neighbors/r01/llaccel/routed_770_BRANCHES_NOT_SYSTEM.odb}
set b [ord::get_db_block];set layer [[ord::get_db_tech] findLayer metal5]
if {[$b getDbUnitsPerMicron]!=2000 || [$layer getWidth]!=280} {error "Original native M5 dimensions differ"}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/actual_encoding_status.tsv} w];puts $f "method\tstatus\tmessage"
puts "ACTUAL_RECT_ENCODING_API [info commands ::odb::*WireEncoder*Rect*]"
foreach method {POINT_PAIR RECT_OPCODE} {
 set n [odb::dbNet_create $b HPY_PATCH_$method];set w [odb::dbWire_create $n];set enc [odb::dbWireEncoder];$enc begin $w
 $enc newPath $layer ROUTED;$enc addPoint 3976000 2411360
 set failed [catch {
  if {$method eq "POINT_PAIR"} {$enc addPoint 3976000 2411360} else {$enc addRect -140 -140 140 140}
 } message]
 catch {$enc end} finalize_message
 puts $f [join [list $method $failed [string map [list \n { | } \t { }] $message]] "\t"]
};close $f
set ::env(PINXY_ACCESS_NET_NAMES) {HPY_PATCH_POINT_PAIR HPY_PATCH_RECT_OPCODE}
set ::env(PINXY_ACCESS_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/before_readback.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/pin-metal-encoding-r02/export_access.tcl}
write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
write_def {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.def}
