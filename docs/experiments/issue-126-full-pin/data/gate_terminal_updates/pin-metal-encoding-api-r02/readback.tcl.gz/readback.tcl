read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
set ::env(PINXY_ACCESS_NET_NAMES) {HPY_PATCH_POINT_PAIR HPY_PATCH_RECT_OPCODE}
set ::env(PINXY_ACCESS_OUT) {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/after_readback.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/pin-metal-encoding-r02/export_access.tcl}
