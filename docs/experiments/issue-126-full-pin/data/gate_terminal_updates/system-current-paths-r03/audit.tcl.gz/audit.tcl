read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_1024x128.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_128x128.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_4096x32.lib}
read_liberty {/public/home/yuzelu/project-circuit/llm_routing_analysis/repos/openTPU/build/asic/small/macros/fakeram45_1r1w_512x31.lib}
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_route/r01/opentpu_aux-C/routed.odb}
read_sdc {/public/home/yuzelu/PingyangHuang/issue-55/full-block-integration-20261023T103718349596Z/runs/auxiliary-route-opentpu-4c-01/flow/results/nangate45/hpy_opentpu_aux/base/5_1_grt.sdc}
source /OpenROAD-flow-scripts/flow/platforms/nangate45/setRC.tcl
read_spef {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/system_stacked_via_route/r01/opentpu_aux-C/extracted.spef}
report_worst_slack -max -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/setup.txt}
report_checks -path_delay max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 12 -endpoint_path_count 1 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/setup_paths.txt}
report_checks -path_delay max -format json -group_path_count 12 -endpoint_path_count 1 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/setup_paths.json}
report_worst_slack -min -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/hold.txt}
report_checks -path_delay min -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 12 -endpoint_path_count 1 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/hold_paths.txt}
report_checks -path_delay min -format json -group_path_count 12 -endpoint_path_count 1 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/hold_paths.json}
report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/checks.txt}
report_parasitic_annotation -report_unannotated > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/parasitic_coverage.txt}
check_setup -verbose > {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/actual_path_audit/r03/opentpu_aux/constraint_coverage.txt}
