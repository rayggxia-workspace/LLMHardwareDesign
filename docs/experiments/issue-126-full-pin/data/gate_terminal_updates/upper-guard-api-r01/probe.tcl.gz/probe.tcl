read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_adaptation_trial/r02/llaccel/placed_adapter_NOT_SYSTEM.odb}
puts "ACTUAL_CREATE_NDR_TCL_BODY [info body create_ndr]"
puts "ACTUAL_SET_NDR_RULES_TCL_BODY [info body set_ndr_rules]"
create_ndr -name HPY_UPPER_GUARD_15 -width {metal11 0.8 metal12 0.8} -spacing {metal11 1.5 metal12 1.5}
set guard NULL
foreach rule [[ord::get_db_block] getNonDefaultRules] {if {[$rule getName] eq "HPY_UPPER_GUARD_15"} {set guard $rule}}
if {$guard eq "NULL"} {error "Actual native NDR creation not found"}
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_guard_api/r01/actual_NDR_layer_rules.tsv} w]
puts $f "layer	width_DBU	spacing_DBU"
foreach rule [$guard getLayerRules] {puts $f [join [list [[$rule getLayer] getName] [$rule getWidth] [$rule getSpacing]] "	"]}
close $f
set count 0
foreach net [[ord::get_db_block] getNets] {$net setNonDefaultRule $guard;if {[$net getNonDefaultRule] ne $guard} {error "Native NDR assignment mismatch"};incr count}
if {$count!=770} {error "Expected all original 770 branch nets"}
puts "ACTUAL_NATIVE_GUARD_ASSIGNED_770_NOT_ROUTED"
