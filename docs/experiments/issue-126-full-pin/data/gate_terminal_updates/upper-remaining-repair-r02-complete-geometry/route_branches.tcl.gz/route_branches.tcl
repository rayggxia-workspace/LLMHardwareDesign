# Small matched pure-XY experiment. No resize, placement, CTS, filler removal,
# obstruction deletion, architecture change, or rule relaxation.
set out $::env(PINXY_OUTPUT)
set stages [open $out/branch_route_stages.tsv w]
puts $stages "stage\tstatus\tdetail"
proc stage {name body} {
  global stages
  puts "STAGE_START $name"
  if {[catch {uplevel 1 $body} result options]} {
    puts $stages "$name\tFAIL\t[string map [list \n { | } \t { }] $result]";flush $stages
    puts "STAGE_FAIL $name $result"
    set f [open "$::env(PINXY_OUTPUT)/$name.error.txt" w];puts $f [dict get $options -errorinfo];close $f
    return 0
  }
  puts $stages "$name\tEXECUTED\t";flush $stages
  puts "STAGE_EXECUTED $name"
  return 1
}
proc fingerprint {prefix} {
  set b [ord::get_db_block]
  set f [open "$prefix.cells.tsv" w]
  foreach i [$b getInsts] {
    puts $f [list [$i getName] [[$i getMaster] getName] [$i getLocation] [$i getOrient] [$i getPlacementStatus]]
    foreach t [$i getITerms] {set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]};puts $f [list [$i getName] [[$t getMTerm] getName] $nn]}
  };close $f
  set f [open "$prefix.pins.tsv" w]
  foreach t [$b getBTerms] {
    set n [$t getNet];set nn NULL;if {$n ne "NULL"} {set nn [$n getName]}
    foreach p [$t getBPins] {foreach r [$p getBoxes] {puts $f [list [$t getName] [$t getIoType] [$t getSigType] $nn [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]}}
  };close $f
  set f [open "$prefix.pdn.tsv" w]
  foreach n [$b getNets] {foreach sw [$n getSWires] {foreach r [$sw getWires] {puts $f [list [$n getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax] [$r isVia]]}}};close $f
  set f [open "$prefix.die.tsv" w];set d [$b getDieArea];puts $f [list [$d xMin] [$d yMin] [$d xMax] [$d yMax]];close $f
}
proc timing {prefix} {
  report_worst_slack -max -digits 6 > $prefix.setup.txt
  report_worst_slack -min -digits 6 > $prefix.hold.txt
  report_tns -max -digits 6 > $prefix.setup_tns.txt
  report_tns -min -digits 6 > $prefix.hold_tns.txt
  report_check_types -violators -max_delay -min_delay -max_slew -max_capacitance -max_fanout -recovery -removal -max_count 1000000 -digits 6 > $prefix.checks.txt
  report_checks -path_delay min_max -group_path_count 1000000 -endpoint_path_count 1 -format json > $prefix.paths.json
  check_setup -verbose > $prefix.constraint_coverage.txt
  report_parasitic_annotation -report_unannotated > $prefix.parasitic_coverage.txt
  set relocations {};source $::env(PINXY_RELOCATIONS)
  set count 0
  foreach row $relocations {
    incr count;set pin [lindex $row 0]
    report_checks -through [get_ports $pin] -path_delay min_max -fields {capacitance slew fanout} -format full_clock_expanded -group_path_count 20 -digits 6 > $prefix.selected_$count.txt
  }
}

read_liberty /OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r01/llaccel/routed_770_BRANCHES_NOT_SYSTEM.odb}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_layer_probe/r01/model/research12.setRC.tcl}
proc save_obs {file} {set f [open $file w];foreach ob [[ord::get_db_block] getObstructions] {set r [$ob getBBox];puts $f [list [[$r getTechLayer] getName] [$r xMin] [$r yMin] [$r xMax] [$r yMax]]};close $f}
set b [ord::get_db_block];if {[llength [$b getNets]]!=770 || [llength [$b getBTerms]]!=1540 || [llength [$b getInsts]]} {error "Original full helper count mismatch"}
foreach n [$b getNets] {if {[$n getWire] eq "NULL"} {error "Missing closed original branch wire"}}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r02/llaccel/before_route}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r02/llaccel/before.OBS.tsv}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
read_guides {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_composition/r01/llaccel/route.guide}
set selected_nets {}
lappend selected_nets [[$b findBTerm {src[123]}] getNet]
lappend selected_nets [[$b findBTerm {src[124]}] getNet]
lappend selected_nets [[$b findBTerm {src[128]}] getNet]
lappend selected_nets [[$b findBTerm {src[139]}] getNet]
lappend selected_nets [[$b findBTerm {src[166]}] getNet]
lappend selected_nets [[$b findBTerm {src[180]}] getNet]
lappend selected_nets [[$b findBTerm {src[199]}] getNet]
lappend selected_nets [[$b findBTerm {src[205]}] getNet]
lappend selected_nets [[$b findBTerm {src[206]}] getNet]
lappend selected_nets [[$b findBTerm {src[243]}] getNet]
lappend selected_nets [[$b findBTerm {src[248]}] getNet]
set selected_names {};foreach n [lsort -unique $selected_nets] {lappend selected_names [$n getName]};if {[llength $selected_names]!=11} {error "Selected branch identity mismatch"};set_nets_to_route $selected_names
if {![stage detailed_route_all770 {detailed_route -output_drc {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r02/llaccel/branch_route.drc} -verbose 1;write_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r02/llaccel/routed_770_BRANCHES_NOT_SYSTEM.odb}}]} {close $stages;exit 1}
fingerprint {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r02/llaccel/after_branch_route}
save_obs {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/upper_branch_repair/r02/llaccel/after_branch.OBS.tsv}
source {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/drivers/upper-actual-remaining-r02/export_access.tcl}
close $stages
