read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
puts "ACTUAL_WIRE_BINDING_INVENTORY [lsort [info commands ::odb::*Wire*]]"
