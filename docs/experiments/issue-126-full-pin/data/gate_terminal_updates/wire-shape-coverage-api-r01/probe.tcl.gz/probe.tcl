read_db {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/pin_metal_encoding_API/r02/encoding_probe_NOT_LEAF.odb}
puts "NATIVE_SHAPE_API [info commands ::odb::*WireShapeItr*]"
set b [ord::get_db_block];set it [odb::dbWireShapeItr];set shape [odb::dbShape]
set f [open {/public/home/yuzelu/PingyangHuang/issue-126/full-pin-20261027/wire_shape_coverage_API/r01/native_all_shapes.tsv} w];puts $f "net\tlayer\tx0\ty0\tx1\ty1\tvia"
foreach name {HPY_PATCH_POINT_PAIR HPY_PATCH_RECT_OPCODE} {
 set n [$b findNet $name];$it begin [$n getWire]
 while {[$it next $shape]} {
  set l [$shape getTechLayer]
  puts $f [join [list $name [$l getName] [$shape xMin] [$shape yMin] [$shape xMax] [$shape yMax] [$shape isVia]] "\t"]
 }
};close $f
