import json,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
original=ROOT/'server-return01'
script=Path('project/experiments/cpu_pilot/audit.py').resolve()
checks=[]
for name in ['token','shape','timing']:
    folder=ROOT/('negative-'+name)
    shutil.copytree(original,folder)
    if name=='token':
        p=folder/'run01/inputs.json';x=json.loads(p.read_text());x['input_ids'][0]+=1;p.write_text(json.dumps(x))
    else:
        for fn in ['result.json','correctness.json'] if name=='shape' else ['result.json']:
            p=folder/'run01/float32-8'/fn;x=json.loads(p.read_text())
            if name=='shape':x['cache_layers'][0]['shape'][-1]=64
            else:x['timings'][0]['decode_tokens_per_second']*=2
            p.write_text(json.dumps(x))
    r=subprocess.run(['python','-B',str(script),str(folder),'--out',str(ROOT/('negative-'+name+'.json'))],capture_output=True)
    assert r.returncode!=0,name
    (ROOT/('negative-'+name+'.log')).write_bytes(r.stdout+r.stderr)
    checks.append({'mutation':name,'rejected':True,'exit':r.returncode})
(ROOT/'negative-audit.json').write_text(json.dumps(checks,indent=2)+'\n')
print(checks)
