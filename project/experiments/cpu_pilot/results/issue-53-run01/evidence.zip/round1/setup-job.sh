#!/bin/bash
#SBATCH --job-name=lrz-cpuenv
#SBATCH --partition=debug
#SBATCH --cpus-per-task=4
#SBATCH --time=00:15:00
set -euo pipefail
cd /public/home/yuzelu/RuizhiLiang/issue53-cpu-pilot-20261023
export TMPDIR="$PWD/tmp" PIP_CACHE_DIR="$PWD/cache" PYTHONDONTWRITEBYTECODE=1
/public/home/yuzelu/python-3.12/bin/python3.12 - <<'PY'
import hashlib,json,zipfile
from pathlib import Path
expected=json.loads(Path('transfer-receipt.json').read_text())
h=hashlib.sha256()
with open('environment-input.zip','rb') as f:
    for b in iter(lambda:f.read(8<<20),b''):h.update(b)
assert h.hexdigest()==expected['sha256']
assert not Path('model').exists() and not Path('wheelhouse').exists()
with zipfile.ZipFile('environment-input.zip') as z:
    assert all(not Path(i.filename).is_absolute() and '..' not in Path(i.filename).parts for i in z.infolist())
    z.extractall('.')
manifest=json.loads(Path('manifest.json').read_text())
for name,info in manifest.items():
    p=Path(name);h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    assert h.hexdigest()==info['sha256'] and p.stat().st_size==info['bytes'],name
print('INPUT ARCHIVE AND ALL MODEL/WHEEL HASHES VERIFIED',flush=True)
PY
/public/home/yuzelu/python-3.12/bin/python3.12 -m venv venv
venv/bin/python -m pip install --no-index --no-compile --find-links wheelhouse --report pip-report.json 'torch==2.10.0+cpu' 'transformers==4.57.6' 'numpy==2.2.6' > install.log 2>&1
venv/bin/python -m pip check > pip-check.txt
venv/bin/python -m pip freeze > installed.txt
venv/bin/python -c 'import torch,transformers; print(torch.__version__,transformers.__version__);print(torch.ones(2,2)@torch.ones(2,2))' > import-smoke.txt
