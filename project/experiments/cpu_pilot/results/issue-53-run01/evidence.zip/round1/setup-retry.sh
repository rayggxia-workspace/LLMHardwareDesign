#!/bin/bash
#SBATCH --job-name=lrz-cpuenvfix
#SBATCH --partition=debug
#SBATCH --cpus-per-task=4
#SBATCH --time=00:15:00
set -euo pipefail
cd /public/home/yuzelu/RuizhiLiang/issue53-cpu-pilot-20261023
export TMPDIR="$PWD/tmp" PIP_CACHE_DIR="$PWD/cache" PYTHONDONTWRITEBYTECODE=1
sha256sum -c fix-wheel.sha256
venv/bin/python -m pip install --no-index --no-compile --find-links wheelhouse --report pip-report-retry.json 'torch==2.10.0+cpu' 'transformers==4.57.6' 'numpy==2.2.6' > install-retry.log 2>&1
venv/bin/python -m pip check > pip-check.txt
venv/bin/python -m pip freeze > installed.txt
venv/bin/python -c 'import torch,transformers; print(torch.__version__,transformers.__version__);print(torch.ones(2,2)@torch.ones(2,2))' > import-smoke.txt
