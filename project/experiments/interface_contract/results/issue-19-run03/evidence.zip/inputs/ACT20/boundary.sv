// Fixed small parameters; source RTL unchanged.
module llhd_opentpu_act import otpu_pkg::*; (
  input logic clk,
  input logic [3:0] we,
  input logic [7:0] w_row,
  input logic [31:0] w_idx,
  input logic [3:0][7:0] w_data,
  input logic w_dup,
  input logic [7:0] w_off,
  input logic swe,
  input logic [7:0] s_row,
  input logic [15:0] s_blk,
  input logic [63:0] s_data,
  input logic [1:0] ren,
  input logic r_use,
  input logic [15:0] r_blk, r_blk2,
  input logic [1:0] r_hi,
  input logic [7:0] r_grp,
  output wire [511:0] r_data,
  output wire [127:0] r_scale);
  otpu_actram #(.D(32), .MCOLS(2), .ROWS(2), .BLOCKS(32), .LANES(4)) u_act (
    .clk, .we, .w_row, .w_idx, .w_data, .w_dup, .w_off, .swe, .s_row, .s_blk, .s_data,
    .ren(ren), .r_use(r_use), .r_blk(r_blk), .r_blk2(r_blk2), .r_hi(r_hi), .r_grp(r_grp),
    .r_data(r_data), .r_scale(r_scale));
endmodule
