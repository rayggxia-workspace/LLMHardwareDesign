#!/bin/bash
set -euo pipefail
cd /work
export TMPDIR=/work/tmp
yosys -V > version.txt
sha256sum /usr/local/bin/yosys /inputs/bank_port_fabric.sv > inputs.sha256
/usr/bin/time -v -o frontend.time timeout 360 yosys -Q -T -l frontend.log -p 'read_verilog -sv -defer -D SYNTHESIS /inputs/bank_port_fabric.sv; hierarchy -check -top bank_port_fabric -chparam PORT_MODE 0 -chparam RESP_DEPTH 1; write_rtlil elaborated.il'
sha256sum elaborated.il > checkpoint.sha256
/usr/bin/time -v -o lowering.time timeout 720 yosys -Q -T -l lowering.log -p 'read_rtlil elaborated.il; proc; opt; memory_collect; check -assert; stat; write_json generic.json'
sha256sum generic.json > result.sha256
