#!/bin/bash
#SBATCH --job-name=lrz-portdefer
#SBATCH --partition=debug
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=00:20:00
set -euo pipefail
cd /public/home/yuzelu/RuizhiLiang/issue29-port-rtl-20261022/defer01
/public/software/singularity-ce-4.3.4/bin/singularity exec --cleanenv --contain --bind "$PWD:/work" --bind /public/home/yuzelu/RuizhiLiang/issue29-port-rtl-20261022/formal01/source:/inputs:ro /public/home/yuzelu/opt/eda/containers/orfs-26Q1-repacked.sif bash /work/inside.sh
