"""Exercise independent readback rejection after updating artifact checksums."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

import numpy as np
root=Path('D:/Projects/LLMHardwareDesign-primitives')
sys.path.insert(0,str(root/'project/experiments/primitive_stream'))
from audit import audit
from common import save,npz,digest
scratch=Path('D:/Projects/Codex/primitive-stream-20261023')
capture=scratch/'capture02';original=scratch/'numeric03'
results=[]
for case in ('input_code','score_compiler','cache_epoch'):
    destination=scratch/('negative-'+case)
    if destination.exists():raise ValueError('refuse overwrite')
    shutil.copytree(original,destination)
    if case in ('input_code','score_compiler'):
        with np.load(destination/'integers.npz',allow_pickle=False) as f:
            arrays={name:f[name].copy() for name in f.files}
        suffix='Q_i8' if case=='input_code' else 'score_M_u32'
        key=next(k for k in arrays if k.endswith('.'+suffix))
        item=arrays[key].flat[0]
        arrays[key].flat[0]=int(item)-1 if int(item)>0 else int(item)+1
        npz(destination/'integers.npz',arrays)
    else:
        records=json.loads((destination/'numeric.json').read_text())
        records[0]['cache_events'][1]['published_epoch']=0
        save(destination/'numeric.json',records)
    manifest=json.loads((destination/'manifest.json').read_text())
    for name in manifest['artifacts']:
        path=destination/name
        manifest['artifacts'][name]={'bytes':path.stat().st_size,'sha256':digest(path)}
    save(destination/'manifest.json',manifest)
    try:
        audit(capture,destination)
    except AssertionError as exc:
        results.append({'mutation':case,'rejected':True,'reason':str(exc) or 'independent invariant assertion',
                        'artifact_checksums_updated':True})
    else:raise AssertionError('mutation accepted '+case)
save(scratch/'negative-audit.json',{'status':'PASS','checks':results})
print(json.dumps(results))
