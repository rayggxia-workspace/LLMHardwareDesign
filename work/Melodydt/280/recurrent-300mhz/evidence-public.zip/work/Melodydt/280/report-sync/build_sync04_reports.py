"""Synchronize accepted partial v5 results without changing experiment files.

New data are current; obsolete dependent estimates are null. SYNC-03 remains
an explicitly marked historical appendix, never a replacement for missing data.
"""
import argparse
import copy
import hashlib
import io
import json
import math
from datetime import datetime, timezone, timedelta
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab import rl_config
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, PageBreak, Spacer
from pypdf import PdfReader, PdfWriter

ROOT=Path(__file__).resolve().parents[4]
OLD='output/pdf/seven-model-sync03-20261118'
BASE='work/Melodydt/280'
V5=BASE+'/closure-v5'
ORDER=('qwen3','llama','granite','phi','gemma','qwen35','falcon')
NAMES=dict(qwen3='Qwen3-0.6B',llama='Llama-3.2-1B',granite='Granite-3.1-3B-A800M',
           phi='Phi-4-mini',gemma='Gemma-3-4B',qwen35='Qwen3.5-4B',falcon='Falcon-H1-3B')

def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def build(out,context,offline=None):
    out.mkdir(parents=True,exist_ok=False);files={};cache={};checks=[]
    def take(rel):
        rel=str(rel).replace('\\','/')
        if rel not in cache:
            raw=((offline/'inputs'/rel) if offline else ROOT/rel).read_bytes()
            dest=out/'inputs'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            cache[rel]=raw;files[rel]=sha(raw)
        return cache[rel]
    def read(rel):return json.loads(take(rel))
    def eq(a,b,label):
        assert math.isclose(a,b,rel_tol=2e-10,abs_tol=1e-8),(label,a,b)
        checks.append(label)
    def units(z,ps,tokens,label):
        e=z['energy_nj_per_window'];assert 0<=e[0]<=e[1]
        for i in (0,1):
            eq(z['average_power_w'][i],e[i]*1000/ps,label+'/W')
            eq(z['energy_mj_per_token'][i],e[i]/1e6/tokens,label+'/mJ')
    def convert(w):
        scopes={}
        for scope,key in [('on_chip','estimated_on_chip'),('on_chip_plus_ddr','estimated_on_chip_plus_ddr')]:
            z=w[key];e=[v/1000 for v in z['energy_mj_per_token']]
            scopes[scope]={'energy_j_per_token':e,'average_power_w':z['average_power_w'],
                'tokens_per_joule':[1/e[1],1/e[0]],'energy_j_per_window':[v*w['tokens'] for v in e]}
        return {'tokens':w['tokens'],'duration_s':w['elapsed_ps']/1e12,
                'tokens_per_second':w['tokens_per_second'],'scopes':scopes}

    old=read(OLD+'/frequency-estimates.json');current=copy.deepcopy(old)
    # Recheck the previously accepted source chain; its obsolete descendants
    # remain archived and are excluded from the current tables below.
    previous_lock=read(OLD+'/source-consistency.json')
    for rel,h in previous_lock['checked_files'].items():
        assert sha(take(rel))==h,('legacy result source changed',rel)
    jobs=read(V5+'/deployments-current.tar.json')['jobs']
    accepted={(j['model'],j['phase']):j for j in jobs if j['variant']=='e32-18' and j['status']=='accepted_and_manifest_verified'}
    indices={kind:read(V5+'/'+kind+'/index.json') for kind in ('timing-ledger','dma-ledger','special-candidate-ledger')}
    expected={(r['model'],r['phase']) for r in indices['timing-ledger']}
    assert expected==set(accepted),'New accepted short results require their matching timing ledger'
    for kind,idx in indices.items():
        assert {(r['model'],r['phase']) for r in idx}==expected
        for r in idx:
            rel=f"{V5}/{kind}/{r['model']}-{r['phase']}.json"
            assert sha(take(rel))==r['sha256'],rel
    coefficients=read(V5+'/dma-coefficients.json')
    for variant,c in coefficients.items():
        cal=read(f'{V5}/dma-{variant}-pin-calibration.json')
        assert files[f'{V5}/dma-{variant}-pin-calibration.json']==c['calibration_sha256']
        assert cal['clock_mhz']==300 and cal['wire_parasitics_loaded'] is False
        assert 'reset fence completed' in cal['operational_idle']
        sets=[]
        for row in cal['windows'].values():
            assert row['annotated']==row['activity_pin_mapping']['expected_annotated_pins']
            sets.append(row['activity_pin_mapping']['observed_pin_set_sha256'])
        assert len(set(sets))==1
    for rel in ('control-periphery-calibration.json','special-pin-calibration.json','conv4-pin-calibration.json',
                'integrated-ledger-validation.json','README.md','integrate_calibrated_timing.py',
                'integrate_dma_scenarios.py','integrate_special_candidates.py','verify_integrated_ledgers.py'):
        take(V5+'/'+rel)
    for rel in ('DELIVERY.md','full-pin-preflight-receipt.json','publication.json','trace-opt-jobs.json'):
        take(BASE+'/recurrent-step1/'+rel)
    take('docs/handoffs/2026-11-18-issue-280-closure-v5.md')
    updated={};ledgers={};windows=0
    for model,phase in sorted(expected):
        path=f'{model}-{phase}.json';timing=read(V5+'/timing-ledger/'+path)
        dma=read(V5+'/dma-ledger/'+path);special=read(V5+'/special-candidate-ledger/'+path)
        assert dma['baseline_sha256']==files[V5+'/timing-ledger/'+path]
        for obj in (timing,special):
            for rel,h in obj['inputs'].items():assert sha(take(BASE+'/'+rel.replace('\\','/')))==h,rel
        stage=f'{V5}/deployments/{model}-{phase}-e32-18'
        a=read(stage+'/result/acceptance.json');prov=read(stage+'/provenance.json')
        assert a['passed'] and a['numerical_and_traffic_invariants_equal'] and a['numerical_files_equal'] and a['ddr_terminal_reconciled']
        audit=read(f'{V5}/deployment-audits/{model}-{phase}-e32-18.json')
        assert audit['e32_product_cycles']==18 and audit['data_sram_bits']==512
        observed=read(stage+'/result/deployment-observation.json')
        device=read(stage+'/result/ddr-window-energy.json')['windows']
        updated.setdefault(model,{})[phase]={'job':accepted[model,phase]['job'],'source_commit':prov['source_commit'],
            'acceptance_sha256':files[stage+'/result/acceptance.json'],'timing_sha256':files[V5+'/timing-ledger/'+path]}
        ledgers[model,phase]={'timing':timing,'dma':dma,'special':special}
        assert not special['rtl_full_model_numeric_accepted'] and not special['timing_recomputed_for_candidate_service']
        for name,w in timing['windows'].items():
            windows+=1;ps,tokens=w['elapsed_ps'],w['tokens']
            assert ps==observed['windows'][name]['elapsed_ps']==device[name]['elapsed_ps']
            eq(w['tokens_per_second'],tokens*1e12/ps,model+'/'+name+'/rate')
            eq(w['ddr']['energy_nj_per_window'][0],device[name]['device_j']*1e9,model+'/ddr')
            chip=[sum(z['energy_nj_per_window'][i] for z in w['components'].values()) for i in (0,1)]
            for i in (0,1):
                eq(chip[i],w['estimated_on_chip']['energy_nj_per_window'][i],'components')
                eq(chip[i]+w['ddr']['energy_nj_per_window'][i],w['estimated_on_chip_plus_ddr']['energy_nj_per_window'][i],'DDR sum')
            for z in [*w['components'].values(),w['estimated_on_chip'],w['estimated_on_chip_plus_ddr']]:units(z,ps,tokens,'timing')
            s=special['windows'][name]
            for k,z in s['removed_proxies'].items():assert z['energy_nj_per_window']==w['components'][k]['energy_nj_per_window']
            sc=[sum(z['energy_nj_per_window'][i] for k,z in w['components'].items() if k not in s['removed_proxies'])+
                sum(z['energy_nj_per_window'][i] for z in s['replacement_components'].values())+s['candidate_idle']['energy_nj_per_window'][i] for i in (0,1)]
            for i in (0,1):eq(sc[i],s['estimated_on_chip']['energy_nj_per_window'][i],'proxy replacement')
            for variant,entry in dma['scenarios'].items():
                assert entry['coefficient']==coefficients[variant]
                d=entry['windows'][name];assert d['elapsed_ps']==ps and d['tokens']==tokens
                for i in (0,1):
                    de=d['read_dma_total']['energy_nj_per_window'][i]
                    eq(de,d['read_dma_idle']['energy_nj_per_window'][i]+d['read_dma_dynamic']['energy_nj_per_window'][i],'DMA parts')
                    eq(d['read_dma_dynamic']['energy_nj_per_window'][i],w['validated_counts']['read_dma_beats_64b']*coefficients[variant]['dynamic_nj_per_64b'][i],'DMA reads')
                    eq(d['read_dma_idle']['energy_nj_per_window'][i],coefficients[variant]['idle_w'][i]*ps/1000,'DMA residence')
                    eq(chip[i]+de,d['estimated_on_chip']['energy_nj_per_window'][i],'DMA addition')
                    eq(sc[i]+de,s['dma_scenarios'][variant]['estimated_on_chip']['energy_nj_per_window'][i],'candidate plus one DMA')
                for k in ('read_dma_total','estimated_on_chip','estimated_on_chip_plus_ddr'):units(d[k],ps,tokens,'DMA')
            key='short_prefill' if name=='prefill' else name
            current['300'][model]['windows'][key]=convert(w)
    # Never silently apply obsolete 9-cycle coefficients to an 18-cycle schedule.
    for model in ORDER:
        changed=model in updated
        current['300'][model]['basis']='E32-18 partial v5' if changed else 'E32-9 / control-v4; retest pending'
        current['200'][model]['basis']='pending same-baseline reconstruction' if changed else 'E32-9 / power-v4; E32-18 retest pending'
        if changed:
            current['300'][model]['prefill512_tok_s']=None;current['300'][model]['prefill512_s']=None
            current['300'][model]['p512_version']='pending E32-18 re-extrapolation'
            current['200'][model]['windows']={};current['200'][model]['prefill512_tok_s']=None
            current['200'][model]['prefill512_s']=None;current['200'][model]['p512_energy_available']=False
        assert not current['300'][model]['p512_energy_available']
    data={'current':current,'historical_sync03':old,'updates':updated,
          'scenario_ledgers':{m+'-'+p:v for (m,p),v in ledgers.items()},'dma_coefficients':coefficients}
    context=copy.deepcopy(context);context['snapshot_time']=context.get('snapshot_time') or datetime.now(timezone(timedelta(hours=8))).isoformat()
    context['new_changes']=[
        '新增已验收 E32 18 周期短窗和对应能耗：'+', '.join(NAMES[m] for m in ORDER if m in updated)+'。其余模型沿用明确标注的既有值。',
        '新增母控外围；读 DMA 四种综合网表仅作互斥条件场景，均未宣称实际整机物理绑定。',
        '特殊候选采用先删除旧代理再加入新成本的规则；尚无候选整模型数值/调度验收。',
        '已更新模型的旧 P512 和 200 MHz 派生结果退出当前表，待同基线重算；历史数据只在标注的附录保留。',
        '再次核实：300 MHz P512 能耗仍未形成完整积分；200 MHz P512 power-v4 已有，但受 E32 基线更新影响。']
    dump(out/'frequency-estimates.json',data)
    baseline=sha(json.dumps(updated,sort_keys=True).encode())
    context['source_consistency']={'source_baseline_id':baseline,'numeric_checks':len(checks),
        'policy':'stale descendants excluded from current tables; historical appendix explicitly marked'}
    dump(out/'sync-context.json',context)
    dump(out/'version-changes.json',{'version':'SYNC-04','previous_sync':'SYNC-03','snapshot_time':context['snapshot_time'],
        'new_changes':context['new_changes'],'numerical_results_changed':True,'same_baseline_reconstruction_complete':False})
    for freq in (300,200):
        for kind in ('speed','power'):take(f'{OLD}/seven-model-{kind}-{freq}mhz-sync03.pdf')
    # Make the audit reflect every source that supports the delivered pages.
    lock={'passed':True,'meaning':'all published CURRENT numbers have matching sources; missing descendants are null',
        'source_baseline_id':baseline,'numeric_checks':len(checks),'checked_files':files,
        'report_metrics_sha256':sha((out/'frequency-estimates.json').read_bytes()),
        'pending_descendants':list(updated),'full_seven_model_e32_18_complete':len(updated)==7,
        'windows_reintegrated':windows,'checks':checks}
    dump(out/'source-consistency.json',lock);dump(out/'source-manifest.json',{'files':{k:{'sha256':v,'bytes':len(cache[k])} for k,v in files.items()}})
    pdf_records=[]
    for freq in (300,200):
        for kind in ('speed','power'):
            pdf_records.append(render(out,freq,kind,data,context))
    dump(out/'validation.json',{'management_structure':'checked separately','pdf_visual_review':'pending','files':pdf_records,
        'source_files':len(files),'dependency_numeric_checks':len(checks),'new_energy_windows':windows,
        'stale_descendants_not_current':True})
    print(json.dumps({'snapshot':str(out),'updated_models':list(updated),'source_files':len(files),'checks':len(checks),'files':pdf_records},indent=2))


def render(out,freq,kind,data,context):
    pdfmetrics.registerFont(TTFont('CN','C:/Windows/Fonts/Deng.ttf'));pdfmetrics.registerFont(TTFont('CNB','C:/Windows/Fonts/Dengb.ttf'));rl_config.invariant=1
    ink=colors.HexColor('#183044');teal=colors.HexColor('#006c70');orange=colors.HexColor('#9a451d')
    body=ParagraphStyle('body',fontName='CN',fontSize=10,leading=15,spaceAfter=8,textColor=ink,wordWrap='CJK')
    title=ParagraphStyle('title',parent=body,fontName='CNB',fontSize=22,leading=29,spaceAfter=15)
    small=ParagraphStyle('small',parent=body,fontSize=8.3,leading=12)
    cell=ParagraphStyle('cell',parent=small,spaceAfter=0)
    story=[];expected=[];pages=0;current=data['current'][str(freq)];old=data['historical_sync03'][str(freq)];updated=data['updates']
    def p(s,style=body):story.append(Paragraph(escape(str(s)).replace('\n','<br/>'),style))
    def page(s):
        nonlocal pages
        if pages:story.append(PageBreak())
        pages+=1;p(s,title)
    def num(v,n=4):
        if v is None:return '待同基线重算'
        if isinstance(v,list):return '–'.join(num(x,n) for x in v)
        s=f'{v:.{n}f}';expected.append(s);return s
    def table(headers,rows,widths):
        t=Table([[Paragraph(escape(str(x)).replace('\n','<br/>'),cell) for x in row] for row in [headers]+rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6f0f2')),('LINEBELOW',(0,0),(-1,0),.8,teal),
            ('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#cad7dc')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.append(t);story.append(Spacer(1,9))
    def scope(w,key,metric):return num(w['scopes'][key][metric])
    def intro():
        p('SYNC-04 | '+context['snapshot_time'],small)
        p('512-bit 数据 SRAM | 三路 P | 300 MHz 核心 3334 ps / 200 MHz 核心 5000 ps | DDR 630 ps',small)
    if kind=='speed':
        page(f'{freq} MHz 速度同步');intro()
        p('本轮是部分模型 E32 调度校准的增量同步。最新已验收短窗优先；没有匹配新基线的 P512 / 200 MHz 值不列为当前结果。')
        rows=[]
        for m in ORDER:
            w=current[m]['windows'];fresh=m in updated
            rows.append([NAMES[m],num(w['short_prefill']['tokens_per_second']) if w else '待重算',
                num(current[m]['prefill512_tok_s']) if current[m]['prefill512_tok_s'] is not None else '待重算',
                num(w['decode']['tokens_per_second']) if w else '待重算',
                ('E32-18 已验收' if freq==300 else '300 MHz 已更新') if fresh else 'E32-9；重测待验'])
        table(['模型','短 P2\ntoken/s','P512\ntoken/s','Decode\ntoken/s','数据状态'],rows,[128,78,78,78,133])
        p('短 Prefill 为两个输入 token；Decode 为真实 512 历史起点运行两步中的第二步区间。P512 为条件估计，包含最后一次输出头。各模型当前版本可能不同，不能把混合版本表当作统一 E32-18 横向验收。',small)
        page('来源一致性与变化');intro()
        if freq==300:
            rows=[]
            for m in ORDER:
                if m not in updated:continue
                a=data['historical_sync03']['300'][m]['windows'];b=current[m]['windows']
                rows.append([NAMES[m],num(100*(b['short_prefill']['tokens_per_second']/a['short_prefill']['tokens_per_second']-1),2)+'%',
                    num(100*(b['decode']['tokens_per_second']/a['decode']['tokens_per_second']-1),2)+'%',
                    updated[m]['prefill']['job']+' / '+updated[m]['decode']['job']])
            table(['模型','短 P2 变化','Decode 变化','验收作业 P / D'],rows,[150,95,95,155])
            p('变化原因是 E32 MUL 从原调度 9 周期校准为 18 周期，并重新处理共享资源和 DDR 等待；不是新优化提升。接受条件包括数值文件不变、流量守恒、DDR 对账和资源区间审计。')
        else:
            p('Qwen3、Llama、Granite 的 300 MHz 短窗已改为 E32-18；#293 的代表层成对系数、P512 v3 和 power-v4 仍基于 E32-9。它们不能直接冒充最新 300 MHz 的派生值。')
            p('其余四模型暂保留既有已发布同源结果，并明确标注 E32-18 重测待验。200 MHz 新同源结果需匹配当前调度的成对代表层、入口和输出头，DDR 仍保持独立时钟。')
        for s in context['new_changes']:p(s,small)
        p('后续顺序：收齐七模型 E32-18 → 更新 300 MHz P512 曲线与端点 → 重新核验 200 MHz 成对样本和短窗 → 更新 200 MHz P512 → 两档同窗口能耗积分。不能只按频率或总延迟比例修改全部动态项。',small)
        p('以下附录保留 SYNC-03 的完整方法、模型优化和历史数值。每页均有历史标识；其中受新基线影响的值不属于当前指标。',small)
    elif freq==300:
        page('300 MHz 功耗与能耗同步');intro()
        p('主表为当前已完成的条件小计：三模型采用 E32-18 时间＋母控外围，四模型保留控制 v4。读 DMA 的四种网表单列为替代场景；不任意选择其中一版，也不相加。')
        rows=[]
        for m in ORDER:
            w=current[m]['windows']['decode']
            rows.append([NAMES[m],scope(w,'on_chip','energy_j_per_token'),scope(w,'on_chip_plus_ddr','energy_j_per_token'),
                scope(w,'on_chip','average_power_w'),scope(w,'on_chip_plus_ddr','average_power_w'), 'v5 部分' if m in updated else 'v4'])
        table(['第二步 Decode','片上\nJ/token','片上＋DDR\nJ/token','片上 W','片上＋DDR W','版本'],rows,[120,88,88,79,79,41])
        p('300 MHz 七模型 P512 功耗与能耗：仍缺匹配完整积分。已有 P512 速度、短窗能耗和新增模块标定，不等于已有 P512 能耗。此处不填短 P2 值，也不从 200 MHz 比例反推。')
        p('小计仍不代表完整芯片。实际 RTL 拓扑、门控/状态驻留、特殊算子 provider/转换、全局时钟互连、PHY/板级等边界未闭合；区间为成本/样本情景，不是置信区间。',small)
        page('短 Prefill 与首步窗口');intro()
        p('短 P2 的片上与片上＋DDR 条件小计如下。三模型已按 E32-18 新窗口重算驻留项，其余四模型仍为控制 v4；均不能代替 P512。')
        rows=[]
        for m in ORDER:
            w=current[m]['windows']['short_prefill']
            rows.append([NAMES[m],scope(w,'on_chip','energy_j_per_token'),scope(w,'on_chip_plus_ddr','energy_j_per_token'),
                scope(w,'on_chip','average_power_w'),scope(w,'on_chip_plus_ddr','average_power_w')])
        table(['短 P2','片上 J/token','片上＋DDR J/token','片上 W','片上＋DDR W'],rows,[125,95,95,90,90])
        p('新三模型的首步窗口含实际入口及状态载入，单列以便复用；常规 Decode 指标仍取第二步。',small)
        rows=[]
        for m in ORDER:
            if m not in updated:continue
            w=current[m]['windows']['first_token']
            rows.append([NAMES[m],num(w['duration_s']),scope(w,'on_chip','energy_j_per_token'),scope(w,'on_chip_plus_ddr','energy_j_per_token')])
        table(['首步窗口','时间 s','片上 J/token','片上＋DDR J/token'],rows,[150,95,125,125])
        p('新增母控外围采用参考功率乘匹配驻留时间；M 活跃/空闲按本轮 TLM 部署观测重新分配，不能称为整模型门级活动实测。DMA 和特殊候选仍在后页单独列示。',small)
        page('读 DMA 条件场景');intro()
        p('下表是在新时间与母控外围小计上加入一个读 fabric 的第二步 Decode 结果，未替换特殊算子代理。phase 已包含 shared；四行互为替代，不能叠加。')
        rows=[]
        for m in ORDER:
            if m not in updated:continue
            for variant,entry in data['scenario_ledgers'][m+'-decode']['dma']['scenarios'].items():
                w=entry['windows']['decode'];a=w['estimated_on_chip'];b=w['estimated_on_chip_plus_ddr']
                rows.append([NAMES[m],variant,num([v/1000 for v in a['energy_mj_per_token']]),num([v/1000 for v in b['energy_mj_per_token']]),num(b['average_power_w'])])
        table(['模型','单个读 fabric','片上 J/token','片上＋DDR J/token','片上＋DDR W'],rows,[107,94,98,108,88])
        p('用真实读 64B 次数和新驻留时长积分；未观测内部门级活动仍含传播估计。phase 的 owner 1 动态与每模型实际网表选择尚待绑定。四个模型未收齐 E32-18 结果，暂不把 DMA 新系数写入其主表。',small)
        page('新标定与尚未纳入项');intro()
        per=json.loads((out/'inputs'/V5/'control-periphery-calibration.json').read_bytes())
        vals=[r['power_w']['total']*1000 for r in per['windows'].values()]
        p('母控外围：切除已计入的 10 个实例后，参考功耗 '+num([min(vals),max(vals)],3)+' mW。已按已验收模型窗口驻留积分；不是整模型 RTL 状态分布实测。')
        spec=json.loads((out/'inputs'/V5/'special-pin-calibration.json').read_bytes())
        rows=[[op,num(v['incremental_nj_per_call'],4)] for op,v in spec['primitives'].items()]
        table(['候选原语','动态增量 nJ/调用'],rows,[280,215])
        p('Conv4 动态约 0.475–0.789 nJ/通道；候选输入/定点结果通过不等于完整 FP32 服务通过。新候选账本先删除旧 proxy，再加入原语与残余复合算术，避免重复计费；候选执行周期尚未接入整模型，故不改吞吐。',small)
        rows=[]
        for m in ORDER:
            if m not in updated:continue
            z=data['scenario_ledgers'][m+'-decode']['special']['windows']['decode']
            rows.append([NAMES[m],', '.join(z['removed_proxies']) or '无匹配替换项',num([v/1000 for v in z['estimated_on_chip']['energy_mj_per_token']]),num([v/1000 for v in z['estimated_on_chip_plus_ddr']['energy_mj_per_token']])])
        table(['候选场景（不含读 DMA）','删除的旧代理','片上 J/token','片上＋DDR J/token'],rows,[145,130,110,110])
        p('200 MHz 递推侧线：Qwen3.5 / Falcon 已通过完整引脚读取预检，但回执明确排除在标定和模型能耗之外，本次不将预检当作新能耗结果。300 MHz P512 能耗仍待独立同窗积分。',small)
        p('以下为历史 SYNC-03 七模型分项与优化附录；新三模型当前值以前面的增量表为准。',small)
    else:
        page('200 MHz 功耗与能耗同步');intro()
        p('200 MHz 的 power-v4 已包含 P512 能耗。Qwen3、Llama、Granite 的最新 300 MHz 基线发生变化，故它们当前同基线的 200 MHz 功耗／能耗标为待重算；旧值保留在历史附录。')
        for phase,label in [('prefill512','512-token Prefill'),('decode','第二步 Decode')]:
            p(label)
            rows=[]
            for m in ORDER:
                w=current[m]['windows'].get(phase)
                rows.append([NAMES[m]]+([scope(w,'on_chip','energy_j_per_token'),scope(w,'on_chip_plus_ddr','energy_j_per_token'),scope(w,'on_chip_plus_ddr','average_power_w')] if w else ['待重算']*3))
            table(['模型','片上 J/token','片上＋DDR J/token','片上＋DDR W'],rows,[155,110,120,110])
        p('四个仍显示数值的模型属于既有 E32-9 同源版本，E32-18 重测尚未验收。无完整 P512 实测误差界；这些数据仅为已覆盖条件估算。',small)
        page('200 MHz 短 Prefill');intro()
        p('短 P2 与 P512 使用不同窗口。已更新 300 MHz 基线的三模型，200 MHz 对应值等待匹配重算。')
        rows=[]
        for m in ORDER:
            w=current[m]['windows'].get('short_prefill')
            rows.append([NAMES[m]]+([scope(w,'on_chip','energy_j_per_token'),scope(w,'on_chip_plus_ddr','energy_j_per_token'),scope(w,'on_chip','average_power_w'),scope(w,'on_chip_plus_ddr','average_power_w')] if w else ['待重算']*4))
        table(['短 P2','片上 J/token','片上＋DDR J/token','片上 W','片上＋DDR W'],rows,[125,95,95,90,90])
        p('四模型保留值的算术、控制、SRAM 和 DDR 范围见历史附录；没有把 300 MHz 新母控外围或读 DMA 系数直接套入 200 MHz。缺项仍按对应版本保留。')
        page('200 MHz 来源与待更新范围');intro()
        table(['项目','已发布来源','当前结论'],[
            ['短 P2 / Decode','成对代表层 v1，c9caea1f','E32-9；三模型新基线待迁移'],
            ['P512 速度','prefill-v3，6efee9ab','200 MHz 直接曲线，起点仍来自旧短窗'],
            ['P512 / 短窗能耗','power-v4，7150d6de','算术 v3＋控制 v4；未吸收 E32-18／新读 DMA'],
            ['递推候选 RTL','recurrent-step1 本地回执','引脚预检通过；尚非完整能耗标定']],[118,178,199])
        p('200 MHz 能耗不能用 300 MHz 功率乘 2/3 得到。应把动态事件数、驻留时间、漏电和 DDR 后台/刷新分开，按匹配新短窗和 P512 的时间线重新积分。')
        p('本轮没有提交新仿真，也没有修改主线或其他侧线账本。当前同步仅接收已验收工件并明确列出依赖缺口，不把旧派生值自动改写成新基线结果。')
        p('下一次同步需核对：七模型 E32-18 验收是否收齐；成对代表层与长上下文曲线是否重采样或证明仍适用；两档 P512 能耗积分是否完成；读 DMA 和候选算术是否与物理部署、接口及时序相匹配。')
        p('以下历史附录保留完整七模型旧结果、范围、优化和方法。它可用于复查之前版本，但受新基线影响的值不可直接引用为最新。',small)

    front=out/f'front-{kind}-{freq}.pdf'
    def footer(c,doc):
        c.saveState();c.setStrokeColor(teal);c.line(45,36,550,36);c.setFont('CN',8);c.setFillColor(ink)
        c.drawString(45,23,f'SYNC-04 | {freq} MHz | 当前增量 | 条件估算');c.drawRightString(550,23,str(doc.page));c.restoreState()
    SimpleDocTemplate(str(front),pagesize=A4,leftMargin=45,rightMargin=45,topMargin=44,bottomMargin=48).build(story,onFirstPage=footer,onLaterPages=footer)
    fr=PdfReader(front);assert len(fr.pages)==pages,(front,len(fr.pages),pages)
    text=''.join((p.extract_text() or '') for p in fr.pages)
    assert all(v in text for v in expected)
    writer=PdfWriter();writer.append(fr)
    historical=PdfReader(out/'inputs'/OLD/f'seven-model-{kind}-{freq}mhz-sync03.pdf')
    buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=A4);c.setFont('CNB',9);c.setFillColor(orange)
    c.drawCentredString(A4[0]/2,A4[1]-23,'历史附录  SYNC-03 / E32-9  |  不代表 E32-18 最新重测结果');c.save();buf.seek(0)
    stamp=PdfReader(buf).pages[0]
    for page_obj in historical.pages:page_obj.merge_page(stamp);writer.add_page(page_obj)
    dest=out/f'seven-model-{kind}-{freq}mhz-sync04.pdf';writer.write(dest);writer.close()
    return {'file':dest.name,'pages':len(fr.pages)+len(historical.pages),'current_pages':len(fr.pages),
        'historical_pages':len(historical.pages),'numeric_cells_checked':len(expected),'sha256':sha(dest.read_bytes())}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--context',type=Path);p.add_argument('--snapshot',type=Path);p.add_argument('--render-only',action='store_true')
    a=p.parse_args()
    if a.render_only:
        out=a.output.resolve();data=json.loads((out/'frequency-estimates.json').read_bytes());context=json.loads((out/'sync-context.json').read_bytes())
        records=[render(out,f,k,data,context) for f in (300,200) for k in ('speed','power')]
        validation=json.loads((out/'validation.json').read_bytes());validation.update(files=records,pdf_visual_review='pending')
        dump(out/'validation.json',validation);print(json.dumps(records,indent=2))
    else:
        assert a.context,'--context is required for a new snapshot'
        build(a.output.resolve(),json.loads(a.context.read_bytes()),a.snapshot.resolve() if a.snapshot else None)
