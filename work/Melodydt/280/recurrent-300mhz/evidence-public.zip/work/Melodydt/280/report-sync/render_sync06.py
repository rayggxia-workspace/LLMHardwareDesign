"""Render current 300 MHz and clearly labeled historical 200 MHz summaries."""
import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab import rl_config
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, PageBreak, Spacer
from pypdf import PdfReader
from build_sync04_reports import ORDER,NAMES,sha,dump

OPT={
 'qwen3':'三 P FFN；注意力分片和双窗口，P512 使用 0/14/27 代表层映射。',
 'llama':'64 维紧凑 KV、256 B 行与 V 读取复用；保留自身上下文曲线。',
 'granite':'top-8/40 专家按 3/3/2 分给三 P；专家 Mid 保留在本地 SRAM，ATT 增长与专家路由成本分开。',
 'phi':'融合 QKV 与 Gate/Up、128 维 ATT1、V 流水和 partial LongRoPE；采用自身曲线。',
 'gemma':'256 维宽注意力；Q12 残差及后归一化，保留局部/全局注意力和 GELU 特殊路径。',
 'qwen35':'8 个 ATT 与 24 个 GDN 层；真实卷积/递推历史通过 DDR 显式恢复读写，仅 ATT 随 KV 长度增长。',
 'falcon':'32 层每层 Mamba2 后执行 ATT，保持串行依赖；递推状态维度固定，仅 ATT 随上下文增长。'}
GAPS='未覆盖/未验收：实际物理 top/provider/原生 ABI、路由与门控绑定，完整 RTL 控制状态驻留，全局时钟及跨块互连、DDR PHY/封装/板级；M 的300 MHz时序仍未闭合。布线寄生按本路线主动排除。'
SPECIAL={
 'qwen3':'公共算术仍为样本迁移；无新增模型专属 RTL 优化。',
 'llama':'公共算术仍为样本迁移；长上下文形状并非完整序列验证。',
 'granite':'长提示自然专家路由、专家驻留及状态分布仍未知。',
 'phi':'长上下文非线性仍依赖采样形状迁移，完整 P512 误差未知。',
 'gemma':'默认 GELU 保留运算级代理；匹配定点候选单列，FP32转换与周期未接入。',
 'qwen35':'默认 GDN 状态、卷积、浮点因子等仍有代理；200 MHz R 候选未迁入300 MHz。',
 'falcon':'默认 Mamba 状态、卷积、浮点因子等仍有代理；外部注入、格式转换和候选周期仍未闭合。'}

def metric(e,t,n):
    return {'energy_j_per_window':e,'energy_j_per_token':[x/n for x in e],
            'average_power_w':[x/t for x in e],'tokens_per_joule':[n/e[1],n/e[0]]}

def dma_envelope(w):
    scopes={}
    for scope in ('on_chip','on_chip_plus_ddr'):
        e=[min(s['scopes'][scope]['energy_j_per_window'][0] for s in w['dma_scenarios'].values()),
           max(s['scopes'][scope]['energy_j_per_window'][1] for s in w['dma_scenarios'].values())]
        scopes[scope]=metric(e,w['duration_s'],w['tokens'])
    return dict(w,scopes=scopes)

def short_dma(data,model,name):
    phase='prefill' if name=='short_prefill' else 'decode';key='prefill' if name=='short_prefill' else name
    ledger=data['scenario_ledgers'][model+'-'+phase]['dma'];w=data['current']['300'][model]['windows'][name]
    scenarios={}
    for variant,s in ledger['scenarios'].items():
        v=s['windows'][key];scopes={}
        for scope,k in [('on_chip','estimated_on_chip'),('on_chip_plus_ddr','estimated_on_chip_plus_ddr')]:
            scopes[scope]=metric([x*1e-9 for x in v[k]['energy_nj_per_window']],w['duration_s'],w['tokens'])
        scenarios[variant]={'scopes':scopes}
    return dict(w,dma_scenarios=scenarios)

def grouped_components(w):
    groups={k:[0.,0.] for k in ('M计算与驻留','数据SRAM','控制/PM/路由参考','公共算术与驻留','特殊算术代理','写DMA')}
    for key,v in w['components'].items():
        group=('M计算与驻留' if key.startswith('m_') else '数据SRAM' if key.startswith('s_p_') else
               '写DMA' if key.startswith('write_dma_') else '特殊算术代理' if key.startswith('proxy_') else
               '公共算术与驻留' if key.startswith(('rms_','measured_','arithmetic_','chunk_','g32_','u_add')) else '控制/PM/路由参考')
        for i in (0,1):groups[group][i]+=v['energy_nj_per_window'][i]/1e6/w['tokens']
    return groups

def render_all(out):
    data=json.loads((out/'frequency-estimates.json').read_bytes());context=json.loads((out/'sync-context.json').read_bytes())
    records=[render(out,f,k,data,context) for f in (300,200) for k in ('speed','power')]
    validation=json.loads((out/'validation.json').read_bytes());validation.update(files=records,pdf_visual_review='pending')
    dump(out/'validation.json',validation)

def render(out,freq,kind,data,context):
    pdfmetrics.registerFont(TTFont('CN','C:/Windows/Fonts/Deng.ttf'));pdfmetrics.registerFont(TTFont('CNB','C:/Windows/Fonts/Dengb.ttf'));rl_config.invariant=1
    ink=colors.HexColor('#183044');teal=colors.HexColor('#006c70')
    body=ParagraphStyle('body',fontName='CN',fontSize=9.6,leading=14.5,spaceAfter=8,textColor=ink,wordWrap='CJK')
    title=ParagraphStyle('title',parent=body,fontName='CNB',fontSize=21,leading=28,spaceAfter=14)
    small=ParagraphStyle('small',parent=body,fontSize=8.3,leading=12)
    cell=ParagraphStyle('cell',parent=small,spaceAfter=0,fontSize=8,leading=11.3)
    story=[];expected=[];pages=0;cur=data['current']['300'];hist=data['historical_sync03']['200']
    def p(s,style=body):story.append(Paragraph(escape(str(s)).replace('\n','<br/>'),style))
    def page(s):
        nonlocal pages
        if pages:story.append(PageBreak())
        pages+=1;p(s,title);p('SYNC-06 | '+context['snapshot_time'][:19]+' +08 | '+('当前300 MHz条件估算' if freq==300 else '200 MHz历史基线 / 待同源刷新'),small)
    def n(v,d=3):
        if isinstance(v,(tuple,list)):return ' - '.join(n(x,d) for x in v)
        if v is None:return '未提供'
        s=f'{v:.{d}f}';expected.append(s);return s
    def e(w,scope):return n([x*1000 for x in w['scopes'][scope]['energy_j_per_token']])
    def power(w,scope):return n(w['scopes'][scope]['average_power_w'])
    def table(headers,rows,widths):
        t=Table([[Paragraph(escape(str(x)).replace('\n','<br/>'),cell) for x in row] for row in [headers]+rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6f0f2')),('LINEBELOW',(0,0),(-1,0),.8,teal),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#cad7dc')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        story.append(t);story.append(Spacer(1,8))
    def energy_rows(windows):
        return [[label,e(w,'on_chip'),e(w,'on_chip_plus_ddr'),power(w,'on_chip'),power(w,'on_chip_plus_ddr')] for label,w in windows]
    energy_heads=['模型/窗口','片上\nmJ/token','片上＋DDR\nmJ/token','片上 W','片上＋DDR W']
    energy_widths=[111,98,105,88,93]
    if kind=='speed' and freq==300:
        page('七模型 300 MHz 速度')
        p('W8A16、512-bit数据SRAM、三P并行FFN。核心3334 ps（名义300 MHz），DDR独立630 ps。短P2是两个输入token；Decode为512历史起点两步测试中的第二步。',small)
        table(['模型','短 P2\ntoken/s','P512估计\ntoken/s','P512至logits\ns','Decode2\ntoken/s'],[[NAMES[m],n(cur[m]['windows']['short_prefill']['tokens_per_second']),n(cur[m]['prefill512_tok_s']),n(cur[m]['prefill512_s']),n(cur[m]['windows']['decode']['tokens_per_second'])] for m in ORDER],[139,83,88,95,90])
        p('七模型短窗均为E32-18重测验收；P512为逐位置外推，启动及末次词表头各计一次。没有完整512-token实跑，误差未知；中间上下文仍迁移旧采样曲线形状。')
        p('本次完善：',small)
        for s in context['new_changes'][:3]:p(s,small)
        p('来源：主线PR281@e29d72a5；P512第3版PR294@'+context['p512_published_commit'][:8]+'，冻结结果SHA见随附清单。21短窗和7个P512窗口均区分片上/片上＋DDR。',small)
        page('速度变化与逐模型优化')
        table(['模型','短P2变化 %','Decode2变化 %','沿用的专项调度/处理'],[[NAMES[m],n(data['delta_vs_sync05'][m]['short_prefill']['throughput_change_percent']),n(data['delta_vs_sync05'][m]['decode']['throughput_change_percent']),OPT[m]] for m in ORDER],[108,72,78,237])
        p('变化相对SYNC-05当前表：Qwen3/Llama/Granite已在上版更新，Falcon的短P2也已更新。本次主要补齐余下模型/阶段。E32由9修正为18周期后重新仲裁共享资源；速度下降是计时修正，不能解释为硬件退化。')
        p('共同继承PR272权重供给/FFN调度与三P部署，保留DDR/SRAM争用。专项优化不是本次新增RTL。数值文件及流量对账通过，仍不等于整模型FP32 RTL、物理绑定或300 MHz时序签核。',small)
    elif kind=='speed':
        page('200 MHz 速度：历史基线')
        p('本次没有匹配新E32-18基线的200 MHz重算。下表是既有#293已发布结果，便于复用；全部不再标为最新300 MHz的同源派生值。')
        table(['模型','旧短P2\ntoken/s','旧P512\ntoken/s','旧P512\ns','旧Decode2\ntoken/s'],[[NAMES[m],n(hist[m]['windows']['short_prefill']['tokens_per_second']),n(hist[m]['prefill512_tok_s']),n(hist[m]['prefill512_s']),n(hist[m]['windows']['decode']['tokens_per_second'])] for m in ORDER],[139,83,88,95,90])
        p('方法保留：核心5000 ps、DDR630 ps；短P2/Decode按固定DDR的成对代表层重建，P512采用200 MHz直接组件曲线与完整层锚点。不能将新300 MHz时间统一乘1.5，也不能将其功率统一乘2/3。')
        p('待更新链：新300 MHz短窗 → 200 MHz同配置成对代表层及共享资源计时 → 新P512位置积分 → 对应事件/驻留/DDR能耗积分。旧200 MHz与新300 MHz的数值比值不代表纯频率收益。')
        p('来源：#293 results-200mhz、prefill-v3、power-v4@7150d6de；继承算术v3和控制v4。各模型沿用的优化与当前300 MHz报告逐模型说明一致，硬件配置与覆盖版本仍须重新核对。',small)
    elif freq==300:
        for phase,title_text in [('prefill512','300 MHz P512功率与能耗'),('decode','300 MHz Decode功率与能耗')]:
            page(title_text)
            p('主表包含一个读DMA的条件场景包络；四种DMA互为替代，不相加。片上＋DDR只加DRAM器件能量，不包含PHY/封装/板级。范围是模型/样本/场景端点，不是置信区间。',small)
            wins=[(NAMES[m],dma_envelope(cur[m]['windows'][phase] if phase=='prefill512' else short_dma(data,m,phase))) for m in ORDER]
            table(energy_heads,energy_rows(wins),energy_widths)
            if phase=='prefill512':
                p('P512能耗与速度使用同一512位置窗口；未把短P2能耗乘256。固定工作逐token累计，启动和输出头各一次，KV相关SRAM/softmax/DDR命令按位置增长，驻留与DDR后台/刷新按时间累计。')
                p('P512第3版已消除Phi/Gemma/Qwen3.5的旧Decode端点临时假设；所有模型端点统一E32-18。中间曲线形状、MoE自然路由及混合模型中间状态仍为条件迁移。',small)
            else:
                p('该表对应第二步单token窗口；首步及短P2在后续逐模型页。M动态增量使用实际新忙区间并集，驻留项随新时间积分；已验事件项按守恒复用，DDR采用新器件账本。',small)
                p('新增覆盖：母控外围参考、M精确TLM忙区间、四版读DMA配对引脚标定。默认特殊算术代理仍保留；定点候选先去掉匹配旧代理再替换，另页列出。',small)
            p(GAPS,small)
        for m in ORDER:
            page(NAMES[m]+'：分项与边界')
            p('以下基础小计不含读DMA。窗口时间与E32-18匹配；读DMA通过后表每次选一个方案加入。',small)
            table(energy_heads,energy_rows([(label,cur[m]['windows'][key]) for key,label in [('short_prefill','短P2 / 2输入'),('first_token','首Decode / 1输出'),('decode','Decode2 / 1输出'),('prefill512','P512 / 512输入')]]),energy_widths)
            w=data['scenario_ledgers'][m+'-decode']['timing']['windows']['decode']
            groups=grouped_components(w)
            table(['Decode2基础片上分项','mJ/token','Decode2基础片上分项','mJ/token'],[[a,n(groups[a]),b,n(groups[b])] for a,b in [('M计算与驻留','数据SRAM'),('控制/PM/路由参考','公共算术与驻留'),('特殊算术代理','写DMA')]],[137,110,138,110])
            sw=short_dma(data,m,'decode')
            table(['Decode2读DMA方案（互斥）','新增读DMA mJ/token','含DMA片上 mJ/token'],[[v,n([(s['scopes']['on_chip']['energy_j_per_window'][i]-cur[m]['windows']['decode']['scopes']['on_chip']['energy_j_per_window'][i])*1000 for i in (0,1)]),e(s,'on_chip')] for v,s in sw['dma_scenarios'].items()],[177,159,159])
            p('专项调度：'+OPT[m],small)
            p('本模型未覆盖：'+SPECIAL[m]+' 读DMA唯一实例/owner尚未绑定，phase已包含shared，禁止两者叠加。',small)
            p(GAPS,small)
        page('特殊候选与复用边界')
        p('以下仅为匹配特殊算子的条件替换：删除原代理，再加Conv4、EXP/sigmoid/softplus/GELU等候选及残余项。包含一个读DMA的跨方案包络；未改吞吐、未重算候选执行周期。')
        rows=[]
        for m in ORDER:
            w=data['scenario_ledgers'][m+'-decode']['special']['windows']['decode'];sc=w['dma_scenarios']
            def er(k):return [min(v[k]['energy_mj_per_token'][0] for v in sc.values()),max(v[k]['energy_mj_per_token'][1] for v in sc.values())]
            rows.append([NAMES[m],n(er('estimated_on_chip')),n(er('estimated_on_chip_plus_ddr'))])
        table(['Decode2特殊替换候选','片上 mJ/token','片上＋DDR mJ/token'],rows,[165,165,165])
        p('候选并非完整模型FP32数值验收。未包括完整浮点转换、复合运算/provider、递推状态存储、300 MHz物理绑定及候选周期重调度。200 MHz递推R候选不得直接搬入此表。')
        p('DMA和特殊算子标定将观测RTL位映射到对应单元引脚；未观测内部活动仍使用传播估计。匹配引脚集合全部标注不等于全芯片门级活动实测。',small)
        p('复用：frequency-estimates.json保存三类账本、四种DMA场景、28个当前窗口和历史200 MHz表；source-manifest及source-consistency保存输入SHA、单位守恒与去重检查。只在版本、时间窗口和部署假设一致时比较。',small)
    else:
        page('200 MHz历史功耗：P512')
        p('算术v3＋控制v4已发布小计，非匹配新300 MHz E32-18的重算结果。默认未含读DMA，不与新版含DMA范围直接比较。')
        table(energy_heads,energy_rows([(NAMES[m],hist[m]['windows']['prefill512']) for m in ORDER]),energy_widths)
        p('保留同窗速度、能耗和功率；功耗升级不是速度重测。漏电/空闲驻留、事件能量和DDR命令/背景分别处理，既有P512结果仍是外推而非完整序列实跑。',small)
        p('未覆盖：实际读DMA，母控外围完整绑定与真实RTL驻留，各模型部署/门控及特殊算子完整RTL，全局时钟/互连、DDR PHY/封装/板级。新300 MHz母控外围/读DMA及E32修正未自动并入本表。',small)
        for m in ORDER:p(NAMES[m]+'：'+SPECIAL[m],small)
        page('200 MHz历史功耗：短窗')
        p('第二步Decode / 单输出token',small)
        table(energy_heads,energy_rows([(NAMES[m],hist[m]['windows']['decode']) for m in ORDER]),energy_widths)
        p('短P2 / 两个输入token',small)
        table(['模型','片上 mJ/token','片上＋DDR mJ/token'],[[NAMES[m],e(hist[m]['windows']['short_prefill'],'on_chip'),e(hist[m]['windows']['short_prefill'],'on_chip_plus_ddr')] for m in ORDER],[165,165,165])
        p('表内未包含P512的长上下文增长；相同模型不同窗口不可混用。完整分项保留JSON；缺项同上页。',small)
        page('200 MHz递推R候选：单独场景')
        p('Qwen3.5/Falcon基于旧R3账本的第一轮候选交付保持独立。先删原递推代理，再加入一个分时复用8-lane R的load/execute/readback活动和驻留；24对活动/空闲窗口门级标定已完成。')
        rows=[]
        for model in data['recurrent_candidate_200']['models']:
            for phase,w in model['windows'].items():
                a=w['candidate']['on_chip'];b=w['candidate']['on_chip_plus_ddr']
                rows.append([model['name']+' / '+('短P2' if phase=='prefill' else 'Decode2'),n(a['mj_per_token']),n(b['mj_per_token']),n(a['mean_w']),n(b['mean_w'])])
        table(energy_heads,rows,energy_widths)
        p('与原R3状态代理相比，Decode能耗区间宽度分别收窄约84.9%和92.8%；这是同账本局部代理替换的范围变化，不是整模型实测误差界。')
        p('未覆盖：真实长序列中间状态、端到端浮点精度、格式转换、接入互连；Falcon外部注入代理仍保留。Prefill采样为零初态，仅支持冷状态外推，未得到候选P512能耗。')
        p('这些候选没有更新吞吐，也未接入新E32-18、母控外围和读DMA账本。下一轮应先统一频率、时间窗口及覆盖，再判断候选是否可替换默认项；不能直接移植到300 MHz。',small)
        p('本轮仅整理报告；未提交、取消或修改仿真作业。完整硬件绑定、独立审查和PR合并仍未完成。',small)
    dest=out/f'seven-model-{kind}-{freq}mhz-sync06.pdf'
    def footer(c,doc):
        c.saveState();c.setStrokeColor(teal);c.line(45,36,550,36);c.setFont('CN',8);c.setFillColor(ink)
        c.drawString(45,23,f'SYNC-06 | {freq} MHz | '+('当前条件估算' if freq==300 else '历史基线 / 待同源重算'));c.drawRightString(550,23,str(doc.page));c.restoreState()
    SimpleDocTemplate(str(dest),pagesize=A4,leftMargin=45,rightMargin=45,topMargin=44,bottomMargin=48).build(story,onFirstPage=footer,onLaterPages=footer)
    reader=PdfReader(dest);assert len(reader.pages)==pages,(dest,len(reader.pages),pages)
    text=''.join(p.extract_text() or '' for p in reader.pages);assert all(x in text for x in expected)
    return {'file':dest.name,'pages':pages,'current_pages':pages,'historical_pages':0,'numeric_cells_checked':len(expected),'sha256':sha(dest.read_bytes())}
