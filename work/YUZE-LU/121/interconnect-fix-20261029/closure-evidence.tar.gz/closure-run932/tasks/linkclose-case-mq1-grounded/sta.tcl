set_thread_count 16
read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-prepare-mq1/m-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-prepare-mq1/t-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-prepare-mq1/bridge-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-prepare-mq1/booster-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-case-mq1-grounded/wrapper.v}
link_design interconnect_fixture
set_cmd_units -time ns -capacitance fF -resistance kOhm -distance um
set_units -time ns -capacitance fF -resistance kOhm -distance um
create_clock -name core -period 3.333333333333333 [get_ports clk]
set_clock_uncertainty 0.1 [get_clocks core]
set_clock_transition 0.05 [get_clocks core]
set data_inputs {}
foreach p [all_inputs] {if {[get_full_name $p] ne "clk"} {lappend data_inputs $p}}
set_input_delay -clock core -min 0.2 $data_inputs
set_input_delay -clock core -max 0.8 $data_inputs
set_output_delay -clock core -min 0.2 [all_outputs]
set_output_delay -clock core -max 0.8 [all_outputs]
set_driving_cell -lib_cell BUF_X2 -pin Z $data_inputs
set_load 50 [all_outputs]
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-prepare-mq1/prepared/common-direct.spef}
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/tasks/linkclose-case-mq1-grounded/links.spef}
set_propagated_clock [all_clocks]
sta::find_timing
report_units
write_sdc -digits 12 constraints-readback.sdc
report_parasitic_annotation -report_unannotated > annotation.rpt
set f [open summary.tsv w]
puts $f "setup_count\t[sta::endpoint_violation_count max]"
puts $f "hold_count\t[sta::endpoint_violation_count min]"
puts $f "time_unit_seconds\t[sta::time_ui_sta 1]"
puts $f "cap_unit_farads\t[sta::capacitance_ui_sta 1]"
foreach kind {capacitance slew fanout} {
 puts $f "$kind\t[sta::max_${kind}_violation_count]\t[sta::max_${kind}_check_slack]\t[sta::max_${kind}_check_limit]"
}
close $f
report_worst_slack -max -digits 12 > timing.rpt
report_worst_slack -min -digits 12 >> timing.rpt
report_checks -path_delay min_max -group_path_count 5 -format full_clock_expanded -digits 12 >> timing.rpt
report_check_types -max_capacitance -max_slew -max_fanout -violators -digits 12 -no_line_splits > electrical.rpt
set setup_stream [open check-setup.rpt w]
puts $setup_stream [check_setup -verbose]
close $setup_stream
set f [open links.tsv w]
set source_name {u_m/wire2920/Z}
set sink_names [list {u_bridge/hold191/A} {u_bridge/bv1_input_diode_7/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2892/Z}
set sink_names [list {u_bridge/hold189/A} {u_bridge/bv1_input_diode_46/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n001	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n001	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2891/Z}
set sink_names [list {u_bridge/hold193/A} {u_bridge/bv1_input_diode_57/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n002	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n002	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16775/Z}
set sink_names [list {u_bridge/hold188/A} {u_bridge/bv1_input_diode_68/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n003	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n003	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16770/Z}
set sink_names [list {u_bridge/hold194/A} {u_bridge/bv1_input_diode_79/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n004	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n004	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16759/Z}
set sink_names [list {u_bridge/hold190/A} {u_bridge/bv1_input_diode_90/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n005	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n005	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16754/Z}
set sink_names [list {u_bridge/hold208/A} {u_bridge/bv1_input_diode_101/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n006	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n006	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9005/Z}
set sink_names [list {u_bridge/hold205/A} {u_bridge/bv1_input_diode_112/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n007	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n007	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9004/Z}
set sink_names [list {u_bridge/hold200/A} {u_bridge/bv1_input_diode_123/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n008	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n008	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9003/Z}
set sink_names [list {u_bridge/hold196/A} {u_bridge/bv1_input_diode_134/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n009	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n009	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16794/Z}
set sink_names [list {u_bridge/hold195/A} {u_bridge/bv1_input_diode_18/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n010	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n010	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9016/Z}
set sink_names [list {u_bridge/hold201/A} {u_bridge/bv1_input_diode_29/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n011	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n011	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16791/Z}
set sink_names [list {u_bridge/hold192/A} {u_bridge/bv1_input_diode_38/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n012	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n012	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16790/Z}
set sink_names [list {u_bridge/hold204/A} {u_bridge/bv1_input_diode_39/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n013	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n013	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16789/Z}
set sink_names [list {u_bridge/hold206/A} {u_bridge/bv1_input_diode_40/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n014	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n014	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2893/Z}
set sink_names [list {u_bridge/hold244/A} {u_bridge/bv1_input_diode_41/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n015	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n015	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9015/Z}
set sink_names [list {u_bridge/hold210/A} {u_bridge/bv1_input_diode_42/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n016	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n016	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9014/Z}
set sink_names [list {u_bridge/hold209/A} {u_bridge/bv1_input_diode_43/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n017	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n017	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16788/Z}
set sink_names [list {u_bridge/hold207/A} {u_bridge/bv1_input_diode_44/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n018	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n018	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16787/Z}
set sink_names [list {u_bridge/hold202/A} {u_bridge/bv1_input_diode_45/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n019	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n019	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16786/Z}
set sink_names [list {u_bridge/hold177/A} {u_bridge/bv1_input_diode_47/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n020	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n020	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9013/Z}
set sink_names [list {u_bridge/hold216/A} {u_bridge/bv1_input_diode_48/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n021	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n021	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16785/Z}
set sink_names [list {u_bridge/hold222/A} {u_bridge/bv1_input_diode_49/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n022	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n022	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16784/Z}
set sink_names [list {u_bridge/hold215/A} {u_bridge/bv1_input_diode_50/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n023	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n023	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9012/Z}
set sink_names [list {u_bridge/hold185/A} {u_bridge/bv1_input_diode_51/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n024	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n024	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16783/Z}
set sink_names [list {u_bridge/hold217/A} {u_bridge/bv1_input_diode_52/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n025	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n025	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9011/Z}
set sink_names [list {u_bridge/hold183/A} {u_bridge/bv1_input_diode_53/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n026	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n026	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9010/Z}
set sink_names [list {u_bridge/hold181/A} {u_bridge/bv1_input_diode_54/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n027	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n027	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9009/Z}
set sink_names [list {u_bridge/hold178/A} {u_bridge/bv1_input_diode_55/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n028	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n028	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9008/Z}
set sink_names [list {u_bridge/hold184/A} {u_bridge/bv1_input_diode_56/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n029	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n029	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9007/Z}
set sink_names [list {u_bridge/hold260/A} {u_bridge/bv1_input_diode_58/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n030	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n030	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16782/Z}
set sink_names [list {u_bridge/hold179/A} {u_bridge/bv1_input_diode_59/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n031	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n031	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16781/Z}
set sink_names [list {u_bridge/hold241/A} {u_bridge/bv1_input_diode_60/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n032	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n032	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16780/Z}
set sink_names [list {u_bridge/hold173/A} {u_bridge/bv1_input_diode_61/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n033	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n033	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16779/Z}
set sink_names [list {u_bridge/hold243/A} {u_bridge/bv1_input_diode_62/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n034	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n034	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16778/Z}
set sink_names [list {u_bridge/hold228/A} {u_bridge/bv1_input_diode_63/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n035	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n035	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2890/Z}
set sink_names [list {u_bridge/hold174/A} {u_bridge/bv1_input_diode_64/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n036	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n036	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16777/Z}
set sink_names [list {u_bridge/hold176/A} {u_bridge/bv1_input_diode_65/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n037	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n037	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16776/Z}
set sink_names [list {u_bridge/hold245/A} {u_bridge/bv1_input_diode_66/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n038	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n038	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2889/Z}
set sink_names [list {u_bridge/hold254/A} {u_bridge/bv1_input_diode_67/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n039	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n039	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2888/Z}
set sink_names [list {u_bridge/hold238/A} {u_bridge/bv1_input_diode_69/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n040	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n040	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16774/Z}
set sink_names [list {u_bridge/hold203/A} {u_bridge/bv1_input_diode_70/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n041	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n041	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2887/Z}
set sink_names [list {u_bridge/hold198/A} {u_bridge/bv1_input_diode_71/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n042	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n042	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16773/Z}
set sink_names [list {u_bridge/hold199/A} {u_bridge/bv1_input_diode_72/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n043	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n043	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2886/Z}
set sink_names [list {u_bridge/hold197/A} {u_bridge/bv1_input_diode_73/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n044	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n044	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16772/Z}
set sink_names [list {u_bridge/hold211/A} {u_bridge/bv1_input_diode_74/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n045	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n045	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2885/Z}
set sink_names [list {u_bridge/hold180/A} {u_bridge/bv1_input_diode_75/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n046	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n046	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2884/Z}
set sink_names [list {u_bridge/hold175/A} {u_bridge/bv1_input_diode_76/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n047	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n047	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9006/Z}
set sink_names [list {u_bridge/hold276/A} {u_bridge/bv1_input_diode_77/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n048	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n048	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16771/Z}
set sink_names [list {u_bridge/hold277/A} {u_bridge/bv1_input_diode_78/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n049	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n049	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16769/Z}
set sink_names [list {u_bridge/hold275/A} {u_bridge/bv1_input_diode_80/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n050	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n050	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16768/Z}
set sink_names [list {u_bridge/hold268/A} {u_bridge/bv1_input_diode_81/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n051	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n051	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16767/Z}
set sink_names [list {u_bridge/hold271/A} {u_bridge/bv1_input_diode_82/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n052	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n052	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16766/Z}
set sink_names [list {u_bridge/hold269/A} {u_bridge/bv1_input_diode_83/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n053	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n053	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16765/Z}
set sink_names [list {u_bridge/hold264/A} {u_bridge/bv1_input_diode_84/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n054	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n054	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16764/Z}
set sink_names [list {u_bridge/hold224/A} {u_bridge/bv1_input_diode_85/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n055	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n055	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16763/Z}
set sink_names [list {u_bridge/hold218/A} {u_bridge/bv1_input_diode_86/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n056	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n056	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16762/Z}
set sink_names [list {u_bridge/hold221/A} {u_bridge/bv1_input_diode_87/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n057	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n057	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16761/Z}
set sink_names [list {u_bridge/hold223/A} {u_bridge/bv1_input_diode_88/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n058	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n058	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16760/Z}
set sink_names [list {u_bridge/hold214/A} {u_bridge/bv1_input_diode_89/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n059	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n059	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16758/Z}
set sink_names [list {u_bridge/hold220/A} {u_bridge/bv1_input_diode_91/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n060	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n060	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16757/Z}
set sink_names [list {u_bridge/hold182/A} {u_bridge/bv1_input_diode_92/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n061	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n061	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16756/Z}
set sink_names [list {u_bridge/hold186/A} {u_bridge/bv1_input_diode_93/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n062	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n062	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16755/Z}
set sink_names [list {u_bridge/hold187/A} {u_bridge/bv1_input_diode_94/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n063	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n063	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2883/Z}
set sink_names [list {u_bridge/hold278/A} {u_bridge/bv1_input_diode_95/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n064	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n064	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2882/Z}
set sink_names [list {u_bridge/hold285/A} {u_bridge/bv1_input_diode_96/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n065	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n065	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2881/Z}
set sink_names [list {u_bridge/hold288/A} {u_bridge/bv1_input_diode_97/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n066	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n066	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2880/Z}
set sink_names [list {u_bridge/hold282/A} {u_bridge/bv1_input_diode_98/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n067	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n067	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2879/Z}
set sink_names [list {u_bridge/hold284/A} {u_bridge/bv1_input_diode_99/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n068	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n068	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2878/Z}
set sink_names [list {u_bridge/hold286/A} {u_bridge/bv1_input_diode_100/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n069	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n069	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2877/Z}
set sink_names [list {u_bridge/hold279/A} {u_bridge/bv1_input_diode_102/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n070	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n070	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2876/Z}
set sink_names [list {u_bridge/hold289/A} {u_bridge/bv1_input_diode_103/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n071	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n071	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2875/Z}
set sink_names [list {u_bridge/input104/A} {u_bridge/bv1_input_diode_104/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n072	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n072	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2874/Z}
set sink_names [list {u_bridge/input105/A} {u_bridge/bv1_input_diode_105/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n073	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n073	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2873/Z}
set sink_names [list {u_bridge/input106/A} {u_bridge/bv1_input_diode_106/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n074	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n074	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2872/Z}
set sink_names [list {u_bridge/input107/A} {u_bridge/bv1_input_diode_107/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n075	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n075	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2871/Z}
set sink_names [list {u_bridge/input108/A} {u_bridge/bv1_input_diode_108/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n076	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n076	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2870/Z}
set sink_names [list {u_bridge/input109/A} {u_bridge/bv1_input_diode_109/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n077	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n077	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2869/Z}
set sink_names [list {u_bridge/bv1_input_diode_110/A} {u_bridge/input110/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n078	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n078	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2868/Z}
set sink_names [list {u_bridge/input111/A} {u_bridge/bv1_input_diode_111/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n079	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n079	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16753/Z}
set sink_names [list {u_bridge/hold281/A} {u_bridge/bv1_input_diode_113/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n080	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n080	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16752/Z}
set sink_names [list {u_bridge/input114/A} {u_bridge/bv1_input_diode_114/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n081	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n081	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16751/Z}
set sink_names [list {u_bridge/hold283/A} {u_bridge/bv1_input_diode_115/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n082	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n082	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16750/Z}
set sink_names [list {u_bridge/input116/A} {u_bridge/bv1_input_diode_116/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n083	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n083	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16749/Z}
set sink_names [list {u_bridge/input117/A} {u_bridge/bv1_input_diode_117/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n084	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n084	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16748/Z}
set sink_names [list {u_bridge/hold287/A} {u_bridge/bv1_input_diode_118/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n085	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n085	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16747/Z}
set sink_names [list {u_bridge/input119/A} {u_bridge/bv1_input_diode_119/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n086	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n086	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16746/Z}
set sink_names [list {u_bridge/hold280/A} {u_bridge/bv1_input_diode_120/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n087	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n087	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16745/Z}
set sink_names [list {u_bridge/input121/A} {u_bridge/bv1_input_diode_121/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n088	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n088	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16744/Z}
set sink_names [list {u_bridge/input122/A} {u_bridge/bv1_input_diode_122/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n089	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n089	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16743/Z}
set sink_names [list {u_bridge/input124/A} {u_bridge/bv1_input_diode_124/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n090	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n090	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16742/Z}
set sink_names [list {u_bridge/input125/A} {u_bridge/bv1_input_diode_125/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n091	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n091	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16741/Z}
set sink_names [list {u_bridge/input126/A} {u_bridge/bv1_input_diode_126/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n092	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n092	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16740/Z}
set sink_names [list {u_bridge/hold237/A} {u_bridge/bv1_input_diode_127/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n093	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n093	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16739/Z}
set sink_names [list {u_bridge/hold232/A} {u_bridge/bv1_input_diode_128/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n094	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n094	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16738/Z}
set sink_names [list {u_bridge/hold273/A} {u_bridge/bv1_input_diode_129/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n095	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n095	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2867/Z}
set sink_names [list {u_bridge/hold246/A} {u_bridge/bv1_input_diode_130/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n096	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n096	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2866/Z}
set sink_names [list {u_bridge/hold233/A} {u_bridge/bv1_input_diode_131/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n097	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n097	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2865/Z}
set sink_names [list {u_bridge/hold265/A} {u_bridge/bv1_input_diode_132/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n098	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n098	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2864/Z}
set sink_names [list {u_bridge/hold236/A} {u_bridge/bv1_input_diode_133/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n099	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n099	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2919/Z}
set sink_names [list {u_bridge/hold231/A} {u_bridge/bv1_input_diode_8/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n100	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n100	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2918/Z}
set sink_names [list {u_bridge/hold230/A} {u_bridge/bv1_input_diode_9/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n101	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n101	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2917/Z}
set sink_names [list {u_bridge/hold227/A} {u_bridge/bv1_input_diode_10/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n102	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n102	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2916/Z}
set sink_names [list {u_bridge/hold240/A} {u_bridge/bv1_input_diode_11/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n103	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n103	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2915/Z}
set sink_names [list {u_bridge/hold248/A} {u_bridge/bv1_input_diode_12/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n104	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n104	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2914/Z}
set sink_names [list {u_bridge/hold250/A} {u_bridge/bv1_input_diode_13/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n105	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n105	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2913/Z}
set sink_names [list {u_bridge/hold226/A} {u_bridge/bv1_input_diode_14/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n106	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n106	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2912/Z}
set sink_names [list {u_bridge/hold251/A} {u_bridge/bv1_input_diode_15/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n107	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n107	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2911/Z}
set sink_names [list {u_bridge/hold247/A} {u_bridge/bv1_input_diode_16/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n108	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n108	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2910/Z}
set sink_names [list {u_bridge/hold242/A} {u_bridge/bv1_input_diode_17/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n109	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n109	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2909/Z}
set sink_names [list {u_bridge/hold229/A} {u_bridge/bv1_input_diode_19/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n110	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n110	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2908/Z}
set sink_names [list {u_bridge/hold249/A} {u_bridge/bv1_input_diode_20/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n111	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n111	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16793/Z}
set sink_names [list {u_bridge/bv1_input_diode_21/A} {u_bridge/hold272/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n112	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n112	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire16792/Z}
set sink_names [list {u_bridge/hold256/A} {u_bridge/bv1_input_diode_22/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n113	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n113	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2907/Z}
set sink_names [list {u_bridge/hold261/A} {u_bridge/bv1_input_diode_23/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n114	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n114	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2906/Z}
set sink_names [list {u_bridge/hold274/A} {u_bridge/bv1_input_diode_24/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n115	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n115	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2905/Z}
set sink_names [list {u_bridge/hold253/A} {u_bridge/bv1_input_diode_25/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n116	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n116	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2904/Z}
set sink_names [list {u_bridge/hold239/A} {u_bridge/bv1_input_diode_26/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n117	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n117	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2903/Z}
set sink_names [list {u_bridge/hold267/A} {u_bridge/bv1_input_diode_27/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n118	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n118	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2902/Z}
set sink_names [list {u_bridge/hold258/A} {u_bridge/bv1_input_diode_28/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n119	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n119	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2901/Z}
set sink_names [list {u_bridge/hold270/A} {u_bridge/bv1_input_diode_30/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n120	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n120	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2900/Z}
set sink_names [list {u_bridge/hold263/A} {u_bridge/bv1_input_diode_31/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n121	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n121	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2899/Z}
set sink_names [list {u_bridge/hold262/A} {u_bridge/bv1_input_diode_32/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n122	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n122	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2898/Z}
set sink_names [list {u_bridge/hold266/A} {u_bridge/bv1_input_diode_33/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n123	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n123	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2897/Z}
set sink_names [list {u_bridge/hold252/A} {u_bridge/bv1_input_diode_34/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n124	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n124	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2896/Z}
set sink_names [list {u_bridge/hold257/A} {u_bridge/bv1_input_diode_35/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n125	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n125	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2895/Z}
set sink_names [list {u_bridge/hold255/A} {u_bridge/bv1_input_diode_36/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n126	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n126	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2894/Z}
set sink_names [list {u_bridge/hold259/A} {u_bridge/bv1_input_diode_37/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n127	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n127	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2861/Z}
set sink_names [list {u_bridge/input137/A} {u_bridge/bv1_input_diode_137/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n128	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n128	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2863/Z}
set sink_names [list {u_bridge/input135/A} {u_bridge/bv1_input_diode_135/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n129	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n129	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2862/Z}
set sink_names [list {u_bridge/input136/A} {u_bridge/bv1_input_diode_136/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n130	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n130	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire15650/Z}
set sink_names [list {u_bridge/input4/A} {u_bridge/bv1_input_diode_4/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n131	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n131	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_response_ready_0/Z}
set sink_names [list {u_m/hold18237/A} {u_m/bv1_input_diode_141/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n132	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n132	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_0/Z}
set sink_names [list {u_t/bv1_delay_probe_1200/A} {u_t/bv1_input_diode_51/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n133	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n133	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_1/Z}
set sink_names [list {u_t/bv1_delay_probe_2136/A} {u_t/bv1_input_diode_90/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n134	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n134	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_2/Z}
set sink_names [list {u_t/bv1_delay_probe_2400/A} {u_t/bv1_input_diode_101/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n135	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n135	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_3/Z}
set sink_names [list {u_t/bv1_delay_probe_2664/A} {u_t/bv1_input_diode_112/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n136	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n136	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_4/Z}
set sink_names [list {u_t/bv1_delay_probe_2928/A} {u_t/bv1_input_diode_123/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n137	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n137	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_5/Z}
set sink_names [list {u_t/bv1_delay_probe_3192/A} {u_t/bv1_input_diode_134/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n138	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n138	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_6/Z}
set sink_names [list {u_t/bv1_delay_probe_3456/A} {u_t/bv1_input_diode_145/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n139	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n139	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_7/Z}
set sink_names [list {u_t/bv1_input_diode_156/A} {u_t/bv1_delay_probe_3720/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n140	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n140	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_8/Z}
set sink_names [list {u_t/bv1_delay_probe_3984/A} {u_t/bv1_input_diode_167/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n141	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n141	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_9/Z}
set sink_names [list {u_t/bv1_delay_probe_4248/A} {u_t/bv1_input_diode_178/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n142	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n142	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_10/Z}
set sink_names [list {u_t/bv1_input_diode_62/A} {u_t/bv1_delay_probe_1464/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n143	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n143	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_11/Z}
set sink_names [list {u_t/bv1_delay_probe_1728/A} {u_t/bv1_input_diode_73/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n144	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n144	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_12/Z}
set sink_names [list {u_t/bv1_delay_probe_1944/A} {u_t/bv1_input_diode_82/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n145	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n145	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_13/Z}
set sink_names [list {u_t/bv1_delay_probe_1968/A} {u_t/bv1_input_diode_83/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n146	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n146	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_14/Z}
set sink_names [list {u_t/bv1_input_diode_84/A} {u_t/bv1_delay_probe_1992/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n147	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n147	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_15/Z}
set sink_names [list {u_t/bv1_delay_probe_2016/A} {u_t/bv1_input_diode_85/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n148	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n148	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_16/Z}
set sink_names [list {u_t/bv1_delay_probe_2040/A} {u_t/bv1_input_diode_86/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n149	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n149	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_17/Z}
set sink_names [list {u_t/bv1_delay_probe_2064/A} {u_t/bv1_input_diode_87/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n150	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n150	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_18/Z}
set sink_names [list {u_t/bv1_input_diode_88/A} {u_t/bv1_delay_probe_2088/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n151	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n151	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_19/Z}
set sink_names [list {u_t/bv1_input_diode_89/A} {u_t/bv1_delay_probe_2112/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n152	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n152	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_20/Z}
set sink_names [list {u_t/bv1_delay_probe_2160/A} {u_t/bv1_input_diode_91/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n153	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n153	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_21/Z}
set sink_names [list {u_t/bv1_delay_probe_2184/A} {u_t/bv1_input_diode_92/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n154	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n154	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_22/Z}
set sink_names [list {u_t/bv1_delay_probe_2208/A} {u_t/bv1_input_diode_93/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n155	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n155	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_23/Z}
set sink_names [list {u_t/bv1_input_diode_94/A} {u_t/bv1_delay_probe_2232/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n156	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n156	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_24/Z}
set sink_names [list {u_t/bv1_delay_probe_2256/A} {u_t/bv1_input_diode_95/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n157	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n157	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_25/Z}
set sink_names [list {u_t/bv1_delay_probe_2280/A} {u_t/bv1_input_diode_96/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n158	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n158	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_26/Z}
set sink_names [list {u_t/bv1_delay_probe_2304/A} {u_t/bv1_input_diode_97/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n159	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n159	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_27/Z}
set sink_names [list {u_t/bv1_delay_probe_2328/A} {u_t/bv1_input_diode_98/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n160	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n160	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_28/Z}
set sink_names [list {u_t/bv1_delay_probe_2352/A} {u_t/bv1_input_diode_99/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n161	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n161	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_29/Z}
set sink_names [list {u_t/bv1_delay_probe_2376/A} {u_t/bv1_input_diode_100/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n162	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n162	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_30/Z}
set sink_names [list {u_t/bv1_delay_probe_2424/A} {u_t/bv1_input_diode_102/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n163	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n163	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_31/Z}
set sink_names [list {u_t/bv1_delay_probe_2448/A} {u_t/bv1_input_diode_103/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n164	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n164	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_32/Z}
set sink_names [list {u_t/bv1_delay_probe_2472/A} {u_t/bv1_input_diode_104/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n165	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n165	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_33/Z}
set sink_names [list {u_t/bv1_delay_probe_2496/A} {u_t/bv1_input_diode_105/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n166	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n166	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_34/Z}
set sink_names [list {u_t/bv1_delay_probe_2520/A} {u_t/bv1_input_diode_106/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n167	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n167	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_35/Z}
set sink_names [list {u_t/bv1_delay_probe_2544/A} {u_t/bv1_input_diode_107/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n168	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n168	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_36/Z}
set sink_names [list {u_t/bv1_delay_probe_2568/A} {u_t/bv1_input_diode_108/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n169	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n169	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_37/Z}
set sink_names [list {u_t/bv1_delay_probe_2592/A} {u_t/bv1_input_diode_109/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n170	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n170	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_38/Z}
set sink_names [list {u_t/bv1_delay_probe_2616/A} {u_t/bv1_input_diode_110/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n171	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n171	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_39/Z}
set sink_names [list {u_t/bv1_delay_probe_2640/A} {u_t/bv1_input_diode_111/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n172	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n172	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_40/Z}
set sink_names [list {u_t/bv1_delay_probe_2688/A} {u_t/bv1_input_diode_113/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n173	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n173	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_41/Z}
set sink_names [list {u_t/bv1_delay_probe_2712/A} {u_t/bv1_input_diode_114/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n174	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n174	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_42/Z}
set sink_names [list {u_t/bv1_delay_probe_2736/A} {u_t/bv1_input_diode_115/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n175	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n175	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_43/Z}
set sink_names [list {u_t/bv1_input_diode_116/A} {u_t/bv1_delay_probe_2760/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n176	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n176	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_44/Z}
set sink_names [list {u_t/bv1_delay_probe_2784/A} {u_t/bv1_input_diode_117/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n177	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n177	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_45/Z}
set sink_names [list {u_t/bv1_delay_probe_2808/A} {u_t/bv1_input_diode_118/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n178	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n178	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_46/Z}
set sink_names [list {u_t/bv1_delay_probe_2832/A} {u_t/bv1_input_diode_119/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n179	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n179	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_47/Z}
set sink_names [list {u_t/bv1_input_diode_120/A} {u_t/bv1_delay_probe_2856/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n180	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n180	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_48/Z}
set sink_names [list {u_t/bv1_delay_probe_2880/A} {u_t/bv1_input_diode_121/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n181	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n181	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_49/Z}
set sink_names [list {u_t/bv1_delay_probe_2904/A} {u_t/bv1_input_diode_122/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n182	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n182	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_50/Z}
set sink_names [list {u_t/bv1_delay_probe_2952/A} {u_t/bv1_input_diode_124/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n183	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n183	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_51/Z}
set sink_names [list {u_t/bv1_delay_probe_2976/A} {u_t/bv1_input_diode_125/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n184	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n184	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_52/Z}
set sink_names [list {u_t/bv1_delay_probe_3000/A} {u_t/bv1_input_diode_126/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n185	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n185	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_53/Z}
set sink_names [list {u_t/bv1_delay_probe_3024/A} {u_t/bv1_input_diode_127/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n186	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n186	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_54/Z}
set sink_names [list {u_t/bv1_delay_probe_3048/A} {u_t/bv1_input_diode_128/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n187	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n187	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_55/Z}
set sink_names [list {u_t/bv1_delay_probe_3072/A} {u_t/bv1_input_diode_129/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n188	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n188	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_56/Z}
set sink_names [list {u_t/bv1_delay_probe_3096/A} {u_t/bv1_input_diode_130/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n189	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n189	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_57/Z}
set sink_names [list {u_t/bv1_delay_probe_3120/A} {u_t/bv1_input_diode_131/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n190	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n190	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_58/Z}
set sink_names [list {u_t/bv1_delay_probe_3144/A} {u_t/bv1_input_diode_132/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n191	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n191	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_59/Z}
set sink_names [list {u_t/bv1_input_diode_133/A} {u_t/bv1_delay_probe_3168/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n192	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n192	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_60/Z}
set sink_names [list {u_t/bv1_delay_probe_3216/A} {u_t/bv1_input_diode_135/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n193	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n193	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_61/Z}
set sink_names [list {u_t/bv1_input_diode_136/A} {u_t/bv1_delay_probe_3240/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n194	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n194	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_62/Z}
set sink_names [list {u_t/bv1_delay_probe_3264/A} {u_t/bv1_input_diode_137/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n195	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n195	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_63/Z}
set sink_names [list {u_t/bv1_delay_probe_3288/A} {u_t/bv1_input_diode_138/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n196	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n196	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_64/Z}
set sink_names [list {u_t/bv1_delay_probe_3312/A} {u_t/bv1_input_diode_139/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n197	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n197	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_65/Z}
set sink_names [list {u_t/bv1_input_diode_140/A} {u_t/bv1_delay_probe_3336/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n198	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n198	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_66/Z}
set sink_names [list {u_t/bv1_delay_probe_3360/A} {u_t/bv1_input_diode_141/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n199	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n199	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_67/Z}
set sink_names [list {u_t/bv1_delay_probe_3384/A} {u_t/bv1_input_diode_142/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n200	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n200	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_68/Z}
set sink_names [list {u_t/bv1_delay_probe_3408/A} {u_t/bv1_input_diode_143/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n201	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n201	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_69/Z}
set sink_names [list {u_t/bv1_delay_probe_3432/A} {u_t/bv1_input_diode_144/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n202	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n202	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_70/Z}
set sink_names [list {u_t/bv1_delay_probe_3480/A} {u_t/bv1_input_diode_146/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n203	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n203	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_71/Z}
set sink_names [list {u_t/bv1_delay_probe_3504/A} {u_t/bv1_input_diode_147/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n204	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n204	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_72/Z}
set sink_names [list {u_t/bv1_delay_probe_3528/A} {u_t/bv1_input_diode_148/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n205	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n205	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_73/Z}
set sink_names [list {u_t/bv1_delay_probe_3552/A} {u_t/bv1_input_diode_149/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n206	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n206	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_74/Z}
set sink_names [list {u_t/bv1_delay_probe_3576/A} {u_t/bv1_input_diode_150/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n207	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n207	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_75/Z}
set sink_names [list {u_t/bv1_delay_probe_3600/A} {u_t/bv1_input_diode_151/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n208	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n208	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_76/Z}
set sink_names [list {u_t/bv1_delay_probe_3624/A} {u_t/bv1_input_diode_152/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n209	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n209	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_77/Z}
set sink_names [list {u_t/bv1_delay_probe_3648/A} {u_t/bv1_input_diode_153/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n210	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n210	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_78/Z}
set sink_names [list {u_t/bv1_delay_probe_3672/A} {u_t/bv1_input_diode_154/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n211	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n211	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_79/Z}
set sink_names [list {u_t/bv1_delay_probe_3696/A} {u_t/bv1_input_diode_155/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n212	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n212	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_80/Z}
set sink_names [list {u_t/bv1_delay_probe_3744/A} {u_t/bv1_input_diode_157/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n213	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n213	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_81/Z}
set sink_names [list {u_t/bv1_delay_probe_3768/A} {u_t/bv1_input_diode_158/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n214	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n214	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_82/Z}
set sink_names [list {u_t/bv1_input_diode_159/A} {u_t/bv1_delay_probe_3792/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n215	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n215	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_83/Z}
set sink_names [list {u_t/bv1_delay_probe_3816/A} {u_t/bv1_input_diode_160/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n216	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n216	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_84/Z}
set sink_names [list {u_t/bv1_delay_probe_3840/A} {u_t/bv1_input_diode_161/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n217	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n217	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_85/Z}
set sink_names [list {u_t/bv1_delay_probe_3864/A} {u_t/bv1_input_diode_162/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n218	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n218	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_86/Z}
set sink_names [list {u_t/bv1_delay_probe_3888/A} {u_t/bv1_input_diode_163/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n219	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n219	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_87/Z}
set sink_names [list {u_t/bv1_input_diode_164/A} {u_t/bv1_delay_probe_3912/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n220	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n220	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_88/Z}
set sink_names [list {u_t/bv1_input_diode_165/A} {u_t/bv1_delay_probe_3936/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n221	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n221	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_89/Z}
set sink_names [list {u_t/bv1_delay_probe_3960/A} {u_t/bv1_input_diode_166/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n222	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n222	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_90/Z}
set sink_names [list {u_t/bv1_delay_probe_4008/A} {u_t/bv1_input_diode_168/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n223	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n223	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_91/Z}
set sink_names [list {u_t/bv1_delay_probe_4032/A} {u_t/bv1_input_diode_169/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n224	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n224	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_92/Z}
set sink_names [list {u_t/bv1_delay_probe_4056/A} {u_t/bv1_input_diode_170/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n225	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n225	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_93/Z}
set sink_names [list {u_t/bv1_input_diode_171/A} {u_t/bv1_delay_probe_4080/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n226	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n226	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_94/Z}
set sink_names [list {u_t/bv1_delay_probe_4104/A} {u_t/bv1_input_diode_172/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n227	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n227	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_95/Z}
set sink_names [list {u_t/bv1_delay_probe_4128/A} {u_t/bv1_input_diode_173/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n228	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n228	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_96/Z}
set sink_names [list {u_t/bv1_delay_probe_4152/A} {u_t/bv1_input_diode_174/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n229	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n229	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_97/Z}
set sink_names [list {u_t/bv1_delay_probe_4176/A} {u_t/bv1_input_diode_175/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n230	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n230	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_98/Z}
set sink_names [list {u_t/bv1_delay_probe_4200/A} {u_t/bv1_input_diode_176/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n231	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n231	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_99/Z}
set sink_names [list {u_t/bv1_delay_probe_4224/A} {u_t/bv1_input_diode_177/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n232	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n232	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_100/Z}
set sink_names [list {u_t/bv1_input_diode_52/A} {u_t/bv1_delay_probe_1224/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n233	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n233	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_101/Z}
set sink_names [list {u_t/bv1_delay_probe_1248/A} {u_t/bv1_input_diode_53/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n234	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n234	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_102/Z}
set sink_names [list {u_t/bv1_delay_probe_1272/A} {u_t/bv1_input_diode_54/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n235	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n235	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_103/Z}
set sink_names [list {u_t/bv1_input_diode_55/A} {u_t/bv1_delay_probe_1296/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n236	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n236	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_104/Z}
set sink_names [list {u_t/bv1_delay_probe_1320/A} {u_t/bv1_input_diode_56/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n237	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n237	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_105/Z}
set sink_names [list {u_t/bv1_delay_probe_1344/A} {u_t/bv1_input_diode_57/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n238	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n238	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_106/Z}
set sink_names [list {u_t/bv1_delay_probe_1368/A} {u_t/bv1_input_diode_58/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n239	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n239	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_107/Z}
set sink_names [list {u_t/bv1_delay_probe_1392/A} {u_t/bv1_input_diode_59/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n240	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n240	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_108/Z}
set sink_names [list {u_t/bv1_input_diode_60/A} {u_t/bv1_delay_probe_1416/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n241	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n241	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_109/Z}
set sink_names [list {u_t/bv1_delay_probe_1440/A} {u_t/bv1_input_diode_61/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n242	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n242	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_110/Z}
set sink_names [list {u_t/bv1_input_diode_63/A} {u_t/bv1_delay_probe_1488/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n243	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n243	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_111/Z}
set sink_names [list {u_t/bv1_delay_probe_1512/A} {u_t/bv1_input_diode_64/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n244	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n244	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_112/Z}
set sink_names [list {u_t/bv1_delay_probe_1536/A} {u_t/bv1_input_diode_65/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n245	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n245	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_113/Z}
set sink_names [list {u_t/bv1_delay_probe_1560/A} {u_t/bv1_input_diode_66/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n246	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n246	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_114/Z}
set sink_names [list {u_t/bv1_delay_probe_1584/A} {u_t/bv1_input_diode_67/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n247	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n247	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_115/Z}
set sink_names [list {u_t/bv1_delay_probe_1608/A} {u_t/bv1_input_diode_68/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n248	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n248	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_116/Z}
set sink_names [list {u_t/bv1_delay_probe_1632/A} {u_t/bv1_input_diode_69/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n249	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n249	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_117/Z}
set sink_names [list {u_t/bv1_delay_probe_1656/A} {u_t/bv1_input_diode_70/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n250	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n250	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_118/Z}
set sink_names [list {u_t/bv1_delay_probe_1680/A} {u_t/bv1_input_diode_71/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n251	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n251	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_119/Z}
set sink_names [list {u_t/bv1_delay_probe_1704/A} {u_t/bv1_input_diode_72/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n252	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n252	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_120/Z}
set sink_names [list {u_t/bv1_delay_probe_1752/A} {u_t/bv1_input_diode_74/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n253	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n253	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_121/Z}
set sink_names [list {u_t/bv1_delay_probe_1776/A} {u_t/bv1_input_diode_75/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n254	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n254	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_122/Z}
set sink_names [list {u_t/bv1_delay_probe_1800/A} {u_t/bv1_input_diode_76/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n255	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n255	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_123/Z}
set sink_names [list {u_t/bv1_delay_probe_1824/A} {u_t/bv1_input_diode_77/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n256	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n256	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_124/Z}
set sink_names [list {u_t/bv1_delay_probe_1848/A} {u_t/bv1_input_diode_78/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n257	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n257	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_125/Z}
set sink_names [list {u_t/bv1_delay_probe_1872/A} {u_t/bv1_input_diode_79/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n258	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n258	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_126/Z}
set sink_names [list {u_t/bv1_delay_probe_1896/A} {u_t/bv1_input_diode_80/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n259	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n259	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_127/Z}
set sink_names [list {u_t/bv1_delay_probe_1920/A} {u_t/bv1_input_diode_81/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n260	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n260	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_valid_0/Z}
set sink_names [list {u_t/bv1_input_diode_189/A} {u_t/bv1_delay_probe_4512/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n261	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n261	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_0/Z}
set sink_names [list {u_t/bv1_delay_probe_4272/A} {u_t/bv1_input_diode_179/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n262	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n262	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_1/Z}
set sink_names [list {u_t/bv1_delay_probe_4296/A} {u_t/bv1_input_diode_180/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n263	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n263	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_2/Z}
set sink_names [list {u_t/bv1_delay_probe_4320/A} {u_t/bv1_input_diode_181/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n264	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n264	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_3/Z}
set sink_names [list {u_t/bv1_delay_probe_4344/A} {u_t/bv1_input_diode_182/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n265	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n265	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_4/Z}
set sink_names [list {u_t/bv1_delay_probe_4368/A} {u_t/bv1_input_diode_183/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n266	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n266	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_5/Z}
set sink_names [list {u_t/bv1_input_diode_184/A} {u_t/bv1_delay_probe_4392/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n267	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n267	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_6/Z}
set sink_names [list {u_t/bv1_delay_probe_4416/A} {u_t/bv1_input_diode_185/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n268	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n268	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_7/Z}
set sink_names [list {u_t/bv1_delay_probe_4440/A} {u_t/bv1_input_diode_186/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n269	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n269	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_8/Z}
set sink_names [list {u_t/bv1_delay_probe_4464/A} {u_t/bv1_input_diode_187/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n270	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n270	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_9/Z}
set sink_names [list {u_t/bv1_delay_probe_4488/A} {u_t/bv1_input_diode_188/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n271	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n271	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire4111/Z}
set sink_names [list {u_booster/relay_0/A} {u_booster/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n272	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n272	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_booster/relay_0/Z}
set sink_names [list {u_return/relay_0/A} {u_return/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n273	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n273	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_return/relay_0/Z}
set sink_names [list {u_bridge/input139/A} {u_bridge/bv1_input_diode_139/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
close $f
source {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-932/src/project/experiments/block_v1/native_annotation.tcl}
