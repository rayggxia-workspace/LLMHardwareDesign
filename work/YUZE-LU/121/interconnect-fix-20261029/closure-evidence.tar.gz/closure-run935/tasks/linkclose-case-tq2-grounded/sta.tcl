set_thread_count 16
read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-prepare-tq2/t-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-prepare-tq2/s-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-prepare-tq2/bank-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-prepare-tq2/booster-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-case-tq2-grounded/wrapper.v}
link_design interconnect_fixture
set_cmd_units -time ns -capacitance fF -resistance kOhm -distance um
set_units -time ns -capacitance fF -resistance kOhm -distance um
create_clock -name core -period 3.333333333333333 [get_ports clk]
set_clock_uncertainty 0.1 [get_clocks core]
set_clock_transition 0.05 [get_clocks core]
set data_inputs {}
foreach p [all_inputs] {if {[get_full_name $p] ne "clk"} {lappend data_inputs $p}}
set_input_delay -clock core -min 0.2 $data_inputs
set_input_delay -clock core -max 0.8 $data_inputs
set_output_delay -clock core -min 0.2 [all_outputs]
set_output_delay -clock core -max 0.8 [all_outputs]
set_driving_cell -lib_cell BUF_X2 -pin Z $data_inputs
set_load 50 [all_outputs]
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-prepare-tq2/prepared/common-direct.spef}
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/tasks/linkclose-case-tq2-grounded/links.spef}
set_propagated_clock [all_clocks]
sta::find_timing
report_units
write_sdc -digits 12 constraints-readback.sdc
report_parasitic_annotation -report_unannotated > annotation.rpt
set f [open summary.tsv w]
puts $f "setup_count\t[sta::endpoint_violation_count max]"
puts $f "hold_count\t[sta::endpoint_violation_count min]"
puts $f "time_unit_seconds\t[sta::time_ui_sta 1]"
puts $f "cap_unit_farads\t[sta::capacitance_ui_sta 1]"
foreach kind {capacitance slew fanout} {
 puts $f "$kind\t[sta::max_${kind}_violation_count]\t[sta::max_${kind}_check_slack]\t[sta::max_${kind}_check_limit]"
}
close $f
report_worst_slack -max -digits 12 > timing.rpt
report_worst_slack -min -digits 12 >> timing.rpt
report_checks -path_delay min_max -group_path_count 5 -format full_clock_expanded -digits 12 >> timing.rpt
report_check_types -max_capacitance -max_slew -max_fanout -violators -digits 12 -no_line_splits > electrical.rpt
set setup_stream [open check-setup.rpt w]
puts $setup_stream [check_setup -verbose]
close $setup_stream
set f [open links.tsv w]
set source_name {u_t/wire31465/Z}
set sink_names [list {u_bank/relay_0/A} {u_bank/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_0/Z}
set sink_names [list {u_s/bv1_delay_probe_240/A} {u_s/bv1_input_diode_11/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n001	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n001	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19210/Z}
set sink_names [list {u_bank/relay_1/A} {u_bank/bv1_input_diode_51/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n002	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n002	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_1/Z}
set sink_names [list {u_s/bv1_delay_probe_1176/A} {u_s/bv1_input_diode_50/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n003	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n003	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31425/Z}
set sink_names [list {u_bank/relay_2/A} {u_bank/bv1_input_diode_62/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n004	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n004	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_2/Z}
set sink_names [list {u_s/bv1_delay_probe_1440/A} {u_s/bv1_input_diode_61/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n005	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n005	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31416/Z}
set sink_names [list {u_bank/relay_3/A} {u_bank/bv1_input_diode_73/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n006	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n006	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_3/Z}
set sink_names [list {u_s/bv1_input_diode_72/A} {u_s/bv1_delay_probe_1704/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n007	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n007	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31409/Z}
set sink_names [list {u_bank/relay_4/A} {u_bank/bv1_input_diode_84/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n008	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n008	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_4/Z}
set sink_names [list {u_s/bv1_delay_probe_1968/A} {u_s/bv1_input_diode_83/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n009	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n009	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31398/Z}
set sink_names [list {u_bank/relay_5/A} {u_bank/bv1_input_diode_95/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n010	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n010	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_5/Z}
set sink_names [list {u_s/bv1_delay_probe_2232/A} {u_s/bv1_input_diode_94/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n011	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n011	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31390/Z}
set sink_names [list {u_bank/relay_6/A} {u_bank/bv1_input_diode_106/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n012	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n012	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_6/Z}
set sink_names [list {u_s/bv1_input_diode_105/A} {u_s/bv1_delay_probe_2496/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n013	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n013	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31382/Z}
set sink_names [list {u_bank/relay_7/A} {u_bank/bv1_input_diode_117/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n014	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n014	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_7/Z}
set sink_names [list {u_s/bv1_delay_probe_2760/A} {u_s/bv1_input_diode_116/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n015	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n015	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31371/Z}
set sink_names [list {u_bank/relay_8/A} {u_bank/bv1_input_diode_128/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n016	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n016	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_8/Z}
set sink_names [list {u_s/bv1_delay_probe_3024/A} {u_s/bv1_input_diode_127/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n017	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n017	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31363/Z}
set sink_names [list {u_bank/relay_9/A} {u_bank/bv1_input_diode_139/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n018	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n018	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_9/Z}
set sink_names [list {u_s/bv1_delay_probe_3288/A} {u_s/bv1_input_diode_138/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n019	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n019	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31459/Z}
set sink_names [list {u_bank/relay_10/A} {u_bank/bv1_input_diode_11/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n020	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n020	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_10/Z}
set sink_names [list {u_s/bv1_delay_probe_504/A} {u_s/bv1_input_diode_22/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n021	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n021	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31450/Z}
set sink_names [list {u_bank/relay_11/A} {u_bank/bv1_input_diode_22/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n022	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n022	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_11/Z}
set sink_names [list {u_s/bv1_delay_probe_768/A} {u_s/bv1_input_diode_33/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n023	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n023	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31442/Z}
set sink_names [list {u_bank/relay_12/A} {u_bank/bv1_input_diode_33/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n024	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n024	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_12/Z}
set sink_names [list {u_s/bv1_delay_probe_984/A} {u_s/bv1_input_diode_42/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n025	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n025	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19211/Z}
set sink_names [list {u_bank/relay_13/A} {u_bank/bv1_input_diode_44/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n026	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n026	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_13/Z}
set sink_names [list {u_s/bv1_input_diode_43/A} {u_s/bv1_delay_probe_1008/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n027	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n027	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31441/Z}
set sink_names [list {u_bank/relay_14/A} {u_bank/bv1_input_diode_45/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n028	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n028	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_14/Z}
set sink_names [list {u_s/bv1_delay_probe_1032/A} {u_s/bv1_input_diode_44/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n029	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n029	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31440/Z}
set sink_names [list {u_bank/relay_15/A} {u_bank/bv1_input_diode_46/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n030	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n030	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_15/Z}
set sink_names [list {u_s/bv1_delay_probe_1056/A} {u_s/bv1_input_diode_45/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n031	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n031	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31439/Z}
set sink_names [list {u_bank/relay_16/A} {u_bank/bv1_input_diode_47/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n032	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n032	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_16/Z}
set sink_names [list {u_s/bv1_delay_probe_1080/A} {u_s/bv1_input_diode_46/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n033	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n033	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31438/Z}
set sink_names [list {u_bank/relay_17/A} {u_bank/bv1_input_diode_48/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n034	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n034	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_17/Z}
set sink_names [list {u_s/bv1_delay_probe_1104/A} {u_s/bv1_input_diode_47/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n035	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n035	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31437/Z}
set sink_names [list {u_bank/relay_18/A} {u_bank/bv1_input_diode_49/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n036	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n036	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_18/Z}
set sink_names [list {u_s/bv1_delay_probe_1128/A} {u_s/bv1_input_diode_48/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n037	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n037	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31436/Z}
set sink_names [list {u_bank/relay_19/A} {u_bank/bv1_input_diode_50/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n038	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n038	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_19/Z}
set sink_names [list {u_s/bv1_delay_probe_1152/A} {u_s/bv1_input_diode_49/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n039	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n039	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31435/Z}
set sink_names [list {u_bank/relay_20/A} {u_bank/bv1_input_diode_52/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n040	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n040	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_20/Z}
set sink_names [list {u_s/bv1_input_diode_51/A} {u_s/bv1_delay_probe_1200/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n041	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n041	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31434/Z}
set sink_names [list {u_bank/relay_21/A} {u_bank/bv1_input_diode_53/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n042	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n042	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_21/Z}
set sink_names [list {u_s/bv1_input_diode_52/A} {u_s/bv1_delay_probe_1224/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n043	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n043	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31433/Z}
set sink_names [list {u_bank/relay_22/A} {u_bank/bv1_input_diode_54/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n044	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n044	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_22/Z}
set sink_names [list {u_s/bv1_delay_probe_1248/A} {u_s/bv1_input_diode_53/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n045	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n045	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31432/Z}
set sink_names [list {u_bank/relay_23/A} {u_bank/bv1_input_diode_55/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n046	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n046	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_23/Z}
set sink_names [list {u_s/bv1_delay_probe_1272/A} {u_s/bv1_input_diode_54/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n047	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n047	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31431/Z}
set sink_names [list {u_bank/relay_24/A} {u_bank/bv1_input_diode_56/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n048	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n048	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_24/Z}
set sink_names [list {u_s/bv1_delay_probe_1296/A} {u_s/bv1_input_diode_55/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n049	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n049	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31430/Z}
set sink_names [list {u_bank/relay_25/A} {u_bank/bv1_input_diode_57/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n050	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n050	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_25/Z}
set sink_names [list {u_s/bv1_input_diode_56/A} {u_s/bv1_delay_probe_1320/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n051	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n051	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31429/Z}
set sink_names [list {u_bank/relay_26/A} {u_bank/bv1_input_diode_58/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n052	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n052	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_26/Z}
set sink_names [list {u_s/bv1_delay_probe_1344/A} {u_s/bv1_input_diode_57/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n053	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n053	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31428/Z}
set sink_names [list {u_bank/relay_27/A} {u_bank/bv1_input_diode_59/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n054	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n054	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_27/Z}
set sink_names [list {u_s/bv1_delay_probe_1368/A} {u_s/bv1_input_diode_58/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n055	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n055	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31427/Z}
set sink_names [list {u_bank/relay_28/A} {u_bank/bv1_input_diode_60/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n056	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n056	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_28/Z}
set sink_names [list {u_s/bv1_delay_probe_1392/A} {u_s/bv1_input_diode_59/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n057	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n057	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31426/Z}
set sink_names [list {u_bank/relay_29/A} {u_bank/bv1_input_diode_61/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n058	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n058	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_29/Z}
set sink_names [list {u_s/bv1_delay_probe_1416/A} {u_s/bv1_input_diode_60/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n059	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n059	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31424/Z}
set sink_names [list {u_bank/relay_30/A} {u_bank/bv1_input_diode_63/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n060	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n060	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_30/Z}
set sink_names [list {u_s/bv1_delay_probe_1464/A} {u_s/bv1_input_diode_62/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n061	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n061	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31423/Z}
set sink_names [list {u_bank/relay_31/A} {u_bank/bv1_input_diode_64/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n062	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n062	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_31/Z}
set sink_names [list {u_s/bv1_delay_probe_1488/A} {u_s/bv1_input_diode_63/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n063	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n063	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31422/Z}
set sink_names [list {u_bank/relay_32/A} {u_bank/bv1_input_diode_65/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n064	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n064	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_32/Z}
set sink_names [list {u_s/bv1_delay_probe_1512/A} {u_s/bv1_input_diode_64/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n065	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n065	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31421/Z}
set sink_names [list {u_bank/relay_33/A} {u_bank/bv1_input_diode_66/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n066	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n066	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_33/Z}
set sink_names [list {u_s/bv1_delay_probe_1536/A} {u_s/bv1_input_diode_65/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n067	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n067	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31420/Z}
set sink_names [list {u_bank/relay_34/A} {u_bank/bv1_input_diode_67/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n068	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n068	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_34/Z}
set sink_names [list {u_s/bv1_input_diode_66/A} {u_s/bv1_delay_probe_1560/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n069	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n069	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19209/Z}
set sink_names [list {u_bank/relay_35/A} {u_bank/bv1_input_diode_68/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n070	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n070	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_35/Z}
set sink_names [list {u_s/bv1_input_diode_67/A} {u_s/bv1_delay_probe_1584/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n071	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n071	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19208/Z}
set sink_names [list {u_bank/relay_36/A} {u_bank/bv1_input_diode_69/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n072	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n072	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_36/Z}
set sink_names [list {u_s/bv1_delay_probe_1608/A} {u_s/bv1_input_diode_68/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n073	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n073	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31419/Z}
set sink_names [list {u_bank/relay_37/A} {u_bank/bv1_input_diode_70/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n074	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n074	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_37/Z}
set sink_names [list {u_s/bv1_delay_probe_1632/A} {u_s/bv1_input_diode_69/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n075	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n075	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31418/Z}
set sink_names [list {u_bank/relay_38/A} {u_bank/bv1_input_diode_71/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n076	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n076	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_38/Z}
set sink_names [list {u_s/bv1_input_diode_70/A} {u_s/bv1_delay_probe_1656/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n077	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n077	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31417/Z}
set sink_names [list {u_bank/relay_39/A} {u_bank/bv1_input_diode_72/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n078	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n078	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_39/Z}
set sink_names [list {u_s/bv1_delay_probe_1680/A} {u_s/bv1_input_diode_71/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n079	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n079	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19207/Z}
set sink_names [list {u_bank/relay_40/A} {u_bank/bv1_input_diode_74/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n080	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n080	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_40/Z}
set sink_names [list {u_s/bv1_delay_probe_1728/A} {u_s/bv1_input_diode_73/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n081	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n081	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31415/Z}
set sink_names [list {u_bank/relay_41/A} {u_bank/bv1_input_diode_75/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n082	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n082	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_41/Z}
set sink_names [list {u_s/bv1_delay_probe_1752/A} {u_s/bv1_input_diode_74/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n083	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n083	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19206/Z}
set sink_names [list {u_bank/relay_42/A} {u_bank/bv1_input_diode_76/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n084	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n084	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_42/Z}
set sink_names [list {u_s/bv1_delay_probe_1776/A} {u_s/bv1_input_diode_75/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n085	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n085	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19205/Z}
set sink_names [list {u_bank/relay_43/A} {u_bank/bv1_input_diode_77/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n086	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n086	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_43/Z}
set sink_names [list {u_s/bv1_delay_probe_1800/A} {u_s/bv1_input_diode_76/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n087	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n087	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire7322/Z}
set sink_names [list {u_bank/relay_44/A} {u_bank/bv1_input_diode_78/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n088	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n088	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_44/Z}
set sink_names [list {u_s/bv1_delay_probe_1824/A} {u_s/bv1_input_diode_77/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n089	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n089	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31414/Z}
set sink_names [list {u_bank/relay_45/A} {u_bank/bv1_input_diode_79/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n090	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n090	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_45/Z}
set sink_names [list {u_s/bv1_delay_probe_1848/A} {u_s/bv1_input_diode_78/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n091	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n091	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31413/Z}
set sink_names [list {u_bank/relay_46/A} {u_bank/bv1_input_diode_80/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n092	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n092	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_46/Z}
set sink_names [list {u_s/bv1_delay_probe_1872/A} {u_s/bv1_input_diode_79/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n093	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n093	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31412/Z}
set sink_names [list {u_bank/relay_47/A} {u_bank/bv1_input_diode_81/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n094	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n094	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_47/Z}
set sink_names [list {u_s/bv1_input_diode_80/A} {u_s/bv1_delay_probe_1896/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n095	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n095	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31411/Z}
set sink_names [list {u_bank/relay_48/A} {u_bank/bv1_input_diode_82/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n096	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n096	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_48/Z}
set sink_names [list {u_s/bv1_delay_probe_1920/A} {u_s/bv1_input_diode_81/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n097	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n097	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31410/Z}
set sink_names [list {u_bank/relay_49/A} {u_bank/bv1_input_diode_83/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n098	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n098	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_49/Z}
set sink_names [list {u_s/bv1_delay_probe_1944/A} {u_s/bv1_input_diode_82/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n099	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n099	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31408/Z}
set sink_names [list {u_bank/relay_50/A} {u_bank/bv1_input_diode_85/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n100	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n100	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_50/Z}
set sink_names [list {u_s/bv1_delay_probe_1992/A} {u_s/bv1_input_diode_84/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n101	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n101	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31407/Z}
set sink_names [list {u_bank/relay_51/A} {u_bank/bv1_input_diode_86/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n102	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n102	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_51/Z}
set sink_names [list {u_s/bv1_delay_probe_2016/A} {u_s/bv1_input_diode_85/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n103	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n103	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31406/Z}
set sink_names [list {u_bank/relay_52/A} {u_bank/bv1_input_diode_87/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n104	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n104	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_52/Z}
set sink_names [list {u_s/bv1_delay_probe_2040/A} {u_s/bv1_input_diode_86/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n105	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n105	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31405/Z}
set sink_names [list {u_bank/relay_53/A} {u_bank/bv1_input_diode_88/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n106	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n106	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_53/Z}
set sink_names [list {u_s/bv1_delay_probe_2064/A} {u_s/bv1_input_diode_87/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n107	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n107	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31404/Z}
set sink_names [list {u_bank/relay_54/A} {u_bank/bv1_input_diode_89/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n108	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n108	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_54/Z}
set sink_names [list {u_s/bv1_delay_probe_2088/A} {u_s/bv1_input_diode_88/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n109	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n109	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31403/Z}
set sink_names [list {u_bank/relay_55/A} {u_bank/bv1_input_diode_90/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n110	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n110	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_55/Z}
set sink_names [list {u_s/bv1_delay_probe_2112/A} {u_s/bv1_input_diode_89/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n111	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n111	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31402/Z}
set sink_names [list {u_bank/bv1_input_diode_91/A} {u_bank/relay_56/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n112	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n112	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_56/Z}
set sink_names [list {u_s/bv1_delay_probe_2136/A} {u_s/bv1_input_diode_90/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n113	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n113	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31401/Z}
set sink_names [list {u_bank/relay_57/A} {u_bank/bv1_input_diode_92/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n114	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n114	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_57/Z}
set sink_names [list {u_s/bv1_delay_probe_2160/A} {u_s/bv1_input_diode_91/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n115	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n115	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31400/Z}
set sink_names [list {u_bank/relay_58/A} {u_bank/bv1_input_diode_93/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n116	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n116	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_58/Z}
set sink_names [list {u_s/bv1_delay_probe_2184/A} {u_s/bv1_input_diode_92/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n117	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n117	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31399/Z}
set sink_names [list {u_bank/relay_59/A} {u_bank/bv1_input_diode_94/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n118	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n118	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_59/Z}
set sink_names [list {u_s/bv1_input_diode_93/A} {u_s/bv1_delay_probe_2208/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n119	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n119	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire7321/Z}
set sink_names [list {u_bank/relay_60/A} {u_bank/bv1_input_diode_96/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n120	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n120	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_60/Z}
set sink_names [list {u_s/bv1_delay_probe_2256/A} {u_s/bv1_input_diode_95/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n121	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n121	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31397/Z}
set sink_names [list {u_bank/relay_61/A} {u_bank/bv1_input_diode_97/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n122	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n122	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_61/Z}
set sink_names [list {u_s/bv1_delay_probe_2280/A} {u_s/bv1_input_diode_96/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n123	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n123	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31396/Z}
set sink_names [list {u_bank/relay_62/A} {u_bank/bv1_input_diode_98/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n124	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n124	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_62/Z}
set sink_names [list {u_s/bv1_delay_probe_2304/A} {u_s/bv1_input_diode_97/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n125	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n125	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31395/Z}
set sink_names [list {u_bank/relay_63/A} {u_bank/bv1_input_diode_99/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n126	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n126	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_63/Z}
set sink_names [list {u_s/bv1_delay_probe_2328/A} {u_s/bv1_input_diode_98/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n127	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n127	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31394/Z}
set sink_names [list {u_bank/relay_64/A} {u_bank/bv1_input_diode_100/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n128	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n128	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_64/Z}
set sink_names [list {u_s/bv1_delay_probe_2352/A} {u_s/bv1_input_diode_99/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n129	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n129	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19204/Z}
set sink_names [list {u_bank/relay_65/A} {u_bank/bv1_input_diode_101/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n130	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n130	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_65/Z}
set sink_names [list {u_s/bv1_delay_probe_2376/A} {u_s/bv1_input_diode_100/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n131	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n131	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31393/Z}
set sink_names [list {u_bank/relay_66/A} {u_bank/bv1_input_diode_102/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n132	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n132	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_66/Z}
set sink_names [list {u_s/bv1_input_diode_101/A} {u_s/bv1_delay_probe_2400/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n133	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n133	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19203/Z}
set sink_names [list {u_bank/relay_67/A} {u_bank/bv1_input_diode_103/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n134	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n134	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_67/Z}
set sink_names [list {u_s/bv1_delay_probe_2424/A} {u_s/bv1_input_diode_102/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n135	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n135	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31392/Z}
set sink_names [list {u_bank/relay_68/A} {u_bank/bv1_input_diode_104/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n136	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n136	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_68/Z}
set sink_names [list {u_s/bv1_delay_probe_2448/A} {u_s/bv1_input_diode_103/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n137	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n137	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31391/Z}
set sink_names [list {u_bank/relay_69/A} {u_bank/bv1_input_diode_105/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n138	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n138	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_69/Z}
set sink_names [list {u_s/bv1_input_diode_104/A} {u_s/bv1_delay_probe_2472/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n139	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n139	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31389/Z}
set sink_names [list {u_bank/relay_70/A} {u_bank/bv1_input_diode_107/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n140	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n140	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_70/Z}
set sink_names [list {u_s/bv1_delay_probe_2520/A} {u_s/bv1_input_diode_106/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n141	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n141	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31388/Z}
set sink_names [list {u_bank/relay_71/A} {u_bank/bv1_input_diode_108/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n142	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n142	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_71/Z}
set sink_names [list {u_s/bv1_delay_probe_2544/A} {u_s/bv1_input_diode_107/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n143	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n143	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31387/Z}
set sink_names [list {u_bank/relay_72/A} {u_bank/bv1_input_diode_109/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n144	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n144	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_72/Z}
set sink_names [list {u_s/bv1_delay_probe_2568/A} {u_s/bv1_input_diode_108/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n145	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n145	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31386/Z}
set sink_names [list {u_bank/relay_73/A} {u_bank/bv1_input_diode_110/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n146	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n146	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_73/Z}
set sink_names [list {u_s/bv1_delay_probe_2592/A} {u_s/bv1_input_diode_109/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n147	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n147	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31385/Z}
set sink_names [list {u_bank/relay_74/A} {u_bank/bv1_input_diode_111/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n148	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n148	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_74/Z}
set sink_names [list {u_s/bv1_delay_probe_2616/A} {u_s/bv1_input_diode_110/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n149	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n149	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19202/Z}
set sink_names [list {u_bank/relay_75/A} {u_bank/bv1_input_diode_112/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n150	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n150	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_75/Z}
set sink_names [list {u_s/bv1_delay_probe_2640/A} {u_s/bv1_input_diode_111/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n151	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n151	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire7320/Z}
set sink_names [list {u_bank/relay_76/A} {u_bank/bv1_input_diode_113/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n152	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n152	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_76/Z}
set sink_names [list {u_s/bv1_delay_probe_2664/A} {u_s/bv1_input_diode_112/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n153	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n153	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31384/Z}
set sink_names [list {u_bank/relay_77/A} {u_bank/bv1_input_diode_114/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n154	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n154	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_77/Z}
set sink_names [list {u_s/bv1_delay_probe_2688/A} {u_s/bv1_input_diode_113/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n155	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n155	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19201/Z}
set sink_names [list {u_bank/relay_78/A} {u_bank/bv1_input_diode_115/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n156	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n156	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_78/Z}
set sink_names [list {u_s/bv1_delay_probe_2712/A} {u_s/bv1_input_diode_114/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n157	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n157	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31383/Z}
set sink_names [list {u_bank/relay_79/A} {u_bank/bv1_input_diode_116/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n158	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n158	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_79/Z}
set sink_names [list {u_s/bv1_delay_probe_2736/A} {u_s/bv1_input_diode_115/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n159	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n159	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31381/Z}
set sink_names [list {u_bank/relay_80/A} {u_bank/bv1_input_diode_118/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n160	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n160	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_80/Z}
set sink_names [list {u_s/bv1_input_diode_117/A} {u_s/bv1_delay_probe_2784/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n161	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n161	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31380/Z}
set sink_names [list {u_bank/relay_81/A} {u_bank/bv1_input_diode_119/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n162	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n162	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_81/Z}
set sink_names [list {u_s/bv1_delay_probe_2808/A} {u_s/bv1_input_diode_118/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n163	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n163	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31379/Z}
set sink_names [list {u_bank/relay_82/A} {u_bank/bv1_input_diode_120/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n164	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n164	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_82/Z}
set sink_names [list {u_s/bv1_delay_probe_2832/A} {u_s/bv1_input_diode_119/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n165	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n165	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31378/Z}
set sink_names [list {u_bank/relay_83/A} {u_bank/bv1_input_diode_121/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n166	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n166	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_83/Z}
set sink_names [list {u_s/bv1_delay_probe_2856/A} {u_s/bv1_input_diode_120/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n167	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n167	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31377/Z}
set sink_names [list {u_bank/relay_84/A} {u_bank/bv1_input_diode_122/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n168	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n168	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_84/Z}
set sink_names [list {u_s/bv1_delay_probe_2880/A} {u_s/bv1_input_diode_121/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n169	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n169	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31376/Z}
set sink_names [list {u_bank/relay_85/A} {u_bank/bv1_input_diode_123/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n170	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n170	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_85/Z}
set sink_names [list {u_s/bv1_delay_probe_2904/A} {u_s/bv1_input_diode_122/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n171	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n171	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31375/Z}
set sink_names [list {u_bank/relay_86/A} {u_bank/bv1_input_diode_124/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n172	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n172	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_86/Z}
set sink_names [list {u_s/bv1_delay_probe_2928/A} {u_s/bv1_input_diode_123/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n173	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n173	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31374/Z}
set sink_names [list {u_bank/relay_87/A} {u_bank/bv1_input_diode_125/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n174	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n174	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_87/Z}
set sink_names [list {u_s/bv1_delay_probe_2952/A} {u_s/bv1_input_diode_124/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n175	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n175	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31373/Z}
set sink_names [list {u_bank/relay_88/A} {u_bank/bv1_input_diode_126/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n176	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n176	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_88/Z}
set sink_names [list {u_s/bv1_delay_probe_2976/A} {u_s/bv1_input_diode_125/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n177	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n177	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31372/Z}
set sink_names [list {u_bank/relay_89/A} {u_bank/bv1_input_diode_127/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n178	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n178	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_89/Z}
set sink_names [list {u_s/bv1_delay_probe_3000/A} {u_s/bv1_input_diode_126/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n179	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n179	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31370/Z}
set sink_names [list {u_bank/relay_90/A} {u_bank/bv1_input_diode_129/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n180	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n180	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_90/Z}
set sink_names [list {u_s/bv1_delay_probe_3048/A} {u_s/bv1_input_diode_128/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n181	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n181	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31369/Z}
set sink_names [list {u_bank/relay_91/A} {u_bank/bv1_input_diode_130/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n182	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n182	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_91/Z}
set sink_names [list {u_s/bv1_input_diode_129/A} {u_s/bv1_delay_probe_3072/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n183	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n183	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31368/Z}
set sink_names [list {u_bank/relay_92/A} {u_bank/bv1_input_diode_131/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n184	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n184	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_92/Z}
set sink_names [list {u_s/bv1_delay_probe_3096/A} {u_s/bv1_input_diode_130/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n185	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n185	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31367/Z}
set sink_names [list {u_bank/relay_93/A} {u_bank/bv1_input_diode_132/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n186	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n186	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_93/Z}
set sink_names [list {u_s/bv1_input_diode_131/A} {u_s/bv1_delay_probe_3120/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n187	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n187	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31366/Z}
set sink_names [list {u_bank/relay_94/A} {u_bank/bv1_input_diode_133/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n188	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n188	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_94/Z}
set sink_names [list {u_s/bv1_input_diode_132/A} {u_s/bv1_delay_probe_3144/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n189	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n189	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31365/Z}
set sink_names [list {u_bank/relay_95/A} {u_bank/bv1_input_diode_134/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n190	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n190	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_95/Z}
set sink_names [list {u_s/bv1_delay_probe_3168/A} {u_s/bv1_input_diode_133/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n191	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n191	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31364/Z}
set sink_names [list {u_bank/bv1_input_diode_135/A} {u_bank/relay_96/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n192	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n192	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_96/Z}
set sink_names [list {u_s/bv1_delay_probe_3192/A} {u_s/bv1_input_diode_134/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n193	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n193	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19200/Z}
set sink_names [list {u_bank/relay_97/A} {u_bank/bv1_input_diode_136/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n194	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n194	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_97/Z}
set sink_names [list {u_s/bv1_delay_probe_3216/A} {u_s/bv1_input_diode_135/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n195	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n195	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19199/Z}
set sink_names [list {u_bank/relay_98/A} {u_bank/bv1_input_diode_137/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n196	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n196	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_98/Z}
set sink_names [list {u_s/bv1_delay_probe_3240/A} {u_s/bv1_input_diode_136/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n197	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n197	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19198/Z}
set sink_names [list {u_bank/relay_99/A} {u_bank/bv1_input_diode_138/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n198	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n198	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_99/Z}
set sink_names [list {u_s/bv1_delay_probe_3264/A} {u_s/bv1_input_diode_137/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n199	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n199	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19219/Z}
set sink_names [list {u_bank/relay_100/A} {u_bank/bv1_input_diode_1/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n200	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n200	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_100/Z}
set sink_names [list {u_s/bv1_delay_probe_264/A} {u_s/bv1_input_diode_12/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n201	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n201	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19218/Z}
set sink_names [list {u_bank/relay_101/A} {u_bank/bv1_input_diode_2/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n202	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n202	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_101/Z}
set sink_names [list {u_s/bv1_delay_probe_288/A} {u_s/bv1_input_diode_13/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n203	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n203	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31464/Z}
set sink_names [list {u_bank/relay_102/A} {u_bank/bv1_input_diode_3/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n204	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n204	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_102/Z}
set sink_names [list {u_s/bv1_delay_probe_312/A} {u_s/bv1_input_diode_14/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n205	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n205	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31463/Z}
set sink_names [list {u_bank/relay_103/A} {u_bank/bv1_input_diode_4/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n206	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n206	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_103/Z}
set sink_names [list {u_s/bv1_delay_probe_336/A} {u_s/bv1_input_diode_15/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n207	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n207	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19217/Z}
set sink_names [list {u_bank/relay_104/A} {u_bank/bv1_input_diode_5/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n208	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n208	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_104/Z}
set sink_names [list {u_s/bv1_input_diode_16/A} {u_s/bv1_delay_probe_360/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n209	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n209	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31462/Z}
set sink_names [list {u_bank/relay_105/A} {u_bank/bv1_input_diode_6/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n210	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n210	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_105/Z}
set sink_names [list {u_s/bv1_delay_probe_384/A} {u_s/bv1_input_diode_17/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n211	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n211	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19216/Z}
set sink_names [list {u_bank/relay_106/A} {u_bank/bv1_input_diode_7/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n212	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n212	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_106/Z}
set sink_names [list {u_s/bv1_delay_probe_408/A} {u_s/bv1_input_diode_18/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n213	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n213	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19215/Z}
set sink_names [list {u_bank/relay_107/A} {u_bank/bv1_input_diode_8/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n214	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n214	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_107/Z}
set sink_names [list {u_s/bv1_delay_probe_432/A} {u_s/bv1_input_diode_19/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n215	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n215	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31461/Z}
set sink_names [list {u_bank/relay_108/A} {u_bank/bv1_input_diode_9/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n216	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n216	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_108/Z}
set sink_names [list {u_s/bv1_delay_probe_456/A} {u_s/bv1_input_diode_20/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n217	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n217	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31460/Z}
set sink_names [list {u_bank/relay_109/A} {u_bank/bv1_input_diode_10/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n218	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n218	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_109/Z}
set sink_names [list {u_s/bv1_delay_probe_480/A} {u_s/bv1_input_diode_21/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n219	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n219	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31458/Z}
set sink_names [list {u_bank/relay_110/A} {u_bank/bv1_input_diode_12/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n220	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n220	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_110/Z}
set sink_names [list {u_s/bv1_delay_probe_528/A} {u_s/bv1_input_diode_23/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n221	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n221	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31457/Z}
set sink_names [list {u_bank/relay_111/A} {u_bank/bv1_input_diode_13/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n222	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n222	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_111/Z}
set sink_names [list {u_s/bv1_delay_probe_552/A} {u_s/bv1_input_diode_24/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n223	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n223	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31456/Z}
set sink_names [list {u_bank/relay_112/A} {u_bank/bv1_input_diode_14/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n224	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n224	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_112/Z}
set sink_names [list {u_s/bv1_delay_probe_576/A} {u_s/bv1_input_diode_25/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n225	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n225	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31455/Z}
set sink_names [list {u_bank/relay_113/A} {u_bank/bv1_input_diode_15/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n226	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n226	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_113/Z}
set sink_names [list {u_s/bv1_input_diode_26/A} {u_s/bv1_delay_probe_600/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n227	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n227	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31454/Z}
set sink_names [list {u_bank/relay_114/A} {u_bank/bv1_input_diode_16/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n228	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n228	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_114/Z}
set sink_names [list {u_s/bv1_delay_probe_624/A} {u_s/bv1_input_diode_27/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n229	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n229	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31453/Z}
set sink_names [list {u_bank/relay_115/A} {u_bank/bv1_input_diode_17/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n230	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n230	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_115/Z}
set sink_names [list {u_s/bv1_delay_probe_648/A} {u_s/bv1_input_diode_28/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n231	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n231	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31452/Z}
set sink_names [list {u_bank/relay_116/A} {u_bank/bv1_input_diode_18/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n232	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n232	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_116/Z}
set sink_names [list {u_s/bv1_delay_probe_672/A} {u_s/bv1_input_diode_29/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n233	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n233	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31451/Z}
set sink_names [list {u_bank/relay_117/A} {u_bank/bv1_input_diode_19/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n234	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n234	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_117/Z}
set sink_names [list {u_s/bv1_delay_probe_696/A} {u_s/bv1_input_diode_30/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n235	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n235	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19214/Z}
set sink_names [list {u_bank/relay_118/A} {u_bank/bv1_input_diode_20/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n236	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n236	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_118/Z}
set sink_names [list {u_s/bv1_input_diode_31/A} {u_s/bv1_delay_probe_720/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n237	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n237	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19213/Z}
set sink_names [list {u_bank/relay_119/A} {u_bank/bv1_input_diode_21/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n238	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n238	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_119/Z}
set sink_names [list {u_s/bv1_delay_probe_744/A} {u_s/bv1_input_diode_32/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n239	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n239	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31449/Z}
set sink_names [list {u_bank/relay_120/A} {u_bank/bv1_input_diode_23/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n240	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n240	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_120/Z}
set sink_names [list {u_s/bv1_delay_probe_792/A} {u_s/bv1_input_diode_34/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n241	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n241	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31448/Z}
set sink_names [list {u_bank/relay_121/A} {u_bank/bv1_input_diode_24/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n242	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n242	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_121/Z}
set sink_names [list {u_s/bv1_delay_probe_816/A} {u_s/bv1_input_diode_35/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n243	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n243	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31447/Z}
set sink_names [list {u_bank/relay_122/A} {u_bank/bv1_input_diode_25/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n244	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n244	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_122/Z}
set sink_names [list {u_s/bv1_input_diode_36/A} {u_s/bv1_delay_probe_840/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n245	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n245	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31446/Z}
set sink_names [list {u_bank/relay_123/A} {u_bank/bv1_input_diode_26/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n246	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n246	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_123/Z}
set sink_names [list {u_s/bv1_input_diode_37/A} {u_s/bv1_delay_probe_864/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n247	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n247	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31445/Z}
set sink_names [list {u_bank/relay_124/A} {u_bank/bv1_input_diode_27/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n248	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n248	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_124/Z}
set sink_names [list {u_s/bv1_delay_probe_888/A} {u_s/bv1_input_diode_38/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n249	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n249	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31444/Z}
set sink_names [list {u_bank/relay_125/A} {u_bank/bv1_input_diode_28/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n250	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n250	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_125/Z}
set sink_names [list {u_s/bv1_delay_probe_912/A} {u_s/bv1_input_diode_39/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n251	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n251	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19212/Z}
set sink_names [list {u_bank/relay_126/A} {u_bank/bv1_input_diode_29/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n252	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n252	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_126/Z}
set sink_names [list {u_s/bv1_delay_probe_936/A} {u_s/bv1_input_diode_40/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n253	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n253	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31443/Z}
set sink_names [list {u_bank/relay_127/A} {u_bank/bv1_input_diode_30/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n254	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n254	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_127/Z}
set sink_names [list {u_s/bv1_delay_probe_960/A} {u_s/bv1_input_diode_41/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n255	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n255	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19197/Z}
set sink_names [list {u_bank/relay_128/A} {u_bank/bv1_input_diode_31/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n256	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n256	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_128/Z}
set sink_names [list {u_s/bv1_delay_probe_0/A} {u_s/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n257	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n257	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19196/Z}
set sink_names [list {u_bank/bv1_input_diode_32/A} {u_bank/relay_129/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n258	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n258	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_129/Z}
set sink_names [list {u_s/bv1_delay_probe_24/A} {u_s/bv1_input_diode_1/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n259	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n259	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19195/Z}
set sink_names [list {u_bank/relay_130/A} {u_bank/bv1_input_diode_34/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n260	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n260	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_130/Z}
set sink_names [list {u_s/bv1_delay_probe_48/A} {u_s/bv1_input_diode_2/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n261	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n261	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19194/Z}
set sink_names [list {u_bank/relay_131/A} {u_bank/bv1_input_diode_35/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n262	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n262	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_131/Z}
set sink_names [list {u_s/bv1_delay_probe_72/A} {u_s/bv1_input_diode_3/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n263	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n263	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19193/Z}
set sink_names [list {u_bank/relay_132/A} {u_bank/bv1_input_diode_36/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n264	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n264	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_132/Z}
set sink_names [list {u_s/bv1_delay_probe_96/A} {u_s/bv1_input_diode_4/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n265	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n265	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19192/Z}
set sink_names [list {u_bank/relay_133/A} {u_bank/bv1_input_diode_37/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n266	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n266	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_133/Z}
set sink_names [list {u_s/bv1_delay_probe_120/A} {u_s/bv1_input_diode_5/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n267	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n267	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19191/Z}
set sink_names [list {u_bank/relay_134/A} {u_bank/bv1_input_diode_38/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n268	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n268	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_134/Z}
set sink_names [list {u_s/bv1_delay_probe_144/A} {u_s/bv1_input_diode_6/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n269	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n269	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19190/Z}
set sink_names [list {u_bank/relay_135/A} {u_bank/bv1_input_diode_39/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n270	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n270	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_135/Z}
set sink_names [list {u_s/bv1_input_diode_7/A} {u_s/bv1_delay_probe_168/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n271	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n271	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19189/Z}
set sink_names [list {u_bank/relay_136/A} {u_bank/bv1_input_diode_40/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n272	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n272	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_136/Z}
set sink_names [list {u_s/bv1_input_diode_8/A} {u_s/bv1_delay_probe_192/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n273	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n273	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19188/Z}
set sink_names [list {u_bank/relay_137/A} {u_bank/bv1_input_diode_41/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_137/Z}
set sink_names [list {u_s/bv1_delay_probe_216/A} {u_s/bv1_input_diode_9/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n275	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n275	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19177/Z}
set sink_names [list {u_bank/relay_138/A} {u_bank/bv1_input_diode_42/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n276	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n276	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_138/Z}
set sink_names [list {u_s/bv1_input_diode_139/A} {u_s/bv1_delay_probe_3312/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n277	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n277	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_s/wire77944/Z}
set sink_names [list {u_booster/relay_0/A} {u_booster/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n278	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n278	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_booster/relay_0/Z}
set sink_names [list {u_return/relay_0/A} {u_return/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n279	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n279	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_return/relay_0/Z}
set sink_names [list {u_t/bv1_delay_probe_1104/A} {u_t/bv1_input_diode_47/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n280	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n280	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
close $f
source {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-935/src/project/experiments/block_v1/native_annotation.tcl}
