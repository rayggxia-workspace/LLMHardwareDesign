set_thread_count 16
read_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-940/tasks/linkfix-s-finish/flow/results/nangate45/bv1_block_v1_s16k/base/6_final.odb}
drt::check_drc_cmd final-native-drc.rpt 0 0 0 0 native_whole_drc
