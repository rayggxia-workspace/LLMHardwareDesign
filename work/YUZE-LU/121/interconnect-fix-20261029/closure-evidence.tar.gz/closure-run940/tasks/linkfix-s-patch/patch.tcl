set_thread_count 16
read_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-928/tasks/linkfix-native-s/flow/results/nangate45/bv1_block_v1_s16k/base/5_2_route.odb}
write_def before.def
drt::check_drc_cmd before-native-drc.rpt 0 0 0 0 native_whole_drc
set b [ord::get_db_block]
set matches {}
foreach n [$b getNets] {if {[string map [list [format %c 92] {}] [$n getName]] eq {words[674][3]}} {lappend matches $n}}
if {[llength $matches]!=1} {error {Ambiguous target net}}
set n [lindex $matches 0]
set e [odb::new_dbWireEncoder]
odb::dbWireEncoder_append $e [$n getWire]
odb::dbWireEncoder_newPath $e [[ord::get_db_tech] findLayer metal2] ROUTED
odb::dbWireEncoder_addPoint $e 362260 1806770
odb::dbWireEncoder_addRect $e 0 0 200 60
odb::dbWireEncoder_end $e
odb::delete_dbWireEncoder $e
set matches {}
foreach n [$b getNets] {if {[string map [list [format %c 92] {}] [$n getName]] eq {words[232][62]}} {lappend matches $n}}
if {[llength $matches]!=1} {error {Ambiguous target net}}
set n [lindex $matches 0]
set e [odb::new_dbWireEncoder]
odb::dbWireEncoder_append $e [$n getWire]
odb::dbWireEncoder_newPath $e [[ord::get_db_tech] findLayer metal2] ROUTED
odb::dbWireEncoder_addPoint $e 2875960 2001090
odb::dbWireEncoder_addRect $e 0 0 200 70
odb::dbWireEncoder_end $e
odb::delete_dbWireEncoder $e
write_db patched.odb
write_def patched.def
