set_thread_count 16
read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-mtr/m-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-mtr/t-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-mtr/bridge-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-mtr/booster-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-case-mtr-length2/wrapper.v}
link_design interconnect_fixture
set_cmd_units -time ns -capacitance fF -resistance kOhm -distance um
set_units -time ns -capacitance fF -resistance kOhm -distance um
create_clock -name core -period 3.333333333333333 [get_ports clk]
set_clock_uncertainty 0.1 [get_clocks core]
set_clock_transition 0.05 [get_clocks core]
set data_inputs {}
foreach p [all_inputs] {if {[get_full_name $p] ne "clk"} {lappend data_inputs $p}}
set_input_delay -clock core -min 0.2 $data_inputs
set_input_delay -clock core -max 0.8 $data_inputs
set_output_delay -clock core -min 0.2 [all_outputs]
set_output_delay -clock core -max 0.8 [all_outputs]
set_driving_cell -lib_cell BUF_X2 -pin Z $data_inputs
set_load 50 [all_outputs]
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-mtr/prepared/common-direct.spef}
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-case-mtr-length2/links.spef}
set_propagated_clock [all_clocks]
sta::find_timing
report_units
write_sdc -digits 12 constraints-readback.sdc
report_parasitic_annotation -report_unannotated > annotation.rpt
set f [open summary.tsv w]
puts $f "setup_count\t[sta::endpoint_violation_count max]"
puts $f "hold_count\t[sta::endpoint_violation_count min]"
puts $f "time_unit_seconds\t[sta::time_ui_sta 1]"
puts $f "cap_unit_farads\t[sta::capacitance_ui_sta 1]"
foreach kind {capacitance slew fanout} {
 puts $f "$kind\t[sta::max_${kind}_violation_count]\t[sta::max_${kind}_check_slack]\t[sta::max_${kind}_check_limit]"
}
close $f
report_worst_slack -max -digits 12 > timing.rpt
report_worst_slack -min -digits 12 >> timing.rpt
report_checks -path_delay min_max -group_path_count 5 -format full_clock_expanded -digits 12 >> timing.rpt
report_check_types -max_capacitance -max_slew -max_fanout -violators -digits 12 -no_line_splits > electrical.rpt
set setup_stream [open check-setup.rpt w]
puts $setup_stream [check_setup -verbose]
close $setup_stream
set f [open links.tsv w]
set source_name {u_m/wire2920/Z}
set sink_names [list {u_bridge/hold191/A} {u_bridge/bv1_input_diode_7/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire9003/Z}
set sink_names [list {u_bridge/hold196/A} {u_bridge/bv1_input_diode_134/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n009	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n009	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2894/Z}
set sink_names [list {u_bridge/hold259/A} {u_bridge/bv1_input_diode_37/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n127	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n127	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2861/Z}
set sink_names [list {u_bridge/input137/A} {u_bridge/bv1_input_diode_137/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n128	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n128	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2863/Z}
set sink_names [list {u_bridge/input135/A} {u_bridge/bv1_input_diode_135/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n129	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n129	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire2862/Z}
set sink_names [list {u_bridge/input136/A} {u_bridge/bv1_input_diode_136/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n130	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n130	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_m/wire15650/Z}
set sink_names [list {u_bridge/input4/A} {u_bridge/bv1_input_diode_4/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n131	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n131	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_response_ready_0/Z}
set sink_names [list {u_m/hold18237/A} {u_m/bv1_input_diode_141/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n132	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n132	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_0/Z}
set sink_names [list {u_t/bv1_delay_probe_1200/A} {u_t/bv1_input_diode_51/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n133	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n133	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_9/Z}
set sink_names [list {u_t/bv1_delay_probe_4248/A} {u_t/bv1_input_diode_178/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n142	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n142	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_data_127/Z}
set sink_names [list {u_t/bv1_delay_probe_1920/A} {u_t/bv1_input_diode_81/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n260	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n260	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_valid_0/Z}
set sink_names [list {u_t/bv1_input_diode_189/A} {u_t/bv1_delay_probe_4512/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n261	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n261	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_0/Z}
set sink_names [list {u_t/bv1_delay_probe_4272/A} {u_t/bv1_input_diode_179/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n262	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n262	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bridge/drive_write_index_9/Z}
set sink_names [list {u_t/bv1_delay_probe_4488/A} {u_t/bv1_input_diode_188/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n271	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n271	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire4111/Z}
set sink_names [list {u_booster/relay_0/A} {u_booster/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n272	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n272	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_booster/relay_0/Z}
set sink_names [list {u_return/relay_0/A} {u_return/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n273	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n273	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_return/relay_0/Z}
set sink_names [list {u_bridge/input139/A} {u_bridge/bv1_input_diode_139/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
close $f
source {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/src/project/experiments/block_v1/native_annotation.tcl}
