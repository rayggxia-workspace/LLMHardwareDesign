set_thread_count 16
read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-tsr/t-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-tsr/s-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-tsr/bank-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-tsr/booster-with-physical.v}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-case-tsr-load4/wrapper.v}
link_design interconnect_fixture
set_cmd_units -time ns -capacitance fF -resistance kOhm -distance um
set_units -time ns -capacitance fF -resistance kOhm -distance um
create_clock -name core -period 3.333333333333333 [get_ports clk]
set_clock_uncertainty 0.1 [get_clocks core]
set_clock_transition 0.05 [get_clocks core]
set data_inputs {}
foreach p [all_inputs] {if {[get_full_name $p] ne "clk"} {lappend data_inputs $p}}
set_input_delay -clock core -min 0.2 $data_inputs
set_input_delay -clock core -max 0.8 $data_inputs
set_output_delay -clock core -min 0.2 [all_outputs]
set_output_delay -clock core -max 0.8 [all_outputs]
set_driving_cell -lib_cell BUF_X2 -pin Z $data_inputs
set_load 50 [all_outputs]
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-prepare-tsr/prepared/common-direct.spef}
read_spef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/tasks/linkclose-case-tsr-load4/links.spef}
set_propagated_clock [all_clocks]
sta::find_timing
report_units
write_sdc -digits 12 constraints-readback.sdc
report_parasitic_annotation -report_unannotated > annotation.rpt
set f [open summary.tsv w]
puts $f "setup_count\t[sta::endpoint_violation_count max]"
puts $f "hold_count\t[sta::endpoint_violation_count min]"
puts $f "time_unit_seconds\t[sta::time_ui_sta 1]"
puts $f "cap_unit_farads\t[sta::capacitance_ui_sta 1]"
foreach kind {capacitance slew fanout} {
 puts $f "$kind\t[sta::max_${kind}_violation_count]\t[sta::max_${kind}_check_slack]\t[sta::max_${kind}_check_limit]"
}
close $f
report_worst_slack -max -digits 12 > timing.rpt
report_worst_slack -min -digits 12 >> timing.rpt
report_checks -path_delay min_max -group_path_count 5 -format full_clock_expanded -digits 12 >> timing.rpt
report_check_types -max_capacitance -max_slew -max_fanout -violators -digits 12 -no_line_splits > electrical.rpt
set setup_stream [open check-setup.rpt w]
puts $setup_stream [check_setup -verbose]
close $setup_stream
set f [open links.tsv w]
set source_name {u_t/wire31465/Z}
set sink_names [list {u_bank/relay_0/A} {u_bank/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n000	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_0/Z}
set sink_names [list {u_s/bv1_delay_probe_240/A} {u_s/bv1_input_diode_11/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n001	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n001	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31363/Z}
set sink_names [list {u_bank/relay_9/A} {u_bank/bv1_input_diode_139/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n018	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n018	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_9/Z}
set sink_names [list {u_s/bv1_delay_probe_3288/A} {u_s/bv1_input_diode_138/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n019	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n019	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire31443/Z}
set sink_names [list {u_bank/relay_127/A} {u_bank/bv1_input_diode_30/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n254	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n254	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_127/Z}
set sink_names [list {u_s/bv1_delay_probe_960/A} {u_s/bv1_input_diode_41/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n255	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n255	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19197/Z}
set sink_names [list {u_bank/relay_128/A} {u_bank/bv1_input_diode_31/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n256	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n256	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_128/Z}
set sink_names [list {u_s/bv1_delay_probe_0/A} {u_s/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n257	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n257	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19188/Z}
set sink_names [list {u_bank/relay_137/A} {u_bank/bv1_input_diode_41/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n274	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_137/Z}
set sink_names [list {u_s/bv1_delay_probe_216/A} {u_s/bv1_input_diode_9/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n275	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n275	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_t/wire19177/Z}
set sink_names [list {u_bank/relay_138/A} {u_bank/bv1_input_diode_42/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n276	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n276	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_bank/relay_138/Z}
set sink_names [list {u_s/bv1_input_diode_139/A} {u_s/bv1_delay_probe_3312/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n277	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n277	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_s/wire77944/Z}
set sink_names [list {u_booster/relay_0/A} {u_booster/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n278	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n278	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_booster/relay_0/Z}
set sink_names [list {u_return/relay_0/A} {u_return/bv1_input_diode_0/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n279	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n279	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set source_name {u_return/relay_0/Z}
set sink_names [list {u_t/bv1_delay_probe_1104/A} {u_t/bv1_input_diode_47/A}]
set source_pins [get_pins -quiet $source_name]
if {[llength $source_pins]!=1} {error "Missing actual native source driver: $source_name"}
set sink_pins [get_pins -quiet $sink_names]
if {[llength $sink_pins]!=[llength $sink_names]} {error "Missing actual native receiver pins"}
set paths [find_timing_paths -path_delay max -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n280	max	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
set paths [find_timing_paths -path_delay min -through $source_pins -through $sink_pins -group_path_count 1]
if {![llength $paths]} {error "No constrained real producer-to-consumer path"}
set p [lindex $paths 0]
foreach candidate $paths {if {[get_property $candidate slack] < [get_property $p slack]} {set p $candidate}}
puts $f "n280	min	[get_property $p slack]	[get_full_name [get_property $p startpoint]]	[get_full_name [get_property $p endpoint]]"
close $f
source {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-121/block-v1-20261029-923/src/project/experiments/block_v1/native_annotation.tcl}
