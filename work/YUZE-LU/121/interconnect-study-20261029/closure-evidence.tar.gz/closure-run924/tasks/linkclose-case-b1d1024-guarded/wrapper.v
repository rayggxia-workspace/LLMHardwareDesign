module interconnect_fixture (clk, driver_canary, driver_i, driver_reset, relay0_canary, relay0_o, relay0_reset);
input clk;
output driver_canary;
input driver_i;
input driver_reset;
output relay0_canary;
output relay0_o;
input relay0_reset;
wire n000;
linkclose_buffer1 u_driver (.canary(driver_canary), .clk(clk), .i(driver_i), .o(n000), .reset(driver_reset));
linkclose_buffer1 u_relay0 (.canary(relay0_canary), .clk(clk), .i(n000), .o(relay0_o), .reset(relay0_reset));
endmodule
