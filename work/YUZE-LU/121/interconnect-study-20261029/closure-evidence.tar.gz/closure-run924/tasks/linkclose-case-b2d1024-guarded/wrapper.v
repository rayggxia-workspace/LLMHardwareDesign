module interconnect_fixture (clk, driver_canary, driver_i, driver_reset, relay0_canary, relay0_o, relay0_reset, relay1_canary, relay1_o, relay1_reset);
input clk;
output driver_canary;
input driver_i;
input driver_reset;
output relay0_canary;
output relay0_o;
input relay0_reset;
output relay1_canary;
output relay1_o;
input relay1_reset;
wire n000;
linkclose_buffer1 u_driver (.canary(driver_canary), .clk(clk), .i(driver_i), .o(n000), .reset(driver_reset));
linkclose_buffer1 u_relay0 (.canary(relay0_canary), .clk(clk), .i(n000), .o(relay0_o), .reset(relay0_reset));
linkclose_buffer1 u_relay1 (.canary(relay1_canary), .clk(clk), .i(n000), .o(relay1_o), .reset(relay1_reset));
endmodule
