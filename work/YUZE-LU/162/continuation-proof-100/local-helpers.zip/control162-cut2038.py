"""Bounded mathematical necessary cut check, never physical qualification."""
from pathlib import Path
import hashlib,json
p=Path(__file__).parent/'control162-receive1988/input.txt'
lines=p.read_text(encoding='utf-8').splitlines();h=list(map(int,lines[0].split()));nx,ny,count=h[:3]
nets=[]
for line in lines[1:]:
 r=line.split();k=int(r[1]);assert len(r)==3+2*k
 ps=[tuple(map(int,r[2+2*i:4+2*i]))for i in range(k)]
 nets.append(ps)
assert len(nets)==count==11149
cuts=[]
for axis,n,other in [(0,nx,ny),(1,ny,nx)]:
 delta=[0]*(n+1)
 for ps in nets:
  lo=min(p[axis]for p in ps);hi=max(p[axis]for p in ps)
  delta[lo]+=1;delta[hi]-=1
 demand=0;capacity=2*(other-8)
 for x in range(n):
  demand+=delta[x]
  if 4<=x<n-5:cuts.append(dict(axis=axis,after=x,demand=demand,capacity=capacity,ratio=demand/capacity))
result=dict(passed=True,whole_system_qualified=False,input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),grid=[nx,ny],nets=count,top_cuts=sorted(cuts,key=lambda r:r['ratio'],reverse=True)[:20],necessary_violations=sum(r['demand']>r['capacity']for r in cuts),scope='Exact terminal-separation lower demand across each complete straight cut, capacity includes both physical layers in either direction. No preferred-direction assumption, no inferred routing feasibility. Local bounded mathematical diagnostic only.')
out=Path(__file__).parent/'control162-cut2038.json';assert not out.exists();out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
