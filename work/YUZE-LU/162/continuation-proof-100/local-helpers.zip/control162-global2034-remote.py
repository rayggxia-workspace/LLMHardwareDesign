from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';source=b/'source-2031';record=b/'route-selection-102/sready2034-current-global-round';assert not record.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();audit=b/'r256-current-global-grid-source-audit-2033/receipt.json';assert json.loads(audit.read_text())['passed'];record.mkdir()
parent=root/'upper-candidates/20000/route/trial-0';inp=parent/'input.txt';snapshot=parent/'output.txt.global-round-8.txt';original_log=parent/'router.log';assert snapshot.is_file();prefix=[]
with original_log.open('rb')as f:
 for line in f:
  assert line.endswith(b'\n'),'Partial live line reached before stable snapshot marker';prefix.append(line)
  if b'"global_snapshot_round":8'in line:
   row=json.loads(line);assert row['global_snapshot_nets']==11149 and row['diagnostic_only'];break
 else:raise AssertionError('Actual completed snapshot marker missing')
raw=b''.join(prefix);log=record/'actual-round8-log-prefix.log';log.write_bytes(raw)
with original_log.open('rb')as f:assert f.read(len(raw))==raw
graph=root/'topology/boundary-graph.json';cfg=dict(schema='control162-global-round-diagnostic-v1',round=8,phase_stride=16)
for name,p in [('input',inp),('snapshot',snapshot),('log',log),('graph',graph)]:cfg[name]=str(p);cfg[name+'_sha256']=sha(p)
config=record/'config.json';config.write_text(json.dumps(cfg,indent=2));out=b/'r256-current-global-round-20340';task=b/'dynamic-04/node25/pending/00-a-sready2034-current-global-round-20340.json';assert not task.exists()and not out.exists()
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=8,requires=list(map(str,[audit,root/'final-chain-binding-audit-2000/receipt.json'])),args=list(map(str,['--manifest',root/'selected/physical.json','--graph',graph,'--global-snapshot-analysis-config',config,'--out',out])))
result=dict(time=time.time(),tasks=[dict(path=str(task),spec=spec)],whole_system_qualified=False,config=str(config),config_sha256=sha(config),actual_input_sha256=sha(inp),snapshot_sha256=sha(snapshot),snapshot_bytes=snapshot.stat().st_size,original_live_log=str(original_log),immutable_actual_log_prefix_bytes=len(raw),immutable_actual_log_prefix_sha256=sha(log),scope='Actualcomplete11149net fullround7 state, snapshot8 diagnostic copiedbyexistingunchangedCPP. Frozenlog is exactoriginalprefix throughcompleted snapshot marker, notgrowingfileSHA. Existingglobalobserver source2031 dimensionsonly, fullflood/wire/parity/exactroundcounts andphaseclassification mandatory. Node25memory-limited16CPUvacancy mayadmit8GiB dataanalysis while65GiB routeswait; originalaggregateguardunchanged, notloweringP&Rforecast orcancelinganytask. No route/system qualification.')
(record/'tasks.json').write_text(json.dumps(result,indent=2));tmp=task.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(task);print(json.dumps(dict(queued=1,snapshot_bytes=snapshot.stat().st_size,forecast_gib=8,whole_system_qualified=False)))
