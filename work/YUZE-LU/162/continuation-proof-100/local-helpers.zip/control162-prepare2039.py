from pathlib import Path
b=Path(__file__).parent
original=(b/'control162-full2220-remote.py').read_text(encoding='utf-8')
for tag,growth in [(2340,0),(2350,8)]:
 s=original.replace('22200',str(tag*10)).replace('2220',str(tag))
 old=";k=a.index('--route-native-prefix-input')"
 assert s.count(old)==1
 s=s.replace(old,";a[a.index('--route-ordinary-present-growth')+1]='"+str(growth)+"'"+old)
 old="a[a.index('--route-ordinary-present-growth')+1]=='4'";assert s.count(old)==1
 s=s.replace(old,"a[a.index('--route-ordinary-present-growth')+1]=='"+str(growth)+"'")
 s=s.replace("else'dynamic-04/node25'","else'dynamic-06/node26'")
 # Two diversity slots precede existing pending parameter-grid cases; all
 # existing parents, completed files and pending records remain untouched.
 old="rows.append(dict(path=str(p),spec=spec))";assert s.count(old)==1
 s=s.replace(old,"p=p.with_name(p.name.replace('00-g-sready','00-b-sready')) if spec['script']=='system_upper.py' else p;rows.append(dict(path=str(p),spec=spec))")
 s=s.replace('backendCPPexistingpresentgrowth4','backendCPPexistingpresentgrowth'+str(growth))
 s=s.replace('originalsupported weight1 cost32 coarse32 search','originalsupported weight1 cost32 coarse32 search with bounded ordinary-present schedule comparison')
 s=s.replace('Existingactualnode24naturallyfreedslot afterprovenoldretirement','Existingactualnode24 slot; two redundant weight256 seed replicas may be separately retired only after strict own-step checks, retaining four baseline replicas and every partial result. Search-priority decision, never proof of impossibility')
 p=b/('control162-full'+str(tag)+'-remote.py');assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8')
 print(p.name,'present_growth',growth)
