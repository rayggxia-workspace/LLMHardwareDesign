from pathlib import Path
import subprocess,tarfile,io,json,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();assert head==json.loads((b/'control162-commit2048.json').read_text())['commit'];sha=lambda raw:hashlib.sha256(raw).hexdigest()
with tarfile.open(b/'control162-source2031.tar.gz')as z:old=json.loads(z.extractfile('source-manifest.json').read())
names=sorted(old['files']);assert len(names)==1030;raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(head+':'+n+'\n'for n in names).encode(),cwd=r);stream=io.BytesIO(raw);files={}
for n in names:
 h=stream.readline().split();assert len(h)==3 and h[1]==b'blob';data=stream.read(int(h[2]));assert stream.read(1)==b'\n';files[n]=data
assert not stream.read();changed=[n for n,data in files.items()if sha(data)!=old['files'][n]];expected=['project/experiments/control_v1/'+n for n in ['coarse_refine_regression.py','system_upper.py','tree_router.cpp','tree_router_cpp.py']];assert changed==expected,changed
manifest=dict(commit=head,files={n:sha(raw)for n,raw in files.items()});archive=b/'control162-source2048.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as z:
 for n,data in list(files.items())+[('source-manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;z.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as z:assert all(sha(z.extractfile(n).read())==digest for n,digest in manifest['files'].items())
patch=subprocess.check_output(['git','diff','--binary',old['commit'],head,'--',*changed],cwd=r);(b/'control162-backout2048.patch').write_bytes(patch);receipt=dict(passed=True,commit=head,source_files=1030,unchanged_files=1026,changed_files=changed,archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,patch_sha256=sha(patch),whole_system_qualified=False);(b/'control162-archive2049.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'
for p,n in [(archive,'source2048.tar.gz'),(b/'control162-backout2048.patch','control162-backout2048.patch'),(b/'control162-archive2049.json','control162-archive2049.json'),(b/'control162-contract2047-v2.json','control162-contract2047-v2.json')]:subprocess.run(['scp','-q',str(p),host+':'+remote+n],check=True)
