from pathlib import Path
import json,subprocess
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/ordinary-refresh2048';assert not out.exists();out.mkdir();contract=json.loads((b/'control162-contract2047-v2.json').read_bytes());assert contract['passed']
(out/'contract.json').write_bytes((b/'control162-contract2047-v2.json').read_bytes())
(out/'README.md').write_bytes('''# 默认关闭的普通树周期重布搜索候选

Issue #162 / Draft PR #163。真实全网在约55万冲突附近波动。代码会保留当前clean树，这可能固定占据绕行空间；这里只提出可验证的软件搜索候选，不认定它是全部失败主因。

新增ordinary_refresh=8/16，默认0完全走原搜索分支。只在完整全网阶段的周期边界同时撤除全部ordinary树，沿用撤除前的dirty-first顺序重新搜索；此前clean和dirty计数先共同快照。保留native树、实际landing固定所有权、历史成本、全部有限标签/物理线长预算，以及所有最终门。与其他batch或present-growth调度组合明确拒绝。没有新增硬件、状态宿主、宏、die或互联层。

本地6项Python上下文拒绝、3项CLI拒绝、3文件语法及12份native/最终文件逐字不变检查通过；最初参数草稿的一些拒绝先触及前置条件，正式v2合同使用完整合法基准参数后单独破坏条件。真实CPP编译与回归尚未执行，不能称已验收。

计划在原16CPU空槽运行18份关闭选项的旧路径/native/日志逐字回放，20个实际小图尝试（含已证明超容量负例与可进入后续轮次的pressure例），独立flood/预算/零冲突、实际clean/dirty树共同释放和非法CPP/CLI拒绝。未知失败继续定位，不删检查。测试通过之前不得投入完整组合；小图通过也不替代完整M11/M12/native-XOR/PG/low-base-high 300MHz联合验收。

现有完整候选继续运行。main六宏、S驱动、R及并行修改保留，不合并。规则rayggxia-project-collab1.0.0；登记PR5 pending；看板unverified/同步pending；审查待指定；Issue in_progress / PR Draft。
'''.encode())
for n,prefix in [('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/n;p.write_bytes(f'Issue162：[默认关闭的普通树周期重布候选]({prefix}work/YUZE-LU/162/ordinary-refresh2048/README.md)只改变软件搜索，默认0；本地拒绝/语法/原文件合同通过，真实C++及旧关闭路径重放待冻结审计后执行。全部硬件/预算/最终门不变，现有完整候选继续，组合尚未验收。\n\n'.encode()+p.read_bytes())
files=['project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','coarse_refine_regression.py']]+['docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md',str(out.relative_to(r))]
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r)==b''
for n in files[:-1]:p=r/n;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*files],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:n=raw.decode();assert subprocess.check_output(['git','show',':'+n],cwd=r)==(r/n).read_bytes()
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Add default-off periodic ordinary-tree refresh search experiment'],cwd=r,check=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();(b/'control162-commit2048.json').write_text(json.dumps(dict(commit=head,physical_system_passed=False)),encoding='utf-8');print(head)
p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');needle="'2031','2044')";assert needle in s;s=s.replace(needle,"'2031','2044','2048')");p.write_text(s,encoding='utf-8')
