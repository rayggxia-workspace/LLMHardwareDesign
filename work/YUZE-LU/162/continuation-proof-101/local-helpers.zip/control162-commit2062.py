from pathlib import Path
import json,subprocess,sys,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';here=r/'project/experiments/control_v1';out=r/'work/YUZE-LU/162/twelve-trial2062';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=subprocess.check_output(['git','show','HEAD:project/experiments/control_v1/system_upper.py'],cwd=r);assert(here/'system_upper.py').read_bytes().replace(b'\r\n',b'\n')==old.replace(b'choices=[1,4,8,16],default=1)',b'choices=[1,4,8,12,16],default=1)')
for width in [1,4,8,12,16,0,13,17]:
 target=b/('control162-invalid-width2062-'+str(width));assert not target.exists();p=subprocess.run([sys.executable,str(here/'system_upper.py'),'--manifest',str(b/'absent.json'),'--graph',str(b/'absent.json'),'--out',str(target),'--route-trials',str(width),'--route-ordinary-refresh','8'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode and not target.exists()
 if width in [1,4,8,12,16]:assert b'AssertionError'in p.stderr and b'invalid choice'not in p.stderr
 else:assert b'invalid choice'in p.stderr
contract=dict(passed=True,cli_width_cases=8,existing_unittest_command='python -m unittest test_router_trial_pool -v',actual_unittest_tests=4,unittest_exit_code=0,finite_exhaustion_widths=[2,12],source_sha256={n:sha(here/n)for n in ['system_upper.py','test_router_trial_pool.py','router_trial_pool.py','tree_router.cpp','tree_router_cpp.py']},whole_system_qualified=False,scope='CLI accepts12 and retainsoldchoices; invalidwidths0/13/17 rejectedbeforeout. Actual4localpooltests passed including25failedchildrenatwidth12/no falsewinner/finite exhaustion andoriginaldynamicrefill/launchcleanup/rejections. Only CLIchoice andpooltest changed; actualsource2048CPP/worker/regression/native/final gates unchanged. Earlier23700didnotrunphysicalsearch:actualparserexit2 preserved. New fullwidth12 stillmustexecute allgates.')
(out/'contract.json').write_bytes(json.dumps(contract,indent=2).encode());(b/'control162-contract2062.json').write_bytes(json.dumps(contract,indent=2).encode())
(out/'README.md').write_bytes('''# 内存受限时保留12路独立任务入口

Issue #162 / Draft PR #163。当前node24原四项预测260GiB；加入16路候选预测65GiB需435939180544字节，可用419540267008字节不足。每路4GiB+1GiB开销不变，12路49GiB需415323337523.2字节可满足，13路需420477298278.4字节已超过。保留原20%+16GiB余量和有限64总尝试动态补位。

23700实际49GiB准入通过，但CLI只允许1/4/8/16，在物理执行之前以参数错误退出2；原规格、日志、命令、结果和未执行后继保留。此前遗漏入口限制，不能把这次准入当作实际布线启动。

只在system_upper的route-trials闭合选择中加入12。底层原池已允许1至16，本次不改池实现、CPP、RTL、预算或验收门。8项CLI选择/拒绝检查通过；原4项池测试实际通过，有限耗尽测试补入12路25个失败子任务，确认不虚报成功并全部动态结束。source2048实际28小图回归/18关闭路径字节重放可据逐字相同CPP/worker/回归源复用，新增完整候选仍须独立布局布线和所有物理门。

当前main六宏、S内部驱动、R及并行工作不动。完整组合仍未联合验收，不合并。规则rayggxia-project-collab1.0.0；登记PR5 pending；看板unverified/同步pending；审查待指定；Issue in_progress / PR Draft。
'''.encode())
for n,prefix in [('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/n;p.write_bytes(f'Issue162：[内存受限12路入口修复]({prefix}work/YUZE-LU/162/twelve-trial2062/README.md)：23700实际内存准入后被旧CLI拒绝、未物理执行。只补入底层原池已支持的12路选择，8项CLI和4项池测试通过；原CPP/worker/物理门不变，待冻结审计后重试全部七阶段。组合仍未验收，继续。\n\n'.encode()+p.read_bytes())
files=['project/experiments/control_v1/system_upper.py','project/experiments/control_v1/test_router_trial_pool.py','docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md',str(out.relative_to(r))]
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r)==b''
for n in files[:-1]:p=r/n;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*files],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:n=raw.decode();assert subprocess.check_output(['git','show',':'+n],cwd=r)==(r/n).read_bytes(),n
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Expose existing twelve-trial pool width for memory-limited routing slots'],cwd=r,check=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();(b/'control162-commit2062.json').write_text(json.dumps(dict(commit=head,physical_system_passed=False)),encoding='utf-8');print(head)
p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');needle="'2044','2050')";assert needle in s;s=s.replace(needle,"'2044','2050','2062')");p.write_text(s,encoding='utf-8')
