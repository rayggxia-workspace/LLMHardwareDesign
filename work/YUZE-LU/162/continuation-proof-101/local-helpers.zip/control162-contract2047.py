from pathlib import Path
import sys,json,hashlib,subprocess
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';here=r/'project/experiments/control_v1';sys.path.insert(0,str(here))
from tree_router_cpp import route
valid=dict(heuristic_weight=256,locked_names=[],wire_limits={},negotiated_priority=True,defer_access_vias=True,congestion_scale=1,bidirectional_two_terminal=True,weighted_bidirectional=True,pareto_wire_budget=True,critical_first=True,native_prefix_first=True,native_prefix_flexible=True,ordinary_coarse_grid_stride=16,ordinary_coarse_access=True,weighted_settle_once=True,coarse_refine=True,ordinary_zero_pattern=True,ordinary_coarse_static=True,ordinary_coarse_multicast=True,ordinary_coarse_zero=True,ordinary_refresh=8)
cases=[dict(ordinary_refresh=4),dict(native_prefix_flexible=False),dict(coarse_refine=False),dict(global_batch_ripup=True),dict(ordinary_present_growth=4),dict(ordinary_present_growth=8)]
for i,kw in enumerate(cases):
 target=b/('control162-invalid-refresh2047-'+str(i));assert not target.exists()
 try:route({},40,40,1,80,target,**dict(valid,**kw))
 except AssertionError:assert not target.exists()
 else:raise AssertionError('Invalid refresh context accepted')
for period in ['8','16','4']:
 target=b/('control162-invalid-cli-refresh2047-'+period);assert not target.exists();p=subprocess.run([sys.executable,str(here/'system_upper.py'),'--manifest',str(b/'absent.json'),'--graph',str(b/'absent.json'),'--out',str(target),'--route-ordinary-refresh',period],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode and not target.exists()
changed={line.strip()for line in subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=r).decode().splitlines()};expected={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','coarse_refine_regression.py']};assert changed==expected,changed
gates=['resource_search.h','native_prefix_seed.h','ordinary_coarse_grid.h','weighted_settled_bidirectional.h','system_geometry.py','system_sta.py','system_accept.py','final_composition.py','native_pin_load.py','native_cap_residual.py','upper_cap_bound.py','steiner_wire_bound.py']
for n in gates:assert(here/n).read_bytes()==subprocess.check_output(['git','show','HEAD:project/experiments/control_v1/'+n],cwd=r)
for n in ['tree_router_cpp.py','system_upper.py','coarse_refine_regression.py']:compile((here/n).read_bytes(),n,'exec')
result=dict(passed=True,python_negative_contexts=len(cases),cli_negative_contexts=3,syntax_files=3,final_and_native_files_unchanged=gates,source_sha256={n:hashlib.sha256((here/n).read_bytes()).hexdigest()for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','coarse_refine_regression.py',*gates]},whole_system_qualified=False,scope='Local parser/context/syntax and unchanged-file contract only. Actual C++ compile, old disabled byteexact replay, 20 small full attempts, periodic-clean/dirty release and full physical acceptance still pending.')
p=b/'control162-contract2047-v2.json';assert not p.exists();p.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k!='source_sha256'}))
