from pathlib import Path
r=Path(__file__).parent/'LLMHardwareDesign-worktrees/issue-162-control';base=r/'project/experiments/control_v1';changes={}
def edit(name,old,new):
 s=changes.get(name,(base/name).read_text(encoding='utf-8'));assert s.count(old)==1,(name,old[:70],s.count(old));changes[name]=s.replace(old,new)
edit('tree_router.cpp',' int ordinary_coarse_rounds=64;',' int ordinary_refresh=0;int ordinary_coarse_rounds=64;')
edit('tree_router.cpp','  else if(option=="--ordinary-coarse-refine")','  else if(option=="--ordinary-refresh=8"||option=="--ordinary-refresh=16"){if(ordinary_refresh)throw runtime_error("duplicate ordinary refresh");ordinary_refresh=stoi(option.substr(option.find(\'=\')+1));}\n  else if(option=="--ordinary-coarse-refine")')
edit('tree_router.cpp',' if(coarse_refine&&(!weighted_settle_once',' if(ordinary_refresh&&(!native_flexible||!coarse_refine||global_batch||ordinary_present_growth))throw runtime_error("ordinary refresh requires flexible guided mode without other batch/growth schedules");\n if(coarse_refine&&(!weighted_settle_once')
marker='  if(!native_stage&&global_batch&&iteration){'
refresh='''  // Optional software search experiment. Dirty-first ordering was computed
  // above using actual previous occupancy. Periodically release ALL ordinary
  // trees together so clean old routes cannot permanently reserve a corridor.
  // Native trees, real landing ownership, history and finite budgets remain.
  // Disabled mode executes exactly the old path; no acceptance is inferred.
  if(!native_stage&&ordinary_refresh&&iteration&&iteration%ordinary_refresh==0){
   int clean=0,dirty=0;uint64_t vertices=0;
   for(int n=locked_count;n<count;++n){
    if(trees[n].empty())throw runtime_error("missing ordinary tree before refresh");
    bool conflicted=any_of(trees[n].begin(),trees[n].end(),[&](int v){return usage[v]>1;});
    if(conflicted)++dirty;else ++clean;batch_removed[n]=1;
   }
   for(int n=locked_count;n<count;++n){
    for(int v:trees[n]){if(!usage[v])throw runtime_error("ordinary refresh usage underflow");--usage[v];++vertices;}
    trees[n].clear();branches[n].clear();
   }
   cout<<"{\\"round\\":"<<iteration<<",\\"ordinary_refresh_period\\":"<<ordinary_refresh<<",\\"ordinary_refresh_clean_trees\\":"<<clean<<",\\"ordinary_refresh_dirty_trees\\":"<<dirty<<",\\"ordinary_refresh_removed_vertices\\":"<<vertices<<",\\"native_trees_retained\\":"<<locked_count<<"}"<<endl;
  }
'''
edit('tree_router.cpp',marker,refresh+marker)
edit('tree_router_cpp.py','coarse_refine=False,ordinary_present_growth=0):','coarse_refine=False,ordinary_present_growth=0,ordinary_refresh=0):')
edit('tree_router_cpp.py','    assert ordinary_present_growth in (0,4,8)','    assert ordinary_refresh in (0,8,16)\n    assert not ordinary_refresh or(native_prefix_flexible and coarse_refine and not global_batch_ripup and not ordinary_present_growth)\n    if ordinary_refresh:extra_cli.append("--ordinary-refresh="+str(ordinary_refresh))\n    assert ordinary_present_growth in (0,4,8)')
edit('tree_router_cpp.py','        ordinary_present_growth=ordinary_present_growth,ordinary_present_trace=',"        ordinary_refresh=ordinary_refresh,ordinary_refresh_trace=[r for r in trace if 'ordinary_refresh_period'in r],\n        ordinary_present_growth=ordinary_present_growth,ordinary_present_trace=")
edit('system_upper.py',"    p.add_argument('--route-ordinary-present-growth'","    p.add_argument('--route-ordinary-refresh',type=int,choices=[0,8,16],default=0,help='Search only: periodically release all ordinary trees together; native trees/budgets and final gates unchanged')\n    p.add_argument('--route-ordinary-present-growth'")
edit('system_upper.py',"    assert not a.route_ordinary_present_growth or(","    assert not a.route_ordinary_refresh or(a.router=='cpp'and a.route_native_prefix_flexible and a.route_ordinary_coarse_refine and not a.route_global_batch_ripup and not a.route_ordinary_present_growth)\n    assert not a.route_ordinary_present_growth or(")
edit('system_upper.py','ordinary_present_growth=a.route_ordinary_present_growth)','ordinary_present_growth=a.route_ordinary_present_growth,ordinary_refresh=a.route_ordinary_refresh)')
edit('coarse_refine_regression.py',"    guided_present_growth=cfg.get('guided_present_growth',0);assert guided_present_growth in (0,4,8)","    guided_present_growth=cfg.get('guided_present_growth',0);assert guided_present_growth in (0,4,8)\n    guided_refresh=cfg.get('guided_refresh',0);assert guided_refresh in (0,8,16)\n    assert not guided_refresh or(not guided_present_growth and not guided_global_batch)")
edit('coarse_refine_regression.py',"    if guided_present_growth:\n        # Deliberately over-capacity", "    if guided_present_growth or guided_refresh:\n        # Deliberately over-capacity")
edit('coarse_refine_regression.py','ordinary_present_growth=guided_present_growth,**options)','ordinary_present_growth=guided_present_growth,ordinary_refresh=guided_refresh,**options)')
edit('coarse_refine_regression.py',"ordinary_present_trace=[r for r in trace if 'ordinary_present_growth_period'in r])","ordinary_present_trace=[r for r in trace if 'ordinary_present_growth_period'in r],ordinary_refresh_trace=[r for r in trace if 'ordinary_refresh_period'in r])")
edit('coarse_refine_regression.py',"if guided_present_growth else[])\n    with concurrent", "if (guided_present_growth or guided_refresh) else[])\n    with concurrent")
edit('coarse_refine_regression.py',"    if guided_global_batch:\n        assert any", "    if guided_refresh:\n        refreshed=[t for r in cases for t in r['ordinary_refresh_trace']]\n        assert refreshed and all(t['round']%guided_refresh==0 and t['native_trees_retained']==8 and t['ordinary_refresh_clean_trees']+t['ordinary_refresh_dirty_trees']>=16 for t in refreshed)\n        assert any(t['ordinary_refresh_clean_trees']>0 for t in refreshed),'No actual previously clean ordinary tree released'\n        assert any(t['ordinary_refresh_dirty_trees']>0 for t in refreshed),'No actual dirty ordinary tree released'\n    if guided_global_batch:\n        assert any")
edit('coarse_refine_regression.py','    rejected=[]\n    for name,flags', '''    rejected=[]
    if guided_refresh:
        for name,flags in [('refresh-no-context',['--ordinary-refresh=8']),('refresh-duplicate',['--ordinary-refresh=8','--ordinary-refresh=8']),('refresh-invalid',['--ordinary-refresh=4'])]:
            target=out/name;default=out/'unchanged-default';p=subprocess.run([str(default/'router'),str(default/'router-input.txt'),str(target),*flags],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(name+'.stderr')).write_bytes(p.stderr)
            assert p.returncode and not target.exists();rejected.append(dict(name=name,returncode=p.returncode))
        target=out/'refresh-cli-no-context';p=subprocess.run([__import__('sys').executable,str(here/'system_upper.py'),'--manifest',str(out/'absent-manifest.json'),'--graph',str(out/'absent-graph.json'),'--out',str(target),'--route-ordinary-refresh','8'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert p.returncode and b'AssertionError'in p.stderr and not target.exists();rejected.append(dict(name='refresh-cli-no-context',returncode=p.returncode))
    for name,flags''')
edit('coarse_refine_regression.py',"    result['guided_present_growth']=guided_present_growth","    result['guided_refresh']=guided_refresh\n    result['guided_present_growth']=guided_present_growth")
for n,s in changes.items():
 if n.endswith('.py'):compile(s,n,'exec')
for n,s in changes.items():(base/n).write_bytes(s.encode())
print('Changed only',sorted(changes))
