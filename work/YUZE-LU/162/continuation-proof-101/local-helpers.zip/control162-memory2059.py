from pathlib import Path
import subprocess,json,shlex
b=Path(__file__).parent
q="from pathlib import Path;import json;b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d=json.loads((b/'dynamic-06/node26/queue-state.json').read_text());print(json.dumps({k:d[k]for k in ['time','active','finished','memory_admissions','waiting_for_complete_receipts']}))"
p=subprocess.run(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=35)
assert p.returncode==0,p.stderr.decode();(b/'control162-memory2059-latest.json').write_bytes(p.stdout);d=json.loads(p.stdout);print(json.dumps({k:v for k,v in d.items()if k!='finished'}));print('23600 finished?',{k:v for k,v in d['finished'].items()if'2360'in k})
