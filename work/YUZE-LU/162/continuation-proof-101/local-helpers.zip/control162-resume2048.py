from pathlib import Path
import subprocess,json
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip()=='d74f9dd67512c311426c5afd3d10361a21e44495'
p=r/'.gitattributes';line=b'work/YUZE-LU/162/ordinary-refresh2048/** -text';raw=p.read_bytes().replace(b'\r\n',b'\n');assert line in raw;p.write_bytes(raw)
subprocess.run(['git','add','--','.gitattributes','work/YUZE-LU/162/ordinary-refresh2048'],cwd=r,check=True)
subprocess.run(['git','add','--renormalize','--','work/YUZE-LU/162/ordinary-refresh2048'],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:
  n=raw.decode();assert n in ['.gitattributes','docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md']or n.startswith('project/experiments/control_v1/')or n.startswith('work/YUZE-LU/162/ordinary-refresh2048/');assert subprocess.check_output(['git','show',':'+n],cwd=r)==(r/n).read_bytes(),n
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Add default-off periodic ordinary-tree refresh search experiment'],cwd=r,check=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();(b/'control162-commit2048.json').write_text(json.dumps(dict(commit=head,physical_system_passed=False,initial_stage_byte_check_rejected_crlf_contract=True,raw_attribute_fixed_and_all_staged_bytes_verified=True)),encoding='utf-8');print(head)
p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');needle="'2031','2044')";assert needle in s;s=s.replace(needle,"'2031','2044','2050')");p.write_text(s,encoding='utf-8')
