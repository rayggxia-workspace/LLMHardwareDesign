from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reference=(root/'upper-candidates/19700/route/trial-14/input.txt').read_bytes();hh,body=reference.split(b'\n',1);header=list(map(int,hh.split()));placement=json.loads((root/'cap-candidates/19540/placement.json').read_text());config=b/'r256-current-prefix-data-1999/config.json';cfg=json.loads(config.read_text());assert sha(Path(cfg['prefix']))==cfg['prefix_sha256'];rows=[];waiting=[];binary_shas=set()
for seed in (23800,):
 p=root/'upper-candidates'/str(seed)/'route';f=p/'router-input.txt'
 if not f.exists():waiting.append(seed);continue
 raw=f.read_bytes();h,actualbody=raw.split(b'\n',1);h=list(map(int,h.split()));assert actualbody==body and all(h[i]==header[i]for i in [0,1,2,6,7,9]);assert h[2]==11149 and h[6]==1229
 actual=json.loads((p/'placement.json').read_text());assert actual['placements_um']==placement['placements_um']and actual['terminals']==placement['terminals']
 tag=seed//10;record=b/('route-selection-102/sready'+str(tag)+'-arbiter-fullchain/tasks.json');t=next(t for t in json.loads(record.read_text())['tasks']if t['spec']['script']=='system_upper.py');spec=t['spec'];a=spec['args'];assert h[5]==int(a[a.index('--route-heuristic-weight')+1])and h[15]==int(a[a.index('--route-nonpreferred-cost')+1])
 assert spec['source_root']==str(b/'source-2062')and a[a.index('--route-ordinary-refresh')+1]=='8'and a[a.index('--route-ordinary-present-growth')+1]=='0'and a[a.index('--route-trials')+1]=='12'and spec['forecast_gib']==49
 queued=Path(t['path'])
 if seed==20500:queued=b/'dynamic-09/node3/pending'/queued.name
 cmd=json.loads((queued.parent.parent/'commands'/queued.name).read_text());assert cmd['spec_sha256']==t['sha256']and cmd['admission']['admitted']and cmd['admission']['available_bytes']>cmd['admission']['required_bytes'];assert sha(queued)==t['sha256']and cmd['script_sha256']==sha(b/'source-2062/project/experiments/control_v1/system_upper.py')
 proof=p/'trial-0/output.txt.native-prefix.log';native=[]
 if proof.exists():
  for line in proof.read_text().splitlines():
   v=json.loads(line)
   if 'conflict_nodes'in v:native.append(v)
  assert native and native[-1]['conflict_nodes']==0 and native[-1]['summed_tree_vertices']==109862
 assert native,'Prefix not ready yet; no PASS receipt'
 binary=p/'router';binary_sha=sha(binary);binary_shas.add(binary_sha)
 rows.append(dict(seed=seed,actual_header=h,input_body_byte_exact=True,all345positions_and11149terminal_arrays_exact=True,input_sha256=sha(f),spec_sha256=t['sha256'],actual_command_sha256=sha(queued.parent.parent/'commands'/queued.name),admission=cmd['admission'],native_prefix_actual_verified=bool(native),native_prefix_log_sha256=sha(proof)if proof.exists()else None,binary_sha256=binary_sha))
assert len(binary_shas)==1
out=dict(passed=True,time=time.time(),whole_system_qualified=False,executed=len(rows),pending_or_preflight=waiting,rows=rows,binary_sha256=sorted(binary_shas),original_actual_input_sha256=hashlib.sha256(reference).hexdigest(),warm_config_sha256=sha(config),warm_prefix_sha256=cfg['prefix_sha256'],scope='Actualruntimeindependentaudit: current19540all345positions/11149terminal arrays, all11149netbodybytes/1229budgets exactoriginalcase14, onlyexistingallowedheadersearchfields vary; actualowncommand/spec/originalmemoryadmission andnativeprefix1229 zero allchecked. Fullordinaryroutes/geometryPG3RC300MHz notqualified.')
p=b/'route-selection-102/sready2068-actual-runtime-binding';assert not p.exists();p.mkdir();(p/'receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=55);(b/'control162-runtime2068-receipt.json').write_bytes(raw);d=json.loads(raw);print(json.dumps({k:v for k,v in d.items()if k!='rows'}));print('native import verified',sum(r['native_prefix_actual_verified']for r in d['rows']))
