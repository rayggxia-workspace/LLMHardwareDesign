from pathlib import Path
import ast,hashlib,json,subprocess,sys,types
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';here=r/'project/experiments/control_v1';out=r/'work/YUZE-LU/162/after-native2089';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=['coarse_refine_regression.py','system_upper.py','tree_router.cpp','tree_router_cpp.py']
for n in changed:p=here/n;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
command=json.loads((b/'control162-status2066-latest.json').read_text(encoding='utf-8'))['commands']['command'];argv=command[command.index('--manifest'):];argv[argv.index('--out')+1]=str(b/'control162-absent2089');assert not Path(argv[argv.index('--out')+1]).exists()
tree=ast.parse((here/'system_upper.py').read_text(encoding='utf-8'));main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main')
cut=next(i for i,n in enumerate(main.body)if isinstance(n,ast.Expr)and isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Attribute)and n.value.func.attr=='mkdir'and isinstance(n.value.func.value,ast.Attribute)and n.value.func.value.attr=='out')
main.body=main.body[:cut]+[ast.Return(value=ast.Name(id='a',ctx=ast.Load()))];ast.fix_missing_locations(tree)
sys.path.insert(0,str(here));ns={'__name__':'contract_only','__file__':str(here/'system_upper.py')};exec(compile(tree,str(here/'system_upper.py'),'exec'),ns)
ns['os']=types.SimpleNamespace(environ={'SLURM_JOB_ID':'local-contract-only'},sched_getaffinity=lambda _:set(range(16)))
cases=[]
for policy in ['none','after-native','all','ordinary-first']:
 args=list(argv);args[args.index('--route-pin-access')+1]=policy;sys.argv=[str(here/'system_upper.py'),*args];failed=False
 try:a=ns['main']()
 except AssertionError:failed=True
 assert failed==(policy in ['all','ordinary-first']);cases.append(dict(policy=policy,rejected=failed))
from tree_router_cpp import route
for policy in ['all','ordinary-first']:
 failed=False
 try:route({},40,40,1,80,b/'never-created2089',locked_names=['a'],wire_limits={'a':30},negotiated_priority=True,defer_access_vias=True,congestion_scale=1,bidirectional_two_terminal=True,weighted_bidirectional=True,ordinary_zero_pattern=True,pareto_wire_budget=True,critical_first=True,native_prefix_first=True,native_prefix_flexible=True,pin_access_policy=policy)
 except AssertionError:failed=True
 assert failed and not(b/'never-created2089').exists()
for n in changed:
 if n.endswith('.py'):compile((here/n).read_text(encoding='utf-8'),str(here/n),'exec')
unchanged=['pin_access_reservation.h','native_prefix_seed.h','resource_search.h','weighted_settled_bidirectional.h','ordinary_coarse_grid.h','routing_corridor.h','router_trial_pool.py','system_geometry.py','system_sta.py','system_accept.py','final_composition.py','native_pin_load.py','placement_residual_budget.py']
for n in unchanged:assert subprocess.check_output(['git','show','HEAD:project/experiments/control_v1/'+n],cwd=r)==(here/n).read_bytes()
diagnostic=b/'control162-endpoint2088/endpoint-pressure.json';d=json.loads(diagnostic.read_text(encoding='utf-8'));assert d['passed']and d['summary']['nets_with_closed_terminal']==7399
contract=dict(passed=True,whole_system_qualified=False,cli_full_context_cases=cases,python_invalid_contexts=2,python_syntax_checks=3,preoutput_assertions=sum(isinstance(n,ast.Assert)for n in main.body),unchanged_helpers_and_gates=unchanged,source_sha256={n:sha(here/n)for n in changed+unchanged},endpoint_diagnostic_sha256=sha(diagnostic),scope='Local AST executes actual CLI parser and all pre-output assertions using explicit local16CPU/Slurm environment stub; no EDA. Both none/after-native accepted, all/ordinary-first still rejected in complete context; two worker invalid contexts rejected before output. Source compatibility gate only; actual CPP regression and full physical acceptance still mandatory.')
raw=json.dumps(contract,indent=2).encode();(out/'contract.json').write_bytes(raw);(b/'control162-contract2089.json').write_bytes(raw)
(out/'README.md').write_bytes('''# 在可重布关键前缀之后复用引脚出口匹配

Issue #162 / Draft PR #163。当前22200/trial0完整round7快照经原独立flood/预算/通孔/轮次审计和精确SHA绑定，本地重算原占用全部一致。只移除被检查网络自己的旧树时，22302个普通端点中10568个被其他树/引脚围在半径4以内的小连通分量，涉及7399条普通网络；1979个端点没有任何空闲相邻点。此为固定其他树状态的局部事实，移动其他树仍可能打开出口，不能称全局不可行证明。

只将既有after-native策略与native_prefix_flexible组合显式放行：CPP、Python worker和CLI各一处上下文条件。原匹配器在实际零冲突关键前缀之后执行，避开其真实占用；只添加软件搜索所有权，不制造真实线或赋予物理资格。匹配可不完整，未分配数据实记录。关键前缀仍可协商重布，所有有限线长/电容及几何/PG/三RC300MHz门保持。原none默认路径、匹配器、所有RTL与固定宏均不改。

回归保留18份关闭路径的字节重放和每种cost的真实零冲突/独立最终检查；新增逐项核对匹配计划的实际端点/奇偶通孔/多点所有权/不占关键路径，以及原关键前缀字节不变。当前只完成本地完整CLI前置条件、worker拒绝和语法检查，实际C++回归、全图布线及全部组合验收继续，不能宣布系统通过。

8节点既有任务保留，S内部驱动及R/并行工作不动，不自行合并。规则rayggxia-project-collab1.0.0；登记PR5 pending；看板unverified/同步pending；审查待指定；Issue in_progress / PR Draft。
'''.encode())
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/after-native2089/contract.json -text\n')
for n,prefix in [('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/n;p.write_bytes(f'Issue162：[关键前缀后出口匹配兼容]({prefix}work/YUZE-LU/162/after-native2089/README.md)：真实快照发现7399普通网络有局部封闭端点；仅放行已有after-native匹配器与可重布前缀组合。所有硬件/最终门保留，本地条件检查通过，待实际冻结/回归/全网物理验收，继续、不合并。\n\n'.encode()+p.read_bytes())
files=['.gitattributes',*['project/experiments/control_v1/'+n for n in changed],'docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md',str(out.relative_to(r))]
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r)==b''
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*files],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:n=raw.decode();assert subprocess.check_output(['git','show',':'+n],cwd=r)==(r/n).read_bytes(),n
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Allow existing post-prefix pin access matching with negotiable native trees'],cwd=r,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();(b/'control162-commit2089.json').write_text(json.dumps(dict(commit=head,whole_system_qualified=False)),encoding='utf-8');print(head)
