from pathlib import Path
import hashlib,json,re,subprocess,time,sys
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';q=b/'dynamic-06/node26';out=b/'route-selection-102/sready2093-after-native-diversity'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not out.exists()
audit=b/'r256-after-native-source-audit-2091/receipt.json';assert json.loads(audit.read_text())['passed']
record=b/'route-selection-102/sready2092-ordinary-refresh-regression/tasks.json';z=json.loads(record.read_text());assert len(z['tasks'])==1
r=z['tasks'][0];p=Path(r['path']);assert p.parent==q/'pending'and json.loads(p.read_text())==r['spec']and r['spec']['source_root']==str(b/'source-2089')and r['spec']['forecast_gib']==8
args=r['spec']['args'];config=Path(args[args.index('--coarse-refine-regression-config')+1]);cfg=json.loads(config.read_text());assert cfg['guided_pin_access']=='after-native'and cfg['guided_refresh']==8 and sha(config)==z['config_sha256']
details=subprocess.check_output(['scontrol','show','job','96222','-o'],universal_newlines=True)
assert 'UserId=yuzelu(10011)'in details and 'JobName=yzl-ctl162-'in details and 'NodeList=node24 'in details
steps=subprocess.check_output(['scontrol','show','step','96222','-o'],universal_newlines=True)
found=[m.groups()for m in re.finditer(r'StepId=(96222\.[0-9]+).*?SrunHost:Pid=(node[0-9]+):([0-9]+)',steps)]
code="import os,json;d={}"+chr(10)+"for p in "+repr([r[2]for r in found])+":"+chr(10)+" try:"+chr(10)+"  assert os.stat('/proc/'+p).st_uid==10011;d[p]=open('/proc/'+p+'/cmdline','rb').read().decode().split(chr(0))"+chr(10)+" except OSError:pass"+chr(10)+"print(json.dumps(d))"
procs=json.loads(subprocess.check_output(['srun','--jobid=96222','--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));targets=[]
for seed in (20300,):
 tag=seed//10;rows=json.loads((b/('route-selection-102/sready'+str(tag)+'-arbiter-fullchain/tasks.json')).read_text())['tasks'];r=next(t for t in rows if t['spec']['script']=='system_upper.py');p=Path(r['path']);spec=r['spec'];a=spec['args'];route=root/'upper-candidates'/str(seed)/'route';state=json.loads((q/'queue-state.json').read_text())
 assert p.parent==q/'pending'and sha(p)==r['sha256']and p.stem in state['active']and p.stem not in state['finished']and state['job']=='96222'
 assert spec['source_root']==str(b/'source-1885')and a[a.index('--out')+1]==str(route)and a[a.index('--graph')+1]==str(root/'topology/boundary-graph.json')and a[a.index('--route-heuristic-weight')+1]=='256'
 assert a[a.index('--route-nonpreferred-cost')+1]=='8'and a[a.index('--route-ordinary-coarse')+1]=='16'and a[a.index('--route-ordinary-present-growth')+1]=='4'
 for n in ['receipt.json','trees.json','search.json','router-output.txt']:assert not(route/n).exists(),('Possible final result appeared; preserve',seed,n)
 cmd=json.loads((q/'commands'/p.name).read_text());assert cmd['spec_sha256']==sha(p)
 matched=[]
 for step,host,pid in found:
  c=procs.get(pid,[])
  if '--out'in c and c[c.index('--out')+1]==str(route)and str(b/'source-1885/project/experiments/control_v1/system_upper.py')in c:matched.append(dict(step=step,host=host,pid=pid,command=c))
 assert len(matched)==1 and matched[0]['host']=='node24'
 logs=[]
 for i in range(16):
  log=route/('trial-'+str(i))/'router.log';raw=log.read_bytes();records=[]
  for line in raw.decode(errors='replace').splitlines():
   try:v=json.loads(line)
   except ValueError:continue
   if 'conflict_nodes'in v:records.append(v)
  assert records and records[-1]['round']>=8 and records[-1]['conflict_nodes']>500000
  assert not(route/('trial-'+str(i))/'output.txt').exists()
  logs.append(dict(path=str(log),observed_bytes=len(raw),observed_prefix_sha256=hashlib.sha256(raw).hexdigest(),last_round=records[-1],scope='Hash of observed live prefix, not a promise the live file stops growing'))
 targets.append(dict(seed=seed,spec_path=str(p),spec_sha256=sha(p),spec=spec,process=matched[0],log_observations=logs,command_receipt=cmd))
reason='Only own redundant weight256/cost8/stride16 seed20300 retired as search-priority replacement, not an impossibility claim. Two identical seedcontrols20400/20500 remain, all original27matrix conditions/parents/searches/R untouched. All16actual logs past8rounds/>500000conflicts/no finaloutputs plusUID/job/node/PID/source/spec matched. Newsource2089 full1030/archive/reverse audit PASS, actual endpoint snapshot diagnosis7399ordinarynets locally blocked. Concrete queued8GiB actual after-native matcher compatibility regression20920 precedes a new complete7stage candidate; existing matcher/native finite/RTL/allfinalgates unchanged. Every oldspec/log/partial andneverstarted successor preservedinplace. No whole-system qualification.'
out.mkdir();(out/'verified-before.json').write_text(json.dumps(dict(time=time.time(),targets=targets,job_details=details,whole_system_qualified=False,reason=reason),indent=2))
print(json.dumps(dict(verified=True,targets=[dict(seed=t['seed'],step=t['process']['step'],minimum_completed_round=min(v['last_round']['round']for v in t['log_observations']))for t in targets],apply_requested='--apply'in sys.argv)))
if '--apply'not in sys.argv:
 (out/'read-only.json').write_text(json.dumps(dict(passed=True,cancelled=False,scope=reason),indent=2))
 sys.exit(0)
retired=[]
for t in targets:
 p=Path(t['spec_path']);route=root/'upper-candidates'/str(t['seed'])/'route';state=json.loads((q/'queue-state.json').read_text());assert p.stem in state['active']and sha(p)==t['spec_sha256']
 for n in ['receipt.json','trees.json','search.json','router-output.txt']:assert not(route/n).exists()
 subprocess.run(['scancel',t['process']['step']],check=True);retired.append(dict(seed=t['seed'],step=t['process']['step']));(out/'retire-progress.json').write_text(json.dumps(retired,indent=2))
(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),retired=retired,whole_system_qualified=False,scope=reason),indent=2));print(json.dumps(dict(passed=True,retired=retired)))
