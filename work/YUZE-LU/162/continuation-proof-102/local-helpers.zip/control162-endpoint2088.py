"""Local exact-state diagnostic, never a route or physical qualification."""
from pathlib import Path
import array,collections,hashlib,json,time
b=Path(__file__).parent/'control162-endpoint2088';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cfg=json.loads((b/'config.json').read_text(encoding='utf-8'));outer=json.loads((b/'receipt.json').read_text(encoding='utf-8'));prior=json.loads((b/'analysis-receipt.json').read_text(encoding='utf-8'))
assert outer['passed']and any(v==sha(b/'analysis-receipt.json')for k,v in outer['inputs'].items()if k.endswith('/global-snapshot/receipt.json'))
assert prior['passed']and not prior['whole_system_qualified']and cfg['round']==8
snapshot=b/'output.txt.global-round-8.txt';inp=b/'input.txt'
assert sha(snapshot)==cfg['snapshot_sha256']and sha(inp)==cfg['input_sha256']
assert prior['inputs'][cfg['snapshot']]==sha(snapshot)and prior['inputs'][cfg['input']]==sha(inp)
lines=inp.read_text(encoding='utf-8').splitlines();h=list(map(int,lines[0].split()));nx,ny,count=h[:3];plane=nx*ny;assert h[:3]==[3070,3252,11149]and h[6]==1229
nets=[];landings={}
for n,line in enumerate(lines[1:]):
 r=line.split();k=int(r[1]);assert len(r)==3+2*k
 ps=[int(r[2+2*i])+nx*int(r[3+2*i])for i in range(k)]
 for v in ps:assert v not in landings;landings[v]=n
 nets.append((r[0],ps))
usage=array.array('H',[0])*(2*plane);owner=array.array('i',[-1])*(2*plane);trees=[]
with snapshot.open(encoding='utf-8')as f:
 assert int(f.readline())==count
 for n,(name,ps)in enumerate(nets):
  fields=f.readline().split();assert fields[0]==name;vs=set()
  for _ in range(int(fields[1])):
   r=list(map(int,f.readline().split()));assert len(r)==1+3*r[0]
   for j in range(1,len(r),3):vs.add(r[j]+nx*r[j+1]+plane*r[j+2])
  for v in vs:usage[v]+=1;owner[v]=n
  trees.append(array.array('I',vs))
 assert not f.read().strip()
actual=dict(conflict_nodes=sum(u>1 for u in usage),excess_occupancy=sum(max(0,u-1)for u in usage),occupied_cells=sum(bool(u)for u in usage),summed_tree_vertices=sum(usage))
for k,v in actual.items():assert v==prior['diagnostic'][k]
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
hist=collections.Counter();rows=[];blocked_by=collections.Counter()
for n,(name,ps)in enumerate(nets):
 if n<h[6]:continue
 own=set(trees[n]);endpoints=[]
 def allowed(v):return landings.get(v,n)==n and usage[v]-(v in own)==0
 for start in ps:
  assert allowed(start),'Foreign tree illegally touches reserved landing'
  x=start%nx;y=(start%plane)//nx;seen={start};todo=[start];escape=False
  for v in todo:
   if max(abs(v%nx-x),abs((v%plane)//nx-y))>=4:escape=True;break
   for w in neighbors(v):
    if w not in seen and allowed(w):seen.add(w);todo.append(w)
  degree=sum(allowed(v)for v in neighbors(start));hist['terminals']+=1;hist['degree_'+str(degree)]+=1
  if not escape:
   hist['closed_terminals']+=1;hist['closed_component_size_'+str(len(seen))]+=1
   for v in seen:
    for w in neighbors(v):
     if not allowed(w):
      category='foreign-reserved-landing'if landings.get(w,n)!=n else 'foreign-routed-wire'
      blocked_by[category]+=1
   endpoints.append(dict(x=x,y=y,available_immediate_neighbors=degree,closed_component_vertices=len(seen)))
 if endpoints:
  hist['nets_with_closed_terminal']+=1
  rows.append(dict(net=name,index=n,terminal_count=len(ps),closed_terminals=endpoints,existing_vertices=len(own)))
result=dict(passed=True,time=time.time(),whole_system_qualified=False,snapshot_round=7,grid=[nx,ny],original_counts=actual,summary=dict(hist),boundary_blocker_edges=dict(blocked_by),closed_nets=rows,inputs={str(p):sha(p)for p in[inp,snapshot,b/'config.json',b/'receipt.json',b/'analysis-receipt.json',Path(__file__)]},scope='Exact current22200/trial0 full-round7 intermediate state. Original independently qualified snapshot flood/unit/via/budget/exact-round audit reused only by exact SHA binding; all original occupancy counts recomputed. For each ordinary net remove ONLY its own whole tree occupancy, retain every foreign tree and real M11 landing, BFS strict-zero graph with original unit edges/checkerboard vias until XY Chebyshev radius4. No boundary reached means an actually closed local component in THIS foreign-tree state, not impossible global routing: moving foreign nets can open it. Native trees/RTL/hardware/search/gates/remote jobs unchanged. This is local diagnosis, no physical qualification or new route.')
p=b/'endpoint-pressure.json';assert not p.exists();p.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=True,summary=result['summary'],blockers=result['boundary_blocker_edges'],whole_system_qualified=False)))
