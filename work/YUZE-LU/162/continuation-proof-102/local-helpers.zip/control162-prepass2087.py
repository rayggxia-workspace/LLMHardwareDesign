from pathlib import Path
import subprocess,json,shlex
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,time
root=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888/upper-candidates');rows=[]
for seed in [20800,21800,22000,22100,22200,23400,23500,23800,24000]:
 f=root/str(seed)/'route'/('router.log'if seed==24000 else'trial-0/router.log');raw=f.read_bytes();records=[]
 for line in raw.splitlines(keepends=True):
  if not line.endswith(b'\n'):continue
  try:r=json.loads(line)
  except ValueError:continue
  if any(k in r for k in ['conflict_nodes','zero_maze_attempts','coarse_refinement_attempts','zero_pattern_attempts','coarse_attempts']):records.append(r)
 completed=[r['round']for r in records if'conflict_nodes'in r]
 latest=max(completed)if completed else -1
 rows.append(dict(seed=seed,bytes=len(raw),round=latest,latest=[r for r in records if r['round']==latest],phase='live completed round only; no full qualification'))
print(json.dumps(dict(time=time.time(),whole_system_qualified=False,rows=rows)))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=15','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35)
(b/'control162-prepass2087.json').write_bytes(raw)
for r in json.loads(raw)['rows']:print(json.dumps(r))
