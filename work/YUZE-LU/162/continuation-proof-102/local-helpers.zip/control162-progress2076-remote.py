"""Read-only bounded live-log observations, on one existing exclusive Slurm step."""
from pathlib import Path
import concurrent.futures,hashlib,json,os,statistics,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'r256-all-trial-progress-2076';root=b/'r256-balanced-reset-composition-1888/upper-candidates';assert not out.exists();assert os.environ.get('SLURM_JOB_ID')=='95204'and len(os.sched_getaffinity(0))==16
state=json.loads((b/'dynamic-04/node25/queue-state.json').read_text());assert len(state['active'])==5 and state['job']=='95204'
forecasts=[]
for name in state['active']:forecasts.append(json.loads((b/'dynamic-04/node25/pending'/(name+'.json')).read_text())['forecast_gib'])
memory={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};required=(1.2*(sum(forecasts)+8)+16)*1024**3;assert memory['MemAvailable']>required
paths=[]
for seed in range(20300,23900,100):
 for p in(root/str(seed)/'route').glob('trial-*/router.log'):paths.append((seed,p))
def observe(pair):
 seed,p=pair;raw=p.read_bytes();rows=[]
 for line in raw.splitlines(keepends=True):
  if not line.endswith(b'\n')or b'"conflict_nodes"'not in line:continue
  try:v=json.loads(line.decode())
  except ValueError:continue
  rows.append(v)
 by={v['round']:v for v in rows};return dict(seed=seed,attempt=int(p.parent.name.split('-')[1]),path=str(p),observed_bytes=len(raw),observed_prefix_sha256=hashlib.sha256(raw).hexdigest(),rounds=[by[n]for n in sorted(by)],scope='Exact observed live byte prefix; file may continue growing. No final path or success inferred.')
with concurrent.futures.ThreadPoolExecutor(max_workers=16)as pool:rows=list(pool.map(observe,paths))
cases=[]
for seed in range(20300,23900,100):
 rr=[r for r in rows if r['seed']==seed];matched={}
 for round_number in [3,7,15,23,31]:
  values=[v['conflict_nodes']for r in rr for v in r['rounds']if v['round']==round_number]
  if values:matched[str(round_number)]=dict(attempts=len(values),min=min(values),median=statistics.median(values),max=max(values))
 latest=[dict(attempt=r['attempt'],**r['rounds'][-1])for r in rr if r['rounds']]
 best=min(latest,key=lambda r:r['conflict_nodes'])if latest else None
 cases.append(dict(seed=seed,observed_attempts=len(rr),matched_rounds=matched,best_latest=best))
result=dict(passed=True,time=time.time(),whole_system_qualified=False,actual_observed_log_count=len(rows),admission=dict(active_forecasts_gib=forecasts,analysis_forecast_gib=8,available_bytes=memory['MemAvailable'],required_bytes=required),cases=cases,observations=rows,scope='Bounded all-attempt read-only progress evidence, not physical qualification. Matched-round distributions only compare those attempts that actually completed that round; completion times vary, no early winner or impossibility claim. Existing own95204 exclusive16CPU vacancy; original aggregate20percent+16GiB guard checked before analysis. No EDA, source, macro, parent, queue-spec or other/R job mutation.')
out.mkdir();(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,observed_logs=len(rows),best=sorted([dict(seed=c['seed'],**c['best_latest'])for c in cases if c['best_latest']],key=lambda v:v['conflict_nodes'])[:8],whole_system_qualified=False)))
