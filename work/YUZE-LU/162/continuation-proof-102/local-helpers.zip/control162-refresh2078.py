from pathlib import Path
import subprocess,shlex,json,time
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';p=root/'upper-candidates/23800/route'
d=dict(time=time.time(),whole_system_qualified=False,attempts=[])
for f in sorted(p.glob('trial-*/router.log')):
 raw=f.read_bytes();completed=[];refresh=[]
 for line in raw.splitlines(keepends=True):
  if not line.endswith(b'\n'):continue
  if b'"conflict_nodes"'not in line and b'"ordinary_refresh_period"'not in line:continue
  try:v=json.loads(line)
  except ValueError:continue
  if 'conflict_nodes'in v:completed.append(v)
  if 'ordinary_refresh_period'in v:refresh.append(v)
 d['attempts'].append(dict(attempt=int(f.parent.name.split('-')[1]),last=completed[-1]if completed else None,refresh=refresh,last_line=raw.splitlines()[-1].decode(errors='replace'),bytes=len(raw)))
d['stages']={}
for sub in ['route','geometry','pg-audit','timing/low','timing/base','timing/high','delivery']:
 f=root/'upper-candidates/23800'/sub/'receipt.json'
 if f.exists():d['stages'][sub]=json.loads(f.read_text())
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=15','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35)
with(b/'control162-refresh2078.jsonl').open('ab')as f:f.write(raw.rstrip()+b'\n')
d=json.loads(raw)
print(json.dumps(dict(time=d['time'],stages=d['stages'],attempts=[dict(attempt=x['attempt'],round=x['last']['round']if x['last']else None,conflicts=x['last']['conflict_nodes']if x['last']else None,refresh_count=len(x['refresh']),last_refresh=x['refresh'][-1]if x['refresh']else None)for x in d['attempts']],whole_system_qualified=False)))
