from pathlib import Path
import json
b=Path(__file__).parent
d=json.loads((b/'control162-progress2076-receipt.json').read_text(encoding='utf-8'))
print(json.dumps(dict(passed=d['passed'],logs=d['actual_observed_log_count'],cases=[dict(seed=c['seed'],attempts=c['observed_attempts'],matched=c['matched_rounds'],best=c['best_latest'])for c in d['cases']if c['observed_attempts']]),ensure_ascii=False))
for seed in [20800,21800,22000,22100,23400,23500,23800]:
 r=next(r for r in d['observations']if r['seed']==seed and r['attempt']==0)
 print(json.dumps(dict(seed=seed,trial0_rounds=r['rounds'])))
