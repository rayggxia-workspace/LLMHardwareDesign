"""Local exact-state diagnostic, never a route or physical qualification."""
from pathlib import Path
import array,collections,hashlib,json,time
b=Path(__file__).parent/'control162-endpoint2088';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cfg=json.loads((b/'config.json').read_text(encoding='utf-8'));outer=json.loads((b/'receipt.json').read_text(encoding='utf-8'));prior=json.loads((b/'analysis-receipt.json').read_text(encoding='utf-8'))
assert outer['passed']and any(v==sha(b/'analysis-receipt.json')for k,v in outer['inputs'].items()if k.endswith('/global-snapshot/receipt.json'))
assert prior['passed']and not prior['whole_system_qualified']and cfg['round']==8
snapshot=b/'output.txt.global-round-8.txt';inp=b/'input.txt'
assert sha(snapshot)==cfg['snapshot_sha256']and sha(inp)==cfg['input_sha256']
assert prior['inputs'][cfg['snapshot']]==sha(snapshot)and prior['inputs'][cfg['input']]==sha(inp)
lines=inp.read_text(encoding='utf-8').splitlines();h=list(map(int,lines[0].split()));nx,ny,count=h[:3];plane=nx*ny;assert h[:3]==[3070,3252,11149]and h[6]==1229
nets=[];landings={}
for n,line in enumerate(lines[1:]):
 r=line.split();k=int(r[1]);assert len(r)==3+2*k
 ps=[int(r[2+2*i])+nx*int(r[3+2*i])for i in range(k)]
 for v in ps:assert v not in landings;landings[v]=n
 nets.append((r[0],ps))
usage=array.array('H',[0])*(2*plane);owner=array.array('i',[-1])*(2*plane);trees=[]
with snapshot.open(encoding='utf-8')as f:
 assert int(f.readline())==count
 for n,(name,ps)in enumerate(nets):
  fields=f.readline().split();assert fields[0]==name;vs=set()
  for _ in range(int(fields[1])):
   r=list(map(int,f.readline().split()));assert len(r)==1+3*r[0]
   for j in range(1,len(r),3):vs.add(r[j]+nx*r[j+1]+plane*r[j+2])
  for v in vs:usage[v]+=1;owner[v]=n
  trees.append(array.array('I',vs))
 assert not f.read().strip()
actual=dict(conflict_nodes=sum(u>1 for u in usage),excess_occupancy=sum(max(0,u-1)for u in usage),occupied_cells=sum(bool(u)for u in usage),summed_tree_vertices=sum(usage))
for k,v in actual.items():assert v==prior['diagnostic'][k]
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
# Classify each original tree using the original occupancy, before any removal.
dirty=[any(usage[v]>1 for v in vs) for vs in trees]
native_use=array.array('H',[0])*(2*plane);clean_use=array.array('H',[0])*(2*plane)
for n,vs in enumerate(trees):
 target=native_use if n<h[6] else clean_use if not dirty[n] else None
 if target is not None:
  for v in vs:target[v]+=1
# Minimum foreign-occupied cells to cross to radius4, retaining real landings.
# Ties choose fewer foreign occupancy counts, then fewer steps.
import heapq
H=collections.Counter();Q=collections.Counter();block_hot=collections.Counter();closed=0
for n,(name,ps) in enumerate(nets):
 if n<h[6]:continue
 own=set(trees[n])
 for start in ps:
  x=start%nx;y=(start%plane)//nx
  stack=[(0,0,0,start)];dist={start:(0,0,0)};prev={}
  while stack:
   cells,excess,steps,v=heapq.heappop(stack)
   if dist[v]!=(cells,excess,steps):continue
   if max(abs(v%nx-x),abs((v%plane)//nx-y))>=4:break
   for w in neighbors(v):
    if landings.get(w,n)!=n:continue
    u=usage[w]-(w in own)
    k=(cells+int(bool(u)),excess+u,steps+1)
    if k<dist.get(w,(1000,1000,1000)):
     dist[w]=k;prev[w]=v;heapq.heappush(stack,(*k,w))
  else:raise AssertionError((n,start,'No fixed-landing-only escape'))
  H[cells]+=1
  if cells:
   closed+=1;Q[(cells,excess)]+=1
   while v!=start:
    if usage[v]>(v in own):block_hot[v]+=1
    v=prev[v]
assert closed==10568 and sum(H.values())==22302
# Bounds count occupied cells, not moving distinct nets. All paths are diagnostic.
result=dict(passed=True,whole_system_qualified=False,route_qualified=False,closed=closed,minimum_foreign_occupied_cell_distribution=dict(H),minimum_foreign_occupant_visit_distribution={str(k):v for k,v in Q.items()},unique_best_witness_blocking_cells=len(block_hot),top_blocking_cells=[dict(x=v%nx,y=(v%plane)//nx,metal=11+v//plane,chosen_witnesses=c)for v,c in block_hot.most_common(40)],inputs={str(x):sha(x)for x in [inp,snapshot,b/'analysis-receipt.json',Path(__file__)]},scope='Bounded exact shortest escape around each actual M11 terminal of snapshot22200/trial0 completed round7, removes own old tree, retains all true foreign landings; cost first counts foreign occupied cells, then occupants and steps. This only ranks actual nearby blockers; results are neither independent routes nor counts of distinct nets that must move.')
out=Path(__file__).with_suffix('.json');assert not out.exists();out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k not in ['scope','inputs','top_blocking_cells']}))
