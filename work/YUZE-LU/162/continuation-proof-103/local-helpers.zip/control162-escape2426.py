"""Local exact-state diagnostic, never a route or physical qualification."""
from pathlib import Path
import array,collections,hashlib,json,time
b=Path(__file__).parent/'control162-endpoint2088';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cfg=json.loads((b/'config.json').read_text(encoding='utf-8'));outer=json.loads((b/'receipt.json').read_text(encoding='utf-8'));prior=json.loads((b/'analysis-receipt.json').read_text(encoding='utf-8'))
assert outer['passed']and any(v==sha(b/'analysis-receipt.json')for k,v in outer['inputs'].items()if k.endswith('/global-snapshot/receipt.json'))
assert prior['passed']and not prior['whole_system_qualified']and cfg['round']==8
snapshot=b/'output.txt.global-round-8.txt';inp=b/'input.txt'
assert sha(snapshot)==cfg['snapshot_sha256']and sha(inp)==cfg['input_sha256']
assert prior['inputs'][cfg['snapshot']]==sha(snapshot)and prior['inputs'][cfg['input']]==sha(inp)
lines=inp.read_text(encoding='utf-8').splitlines();h=list(map(int,lines[0].split()));nx,ny,count=h[:3];plane=nx*ny;assert h[:3]==[3070,3252,11149]and h[6]==1229
nets=[];landings={}
for n,line in enumerate(lines[1:]):
 r=line.split();k=int(r[1]);assert len(r)==3+2*k
 ps=[int(r[2+2*i])+nx*int(r[3+2*i])for i in range(k)]
 for v in ps:assert v not in landings;landings[v]=n
 nets.append((r[0],ps))
usage=array.array('H',[0])*(2*plane);owner=array.array('i',[-1])*(2*plane);trees=[]
with snapshot.open(encoding='utf-8')as f:
 assert int(f.readline())==count
 for n,(name,ps)in enumerate(nets):
  fields=f.readline().split();assert fields[0]==name;vs=set()
  for _ in range(int(fields[1])):
   r=list(map(int,f.readline().split()));assert len(r)==1+3*r[0]
   for j in range(1,len(r),3):vs.add(r[j]+nx*r[j+1]+plane*r[j+2])
  for v in vs:usage[v]+=1;owner[v]=n
  trees.append(array.array('I',vs))
 assert not f.read().strip()
actual=dict(conflict_nodes=sum(u>1 for u in usage),excess_occupancy=sum(max(0,u-1)for u in usage),occupied_cells=sum(bool(u)for u in usage),summed_tree_vertices=sum(usage))
for k,v in actual.items():assert v==prior['diagnostic'][k]
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
# Classify each original tree using the original occupancy, before any removal.
dirty=[any(usage[v]>1 for v in vs) for vs in trees]
native_use=array.array('H',[0])*(2*plane);clean_use=array.array('H',[0])*(2*plane)
for n,vs in enumerate(trees):
 target=native_use if n<h[6] else clean_use if not dirty[n] else None
 if target is not None:
  for v in vs:target[v]+=1
metrics=collections.Counter();cross=collections.Counter();joint=collections.Counter()
for n,(name,ps) in enumerate(nets):
 if n<h[6]:continue
 own=set(trees[n]);is_clean=not dirty[n]
 for start in ps:
  x=start%nx;y=(start%plane)//nx
  def escaped(remove_dirty,remove_clean,remove_native=False):
   seen={start};queue=[start]
   for v in queue:
    if max(abs(v%nx-x),abs((v%plane)//nx-y))>=4:return True
    for w in neighbors(v):
     if w in seen or landings.get(w,n)!=n:continue
     nv=native_use[w];cv=clean_use[w];dv=usage[w]-nv-cv
     assert dv>=0
     if w in own:
      if is_clean:cv-=1
      else:dv-=1
     assert cv>=0 and dv>=0
     if (0 if remove_native else nv)+(0 if remove_clean else cv)+(0 if remove_dirty else dv):continue
     seen.add(w);queue.append(w)
   return False
  metrics['all']+=1
  if escaped(False,False):continue
  metrics['closed']+=1
  rd=escaped(True,False);rc=escaped(False,True);ra=escaped(True,True);rn=escaped(True,True,True)
  assert (not rd or ra)and(not rc or ra)and(not ra or rn)
  cross[str((rd,rc,ra,rn))]+=1
  if rd:metrics['opens_removing_dirty_ordinary']+=1
  if rc:metrics['opens_removing_clean_ordinary']+=1
  if ra:metrics['opens_removing_all_ordinary']+=1
  if rn:metrics['opens_only_landing_constraint']+=1
  joint['source_tree_clean' if is_clean else 'source_tree_dirty']+=1
assert metrics['all']==22302 and metrics['closed']==10568
result=dict(passed=True,whole_system_qualified=False,route_qualified=False,source_snapshot_round=7,original_counts=actual,tree_counts=dict(native=h[6],dirty_ordinary=sum(dirty[h[6]:]),clean_ordinary=sum(not d for d in dirty[h[6]:])),metrics=dict(metrics),closed_counterfactuals=dict(cross),source_tree_status=dict(joint),inputs={str(x):sha(x) for x in [inp,snapshot,b/'config.json',b/'receipt.json',b/'analysis-receipt.json',b/'endpoint-pressure.json',Path(__file__)]},scope='Exact22200/trial0 completed round7; original all-plane usage rebuilt and matched. Radius4 local zero-use escape with target own tree always removed, then test independently removing foreign dirty ordinary, clean ordinary, both, and all including native. All true fixed landings remain. These are attribution counterfactuals, not viable reroutes or proof of global feasibility. No changes to remote hardware/jobs/source.')
out=Path(__file__).with_suffix('.json');assert not out.exists();out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k not in ['scope','inputs']}))
