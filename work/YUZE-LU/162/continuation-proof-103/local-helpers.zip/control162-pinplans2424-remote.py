"""Independent read-only actual full-scene software ownership audit."""
from pathlib import Path
import hashlib,json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';route=root/'upper-candidates/24200/route';out=b/'route-selection-102/sready2424-actual-pin-exits';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cfg=json.loads((b/'r256-current-prefix-data-1999/config.json').read_text());prefix=Path(cfg['prefix']);assert sha(prefix)==cfg['prefix_sha256']
reference=(root/'upper-candidates/19700/route/trial-14/input.txt').read_bytes();rh,body=reference.split(b'\n',1);h=list(map(int,rh.split()));nx,ny,count=h[:3];plane=nx*ny;assert[nx,ny,count,h[6]]==[3070,3252,11149,1229]
nets=[];landings={}
for n,line in enumerate(body.decode().splitlines()):
 r=line.split();k=int(r[1]);assert len(r)==3+2*k;ps={int(r[2+2*i])+nx*int(r[3+2*i])for i in range(k)}
 assert len(ps)==k
 for v in ps:assert v not in landings;landings[v]=n
 nets.append((r[0],ps))
native=set()
with prefix.open()as f:
 assert int(f.readline())==1229
 for index in range(1229):
  fields=f.readline().split();assert fields[0]==nets[index][0]
  for _ in range(int(fields[1])):
   r=list(map(int,f.readline().split()));assert len(r)==1+3*r[0]
   native.update(r[j]+nx*r[j+1]+plane*r[j+2]for j in range(1,len(r),3))
 assert not f.read().strip()
assert len(native)==109862
ordinary={(n,v)for n,(_,ps)in enumerate(nets)if n>=1229 for v in ps};assert len(ordinary)==22302
rows=[]
for i in range(12):
 folder=route/('trial-'+str(i));inp=folder/'input.txt';raw=inp.read_bytes();hh,bb=raw.split(b'\n',1);header=list(map(int,hh.split()));assert bb==body and header[3]==24200*1009+i
 native_file=folder/'output.txt.native-prefix-paths.txt';assert native_file.read_bytes()==prefix.read_bytes()
 log=folder/'router.log';events=[]
 for line in log.read_bytes().splitlines(keepends=True):
  if not line.endswith(b'\n')or b'"pin_access_policy"'not in line:continue
  events.append(json.loads(line))
 assert len(events)==1 and events[0]['pin_access_policy']=='after-native-m12','Actual matcher not complete yet; no PASS receipt'
 path=folder/'output.txt.pin-access.json';plan=json.loads(path.read_text());claims={};seen=set();even=odd=0
 for n,pin,site in plan['plan']:
  assert(n,pin)in ordinary and(n,pin)not in seen;seen.add((n,pin))
  assert 4<=site%nx<nx-4 and 4<=site//nx<ny-4 and(site%nx+site//nx)%2==0
  if(pin%nx+pin//nx)%2==0:assert site==pin;even+=1
  else:assert abs(pin%nx-site%nx)+abs(pin//nx-site//nx)==1;odd+=1
  for v in {pin,site,site+plane}:
   assert v not in native and(v>=plane or landings.get(v,n)==n)
   assert claims.get(v,n)==n;claims[v]=n
 assert plan['terminals']==len(ordinary)and plan['assigned']==len(seen)<=plan['terminals']
 assert plan['assigned']+plan['unassigned']==plan['terminals']and plan['direct']==even and plan['odd']==odd
 assert events[0]['assigned']==plan['assigned']and events[0]['terminals']==plan['terminals']
 extras=[json.loads(x)for x in log.read_bytes().splitlines(keepends=True)if x.endswith(b'\n')and b'"m11_proxy_reservations_released"'in x]
 assert len(extras)==1
 expected=dict(m11_proxy_reservations_released=sum(v<plane and v not in landings for v in claims),physical_m11_landings_preserved=len(ordinary),m12_proxy_reservations_retained=sum(v>=plane for v in claims),native_prefix_unchanged=True)
 assert all(extras[0][k]==v for k,v in expected.items()),(extras,expected)
 rows.append(dict(attempt=i,assigned=plan['assigned'],unassigned=plan['unassigned'],terminals=plan['terminals'],direct=even,odd=odd,claims_checked=len(claims),active_policy=expected,actual_input_sha256=sha(inp),actual_plan_sha256=sha(path),actual_prefix_sha256=sha(native_file),native_prefix_byteexact=True,scope='Software ownership assignments only, never fabricated wires or a completed route.'))
matcher=b/'source-2110/project/experiments/control_v1/pin_access_reservation.h';assert matcher.read_bytes()==(b/'source-2062/project/experiments/control_v1/pin_access_reservation.h').read_bytes()
result=dict(passed=True,time=time.time(),whole_system_qualified=False,route_qualified=False,attempts=12,ordinary_terminals=22302,native_prefix_vertices=109862,rows=rows,inputs={str(prefix):sha(prefix),str(matcher):sha(matcher),str(Path(__file__)):sha(Path(__file__))},scope='Every actual full24200 matcher plan independently checked against all11149real input nets/all24760landings and actual repaired native prefix, all12actual prefix files byteexact. Assignment site geometry/parity/real endpoint/net ownership/no foreign landing/no native-prefix occupancy/no cross-net claim overlap checked; partial assignments counted without claiming completeness. Matcher header unchanged. Native trees may move later; actual final paths/geometry/nativeXOR/PG/lowbasehigh300MHz/joint acceptance still mandatory. Read-only source and actual files; no EDA or other/R task mutation.')
out.mkdir();(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,actual_plans=12,min_assigned=min(r['assigned']for r in rows),max_assigned=max(r['assigned']for r in rows),max_unassigned=max(r['unassigned']for r in rows),whole_system_qualified=False)))
