from pathlib import Path
import subprocess,json,re,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');route=b/'r256-balanced-reset-composition-1888/upper-candidates/24200/route';out=b/'route-selection-102/sready2423-actual-twelve-processes';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
detail=subprocess.check_output(['scontrol','show','job','96222','-o'],universal_newlines=True);assert 'UserId=yuzelu(10011)'in detail and 'NodeList=node24 'in detail and 'JobName=yzl-ctl162-'in detail
steps=subprocess.check_output(['scontrol','show','step','96222','-o'],universal_newlines=True);found=[m.groups()for m in re.finditer(r'StepId=(96222\.[0-9]+).*?SrunHost:Pid=(node[0-9]+):([0-9]+)',steps)]
code=r'''from pathlib import Path
import os,json
found=FOUND;target=TARGET;source=SOURCE
matches=[]
for step,host,pid in found:
 try:
  p=Path('/proc')/pid;assert p.stat().st_uid==10011;cmd=(p/'cmdline').read_bytes().decode().split(chr(0))
 except OSError:continue
 if source in cmd and '--out'in cmd and cmd[cmd.index('--out')+1]==target:matches.append(dict(step=step,host=host,pid=int(pid),command=cmd))
assert len(matches)==1 and matches[0]['host']=='node24';launcher=matches[0];workers=[]
# SrunHost:Pid identifies the allocation-side srun launcher, whose affinity
# can be96. The real16CPU Python task is a slurmstepd child, not its child.
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=10011 or not(p/'comm').read_text().strip().startswith('python'):continue
  cmd=(p/'cmdline').read_bytes().decode().split(chr(0))
 except OSError:continue
 if len(cmd)>1 and cmd[1]==source and '--out'in cmd and cmd[cmd.index('--out')+1]==target:workers.append(dict(pid=int(p.name),command=cmd,cgroup=(p/'cgroup').read_text()))
assert len(workers)==1,('Actual Python workers',len(workers));main=workers[0];parent_cpus=sorted(os.sched_getaffinity(main['pid']));assert len(parent_cpus)==16 and main['command'][main['command'].index('--route-trials')+1]=='12';rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=10011:continue
  stat=(p/'stat').read_text();ppid=int(stat[stat.rfind(')')+1:].split()[1])
  if ppid!=main['pid']:continue
  cmd=(p/'cmdline').read_bytes().decode().split(chr(0));cpus=sorted(os.sched_getaffinity(int(p.name)))
 except OSError:continue
 if cmd[0]!=target+'/router':continue
 assert len(cmd)>3 and cmd[1].startswith(target+'/trial-')and cmd[2].startswith(target+'/trial-')and '--pin-access=after-native-m12'in cmd and not any(s.startswith('--ordinary-refresh=')for s in cmd) and not any(s.startswith('--ordinary-present-growth=')for s in cmd)and '--resource-labels=8000000'in cmd and cpus==parent_cpus
 rows.append(dict(pid=int(p.name),command=cmd,cpus=cpus))
assert len(rows)==12,('Actual live process width',len(rows));print(json.dumps(dict(launcher=launcher,main=main,parent_cpus=parent_cpus,children=rows)))
'''.replace('FOUND',repr(found)).replace('TARGET',repr(str(route))).replace('SOURCE',repr(str(b/'source-2110/project/experiments/control_v1/system_upper.py')))
data=json.loads(subprocess.check_output(['srun','--jobid=96222','--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));reference=(b/'r256-balanced-reset-composition-1888/upper-candidates/19700/route/trial-14/input.txt').read_bytes().split(b'\n',1)[1];rows=[]
for row in data['children']:
 inp=Path(row['command'][1]);raw=inp.read_bytes();h,body=raw.split(b'\n',1);h=list(map(int,h.split()));assert body==reference and h[:3]==[3070,3252,11149]and h[4:7]==[80,1,1229]and h[15]==32
 i=int(inp.parent.name.split('-')[1]);assert h[3]==24200*1009+i
 native=inp.parent/'output.txt.native-prefix.log';records=[json.loads(l)for l in native.read_text().splitlines()];native_rounds=[r for r in records if 'conflict_nodes'in r];assert native_rounds[-1]['conflict_nodes']==0 and native_rounds[-1]['summed_tree_vertices']==109862
 rows.append(dict(pid=row['pid'],attempt=i,input_sha256=sha(inp),body_byteexact=True,native_prefix_zero=True,native_log_sha256=sha(native)))
source=b/'source-2110/project/experiments/control_v1';prior=b/'source-2062/project/experiments/control_v1'
for n in ['pin_access_reservation.h','router_trial_pool.py','resource_search.h','native_prefix_seed.h','ordinary_coarse_grid.h']:assert(source/n).read_bytes()==(prior/n).read_bytes()
oracle=route/'router-distance-oracle.json';o=json.loads(oracle.read_text());assert o['passed']and o['exhaustive_distance_checks']==50000
result=dict(passed=True,time=time.time(),whole_system_qualified=False,job='96222',node='node24',allocated_cpus=16,actual_independent_live_children=12,source_root=str(b/'source-2110'),processes=data,actual_inputs=rows,binary_sha256=sha(route/'router'),oracle=o,inputs={str(source/n):sha(source/n)for n in ['tree_router.cpp','tree_router_cpp.py','router_trial_pool.py','system_upper.py']},scope='ActualUID/job/node/PID/source/mainCLI12 and12directownCPPchildren, after-native-m12/refresh0/nogrowth/8Mlabels flags andsame16CPUaffinity verified. All12actual11149netinput bodies/1229budgets byteexactoriginal, initialprefix zero. Matcher/pool/nativehelpers byteexactsource2062; actual28case source2110 after-native-m12 regression21130 PASS; currentcompileddistanceoracle passed. No full route/geometryPG3RC300MHz qualification inferred. Read-only metadata check insideexisting allocation; nootherjob mutation.')
out.mkdir();(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,actual_live_children=12,all_inputs_exact=True,whole_system_qualified=False)))
