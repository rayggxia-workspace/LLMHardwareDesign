"""Local exact-state diagnostic, never a route or physical qualification."""
from pathlib import Path
import array,collections,hashlib,json,time
b=Path(__file__).parent/'control162-endpoint2088';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cfg=json.loads((b/'config.json').read_text(encoding='utf-8'));outer=json.loads((b/'receipt.json').read_text(encoding='utf-8'));prior=json.loads((b/'analysis-receipt.json').read_text(encoding='utf-8'))
assert outer['passed']and any(v==sha(b/'analysis-receipt.json')for k,v in outer['inputs'].items()if k.endswith('/global-snapshot/receipt.json'))
assert prior['passed']and not prior['whole_system_qualified']and cfg['round']==8
snapshot=b/'output.txt.global-round-8.txt';inp=b/'input.txt'
assert sha(snapshot)==cfg['snapshot_sha256']and sha(inp)==cfg['input_sha256']
assert prior['inputs'][cfg['snapshot']]==sha(snapshot)and prior['inputs'][cfg['input']]==sha(inp)
lines=inp.read_text(encoding='utf-8').splitlines();h=list(map(int,lines[0].split()));nx,ny,count=h[:3];plane=nx*ny;assert h[:3]==[3070,3252,11149]and h[6]==1229
nets=[];landings={}
for n,line in enumerate(lines[1:]):
 r=line.split();k=int(r[1]);assert len(r)==3+2*k
 ps=[int(r[2+2*i])+nx*int(r[3+2*i])for i in range(k)]
 for v in ps:assert v not in landings;landings[v]=n
 nets.append((r[0],ps))
usage=array.array('H',[0])*(2*plane);owner=array.array('i',[-1])*(2*plane);trees=[]
with snapshot.open(encoding='utf-8')as f:
 assert int(f.readline())==count
 for n,(name,ps)in enumerate(nets):
  fields=f.readline().split();assert fields[0]==name;vs=set()
  for _ in range(int(fields[1])):
   r=list(map(int,f.readline().split()));assert len(r)==1+3*r[0]
   for j in range(1,len(r),3):vs.add(r[j]+nx*r[j+1]+plane*r[j+2])
  for v in vs:usage[v]+=1;owner[v]=n
  trees.append(array.array('I',vs))
 assert not f.read().strip()
actual=dict(conflict_nodes=sum(u>1 for u in usage),excess_occupancy=sum(max(0,u-1)for u in usage),occupied_cells=sum(bool(u)for u in usage),summed_tree_vertices=sum(usage))
for k,v in actual.items():assert v==prior['diagnostic'][k]
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
# Exact attribution using placement terminal sequence (driver then sinks).
import re,math
local=Path(__file__).parent/'control162-route-attribution2428'
gb=local/'boundary-graph.json';pb=local/'placement.json'
assert sha(gb)=='6ff74062b81cbee62076ee11dbd1713e08f9f04d9398cc1f5d904ef3b58fee9a'
assert sha(pb)=='b5f3aec1c9ca729a7f7a378246b55c12542036fb74eefabe1eee0a614b52c625'
g=json.loads(gb.read_bytes());p=json.loads(pb.read_bytes());assert p['graph_sha256']==sha(gb)
T=collections.Counter();B=collections.Counter();V=collections.Counter();W=collections.Counter();A=collections.Counter();roles=collections.Counter();skip=[]
for n,(name,ps) in enumerate(nets):
 xy=p['terminals'][name];assert ps==[x+nx*y for x,y in xy],(name,ps,xy)
 if n<h[6]:continue
 if not name.startswith('net_') or name[4:]not in g['connections']:
  skip.append((name,len(ps)));continue
 conn=g['connections'][name[4:]];own=set(trees[n])
 pins=[conn['driver'],*conn['sinks']];assert len(ps)==len(pins)
 for st,e in zip(ps,pins):
  inst=e['instance'];kind=g['instances'].get(inst,'TOP');bus=re.sub(r'\[\d+\]','[]',e['pin'])
  x=st%nx;y=(st%plane)//nx;seen={st};q=[st];esc=False;eligible=[]
  for v in q:
   if max(abs(v%nx-x),abs((v%plane)//nx-y))>=4:esc=True;break
   for w in neighbors(v):
    if landings.get(w,n)!=n:continue
    if usage[w]>(w in own):
     eligible.append(w)
    elif w not in seen:seen.add(w);q.append(w)
  T[(kind,bus)]+=1;V[inst]+=1;roles[(kind,e['direction'],0)]+=1
  if esc:continue
  B[(kind,bus)]+=1;W[inst]+=1;A[(x//64,y//64)]+=1;roles[(kind,e['direction'],1)]+=1
assert sum(T.values())+sum(x[1]for x in skip)==22302
types=collections.Counter();closed_types=collections.Counter()
for (kind,bus),count in T.items():
 types[kind]+=count;closed_types[kind]+=B[(kind,bus)]
result=dict(passed=True,whole_system_qualified=False,route_qualified=False,attributed_terminals=sum(T.values()),attributed_closed=sum(B.values()),non_connection_specials=skip,roles=[dict(kind=k,role=r,terminals=cnt,closed=roles[(k,r,1)])for(k,r,b),cnt in sorted(roles.items())if b==0],by_type=[dict(kind=k,terminals=t,closed=closed_types[k])for k,t in types.most_common()],top_buses=[dict(kind=k,bus=u,terminals=T[(k,u)],closed=cnt)for(k,u),cnt in B.most_common(45)],top_instances=[dict(instance=k,kind=g['instances'].get(k,'TOP'),terminals=V[k],closed=v)for k,v in W.most_common(35)],top_spatial_tiles=[dict(tile=list(k),closed=v)for k,v in A.most_common(30)],inputs={str(q):sha(q)for q in[inp,snapshot,gb,pb,b/'analysis-receipt.json',Path(__file__)]},scope='Exact original actual22200/trial0 completed round7. All11149 real router-input terminal arrays match original placement, and ordinary connection rows map driver then sinks. Attribute locally closed ordinary terminals by true instance/type/bus/direction, with actual foreign occupancy and real fixed landings. No extrapolation beyond this intermediate state; no physical or source changes.')
out=Path(__file__).with_suffix('.json');assert not out.exists();out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:result[k]for k in ['attributed_terminals','attributed_closed','non_connection_specials','by_type','top_buses']})[:4000])
