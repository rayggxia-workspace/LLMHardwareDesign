from pathlib import Path
import hashlib,json,math
import numpy as np
w=Path(__file__).parent;d=w/'control162-route-attribution2428'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p,g,m,pg=(json.loads((d/n).read_bytes()) for n in ('placement.json','boundary-graph.json','physical.json','physical-graph.json'))
assert sha(d/'placement.json')=='b5f3aec1c9ca729a7f7a378246b55c12542036fb74eefabe1eee0a614b52c625'
assert p['graph_sha256']==sha(d/'boundary-graph.json') and g['inputs'][next(k for k in g['inputs'] if k.endswith('/physical.json'))]==sha(d/'physical.json')
assert len(pg['connections'])==11149 and all(pg['connections'][k]==v for k,v in g['connections'].items())
fixed_input=w/'control162-endpoint2088/input.txt';lines=fixed_input.read_text().splitlines();critical={line.split()[0] for line in lines[1:1230]};assert len(critical)==1229
target='endpoint_7';xy=p['placements_um'][target]; W,H=m['leaves'][g['instances'][target]]['die_um']
assert all(v['source_instance']!=target for v in g['boundary_links']['links'])
static=set();moves=[];affected=[];boxes=[]
for k,c in pg['connections'].items():
 n='net_'+k;ends=[c['driver'],*c['sinks']];pts=p['terminals'][n];assert len(ends)==len(pts)
 mov=[tuple(v) for v,e in zip(pts,ends) if e['instance']==target];fix=[tuple(v) for v,e in zip(pts,ends) if e['instance']!=target]
 for v in fix:assert v not in static;static.add(v)
 if mov:
  assert n not in critical and len(mov)==1 and fix
  moves+=mov;affected.append(n)
  boxes.append([min(v[0] for v in fix),max(v[0] for v in fix),min(v[1] for v in fix),max(v[1] for v in fix),mov[0][0],mov[0][1]])
assert len(static)+len(moves)==24760 and len(set(moves))==len(moves)
limits=np.asarray(boxes,dtype=np.int32);q=np.asarray([(dx,dy)for dx in range(-128,129)for dy in range(-128,129)],dtype=np.int32);mask=np.ones(len(q),dtype=bool)
xx=xy[0]+4*q[:,0];yy=xy[1]+4*q[:,1]
mask&=(xx>=128)&(yy>=128)&(xx+W+128<=p['width_um'])&(yy+H+128<=p['height_um'])
for other,(x,y) in p['placements_um'].items():
 if other==target:continue
 ww,hh=m['leaves'][g['instances'][other]]['die_um']
 mask&=(xx+W<=x)|(x+ww<=xx)|(yy+H<=y)|(y+hh<=yy)
q=q[mask];assert len(q)>0
def measure(vecs):
 x=limits[:,4]+vecs[:,0,None];y=limits[:,5]+vecs[:,1,None]
 return np.maximum(limits[:,1],x)-np.minimum(limits[:,0],x)+np.maximum(limits[:,3],y)-np.minimum(limits[:,2],y)
base=measure(np.array([[0,0]]))[0];records=[]
for i in range(0,len(q),128):
 v=q[i:i+128];costs=measure(v);diff=costs-base
 for delta,change,absolute in zip(v,diff,costs):
  dx,dy=map(int,delta);records.append((int(change.sum()),int(change.max()),int(abs(dx)+abs(dy)),dx,dy,int((change>0).sum()),int(absolute.max())))
records.sort();top=[]
for s,mx,dist,dx,dy,longer,maxspan in records:
 if not any((x+dx,y+dy)in static for x,y in moves):
  top.append(dict(shift_um=[4*dx,4*dy],total_delta_hpwl_um=4*s,worst_increase_um=4*mx,longer_nets=longer,largest_bbox_span_um=4*maxspan))
  if len(top)==15:break
assert top
res=dict(passed=True,whole_system_qualified=False,route_qualified=False,instance=target,original_origin_um=xy,actual_bbox_candidates=int(len(q)),affected_ordinary_nets=len(affected),all_actual_landings=24760,affected_critical_nets=0,original_affected_hpwl_sum_um=int(base.sum())*4,best=top,inputs={str(t):sha(t)for t in [d/'placement.json',d/'boundary-graph.json',d/'physical-graph.json',d/'physical.json',fixed_input,Path(__file__)]},scope='Diagnostic only. Exhaustive single rigid endpoint_7 +/-512um shifts at actual4um step. Reuse immutable size, orientation, current345 rectangles/die and all11149 real landing sequences including PG; finalists reject all collisions and affect none of1229 critical net terminal arrays. Sort sum incident bbox wire length, then worst increase and displacement. No cap/route/PG/timing or physical qualification inferred.')
out=Path(__file__).with_suffix('.json');assert not out.exists();out.write_text(json.dumps(res,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in res.items()if k not in ['inputs','scope']})[:2200])
