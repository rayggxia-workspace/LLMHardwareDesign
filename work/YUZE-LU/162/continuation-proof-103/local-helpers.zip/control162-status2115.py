from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-ordinary-refresh-regression-21130';q=b/'dynamic-06/node26';d=dict(time=time.time(),whole_system_qualified=False)
for n in ['receipt.json','coarse-refine/receipt.json','coarse-refine/corridor-test.json']:
 f=p/n
 if f.exists():
  try:d[n]=json.loads(f.read_text())
  except ValueError:d[n]='transient'
for folder in ['','coarse-refine']:
 f=p/folder;d['file_counts_'+folder]=sum(1 for z in f.glob('*'))if f.exists()else 0
state=json.loads((q/'queue-state.json').read_text());d['queue']=dict(active=state['active'],memory_admissions=state['memory_admissions']);f=q/'commands/00-a-sready2113-ordinary-refresh-regression-21130.json'
if f.exists():d['command']=json.loads(f.read_text())
f=q/'00-a-sready2113-ordinary-refresh-regression-21130.log'
if f.exists():
 with f.open('rb')as s:s.seek(max(0,f.stat().st_size-6000));d['log_tail']=s.read().decode(errors='replace')
print(json.dumps(d))
'''
p=subprocess.run(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
if p.returncode:print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)
(b/'control162-status2115-latest.json').write_bytes(p.stdout);d=json.loads(p.stdout)
for k,v in d.items():
 if k=='command':v=dict(admission=v['admission'],script_sha256=v['script_sha256'])
 if isinstance(v,dict)and'inputs'in v:v={a:c for a,c in v.items()if a not in ['inputs','outputs']}
 if isinstance(v,dict)and'cases'in v:v=dict(passed=v['passed'],cases=len(v['cases']),successes=sum(not c['failed']for c in v['cases']),defaults=len(v['defaults']),prior_policy=len(v.get('prior_pin_policy_replays',[])),refresh=v.get('guided_refresh'),refresh_events=sum(len(c['ordinary_refresh_trace'])for c in v['cases']))
 print(k,json.dumps(v)[:6500])
