from pathlib import Path
import subprocess,json,shlex
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-06/node26';p=b/'r256-balanced-reset-composition-1888/upper-candidates/24200/route';s=json.loads((q/'queue-state.json').read_text());name='00-a0-sready2420-r256-route-24200';d=dict(time=time.time(),active=s['active'],memory_admissions=s['memory_admissions'],finished=s['finished'].get(name),ready=all((p/n).exists()and(p/n).stat().st_size for n in ['router-input.txt','router','trial-0/output.txt.native-prefix.log']),whole_system_qualified=False)
for sub in ['commands','results']:
 f=q/sub/(name+'.json')
 if f.exists():d[sub]=json.loads(f.read_text())
f=q/(name+'.log')
if f.exists():
 with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-2000));d['log_tail']=stream.read().decode(errors='replace')
f=p/'trial-0/router.log'
if f.exists():
 with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-1500));d['router_tail']=stream.read().decode(errors='replace')
print(json.dumps(d))
'''
p=subprocess.run(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=35);assert p.returncode==0,p.stderr.decode();(b/'control162-status2421-latest.json').write_bytes(p.stdout);d=json.loads(p.stdout)
if 'commands'in d:d['commands']={k:d['commands'][k]for k in ['admission','script_sha256','spec_sha256']}
print(json.dumps(d))
