from pathlib import Path
import subprocess,shlex,json,time
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888/upper-candidates';d=dict(time=time.time(),whole_system_qualified=False,cases=[],stages={})
for seed in [20400,20500,20800,21800,22000,22100,23400,23500,24000,24100,24200]:
 p=root/str(seed)/'route';logs=[p/'router.log']if seed==24000 else sorted(p.glob('trial-*/router.log'));rows=[]
 for f in logs:
  if not f.exists():continue
  raw=f.read_bytes();complete=[]
  for line in raw.splitlines(keepends=True):
   if not line.endswith(b'\n')or b'"conflict_nodes"'not in line:continue
   try:complete.append(json.loads(line))
   except ValueError:pass
  rows.append(dict(attempt=0 if seed==24000 else int(f.parent.name.split('-')[1]),last=complete[-1]if complete else None,live_bytes=len(raw),age=time.time()-f.stat().st_mtime,last_line=raw.splitlines()[-1].decode(errors='replace')if raw else''))
 d['cases'].append(dict(seed=seed,observed_attempts=len(rows),attempts=rows))
 if seed in [24000,24100,24200]:
  for stage in ['route','geometry','pg-audit','timing/low','timing/base','timing/high','delivery']:
   f=root/str(seed)/stage/'receipt.json'
   if f.exists():
    try:receipt=json.loads(f.read_text());d['stages'][str(seed)+'/'+stage]=dict(passed=receipt['passed'],stage=receipt.get('stage'),whole_system_qualified=receipt.get('whole_system_qualified'))
    except(ValueError,KeyError):pass
print(json.dumps(d))
'''
out=b/'control162-watch2425.jsonl';assert not out.exists()
for tick in range(60):
 start=time.time()
 try:
  raw=subprocess.check_output(['ssh','-o','ConnectTimeout=15','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35);d=json.loads(raw)
  with out.open('ab')as f:f.write(raw.rstrip()+b'\n')
  cases=[]
  for c in d['cases']:
   completed=[r for r in c['attempts']if r['last']]
   best=min(completed,key=lambda r:r['last']['conflict_nodes'])if completed else None
   first=next((r for r in c['attempts']if r['attempt']==0),None)
   cases.append(dict(seed=c['seed'],attempts=c['observed_attempts'],completed=len(completed),best=best['last']if best else None,trial0=first['last']if first else None,last_line=first['last_line']if first and not first['last']else None))
  print(json.dumps(dict(tick=tick,time=d['time'],cases=cases,stages=d['stages'],whole_system_qualified=False)),flush=True)
  if d['stages']:break
 except(subprocess.SubprocessError,ValueError)as e:print(json.dumps(dict(tick=tick,read_only_observer_error=str(e),remote_tasks_untouched=True)),flush=True)
 if tick<59:time.sleep(max(1,45-(time.time()-start)))
