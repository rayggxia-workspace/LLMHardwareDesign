from pathlib import Path
import hashlib,json,tarfile,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-2110';new=b/'source-2448';out=b/'r256-ordinary-seed-source-audit-2450';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();expected={'passed': True, 'commit': '165f1bbe2dfc7f5670c1bbf7ef8c63f4473896b8', 'source_files': 1030, 'unchanged_files': 1026, 'changed_files': ['project/experiments/control_v1/coarse_refine_regression.py', 'project/experiments/control_v1/system_upper.py', 'project/experiments/control_v1/tree_router.cpp', 'project/experiments/control_v1/tree_router_cpp.py'], 'archive_sha256': '7627e5df39ec1f6bc84db8337ad97bcfb33c2a7112dce3064c18ff8282531ac2', 'archive_bytes': 2414642, 'patch_sha256': 'f99e239dafb00fb2fb51f2b157d9e3afa9461baa06e878fef487edaa402419de', 'whole_system_qualified': False}
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed=set(expected['changed_files']);assert len(a['files'])==len(z['files'])==1030 and z['commit']==expected['commit']and {n for n,v in z['files'].items()if a['files'].get(n)!=v}==changed
archive=b/'source2448.tar.gz';assert sha(archive)==expected['archive_sha256']and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected['archive_sha256']and json.loads((b/'control162-archive2449.json').read_text())==expected
assert all(sha(new/n)==v for n,v in z['files'].items())
with tarfile.open(str(archive))as f:
 members={m.name:f.extractfile(m).read()for m in f.getmembers()};assert set(members)==set(z['files'])|{'source-manifest.json'}and all(hashlib.sha256(members[n]).hexdigest()==v for n,v in z['files'].items())
patch=b/'control162-backout2448.patch';assert sha(patch)==expected['patch_sha256'];out.mkdir();scratch=out/'reverse-copies'
for n in changed:p=scratch/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/n).read_bytes())
subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/n).read_bytes()==(old/n).read_bytes()for n in changed)
contract=b/'control162-contract2448.json';c=json.loads(contract.read_text());assert c['passed'] and c['fixture_cases']==35 and c['default_byte_replays']==18 and c['actual_fixture_successes']==13 and c['actual_full_warm_ordinary_nets']==1586 and c['actual_full_warm_ordinary_vertices']==1068255 and c['python_ast_identical_after_line_normalization']
for n,v in c['source_sha256'].items():assert sha(new/'project/experiments/control_v1'/n)==v
seed=b/'r256-ordinary-warm-data-2450';paths=seed/'pruned-ordinary-prefix.txt'
assert sha(paths)==c['ordinary_path_sha256']
native=b/'r256-current-prefix-data-1999/config.json';nk=json.loads(native.read_text());assert sha(Path(nk['prefix']))==nk['prefix_sha256'] and sha(Path(nk['input']))==nk['input_sha256']
assert json.loads((seed/'receipt.json').read_text())['outputs'][paths.name]==sha(paths)
seed_cfg=seed/'config.json';assert not seed_cfg.exists()
seed_cfg.write_text(json.dumps(dict(paths=str(paths),paths_sha256=sha(paths),native_prefix_sha256=nk['prefix_sha256'],input_sha256=nk['input_sha256']),indent=2))
outdata=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1030,unchanged_files=1026,changed_files=sorted(changed),archive_sha256=expected['archive_sha256'],scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(archive):sha(archive),str(patch):sha(patch),str(contract):sha(contract),str(paths):sha(paths),str(seed_cfg):sha(seed_cfg),str(native):sha(native)},scope='All1030 actual frozen source, archive and exact scratch reverse; same4 search wrapper/regression files differ2110, physical gates unchanged. Pruned ordinary paths and original native config exact by SHA, local whole actual input/landing checks already performed; real server fixture and complete route remain mandatory.')
(out/'receipt.json').write_text(json.dumps(outdata,indent=2));print(json.dumps(dict(passed=True,source_files=1030,unchanged=1026,scratch_backout_exact=True)))
