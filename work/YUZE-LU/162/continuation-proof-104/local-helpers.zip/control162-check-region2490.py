
import argparse, collections, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser()
for a in ('source','route','receipt'):p.add_argument(a,type=Path)
a=p.parse_args()
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def xyz(ls):
 assert len(ls)%3==0
 return tuple(zip(ls[::3],ls[1::3],ls[2::3]))
with a.source.open()as f:
 x0,y0,x1,y1,b,n=map(int,f.readline().split());assert x0<=x1 and y0<=y1 and b>=0 and n>0
 fixed={}
 def valid(u):
  assert x0<=u[0]<=x1 and y0<=u[1]<=y1 and u[2]in (0,1),u
 for i in range(b):
  u=tuple(map(int,f.readline().split()));assert len(u)==3 and u not in fixed;valid(u);fixed[u]='__native__'
 terminals={}
 for i in range(n):
  name,k,*ls=f.readline().split();pts=xyz(list(map(int,ls)));assert len(pts)==int(k)>0 and name not in terminals
  for u in pts:valid(u);assert u not in fixed;fixed[u]=name
  terminals[name]=pts
 assert not f.read().strip()
used={};nets=set();wires=vias=0
with a.route.open()as f:
 assert int(f.readline())==n
 for i in range(n):
  name,k=f.readline().split();assert name in terminals and name not in nets and int(k)>0;nets.add(name)
  adj=collections.defaultdict(set)
  for j in range(int(k)):
   count,*ls=map(int,f.readline().split());pts=xyz(ls);assert count==len(pts)>0 and len(set(pts))==len(pts)
   for u in pts:
    valid(u);assert fixed.get(u,name)==name and used.get(u,name)==name,(name,u,fixed.get(u),used.get(u));used[u]=name;adj[u]
   for u,v in zip(pts,pts[1:]):
    if u[2]==v[2]:assert abs(u[0]-v[0])+abs(u[1]-v[1])==1,(u,v)
    else:assert u[:2]==v[:2] and (u[0]+u[1])%2==0,(u,v)
    adj[u].add(v);adj[v].add(u)
  v=terminals[name][0];assert v in adj
  seen={v};q=[v]
  for v in q:
   for z in adj[v]-seen:seen.add(z);q.append(z)
  assert seen==adj.keys() and all(u in seen for u in terminals[name]),name
  for v,zs in adj.items():
   for z in zs:
    if z>v:wires+=v[2]==z[2];vias+=v[2]!=z[2]
 assert not f.read().strip()
out=dict(passed=True,scope='independent region only, no inter-region, physical or system qualification',region_source_sha256=sha(a.source),route_sha256=sha(a.route),nets=n,native_vertices=b,occupied=len(used),wire_unit_edges=wires,vias=vias)
with a.receipt.open('x')as f:json.dump(out,f,indent=2)
print(out)
