
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <stdexcept>
#include <tuple>
using namespace std;
int main(int argc,char**argv){try{
 if(argc!=2)throw runtime_error("input");
 ifstream in(argv[1]);int x0,y0,x1,y1,b,n;in>>x0>>y0>>x1>>y1>>b>>n;
 const int X=x1-x0+1,Y=y1-y0+1,P=X*Y,S=2*P;
 if(!in||X<1||Y<1||b<0||n<1||X>3070||Y>3252)throw runtime_error("bounds");
 auto pos=[&](int x,int y,int l){if(x<x0||x>x1||y<y0||y>y1||l<0||l>1)throw runtime_error("point bounds");return x-x0+X*(y-y0)+P*l;};
 auto coord=[&](int u){return make_tuple(x0+u%X,y0+(u%P)/X,u/P);};
 auto neighbors=[&](int u,auto f){auto [x,y,l]=coord(u);
  if(x>x0)f(u-1);if(x<x1)f(u+1);if(y>y0)f(u-X);if(y<y1)f(u+X);if((x+y)%2==0)f(u+(l?-P:P));};
 vector<int> owner(S,-1), comp(S,-1);int x,y,l;
 for(int j=0;j<b;++j){in>>x>>y>>l;int u=pos(x,y,l);if(owner[u]!=-1)throw runtime_error("duplicate obstacle");owner[u]=-2;}
 vector<string> names(n);vector<vector<int>> ends(n);
 for(int j=0;j<n;++j){int k;in>>names[j]>>k;if(k<=0)throw runtime_error("no pins");
  for(int i=0;i<k;++i){in>>x>>y>>l;int u=pos(x,y,l);if(owner[u]!=-1)throw runtime_error("overlap/duplicate endpoint");owner[u]=j;ends[j].push_back(u);}}
 string more;if(in>>more)throw runtime_error("trailing");
 vector<int> q,sizes;
 for(int u=0;u<S;++u)if(owner[u]==-1&&comp[u]<0){
  int id=sizes.size();q.clear();q.push_back(u);comp[u]=id;
  for(size_t i=0;i<q.size();++i)neighbors(q[i],[&](int v){if(owner[v]==-1&&comp[v]<0){comp[v]=id;q.push_back(v);}});
  sizes.push_back(q.size());
 }
 int bad=0,isolated=0,term=0;
 for(int j=0;j<n;++j){
  int k=ends[j].size();term+=k;
  vector<int> parents(k);map<int,int> seen;
  for(int i=0;i<k;++i)parents[i]=i;
  auto root=[&](int i){while(i!=parents[i]){parents[i]=parents[parents[i]];i=parents[i];}return i;};
  auto unite=[&](int i,int z){parents[root(z)]=root(i);};
  map<int,int> pin;for(int i=0;i<k;++i)pin[ends[j][i]]=i;
  vector<vector<int>> access(k);
  for(int i=0;i<k;++i)neighbors(ends[j][i],[&](int v){
   if(owner[v]==j)unite(i,pin.at(v));
   if(comp[v]>=0){access[i].push_back(comp[v]);auto [it,newcomp]=seen.emplace(comp[v],i);if(!newcomp)unite(i,it->second);}
  });
  set<int> parts;for(int i=0;i<k;++i)parts.insert(root(i));
  if(parts.size()>1){
   ++bad;int largest=-1;for(int i=0;i<k;++i)for(int c:access[i])if(largest<0||sizes[c]>sizes[largest])largest=c;
   int largest_root=-1;if(largest>=0)largest_root=root(seen.at(largest));
   for(int i=0;i<k;++i)if(root(i)!=largest_root){++isolated;auto [x,y,l]=coord(ends[j][i]);cout<<"isolated "<<names[j]<<" "<<x<<" "<<y<<" "<<l<<" "<<parts.size()<<" ";
    for(int c:access[i])cout<<sizes[c]<<",";cout<<endl;}
  }
 }
 cout<<"summary "<<n<<" "<<term<<" "<<sizes.size()<<" "<<*max_element(sizes.begin(),sizes.end())<<" "<<bad<<" "<<isolated<<endl;
 return bad?2:0;
}catch(const exception& e){cerr<<e.what()<<endl;return 1;}}
