#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <random>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;
struct E{int u,v,cap,base,occ=0,history=0,native=0;};
int main(int argc,char**argv){
 if(argc!=8)throw runtime_error("input prefix stride origin rounds seed out");
 ifstream in(argv[1]);int nx,ny,n,k,rounds,weight,locked;in>>nx>>ny>>n>>k>>rounds>>weight>>locked;string line;getline(in,line);
 if(nx!=3070||ny!=3252||n!=11149||locked!=1229)throw runtime_error("actual input");
 int S=stoi(argv[3]),O=stoi(argv[4]),R=stoi(argv[5]);if(S<32||S>128||O<0||O>=S||R<1||R>24)throw runtime_error("envelope");
 int X=(nx-8+O+S-1)/S,Y=(ny-8+O+S-1)/S,A=X*Y,V=2*A;
 auto node=[&](int x,int y,int l){return (x-4+O)/S+((y-4+O)/S)*X+l*A;};
 auto xy=[&](int v){return array<int,3>{v%X,(v%A)/X,v/A};};
 vector<vector<int>> edges(V);vector<E> ed;
 auto add=[&](int a,int b,int c,int d){if(c<=0)throw runtime_error("invalid cap");int i=ed.size();ed.push_back({a,b,c,d});edges[a].push_back(i);edges[b].push_back(i);};
 for(int l=0;l<2;++l)for(int y=0;y<Y;++y)for(int x=0;x<X;++x){
  int xa=max(4,4+x*S-O),xb=min(nx-5,3+(x+1)*S-O),ya=max(4,4+y*S-O),yb=min(ny-5,3+(y+1)*S-O),w=xb-xa+1,h=yb-ya+1,v=x+y*X+l*A;
  if(x+1<X)add(v,v+1,max(1,h*4/5),l==0?32:64);
  if(y+1<Y)add(v,v+X,max(1,w*4/5),l==1?32:64);
  if(!l){int cuts=(w*h+(((xa+ya)%2==0)?1:0))/2;add(v,v+A,cuts,48);}
 }
 unordered_set<int> blocked;auto real=[&](int x,int y,int l){return x+nx*y+l*nx*ny;};
 vector<string>names(n);vector<vector<int>> ps(n),routes(n);vector<int>spans(n);
 for(int j=0;j<n;++j){
  in>>names[j]>>k;int x0=nx,x1=0,y0=ny,y1=0;
  while(k--){int x,y;in>>x>>y;ps[j].push_back(node(x,y,0));blocked.insert(real(x,y,0));x0=min(x0,x);x1=max(x1,x);y0=min(y0,y);y1=max(y1,y);}
  in>>k;spans[j]=x1-x0+y1-y0;sort(ps[j].begin(),ps[j].end());ps[j].erase(unique(ps[j].begin(),ps[j].end()),ps[j].end());
 }
 ifstream pref(argv[2]);pref>>k;if(k!=locked)throw runtime_error("native prefix count");
 for(int j=0;j<locked;++j){string name;pref>>name>>k;if(name!=names[j])throw runtime_error("prefix net");unordered_set<int> es;while(k--){int z;pref>>z;int prev=-1;while(z--){int x,y,l;pref>>x>>y>>l;int v=node(x,y,l);blocked.insert(real(x,y,l));
   if(prev>=0&&v!=prev){auto w=find_if(edges[prev].begin(),edges[prev].end(),[&](int i){return ed[i].u==v||ed[i].v==v;});if(w==edges[prev].end())throw runtime_error("prefix coarse discontinuity");es.insert(*w);}
   prev=v;}}
  for(int e:es)++ed[e].native,++ed[e].occ;
 }
 // Capacity of actual disjoint across-tile unit edges, not nominal cut.
 // Never use the two corner sites of a side; a corner would otherwise
 // contend with a different axis. Native paths and actual landings stay.
 for(auto& e:ed){
  auto a=xy(e.u),b=xy(e.v);if(a[2]!=b[2])continue;
  int xa=max(4,4+a[0]*S-O),xb=min(nx-5,3+(a[0]+1)*S-O);
  int ya=max(4,4+a[1]*S-O),yb=min(ny-5,3+(a[1]+1)*S-O);
  int avail=0;
  if(a[0]!=b[0]){
   for(int y=ya+1;y<yb;++y)if(!blocked.count(real(xb,y,a[2]))&&!blocked.count(real(xb+1,y,a[2])))++avail;
  }else{
   for(int x=xa+1;x<xb;++x)if(!blocked.count(real(x,yb,a[2]))&&!blocked.count(real(x,yb+1,a[2])))++avail;
  }
  int soft=avail?min(e.cap,max(1,avail*9/10)):0;
  e.cap=e.native+soft;
 }
 vector<int> order(n-locked);iota(order.begin(),order.end(),locked);mt19937 rng(stoi(argv[6]));shuffle(order.begin(),order.end(),rng);
 stable_sort(order.begin(),order.end(),[&](int a,int b){return ps[a].size()!=ps[b].size()?ps[a].size()>ps[b].size():spans[a]>spans[b];});
 vector<int>dist(V),par(V);vector<unsigned char>tree(V);
 auto pressure=[&](int j){int p=0;for(int i:routes[j])p+=max(0,ed[i].occ-ed[i].cap);return p;};
 for(int r=0;r<R;++r){
  if(r){vector<int> priority(n);for(int j:order)priority[j]=pressure(j);stable_sort(order.begin(),order.end(),[&](int a,int b){return priority[a]>priority[b];});}
  for(int j:order){
   if(ps[j].size()<2)continue;
   if(r&&pressure(j)==0)continue;
   for(int e:routes[j])--ed[e].occ;routes[j].clear();fill(tree.begin(),tree.end(),0);
   tree[ps[j][0]]=1;vector<int> rest(ps[j].begin()+1,ps[j].end());
   while(!rest.empty()){
    int s=rest.front();rest.erase(rest.begin());if(tree[s])continue;
    fill(dist.begin(),dist.end(),numeric_limits<int>::max());fill(par.begin(),par.end(),-1);
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> q;dist[s]=0;q.push({0,s});
    int hit=-1;
    while(!q.empty()){
     auto [c,v]=q.top();q.pop();if(c!=dist[v])continue;if(tree[v]){hit=v;break;}
     for(int i:edges[v]){
      const auto& e=ed[i];if(e.cap<=e.native)continue;int u=e.u^e.v^v;
      int co=e.base+e.occ*26/e.cap+e.history*3+max(0,e.occ+1-e.cap)*(7+r*3);
      if(c+co<dist[u]){dist[u]=c+co;par[u]=i;q.push({c+co,u});}
     }
    }
    if(hit<0)throw runtime_error("coarse disconnected");
    for(int v=hit;v!=s;){int i=par[v];if(i<0)throw runtime_error("coarse path missing");routes[j].push_back(i);tree[v]=1;v=ed[i].u^ed[i].v^v;}
    tree[s]=1;
   }
   sort(routes[j].begin(),routes[j].end());routes[j].erase(unique(routes[j].begin(),routes[j].end()),routes[j].end());
   for(int e:routes[j])++ed[e].occ;
  }
  int over=0,max_over=0,excess=0,used=0,capacity=0;
  for(auto& e:ed){
   int p=max(0,e.occ-e.cap);e.history+=p;over+=p>0;max_over=max(max_over,p);excess+=p;used+=e.occ;capacity+=e.cap;
  }
  cout<<"{\"round\":"<<r<<",\"over_edges\":"<<over<<",\"excess\":"<<excess<<",\"max_over\":"<<max_over<<",\"used\":"<<used<<",\"sum_capacity\":"<<capacity<<"}"<<endl;
  if(!over)break;
 }
 ofstream out(argv[7]);out<<nx<<" "<<ny<<" "<<S<<" "<<O<<" "<<X<<" "<<Y<<" "<<locked<<" "<<n<<" "<<ed.size()<<"\n";
 for(const auto& e:ed)out<<e.u<<" "<<e.v<<" "<<e.cap<<" "<<e.occ<<" "<<e.native<<"\n";
 for(int j=locked;j<n;++j){
  out<<names[j]<<" "<<routes[j].size();for(int i:routes[j])out<<" "<<i;out<<"\n";
 }
}
