from pathlib import Path
import json,hashlib,collections,sys
b=Path(__file__).parent;src=b/(sys.argv[1]if len(sys.argv)>1 else'control162-portals2477');d=json.loads((src/'tile-plan.json').read_bytes())
original=json.loads((src/'receipt.json').read_bytes());assert hashlib.sha256((src/'tile-plan.json').read_bytes()).hexdigest()==original['plan_sha256']
S,O=96,32
pt_tile=lambda p:((p[0]-4+O)//S,(p[1]-4+O)//S)
# Ordinary terminal sets are part of tile-plan. Remove only actual portal
# endpoints whose single boundary step lies inside the merged window.
def get(k,ox,oy,emit=False):
 def group(t):return (t[0]+ox)//k,(t[1]+oy)//k
 grouped={}
 for t in d['tiles']:
  g=group(t['tile']);z=grouped.setdefault(g,dict(tiles=[],capacity=0,native=[],ports=collections.defaultdict(set)))
  z['tiles'].append(t['tile']);x,y,xx,yy=t['bounds'];z['capacity']+=2*(xx-x+1)*(yy-y+1)-len(t['native_points']);z['native']+=t['native_points']
  for n,ps in t['net_ports'].items():z['ports'][n].update(map(tuple,ps))
 keep={}
 for n,pairs in d['portals'].items():
  for a,v in pairs:
   p,q=group(pt_tile(a)),group(pt_tile(v))
   if p==q:
    z=grouped[p]['ports'][n];z.remove(tuple(a));z.remove(tuple(v))
   elif emit:keep.setdefault(n,[]).append((a,v))
 obs=[];specs=[]
 for g,z in grouped.items():
  bound=0;nums=0;pn=0
  for n,ps in z['ports'].items():
   if not ps:continue
   nums+=1;pn+=len(ps)
   span=sum(max(p[i]for p in ps)-min(p[i]for p in ps)for i in [0,1])
   bound+=max(len(ps),span+len({p[2]for p in ps}))
  obs.append(dict(group=g,available=z['capacity'],minimum=bound,excess=max(0,bound-z['capacity']),ratio=bound/z['capacity'],nets=nums,pins=pn,tiles=len(z['tiles'])))
  if emit:specs.append(dict(group=g,capacity=z['capacity'],native=z['native'],tiles=z['tiles'],net_ports={n:sorted(p)for n,p in z['ports'].items()if p}))
 ret=dict(group_size=k,offset=[ox,oy],groups=len(obs),excess=sum(x['excess']for x in obs),bad=sum(x['excess']>0 for x in obs),maximum=max(x['ratio']for x in obs),max_tiles=max(x['tiles']for x in obs),max_nets=max(x['nets']for x in obs),top=sorted(obs,key=lambda x:-x['ratio'])[:8])
 return (ret,specs,keep)if emit else ret

out=b/'control162-regions2482';assert not out.exists();out.mkdir()
k=12;ox=6;oy=6;rule,regions,portals=get(k,ox,oy,True);assert rule['bad']==0
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
nx,ny=d['grid'];rows=[];joined={};global_native=set();seen_ports={}
for z in regions:
 gx,gy=z['group'];ax,ay=gx*k-ox,gy*k-oy
 bounds=(max(4,4+ax*S-O),max(4,4+ay*S-O),min(nx-5,3+(ax+k)*S-O),min(ny-5,3+(ay+k)*S-O));x,y,xx,yy=bounds
 P={tuple(p)for p in z['native']};assert len(P)==len(z['native'])and not P&global_native;global_native|=P
 assert all(x<=p[0]<=xx and y<=p[1]<=yy for p in P)
 fixed={};boxlb=mstlb=0
 for n,ps in z['net_ports'].items():
  assert all(x<=p[0]<=xx and y<=p[1]<=yy for p in ps)
  for p in map(tuple,ps):assert p not in P and p not in fixed;fixed[p]=n
  span=sum(max(p[i]for p in ps)-min(p[i]for p in ps)for i in (0,1));layers=len({p[2]for p in ps})
  remaining=set(range(1,len(ps)));md=[abs(p[0]-ps[0][0])+abs(p[1]-ps[0][1])for p in ps];mst=0
  while remaining:
   q=min(remaining,key=lambda j:md[j]);remaining.remove(q);mst+=md[q]
   for j in remaining:md[j]=min(md[j],abs(ps[j][0]-ps[q][0])+abs(ps[j][1]-ps[q][1]))
  boxlb+=max(len(ps),span+layers);mstlb+=max(len(ps),max(span,(mst*2+2)//3)+layers)
 for p,n in fixed.items():assert p not in seen_ports;seen_ports[p]=n
 cap=2*(xx-x+1)*(yy-y+1)-len(P);assert mstlb<=cap
 tag=f'region-{gx}-{gy}';f=out/(tag+'.txt')
 with f.open('w',encoding='ascii',newline='\n')as fp:
  fp.write(' '.join(map(str,[*bounds,len(P),len(z['net_ports'])]))+'\n')
  for p in sorted(P):fp.write(' '.join(map(str,p))+'\n')
  for n,ps in z['net_ports'].items():fp.write(n+' '+str(len(ps))+' '+' '.join(str(v)for p in ps for v in p)+'\n')
 rows.append(dict(name=tag,group=z['group'],bounds=bounds,bytes=f.stat().st_size,sha256=sha(f),available=cap,minimum=mstlb,ratio=mstlb/cap,nets=len(z['net_ports']),ports=len(fixed),native_points=len(P)))
assert len(global_native)==109862
for n,ps in portals.items():
 for p,q in ps:
  assert seen_ports[tuple(p)]==n and seen_ports[tuple(q)]==n
  assert p[2]==q[2] and abs(p[0]-q[0])+abs(p[1]-q[1])==1
  assert (pt_tile(p)[0]+ox)//k!=(pt_tile(q)[0]+ox)//k or (pt_tile(p)[1]+oy)//k!=(pt_tile(q)[1]+oy)//k
plan=out/'cross-region.json';plan.write_text(json.dumps(portals,separators=(',',':')))
receipt=dict(passed=True,route_qualified=False,whole_system_qualified=False,rule=rule,retained_portals=sum(map(len,portals.values())),regions=sorted(rows,key=lambda x:-x['ratio']),actual_source_plan_sha256=original['plan_sha256'],cross_region_sha256=sha(plan),scope='Real source-bound region inputs plus independent bbox/MST physical capacity lower bounds and legal actual boundary vertices. No routes inside regions or final geometry/timing yet.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:receipt[k]for k in ['retained_portals','regions']})[:4200])
