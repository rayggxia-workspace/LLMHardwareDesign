from pathlib import Path
import json,hashlib,collections,sys
b=Path(__file__).parent;src=b/(sys.argv[1]if len(sys.argv)>1 else'control162-portals2477');d=json.loads((src/'tile-plan.json').read_bytes())
original=json.loads((src/'receipt.json').read_bytes());assert hashlib.sha256((src/'tile-plan.json').read_bytes()).hexdigest()==original['plan_sha256']
S,O=96,32
pt_tile=lambda p:((p[0]-4+O)//S,(p[1]-4+O)//S)
# Ordinary terminal sets are part of tile-plan. Remove only actual portal
# endpoints whose single boundary step lies inside the merged window.
def get(k,ox,oy,emit=False):
 def group(t):return (t[0]+ox)//k,(t[1]+oy)//k
 grouped={}
 for t in d['tiles']:
  g=group(t['tile']);z=grouped.setdefault(g,dict(tiles=[],capacity=0,native=[],ports=collections.defaultdict(set)))
  z['tiles'].append(t['tile']);x,y,xx,yy=t['bounds'];z['capacity']+=2*(xx-x+1)*(yy-y+1)-len(t['native_points']);z['native']+=t['native_points']
  for n,ps in t['net_ports'].items():z['ports'][n].update(map(tuple,ps))
 keep={}
 for n,pairs in d['portals'].items():
  for a,v in pairs:
   p,q=group(pt_tile(a)),group(pt_tile(v))
   if p==q:
    z=grouped[p]['ports'][n];z.remove(tuple(a));z.remove(tuple(v))
   elif emit:keep.setdefault(n,[]).append((a,v))
 obs=[];specs=[]
 for g,z in grouped.items():
  bound=0;nums=0;pn=0
  for n,ps in z['ports'].items():
   if not ps:continue
   nums+=1;pn+=len(ps)
   span=sum(max(p[i]for p in ps)-min(p[i]for p in ps)for i in [0,1])
   bound+=max(len(ps),span+len({p[2]for p in ps}))
  obs.append(dict(group=g,available=z['capacity'],minimum=bound,excess=max(0,bound-z['capacity']),ratio=bound/z['capacity'],nets=nums,pins=pn,tiles=len(z['tiles'])))
  if emit:specs.append(dict(group=g,capacity=z['capacity'],native=z['native'],tiles=z['tiles'],net_ports={n:sorted(p)for n,p in z['ports'].items()if p}))
 ret=dict(group_size=k,offset=[ox,oy],groups=len(obs),excess=sum(x['excess']for x in obs),bad=sum(x['excess']>0 for x in obs),maximum=max(x['ratio']for x in obs),max_tiles=max(x['tiles']for x in obs),max_nets=max(x['nets']for x in obs),top=sorted(obs,key=lambda x:-x['ratio'])[:8])
 return (ret,specs,keep)if emit else ret
rows=[get(k,ox,oy)for k in (1,2,3,4,5,6,8,10,12,16,20,32)for ox,oy in sorted({(0,0),(k//2,0),(0,k//2),(k//2,k//2)})]
r=dict(passed=True,whole_system_qualified=False,route_qualified=False,source_portal_sha256=original['plan_sha256'],cases=rows,scope='Fixed decomposition diagnostic. Merge adjacent existing real portal tiles, remove only interior portal constraints, keep exact available vertices/native occupancy. Report optimistic XY bbox and layer-change vertex lower bounds for each merged local system. Zero deficit is only a necessary check.')
out=Path(__file__).with_name(Path(__file__).stem+'-'+src.name+'.json');assert not out.exists();out.write_text(json.dumps(r,indent=2))
for k in sorted(set(t['group_size']for t in rows)):
 x=min((t for t in rows if t['group_size']==k),key=lambda t:(t['excess'],t['maximum']))
 print(k,x['offset'],x['bad'],x['excess'],round(x['maximum'],3),x['groups'],x['max_nets'])
