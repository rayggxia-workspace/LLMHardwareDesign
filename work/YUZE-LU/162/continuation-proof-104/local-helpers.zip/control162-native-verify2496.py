
import hashlib,json,collections,subprocess,sys
from pathlib import Path
b=Path(__file__).parent;root=b/'control162-native-repair2493';w=b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'
sys.path.insert(0,str(w));from router_conflict_snapshot import inputs,inspect
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inp=b/'control162-receive1988/input.txt';old=b/'control162-oriented1998/prefix.txt';pref=root/'candidate.txt';rec=json.loads((root/'receipt.json').read_bytes())
assert sha(pref)==rec['output_sha256'] and rec['inputs'][str(inp)]==sha(inp) and rec['inputs'][str(old)]==sha(old)
h,nets,limits=inputs(inp);nx,ny=h[:2];lock=h[6];names=list(nets);critical={n:nets[n]for n in names[:lock]};ordinary={n:nets[n]for n in names[lock:]}
assert len(critical)==1229 and len(ordinary)==9920 and all(limits[n]>=0 for n in critical)and all(limits[n]==-1 for n in ordinary)
a=inspect(pref,critical,nx,ny,limits);assert not a['conflict_nodes'] and a['all_trees_flood_verified']and a['all_wire_budgets_verified']
lands={(x,y,0):n for n,p in nets.items()for x,y in p};assert len(lands)==24760
occupied={}
with pref.open()as f:
 assert int(f.readline())==lock
 for n in critical:
  name,k=f.readline().split();assert n==name
  for _ in range(int(k)):
   count,*row=map(int,f.readline().split());assert len(row)==count*3
   for p in zip(row[::3],row[1::3],row[2::3]):
    assert lands.get(p,n)==n and occupied.get(p,n)==n
    occupied[p]=n
 assert not f.read().strip()
native_file=root/'exact-occupied.txt';global_input=root/'ordinary-connectivity.txt'
with native_file.open('x',newline=chr(10))as f:
 for p in sorted(occupied):f.write(' '.join(map(str,p))+chr(10))
with global_input.open('x',newline=chr(10))as f:
 f.write(f'4 4 {nx-5} {ny-5} {len(occupied)} {len(ordinary)}'+chr(10));f.write(native_file.read_text())
 for n,pts in ordinary.items():f.write(n+' '+str(len(pts))+' '+' '.join(f'{x} {y} 0'for x,y in pts)+chr(10))
exe=b/'control162-connect2492.exe';r=subprocess.run([str(exe),str(global_input)],capture_output=True,text=True)
with (root/'ordinary-connectivity.log').open('x')as f:f.write(r.stdout+r.stderr)
assert r.returncode==0 and r.stdout.split()[-2:]==['0','0'],r.stdout[-300:]
r=dict(passed=True,route_qualified=False,whole_system_qualified=False,inputs={str(p):sha(p)for p in [pref,inp,old,exe,b/'control162-connect2492.cpp',Path(__file__)]},native_nets=len(critical),native_occupied=len(occupied),ordinary_nets=len(ordinary),ordinary_terminal_groups=sum(map(len,ordinary.values())),budget_count=len(critical),foreign_true_landing_violations=0,native_overlap=0,all_ordinary_fixed_reachability=True,component_summary=r.stdout.strip(),output_sha256={q.name:sha(q)for q in [native_file,global_input,root/'ordinary-connectivity.log']})
with (root/'independent-receipt.json').open('x')as f:json.dump(r,f,indent=2)
print(r['component_summary'],r['native_occupied'])
