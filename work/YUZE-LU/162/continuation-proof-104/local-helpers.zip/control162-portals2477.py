from pathlib import Path
import hashlib,json,collections,statistics
b=Path(__file__).parent;inp=b/'control162-endpoint2088/input.txt';pref=b/'control162-oriented1998/prefix.txt';guide=b/'control162-guide2476-96-32-2068.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(guide.read_bytes())>300000
raw=inp.read_text().splitlines();nx,ny,n=map(int,raw[0].split()[:3]);lock=1229
with guide.open()as f:
 x,y,s,o,X,Y,k,N,m=map(int,f.readline().split());assert(x,y,k,N)==(nx,ny,lock,n);A=X*Y
 ed=[tuple(map(int,f.readline().split()))for _ in range(m)];paths={}
 for ln in f:
  v=ln.split();assert int(v[1])==len(v)-2;paths[v[0]]=list(map(int,v[2:]))
def xy(p):return ((p[0]-4+o)//s,(p[1]-4+o)//s)
def node(p):x,y=xy(p);return x+X*y+A*p[2]
def bounds(v):
 x,y=v%X,(v%A)//X
 return max(4,4+x*s-o),max(4,4+y*s-o),min(nx-5,3+(x+1)*s-o),min(ny-5,3+(y+1)*s-o)
nets={};landings={}
for i,ln in enumerate(raw[1:]):
 v=ln.split();pts=[(int(v[j]),int(v[j+1]),0)for j in range(2,len(v)-1,2)];nets[v[0]]=pts
 for pt in pts:assert pt not in landings;landings[pt]=v[0]
native=set();per_tile=collections.defaultdict(set)
with pref.open()as f:
 assert int(f.readline())==lock
 for name in list(nets)[:lock]:
  n0,k=f.readline().split();assert n0==name
  for _ in range(int(k)):
   v=list(map(int,f.readline().split()))
   for pt in zip(v[1::3],v[2::3],v[3::3]):native.add(pt);per_tile[xy(pt)].add(pt)
 assert not f.read().strip()
assert len(native)==109862
tile_ports=collections.defaultdict(lambda:collections.defaultdict(set));cross_demand=collections.defaultdict(list)
for name,ids in paths.items():
 for pt in nets[name]:tile_ports[xy(pt)][name].add(pt)
 for i in ids:
  u,v,*_=ed[i]
  if u//A==v//A:cross_demand[i].append(name)
available={}
for i,users in cross_demand.items():
 u,v,cap,all_demand,native_demand=ed[i];assert len(users)+native_demand==all_demand
 a,b0,c,d=bounds(u);aa,bb,cc,dd=bounds(v);l=u//A
 if v-u==1:
  assert c+1==aa and (b0,d)==(bb,dd);pairs=[((c,y,l),(aa,y,l))for y in range(b0,d+1)]
 else:
  assert v-u==X and d+1==bb and (a,c)==(aa,cc);pairs=[((x,d,l),(x,bb,l))for x in range(a,c+1)]
 assert all(node(p)==u and node(q)==v for p,q in pairs)
 potential=[(j,p,q)for j,(p,q)in enumerate(pairs)if p not in landings and q not in landings and p not in native and q not in native]
 corners={0,len(pairs)-1};available[i]=(potential,corners)
taken=set();portals={};miss=[];counts=collections.Counter()
for i,users in sorted(cross_demand.items(),key=lambda t:len(available[t[0]][0])-len(t[1])):
 u,v,*_=ed[i];along=1 if v-u==1 else 0
 choices,corners=available[i];choices=[z for z in choices if z[0] not in corners]
 free=[(j,p,q)for j,p,q in choices if p not in taken and q not in taken]
 interior=[z for z in free if z[0]not in corners]
 if len(free)<len(users):miss.append((i,len(users),len(free)));continue
 options=interior if len(interior)>=len(users)else free
 # Use regularly spaced legal sites to leave room for within-tile access.
 locs=[options[(2*j+1)*len(options)//(2*len(users))]for j in range(len(users))]
 assert len(locs)==len(set(locs))
 users=sorted(users,key=lambda n:(statistics.median(p[along]for p in nets[n]),n))
 for name,(j,p,q) in zip(users,locs):
  assert p not in taken and q not in taken;taken.update((p,q))
  portals.setdefault(name,[]).append((p,q))
  tile_ports[xy(p)][name].add(p);tile_ports[xy(q)][name].add(q);counts[u//A]+=1
assert not miss,miss
for name,ps in nets.items():
 if name not in paths:continue
 demands={xy(p)for p in ps};adj=collections.defaultdict(set)
 for p,q in portals.get(name,[]):
  a,z=xy(p),xy(q);adj[a].add(z);adj[z].add(a)
 start=min(demands);q=[start];seen={start}
 for u in q:
  for v in adj[u]:
   if v not in seen:seen.add(v);q.append(v)
 assert demands<=seen and set(adj)<=seen
assert sum(counts.values())==sum(len(v) for v in cross_demand.values())
out=b/'control162-portals2477';assert not out.exists();out.mkdir()
tiles=[dict(tile=list(k),bounds=bounds(k[0]+X*k[1]),native_points=sorted(per_tile[k]),net_ports={n:sorted(p)for n,p in sorted(v.items())})for k,v in sorted(tile_ports.items())]
plan=dict(schema='actual-coarse-portal-plan-v1',grid=[nx,ny],tiles=tiles,portals=portals,inputs={str(p):sha(p)for p in [inp,pref,guide,Path(__file__)]},whole_system_qualified=False)
target=out/'tile-plan.json';target.write_text(json.dumps(plan,separators=(',',':')),encoding='ascii')
receipt=dict(passed=True,whole_system_qualified=False,route_qualified=False,actual_portal_edges=sum(counts.values()),by_layer=dict(counts),distinct_true_vertices=len(taken),tiles=len(tiles),nonlocal_nets=len(portals),plan_sha256=sha(target),top_tiles=[dict(tile=t['tile'],net_count=len(t['net_ports']),pins=sum(len(v)for v in t['net_ports'].values()))for t in sorted(tiles,key=lambda t:-sum(map(len,t['net_ports'].values())))[:12]],scope='All candidate coarse intertile wire crossings are unique real single grid edges, outside native prefix and every physical M11 landing. Both layers. No within-tile connection exists yet; tile-local buses, vias, native budgets, timing, geometry and physical acceptance remain separate.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt)[:2700])
