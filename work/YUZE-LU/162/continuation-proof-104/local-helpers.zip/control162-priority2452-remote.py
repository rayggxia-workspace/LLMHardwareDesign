from pathlib import Path
import hashlib,json,re,subprocess,time,sys
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';q=b/'dynamic-06/node26';out=b/'route-selection-102/sready2452-ordinary-warm-search-priority'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not out.exists()
audit=b/'r256-ordinary-seed-source-audit-2450/receipt.json';assert json.loads(audit.read_text())['passed']
record=b/'route-selection-102/sready2451-ordinary-refresh-regression/tasks.json';z=json.loads(record.read_text());assert len(z['tasks'])==1
r=z['tasks'][0];p=Path(r['path']);assert p.parent==q/'pending'and json.loads(p.read_text())==r['spec']and r['spec']['source_root']==str(b/'source-2448')and r['spec']['forecast_gib']==8
qs=json.loads((q/'queue-state.json').read_text())
assert p.stem not in qs['active'] and p.stem not in qs['finished'], 'Regression already admitted; no replacement before full-chain memory decision'
assert any(x['name']==p.stem and not x['admitted'] for x in qs['memory_admissions']), 'Need an actual recent original memory refusal'
args=r['spec']['args'];config=Path(args[args.index('--coarse-refine-regression-config')+1]);cfg=json.loads(config.read_text());assert cfg['guided_pin_access']=='after-native-m12'and cfg['guided_refresh']==8 and sha(config)==z['config_sha256']
assert cfg['previous_m12_for_ordinary_seed']==str(b/'r256-ordinary-refresh-regression-21130/coarse-refine')
m12=root/'upper-candidates/24200/route';z=json.loads((b/'route-selection-102/sready2423-actual-twelve-processes/receipt.json').read_text());assert z['passed']and z['actual_independent_live_children']==12
m12_task=next(t for t in json.loads((b/'route-selection-102/sready2420-arbiter-fullchain/tasks.json').read_text())['tasks']if t['spec']['script']=='system_upper.py')
m12_spec=Path(m12_task['path']);assert sha(m12_spec)==m12_task['sha256'] and m12_spec.stem in json.loads((q/'queue-state.json').read_text())['active']
for t in range(12):
 f=m12/('trial-'+str(t))/'router.log'
 rounds=[json.loads(x)for x in f.read_bytes().splitlines()if b'"conflict_nodes"' in x and x.endswith(b'}')]
 assert rounds and rounds[-1]['round']>=7
details=subprocess.check_output(['scontrol','show','job','96222','-o'],universal_newlines=True)
assert 'UserId=yuzelu(10011)'in details and 'JobName=yzl-ctl162-'in details and 'NodeList=node24 'in details
steps=subprocess.check_output(['scontrol','show','step','96222','-o'],universal_newlines=True)
found=[m.groups()for m in re.finditer(r'StepId=(96222\.[0-9]+).*?SrunHost:Pid=(node[0-9]+):([0-9]+)',steps)]
code="import os,json;d={}"+chr(10)+"for p in "+repr([r[2]for r in found])+":"+chr(10)+" try:"+chr(10)+"  assert os.stat('/proc/'+p).st_uid==10011;d[p]=open('/proc/'+p+'/cmdline','rb').read().decode().split(chr(0))"+chr(10)+" except OSError:pass"+chr(10)+"print(json.dumps(d))"
procs=json.loads(subprocess.check_output(['srun','--jobid=96222','--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));targets=[]
for seed in (24100,):
 tag=seed//10;rows=json.loads((b/('route-selection-102/sready'+str(tag)+'-arbiter-fullchain/tasks.json')).read_text())['tasks'];r=next(t for t in rows if t['spec']['script']=='system_upper.py');p=Path(r['path']);spec=r['spec'];a=spec['args'];route=root/'upper-candidates'/str(seed)/'route';state=json.loads((q/'queue-state.json').read_text())
 assert p.parent==q/'pending'and sha(p)==r['sha256']and p.stem in state['active']and p.stem not in state['finished']and state['job']=='96222'
 assert spec['source_root']==str(b/'source-2089')and a[a.index('--out')+1]==str(route)and a[a.index('--graph')+1]==str(root/'topology/boundary-graph.json')and a[a.index('--route-heuristic-weight')+1]=='1'
 assert a[a.index('--route-nonpreferred-cost')+1]=='32'and a[a.index('--route-ordinary-coarse')+1]=='32'and a[a.index('--route-ordinary-present-growth')+1]=='0' and a[a.index('--route-trials')+1]=='16' and a[a.index('--route-pin-access')+1]=='after-native' and a[a.index('--route-ordinary-refresh')+1]=='0' and spec['forecast_gib']==65
 for n in ['receipt.json','trees.json','search.json','router-output.txt']:assert not(route/n).exists(),('Possible final result appeared; preserve',seed,n)
 cmd=json.loads((q/'commands'/p.name).read_text());assert cmd['spec_sha256']==sha(p)=='eddfe5abed60ccb1d5ec882f81b2e04801e1bd3dde9832e6b3a4db291b9cec6a'
 matched=[]
 for step,host,pid in found:
  c=procs.get(pid,[])
  if '--out'in c and c[c.index('--out')+1]==str(route)and str(b/'source-2089/project/experiments/control_v1/system_upper.py')in c:matched.append(dict(step=step,host=host,pid=pid,command=c))
 assert len(matched)==1 and matched[0]['host']=='node24'
 logs=[]
 for i in range(17):
  log=route/('trial-'+str(i))/'router.log';raw=log.read_bytes();records=[]
  for line in raw.decode(errors='replace').splitlines():
   try:v=json.loads(line)
   except ValueError:continue
   if 'conflict_nodes'in v:records.append(v)
  if i==6:assert not records and raw.splitlines()[-1]==b'disconnected bidirectional tree: net_3833'
  else:assert records and records[-1]['round']>=8 and records[-1]['conflict_nodes']>750000
  if i==0:assert any(x['round']==7 and x['conflict_nodes']==908654 for x in records)
  assert not(route/('trial-'+str(i))/'output.txt').exists()
  logs.append(dict(path=str(log),observed_bytes=len(raw),observed_prefix_sha256=hashlib.sha256(raw).hexdigest(),last_round=records[-1]if records else None,scope='Hash of observed live prefix, not a promise the live file stops growing'))
 targets.append(dict(seed=seed,spec_path=str(p),spec_sha256=sha(p),spec=spec,process=matched[0],log_observations=logs,command_receipt=cmd))
reason='Reprioritized only owned dual-plane 24100 after an exact closed pin failure (trial6) and all sixteen remaining attempts >=8 rounds/>750000 conflicts with no final outputs. Retain M12-only 24200 (twelve actual trials each >=7), baseline23400/23500, periodic24000 and original matrix. Source2448 audited and actual24510 warm-route regression concretely queued, unchanged physical gates. Preserved original failed trial, all logs/artifacts and six untouched successors. No other job/parent/R mutation or feasibility claim.'
out.mkdir();(out/'verified-before.json').write_text(json.dumps(dict(time=time.time(),targets=targets,job_details=details,whole_system_qualified=False,reason=reason),indent=2))
print(json.dumps(dict(verified=True,targets=[dict(seed=t['seed'],step=t['process']['step'],minimum_completed_round=min(v['last_round']['round']for v in t['log_observations']if v['last_round']))for t in targets],apply_requested='--apply'in sys.argv)))
if '--apply'not in sys.argv:
 (out/'read-only.json').write_text(json.dumps(dict(passed=True,cancelled=False,scope=reason),indent=2))
 sys.exit(0)
retired=[]
for t in targets:
 p=Path(t['spec_path']);route=root/'upper-candidates'/str(t['seed'])/'route';state=json.loads((q/'queue-state.json').read_text());assert p.stem in state['active']and sha(p)==t['spec_sha256']
 for n in ['receipt.json','trees.json','search.json','router-output.txt']:assert not(route/n).exists()
 subprocess.run(['scancel',t['process']['step']],check=True);retired.append(dict(seed=t['seed'],step=t['process']['step']));(out/'retire-progress.json').write_text(json.dumps(retired,indent=2))
(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),retired=retired,whole_system_qualified=False,scope=reason),indent=2));print(json.dumps(dict(passed=True,retired=retired)))
