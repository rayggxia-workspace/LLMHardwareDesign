
from pathlib import Path
import json,collections,hashlib,subprocess
b=Path(__file__).parent;s=b/'control162-regions2482';o=b/'control162-regions2497';p=b/'control162-native-repair2493';assert not o.exists();o.mkdir()
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
base=json.loads((s/'receipt.json').read_bytes());pr=json.loads((p/'receipt.json').read_bytes())
assert sha(p/'candidate.txt')==pr['output_sha256']
assert sha(s/'cross-region.json')==base['cross_region_sha256']
data=json.loads((s/'cross-region.json').read_bytes());ordered=[(name,tuple(a),tuple(z))for name,es in data.items()for a,z in es]
bounds={r['name']:tuple(r['bounds'])for r in base['regions']};native={r:set()for r in bounds};real={r:collections.defaultdict(set)for r in bounds}
def region(v):
 for r,(x,y,xx,yy)in bounds.items():
  if x<=v[0]<=xx and y<=v[1]<=yy:return r
 raise AssertionError(v)
inp=b/'control162-receive1988/input.txt'
with inp.open()as f:
 head=list(map(int,f.readline().split()));lock=head[6]
 for j,row in enumerate(f):
  if j<lock:continue
  a=row.split();n,k=a[:2];xy=list(map(int,a[2:-1]));assert len(xy)==2*int(k) and int(a[-1])==-1
  for x,y in zip(xy[::2],xy[1::2]):
   v=x,y,0;real[region(v)][n].add(v)
with (p/'candidate.txt').open()as f:
 assert int(f.readline())==lock
 for i in range(lock):
  _,k=f.readline().split()
  for j in range(int(k)):
   count,*row=map(int,f.readline().split());assert len(row)==3*count
   for v in zip(row[::3],row[1::3],row[2::3]):native[region(v)].add(v)
 assert not f.read().strip()
fix={}
for r,m in real.items():
 for n,vs in m.items():
  for v in vs:assert v not in fix and v not in native[r];fix[v]=n
for r,ps in native.items():
 for v in ps:assert v not in fix;fix[v]=None
assert len(ordered)==7222
at={};pos=[];options=[];rng=None
for i,(n,a,z) in enumerate(ordered):
 r,t=region(a),region(z);assert r!=t and a[2]==z[2]
 slide=1 if a[0]!=z[0] else 0
 assert abs(a[1-slide]-z[1-slide])==1 and a[slide]==z[slide]
 # Confine to the existing 96-track cut segment. Leave real region corners alone.
 first=max(4+((a[slide]-4+32)//96)*96-32,bounds[r][slide],bounds[t][slide])
 last=min(first+95,bounds[r][slide+2],bounds[t][slide+2],3+((a[slide]-4+32)//96+1)*96-32)
 pairs=[]
 for d in range(first+1,last):
  u=list(a);v=list(z);u[slide]=v[slide]=d;u,v=tuple(u),tuple(v)
  assert region(u)==r and region(v)==t
  if u not in fix and v not in fix:pairs.append((u,v))
 assert pairs,(a,z)
 options.append(pairs)
 pair=(a,z)
 if pair not in pairs:pos.append(None);continue
 assert a not in at and z not in at
 at[a]=at[z]=i;pos.append(pair)
def nbr(v,r):
 x,y,l=v;x0,y0,x1,y1=bounds[r]
 if x>x0:yield x-1,y,l
 if x<x1:yield x+1,y,l
 if y>y0:yield x,y-1,l
 if y<y1:yield x,y+1,l
 if not (x+y)%2:yield x,y,1-l
def reachable(v,n,probe=5):
 r=region(v);q=[v];seen={v}
 for a in q:
  if max(abs(a[0]-v[0]),abs(a[1]-v[1]))>=probe:return True
  for z in nbr(a,r):
   if z not in seen and fix.get(z,n)==n and (z not in at or ordered[at[z]][0]==n):
    seen.add(z);q.append(z)
 return False
def update(i,pair):
 if pos[i]:
  for v in pos[i]:assert at.pop(v)==i
 for v in pair:
  assert v not in at and v not in fix;at[v]=i
 pos[i]=pair
def remedy(i,avoid=()):
 n,a,z=ordered[i]
 prev=pos[i];target=prev or (a,z)
 candidates=sorted((p for p in options[i]if p!=prev and all(v not in at or at[v]==i for v in p)and not any(max(abs(v[0]-u[0]),abs(v[1]-u[1]))<=2 for v in p for u in avoid)),key=lambda p:abs(p[0][0]-target[0][0])+abs(p[0][1]-target[0][1]))
 for pair in candidates:
  update(i,pair)
  if all(reachable(v,n)for v in pair)and all(reachable(u,fix[u])for u in avoid if u in fix and fix[u] is not None):return True
  if prev:update(i,prev)
  else:
   for v in pair:assert at.pop(v)==i
   pos[i]=None
 return False
for i,pair in enumerate(pos):
 if pair is None:assert remedy(i),('failed relocation off native',i,ordered[i])
def emit(folder):
 folder.mkdir()
 pset={r:{n:set(ps)for n,ps in m.items()}for r,m in real.items()};es={}
 for i,pair in enumerate(pos):
  n,_,_=ordered[i];assert pair is not None
  es.setdefault(n,[]).append(pair)
  for v in pair:pset[region(v)].setdefault(n,set()).add(v)
 rs=[]
 for r,m in pset.items():
  fn=folder/(r+'.txt');blocked=native[r];bb=bounds[r]
  if not m:continue
  with fn.open('x',newline=chr(10))as f:
   f.write(' '.join(map(str,[*bb,len(blocked),len(m)]))+chr(10))
   for v in sorted(blocked):f.write(' '.join(map(str,v))+chr(10))
   for n,vs in sorted(m.items()):f.write(n+' '+str(len(vs))+' '+' '.join(str(t)for v in sorted(vs)for t in v)+chr(10))
  rs.append(dict(name=r,bounds=bb,bytes=fn.stat().st_size,sha256=sha(fn),nets=len(m),ports=sum(map(len,m.values())),native_vertices=len(blocked)))
 cross=folder/'cross-region.json';cross.write_text(json.dumps(es,separators=(',',':')))
 return rs,sha(cross)
exe=b/'control162-connect2492.exe';hist=[]
for sweep in range(5):
 folder=o/str(sweep);rs,cross=emit(folder)
 blocked=[]
 for row in rs:
  r=row['name'];f=folder/(r+'.txt');q=subprocess.run([str(exe),str(f)],capture_output=True,text=True)
  assert q.returncode in (0,2),q.stderr
  (folder/(r+'.connect.log')).write_text(q.stdout)
  for line in q.stdout.splitlines():
   if line.startswith('isolated '):
    _,n,x,y,l,*rest=line.split();blocked.append((r,n,(int(x),int(y),int(l))))
 hist.append(dict(sweep=sweep,closed=blocked,region_rows=rs,cross_region_sha256=cross,changed=sum(pair!=(a,z)for pair,(_,a,z)in zip(pos,ordered))))
 print(sweep,len(blocked),hist[-1]['changed'],blocked[:9],flush=True)
 if not blocked:break
 change=0
 for r,n,v in blocked:
  if v in at:
   change+=remedy(at[v]);continue
  nearby=sorted({at[u]for u in at if max(abs(u[0]-v[0]),abs(u[1]-v[1]))<=4})
  for i in nearby:
   change+=remedy(i,[v])
 if not change:break
r=dict(passed=not blocked,route_qualified=False,whole_system_qualified=False,regions=len(rs),retained_portals=len(ordered),observations=hist,inputs={str(q):sha(q)for q in [p/'candidate.txt',s/'cross-region.json',inp,exe,Path(__file__)]},scope='Exact owner-exclusive reachability within each region (no ordinary path occupancy yet). Reassign portals only on same physical cut segment and layer; no completed paths or physical acceptance.')
(o/'receipt.json').write_text(json.dumps(r,indent=2))
