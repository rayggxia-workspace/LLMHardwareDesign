#include <algorithm>
#include <chrono>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <random>
#include <sstream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
struct Item {int64_t priority,cost;int node;bool operator<(const Item& q)const{
 if(priority!=q.priority)return priority>q.priority;
 // On an equal A* score, advance towards the existing tree rather than
 // expanding an arbitrary broad equal-score frontier. Physical checks stay
 // independent of this search-order decision.
 if(cost!=q.cost)return cost<q.cost;
 return node>q.node;
}};
// Optional exact two-ended search. Reverse edges charge the original
// destination vertex, and balanced Manhattan potentials make both reduced
// graphs nonnegative. This workspace is never used for finite wire budgets.
struct BidirectionalSearch {
 vector<int64_t>df,db;vector<uint32_t>vf,vb;vector<int>pf,pb;uint32_t epoch=0;
 explicit BidirectionalSearch(size_t size):df(size),db(size),vf(size),vb(size),pf(size),pb(size){}
 template<class Cost,class Allowed>
 vector<int>find(int nx,int ny,int start,int goal,Cost penalty,Allowed allowed,int nonpreferred_cost=2){
  if(nonpreferred_cost!=2&&nonpreferred_cost!=8&&nonpreferred_cost!=32)throw runtime_error("invalid bidirectional direction cost");
  int plane=nx*ny,size=2*plane;const int64_t inf=numeric_limits<int64_t>::max()/4;
  if(!++epoch)throw runtime_error("bidirectional epoch overflow");
  auto coord=[&](int v){return array<int,3>{v%nx,(v%plane)/nx,v/plane};};
  auto s=coord(start),g=coord(goal);
  auto potential=[&](int v){auto p=coord(v);return abs(p[0]-g[0])+abs(p[1]-g[1])-abs(p[0]-s[0])-abs(p[1]-s[1]);};
  priority_queue<Item>qf,qb;qf.push({0,0,start});qb.push({0,0,goal});
  vf[start]=vb[goal]=epoch;df[start]=db[goal]=0;int meeting=-1;int64_t best=inf;
  auto consider=[&](int v){if(vf[v]==epoch&&vb[v]==epoch&&df[v]+db[v]<best){best=df[v]+db[v];meeting=v;}};
  consider(start);
  while(true){
   while(!qf.empty()&&(vf[qf.top().node]!=epoch||df[qf.top().node]!=qf.top().priority))qf.pop();
   while(!qb.empty()&&(vb[qb.top().node]!=epoch||db[qb.top().node]!=qb.top().priority))qb.pop();
   if(qf.empty()||qb.empty())break;
   if(best!=inf&&qf.top().priority+qb.top().priority>=best)break;
   bool reverse=qb.top().priority<qf.top().priority;auto& q=reverse?qb:qf;
   auto& d=reverse?db:df;auto& seen=reverse?vb:vf;auto& parent=reverse?pb:pf;
   auto item=q.top();q.pop();int v=item.node;auto c=coord(v);int x=c[0],y=c[1],l=c[2];
   array<pair<int,int>,5>next{{{v-1,l==0?1:nonpreferred_cost},{v+1,l==0?1:nonpreferred_cost},{v-nx,l==1?1:nonpreferred_cost},{v+nx,l==1?1:nonpreferred_cost},{(1-l)*plane+y*nx+x,3}}};
   for(int i=0;i<5;++i){if(i==4&&(x+y)%2)continue;int w=next[i].first;if(w<0||w>=size)continue;auto p=coord(w);
    if(p[0]<4||p[0]>=nx-4||p[1]<4||p[1]>=ny-4||!allowed(w))continue;
    int64_t cost=next[i].second+penalty(reverse?v:w);
    __int128 reduced=__int128(2)*cost+(reverse?potential(v)-potential(w):potential(w)-potential(v));
    if(reduced<0||__int128(item.priority)+reduced>=inf)throw runtime_error("invalid reduced bidirectional cost");
    int64_t alt=item.priority+int64_t(reduced);
    // Reduced costs can be zero across an empty Manhattan rectangle. The
    // tie key is twice the original accumulated cost, rather than the
    // reduced cost, so equal-score searches advance instead of sweeping
    // that whole rectangle. Distances and termination use reduced costs.
    int64_t original=alt+(reverse?potential(w)-potential(goal):potential(start)-potential(w));
    if(seen[w]!=epoch||alt<d[w]){seen[w]=epoch;d[w]=alt;parent[w]=v;q.push({alt,original,w});consider(w);}
   }
  }
  if(meeting<0)return{};
  vector<int>path{meeting};while(path.back()!=start)path.push_back(pf[path.back()]);reverse(path.begin(),path.end());
  for(int v=meeting;v!=goal;){v=pb[v];path.push_back(v);}return path;
 }
};
#include "weighted_bidirectional.h"
#include "weighted_settled_bidirectional.h"

#include "ordinary_zero_pattern.h"
#include "ordinary_coarse_grid.h"
#include "routing_corridor.h"
int main(int argc,char**argv){try{
 if(argc!=7)throw runtime_error("region input output seed rounds direction stride");
 ifstream in(argv[1]);int x0,y0,x1,y1,blocked,count;in>>x0>>y0>>x1>>y1>>blocked>>count;
 if(!in||x1<x0||y1<y0||x1-x0>=1200||y1-y0>=1200||count<1||blocked<0)throw runtime_error("region envelope");
 const int ox=4+(x0+y0)%2,oy=4,nx=x1-x0+1+ox+4,ny=y1-y0+1+oy+4,plane=nx*ny,size=2*plane;
 auto pos=[&](int x,int y,int l){if(x<x0||x>x1||y<y0||y>y1||l<0||l>1)throw runtime_error("real point outside region");return (x-x0+ox)+nx*(y-y0+oy)+l*plane;};
 auto local=[&](int v){return array<int,3>{v%nx,(v%plane)/nx,v/plane};};
 auto xy=[&](int v){auto p=local(v);return array<int,3>{p[0]-ox+x0,p[1]-oy+y0,p[2]};};
 vector<int>fixed(size,-1);for(int v=0;v<size;++v){auto p=xy(v);if(p[0]<x0||p[0]>x1||p[1]<y0||p[1]>y1)fixed[v]=-2;}
 for(int i=0;i<blocked;++i){int x,y,l;in>>x>>y>>l;int v=pos(x,y,l);if(fixed[v]!=-1)throw runtime_error("duplicate native point");fixed[v]=-2;}
 vector<string> names(count);vector<vector<int>> ends(count),trees(count);vector<vector<vector<int>>> branches(count);
 for(int n=0;n<count;++n){int k;in>>names[n]>>k;if(k<1)throw runtime_error("empty ports");while(k--){int x,y,l;in>>x>>y>>l;int v=pos(x,y,l);if(fixed[v]!=-1)throw runtime_error("duplicate/blocked terminal");fixed[v]=n;ends[n].push_back(v);}}
 string trailing;if(in>>trailing)throw runtime_error("trailing region input");
 int seed=stoi(argv[3]),maxround=stoi(argv[4]),direction=stoi(argv[5]),stride=stoi(argv[6]);
 if(maxround<1||maxround>80||(direction!=2&&direction!=8&&direction!=32)||(stride!=8&&stride!=16&&stride!=32))throw runtime_error("region search envelope");
 vector<int>order(count);iota(order.begin(),order.end(),0);mt19937 rng(seed);shuffle(order.begin(),order.end(),rng);
 vector<uint32_t> use(size),history(size),mark(size);uint32_t epoch=0;BidirectionalSearch work(size);WeightedSettleState settled;RoutingCorridor corridor;
 auto d=[&](int u,int v){auto p=local(u),q=local(v);return abs(p[0]-q[0])+abs(p[1]-q[1])+abs(p[2]-q[2]);};
 bool okay=false;
 for(int r=0;r<maxround;++r){
  int weight=r<6?8:r<16?4:r<24?2:1;
  if(r){vector<int>scores(count);for(int n=0;n<count;++n)for(int v:trees[n])scores[n]+=max(0,int(use[v])-1);
    stable_sort(order.begin(),order.end(),[&](int a,int b){return scores[a]>scores[b];});}
  uint64_t attempts=0,patterns=0,coarses=0,refines=0,checks=0,expanded=0,zeros=0;
  for(int n:order){
   if(r&&all_of(trees[n].begin(),trees[n].end(),[&](int v){return use[v]<=1;}))continue;
   for(int v:trees[n]){if(!use[v])throw runtime_error("occupancy underflow");--use[v];}
   if(!++epoch)throw runtime_error("epoch wrap");
   auto& tree=trees[n];tree.clear();auto& br=branches[n];br.clear();
   auto add=[&](int v){if(mark[v]!=epoch){mark[v]=epoch;tree.push_back(v);}};
   add(ends[n][0]);br.push_back({ends[n][0]});
   auto allowed=[&](int v){return fixed[v]==-1||fixed[v]==n;};
   auto zero=[&](int v){return allowed(v)&&!use[v];};
   auto goal=[&](int v){return mark[v]==epoch;};
   auto cost=[&](int v){return int64_t(16+4*r)*use[v]+int64_t(history[v])*8;};
   for(size_t i=1;i<ends[n].size();++i){
    int start=ends[n][i];if(goal(start))continue;++attempts;
    int target=*min_element(tree.begin(),tree.end(),[&](int a,int b){return d(start,a)<d(start,b);});
    vector<int> path=ordinary_zero_pattern(nx,ny,start,tree,zero,goal,checks);if(!path.empty())++patterns;
    if(path.empty()){
     const auto free_cost=[&](int v){return int64_t(history[v])/8;};
     const uint64_t begin=settled.expanded,cap=20000+1500*r;
     path=settled_weighted_bidirectional(work,nx,ny,start,target,free_cost,[&](int v){return settled.expanded-begin<cap&&zero(v);},direction,16,settled);
     if(!path.empty())++zeros;
    }
    if(path.empty()){
     int bx=(n*7+seed*3+r*2)%stride,by=(n*11+seed*5+r*2)%stride;by=(by&~1)|(bx&1);
     path=ordinary_coarse_grid(nx,ny,start,target,stride,bx,by,weight,direction,cost,allowed,expanded,checks,65536,true,true);
     if(!path.empty()){
      ++coarses;
      if(any_of(path.begin(),path.end(),[&](int v){return use[v]!=0;})){
       corridor.build(nx,ny,path,4*(1+r/16));
       auto candidate=settled_weighted_bidirectional(work,nx,ny,start,target,cost,[&](int v){return allowed(v)&&corridor.contains(v);},direction,weight,settled);
       if(candidate.empty())throw runtime_error("coarse corridor lost its own path");
       path=move(candidate);++refines;
      }
     }
    }
    if(path.empty())path=settled_weighted_bidirectional(work,nx,ny,start,target,cost,allowed,direction,weight,settled);
    if(path.empty())throw runtime_error("actual region search disconnected: "+names[n]);
    auto end=find_if(path.begin(),path.end(),goal);if(end==path.end())throw runtime_error("missing tree connection");
    path.erase(end+1,path.end());for(int v:path)add(v);br.push_back(move(path));
   }
   for(int v:tree)++use[v];
  }
  uint64_t clashes=0,excess=0,occupied=0;
  for(int v=0;v<size;++v){if(use[v])++occupied;if(use[v]>1){++clashes;excess+=use[v]-1;history[v]+=use[v]-1;}}
  cout<<"{\"round\":"<<r<<",\"conflict_nodes\":"<<clashes<<",\"excess\":"<<excess<<",\"occupied\":"<<occupied<<",\"attempts\":"<<attempts<<",\"patterns\":"<<patterns<<",\"hard_zero\":"<<zeros<<",\"coarse\":"<<coarses<<",\"fine\":"<<refines<<"}"<<endl;
  if(!clashes){okay=true;break;}
 }
 if(!okay)throw runtime_error("region negotiation did not converge");
 ofstream out(argv[2]);out<<count<<'\n';
 for(int n=0;n<count;++n){out<<names[n]<<' '<<branches[n].size()<<'\n';for(auto& br:branches[n]){out<<br.size();for(int v:br){auto p=xy(v);out<<' '<<p[0]<<' '<<p[1]<<' '<<p[2];}out<<'\n';}}
 if(!out)throw runtime_error("output write");return 0;
 }catch(const std::exception& e){cerr<<e.what()<<endl;return 1;}
}
