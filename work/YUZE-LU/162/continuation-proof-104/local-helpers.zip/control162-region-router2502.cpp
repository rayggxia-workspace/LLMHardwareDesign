#include <algorithm>
#include <chrono>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <random>
#include <sstream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
struct Item {int64_t priority,cost;int node;bool operator<(const Item& q)const{
 if(priority!=q.priority)return priority>q.priority;
 // On an equal A* score, advance towards the existing tree rather than
 // expanding an arbitrary broad equal-score frontier. Physical checks stay
 // independent of this search-order decision.
 if(cost!=q.cost)return cost<q.cost;
 return node>q.node;
}};
// Optional exact two-ended search. Reverse edges charge the original
// destination vertex, and balanced Manhattan potentials make both reduced
// graphs nonnegative. This workspace is never used for finite wire budgets.
struct BidirectionalSearch {
 vector<int64_t>df,db;vector<uint32_t>vf,vb;vector<int>pf,pb;uint32_t epoch=0;
 explicit BidirectionalSearch(size_t size):df(size),db(size),vf(size),vb(size),pf(size),pb(size){}
 template<class Cost,class Allowed>
 vector<int>find(int nx,int ny,int start,int goal,Cost penalty,Allowed allowed,int nonpreferred_cost=2){
  if(nonpreferred_cost!=2&&nonpreferred_cost!=8&&nonpreferred_cost!=32)throw runtime_error("invalid bidirectional direction cost");
  int plane=nx*ny,size=2*plane;const int64_t inf=numeric_limits<int64_t>::max()/4;
  if(!++epoch)throw runtime_error("bidirectional epoch overflow");
  auto coord=[&](int v){return array<int,3>{v%nx,(v%plane)/nx,v/plane};};
  auto s=coord(start),g=coord(goal);
  auto potential=[&](int v){auto p=coord(v);return abs(p[0]-g[0])+abs(p[1]-g[1])-abs(p[0]-s[0])-abs(p[1]-s[1]);};
  priority_queue<Item>qf,qb;qf.push({0,0,start});qb.push({0,0,goal});
  vf[start]=vb[goal]=epoch;df[start]=db[goal]=0;int meeting=-1;int64_t best=inf;
  auto consider=[&](int v){if(vf[v]==epoch&&vb[v]==epoch&&df[v]+db[v]<best){best=df[v]+db[v];meeting=v;}};
  consider(start);
  while(true){
   while(!qf.empty()&&(vf[qf.top().node]!=epoch||df[qf.top().node]!=qf.top().priority))qf.pop();
   while(!qb.empty()&&(vb[qb.top().node]!=epoch||db[qb.top().node]!=qb.top().priority))qb.pop();
   if(qf.empty()||qb.empty())break;
   if(best!=inf&&qf.top().priority+qb.top().priority>=best)break;
   bool reverse=qb.top().priority<qf.top().priority;auto& q=reverse?qb:qf;
   auto& d=reverse?db:df;auto& seen=reverse?vb:vf;auto& parent=reverse?pb:pf;
   auto item=q.top();q.pop();int v=item.node;auto c=coord(v);int x=c[0],y=c[1],l=c[2];
   array<pair<int,int>,5>next{{{v-1,l==0?1:nonpreferred_cost},{v+1,l==0?1:nonpreferred_cost},{v-nx,l==1?1:nonpreferred_cost},{v+nx,l==1?1:nonpreferred_cost},{(1-l)*plane+y*nx+x,3}}};
   for(int i=0;i<5;++i){if(i==4&&(x+y)%2)continue;int w=next[i].first;if(w<0||w>=size)continue;auto p=coord(w);
    if(p[0]<4||p[0]>=nx-4||p[1]<4||p[1]>=ny-4||!allowed(w))continue;
    int64_t cost=next[i].second+penalty(reverse?v:w);
    __int128 reduced=__int128(2)*cost+(reverse?potential(v)-potential(w):potential(w)-potential(v));
    if(reduced<0||__int128(item.priority)+reduced>=inf)throw runtime_error("invalid reduced bidirectional cost");
    int64_t alt=item.priority+int64_t(reduced);
    // Reduced costs can be zero across an empty Manhattan rectangle. The
    // tie key is twice the original accumulated cost, rather than the
    // reduced cost, so equal-score searches advance instead of sweeping
    // that whole rectangle. Distances and termination use reduced costs.
    int64_t original=alt+(reverse?potential(w)-potential(goal):potential(start)-potential(w));
    if(seen[w]!=epoch||alt<d[w]){seen[w]=epoch;d[w]=alt;parent[w]=v;q.push({alt,original,w});consider(w);}
   }
  }
  if(meeting<0)return{};
  vector<int>path{meeting};while(path.back()!=start)path.push_back(pf[path.back()]);reverse(path.begin(),path.end());
  for(int v=meeting;v!=goal;){v=pb[v];path.push_back(v);}return path;
 }
};
#include "weighted_bidirectional.h"
#include "weighted_settled_bidirectional.h"

#include "ordinary_zero_pattern.h"
#include "ordinary_coarse_grid.h"
#include "routing_corridor.h"
int main(int argc,char**argv){try{
 if(argc!=7)throw runtime_error("region input output seed rounds direction stride");
 ifstream in(argv[1]);int x0,y0,x1,y1,blocked,count;in>>x0>>y0>>x1>>y1>>blocked>>count;
 if(!in||x1<x0||y1<y0||x1-x0>=1200||y1-y0>=1200||count<1||blocked<0)throw runtime_error("region envelope");
 const int ox=4+(x0+y0)%2,oy=4,nx=x1-x0+1+ox+4,ny=y1-y0+1+oy+4,plane=nx*ny,size=2*plane;
 auto pos=[&](int x,int y,int l){if(x<x0||x>x1||y<y0||y>y1||l<0||l>1)throw runtime_error("real point outside region");return (x-x0+ox)+nx*(y-y0+oy)+l*plane;};
 auto local=[&](int v){return array<int,3>{v%nx,(v%plane)/nx,v/plane};};
 auto xy=[&](int v){auto p=local(v);return array<int,3>{p[0]-ox+x0,p[1]-oy+y0,p[2]};};
 vector<int>fixed(size,-1);for(int v=0;v<size;++v){auto p=xy(v);if(p[0]<x0||p[0]>x1||p[1]<y0||p[1]>y1)fixed[v]=-2;}
 for(int i=0;i<blocked;++i){int x,y,l;in>>x>>y>>l;int v=pos(x,y,l);if(fixed[v]!=-1)throw runtime_error("duplicate native point");fixed[v]=-2;}
 vector<string> names(count);vector<vector<int>> ends(count),trees(count);vector<vector<vector<int>>> branches(count);
 for(int n=0;n<count;++n){int k;in>>names[n]>>k;if(k<1)throw runtime_error("empty ports");while(k--){int x,y,l;in>>x>>y>>l;int v=pos(x,y,l);if(fixed[v]!=-1)throw runtime_error("duplicate/blocked terminal");fixed[v]=n;ends[n].push_back(v);}}
 string trailing;if(in>>trailing)throw runtime_error("trailing region input");
 int seed=stoi(argv[3]),maxround=stoi(argv[4]),direction=stoi(argv[5]),stride=stoi(argv[6]);
 if(maxround<1||maxround>80||(direction!=2&&direction!=8&&direction!=32)||(stride!=8&&stride!=16&&stride!=32))throw runtime_error("region search envelope");

 vector<int>order(count);iota(order.begin(),order.end(),0);mt19937 rng(seed);shuffle(order.begin(),order.end(),rng);
 vector<int> use(size,-1);vector<uint32_t> history(size),mark(size);vector<int> strikes(count),last(count,-1000000);uint32_t epoch=0;
 BidirectionalSearch work(size);WeightedSettleState settled;
 auto d=[&](int u,int v){auto p=local(u),q=local(v);return abs(p[0]-q[0])+abs(p[1]-q[1])+abs(p[2]-q[2]);};
 auto diam=[&](int n){int z=0;for(int v:ends[n])z=max(z,d(v,ends[n][0]));return z;};
 stable_sort(order.begin(),order.end(),[&](int a,int b){return diam(a)>diam(b);});
 auto attempt=[&](int n,bool soft,int step)->bool{
  if(!++epoch)throw runtime_error("epoch wrap");
  auto& tree=trees[n];auto& br=branches[n];tree.clear();br.clear();
  auto add=[&](int v){if(mark[v]!=epoch){mark[v]=epoch;tree.push_back(v);}};
  auto allowed=[&](int v){return fixed[v]==-1||fixed[v]==n;};
  auto zero=[&](int v){return allowed(v)&&use[v]<0;};
  auto goal=[&](int v){return mark[v]==epoch;};
  auto cost=[&](int v){
   int k=use[v];return (k<0?0:int64_t(512+64*min(strikes[k],64)+(step-last[k]<48?2048:0)))+int64_t(history[v])/8;};
  vector<int> remaining=ends[n];int first=remaining[0];add(first);br.push_back({first});remaining.erase(remaining.begin());
  uint64_t checks=0;
  while(!remaining.empty()){
   int start=-1,target=-1,best=numeric_limits<int>::max();size_t which=0;
   for(size_t i=0;i<remaining.size();++i)for(int v:tree){int q=d(v,remaining[i]);if(q<best){best=q;start=remaining[i];target=v;which=i;}}
   remaining.erase(remaining.begin()+which);if(goal(start))continue;
   vector<int> path;
   if(!soft){
    path=ordinary_zero_pattern(nx,ny,start,tree,zero,goal,checks);
    if(path.empty()){
     uint64_t began=settled.expanded,limit=(step<count?60000:140000)+min(140000,250*strikes[n]);
     path=settled_weighted_bidirectional(work,nx,ny,start,target,cost,[&](int v){return settled.expanded-began<limit&&zero(v);},direction,16,settled);
    }
   }else path=settled_weighted_bidirectional(work,nx,ny,start,target,cost,allowed,direction,8,settled);
   if(path.empty()){tree.clear();br.clear();return false;}
   auto end=find_if(path.begin(),path.end(),goal);if(end==path.end())throw runtime_error("missing tree connection");
   path.erase(end+1,path.end());for(int v:path)add(v);br.push_back(move(path));
  }
  return true;
 };
 bool okay=false;int bestpending=count;int step=0,cycle=0;
 for(;cycle<maxround;++cycle){
  if(cycle){
   shuffle(order.begin(),order.end(),rng);
   stable_sort(order.begin(),order.end(),[&](int a,int b){return strikes[a]>strikes[b];});
  }
  int hard=0,soft=0,knock=0,skip=0;
  for(int n:order){
   if(!trees[n].empty())continue;++step;
   bool good=attempt(n,false,step);
   if(!good){
    if(!attempt(n,true,step)){++skip;continue;}
    vector<int> victim;for(int v:trees[n])if(use[v]>=0)victim.push_back(use[v]);
    sort(victim.begin(),victim.end());victim.erase(unique(victim.begin(),victim.end()),victim.end());
    if(int(victim.size())>min(8,2+cycle/8)||any_of(victim.begin(),victim.end(),[&](int k){return step-last[k]<3;})){
     trees[n].clear();branches[n].clear();++strikes[n];++skip;continue;
    }
    for(int v:trees[n])if(use[v]>=0)history[v]+=8;
    for(int k:victim){
     ++strikes[k];++knock;for(int v:trees[k]){if(use[v]!=k)throw runtime_error("owner");use[v]=-1;}
     trees[k].clear();branches[k].clear();
    }++soft;
   }else ++hard;
   for(int v:trees[n]){if(use[v]!=-1)throw runtime_error("conflict");use[v]=n;}
   last[n]=step;
  }
  int pending=0;for(auto& tree:trees)pending+=tree.empty();
  bestpending=min(bestpending,pending);
  cout<<"{\"cycle\":"<<cycle<<",\"unrouted\":"<<pending<<",\"best_unrouted\":"<<bestpending<<",\"zero_add\":"<<hard<<",\"displacing_add\":"<<soft<<",\"displaced\":"<<knock<<",\"skipped\":"<<skip<<"}"<<endl;
  if(!pending){okay=true;break;}
 }
 if(!okay)throw runtime_error("non-overlapping routing did not complete");
 ofstream out(argv[2]);out<<count<<'\n';
 for(int n=0;n<count;++n){out<<names[n]<<' '<<branches[n].size()<<'\n';for(auto& br:branches[n]){out<<br.size();for(int v:br){auto p=xy(v);out<<' '<<p[0]<<' '<<p[1]<<' '<<p[2];}out<<'\n';}}
 if(!out)throw runtime_error("output write");return 0;
 }catch(const std::exception& e){cerr<<e.what()<<endl;return 1;}
}
