from pathlib import Path
import hashlib,collections,json,heapq
b=Path(__file__).parent;inp=b/'control162-receive1988/input.txt';pr=b/'control162-oriented1998/prefix.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(inp)=='94dc48894b54cfd9ccb6533c72e32e35f0c5bad7be1186ab5b0c2ebec97aec37' and sha(pr)=='1e5577486391d8cc6a9e80b6be2434b5702652651396a191312abc07fd511371'
raw=inp.read_text().splitlines();h=list(map(int,raw[0].split()));nx,ny,n=h[:3];lock=h[6];plane=nx*ny
lands={};nets=[]
for j,ln in enumerate(raw[1:]):
 a=ln.split();pts=[int(a[i])+nx*int(a[i+1])for i in range(2,len(a)-1,2)]
 for p in pts:assert p not in lands;lands[p]=j
 nets.append((a[0],pts,int(a[-1])))
own={};trees={};slack={}
with pr.open()as f:
 assert int(f.readline())==lock
 for i,(n,ps,budget)in enumerate(nets[:lock]):
  m,k=f.readline().split();assert n==m;paths=[];edges=set()
  for _ in range(int(k)):
   r=list(map(int,f.readline().split()));v=[x+nx*y+plane*l for x,y,l in zip(r[1::3],r[2::3],r[3::3])]
   assert len(v)==r[0]
   for p in v:
    assert own.get(p,i)==i;own[p]=i
   edges.update(tuple(sorted((a,z)))for a,z in zip(v,v[1:])if a//plane==z//plane)
   paths.append(v)
  assert len(edges)<=budget
  trees[i]=paths;slack[i]=budget-len(edges)
assert len(own)==109862
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
def reached(start,who,r):
 x=start%nx;y=(start%plane)//nx;seen={start};q=[start];edges=set()
 for v in q:
  if max(abs(v%nx-x),abs((v%plane)//nx-y))>=r:return True,seen,edges
  for w in neighbors(v):
   if w in seen or lands.get(w,who)!=who:continue
   if w in own:edges.add(w);continue
   seen.add(w);q.append(w)
 return all(t in seen for t in nets[who][1]),seen,edges

original_prefix=pr
pr=b/'control162-native-repair2486/candidate.txt'
with pr.open()as f:
 assert int(f.readline())==lock
 own.clear();trees.clear();slack.clear()
 for j,(name,pins,cap) in enumerate(nets[:lock]):
  n,k=f.readline().split();assert name==n
  paths=[]
  for _ in range(int(k)):
   row=list(map(int,f.readline().split()));pts=[x+nx*y+plane*l for x,y,l in zip(row[1::3],row[2::3],row[3::3])]
   assert len(pts)==row[0];paths.append(pts)
   for v in pts:assert own.get(v,j)==j;own[v]=j
  trees[j]=paths
protected=set()
def xy(v):return v%nx,(v%plane)//nx,v//plane
def via(a,z):return a//plane!=z//plane
def edges(ps):return {tuple(sorted((u,v)))for u,v in zip(ps,ps[1:])if not via(u,v)}
def find_path(a,z,who,occupied,box,budget):
 x0,y0,x1,y1=box;goal=xy(z)
 def h(v):x,y,_=xy(v);return abs(x-goal[0])+abs(y-goal[1])
 if h(a)>budget:return None
 q=[(h(a),0,0,a)];dist={a:(0,0)};prev={};exp=0
 while q:
  _,wl,vi,u=heapq.heappop(q)
  if dist[u]!=(wl,vi):continue
  if u==z:
   p=[u]
   while u!=a:u=prev[u];p.append(u)
   p.reverse();return p
  exp+=1
  if exp>300000:return None
  for v in neighbors(u):
   x,y,l=xy(v)
   if not(x0<=x<=x1 and y0<=y<=y1)or v in protected or lands.get(v,who)!=who:continue
   if v!=z and v!=a and (v in occupied or own.get(v,who)!=who):continue
   w=(wl+int(not via(u,v)),vi+int(via(u,v)))
   f=w[0]+h(v)
   if f<=budget and w<dist.get(v,(10**9,10**9)):
    dist[v]=w;prev[v]=u;heapq.heappush(q,(f,w[0],w[1],v))
 return None

for j,paths in trees.items():slack[j]=nets[j][2]-sum(len(edges(r))for r in paths)
def attempt(who):
 name,pins,cap=nets[who];paths=trees[who]
 if len(pins)!=2 or len(paths)!=2:return None
 row=paths[-1];hit=[i for i,v in enumerate(row)if v in protected]
 if not hit:return None
 assert row[0]==pins[1] and row[-1]==pins[0]
 for gap,margin in [(2,3),(4,5),(8,8),(12,12),(20,16),(32,24),(48,32),(96,48),(4096,64)]:
  li=max(0,hit[0]-gap);ri=min(len(row)-1,hit[-1]+gap)
  a,z=row[li],row[ri];middle=row[li:ri+1];coords=[xy(v)for v in middle]
  remain=set(row[:li]+row[ri+1:])
  box=(max(4,min(x for x,y,l in coords)-margin),max(4,min(y for x,y,l in coords)-margin),min(nx-5,max(x for x,y,l in coords)+margin),min(ny-5,max(y for x,y,l in coords)+margin))
  result=find_path(a,z,who,remain,box,slack[who]+len(edges(middle)))
  if result:
   value=row[:li]+result+row[ri+1:];assert len(value)==len(set(value)) and len(edges(value))<=cap
   return value
 return None
def update(j,row):
 old=trees[j][-1]
 for v in old:assert own.pop(v)==j
 for v in row:assert v not in own;own[v]=j
 trees[j][-1]=row;slack[j]=nets[j][2]-len(edges(row))
def escape(p,j,avoids,mode):
 x,y,_=xy(p);q=[(0,0,p)];d={p:(0,0)};parent={}
 while q:
  c,l,u=heapq.heappop(q)
  if d[u]!=(c,l):continue
  xx,yy,_=xy(u)
  if max(abs(xx-x),abs(yy-y))>=4:
   path=[u]
   while u!=p:u=parent[u];path.append(u)
   return path
  for v in neighbors(u):
   if lands.get(v,j)!=j:continue
   owner=own.get(v)
   w=(c+avoids.get(v,0)+(0 if owner is None else 10+mode*max(0,20-slack[owner])),l+1)
   if w<d.get(v,(100000,100000)):
    d[v]=w;parent[v]=u;heapq.heappush(q,(*w,v))
 raise AssertionError('No real-landings-only escape')
def all_closed():
 return {(j,p)for j,(name,pins,_)in enumerate(nets)if j>=lock for p in pins if not reached(p,j,4)[0]}
closed=all_closed();assert len(closed)==5;results=[];failed={}
for sweep in range(8):
 progress=0
 for j,p in sorted(closed):
  if (j,p)not in closed:continue
  avoid=collections.Counter()
  for trial in range(120):
   path=escape(p,j,avoid,trial%3);protected=set(path);hits={own[v]for v in path if v in own}
   assert hits
   backup={k:trees[k][-1][:]for k in hits}
   okay=True;applied=[]
   for k in sorted(hits,key=lambda k:(slack[k],k),reverse=bool(trial%3)):
    new=attempt(k)
    if not new:okay=False;break
    update(k,new);applied.append(k)
   # Only pins within radius four of changed occupancy could change result.
   affected={(j,p)}
   if okay:
    changed=set()
    for k in applied:changed|=set(backup[k])^set(trees[k][-1])
    for v in changed:
     x,y,_=xy(v)
     for yy in range(max(4,y-4),min(ny-5,y+4)+1):
      for xx in range(max(4,x-4),min(nx-5,x+4)+1):
       w=xx+nx*yy;l=lands.get(w,-1)
       if l>=lock:affected.add((l,w))
    after={(i,w)for i,w in affected if not reached(w,i,4)[0]}
    if len(after)>=len(affected&closed) or (j,p)in after:okay=False
   if okay:
    before=len(closed);closed=(closed-affected)|after;progress+=1
    results.append(dict(sweep=sweep,net=nets[j][0],landing=p,trial=trial,native=[nets[k][0]for k in applied],newly_open=before-len(closed),left=len(closed)));print('repair',nets[j][0],trial,len(closed),flush=True)
    break
   for k in reversed(applied):update(k,backup[k])
   for v in path[1:]:
    avoid[v]+=4+int(v in own)*8
  else:failed[str((j,p))]=dict(net=nets[j][0],landing=p,attempts=120)
 if not progress:break
assert closed==all_closed()
o=b/'control162-native-repair2489';assert not o.exists();o.mkdir();f=o/'candidate.txt'
with f.open('w',encoding='ascii',newline=chr(10))as z:
 z.write(str(lock)+chr(10))
 for j,(name,ps,cap)in enumerate(nets[:lock]):
  paths=trees[j];z.write(name+' '+str(len(paths))+chr(10))
  for row in paths:z.write(str(len(row))+' '+' '.join(str(x)for v in row for x in xy(v))+chr(10))
r=dict(passed=True,route_qualified=False,whole_system_qualified=False,before_closed=5,remaining_closed=len(closed),iterations=results,remaining=[dict(net=nets[j][0],landing=p)for j,p in sorted(closed)],earlier_failed=failed,inputs={str(p):sha(p)for p in [inp,pr,original_prefix,Path(__file__)]},outputs={f.name:sha(f)},scope='Each individual escape repair retains original real landings, owner exclusions, finite wire bounds and no new local closures. Some blocked states may need simultaneous reroutes beyond this bounded probe; no qualification.')
(o/'receipt.json').write_text(json.dumps(r,indent=2));print(len(results),len(closed),r['remaining'])
