from pathlib import Path
import hashlib,collections,json,heapq
b=Path(__file__).parent;inp=b/'control162-receive1988/input.txt';pr=b/'control162-oriented1998/prefix.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(inp)=='94dc48894b54cfd9ccb6533c72e32e35f0c5bad7be1186ab5b0c2ebec97aec37' and sha(pr)=='1e5577486391d8cc6a9e80b6be2434b5702652651396a191312abc07fd511371'
raw=inp.read_text().splitlines();h=list(map(int,raw[0].split()));nx,ny,n=h[:3];lock=h[6];plane=nx*ny
lands={};nets=[]
for j,ln in enumerate(raw[1:]):
 a=ln.split();pts=[int(a[i])+nx*int(a[i+1])for i in range(2,len(a)-1,2)]
 for p in pts:assert p not in lands;lands[p]=j
 nets.append((a[0],pts,int(a[-1])))
own={};trees={};slack={}
with pr.open()as f:
 assert int(f.readline())==lock
 for i,(n,ps,budget)in enumerate(nets[:lock]):
  m,k=f.readline().split();assert n==m;paths=[];edges=set()
  for _ in range(int(k)):
   r=list(map(int,f.readline().split()));v=[x+nx*y+plane*l for x,y,l in zip(r[1::3],r[2::3],r[3::3])]
   assert len(v)==r[0]
   for p in v:
    assert own.get(p,i)==i;own[p]=i
   edges.update(tuple(sorted((a,z)))for a,z in zip(v,v[1:])if a//plane==z//plane)
   paths.append(v)
  assert len(edges)<=budget
  trees[i]=paths;slack[i]=budget-len(edges)
assert len(own)==109862
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
def reached(start,who,r):
 x=start%nx;y=(start%plane)//nx;seen={start};q=[start];edges=set()
 for v in q:
  if max(abs(v%nx-x),abs((v%plane)//nx-y))>=r:return True,seen,edges
  for w in neighbors(v):
   if w in seen or lands.get(w,who)!=who:continue
   if w in own:edges.add(w);continue
   seen.add(w);q.append(w)
 return all(t in seen for t in nets[who][1]),seen,edges

original_prefix=pr
pr=b/'control162-native-repair2489/candidate.txt'
with pr.open()as f:
 assert int(f.readline())==lock
 own.clear();trees.clear();slack.clear()
 for j,(name,pins,cap) in enumerate(nets[:lock]):
  n,k=f.readline().split();assert name==n
  paths=[]
  for _ in range(int(k)):
   row=list(map(int,f.readline().split()));pts=[x+nx*y+plane*l for x,y,l in zip(row[1::3],row[2::3],row[3::3])]
   assert len(pts)==row[0];paths.append(pts)
   for v in pts:assert own.get(v,j)==j;own[v]=j
  trees[j]=paths
protected=set()
def xy(v):return v%nx,(v%plane)//nx,v//plane
def via(a,z):return a//plane!=z//plane
def edges(ps):return {tuple(sorted((u,v)))for u,v in zip(ps,ps[1:])if not via(u,v)}
def find_path(a,z,who,occupied,box,budget):
 x0,y0,x1,y1=box;goal=xy(z)
 def h(v):x,y,_=xy(v);return abs(x-goal[0])+abs(y-goal[1])
 if h(a)>budget:return None
 q=[(h(a),0,0,a)];dist={a:(0,0)};prev={};exp=0
 while q:
  _,nw,vi,u=heapq.heappop(q);wl=-nw
  if dist[u]!=(wl,vi):continue
  if u==z:
   p=[u]
   while u!=a:u=prev[u];p.append(u)
   p.reverse();return p
  exp+=1
  if exp>180000:return None
  for v in neighbors(u):
   x,y,l=xy(v)
   if not(x0<=x<=x1 and y0<=y<=y1)or v in protected or lands.get(v,who)!=who:continue
   if v!=z and v!=a and (v in occupied or own.get(v,who)!=who):continue
   w=(wl+int(not via(u,v)),vi+int(via(u,v)))
   f=w[0]+h(v)
   if f<=budget and w<dist.get(v,(10**9,10**9)):
    dist[v]=w;prev[v]=u;heapq.heappush(q,(f,-w[0],w[1],v))
 return None

for j,paths in trees.items():slack[j]=nets[j][2]-sum(len(edges(r))for r in paths)
def attempt(who):
 name,pins,cap=nets[who];paths=trees[who]
 if len(pins)!=2 or len(paths)!=2:return None
 row=paths[-1];hit=[i for i,v in enumerate(row)if v in protected]
 if not hit:return None
 assert row[0]==pins[1] and row[-1]==pins[0]
 for gap,margin in [(2,3),(4,5),(8,8),(12,12),(20,16),(32,24),(48,32),(96,48),(4096,64)]:
  li=max(0,hit[0]-gap);ri=min(len(row)-1,hit[-1]+gap)
  a,z=row[li],row[ri];middle=row[li:ri+1];coords=[xy(v)for v in middle]
  remain=set(row[:li]+row[ri+1:])
  box=(max(4,min(x for x,y,l in coords)-margin),max(4,min(y for x,y,l in coords)-margin),min(nx-5,max(x for x,y,l in coords)+margin),min(ny-5,max(y for x,y,l in coords)+margin))
  result=find_path(a,z,who,remain,box,slack[who]+len(edges(middle)))
  if result:
   value=row[:li]+result+row[ri+1:];assert len(value)==len(set(value)) and len(edges(value))<=cap
   return value
 return None
def update(j,row):
 old=trees[j][-1]
 for v in old:assert own.pop(v)==j
 for v in row:assert v not in own;own[v]=j
 trees[j][-1]=row;slack[j]=nets[j][2]-len(edges(row))
def escape(p,j,avoids,mode):
 x,y,_=xy(p);q=[(0,0,p)];d={p:(0,0)};parent={}
 while q:
  c,l,u=heapq.heappop(q)
  if d[u]!=(c,l):continue
  xx,yy,_=xy(u)
  if max(abs(xx-x),abs(yy-y))>=4:
   path=[u]
   while u!=p:u=parent[u];path.append(u)
   return path
  for v in neighbors(u):
   if lands.get(v,j)!=j:continue
   owner=own.get(v)
   w=(c+(0 if owner is None else 10+avoids.get(v,0)+mode*max(0,10-slack[owner])),l+1)
   if w<d.get(v,(100000,100000)):
    d[v]=w;parent[v]=u;heapq.heappush(q,(*w,v))
 raise AssertionError('No real-landings-only escape')
def all_closed():
 return {(j,p)for j,(name,pins,_)in enumerate(nets)if j>=lock for p in pins if not reached(p,j,4)[0]}

import random
closed=all_closed();assert len(closed)==1
j,p=next(iter(closed));rng=random.Random(1622493);avoid=collections.Counter()
old_distance={}
for q in range(500):
 path=escape(p,j,avoid,q%2);protected=set(path);hits={own[v]for v in path if v in own}
 x,y,_=xy(p)
 cand=collections.Counter(own[v] for l in range(2) for yy in range(y-7,y+8)for xx in range(x-7,x+8)if (v:=xx+nx*yy+plane*l)in own and len(trees[own[v]])==2 and len(nets[own[v]][1])==2)
 c=[k for k,v in cand.most_common(20)if k not in hits]
 selected=list(hits)+rng.sample(c,min(len(c),q%5))
 backup={k:trees[k][-1][:]for k in selected}
 for k,row in backup.items():
  for v in row:assert own.pop(v)==k
 order=list(selected);rng.shuffle(order)
 rows={}
 for k in order:
  old=backup[k];a,z=old[0],old[-1];pts=[xy(v)for v in old]
  # Local segment first, preserving existing ends and distant wiring.
  touch=[i for i,v in enumerate(old)if max(abs(xy(v)[0]-x),abs(xy(v)[1]-y))<=7]
  res=None
  if touch:
   for gap,margin in [(3,4),(8,8),(18,16),(40,32),(4096,48)]:
    li=max(0,touch[0]-gap);ri=min(len(old)-1,touch[-1]+gap)
    fixed=old[:li]+old[ri+1:]
    if any(v in protected or v in own for v in fixed):continue
    coords=pts[li:ri+1];box=(max(4,min(v[0]for v in coords)-margin),max(4,min(v[1]for v in coords)-margin),min(nx-5,max(v[0]for v in coords)+margin),min(ny-5,max(v[1]for v in coords)+margin))
    new=find_path(old[li],old[ri],k,set(fixed),box,slack[k]+len(edges(old[li:ri+1])))
    if new:
     res=old[:li]+new+old[ri+1:];break
  if not res:break
  assert len(res)==len(set(res)) and len(edges(res))<=nets[k][2] and not set(res)&protected
  for v in res:assert v not in own;own[v]=k
  rows[k]=res
 if len(rows)==len(order) and not all_closed():
  for k,row in rows.items():trees[k][-1]=row
  print('solved',q,[nets[k][0]for k in order],flush=True);break
 for k,row in rows.items():
  for v in row:assert own.pop(v)==k
 for k,row in backup.items():
  for v in row:assert v not in own;own[v]=k
 for v in path[1:]:avoid[v]+=3+int(v in own)*6
 if q%30==29:
  print('attempt',q+1,flush=True)
  avoid=collections.Counter()
else:
 print('bounded repair failed',flush=True);raise SystemExit(2)
out=b/'control162-native-repair2493';out.mkdir()
f=out/'candidate.txt'
with f.open('x',encoding='ascii',newline=chr(10))as z:
 z.write(str(lock)+chr(10))
 for k,(name,ps,cap)in enumerate(nets[:lock]):
  paths=trees[k];z.write(name+' '+str(len(paths))+chr(10))
  for row in paths:z.write(str(len(row))+' '+' '.join(str(x)for v in row for x in xy(v))+chr(10))
(out/'receipt.json').write_text(json.dumps(dict(passed=True,route_qualified=False,whole_system_qualified=False,closed=0,attempt=q,net=nets[j][0],changed=[nets[k][0]for k in order],inputs={str(v):sha(v)for v in [inp,pr,original_prefix,Path(__file__)]},output_sha256=sha(f)),indent=2))
