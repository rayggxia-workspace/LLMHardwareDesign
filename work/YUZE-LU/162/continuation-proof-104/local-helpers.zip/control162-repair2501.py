from pathlib import Path
import hashlib,collections,json,heapq
b=Path(__file__).parent;inp=b/'control162-receive1988/input.txt';pr=b/'control162-oriented1998/prefix.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(inp)=='94dc48894b54cfd9ccb6533c72e32e35f0c5bad7be1186ab5b0c2ebec97aec37' and sha(pr)=='1e5577486391d8cc6a9e80b6be2434b5702652651396a191312abc07fd511371'
raw=inp.read_text().splitlines();h=list(map(int,raw[0].split()));nx,ny,n=h[:3];lock=h[6];plane=nx*ny
lands={};nets=[]
for j,ln in enumerate(raw[1:]):
 a=ln.split();pts=[int(a[i])+nx*int(a[i+1])for i in range(2,len(a)-1,2)]
 for p in pts:assert p not in lands;lands[p]=j
 nets.append((a[0],pts,int(a[-1])))
own={};trees={};slack={}
with pr.open()as f:
 assert int(f.readline())==lock
 for i,(n,ps,budget)in enumerate(nets[:lock]):
  m,k=f.readline().split();assert n==m;paths=[];edges=set()
  for _ in range(int(k)):
   r=list(map(int,f.readline().split()));v=[x+nx*y+plane*l for x,y,l in zip(r[1::3],r[2::3],r[3::3])]
   assert len(v)==r[0]
   for p in v:
    assert own.get(p,i)==i;own[p]=i
   edges.update(tuple(sorted((a,z)))for a,z in zip(v,v[1:])if a//plane==z//plane)
   paths.append(v)
  assert len(edges)<=budget
  trees[i]=paths;slack[i]=budget-len(edges)
assert len(own)==109862
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
def reached(start,who,r):
 x=start%nx;y=(start%plane)//nx;seen={start};q=[start];edges=set()
 for v in q:
  if max(abs(v%nx-x),abs((v%plane)//nx-y))>=r:return True,seen,edges
  for w in neighbors(v):
   if w in seen or lands.get(w,who)!=who:continue
   if w in own:edges.add(w);continue
   seen.add(w);q.append(w)
 return all(t in seen for t in nets[who][1]),seen,edges

original_prefix=pr
pr=b/'control162-native-repair2493/candidate.txt'
with pr.open()as f:
 assert int(f.readline())==lock
 own.clear();trees.clear();slack.clear()
 for j,(name,pins,cap) in enumerate(nets[:lock]):
  n,k=f.readline().split();assert name==n
  paths=[]
  for _ in range(int(k)):
   row=list(map(int,f.readline().split()));pts=[x+nx*y+plane*l for x,y,l in zip(row[1::3],row[2::3],row[3::3])]
   assert len(pts)==row[0];paths.append(pts)
   for v in pts:assert own.get(v,j)==j;own[v]=j
  trees[j]=paths
protected=set()
def xy(v):return v%nx,(v%plane)//nx,v//plane
def via(a,z):return a//plane!=z//plane
def edges(ps):return {tuple(sorted((u,v)))for u,v in zip(ps,ps[1:])if not via(u,v)}
def find_path(a,z,who,occupied,box,budget):
 x0,y0,x1,y1=box;goal=xy(z)
 def h(v):x,y,_=xy(v);return abs(x-goal[0])+abs(y-goal[1])
 if h(a)>budget:return None
 q=[(h(a),0,0,a)];dist={a:(0,0)};prev={};exp=0
 while q:
  _,nw,vi,u=heapq.heappop(q);wl=-nw
  if dist[u]!=(wl,vi):continue
  if u==z:
   p=[u]
   while u!=a:u=prev[u];p.append(u)
   p.reverse();return p
  exp+=1
  if exp>110000:return None
  for v in neighbors(u):
   x,y,l=xy(v)
   if not(x0<=x<=x1 and y0<=y<=y1)or v in protected or lands.get(v,who)!=who:continue
   if v!=z and v!=a and (v in occupied or own.get(v,who)!=who):continue
   w=(wl+int(not via(u,v)),vi+int(via(u,v)))
   f=w[0]+h(v)
   if f<=budget and w<dist.get(v,(10**9,10**9)):
    dist[v]=w;prev[v]=u;heapq.heappush(q,(f,-w[0],w[1],v))
 return None

for j,paths in trees.items():slack[j]=nets[j][2]-sum(len(edges(r))for r in paths)
def attempt(who):
 name,pins,cap=nets[who];paths=trees[who]
 if len(pins)!=2 or len(paths)!=2:return None
 row=paths[-1];hit=[i for i,v in enumerate(row)if v in protected]
 if not hit:return None
 assert row[0]==pins[1] and row[-1]==pins[0]
 for gap,margin in [(2,3),(4,5),(8,8),(12,12),(20,16),(32,24),(48,32),(96,48),(4096,64)]:
  li=max(0,hit[0]-gap);ri=min(len(row)-1,hit[-1]+gap)
  a,z=row[li],row[ri];middle=row[li:ri+1];coords=[xy(v)for v in middle]
  remain=set(row[:li]+row[ri+1:])
  box=(max(4,min(x for x,y,l in coords)-margin),max(4,min(y for x,y,l in coords)-margin),min(nx-5,max(x for x,y,l in coords)+margin),min(ny-5,max(y for x,y,l in coords)+margin))
  result=find_path(a,z,who,remain,box,slack[who]+len(edges(middle)))
  if result:
   value=row[:li]+result+row[ri+1:];assert len(value)==len(set(value)) and len(edges(value))<=cap
   return value
 return None
def update(j,row):
 old=trees[j][-1]
 for v in old:assert own.pop(v)==j
 for v in row:assert v not in own;own[v]=j
 trees[j][-1]=row;slack[j]=nets[j][2]-len(edges(row))
def escape(p,j,avoids,mode):
 x,y,_=xy(p);q=[(0,0,p)];d={p:(0,0)};parent={}
 while q:
  c,l,u=heapq.heappop(q)
  if d[u]!=(c,l):continue
  xx,yy,_=xy(u)
  if max(abs(xx-x),abs(yy-y))>=4:
   path=[u]
   while u!=p:u=parent[u];path.append(u)
   return path
  for v in neighbors(u):
   if lands.get(v,j)!=j:continue
   owner=own.get(v)
   w=(c+(0 if owner is None else 10+avoids.get(v,0)+mode*max(0,10-slack[owner])),l+1)
   if w<d.get(v,(100000,100000)):
    d[v]=w;parent[v]=u;heapq.heappush(q,(*w,v))
 raise AssertionError('No real-landings-only escape')
def all_closed():
 return {(j,p)for j,(name,pins,_)in enumerate(nets)if j>=lock for p in pins if not reached(p,j,4)[0]}

import random,subprocess,time
rng=random.Random(1622499);out=b/'control162-native-repair2501';out.mkdir();exe=b/'control162-connect2498.exe'
def audit(seq):
 stamp=out/str(seq);stamp.mkdir()
 inp=stamp/'ordinary-connectivity.txt';mp=stamp/'main.mask'
 with inp.open('x',newline=chr(10))as f:
  f.write(f'4 4 {nx-5} {ny-5} {len(own)} {len(nets)-lock}'+chr(10))
  for v in own:f.write(' '.join(map(str,xy(v)))+chr(10))
  for name,ps,cap in nets[lock:]:f.write(name+' '+str(len(ps))+' '+' '.join(str(t)for v in ps for t in xy(v))+chr(10))
 q=subprocess.run([str(exe),str(inp),str(mp)],capture_output=True,text=True)
 assert q.returncode in (0,2),q.stderr
 (stamp/'connect.log').write_text(q.stdout)
 names={name:k for k,(name,ps,cap)in enumerate(nets)}
 closed={}
 for row in q.stdout.splitlines():
  if not row.startswith('isolated '):continue
  _,name,x,y,l,*rest=row.split();v=int(x)+nx*int(y)+plane*int(l);closed[(names[name],v)]=rest
 # Keep exact audit logs in all cases, and only the current binary mask.
 mask=mp.read_bytes();assert len(mask)==2*(nx-8)*(ny-8);mp.unlink();inp.unlink()
 return closed,mask,stamp
def output(target):
 with target.open('x',encoding='ascii',newline=chr(10))as z:
  z.write(str(lock)+chr(10))
  for k,(name,ps,cap)in enumerate(nets[:lock]):
   paths=trees[k];z.write(name+' '+str(len(paths))+chr(10))
   for row in paths:z.write(str(len(row))+' '+' '.join(str(x)for v in row for x in xy(v))+chr(10))
def route_escape(p,j,avoids,mode,mask):
 q=[(0,0,p)];dist={p:(0,0)};parent={}
 while q:
  c,l,u=heapq.heappop(q)
  if dist[u]!=(c,l):continue
  x,y,z=xy(u);i=(x-4)+(nx-8)*(y-4)+(nx-8)*(ny-8)*z
  if mask[i]:
   path=[u]
   while u!=p:u=parent[u];path.append(u)
   return path
  if l>50:continue
  for v in neighbors(u):
   if lands.get(v,j)!=j:continue
   owner=own.get(v)
   w=c+avoids.get(v,0)+(0 if owner is None else 10+mode*max(0,20-slack[owner])),l+1
   if w<dist.get(v,(1000000,1000000)):
    dist[v]=w;parent[v]=u;heapq.heappush(q,(*w,v))
 return None
i=0;closed,mask,_=audit(i);assert len(closed)==75;results=[]
for sweep in range(6):
 changed=0
 for j,p in list(closed):
  if (j,p)not in closed:continue
  avoids=collections.Counter()
  for trial in range(38):
   path=route_escape(p,j,avoids,trial%3,mask)
   if path is None:break
   protected=set(path);hits={own[v]for v in path if v in own}
   if not hits:break
   if any(len(nets[k][1])!=2 or len(trees[k])!=2 for k in hits):
    for v in path:
     if v in own:avoids[v]+=20
    continue
   selected=list(hits)
   if trial%4==3:
    xx,yy,_=xy(p)
    neighbors2=collections.Counter(own[w]for l in range(2)for y in range(yy-8,yy+9)for x in range(xx-8,xx+9)if(w:=x+nx*y+l*plane)in own and own[w]not in hits and len(trees[own[w]])==2)
    pool=[k for k,v in neighbors2.most_common(12)];selected+=rng.sample(pool,min(len(pool),1+trial%3))
   backup={k:trees[k][-1][:]for k in selected}
   for k,row in backup.items():
    for v in row:assert own.pop(v)==k
   order=sorted(selected,key=lambda k:(slack[k],k))
   if trial%3==1:order.reverse()
   if trial%3==2:rng.shuffle(order)
   rows={};xxx,yyy,_=xy(p)
   for k in order:
    old=backup[k];pts=[xy(v)for v in old]
    touch=[l for l,v in enumerate(old)if v in protected or (max(abs(pts[l][0]-xxx),abs(pts[l][1]-yyy))<=8 and k not in hits)]
    if not touch:break
    for gap,margin in [(2,4),(5,7),(10,12),(24,24),(48,36),(4096,56)]:
     li=max(0,touch[0]-gap);ri=min(len(old)-1,touch[-1]+gap);fixed=old[:li]+old[ri+1:]
     if any(v in protected or v in own for v in fixed):continue
     coords=pts[li:ri+1];box=(max(4,min(v[0]for v in coords)-margin),max(4,min(v[1]for v in coords)-margin),min(nx-5,max(v[0]for v in coords)+margin),min(ny-5,max(v[1]for v in coords)+margin))
     new=find_path(old[li],old[ri],k,set(fixed),box,slack[k]+len(edges(old[li:ri+1])))
     if new:
      row=old[:li]+new+old[ri+1:];assert len(row)==len(set(row)) and len(edges(row))<=nets[k][2]and not set(row)&protected
      for v in row:assert v not in own;own[v]=k
      rows[k]=row;break
    if k not in rows:break
   if len(rows)==len(order):
    i+=1;after,new_mask,stamp=audit(i)
    if len(after)<len(closed) and (j,p)not in after:
     for k,row in rows.items():trees[k][-1]=row;slack[k]=nets[k][2]-len(edges(row))
     closed=after;mask=new_mask;changed+=1
     result=dict(sweep=sweep,attempt=trial,audit=i,net=nets[j][0],point=xy(p),closed=len(closed),changed=[nets[k][0]for k in order])
     results.append(result);print(result,flush=True);output(stamp/'candidate.txt');break
   for k,row in rows.items():
    for v in row:assert own.pop(v)==k
   for k,row in backup.items():
    for v in row:assert v not in own;own[v]=k
   for v in path[:-1]:avoids[v]+=2+int(v in own)*8
 if not closed or not changed:break
target=out/'candidate.txt';output(target)
(out/'receipt.json').write_text(json.dumps(dict(passed=not closed,route_qualified=False,whole_system_qualified=False,exact_closed=len(closed),remaining=[(nets[j][0],xy(v),s)for(j,v),s in closed.items()],results=results,output_sha256=sha(target),inputs={str(v):sha(v)for v in [inp,pr,exe,Path(__file__)]}),indent=2))
