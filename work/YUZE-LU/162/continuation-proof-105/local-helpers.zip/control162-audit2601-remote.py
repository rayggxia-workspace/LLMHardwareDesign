
from pathlib import Path
import hashlib,json,tarfile,subprocess,time,sys
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-2573';new=b/'source-2587'
out=b/'r256-ordinary-access-source-audit-2601';assert not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=new/'source-manifest.json';prev=old/'source-manifest.json'
a=json.loads(prev.read_text());z=json.loads(manifest.read_text())
meta=b/'control162-archive2587.json';m=json.loads(meta.read_text())
changed={'project/experiments/control_v1/'+n for n in ['tree_router.cpp']}
assert z['commit']==m['commit'] and len(a['files'])==len(z['files'])==1030 and set(a['files'])==set(z['files'])
assert {n for n,v in z['files'].items() if a['files'][n]!=v}==changed==set(m['changed_files'])
for n,v in z['files'].items():assert sha(new/n)==v
archive=b/'source2587.tar.gz';freeze=new/'freeze-import.json';fz=json.loads(freeze.read_text())
assert sha(archive)==m['archive_sha256']==fz['archive_sha256']and fz['hardlinked_immutable_files']==1029
with tarfile.open(str(archive))as f:
 members={m.name:f.extractfile(m).read()for m in f.getmembers()}
 assert set(members)==set(z['files'])|{'source-manifest.json'}
 assert all(hashlib.sha256(members[n]).hexdigest()==v for n,v in z['files'].items())
patch=b/'control162-backout2587.patch';assert sha(patch)==m['patch_sha256']
out.mkdir();scratch=out/'reverse-copies'
for n in changed:
 p=scratch/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/n).read_bytes())
subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True)
subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/n).read_bytes()==(old/n).read_bytes()for n in changed)
contract=b/'control162-contract2587.json';c=json.loads(contract.read_text())
assert c['passed'] and c['commit']==z['commit'] and all(c['regression'][k] for k in ('old_reproduced_exact_error','fixed_zero_conflicts','all_selected_edges_present','disabled_output_and_stdout_exact'))
assert all(sha(new/'project/experiments/control_v1'/n)==v for n,v in c['source_sha256'].items())

data=b/'r256-ordinary-access-data-2600';data_receipt=data/'receipt.json';d=json.loads(data_receipt.read_text())
proof=data/'window-validation.json';p=json.loads(proof.read_text())
assert d['passed'] and not d['route_qualified'] and d['critical_nets']==1229 and d['native_overlap']==0 and d['all_native_wire_budgets_verified']
assert d['stubs']==115 and d['region_case892_available']==115 and d['region_case892_required']==115
assert sha(proof)==d['source_validation_sha256'] and p['passed'] and not p['route_qualified']
native=data/'prefix.txt';stubs=data/'stubs.txt'
assert sha(native)==d['prefix_sha256'] and sha(stubs)==d['stubs_sha256']
origin=b/'r256-current-prefix-data-1999/config.json';oc=json.loads(origin.read_text());inp=Path(oc['input'])
assert sha(inp)==oc['input_sha256']==d['input_sha256']
h,body=inp.read_bytes().split(b'\n',1);hd=list(map(int,h.split()))
assert hd[:3]==[3070,3252,11149] and hd[6]==1229 and int(native.open().readline())==1229 and int(stubs.open().readline())==115
joint=data/'one-native-joint.json';j=json.loads(joint.read_text());assert sha(joint)==d['joint_validation_sha256'] and j['passed'] and j['best']==0 and j['names']==['net_7869'] and j['prefix_sha256']==sha(native)
static=data/'static-validation.json';st=json.loads(static.read_text());assert sha(static)==d['static_validation_sha256'] and st['cases']['115']['disconnected']==d['isolated_true_landings_or_stub_vertices']==0 and st['real_net_input_sha']==d['input_sha256'] and sha(stubs) in st['cases']['115']['sources'].values()
config=data/'native.json';access=data/'access.json';assert not config.exists() and not access.exists()
config.write_text(json.dumps(dict(prefix=str(native),prefix_sha256=sha(native),input=str(inp),input_sha256=sha(inp)),indent=2))
access.write_text(json.dumps(dict(paths=str(stubs),paths_sha256=sha(stubs),native_prefix_sha256=sha(native),input_sha256=sha(inp)),indent=2))
r=dict(passed=True,whole_system_qualified=False,source_commit=z['commit'],source_files=1030,unchanged=1029,reverse_exact=True,
 original_grid_vertices=19866256,critical_paths=1229,access_stubs=115,available_cut892=115,required_cut892=115,isolated_global_vertices=0,
 inputs={str(x):sha(x)for x in [manifest,archive,freeze,patch,contract,config,access,data_receipt,proof,joint,static,native,stubs,inp,origin]},
 case964=dict(available=d['region_case964_available'],required=d['region_case964_required']),scope='Original full physical gates unchanged. All1030 immutable sources exact with reverse check; actual current geometry/input/prevalidated budgeted native seed and 115 true access stubs. Actual C++/Python full search and independent downstream verification remain mandatory.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,source=z['commit'],stubs=115,critical_paths=1229)))
