from pathlib import Path
import hashlib,json,subprocess,collections,time
b=Path.cwd();out=b/'control162-dual-window2591';out.mkdir()
s=b/'control162-receive1988/input.txt';a=b/'control162-ordinary-access-data2588';native=a/'prefix.txt';stub=a/'stubs.txt';solver=b/'control162-exit-distinct2529.exe'
def parse(a):
 a=list(map(int,a));assert len(a)%3==0
 return list(zip(a[::3],a[1::3],a[2::3]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with s.open()as f:
 h=list(map(int,f.readline().split()));nn=h[6];nets={};own={}
 for line in f:
  n,k,*r=line.split();r=list(map(int,r));q=list(zip(r[:-1:2],r[1:-1:2],[0]*int(k)));assert len(q)==int(k)
  nets[n]=(q,r[-1])
  for p in q:assert p not in own;own[p]=n
with stub.open()as f:
 expected=int(f.readline());ps={}
 for line in f:
  n,k,*r=line.split();p=parse(r);assert len(p)==int(k)and own[p[0]]==n;ps[n]=p
 assert len(ps)==expected==115
occ={}
with native.open()as f:
 assert int(f.readline())==nn
 for name in list(nets)[:nn]:
  n,k=f.readline().split();assert n==name
  for i in range(int(k)):
   size,*a=f.readline().split();p=parse(a);assert len(p)==int(size)
   for v in p:assert occ.setdefault(v,n)==n
guard={v:n for n,p in ps.items()for v in p};assert len(guard)==sum(map(len,ps.values())) and not set(occ)&set(guard)
case=b/'control162-exit-flow-cases2514/964-ordinary.input'
x,y,xx,yy,*_=map(int,case.read_text().splitlines()[0].split())
inside=lambda v:x<=v[0]<=xx and y<=v[1]<=yy
boundary=lambda v:v[0]in (x,xx)or v[1]in (y,yy)
request={};witness={}
for n,(p,budget) in nets.items():
 if budget>=0 or not any(map(inside,p))or all(map(inside,p)):continue
 old=ps.get(n)
 if old and inside(old[0])and any(boundary(v) for v in old):
  witness[n]=old;continue
 for v in p:
  if not inside(v):continue
  start=old[-1]if old and old[0]==v else v
  assert inside(start);request[n+'__'+'_'.join(map(str,start))]=(n,start,start!=v)
assert len(witness)+len({n for n,p,c in request.values()})==129
protected={v for v in own if inside(v)}|{v for v in guard if inside(v)}
pressure=out/'native.txt'
with pressure.open('x',newline=chr(10))as f:
 for v in sorted(v for v in occ if inside(v)):print(*v,file=f)
summary={}
for tag,block,penalty in [('without_native_relaxed',protected,500),('fixed_native_exact',protected|{v for v in occ if inside(v)},500)]:
 i=out/(tag+'.input');r=out/(tag+'.paths')
 with i.open('x',newline=chr(10))as f:
  print(x,y,xx,yy,len(block),len(request),file=f)
  for v in sorted(block):print(*v,file=f)
  for key,(_,v,_)in request.items():print(key,*v,file=f)
 e=subprocess.run([str(solver),str(i),str(r),str(pressure),str(penalty)],capture_output=True,timeout=90);(out/(tag+'.log')).write_bytes(e.stdout+e.stderr);assert e.returncode==0,e.stderr
 used=set();overlaps=collections.Counter();selected={}
 with r.open()as f:
  need,got=map(int,f.readline().split());assert need+len(witness)==129
  for line in f:
   key,k,*a=line.split();n,start,continuation=request[key];p=parse(a)
   assert p[0]==start and len(set(p))==len(p)==int(k) and not block.intersection(p[1:]) and not used.intersection(p)
   assert boundary(p[-1]) and all(inside(v)for v in p)
   assert all(sum(abs(v-w)for v,w in zip(a,c))==1 and (a[2]==c[2]or not(a[0]+a[1])%2)for a,c in zip(p,p[1:]))
   assert n not in selected;selected[n]=(continuation,p);used.update(p);overlaps.update(occ[v]for v in p if v in occ)
 assert len(selected)==got
 if tag=='without_native_relaxed':
  combined=list(ps.items())
  for n,(join,p)in selected.items():
   if join:
    idx=next(i for i,(name,path)in enumerate(combined)if name==n and path[-1]==p[0]);combined[idx]=(n,combined[idx][1]+p[1:])
   else:combined.append((n,p))
  guard2=set();starts=set()
  for n,p in combined:
   assert own[p[0]]==n and p[0] not in starts and not guard2.intersection(p);starts.add(p[0]);guard2.update(p)
  f=out/'combined-diagnostic.txt'
  with f.open('x',newline=chr(10))as fo:
   print(len(combined),file=fo)
   for n,p in combined:print(n,len(p),*(v for pt in p for v in pt),file=fo)
 summary[tag]=dict(required=129,prior_witness=len(witness),new=got,total=got+len(witness),native_overlap=sum(overlaps.values()),native_nets=dict(overlaps),paths_sha256=sha(r))
 print(tag,summary[tag],flush=True)
(out/'receipt.json').write_text(json.dumps(dict(passed=True,route_qualified=False,whole_system_qualified=False,results=summary,inputs={str(f):sha(f) for f in [s,native,stub,case,solver,Path(__file__)]}),indent=2))
