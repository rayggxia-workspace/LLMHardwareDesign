from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();d=root/'control162-escape-layer-regression2586';d.mkdir()
def save(n,s):
 p=d/n;p.open('x',newline='\n').write(s);return p
native=save('native.txt','1\nnet_0 2\n1 5 6 0\n4 8 6 0 7 6 0 6 6 0 5 6 0\n')
nets=['net_0 2 5 6 8 6 12','net_1 2 34 9 9 9 -1'];stubs=['net_1 3 9 9 0 9 9 1 10 9 1']
for x,gap in [(14,9),(22,23),(30,11)]:
 for j,k in [(4,gap),(gap+1,36)]:
  assert j%2==0
  net='net_'+str(len(nets));ps=[(x,y)for y in range(j,k)]
  nets.append(' '.join(map(str,[net,len(ps),*(v for p in ps for v in p),-1])))
  s=[(x,j,0)]+[(x,y,1)for y in range(j,k)]
  stubs.append(' '.join(map(str,[net,len(s),*(v for p in s for v in p)])))
inp=save('input.txt','40 40 8 11940 20 4 1 1 1 1 1 0 0 1 0 2 1\n'+'\n'.join(nets)+'\n')
stub=save('access.txt',str(len(stubs))+'\n'+'\n'.join(stubs)+'\n')
flags=['--critical-first','--native-prefix-first','--native-prefix-flexible','--pin-access=none','--weighted-bidirectional','--ordinary-zero-pattern','--ordinary-endpoint-escape','--ordinary-zero-maze=65536','--native-prefix-input='+str(native)]
old=root/'control162-router-ordinary-access2566.exe';new=root/'control162-router-escape-guard2582.exe'
def run(exe,label,extra):
 p=subprocess.run([str(exe),str(inp),str(d/(label+'.out')),*flags,*extra],capture_output=True,timeout=20)
 (d/(label+'.log')).write_bytes(p.stdout+p.stderr);print(label,p.returncode,(p.stdout+p.stderr).decode().splitlines()[-3:],flush=True);return p
p=run(old,'old',['--ordinary-access-input='+str(stub)]);assert p.returncode!=0 and b'endpoint escape requires M11 terminals' in p.stdout+p.stderr
p=run(new,'fixed',['--ordinary-access-input='+str(stub)]);assert p.returncode==0 and any(r.get('conflict_nodes')==0 for r in map(json.loads,p.stdout.splitlines()))
p=run(old,'old-disabled',[]);q=run(new,'fixed-disabled',[]);assert p.returncode==q.returncode==0 and p.stdout==q.stdout and (d/'old-disabled.out').read_bytes()==(d/'fixed-disabled.out').read_bytes()
import sys
sys.path.insert(0,str(root/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'))
from router_conflict_snapshot import inputs,inspect
h,allnets,limits=inputs(inp);r=inspect(d/'fixed.out',allnets,40,40,limits);assert not r['conflict_nodes']and r['all_trees_flood_verified']and r['all_wire_budgets_verified']
def ps(a):
 a=list(map(int,a));return list(zip(a[::3],a[1::3],a[2::3]))
lines=iter((d/'fixed.out').read_text().splitlines());assert int(next(lines))==len(nets);edges={}
for line in lines:
 n,k=line.split();ee=set()
 for i in range(int(k)):
  pp=ps(next(lines).split()[1:]);ee.update(frozenset((u,v))for u,v in zip(pp,pp[1:]))
 edges[n]=ee
for row in stubs:
 n,k,*a=row.split();p=ps(a);assert all(frozenset((u,v))in edges[n]for u,v in zip(p,p[1:]))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save('receipt.json',json.dumps(dict(passed=True,old_reproduced_exact_error=True,fixed_zero_conflicts=True,all_selected_edges_present=True,disabled_output_and_stdout_exact=True,files={p.name:sha(p)for p in [old,new,inp,native,stub,*d.glob('*.log'),d/'fixed.out']}),indent=2))
