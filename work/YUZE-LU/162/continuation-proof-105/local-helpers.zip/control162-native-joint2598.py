from pathlib import Path
import collections,hashlib,json,heapq,time
root=Path.cwd()
src=root/'control162-receive1988/input.txt'
base=root/'control162-ordinary-access-data2597/prefix.txt'
stubfile=root/'control162-ordinary-access-data2597/stubs.txt'
with src.open() as f:
  nx,ny,num,*other=map(int,f.readline().split())
  nets={}
  land={}
  for line in f:
    n,k,*raw=line.split();a=list(map(int,raw));p=list(zip(a[:-1:2],a[1:-1:2],[0]*int(k)))
    assert len(p)==int(k) and len(set(p))==len(p)
    nets[n]=(p,a[-1])
    for v in p:assert v not in land;land[v]=n
def pts(a):return list(zip(a[::3],a[1::3],a[2::3]))
with base.open() as f:
  m=int(f.readline());routes={}
  for _ in range(m):
    n,k=f.readline().split();assert k=='2'
    r,p=[pts(list(map(int,f.readline().split()[1:])))for _ in range(2)]
    assert r==nets[n][0][:1] and p[0]==nets[n][0][1] and p[-1]==r[0];routes[n]=p
with stubfile.open() as f:
  m=int(f.readline());stubs={}
  for line in f:
    n,k,*a=line.split();p=pts(list(map(int,a)));assert len(p)==int(k) and p[0] in nets[n][0];stubs[n]=p
  assert m==len(stubs)==115
occ={v:n for n,p in routes.items()for v in p};assert len(occ)==sum(map(len,routes.values()))
prot={v:n for n,p in stubs.items()for v in p};assert len(prot)==sum(map(len,stubs.values()))
targets={occ[v] for v in occ.keys()&prot.keys()};assert targets=={'net_7869'}
def adj(p):
  x,y,l=p
  if x>4:yield(x-1,y,l),1
  if x<nx-5:yield(x+1,y,l),1
  if y>4:yield(x,y-1,l),1
  if y<ny-5:yield(x,y+1,l),1
  if not (x+y)%2:yield(x,y,1-l),0
def wire(p):return sum(v[2]==w[2]for v,w in zip(p,p[1:]))
def search(n,hard,pay,avoid=(),search_cap=0):
  a,z=nets[n][0];maxwire=nets[n][1]
  def h(v):return abs(v[0]-z[0])+abs(v[1]-z[1])
  avoid=set(avoid)
  labels=collections.defaultdict(dict); labels[a][0]=0
  back={};q=[(0,h(a),0,a)];sizes=0
  while q:
    hits,est,w,v=heapq.heappop(q)
    if labels[v].get(w)!=hits:continue
    sizes+=1
    if search_cap and sizes>search_cap:return dict(popped=sizes,capped=True)
    if v==z:
      k=(v,w,hits);p=[v]
      while k in back:k=back[k];p.append(k[0])
      p.reverse()
      assert p[0]==a and p[-1]==z and len(set(p))==len(p) and wire(p)==w<=maxwire
      return dict(path=p,wire=w,cost=hits,stub_contacts=collections.Counter(prot[u]for u in p if u in prot),native_contacts=collections.Counter(occ[u]for u in p if u in occ and occ[u]!=n),popped=sizes)
    for u,inc in adj(v):
      nw=w+inc
      if nw+h(u)>maxwire or land.get(u,n)!=n or u in hard or u in avoid:continue
      nh=hits+pay.get(u,0)
      ds=labels[u]
      if any(j<=nw and i<=nh for j,i in ds.items()):continue
      for j in [j for j,i in ds.items()if j>=nw and i>=nh]:del ds[j]
      ds[nw]=nh;back[(u,nw,nh)]=(v,w,hits)
      heapq.heappush(q,(nh,nw+h(u),nw,u))
  return dict(unreachable_within_budget=True,popped=sizes)
# Conflict-based exact bounded single-net search plus disjunction on each
# occupied 3D point; caps below mark this probe inconclusive if reached.
import sys,itertools
tag=sys.argv[1] if len(sys.argv)>1 else 'one'
names=sorted(targets|set(sys.argv[2:]));assert all(n in routes for n in names)
out=root/('control162-native-joint2598-'+tag);out.mkdir()
frozen={v for v,n in occ.items()if n not in names}
hard=frozen|set(prot)
serial=itertools.count();memo={};stats=collections.Counter()
def path(n,cons):
  key=n,cons
  if key not in memo:
    r=search(n,hard,{},cons)
    memo[key]=r.get('path');stats['exact_single_net_queries']+=1;stats['expanded_single_net_labels']+=r['popped']
  return memo[key]
def priority(paths):
  seen=collections.Counter(v for p in paths for v in p)
  c=sum(k-1 for k in seen.values()if k>1)
  return c,sum(map(wire,paths))
def conflict(paths):
  m={}
  for i,p in enumerate(paths):
    for v in p:
      if v in m:return m[v],i,v
      m[v]=i
  return None
t=time.monotonic()
cons=tuple(frozenset()for _ in names);paths=[path(n,c)for n,c in zip(names,cons)]
q=[];seen={cons}
print('independent',[(n,None if p is None else wire(p),nets[n][1])for n,p in zip(names,paths)],flush=True)
if all(paths):heapq.heappush(q,(*priority(paths),next(serial),cons,paths))
else:
 for n,p in zip(names,paths):
  if p is not None:continue
  z=search(n,set(prot),{v:1 for v in frozen});print('minimum blocked native contacts',n,{k:v for k,v in z.items()if k!='path'},flush=True)
best=None;sol=None;last=None
while q and stats['expanded_constraint_states']<3500 and time.monotonic()-t<95:
  ov,ln,_,cons,paths=heapq.heappop(q);stats['expanded_constraint_states']+=1
  if best is None or ov<best:
    best=ov;last=paths;print('best',ov,ln,stats,flush=True)
  hit=conflict(paths)
  if not hit:
    sol=paths;break
  a,b,v=hit
  for i in (a,b):
    s=cons[:i]+(cons[i]|{v},)+cons[i+1:]
    if s in seen:continue
    seen.add(s)
    p=path(names[i],s[i])
    if p is None:continue
    r=paths[:i]+[p]+paths[i+1:]
    heapq.heappush(q,(*priority(r),next(serial),s,r))
r=dict(passed=sol is not None,whole_system_qualified=False,route_qualified=False,
  exhaustive_failure=sol is None and not q,unexplored=len(q),best=best,stats=stats,names=names,independent_all=all(x is not None for x in [memo[n,frozenset()]for n in names]),seconds=time.monotonic()-t,
  inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in (src,base,stubfile,Path(__file__))},scope='Joint native detour under exact fixed other nets and 115 true ordinary stubs; does not route ordinary nets outside access window or verify full final geometry/RC.')
if sol:
  used=set(hard);paths=dict(routes);paths.update(zip(names,sol))
  for n,p in zip(names,sol):
    assert not used.intersection(p) and all(land.get(v,n)==n for v in p)
    assert set(nets[n][0])=={p[0],p[-1]} and wire(p)<=nets[n][1]
    assert all(w in dict(adj(v))for v,w in zip(p,p[1:]));used.update(p)
  target=out/'native-prefix.txt'
  with target.open('x',newline=chr(10))as f:
    print(len(paths),file=f)
    for n,p in paths.items():
      if p[0]==nets[n][0][0]:p=p[::-1]
      print(n,2,file=f);print(1,*p[-1],file=f);print(len(p),*(t for v in p for t in v),file=f)
  r['prefix_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
(out/'receipt.json').write_text(json.dumps(r,indent=2))
print({k:v for k,v in r.items()if k!='inputs'},flush=True)
