from pathlib import Path
import subprocess,concurrent.futures,json,hashlib,collections,heapq
b=Path.cwd();o=b/'control162-static-access2595';o.mkdir()
f=b/'control162-receive1988/input.txt';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with f.open()as p:
 nx,ny,n,*_=map(int,p.readline().split());net={}
 for ln in p:
  k,c,*a=ln.split();a=list(map(int,a[:-1]));net[k]=[(x,y,0)for x,y in zip(a[::2],a[1::2])];assert len(net[k])==int(c)
land={p:n for n,pp in net.items()for p in pp}
candidates={'113':b/'control162-ordinary-access-data2572/stubs.txt','115':b/'control162-ordinary-access-data2588/stubs.txt','228':b/'control162-dual-window2591/combined-diagnostic.txt'}
def test(item):
 name,stubs=item;nets={n:set(p)for n,p in net.items()}
 occ={};owner={}
 with stubs.open()as f:
  count=int(f.readline())
  for line in f:
   k,c,*a=line.split();a=list(map(int,a));pp=list(zip(a[::3],a[1::3],a[2::3]));assert len(pp)==int(c)
   assert pp[0]in nets[k]
   for p in pp[1:]:
    assert p not in occ and p not in land;occ[p]=k;owner[p]=pp[0]
   nets[k].update(pp)
 fmt=o/(name+'.input')
 with fmt.open('x',newline=chr(10))as f:
  print(4,4,nx-5,ny-5,0,len(nets),file=f)
  for k,p in nets.items():print(k,len(p),*(a for v in sorted(p)for a in v),file=f)
 p=subprocess.run([str(b/'control162-connect2498.exe'),str(fmt)],capture_output=True,timeout=50);assert p.returncode in (0,2),p.stderr
 log=o/(name+'.log');log.write_bytes(p.stdout+p.stderr)
 def around(v):
  x,y,l=v
  if x>4:yield(x-1,y,l)
  if x<nx-5:yield(x+1,y,l)
  if y>4:yield(x,y-1,l)
  if y<ny-5:yield(x,y+1,l)
  if (x+y)%2==0:yield(x,y,1-l)
 isol=[];cost=[]
 for ln in p.stdout.decode().splitlines():
  if not ln.startswith('isolated '):continue
  _,k,x,y,l,*_=ln.split();v=tuple(map(int,(x,y,l)));isol.append((k,v))
  free=set();borders=collections.Counter();q=[v];free.add(v)
  for u in q:
   for w in around(u):
    other=land.get(w,k)
    if other!=k:continue
    other=occ.get(w,k)
    if other!=k:
     borders[(other,owner[w])]+=1;continue
    if w not in free:free.add(w);q.append(w)
   if len(free)>50000:break
  cost.append(dict(net=k,site=v,component_size=len(free),blocked_by=[(s,t,c)for(s,t),c in borders.most_common()]))
 print(name,len(isol),cost[:4],flush=True)
 return dict(stubs=count,disconnected=len(isol),routing_fixed_masks_only=True,sources={str(stubs):sha(stubs),str(fmt):sha(fmt),str(log):sha(log)},cavities=cost)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:r=dict(zip(candidates,pool.map(test,candidates.items())))
(o/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,real_net_input_sha=sha(f),cases=r),indent=2))
