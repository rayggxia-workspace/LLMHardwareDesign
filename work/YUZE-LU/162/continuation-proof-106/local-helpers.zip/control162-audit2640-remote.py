
from pathlib import Path
import json,hashlib
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d=b/'r256-partial-ordinary-seed-data-2640';out=b/'r256-partial-ordinary-seed-audit-2640';assert not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=b/'r256-ordinary-access-source-audit-2601/receipt.json';p=json.loads(prior.read_text())
src=b/'source-2587/source-manifest.json';a=json.loads(src.read_text());assert p['passed']and p['source_commit']==a['commit']and p['source_files']==1030 and p['inputs'][str(src)]==sha(src)
r=json.loads((d/'receipt.json').read_text());assert r['passed']and not r['route_qualified']and r['native_finite_budgets_verified']==1229
s=d/'paths.txt';n=b/'r256-ordinary-access-data-2600/native.json';native=json.loads(n.read_text());p2=Path(native['prefix']);inp=Path(native['input']);proof=r['actual_seed']
assert sha(s)==proof['paths_sha256']and sha(inp)==proof['input_sha256']==native['input_sha256']and sha(p2)==proof['native_prefix_sha256']==native['prefix_sha256']
assert int(s.open().readline())==proof['nets']==1760 and proof['vertices']>0 and r['exact_new_isolates']==0 and proof['all_true_landings_checked']
wrapper=b/'source-2587/project/experiments/control_v1/tree_router_cpp.py';assert sha(wrapper) in r['inputs'].values()
sc=d/'ordinary.json';assert not sc.exists()
sc.write_text(json.dumps(dict(paths=str(s),paths_sha256=sha(s),native_prefix_sha256=sha(p2),input_sha256=sha(inp)),indent=2))
out.mkdir()
r=dict(passed=True,whole_system_qualified=False,source_commit=a['commit'],access_stubs=0,ordinary_seed_nets=1760,critical_paths=1229,inputs={str(p):sha(p)for p in [prior,src,inp,p2,n,s,sc,d/'receipt.json']})
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,ordinary_full_pairs=1760,whole_system_qualified=False)))
