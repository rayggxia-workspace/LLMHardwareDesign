from pathlib import Path
import sys,subprocess,json,hashlib
b=Path.cwd();d=b/'control162-native-verify2646';d.mkdir(exist_ok=True);tag=sys.argv[1];out=d/tag;out.mkdir()
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'))
from router_conflict_snapshot import inputs,inspect
src=b/'control162-receive1988/input.txt';pref=b/('control162-native-order2643-'+tag)/'native-prefix.txt';stubs=b/('control162-reopen-baseline2638/alt-'+tag+'.json')
h,nets,limits=inputs(src);assert h[6]==1229 and h[2]==11149;nx,ny=h[:2];crit=dict(list(nets.items())[:h[6]])
r=inspect(pref,crit,nx,ny,limits);print({k:v for k,v in r.items()if not isinstance(v,(list,dict))},flush=True)
assert not r['conflict_nodes'] and r['all_trees_flood_verified'] and r['all_wire_budgets_verified']
own={};all_ends={(*v,0):n for n,ends in nets.items()for v in ends};assert len(all_ends)==24760
with pref.open()as f:
 assert int(f.readline())==len(crit)
 for _ in crit:
  n,c=f.readline().split();assert n in crit
  for _ in range(int(c)):
   vals=list(map(int,f.readline().split()));assert len(vals)==1+3*vals[0]
   for v in zip(vals[1::3],vals[2::3],vals[3::3]):
    assert all_ends.get(v,n)==n and own.get(v,n)==n;own[v]=n
 assert not f.read().strip()
st=0
for row in json.loads(stubs.read_text()):
 n=row['name'];ps=[tuple(v)for v in row['points']];assert all_ends[ps[0]]==n
 assert all(v not in own and all_ends.get(v,n)==n for v in ps)
 st+=len(ps)
orig={n:[(*v,0)for v in p] for n,p in nets.items()if n not in crit};fmt=out/'connect.in'
with fmt.open('x',newline=chr(10))as f:
 print(4,4,nx-5,ny-5,len(own),len(orig),file=f)
 for v in own:print(*v,file=f)
 for n,v in orig.items():print(n,len(v),*(q for w in v for q in w),file=f)
p=subprocess.run([str(b/'control162-connect2498.exe'),str(fmt),str(out/'main.mask')],capture_output=True,timeout=30);(out/'connect.log').write_bytes(p.stdout);print(p.stdout.decode().splitlines()[-12:],flush=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rec=dict(passed=p.returncode==0,whole_system_qualified=False,route_qualified=False,original_native_paths=len(crit),original_landings=len(all_ends),actual_stubs=3,actual_stub_vertices=st,ordinary_global_connectivity_returncode=p.returncode,inputs={str(p):sha(p)for p in [pref,src,stubs,Path(__file__),b/'control162-connect2498.exe']})
(out/'receipt.json').write_text(json.dumps(rec,indent=2))

