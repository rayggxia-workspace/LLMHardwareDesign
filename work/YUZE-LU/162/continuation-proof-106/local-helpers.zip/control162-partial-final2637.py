from pathlib import Path
import hashlib,json,subprocess,collections,sys
b=Path.cwd();out=b/'control162-partial-final2637';out.mkdir()
original=b/'control162-receive1988/input.txt';pref=b/'control162-ordinary-access-data2600/prefix.txt';seed=b/'control162-partial-astar2617/combined2625.txt'
names=[];ends={};all_ends={}
with original.open()as f:
 hd=list(map(int,f.readline().split()));nx,ny,n=hd[:3];crit=hd[6]
 for l in f:
  k,c,*r=l.split();a=list(map(int,r[:-1]));pts=list(zip(a[::2],a[1::2],[0]*int(c)));assert len(pts)==int(c)
  names.append(k);ends[k]=pts
  for v in pts:assert v not in all_ends;all_ends[v]=k
def get(path):
 d={}
 with path.open()as f:
  n=int(f.readline())
  for _ in range(n):
   k,c=f.readline().split();a=set()
   for i in range(int(c)):
    v=list(map(int,f.readline().split()));assert 3*v[0]+1==len(v);a.update(zip(v[1::3],v[2::3],v[3::3]))
   d[k]=a
  assert not f.read().strip()
 return d
fixed=get(pref);warm=get(seed);assert set(fixed)==set(names[:crit]) and len(warm)==2242 and not set(fixed)&set(warm)
def check(label,paths):
 outdir=out/label;outdir.mkdir()
 owner={}
 for n,path in paths.items():
  assert set(ends[n])<=path
  for v in path:assert owner.setdefault(v,n)==n and all_ends.get(v,n)==n
 remaining={n:v for n,v in ends.items()if n not in paths}
 inp=outdir/'network.input'
 with inp.open('x',newline=chr(10))as f:
  print(4,4,nx-5,ny-5,len(owner),len(remaining),file=f)
  for v in owner:print(*v,file=f)
  for n,v in remaining.items():print(n,len(v),*(q for w in v for q in w),file=f)
 e=b/'control162-connect2498.exe';p=subprocess.run([str(e),str(inp)],capture_output=True,timeout=40);assert p.returncode in (0,2),p.stderr
 logs=p.stdout.decode().splitlines();assert logs[-1].startswith('summary ')
 (outdir/'connect.log').write_bytes(p.stdout+p.stderr)
 print(label,logs[-1],flush=True)
 return logs,owner
def nbr(v):
 x,y,l=v
 if x>4:yield x-1,y,l
 if x<nx-5:yield x+1,y,l
 if y>4:yield x,y-1,l
 if y<ny-5:yield x,y+1,l
 if not (x+y)%2:yield x,y,1-l
def iso(log):
 return {tuple(s.split()[1:5])for s in log if s.startswith('isolated ')}
original_iso=iso((b/'control162-partial-static2634/fixed_native/connect.log').read_text().splitlines())
s=b/'control162-partial-safe2635/safe-pairs.txt';keep=set(get(s));assert len(keep)==1761
rlogs,current=check('before',{**fixed,**{k:warm[k]for k in keep}})
new=iso(rlogs)-original_iso;assert new=={('net_8927','1567','2066','0')}
n,x,y,l=next(iter(new));q=[tuple(map(int,(x,y,l)))];seen=set(q);walls=collections.Counter()
for v in q:
 for w in nbr(v):
  if all_ends.get(w,n)!=n:continue
  if w in current:
   if current[w] in keep:walls[current[w]]+=1
  elif w not in seen:
   seen.add(w);q.append(w)
 assert len(seen)<50
assert walls
drop=sorted(walls,key=lambda k:(-walls[k],len(warm[k]),k))[0];keep.remove(drop)
rlogs,current=check('after',{**fixed,**{k:warm[k]for k in keep}});assert not (iso(rlogs)-original_iso)
p=out/'pairs.txt';written=0
with s.open()as f,p.open('x',newline=chr(10))as z:
 print(len(keep),file=z)
 for _ in range(int(f.readline())):
  a=f.readline();x=f.readline();y=f.readline()
  if a.split()[0]not in keep:continue
  print(a.rstrip(),x.rstrip(),y.rstrip(),sep=chr(10),file=z);written+=1
assert written==len(keep)==1760
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(o if False else out/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,pairs=len(keep),removed=drop,exact_new_isolates=0,baseline_isolates=len(original_iso),remaining_isolates=len(iso(rlogs)),cavity_size=len(seen),inputs={str(f):sha(f)for f in [original,pref,s,Path(__file__)]},paths_sha256=sha(p)),indent=2))
print(drop,len(seen),len(keep),flush=True)
