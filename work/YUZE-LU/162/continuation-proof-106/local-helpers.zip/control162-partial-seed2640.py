from pathlib import Path
import json,sys,hashlib
b=Path.cwd();o=b/'control162-partial-seed2640';o.mkdir()
w=b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1';sys.path.insert(0,str(w))
from router_conflict_snapshot import inputs,inspect
from tree_router_cpp import verify_ordinary_seed
inp=b/'control162-receive1988/input.txt';h,ns,limits=inputs(inp);lock=list(ns)[:h[6]]
pref=b/'control162-ordinary-access-data2600/prefix.txt';p=b/'control162-partial-final2637/pairs.txt';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
isolation=b/'control162-partial-final2637/receipt.json';iso=json.loads(isolation.read_text());assert iso['passed'] and iso['pairs']==1760 and iso['exact_new_isolates']==0 and iso['paths_sha256']==sha(p)
old=inspect(pref,{n:ns[n]for n in lock},*h[:2],limits);assert not old['conflict_nodes'] and old['all_trees_flood_verified'] and old['all_wire_budgets_verified']
native=dict(prefix=str(pref),prefix_sha256=sha(pref),input_sha256=sha(inp))
cfg=o/'config.json';cfg.write_text(json.dumps(dict(paths=str(p),paths_sha256=sha(p),input_sha256=sha(inp),native_prefix_sha256=sha(pref)),indent=2))
f=verify_ordinary_seed(cfg,native,ns,*h[:2],lock,limits)
assert f['nets']==1760 and f['all_true_landings_checked']
r=dict(passed=True,whole_system_qualified=False,route_qualified=False,native_finite_budgets_verified=len(lock),exact_new_isolates=0,actual_seed=f,inputs={str(q):sha(q)for q in [inp,pref,p,w/'tree_router_cpp.py',isolation,Path(__file__)]})
(o/'receipt.json').write_text(json.dumps(r,indent=2));print(f)
