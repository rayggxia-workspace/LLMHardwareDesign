from pathlib import Path
import hashlib,json,subprocess,collections,sys
b=Path.cwd();out=b/'control162-reopen-baseline2638';out.mkdir()
original=b/'control162-receive1988/input.txt';pref=b/'control162-native-repair2506/candidate.txt';seed=b/'control162-partial-astar2617/combined2625.txt'
names=[];ends={};all_ends={}
with original.open()as f:
 hd=list(map(int,f.readline().split()));nx,ny,n=hd[:3];crit=hd[6]
 for l in f:
  k,c,*r=l.split();a=list(map(int,r[:-1]));pts=list(zip(a[::2],a[1::2],[0]*int(c)));assert len(pts)==int(c)
  names.append(k);ends[k]=pts
  for v in pts:assert v not in all_ends;all_ends[v]=k
def get(path):
 d={}
 with path.open()as f:
  n=int(f.readline())
  for _ in range(n):
   k,c=f.readline().split();a=set()
   for i in range(int(c)):
    v=list(map(int,f.readline().split()));assert 3*v[0]+1==len(v);a.update(zip(v[1::3],v[2::3],v[3::3]))
   d[k]=a
  assert not f.read().strip()
 return d
import heapq
native=get(pref);occ={v:k for k,pts in native.items()for v in pts};assert len(occ)==111372
orig={k:v for k,v in ends.items()if k not in native};fmt=out/'original.in';mask=out/'main.mask'
with fmt.open('x',newline=chr(10))as f:
 print(4,4,nx-5,ny-5,len(occ),len(orig),file=f)
 for v in occ:print(*v,file=f)
 for n,v in orig.items():print(n,len(v),*(q for w in v for q in w),file=f)
exe=b/'control162-connect2498.exe'
r=subprocess.run([str(exe),str(fmt),str(mask)],capture_output=True,timeout=30);assert r.returncode==2
raw=r.stdout.decode().splitlines();assert raw[-1].split()[-2:]==['2','3'];(out/'initial-connect.log').write_bytes(r.stdout)
from mmap import mmap,ACCESS_READ
mf=mask.open('rb');main=mmap(mf.fileno(),0,access=ACCESS_READ);assert len(main)==2*(nx-8)*(ny-8)
def reachable(v):
 x,y,l=v;return main[(nx-8)*((ny-8)*l+y-4)+x-4]!=0
def adjacent(v):
 x,y,l=v
 if x>4:yield x-1,y,l
 if x<nx-5:yield x+1,y,l
 if y>4:yield x,y-1,l
 if y<ny-5:yield x,y+1,l
 if not (x+y)%2:yield x,y,1-l
def escape(n,a,weights,prefix):
 dist={a:(0,0)};pre={};todo=[(0,0,a)]
 while todo:
  c,d,v=heapq.heappop(todo)
  if (c,d)!=dist[v]:continue
  if reachable(v):
   path=[v]
   while path[-1]!=a:path.append(pre[path[-1]])
   return path[::-1]
  if d>=48:continue
  for w in adjacent(v):
   if all_ends.get(w,n)!=n or w in prefix:continue
   alt=c+(50 if w in occ else 0)+weights[w],d+1
   if alt<dist.get(w,(1e20,1e20)):dist[w]=alt;pre[w]=v;heapq.heappush(todo,(*alt,w))
 return None
isol=[]
for l in raw:
 if l.startswith('isolated '):
  _,k,x,y,l,*_=l.split();isol.append((k,tuple(map(int,(x,y,l)))))
for i in range(12):
 rows=[];used=set();weights=collections.Counter()
 for n,a in isol[i%3:]+isol[:i%3]:
  for z in range(i//3+1):
   ps=escape(n,a,weights,used);assert ps and ps[0]==a and reachable(ps[-1])
   if z<i//3:
    for v in ps[1:-1]:
     if v in occ:weights[v]+=100
  hits=collections.Counter(occ[v]for v in ps if v in occ)
  assert not used.intersection(ps);used.update(ps)
  rows.append(dict(name=n,points=ps,overlaps=dict(hits)))
 print(i,[(r['name'],len(r['points']),r['overlaps'])for r in rows],flush=True)
 (out/('alt-'+str(i)+'.json')).write_text(json.dumps(rows,indent=2))
