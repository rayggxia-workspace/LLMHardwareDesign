from pathlib import Path
import json,subprocess,shlex,time
b=Path.cwd();out=b/'control162-watch-r-link2631.jsonl'
assert not out.exists()
h='yuzelu@10.129.166.172';root='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';scene=root+'/r256-balanced-reset-composition-1888'
f=Path('control162-full2630-remote.py');subprocess.run(['scp','-q',str(f),h+':'+root+'/'+f.name],check=True,timeout=25)
q="from pathlib import Path;import json; p="+repr([scene+'/cap-candidates/26150/receipt.json',scene+'/cap-necessary-2615/26150/native-residual/receipt.json',scene+'/cap-necessary-2615/26150/native-pin-load/receipt.json'])+";print(json.dumps({v:(json.loads(Path(v).read_text()).get('passed')if Path(v).is_file()else None)for v in p}))"
def emit(d):
 with out.open('a',encoding='utf-8')as x:x.write(json.dumps(d)+'\n')
 print(d,flush=True)
for i in range(100):
 try:
  r=json.loads(subprocess.check_output(['ssh','-o','ConnectTimeout=10',h,'python3 -c '+shlex.quote(q)],timeout=26))
 except (subprocess.SubprocessError,ValueError) as e:
  emit(dict(check=i,observer_error=str(e)));time.sleep(40);continue
 emit(dict(check=i,preflight=r))
 if False in r.values():
  emit(dict(refused='actual original preflight failed',whole_system_qualified=False));break
 if all(r.values()):
  subprocess.run(['python','-u','control162-subset2629.py'],check=True,timeout=150)
  rc=b/'control162-subset2629/receipt.json';a=json.loads(rc.read_text())
  if a['violations']!={'low':0,'base':0,'high':0}:
   emit(dict(refused='real stronger lower bound failed',violations=a['violations'],whole_system_qualified=False));break
  dest=scene+'/stronger-necessary-2629'
  x='from pathlib import Path;Path('+repr(dest)+').mkdir()'
  subprocess.run(['ssh','-o','ConnectTimeout=10',h,'python3 -c '+shlex.quote(x)],check=True,timeout=30)
  subprocess.run(['scp','-q',str(rc),h+':'+dest+'/receipt.json'],check=True,timeout=30)
  p=subprocess.run(['ssh','-o','ConnectTimeout=10',h,'PYTHONDONTWRITEBYTECODE=1 python3 '+root+'/'+f.name],capture_output=True,text=True,timeout=45)
  emit(dict(queue_returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0
  break
 if i<99:time.sleep(40)
