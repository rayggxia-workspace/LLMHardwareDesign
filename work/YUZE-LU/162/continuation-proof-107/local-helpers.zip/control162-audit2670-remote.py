from pathlib import Path
import json,hashlib
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d=b/'r256-partial-ordinary-seed-data-2670';out=b/'r256-partial-ordinary-seed-audit-2670';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
prior=b/'r256-ordinary-access-source-audit-2601/receipt.json';p=read(prior)
src=b/'source-2587/source-manifest.json';a=read(src);assert p['passed']and p['source_commit']==a['commit']and p['source_files']==1030 and p['inputs'][str(src)]==sha(src)
r=read(d/'seed-proof.json');assert r['passed']and not r['route_qualified']and r['native_finite_budgets_verified']==1229 and r['exact_new_isolates']==0
nat=d/'native-proof.json';n=read(nat);assert n['passed']and not n['route_qualified'] and n['paths']==1229 and n['checked_landings']==24760 and n['overlap']==n['closed']==n['foreign_landings']==0
iso=d/'isolation-proof.json';ss=read(iso);assert ss['passed']and ss['baseline_isolated']==ss['exact_new_isolates']==ss['stages'][-1]['total_isolated']==0 and ss['final_pair_nets']==1747
raw0=d/'native-only-connect.log';raw1=d/'combined-connect.log'
assert raw0.read_text().splitlines()[-1].split()==['summary','9920','22302','1726','19726524','0','0']
assert raw1.read_text().splitlines()[-1].split()==['summary','8173','18808','4170','18819602','0','0']
old=read(b/'r256-ordinary-access-data-2600/native.json');inp=Path(old['input']);pref=d/'native-prefix.txt';pairs=d/'paths.txt';proof=r['actual_seed']
assert sha(inp)==old['input_sha256']==proof['input_sha256'] and sha(pref)==proof['native_prefix_sha256'] and sha(pref)in n['inputs'].values() and sha(inp)in n['inputs'].values()
assert sha(pairs)==proof['paths_sha256']==ss['paths_sha256'] and int(pairs.open().readline())==proof['nets']==1747 and proof['all_true_landings_checked']
assert sha(iso) in r['inputs'].values() and sha(b/'source-2587/project/experiments/control_v1/tree_router_cpp.py') in r['inputs'].values()
nc=d/'native.json';sc=d/'ordinary.json';assert not nc.exists() and not sc.exists()
nc.write_text(json.dumps(dict(prefix=str(pref),prefix_sha256=sha(pref),input=str(inp),input_sha256=sha(inp)),indent=2))
sc.write_text(json.dumps(dict(paths=str(pairs),paths_sha256=sha(pairs),native_prefix_sha256=sha(pref),input_sha256=sha(inp)),indent=2))
out.mkdir()
e=dict(passed=True,whole_system_qualified=False,source_commit=a['commit'],access_stubs=0,ordinary_seed_nets=1747,critical_paths=1229,exact_closed_native=0,exact_closed_combined=0,inputs={str(x):sha(x)for x in [prior,src,inp,pref,pairs,nat,iso,raw0,raw1,nc,sc,d/'seed-proof.json']})
(out/'receipt.json').write_text(json.dumps(e,indent=2));print(json.dumps(dict(passed=True,ordinary_full_pairs=1747,native_paths=1229,whole_system_qualified=False)))
