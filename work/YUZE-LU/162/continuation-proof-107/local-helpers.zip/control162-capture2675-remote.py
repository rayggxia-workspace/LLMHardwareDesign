from pathlib import Path
import json,hashlib,zipfile,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-107';assert not out.exists();files={};sha=lambda v:hashlib.sha256(v).hexdigest()
def add(p):
 assert p.is_file()and b in p.parents and p.stat().st_size<16000000,str(p)
 files[str(p.relative_to(b))]=p.read_bytes()


for k in (2614,):
 for p in [b/('source-'+str(k))/'source-manifest.json',b/('source-'+str(k))/'freeze-import.json',b/('control162-archive'+str(k)+'.json'),b/('control162-backout'+str(k)+'.patch'),b/('control162-contract'+str(k)+'.json')]:
  if p.is_file():add(p)
for n in ['r256-partial-ordinary-seed-data-2670','r256-partial-ordinary-seed-audit-2670','r256-r-link-shift-source-audit-2615','route-selection-102/sready2662-r-links-refill']:
 for p in (b/n).glob('*'):
  if p.is_file() and p.suffix in ['.json','.txt','.log','.py','.zip'] and p.stat().st_size<9000000:add(p)
for n in ['cap-candidates/26150','cap-necessary-2615/26150/native-residual','cap-necessary-2615/26150/native-pin-load','stronger-necessary-2629']:
 for f in ('receipt.json','cluster-shift-proof.json','placement.json'):
  p=b/'r256-balanced-reset-composition-1888'/n/f
  if p.is_file():add(p)
selection=b/'route-selection-102';scene=b/'r256-balanced-reset-composition-1888'
for k in (2615,2630,2672):
 for d in selection.glob('sready'+str(k)+'-*'):
  rec=d/'tasks.json'
  if not rec.exists():continue
  add(rec);specs=json.loads(rec.read_text())['tasks']
  for row in specs:
   p=Path(row['path'])
   if not p.exists():continue
   if 'sha256'in row:assert sha(p.read_bytes())==row['sha256']
   add(p)
   for folder in ('commands','results'):
    q=p.parent.parent/folder/p.name
    if q.exists():add(q)
for k in (22000,25960,26300,26720):
 cand=scene/'upper-candidates'/str(k)
 p=scene/('acceptance-'+str(k)+'.json')
 if p.exists():add(p)
 route=cand/'route'
 for p in [route/'router-distance-oracle.json',route/'receipt.json',route/'router-input.txt',route/'router.log']:
  if p.exists()and p.stat().st_size<16000000:add(p)
 logs=sorted(route.glob('trial-*/router.log'))
 for p in logs:
  if p.stat().st_size<700000:add(p)
 for i in [0,1,8,15]:
  for n in ('output.txt.native-prefix.log','output.txt.native-prefix-paths.txt'):
   p=route/('trial-'+str(i))/n
   if p.exists()and p.stat().st_size<16000000:add(p)
for n in ('r256-openroad-region-2548','r256-openroad-region-2558'):
 for region in (b/n).glob('*'):
  for p in [region/'receipt.json',region/'case-0/openroad.log',region/'case-0/drc.rpt',region/'case-0/congestion.rpt']:
   if p.exists()and p.stat().st_size<16000000:add(p)
assert all(n in files for n in ('r256-partial-ordinary-seed-audit-2670/receipt.json','route-selection-102/sready2630-r-link-fullchain/tasks.json','route-selection-102/sready2672-physical-access-fullchain/tasks.json','route-selection-102/sready2662-r-links-refill/receipt.json','r256-balanced-reset-composition-1888/stronger-necessary-2629/receipt.json','source-2614/source-manifest.json'))
parents=[]
for folder in ['dynamic-05/node2','dynamic-09/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 p=b/folder/'queue-state.json';add(p);s=json.loads(files[str(p.relative_to(b))]);parents.append(dict(queue=folder,job=s['job'],slots=s['slots'],active=s['active'],memory_admissions=s['memory_admissions'],time=s['time']))
slurm=subprocess.check_output(['squeue','-u','yuzelu','-h','-o','%i|%j|%T|%N'],universal_newlines=True);own=[line for line in slurm.splitlines()if line.split('|')[0]in[p['job']for p in parents]];assert len(own)==8
snapshot=dict(time=time.time(),whole_system_qualified=False,parents=parents,slurm=own,active_slots=sum(len(p['active'])for p in parents),total_slot_capacity=sum(p['slots']for p in parents),scope='Live observed snapshot only. Known memory exceptions and actual process counts are recorded separately. No parent/R/other-job mutation.')
out.mkdir();(out/'snapshot.json').write_text(json.dumps(snapshot,indent=2));files['snapshot.json']=(out/'snapshot.json').read_bytes()
with zipfile.ZipFile(out/'selected-originals.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,raw in sorted(files.items()):z.writestr(n,raw)
index=dict(copied_files=len(files),files={n:dict(zip_entry=n,bytes=len(raw),sha256=sha(raw))for n,raw in sorted(files.items())},archive=dict(path='selected-originals.zip',bytes=(out/'selected-originals.zip').stat().st_size,sha256=sha((out/'selected-originals.zip').read_bytes())),scope='Exact captured bytes from authorized remote current Issue162 files. Live router.log/queue-state/read-only observations are immutable captured prefixes or snapshots, not final remote-file SHA promises. Exact frozen-source audit, access regressions, full-chain failed/current attempts, and independent regional routing runs. Every full-system qualification remains separate.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(copied_files=len(files),archive=index['archive'],active_slots=snapshot['active_slots'],slot_capacity=snapshot['total_slot_capacity'])))
