from pathlib import Path
import collections,hashlib,json,heapq,time
root=Path.cwd()
src=root/'control162-receive1988/input.txt'
base=root/'control162-native-order2657-9-2/native-prefix.txt'
import sys
tag=sys.argv[1]
stubfile=root/('control162-reopen-baseline2638/alt-'+tag+'.json')
with src.open() as f:
  nx,ny,num,*other=map(int,f.readline().split())
  nets={}
  land={}
  for line in f:
    n,k,*raw=line.split();a=list(map(int,raw));p=list(zip(a[:-1:2],a[1:-1:2],[0]*int(k)))
    assert len(p)==int(k) and len(set(p))==len(p)
    nets[n]=(p,a[-1])
    for v in p:assert v not in land;land[v]=n
def pts(a):return list(zip(a[::3],a[1::3],a[2::3]))
with base.open() as f:
  m=int(f.readline());routes={}
  for _ in range(m):
    n,k=f.readline().split();assert k=='2'
    r,p=[pts(list(map(int,f.readline().split()[1:])))for _ in range(2)]
    assert r==nets[n][0][:1] and p[0]==nets[n][0][1] and p[-1]==r[0];routes[n]=p
rr=json.loads(stubfile.read_text());stubs={i:[tuple(v)for v in row['points']]for i,row in enumerate(rr)}
assert len(stubs)==3 and all(p[0] in nets[rr[i]['name']][0]for i,p in stubs.items())
occ={v:n for n,p in routes.items()for v in p};assert len(occ)==sum(map(len,routes.values()))
prot={v:rr[i]['name'] for i,p in stubs.items()for v in p};assert len(prot)==sum(map(len,stubs.values()))
targets={occ[v] for v in occ.keys()&prot.keys()};assert not targets
def adj(p):
  x,y,l=p
  if x>4:yield(x-1,y,l),1
  if x<nx-5:yield(x+1,y,l),1
  if y>4:yield(x,y-1,l),1
  if y<ny-5:yield(x,y+1,l),1
  if not (x+y)%2:yield(x,y,1-l),0
def wire(p):return sum(v[2]==w[2]for v,w in zip(p,p[1:]))
def search(n,hard,pay,avoid=(),search_cap=0):
  a,z=nets[n][0];maxwire=nets[n][1]
  def h(v):return abs(v[0]-z[0])+abs(v[1]-z[1])
  avoid=set(avoid)
  labels=collections.defaultdict(dict); labels[a][0]=0
  back={};q=[(0,h(a),0,a)];sizes=0
  while q:
    hits,est,w,v=heapq.heappop(q)
    if labels[v].get(w)!=hits:continue
    sizes+=1
    if search_cap and sizes>search_cap:return dict(popped=sizes,capped=True)
    if v==z:
      k=(v,w,hits);p=[v]
      while k in back:k=back[k];p.append(k[0])
      p.reverse()
      assert p[0]==a and p[-1]==z and len(set(p))==len(p) and wire(p)==w<=maxwire
      return dict(path=p,wire=w,cost=hits,stub_contacts=collections.Counter(prot[u]for u in p if u in prot),native_contacts=collections.Counter(occ[u]for u in p if u in occ and occ[u]!=n),popped=sizes)
    for u,inc in adj(v):
      nw=w+inc
      if nw+h(u)>maxwire or land.get(u,n)!=n or u in hard or u in avoid:continue
      nh=hits+pay.get(u,0)
      ds=labels[u]
      if any(j<=nw and i<=nh for j,i in ds.items()):continue
      for j in [j for j,i in ds.items()if j>=nw and i>=nh]:del ds[j]
      ds[nw]=nh;back[(u,nw,nh)]=(v,w,hits)
      heapq.heappush(q,(nh,nw+h(u),nw,u))
  return dict(unreachable_within_budget=True,popped=sizes)

import random,subprocess
from mmap import mmap,ACCESS_READ
order=int(sys.argv[2]);out=root/('control162-cavity-repair2664-'+str(order));out.mkdir();t=time.monotonic()
rng=random.Random(2661+order);original={n:list(p)for n,p in routes.items()}
ordinary={n:p for n,(p,_) in nets.items()if n not in routes}
exe=root/'control162-connect2498.exe';scores=[]
def static(rr):
 occ={v:n for n,p in rr.items()for v in p}
 assert len(occ)==sum(map(len,rr.values()))
 p=out/'work.in';m=out/'giant.mask'
 with p.open('w',newline=chr(10))as f:
  print(4,4,nx-5,ny-5,len(occ),len(ordinary),file=f)
  for v in occ:print(*v,file=f)
  for n,ps in ordinary.items():print(n,len(ps),*(k for v in ps for k in v),file=f)
 q=subprocess.run([str(exe),str(p),str(m)],capture_output=True,timeout=25)
 assert q.returncode in(0,2)
 raw=q.stdout.decode().splitlines();e=[]
 for l in raw:
  if l.startswith('isolated '):
   _,n,x,y,z,*_=l.split();e.append((n,tuple(map(int,(x,y,z)))))
 assert len(e)==int(raw[-1].split()[-1])
 return e,raw,occ
class Stay:
 def __init__(self,old):self.old=set(old)
 def get(self,v,d):return int(v not in self.old)
def choices_for(name,a,mask,occ,pen):
 def giant(v):
  x,y,l=v;return bool(mask[(nx-8)*((ny-8)*l+y-4)+x-4])
 d={a:0};parents={};todo=[(0,a)]
 while todo:
  c,v=heapq.heappop(todo)
  if c!=d.get(v):continue
  if giant(v):
   ps=[v]
   while ps[-1]!=a:ps.append(parents[ps[-1]])
   return ps[::-1]
  for w,_ in adj(v):
   if land.get(w,name)!=name:continue
   q=c+1+int(w in occ)*30+pen.get(w,0)
   if q<d.get(w,1e9):d[w]=q;parents[w]=v;heapq.heappush(todo,(q,w))
 return None
isol,raw,occup=static(routes);assert len(isol)==9
(out/'initial.log').write_text('\n'.join(raw)+'\n')
result0=len(isol);passes=0
while isol and time.monotonic()-t<60:
 improved=False;seq=isol[:];rng.shuffle(seq);passes+=1
 with (out/'giant.mask').open('rb')as f:mask=f.read()
 for n,a in seq:
  pen=collections.Counter()
  for i in range(5):
   if time.monotonic()-t>=60:break
   p=choices_for(n,a,mask,occup,pen)
   if p is None:break
   names=sorted({occup[v]for v in p if v in occup})
   if not names:break
   for v in p[1:-1]:pen[v]+=rng.randrange(7,41)
   hard={v for v,k in occup.items()if k not in names}|set(p)
   for j in range(min(8,2+len(names)*2)):
    q=rng.sample(names,len(names));used=set();res={}
    for k in q:
     r=search(k,hard,Stay(routes[k]),used,60000).get('path')
     if not r:break
     used.update(r);res[k]=r
    if len(res)!=len(names):continue
    rr=dict(routes);rr.update(res);new,log,new_occ=static(rr)
    if len(new)<len(isol):
     print('accepted',len(isol),len(new),n,a,names,flush=True);scores.append(dict(before=len(isol),after=len(new),pin=a,net=n,native=names))
     isol,raw,occup=new,log,new_occ;routes=rr;improved=True
     break
   if improved:break
  if improved:break
 if not improved:break
(out/'final.log').write_text('\n'.join(raw)+'\n')
p=out/'native-prefix.txt'
with p.open('x',newline=chr(10))as f:
 print(len(routes),file=f)
 for n,path in routes.items():
  if path[0]==nets[n][0][0]:path=path[::-1]
  print(n,2,file=f);print(1,*path[-1],file=f);print(len(path),*(v for w in path for v in w),file=f)
r=dict(passed=not isol,whole_system_qualified=False,route_qualified=False,before=result0,after=len(isol),scores=scores,passes=passes,seconds=time.monotonic()-t,prefix_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(r,flush=True)

