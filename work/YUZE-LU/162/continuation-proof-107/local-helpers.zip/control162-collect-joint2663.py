from pathlib import Path
import hashlib,json,shlex,subprocess,sys
b=Path.cwd();h='yuzelu@10.129.166.172'
q=r'''
from pathlib import Path
import hashlib,json,math
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
scene=b/'r256-balanced-reset-composition-1888';root=scene/'upper-candidates'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for v in iter(lambda:f.read(1048576),b''):h.update(v)
 return h.hexdigest()
stages=('route','geometry','pg-audit','timing/low','timing/base','timing/high','delivery')
eligible=[];observed={}
for case in sorted(root.iterdir()):
 p=case/'delivery/receipt.json'
 if p.is_file():
  try:r=read(p)
  except ValueError:continue
  observed[case.name]={k:r.get(k,False) for k in ['passed','declared_composition_qualified','whole_system_qualified']}
  if all(observed[case.name].values()):eligible.append((case,r))
if not eligible:
 print(json.dumps(dict(ready=False,whole_system_qualified=False,joint_receipts=observed)))
 raise SystemExit(0)
case,d=eligible[0];files={}
def add(name,p,expected=None,rehash=True):
 assert p.is_file()and b in p.resolve().parents
 if rehash:
  actual=sha(p)
  if expected:assert actual==expected,p
 else:assert expected and len(expected)==64;actual=expected
 assert name not in files
 files[name]=dict(path=str(p),sha256=actual,bytes=p.stat().st_size)
for stage in stages:
 p=case/stage/'receipt.json';r=read(p);assert r['passed'];add(stage+'/receipt.json',p)
route=read(case/'route/receipt.json');geom=read(case/'geometry/receipt.json');pg=read(case/'pg-audit/receipt.json')
assert route['net_count']==11149 and route['search']['final_conflicts']==0 and route['search']['independent_tree_flood']
assert geom['actual_odb_def_readback']and geom['actual_joined_gds_readback']and pg['system_pg_qualified']
j=case/'delivery/system-acceptance.json';a=read(j);add('system-acceptance.json',j,d['outputs'][j.name])
assert a['R_integrated'] and a['instance_count']==345 and a['native_types']==23 and a['all_actual_geometry_pg_function_rc_bound']
assert all(row['passed']and row['cpu_tensor_moves']==0 and row['real_compositions']==8 for row in a['real_programs'].values())
assert len(a['real_programs'])==3 and set(a['timing'])=={'low','base','high'}
for v in ('low','base','high'):
 o=case/'timing'/v;r=read(o/'receipt.json')
 assert r['actual_upper_distributed_research_rc'] and r['research_composed_timing_passed'] and r['native_coverage_audit_passed'] and r['typed_native_timing_passed']
 assert all(math.isfinite(r[k]) and r[k]==a['timing'][v][k]>=0 for k in ('minimum_setup_ns','minimum_hold_ns'))
 for n in ['native-system-audit.json','native-stitch.json']:
  add('timing/'+v+'/'+n,o/n,r['outputs'][n])
 path=Path(a['timing'][v]['stitched_spef']);assert path==o/'stitched-native.spef'
 add('timing/'+v+'/'+path.name,path,a['timing'][v]['stitched_spef_sha256'],False)
for v in ['function','function-audit','internal-program-traces','source-binding-audit']:
 p=scene/v/'receipt.json';assert read(p)['passed'];add(v+'/receipt.json',p)
for n in ('6_final.v','6_final.sdc','6_final.def','6_final.odb','6_final.spef','6_final.gds','layout.png'):
 add(n,case/'delivery'/n,d['outputs'][n],n=='layout.png')
print(json.dumps(dict(ready=True,whole_system_qualified=True,seed=int(case.name),timing=a['timing'],files=files)))
'''
# Probe is read-only and avoids hashing the bulk final files on the login node.
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=12',h,'python3 -c '+shlex.quote(q)],timeout=55)
data=json.loads(raw)
print(json.dumps(dict(ready=data['ready'],whole_system_qualified=data['whole_system_qualified'],seed=data.get('seed'),joint_receipts=data.get('joint_receipts'))),flush=True)
if not data['ready']or '--probe'in sys.argv:raise SystemExit(0)
out=b/'LLMHardwareDesign-worktrees/issue-162-control/work/YUZE-LU/162'/('actual-joint-delivery-'+str(data['seed']));out.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for v in iter(lambda:f.read(1048576),b''):h.update(v)
 return h.hexdigest()
for n,row in data['files'].items():
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True)
 if not(p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']):
  tmp=p.with_name(p.name+'.incoming');assert not tmp.exists()
  subprocess.run(['scp','-q',h+':'+row['path'],str(tmp)],check=True,timeout=1200)
  assert tmp.stat().st_size==row['bytes'] and sha(tmp)==row['sha256'],n
  tmp.replace(p)
 (out/'partial-index.json').write_text(json.dumps(dict(verified_through=n,source_candidate=data['seed']),indent=2))
row=dict(data,all_files_locally_sha_and_length_verified=True)
(out/'index.json').write_text(json.dumps(row,indent=2))
print(json.dumps(dict(ready=True,all_files_locally_sha_and_length_verified=True,seed=data['seed'],files=len(row['files']),index=str(out/'index.json'))),flush=True)
