from pathlib import Path
import collections,hashlib,json,heapq,time
root=Path.cwd()
src=root/'control162-receive1988/input.txt'
base=root/'control162-native-repair2506/candidate.txt'
import sys
tag=sys.argv[1]
stubfile=root/('control162-reopen-baseline2638/alt-'+tag+'.json')
with src.open() as f:
  nx,ny,num,*other=map(int,f.readline().split())
  nets={}
  land={}
  for line in f:
    n,k,*raw=line.split();a=list(map(int,raw));p=list(zip(a[:-1:2],a[1:-1:2],[0]*int(k)))
    assert len(p)==int(k) and len(set(p))==len(p)
    nets[n]=(p,a[-1])
    for v in p:assert v not in land;land[v]=n
def pts(a):return list(zip(a[::3],a[1::3],a[2::3]))
with base.open() as f:
  m=int(f.readline());routes={}
  for _ in range(m):
    n,k=f.readline().split();assert k=='2'
    r,p=[pts(list(map(int,f.readline().split()[1:])))for _ in range(2)]
    assert r==nets[n][0][:1] and p[0]==nets[n][0][1] and p[-1]==r[0];routes[n]=p
rr=json.loads(stubfile.read_text());stubs={i:[tuple(v)for v in row['points']]for i,row in enumerate(rr)}
assert len(stubs)==3 and all(p[0] in nets[rr[i]['name']][0]for i,p in stubs.items())
occ={v:n for n,p in routes.items()for v in p};assert len(occ)==sum(map(len,routes.values()))
prot={v:rr[i]['name'] for i,p in stubs.items()for v in p};assert len(prot)==sum(map(len,stubs.values()))
targets={occ[v] for v in occ.keys()&prot.keys()};assert targets=={n for row in rr for n in row['overlaps']}
def adj(p):
  x,y,l=p
  if x>4:yield(x-1,y,l),1
  if x<nx-5:yield(x+1,y,l),1
  if y>4:yield(x,y-1,l),1
  if y<ny-5:yield(x,y+1,l),1
  if not (x+y)%2:yield(x,y,1-l),0
def wire(p):return sum(v[2]==w[2]for v,w in zip(p,p[1:]))
def search(n,hard,pay,avoid=(),search_cap=0):
  a,z=nets[n][0];maxwire=nets[n][1]
  def h(v):return abs(v[0]-z[0])+abs(v[1]-z[1])
  avoid=set(avoid)
  labels=collections.defaultdict(dict); labels[a][0]=0
  back={};q=[(0,h(a),0,a)];sizes=0
  while q:
    hits,est,w,v=heapq.heappop(q)
    if labels[v].get(w)!=hits:continue
    sizes+=1
    if search_cap and sizes>search_cap:return dict(popped=sizes,capped=True)
    if v==z:
      k=(v,w,hits);p=[v]
      while k in back:k=back[k];p.append(k[0])
      p.reverse()
      assert p[0]==a and p[-1]==z and len(set(p))==len(p) and wire(p)==w<=maxwire
      return dict(path=p,wire=w,cost=hits,stub_contacts=collections.Counter(prot[u]for u in p if u in prot),native_contacts=collections.Counter(occ[u]for u in p if u in occ and occ[u]!=n),popped=sizes)
    for u,inc in adj(v):
      nw=w+inc
      if nw+h(u)>maxwire or land.get(u,n)!=n or u in hard or u in avoid:continue
      nh=hits+pay.get(u,0)
      ds=labels[u]
      if any(j<=nw and i<=nh for j,i in ds.items()):continue
      for j in [j for j,i in ds.items()if j>=nw and i>=nh]:del ds[j]
      ds[nw]=nh;back[(u,nw,nh)]=(v,w,hits)
      heapq.heappush(q,(nh,nw+h(u),nw,u))
  return dict(unreachable_within_budget=True,popped=sizes)

import random,itertools
names=sorted(targets|set(sys.argv[3:]));assert all(n in routes for n in names)
out=root/('control162-native-order2657-'+tag+'-'+sys.argv[2]);out.mkdir()
frozen={v for v,n in occ.items()if n not in names}
hard=frozen|set(prot);memo={};stats=collections.Counter();t=time.monotonic()
q=random.Random(2643+int(tag)+int(sys.argv[2])*101);variants=[];seen=set();best=(0,[]);sol=None
class ChangeCost:
 def __init__(self,old): self.old=set(old)
 def get(self,v,default): return 0 if v in self.old else 1
costs={n:ChangeCost(routes[n]) for n in names};bsol=None
def margin(n):
 a,b=nets[n][0];return nets[n][1]-abs(a[0]-b[0])-abs(a[1]-b[1])
orders=[tuple(sorted(names,key=margin)),tuple(sorted(names,key=margin,reverse=True))]
for attempt in range(500):
 if time.monotonic()-t>=55:break
 if orders:order=orders.pop()
 elif attempt%3==0 and best[1]:
  prefix=best[1][:];first=prefix.pop(q.randrange(len(prefix)));tail=list(set(names)-set(prefix)-{first});q.shuffle(tail);prefix.insert(q.randrange(len(prefix)+1),tail.pop(0)if tail else first)
  order=tuple(prefix+[x for x in [first]+tail if x not in prefix])
 else:order=tuple(q.sample(names,len(names)))
 if order in seen or len(set(order))!=len(names):continue
 seen.add(order);used=set();paths={}
 for n in order:
  key=tuple(paths),n
  if key not in memo:memo[key]=search(n,hard,costs[n],used,250000).get('path');stats['searches']+=1
  p=memo[key]
  if p is None:break
  assert not used.intersection(p);used.update(p);paths[n]=p
 if len(paths)>best[0]:best=len(paths),list(paths);print('best',best,'of',len(names),flush=True)
 if len(paths)==len(names):
  c=sum(len(set(p)-costs[n].old)for n,p in paths.items());bsol=c if bsol is None else bsol
  if sol is None or c<bsol: sol=paths;bsol=c;print('least_changed',c,flush=True)
  variants.append((c,paths));
  if len(variants)>=24:break

import subprocess
outcomes=[];exact_best=None
tested=set()
orig={n:p for n,(p,_)in nets.items()if n not in routes}
def check(selected):
 vset=frozen|{v for p in selected.values() for v in p}
 assert len(vset)==len(frozen)+sum(map(len,selected.values()))
 fmt=out/'candidate-connect.in'
 with fmt.open('w',newline=chr(10))as f:
  print(4,4,nx-5,ny-5,len(vset),len(orig),file=f)
  for v in vset:print(*v,file=f)
  for n,p in orig.items():print(n,len(p),*(q for w in p for q in w),file=f)
 p=subprocess.run([str(root/'control162-connect2498.exe'),str(fmt)],capture_output=True,timeout=30)
 assert p.returncode in(0,2),p.stderr
 lines=p.stdout.decode().splitlines()
 assert lines[-1].startswith('summary 9920 22302 ')
 return tuple(map(int,lines[-1].split()[-2:])),lines
for c,paths in sorted(variants,key=lambda x:x[0]):
 key=tuple((n,tuple(p))for n,p in sorted(paths.items()))
 if key in tested:continue
 tested.add(key)
 result,lines=check(paths)
 outcomes.append((c,*result))
 rank=(result[1],result[0],c)
 if exact_best is None or rank<exact_best:
  exact_best=rank;sol=paths;(out/'best-connect.log').write_text('\n'.join(lines)+'\n');print('best_exact',rank,flush=True)
 if not result[0]:break
r=dict(passed=sol is not None,whole_system_qualified=False,route_qualified=False,names=names,attempts=len(seen),best=best,least_changed=bsol,exact_best=exact_best,checked_candidates=outcomes,stats=stats,seconds=time.monotonic()-t)
if sol:
 paths=dict(routes);paths.update(sol)
 target=out/'native-prefix.txt'
 with target.open('x',newline=chr(10))as f:
  print(len(paths),file=f)
  for n,p in paths.items():
   if p[0]==nets[n][0][0]:p=p[::-1]
   print(n,2,file=f);print(1,*p[-1],file=f);print(len(p),*(t for v in p for t in v),file=f)
 r['prefix_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(r,flush=True)
