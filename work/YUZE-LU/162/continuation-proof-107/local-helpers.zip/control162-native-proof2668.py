from pathlib import Path
import sys,json,hashlib
b=Path.cwd();d=b/'control162-cavity-repair2666-4';out=b/'control162-native-proof2668.json';assert not out.exists()
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'))
from router_conflict_snapshot import inputs,inspect
src=b/'control162-receive1988/input.txt';pref=d/'native-prefix.txt';iso=d/'receipt.json';a=json.loads(iso.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert a['passed'] and a['after']==0 and a['prefix_sha256']==sha(pref)
h,nets,limits=inputs(src);assert h[:3]==[3070,3252,11149] and h[6]==1229;crit=dict(list(nets.items())[:h[6]])
v=inspect(pref,crit,*h[:2],limits)
assert not v['conflict_nodes'] and v['all_trees_flood_verified'] and v['all_wire_budgets_verified']
all_ends={(*p,0):n for n,pts in nets.items()for p in pts};assert len(all_ends)==24760
seen={}
with pref.open()as f:
 assert int(f.readline())==1229
 for n in crit:
  name,k=f.readline().split();assert name==n
  for _ in range(int(k)):
   r=list(map(int,f.readline().split()));assert len(r)==1+3*r[0]
   for p in zip(r[1::3],r[2::3],r[3::3]):
    assert all_ends.get(p,n)==n and seen.get(p,n)==n;seen[p]=n
 assert not f.read().strip()
assert v['occupied_cells']==len(seen)
e=dict(passed=True,whole_system_qualified=False,route_qualified=False,paths=1229,occupied=len(seen),foreign_landings=0,checked_landings=24760,overlap=0,closed=0,inputs={str(p):sha(p)for p in [src,pref,iso,d/'final.log',Path(__file__)]})
out.write_text(json.dumps(e,indent=2));print(e)
