from pathlib import Path
import hashlib,json,subprocess,collections,sys
b=Path.cwd();out=b/'control162-partial-safe2668';out.mkdir()
original=b/'control162-receive1988/input.txt';pref=b/'control162-cavity-repair2666-4/native-prefix.txt';seed=b/'control162-partial-final2637/pairs.txt'
names=[];ends={};all_ends={}
with original.open()as f:
 hd=list(map(int,f.readline().split()));nx,ny,n=hd[:3];crit=hd[6]
 for l in f:
  k,c,*r=l.split();a=list(map(int,r[:-1]));pts=list(zip(a[::2],a[1::2],[0]*int(c)));assert len(pts)==int(c)
  names.append(k);ends[k]=pts
  for v in pts:assert v not in all_ends;all_ends[v]=k
def get(path):
 d={}
 with path.open()as f:
  n=int(f.readline())
  for _ in range(n):
   k,c=f.readline().split();a=set()
   for i in range(int(c)):
    v=list(map(int,f.readline().split()));assert 3*v[0]+1==len(v);a.update(zip(v[1::3],v[2::3],v[3::3]))
   d[k]=a
  assert not f.read().strip()
 return d
fixed=get(pref);warm=get(seed);assert set(fixed)==set(names[:crit]) and len(warm)==1760 and not set(fixed)&set(warm)
def check(label,paths):
 outdir=out/label;outdir.mkdir()
 owner={}
 for n,path in paths.items():
  assert set(ends[n])<=path
  for v in path:assert owner.setdefault(v,n)==n and all_ends.get(v,n)==n
 remaining={n:v for n,v in ends.items()if n not in paths}
 inp=outdir/'network.input'
 with inp.open('x',newline=chr(10))as f:
  print(4,4,nx-5,ny-5,len(owner),len(remaining),file=f)
  for v in owner:print(*v,file=f)
  for n,v in remaining.items():print(n,len(v),*(q for w in v for q in w),file=f)
 e=b/'control162-connect2498.exe';p=subprocess.run([str(e),str(inp)],capture_output=True,timeout=40);assert p.returncode in (0,2),p.stderr
 logs=p.stdout.decode().splitlines();assert logs[-1].startswith('summary ')
 (outdir/'connect.log').write_bytes(p.stdout+p.stderr)
 print(label,logs[-1],flush=True)
 return logs,owner
def nbr(v):
 x,y,l=v
 if x>4:yield x-1,y,l
 if x<nx-5:yield x+1,y,l
 if y>4:yield x,y-1,l
 if y<ny-5:yield x,y+1,l
 if not (x+y)%2:yield x,y,1-l
def iso(log):
 return {tuple(s.split()[1:5])for s in log if s.startswith('isolated ')}
original_iso=iso(check('native-only',fixed)[0]);assert not original_iso
occ={v for vs in fixed.values() for v in vs};colliding={n for n,vs in warm.items() if occ.intersection(vs)};print('native collisions excluded',len(colliding),flush=True)
keep=set(warm)-colliding;history=[];stages=0
for phase,drop_count in enumerate([12,10,8,6,4,3,2,2,1,1,1,1]):
 logs,current=check('trim-'+str(phase),{**fixed,**{k:warm[k]for k in keep}})
 isolated=iso(logs);new=isolated-original_iso
 history.append(dict(stage=phase,nets=len(keep),total_isolated=len(isolated),new_isolated=len(new)))
 print(history[-1],flush=True)
 if not new:break
 pressure=collections.Counter()
 for n,x,y,l in new:
  start=tuple(map(int,(x,y,l)))
  visits={start};front=[(start,0)];hit={}
  for v,dist in front:
   if dist>=5 or len(visits)>40:break
   for w in nbr(v):
    if all_ends.get(w,n)!=n:continue
    if w in current:
     k=current[w]
     if k in keep:hit.setdefault(k,dist)
    elif w not in visits:
     visits.add(w);front.append((w,dist+1))
  for k,d in hit.items():pressure[k]+=1/(1+d)
 if not pressure:break
 rem=[k for k,v in pressure.most_common(drop_count)]
 assert len(rem)==len(set(rem)) and set(rem)<=keep
 keep.difference_update(rem);history[-1]['removed']=[(k,round(pressure[k],4))for k in rem]
else:
 phase+=1;logs,current=check('trim-'+str(phase),{**fixed,**{k:warm[k]for k in keep}})
 t=iso(logs);history.append(dict(stage=phase,nets=len(keep),total_isolated=len(t),new_isolated=len(t-original_iso)))
assert not iso(logs),logs[-12:]
target=out/'safe-pairs.txt'
with target.open('x',newline=chr(10))as f, seed.open()as src:
 print(len(keep),file=f);n=int(src.readline());written=0
 for i in range(n):
  a=src.readline();nm=a.split()[0];x=src.readline();y=src.readline()
  if nm not in keep:continue
  print(a.rstrip(),x.rstrip(),y.rstrip(),sep=chr(10),file=f);written+=1
 assert written==len(keep)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(out/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,baseline_isolated=len(original_iso),colliding_removed=sorted(colliding),exact_new_isolates=0,stages=history,final_pair_nets=len(keep),paths_sha256=sha(target),inputs={str(f):sha(f)for f in [original,pref,seed,Path(__file__)]}),indent=2))
