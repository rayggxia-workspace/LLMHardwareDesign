from pathlib import Path
import json,hashlib,subprocess,re,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
scene=b/'r256-balanced-reset-composition-1888';q=b/'dynamic-08/node6'
out=scene/'upper-candidates/21300/route';job='97097';name='00-g-sready2130-r256-route-21300'
record=b/'route-selection-102/sready2662-r-links-refill';assert not record.exists()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
state=read(q/'queue-state.json');sp=q/'pending'/(name+'.json');s=read(sp);cmd=read(q/'commands'/sp.name)
assert state['job']==job and state['slots']==len(state['active'])==4 and name in state['active'] and name not in state.get('finished',{})
assert cmd['spec_sha256']==sha(sp);a=s['args'];source=Path(s['source_root'])
assert s['script']=='system_upper.py' and a[a.index('--out')+1]==str(out) and a[a.index('--route-trials')+1]=='16' and s['forecast_gib']==65
assert a[a.index('--graph')+1]==str(scene/'topology/boundary-graph.json')
assert a[a.index('--reuse-placement')+1]==str(scene/'cap-candidates/19540')
assert sha(source/'source-manifest.json')==cmd['source_manifest_sha256'] and sha(source/'project/experiments/control_v1/system_upper.py')==cmd['script_sha256']
replacement=next((b/'route-selection-102').glob('sready2615-*/tasks.json'))
rp=next(row for row in read(replacement)['tasks'] if '--out' in row['spec']['args'] and row['spec']['args'][row['spec']['args'].index('--out')+1]==str(scene/'cap-candidates/26150'))
p=Path(rp['path']);assert p.parent==q/'pending' and p.stem not in state['active'] and sha(p)==rp['sha256']
assert not (q/'commands'/p.name).exists() and not (scene/'cap-candidates/26150').exists()
ready=[]
for x in sorted((q/'pending').glob('*.json')):
 if x.stem in state['active'] or x.stem in state.get('finished',{}) or (q/'results'/x.name).exists():continue
 if all(Path(v).is_file()and read(Path(v)).get('passed',True)for v in read(x)['requires']):ready.append(x.name)
assert ready and ready[0]==p.name,ready[:5]
expected=set(['router.log','input.txt'])
raws={};trend=[]
for i in range(16):
 d=out/('trial-'+str(i));assert not(d/'output.txt').exists()
 hdr,body=(d/'input.txt').read_bytes().split(b'\n',1);h=list(map(int,hdr.split()))
 assert h[:3]==[3070,3252,11149] and h[4]==80 and h[6]==1229
 z=(d/'router.log').read_bytes();rows=[]
 for l in z.splitlines(keepends=True):
  if l.endswith(b'\n')and b'"conflict_nodes"'in l:rows.append(json.loads(l))
 assert len(rows)>=69 and rows[-1]['round']>=68
 best=min(x['conflict_nodes']for x in rows)
 assert best>=650000 and best==min(x['conflict_nodes']for x in rows[:-8])
 trend.append(dict(attempt=i,round=rows[-1]['round'],current=rows[-1]['conflict_nodes'],best=best,all_last_eight_no_new_best=True))
 for f in [d/'router.log',d/'input.txt']:raws[str(f.relative_to(out))]=f.read_bytes()
baseline=scene/'upper-candidates/22000/route/trial-0';raws['competing-22000-trial0.log']=(baseline/'router.log').read_bytes()
assert (baseline/'input.txt').read_bytes().split(b'\n',1)[1]==body
assert min(json.loads(l)['conflict_nodes']for l in raws['competing-22000-trial0.log'].splitlines(keepends=True)if l.endswith(b'\n')and b'"conflict_nodes"'in l)<500000
for n in ['receipt.json','trees.json','router-output.txt']:assert not(out/n).exists()
info=subprocess.check_output(['scontrol','show','job',job,'-o'],universal_newlines=True)
assert 'UserId=yuzelu(10011)'in info and 'JobName=yzl-ctl162-'in info and 'NodeList=node6 'in info
lines=subprocess.check_output(['scontrol','show','step',job,'-o'],universal_newlines=True)
match=[m.groups()for m in re.finditer(r'StepId=('+job+r'\.\d+).*?UserId=10011 .*?NodeList=node6 .*?CPUs=16 .*?SrunHost:Pid=node6:(\d+)',lines)]
assert len(match)==4
probe='''import json,os
r={'available':int(next(x.split()[1]for x in open('/proc/meminfo')if x.startswith('MemAvailable:')))*1024,'cmds':{}}
for p in PIDS:
 f='/proc/'+p
 try:
  assert os.stat(f).st_uid==10011
  r['cmds'][p]=open(f+'/cmdline','rb').read().decode().split(chr(0))
 except FileNotFoundError:pass
print(json.dumps(r))
'''.replace('PIDS',repr([v[1]for v in match]))
d=read(replacement);measured=json.loads(subprocess.check_output(['srun','--jobid='+job,'--overlap','-n1','-c1','python3','-c',probe],universal_newlines=True))
targets=[(step,pid,cc)for step,pid in match if (cc:=measured['cmds'].get(pid,[])) and str(out) in cc and str(source/'project/experiments/control_v1/system_upper.py')in cc]
assert len(targets)==1
forecast=sum(read(q/'pending'/(n+'.json'))['forecast_gib']for n in state['active']if n!=name)+rp['spec']['forecast_gib']
required=(forecast*1.2+16)*(2**30);assert measured['available']>required
record.mkdir()
with zipfile.ZipFile(record/'old-21300-snapshot.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,raw in raws.items():z.writestr(n,raw)
 z.writestr('pending-spec.json',sp.read_bytes());z.writestr('actual-command.json',(q/'commands'/sp.name).read_bytes())
with zipfile.ZipFile(record/'old-21300-snapshot.zip')as z:
 assert z.testzip()is None and all(z.read(n)==raw for n,raw in raws.items())
row=dict(passed=True,whole_system_qualified=False,decision='Search priority only, not impossibility. 16 same-scene attempts with unchanged own best for at least eight rounds; stronger live comparison retained. Preserve all old task raw files, archive exactly captured prefixes, and release this one owned step for the original new placement preflight. No other task, allocation, or acceptance change.',candidate=21300,owned_step=targets[0],job=job,source_commit=read(source/'source-manifest.json')['commit'],preflight_spec=rp['path'],preflight_sha256=rp['sha256'],input_sha256=hashlib.sha256(body).hexdigest(),old_spec_sha256=sha(sp),forecast_gib=forecast,measured_available_bytes=measured['available'],required_available_bytes=required,trend=trend,archive_sha256=sha(record/'old-21300-snapshot.zip'),archive_files={n:hashlib.sha256(raw).hexdigest()for n,raw in raws.items()})
(record/'verified-before.json').write_text(json.dumps(row,indent=2));print(json.dumps(dict(verified=True,step=targets[0][0],required=required,available=measured['available'],new=p.name)),flush=True)
latest=read(q/'queue-state.json');assert name in latest['active']and p.stem not in latest['active']and sha(sp)==row['old_spec_sha256']
assert not any((out/n).exists()for n in ('receipt.json','trees.json','router-output.txt'))
assert not any((out/('trial-'+str(i))/'output.txt').exists()for i in range(16))
subprocess.run(['scancel',targets[0][0]],check=True)
(record/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,retired_exact_owned_step=targets[0][0],snapshot_sha256=sha(record/'verified-before.json'),next=p.name,original_gates=True)))
print(json.dumps(dict(retired=targets[0][0],preflight=p.name,whole_system_qualified=False)),flush=True)
