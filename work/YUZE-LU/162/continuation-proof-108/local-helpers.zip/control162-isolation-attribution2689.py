from pathlib import Path
import json,collections,hashlib
b=Path.cwd();d=b/'control162-link-shift-input2676'
p=d/'physical-graph.json';r=json.loads((d/'receipt.json').read_bytes())
assert r['passed'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['outputs'][p.name]
g=json.loads(p.read_bytes());placement=json.loads((b/'control162-subset2629/placement.json').read_bytes())
edges=collections.Counter();positions=collections.Counter();allrows=[]
for tag,p in [(20,b/'control162-moved-pair2680-20/native-only/connect.log'),(62,b/'control162-moved-pair2680-62/native-only/connect.log'),(202,b/'control162-moved-repair2686-20-2/final.log')]:
 hist=collections.Counter();nets=collections.Counter()
 for l in p.read_text().splitlines():
  if not l.startswith('isolated '):continue
  _,n,x,y,z,*_=l.split();pos=list(map(int,(x,y)));i=placement['terminals'][n].index(pos)
  nconn=g['connections'][n[4:]];a=[nconn['driver'],*nconn['sinks']][i]
  t=g['instances'].get(a['instance'],a['instance']);hist[t]+=1
  nets['PG' if n.startswith('net_PG_')else 'clock' if n=='net_2' else 'other']+=1
  allrows.append(dict(candidate=tag,net=n,position_grid=pos,instance=a['instance'],pin=a['pin'],physical_type=t))
 print(tag,dict(nets),hist.most_common(8))
(d/'isolation-attribution2689.json').write_text(json.dumps(allrows,indent=2))
