from pathlib import Path
import sys,json,hashlib,collections
b=Path.cwd()
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'))
from router_conflict_snapshot import inputs
src=b/'control162-link-shift-input2676/input.txt';old=b/'control162-receive1988/input.txt'
h,n,limits=inputs(src);k,p,plimits=inputs(old);assert h[:3]==k[:3] and h[6]==k[6]==1229 and set(n)==set(p) and set(list(n)[:1229])==set(list(p)[:1229])
actual={(*a,0):key for key,row in n.items()for a in row};assert len(actual)==24760
native=b/'control162-cavity-repair2666-4/native-prefix.txt'
routes={}
with native.open()as f:
 assert int(f.readline())==h[6]
 for key in list(p)[:h[6]]:
  name,c=f.readline().split();assert name==key and c=='2'
  rows=[list(map(int,f.readline().split())) for _ in range(2)]
  routes[key]=list(zip(rows[1][1::3],rows[1][2::3],rows[1][3::3]))
changed={k for k in n if n[k]!=p[k]};budgets={k for k in n if limits[k]!=plimits[k]};foreign={k for k,row in routes.items()if any(actual.get(v,k)!=k for v in row)}
too_long={k for k,row in routes.items() if sum(v[2]==w[2]for v,w in zip(row,row[1:]))>limits[k]}
replace=(set(routes)&changed)|foreign|too_long
stats=dict(changed_all=len(changed),changed_finite=len(set(routes)&changed),limits_changed=len(budgets),new_foreign_pin_cross=len(foreign),new_over_budget=len(too_long),need_reroute=len(replace),native_reroutes=sorted(replace),closed_assessment_pending=True)
print(stats)
d=b/'control162-link-shift-input2676/diff.json';d.write_text(json.dumps(stats,indent=2))

