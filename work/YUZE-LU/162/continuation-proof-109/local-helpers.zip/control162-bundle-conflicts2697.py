from pathlib import Path
import json,hashlib,sys,collections
import numpy as np
b=Path.cwd();tag=sys.argv[1];d=b/('control162-snapshot'+tag)
p=d/'output.txt.global-round-8.txt';inp=d/'input.txt';meta=b/'control162-bundle-opportunity2696.json'
summary=d/'global-snapshot/receipt.json';s=json.loads(summary.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads(meta.read_bytes());g={n:i+1 for i,r in enumerate(m['groups'])for n in r['nets']}
with inp.open()as f:
 h=list(map(int,f.readline().split()));nx,ny,n=h[:3];lock=h[6];ordered=[l.split()[0]for l in f]
 assert h[:3]==[3070,3252,11149]and lock==1229
plane=nx*ny;size=2*plane;occ=np.zeros(size,np.uint8);flags=np.zeros(size,np.uint8);first=np.zeros(size,np.int16);different=np.zeros(size,np.bool_)
cp=collections.Counter()
with p.open()as f:
 assert int(f.readline())==n
 for i,name in enumerate(ordered):
  nm,nr=f.readline().split();assert nm==name
  pp=[]
  for _ in range(int(nr)):
   pts=np.fromstring(f.readline(),dtype=np.int32,sep=' ');assert len(pts)==1+3*pts[0]
   pp.append(pts[1::3]+nx*pts[2::3]+plane*pts[3::3])
  v=np.unique(np.concatenate(pp));occ[v]+=1
  cl=1 if i<lock else 4 if name in g else 2
  flags[v]|=cl
  if cl==4:
   gid=g[name];prior=first[v];diff=(prior>0)&(prior!=gid)
   different[v[diff]]=True;first[v[prior==0]]=gid
   q,c=np.unique(prior[diff],return_counts=True)
   for k,mv in zip(q,c):cp[tuple(sorted((gid,int(k))))]+=int(mv)
 assert not f.read().strip()
a=occ>1;ordinary=a&(flags==4);diagnostic=s['diagnostic'];nconf=int(np.count_nonzero(a));assert nconf==diagnostic['conflict_nodes']
same=int(np.count_nonzero(ordinary&~different));between=int(np.count_nonzero(ordinary&different));natives=int(np.count_nonzero(a&(flags&1>0)));others=nconf-same-between-natives
assert same+between+natives+others==nconf
out=dict(passed=True,whole_system_qualified=False,route_qualified=False,case=tag,grid_conflict_vertices=nconf,within_ordinary_instance_pair=same,between_ordinary_instance_pairs=between,any_native=natives,multicast_without_native=others,between_fraction=between/nconf,
top_bundle_pairs=[dict(groups=[dict(from_instance=m['groups'][i-1]['source'],to_instance=m['groups'][i-1]['sink'])for i in k],excess_conflict_incidences=v)for k,v in cp.most_common(15)],
inputs={str(q):sha(q)for q in [p,inp,meta,summary]},scope='Actual complete routed attempts at round8, conflict analysis only. Individual ordinary pairs grouped by exact driver and sink instance names. The largest bundle pairs use occupancy incidences, not a physical routing pass.')
(b/('control162-bundle-conflicts2697-'+tag+'.json')).write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items()if k not in ('top_bundle_pairs','inputs')});print(out['top_bundle_pairs'][:4])
