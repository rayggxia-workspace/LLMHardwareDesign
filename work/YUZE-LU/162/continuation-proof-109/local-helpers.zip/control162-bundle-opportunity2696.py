from pathlib import Path
import json,collections,hashlib
b=Path.cwd();d=b/'control162-floorplan2608';g=json.loads((d/'boundary-graph.json').read_bytes())
p=b/'control162-receive1988/input.txt';f=p.open();h=list(map(int,f.readline().split()));exact={}
for i,l in enumerate(f):
 n,k,*r=l.split();a=list(map(int,r[:-1]));pts=list(zip(a[::2],a[1::2]));exact[n]=(pts,int(r[-1]),i>=h[6])
chosen=b/'control162-partial-safe2668/safe-pairs.txt';sel=set()
with chosen.open()as f:
 n=int(f.readline())
 for i in range(n):sel.add(f.readline().split()[0]);f.readline();f.readline()
x=collections.defaultdict(list)
for bit,c in g['connections'].items():
 k='net_'+bit;pts,w,is_pair=exact[k]
 if len(pts)!=2 or w>=0 or not is_pair:continue
 assert len(c['sinks'])==1
 a,z=c['driver'],c['sinks'][0];x[a['instance'],z['instance']].append((k,a['pin'],z['pin'],pts))
out=[]
for (a,z),v in x.items():
 ps=[[t[3][i]for t in v]for i in range(2)]
 region=[(max(p[0]for p in q)-min(p[0]for p in q),max(p[1]for p in q)-min(p[1]for p in q))for q in ps]
 out.append(dict(source=a,sink=z,groups=(g['instances'].get(a,a),g['instances'].get(z,z)),total=len(v),already_seeded=sum(r[0]in sel for r in v),pin_spans=region,nets=[r[0]for r in v]))
out.sort(key=lambda v:-v['total']);c=collections.Counter(r['total']for r in out)
print('ordinary_groups',len(out),'pairs',sum(r['total']for r in out),'at least 8',sum(r['total']for r in out if r['total']>=8),'hist',c.most_common(12))
for x in out[:12]:print({k:v for k,v in x.items()if k!='nets'})
(b/'control162-bundle-opportunity2696.json').write_text(json.dumps(dict(source_sha=hashlib.sha256(p.read_bytes()).hexdigest(),hist=dict(c),groups=out),indent=2))
