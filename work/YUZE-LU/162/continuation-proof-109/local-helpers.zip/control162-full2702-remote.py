
from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');scene=b/'r256-balanced-reset-composition-1888';old=scene/'upper-candidates/24600';seed=27020;new=scene/'upper-candidates'/str(seed)
record=b/'route-selection-102/sready2702-physical-access-fullchain';assert not record.exists() and not new.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=b/'r256-partial-ordinary-seed-audit-2701/receipt.json';ar=json.loads(audit.read_text());assert ar['passed'] and ar['ordinary_seed_nets']==2174 and ar['critical_paths']==1229
source=b/'source-2587';manifest=json.loads((source/'source-manifest.json').read_text());assert manifest['commit']==ar['source_commit']
data=b/'r256-partial-ordinary-seed-data-2701';native=data/'native.json';access=data/'ordinary.json';assert all(sha(p)==ar['inputs'][str(p)]for p in (native,access))
base=b/'route-selection-102/sready2460-arbiter-fullchain/tasks.json';prev=json.loads(base.read_text())
cfg0=scene/'acceptance-24600.json';cfg=scene/('acceptance-'+str(seed)+'.json');assert not cfg.exists()
def remap(s):return s.replace('/upper-candidates/24600/','/upper-candidates/'+str(seed)+'/').replace('acceptance-24600.json','acceptance-'+str(seed)+'.json')
accept=json.loads(json.dumps(json.loads(cfg0.read_text())).replace('/upper-candidates/24600/','/upper-candidates/'+str(seed)+'/'))
assert set(accept)=={'geometry','pg_audit','function_run','topology','signal_graph','timing'} and set(accept['timing'])=={'low','base','high'}
assert all(Path(p)==new/'timing'/v for v,p in accept['timing'].items()) and accept['geometry']==str(new/'geometry')and accept['pg_audit']==str(new/'pg-audit')
assert accept['function_run']==str(scene/'function') and accept['signal_graph']==str(scene/'topology/boundary-graph.json')
rows=[]
for row in prev['tasks']:
 oldpath=Path(row['path']);assert sha(oldpath)==row['sha256']
 spec=json.loads(json.dumps(row['spec']));spec['source_root']=str(source);a=[remap(x)for x in spec['args']]
 spec['requires']=[remap(x)for x in spec['requires']]
 out=Path(a[a.index('--out')+1]);assert new in out.parents
 if spec['script']=='system_upper.py':
  assert out==new/'route' and spec['forecast_gib']==65 and a[a.index('--route-trials')+1]=='16'
  a[a.index('--seed')+1]=str(seed);a[a.index('--route-native-prefix-input')+1]=str(native)
  j=a.index('--route-ordinary-seed-input');a[j+1]=str(access)
  for flag,value in [('--route-ordinary-coarse','8'),('--route-ordinary-present-growth','4'),('--route-nonpreferred-cost','32'),('--route-heuristic-weight','1'),('--route-ordinary-coarse-rounds','16')]: a[a.index(flag)+1]=value
  assert '--route-native-prefix-flexible'in a and '--defer-access-vias'in a and a[a.index('--route-pin-access')+1]=='none'
  spec['requires'].append(str(audit))
 elif spec['script']=='system_sta.py':
  v=a[a.index('--rc-variant')+1];assert spec['forecast_gib']==224 and out==new/'timing'/v
  assert '--stitch-native-access'in a and '--audit-native-coverage'in a and a[a.index('--upper-geometry')+1]==accept['geometry']
 else:
  assert a[a.index('--route')+1]==str(new/'route') and a[a.index('--graph')+1]==str(new/'route/physical-graph.json')
  if '--acceptance'in a:
   assert out==new/'delivery' and a[a.index('--acceptance')+1]==str(cfg)
   assert all(str(scene/s)in spec['requires']for s in ['function-audit/receipt.json','internal-program-traces/receipt.json','source-binding-audit/receipt.json'])
 spec['args']=a
 if spec['script']=='system_upper.py':oldpath=b/'dynamic-04/node25/pending'/oldpath.name.replace('00-a0-','00-a-')
 target=oldpath.with_name(oldpath.name.replace('sready2460','sready2702').replace('24600',str(seed)));assert not target.exists()
 rows.append(dict(path=str(target),spec=spec,sha256=hashlib.sha256(json.dumps(spec).encode()).hexdigest()))
assert len(rows)==7 and len([r for r in rows if r['spec']['script']=='system_sta.py'])==3
for r in rows:
 p=Path(r['path']);assert p.parent.name=='pending' and p.parent.parent.is_dir()
 a=r['spec']['args'];assert a[a.index('--manifest')+1]==str(scene/'selected/physical.json')
cfg.write_text(json.dumps(accept,indent=2))
record.mkdir()
r=dict(passed=True,whole_system_qualified=False,seed=seed,source_commit=ar['source_commit'],base_tasks_sha256=sha(base),acceptance_config=str(cfg),acceptance_config_sha256=sha(cfg),tasks=rows,
 scope='Production full routing plus original six mandatory successors. 2,174 clean complete pair seed paths imported only at transition, not locked. Exact static audit found zero isolated real landing points before and after the pair seed. All 1,229 native paths use original budgets and remain flexible. Uses stride 8 and present growth 4 from the strongest observed comparable full search. Actual original grid and final acceptance unchanged. Sixteen direct independent C++ attempts per 16CPU slot; original memory admission, no unrelated/parent changes, no merge.')
(record/'tasks.json').write_text(json.dumps(r,indent=2))
for row in rows:
 p=Path(row['path']);t=p.with_suffix('.tmp');assert not t.exists()
 t.write_text(json.dumps(row['spec']));assert sha(t)==row['sha256'];t.rename(p)
print(json.dumps(dict(queued=7,actual_seed=seed,proof=str(record/'tasks.json'),whole_system_qualified=False)))
