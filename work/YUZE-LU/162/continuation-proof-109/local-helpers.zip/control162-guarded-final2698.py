from pathlib import Path
import hashlib,json,subprocess,collections,sys
b=Path.cwd();tag=sys.argv[1];out=b/('control162-guarded-final2698-'+tag);out.mkdir()
original=b/'control162-receive1988/input.txt';pref=b/'control162-cavity-repair2666-4/native-prefix.txt';seed=b/('control162-guarded-pair2691/'+tag+'.txt');preserve=b/'control162-partial-safe2668/safe-pairs.txt'
names=[];ends={};all_ends={}
with original.open()as f:
 hd=list(map(int,f.readline().split()));nx,ny,n=hd[:3];crit=hd[6]
 for l in f:
  k,c,*r=l.split();a=list(map(int,r[:-1]));pts=list(zip(a[::2],a[1::2],[0]*int(c)));assert len(pts)==int(c)
  names.append(k);ends[k]=pts
  for v in pts:assert v not in all_ends;all_ends[v]=k
def get(path):
 d={}
 with path.open()as f:
  n=int(f.readline())
  for _ in range(n):
   k,c=f.readline().split();a=set()
   for i in range(int(c)):
    v=list(map(int,f.readline().split()));assert 3*v[0]+1==len(v);a.update(zip(v[1::3],v[2::3],v[3::3]))
   d[k]=a
  assert not f.read().strip()
 return d
fixed=get(pref);warm=get(seed);assert set(fixed)==set(names[:crit]) and len(warm)>2200 and not set(fixed)&set(warm)
def check(label,paths):
 outdir=out/label;outdir.mkdir()
 owner={}
 for n,path in paths.items():
  assert set(ends[n])<=path
  for v in path:assert owner.setdefault(v,n)==n and all_ends.get(v,n)==n
 remaining={n:v for n,v in ends.items()if n not in paths}
 inp=outdir/'network.input'
 with inp.open('x',newline=chr(10))as f:
  print(4,4,nx-5,ny-5,len(owner),len(remaining),file=f)
  for v in owner:print(*v,file=f)
  for n,v in remaining.items():print(n,len(v),*(q for w in v for q in w),file=f)
 e=b/'control162-connect2498.exe';p=subprocess.run([str(e),str(inp)],capture_output=True,timeout=40);assert p.returncode in (0,2),p.stderr
 logs=p.stdout.decode().splitlines();assert logs[-1].startswith('summary ')
 (outdir/'connect.log').write_bytes(p.stdout+p.stderr)
 print(label,logs[-1],flush=True)
 return logs,owner
def nbr(v):
 x,y,l=v
 if x>4:yield x-1,y,l
 if x<nx-5:yield x+1,y,l
 if y>4:yield x,y-1,l
 if y<ny-5:yield x,y+1,l
 if not (x+y)%2:yield x,y,1-l
def iso(log):
 return {tuple(s.split()[1:5])for s in log if s.startswith('isolated ')}

base=get(preserve);assert len(base)==1747
last=b/('control162-guarded-static2693-'+tag)/('trim-'+sys.argv[2])/'network.input'
with last.open()as f:
 h=list(map(int,f.readline().split()))
 for _ in range(h[4]):f.readline()
 remaining={l.split()[0]for l in f}
 assert len(remaining)==h[5]
keep=set(warm)-remaining;assert set(base)<=keep
history=[]
for i in range(12):
 logs,owner=check(str(i),{**fixed,**{k:warm[k]for k in keep}})
 isolated=iso(logs);history.append(dict(nets=len(keep),closed=len(isolated)))
 if not isolated:break
 marks=collections.Counter()
 for n,x,y,l in isolated:
  v=tuple(map(int,(x,y,l)));front=[v];seen={v}
  for v in front:
   for w in nbr(v):
    if all_ends.get(w,n)!=n:continue
    if w in owner:
     if owner[w] in keep and owner[w] not in base:marks[owner[w]]+=1
    elif w not in seen:seen.add(w);front.append(w)
   assert len(front)<100000,'Avoid mistakenly flooding dominant component'
 if not marks:break
 k=sorted(marks,key=lambda k:(-marks[k],len(warm[k]),k))[0];history[-1]['removed']=k;keep.remove(k)
assert not isolated
target=out/'safe-pairs.txt'
with target.open('x',newline=chr(10))as f, seed.open()as src:
 print(len(keep),file=f);n=int(src.readline());written=0
 for _ in range(n):
  a=src.readline();k=a.split()[0];x=src.readline();y=src.readline()
  if k not in keep:continue
  print(a.rstrip(),x.rstrip(),y.rstrip(),sep=chr(10),file=f);written+=1
 assert written==len(keep)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=dict(passed=True,whole_system_qualified=False,route_qualified=False,original_pairs_retained=1747,final_pair_nets=len(keep),exact_new_isolates=0,closed=0,history=history,paths_sha256=sha(target),inputs={str(p):sha(p)for p in (pref,seed,preserve,last,original)})
(out/'receipt.json').write_text(json.dumps(e,indent=2));print(history,flush=True)
