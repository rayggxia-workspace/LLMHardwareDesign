#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <random>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>
using namespace std;
#include "ordinary_zero_pattern.h"
struct Q { int p,d,v; bool operator<(const Q&b)const {return p!=b.p?p>b.p:d!=b.d?d<b.d:v>b.v;} };
int main(int argc,char** argv){
 try{
  if(argc!=7)throw runtime_error("input prefix mode seed output prior_ordinary_seed");
  ifstream f(argv[1]),pref(argv[2]);ofstream out(argv[5]);
  string mode=argv[3];int seed=stoi(argv[4]);mt19937 rng(seed);int nx,ny,n,s,round,w,crit;
  f>>nx>>ny>>n>>s>>round>>w>>crit;string junk;getline(f,junk);
  if(!f||!pref||!out||n!=11149||crit!=1229||nx!=3070||ny!=3252)throw runtime_error("actual input envelope");
  int plane=nx*ny,sz=2*plane;
  auto id=[&](int x,int y,int z){return x+nx*y+plane*z;};
  auto coord=[&](int v){return array<int,3>{v%nx,(v%plane)/nx,v/plane};};
  auto inside=[&](int x,int y){return x>=4&&x<nx-4&&y>=4&&y<ny-4;};
  vector<int> owner(sz,-1);vector<uint32_t>vis(sz);vector<int>dist(sz),parent(sz);
  vector<string>names(n);vector<vector<int>>p(n),result(n);vector<int>pair;
  for(int j=0;j<n;++j){int c,b;f>>names[j]>>c;if(!f||c<2)throw runtime_error("net input");while(c--){int x,y;f>>x>>y;
   int v=id(x,y,0);if(!inside(x,y)||owner[v]>=0)throw runtime_error("true pin");owner[v]=j;p[j].push_back(v);}
   f>>b;if(!f)throw runtime_error("budget");if(j>=crit&&b==-1&&p[j].size()==2)pair.push_back(j);}
  int pc;pref>>pc;if(pc!=crit)throw runtime_error("prefix count");
  for(int j=0;j<crit;++j){string key;int k;pref>>key>>k;if(key!=names[j]||k!=2)throw runtime_error("prefix binding");
   while(k--){int l;pref>>l;while(l--){int x,y,z;pref>>x>>y>>z;int v=id(x,y,z);
    if(!pref||!inside(x,y)||z<0||z>1||(owner[v]>=0&&owner[v]!=j))throw runtime_error("foreign native point");owner[v]=j;}}}
  auto neighbors=[&](int v,auto add){auto [x,y,z]=coord(v);
    if(x>4)add(v-1,z==0?1:3);
    if(x<nx-5)add(v+1,z==0?1:3);
    if(y>4)add(v-nx,z==1?1:3);
    if(y<ny-5)add(v+nx,z==1?1:3);
    if(!((x+y)%2))add(id(x,y,1-z),4);};
 
 ifstream initial(argv[6]);int ic;initial>>ic;if(!initial||ic!=1747)throw runtime_error("expected original actual clean ordinary seed");
 vector<int> guarded(sz,-1);
 vector<vector<int>> own_guard(n);
 int loaded=0;uint64_t loaded_vertices=0;
 vector<std::pair<string,int>> name_ids;for(int i=0;i<n;++i)name_ids.push_back({names[i],i});sort(name_ids.begin(),name_ids.end());
 for(int i=0;i<ic;++i){string name;int bs;initial>>name>>bs;
  auto f=find_if(name_ids.begin(),name_ids.end(),[&](const auto&a){return a.first==name;});
  if(f==name_ids.end()||f->second<crit||bs!=2)throw runtime_error("bad imported ordinary name");int j=f->second;
  int l,x,y,z;initial>>l>>x>>y>>z;if(l!=1||id(x,y,z)!=p[j][0]||!result[j].empty())throw runtime_error("bad imported ordinary root");
  initial>>l;while(l--){initial>>x>>y>>z;int v=id(x,y,z);
   if(!initial||!inside(x,y)||z<0||z>1||(owner[v]>=0&&owner[v]!=j))throw runtime_error("bad imported ordinary point");
   owner[v]=j;result[j].push_back(v);
  }
  if(result[j].front()!=p[j][1]||result[j].back()!=p[j][0])throw runtime_error("bad imported endpoints");
  ++loaded;loaded_vertices+=result[j].size();
 }
 if(loaded!=1747||loaded_vertices!=900187)throw runtime_error("prior ordinary seed byte contract");
 vector<std::pair<int,int>> unguarded;for(int j=crit;j<n;++j)if(result[j].empty())for(int v:p[j])unguarded.push_back({j,v});
 auto degree0=[&](int v){int c=0;neighbors(v,[&](int u,int){if(owner[u]<0)++c;});return c;};
 stable_sort(unguarded.begin(),unguarded.end(),[&](const auto&a,const auto&b){return degree0(a.second)<degree0(b.second);});
 int reserved=0;
 for(auto [j,v]:unguarded){
  vector<std::pair<int,int>> opt;
  neighbors(v,[&](int u,int){if(owner[u]<0&&guarded[u]<0)opt.push_back({degree0(u),u});});
  if(opt.empty())continue;
  sort(opt.begin(),opt.end(),greater<std::pair<int,int>>());int u=opt[0].second;
  guarded[u]=j;own_guard[j].push_back(u);++reserved;
 }
 cout<<"existing "<<loaded<<" vertices "<<loaded_vertices<<" real remaining pins "<<unguarded.size()<<" individually reserved exits "<<reserved<<endl;
 auto metric=[&](int j){
   auto a=coord(p[j][0]),b=coord(p[j][1]);
   return abs(a[0]-b[0])+abs(a[1]-b[1]);};
  auto degree=[&](int j){int k=5;for(int v:p[j]){int c=0;neighbors(v,[&](int u,int){c+=owner[u]<0||owner[u]==j;});k=min(k,c);}return k;};
  uint32_t epoch=0;uint64_t expansions=0,vertices=0,total_hpwl=0;int picked=loaded;vertices=loaded_vertices;
  auto route=[&](int j,int budget,int weight){
   int a=p[j][1],z=p[j][0];auto [tx,ty,tl]=coord(z);
   auto free=[&](int v){return (owner[v]<0||owner[v]==j)&&(guarded[v]<0||guarded[v]==j);};uint64_t probes=0;
   vector<int> path=ordinary_zero_pattern(nx,ny,a,{z},free,[&](int u){return u==z;},probes);
   if(!path.empty())return path;
   if(degree(j)==0)return vector<int>{};
   auto h=[&](int v){return abs(v%nx-tx)+abs((v%plane)/nx-ty);};
   ++epoch;priority_queue<Q>q;q.push({weight*h(a),0,a});vis[a]=epoch;dist[a]=0;parent[a]=-1;
   while(!q.empty()&&budget--){
    auto [p,d,v]=q.top();q.pop();if(vis[v]!=epoch||dist[v]!=d)continue;
    ++expansions;
    if(v==z){for(int w=z;w>=0;w=parent[w])path.push_back(w);reverse(path.begin(),path.end());return path;}
    neighbors(v,[&](int u,int c){
      int x=d+c;if(!free(u)||(vis[u]==epoch&&dist[u]<=x))return;
      vis[u]=epoch;dist[u]=x;parent[u]=v;q.push({x+weight*h(u),x,u});
    });
   }
   return vector<int>{};
  };
  for(int k=0;k<3;++k){
   vector<int> order;for(int j:pair)if(result[j].empty())order.push_back(j);
   shuffle(order.begin(),order.end(),rng);
   vector<int> ds(n);for(int j:order)ds[j]=degree(j);
   stable_sort(order.begin(),order.end(),[&](int a,int b){
     if(mode=="bottleneck"&&ds[a]!=ds[b])return ds[a]<ds[b];
     if(mode=="long")return metric(a)>metric(b);
     return metric(a)<metric(b);});
   for(size_t i=0;i<order.size();++i){int j=order[i];
    auto path=route(j,k==0?4800:k==1?16000:52000,k==0?5:k==1?3:2);
    if(!path.empty()){
     if(path.front()!=p[j][1]||path.back()!=p[j][0])throw runtime_error("wrong pair");
     for(int v:path){if(owner[v]>=0&&owner[v]!=j)throw runtime_error("foreign route");owner[v]=j;}
     total_hpwl+=metric(j);vertices+=path.size();++picked;result[j]=move(path);
     for(int v:own_guard[j]){if(guarded[v]!=j)throw runtime_error("invalid guard owner");guarded[v]=-1;}
    }
    if((i+1)%1200==0)cout<<"pass "<<k<<" tried "<<i+1<<" accepted "<<picked<<" expansions "<<expansions<<endl;
   }
   cout<<"finished pass "<<k<<" accepted "<<picked<<" vertices "<<vertices<<" selected HPWL "<<total_hpwl<<" expansions "<<expansions<<endl;
  }
  out<<picked<<'\n';
  for(int j=crit;j<n;++j)if(!result[j].empty()){
   auto [x,y,z]=coord(p[j][0]);out<<names[j]<<" 2\n1 "<<x<<" "<<y<<" "<<z<<"\n"<<result[j].size();
   for(int v:result[j]){auto [x,y,z]=coord(v);out<<" "<<x<<" "<<y<<" "<<z;}out<<'\n';}
  if(!out)throw runtime_error("write failed");
 }catch(const exception&e){cerr<<e.what()<<endl;return 1;}
}

