from pathlib import Path
import sys,subprocess,hashlib,json
b=Path(__file__).parent;out=b/'control162-snapshot2695';assert not out.exists();out.mkdir()
d='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888/upper-candidates/22000/route/trial-0'
names=['output.txt.global-round-8.txt','input.txt']
ssh=['ssh','-o','ConnectTimeout=15','yuzelu@10.129.166.172']
raw=subprocess.check_output([*ssh,'sha256sum '+' '.join(d+'/'+n for n in names)],timeout=35);expected={line.split()[-1].split('/')[-1]:line.split()[0]for line in raw.decode().splitlines()}
subprocess.run(['scp','-q',*[f'yuzelu@10.129.166.172:{d}/{n}'for n in names],str(out)],check=True,timeout=140)
log=subprocess.check_output([*ssh,"cd "+d+" && sed -n '/global_snapshot_round/q;p' router.log && grep -m1 'global_snapshot_round' router.log"],timeout=30)
(out/'log.txt').write_bytes(log);assert b'"global_snapshot_round":8' in log
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(out/n)==expected[n]for n in names)
graph=b/'control162-route-attribution2428/boundary-graph.json'
p=dict(input=out/'input.txt',snapshot=out/names[0],log=out/'log.txt',graph=graph)
c=dict(schema='control162-global-round-diagnostic-v1',round=8,phase_stride=8,**{k:str(v)for k,v in p.items()},**{k+'_sha256':sha(v)for k,v in p.items()})
(out/'config.json').write_text(json.dumps(c,indent=2))
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'))
from global_snapshot_analysis import run
r=run(out/'config.json',out/'global-snapshot');print(json.dumps({k:r['diagnostic'][k]for k in ('conflict_nodes','excess_occupancy','occupied_cells','summed_tree_vertices','candidate_phase_conflicts')}))
