"""Build and run two isolated local search diagnostics from the same verified round."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

b = Path.cwd()
code = b / "LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1"
inp = b / "control162-snapshot2695/input.txt"
paths = b / "control162-snapshot2695/output.txt.global-round-8.txt"
receipt = b / "control162-snapshot2695/global-snapshot/receipt.json"
def sha(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()
r = json.loads(receipt.read_bytes())
assert r["passed"] and not r["whole_system_qualified"] and r["round"] == 8
assert sha(inp) == r["inputs"][str(inp)] and sha(paths) == r["inputs"][str(paths)]
source = code / "tree_router.cpp"
d = b / "control162-compare-monotone2716"
d.mkdir()
cpp = d / "router.cpp"
t = source.read_text(encoding="utf-8")
def replace(a, x):
    global t
    assert t.count(a) == 1, a
    t = t.replace(a, x)
replace("#include <cstdint>", "#include <cstdint>\n#include <cstdlib>")
replace(" bool complete=false,native_stage=native_prefix_first;uint64_t previous_conflicts=size;", r'''
 const char* snapshot=getenv("CONTROL162_DIAG_SNAPSHOT");
 bool strict=getenv("CONTROL162_DIAG_MONOTONE")!=nullptr;
 if(!snapshot||!native_prefix_first||!native_flexible||!ordinary_seed_input.empty()||!native_seed_input.empty()||global_batch||ordinary_refresh||rounds<9)
  throw runtime_error("local diagnostic requires an unmodified flexible search and a prevalidated snapshot");
 uint64_t previous_conflicts=0;
 {
  ifstream in(snapshot);int cnt=-1;in>>cnt;if(!in||cnt!=count)throw runtime_error("snapshot count mismatch");
  vector<int> seen(size,-1);
  for(int n=0;n<count;++n){
   string name;int k=-1;in>>name>>k;if(!in||name!=names[n]||k<1||k>int(ends[n].size()))throw runtime_error("snapshot net or branch count mismatch");
   for(int j=0;j<k;++j){
    int len=-1;in>>len;if(!in||len<1||len>size)throw runtime_error("snapshot branch length invalid");
    vector<int> branch;int px=-1,py=-1,pl=-1;
    for(int i=0;i<len;++i){
     int x=-1,y=-1,l=-1;in>>x>>y>>l;
     if(!in||!inside(x,y)||l<0||l>1)throw runtime_error("snapshot illegal vertex");
     int v=x+y*nx+l*plane;
     if(i&&(abs(x-px)+abs(y-py)+abs(l-pl)!=1||(l!=pl&&(x+y)%2)))throw runtime_error("snapshot illegal edge");
     if(fixed[v]>=0&&fixed[v]!=n)throw runtime_error("snapshot touches foreign landing");
     if(seen[v]!=n){seen[v]=n;trees[n].push_back(v);++usage[v];}
     px=x;py=y;pl=l;branch.push_back(v);
    }
    branches[n].push_back(move(branch));
   }
   for(int v:ends[n])if(seen[v]!=n)throw runtime_error("snapshot missing landing");
  }
  string tail;if(in>>tail)throw runtime_error("snapshot trailing data");
  for(int v=0;v<size;++v)if(usage[v]>1){++previous_conflicts;history[v]=usage[v]-1;}
  if(previous_conflicts!=580336)throw runtime_error("snapshot does not match audited conflict count");
  cout<<"{\"diagnostic_only\":true,\"monotone\":"<<(strict?"true":"false")<<",\"starting_conflicts\":"<<previous_conflicts<<"}"<<endl;
 }
 bool complete=false,native_stage=false;''')
replace(" for(int iteration=0;iteration<rounds;++iteration){", " for(int iteration=8;iteration<rounds;++iteration){\n  uint64_t rolled_back=0,accepted_improving=0;")
replace("   ++epoch;if(!epoch)throw runtime_error(\"tree epoch overflow\");vector<int>tree;branches[n].clear();", r'''
   vector<vector<int>> old_branches;
   const bool guard=strict&&n>=locked_count&&!trees[n].empty();
   if(guard)old_branches=move(branches[n]);
   ++epoch;if(!epoch)throw runtime_error("tree epoch overflow");vector<int>tree;branches[n].clear();''')
replace("   trees[n]=move(tree);for(int v:trees[n])++usage[v];++number;", r'''
   if(guard){
    auto score=[&](const vector<int>& path){
     uint64_t new_conflicts=0,added_excess=0;
     for(int v:path){new_conflicts+=usage[v]==1;added_excess+=usage[v]>0;}
     return make_tuple(new_conflicts,added_excess,path.size());
    };
    if(score(tree)>=score(trees[n])){tree=move(trees[n]);branches[n]=move(old_branches);++rolled_back;}
    else ++accepted_improving;
   }
   trees[n]=move(tree);for(int v:trees[n])++usage[v];++number;''')
replace("  previous_conflicts=conflicts;", r'''  cout<<"{\"round\":"<<iteration<<",\"diagnostic_monotone_rollbacks\":"<<rolled_back<<",\"diagnostic_monotone_improvements\":"<<accepted_improving<<"}"<<endl;
  previous_conflicts=conflicts;''')
cpp.write_text(t, encoding="utf-8")
subprocess.run(["g++", "-std=c++17", "-O3", "-DNOMINMAX", "-I", str(code), str(cpp), "-o", str(d / "router.exe")], check=True)
head, data = inp.read_bytes().split(b"\n", 1)
f = head.split()
f[4] = b"9"
input9 = d / "input.txt"
input9.write_bytes(b" ".join(f) + b"\n" + data)
options = json.loads((b / "control162-options2716.json").read_bytes())
(d / "binding.json").write_text(json.dumps({"whole_system_qualified": False, "diagnostic_only": True,
    "inputs": {str(p): sha(p) for p in (source, cpp, inp, paths, receipt, input9, d / "router.exe")}, "options": options}, indent=2))
jobs = []
for mode in ("reference", "guard"):
    e = os.environ.copy()
    e["CONTROL162_DIAG_SNAPSHOT"] = str(paths.relative_to(b))
    if mode == "guard":
        e["CONTROL162_DIAG_MONOTONE"] = "1"
    else:
        e.pop("CONTROL162_DIAG_MONOTONE", None)
    f = (d / (mode + ".log")).open("xb")
    p = subprocess.Popen([str(d / "router.exe"), str(input9.relative_to(b)), str((d / (mode + ".paths")).relative_to(b)), *options],
                         stdout=f, stderr=subprocess.STDOUT, env=e)
    jobs.append((p, f, mode))
for p, f, mode in jobs:
    print(mode, p.wait(), flush=True)
    f.close()
