"""Local diagnostics only; read a complete, already independently checked attempt."""
import collections
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import distance_transform_cdt


def sha(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def main(tag):
    root = Path.cwd()
    run = root / ("control162-snapshot" + tag)
    snap = run / "output.txt.global-round-8.txt"
    graph = run / "input.txt"
    receipt = run / "global-snapshot" / "receipt.json"
    groups = root / "control162-bundle-opportunity2696.json"
    reference = root / "control162-receive1988" / "input.txt"
    g = json.loads(groups.read_bytes())
    assert sha(reference) == g["source_sha"]
    with graph.open("rb") as f, reference.open("rb") as gref:
        f.readline()
        gref.readline()
        assert f.read() == gref.read()
    group = {net: i + 1 for i, r in enumerate(g["groups"]) for net in r["nets"]}
    with graph.open() as f:
        nx, ny, count, *header = map(int, f.readline().split())
        native = header[3]
        plane = nx * ny
        sites = np.ones((ny, nx), dtype=bool)
        order = []
        for line in f:
            n, k, *row = line.split()
            assert len(row) == 2 * int(k) + 1
            x, y = np.array(row[:-1], dtype=np.int32).reshape(-1, 2).T
            sites[y, x] = False
            order.append(n)
        assert len(order) == count
    d = distance_transform_cdt(sites, metric="taxicab").ravel()
    flags = np.zeros(2 * plane, dtype=np.uint8)
    first = np.zeros(2 * plane, dtype=np.int16)
    occ = np.zeros(2 * plane, dtype=np.uint16)
    crosses = np.zeros(2 * plane, dtype=bool)
    direction = np.zeros(2 * plane, dtype=np.uint8)
    with snap.open() as f:
        assert int(f.readline()) == count
        for i, name in enumerate(order):
            key, npath = f.readline().split()
            assert key == name
            points = []
            for _ in range(int(npath)):
                p = np.fromstring(f.readline(), dtype=np.int32, sep=" ")
                assert p.size == 1 + 3 * p[0]
                xyz = p[1:].reshape(-1, 3)
                axis = np.abs(np.diff(xyz, axis=0))
                assert (axis.sum(axis=1) == 1).all()
                path = xyz @ np.array([1, nx, plane], dtype=np.int32)
                ports = (axis @ np.array([1, 2, 4], dtype=np.uint8)).astype(np.uint8)
                np.bitwise_or.at(direction, path[:-1], ports)
                np.bitwise_or.at(direction, path[1:], ports)
                points.append(path)
            v = np.unique(np.concatenate(points))
            occ[v] += 1
            b = group.get(name, 0)
            flags[v] |= 1 if i < native else 4 if b else 2
            if b:
                prior = first[v]
                crosses[v[(prior != 0) & (prior != b)]] = True
                first[v[prior == 0]] = b
        assert not f.read().strip()
    conflict = occ > 1
    checks = json.loads(receipt.read_bytes())["diagnostic"]
    assert int(conflict.sum()) == checks["conflict_nodes"]
    assert int(occ.sum()) == checks["summed_tree_vertices"]
    assert checks["all_trees_flood_verified"] and checks["all_wire_budgets_verified"]
    classes = {"cross_instance_pair": conflict & (flags == 4) & crosses,
               "within_instance_pair": conflict & (flags == 4) & ~crosses,
               "native": conflict & ((flags & 1) != 0),
               "multicast": conflict & ((flags & 1) == 0) & ((flags & 2) != 0)}
    report = {}
    bins = np.array([0, 5, 17, 33, 65, 129, 257, nx + ny])
    tile = 128
    assert sum(int(q.sum()) for q in classes.values()) == int(conflict.sum())
    for k, mask in classes.items():
        report[k] = {}
        for layer in range(2):
            v = np.flatnonzero(mask[layer * plane:(layer + 1) * plane])
            layer_range = slice(layer * plane, (layer + 1) * plane)
            longitudinal = 1 << layer
            parallel = v[direction[layer * plane + v] == longitudinal]
            traffic = np.flatnonzero((direction[layer_range] == longitudinal) & (occ[layer_range] != 0))
            track = (lambda a: a // nx) if layer == 0 else (lambda a: a % nx)
            tiles = collections.Counter(zip((v % nx // tile).tolist(), (v // nx // tile).tolist()))
            counts = np.histogram(d[v], bins=bins)[0]
            report[k]["M" + str(11 + layer)] = {
                "count": int(v.size), "by_nearest_landing_distance": counts.tolist(),
                "top_10_tiles": [[x * tile, y * tile, n] for (x, y), n in tiles.most_common(10)],
                "top_10_tile_fraction": sum(n for _, n in tiles.most_common(10)) / max(1, v.size),
                "incident_axis_union_histogram": np.bincount(direction[layer * plane + v], minlength=8).tolist(),
                "preferred_axis_only_track_mod8": np.bincount(track(parallel) % 8, minlength=8).tolist(),
                "any_preferred_axis_only_occupancy_track_mod8": np.bincount(track(traffic) % 8, minlength=8).tolist(),
            }
    result = {"stage": "diagnostic-conflict-locality-only", "whole_system_qualified": False,
              "distance_metric": "Manhattan to nearest actual landing, ignoring obstacles", "distance_bins_grid_steps": bins.tolist(),
              "axis_histogram_bits": {"x": 1, "y": 2, "via": 4},
              "tile_grid_steps": tile, "inputs": {str(x): sha(x) for x in (snap, graph, reference, receipt, groups)},
              "landing_xy_count": int((~sites).sum()), "results": report}
    with (root / ("control162-conflict-locality2713-" + tag + ".json")).open("x") as f:
        json.dump(result, f, indent=2)
    for k, layers in report.items():
        print(k, [(l, x["count"], x["by_nearest_landing_distance"], round(x["top_10_tile_fraction"], 3),
                   x["incident_axis_union_histogram"], x["preferred_axis_only_track_mod8"]) for l, x in layers.items()])


if __name__ == "__main__":
    main(sys.argv[1])
