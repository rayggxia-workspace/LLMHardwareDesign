"""Bounded monotone repair diagnostic for ordinary two-terminal straight runs."""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np


def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


tag = sys.argv[1]
base = Path("control162-snapshot" + tag)
src = base / "output.txt.global-round-8.txt"
graph = base / "input.txt"
receipt = base / "global-snapshot" / "receipt.json"
report = json.loads(receipt.read_bytes())["diagnostic"]
assert report["all_trees_flood_verified"] and report["all_wire_budgets_verified"]
with graph.open() as f:
    nx, ny, total, _, _, _, prefix, *_ = map(int, f.readline().split())
    plane = nx * ny
    order, finite, terminals = [], [], []
    owner = np.full(plane * 2, -1, dtype=np.int16)
    for row in f:
        name, count, *body = row.split()
        i = len(order)
        order.append(name)
        finite.append(int(body[-1]))
        p = np.array(body[:-1], dtype=np.int32).reshape(-1, 2)
        assert len(p) == int(count)
        landing = p[:, 0] + nx * p[:, 1]
        assert (owner[landing] == -1).all()
        owner[landing] = i
        terminals.append(landing)
    assert total == len(order)
occ = np.zeros(plane * 2, dtype=np.uint16)
old = []
weights = np.array([1, nx, plane], dtype=np.int32)
with src.open() as f:
    assert int(f.readline()) == total
    for i, name in enumerate(order):
        n, k = f.readline().split()
        assert n == name
        bs = []
        for _ in range(int(k)):
            p = np.fromstring(f.readline(), dtype=np.int32, sep=" ")
            assert p.size == 3 * p[0] + 1
            bs.append(p[1:].reshape(-1, 3) @ weights)
        occ[np.unique(np.concatenate(bs))] += 1
        old.append(bs)
    assert not f.read().strip()
assert int((occ > 1).sum()) == report["conflict_nodes"]
assert int(occ.sum()) == report["summed_tree_vertices"]
initial = report["conflict_nodes"]
working = [bs[:] for bs in old]
changes = 0
total_removed = 0
history = []
for sweep in range(3):
    eligible = []
    for i in range(prefix, total):
        if finite[i] >= 0 or len(terminals[i]) != 2:
            continue
        bs = working[i]
        if len(bs) != 2 or len(bs[0]) != 1 or len(bs[1]) < 9:
            continue
        p = bs[1]
        if len(np.unique(p)) != len(p) or bs[0][0] not in (p[0], p[-1]):
            continue
        if (occ[p] > 1).any():
            eligible.append((int((occ[p] > 1).sum()), i))
    accepted = 0
    for _, i in sorted(eligible, reverse=True):
        p = working[i][1]
        used = set(p.tolist())
        step = np.diff(p)
        starts = np.r_[0, np.flatnonzero(step[1:] != step[:-1]) + 1, step.size]
        tries = []
        for a, b in zip(starts[:-1], starts[1:]):
            a, b = int(a), int(b)
            delta = int(step[a])
            layer = int(p[a] // plane)
            if abs(delta) != (1 if layer == 0 else nx) or b - a < 8:
                continue
            conflict = np.flatnonzero(occ[p[a + 1:b]] > 1) + a + 1
            if len(conflict) < 3:
                continue
            q = np.r_[0, np.flatnonzero(np.diff(conflict) > 4) + 1, len(conflict)]
            for c, d in zip(q[:-1], q[1:]):
                if d - c < 3:
                    continue
                u, v = int(conflict[c]), int(conflict[d - 1])
                tries.append((d - c, max(a, u - 1), min(b, v + 1), layer))
        best = None
        for _, a, b, layer in sorted(tries, reverse=True)[:10]:
            mid = p[a + 1:b]
            gain = int((occ[mid] == 2).sum())
            if gain == 0:
                continue
            across = nx if layer == 0 else 1
            lateral = int(p[a] % plane // nx if layer == 0 else p[a] % nx)
            limit = ny if layer == 0 else nx
            for offset in (-1, 1, -2, 2, -3, 3, -4, 4):
                if not 4 <= lateral + offset < limit - 4:
                    continue
                steps = np.arange(1, abs(offset) + 1, dtype=np.int32) * (across if offset > 0 else -across)
                new = np.concatenate((p[a] + steps, mid + steps[-1], p[b] + steps[::-1]))
                if (occ[new] != 0).any() or ((owner[new] >= 0) & (owner[new] != i)).any():
                    continue
                if any(int(x) in used for x in new):
                    continue
                score = (gain, -abs(offset), b - a)
                if best is None or score > best[0]:
                    best = score, a, b, new
                break
        if best:
            score, a, b, new = best
            if len(p) + len(new) - (b - a - 1) > len(old[i][1]) + 16:
                continue
            occ[p[a + 1:b]] -= 1
            occ[new] += 1
            working[i][1] = np.concatenate((p[:a + 1], new, p[b:]))
            total_removed += score[0]
            accepted += 1
    after = int((occ > 1).sum())
    assert after == initial - total_removed
    changes += accepted
    history.append({"sweep": sweep + 1, "eligible_nets": len(eligible), "accepted_detours": accepted, "conflicts": after})
    print(history[-1], flush=True)
    if accepted == 0:
        break
out = Path("control162-parallel-detour2714-" + tag)
out.mkdir()
route = out / "paths.txt"
with route.open("x") as f:
    f.write(str(total) + "\n")
    for i, (name, bs) in enumerate(zip(order, working)):
        if i < prefix or finite[i] >= 0:
            assert all(np.array_equal(a, b) for a, b in zip(bs, old[i]))
        f.write(f"{name} {len(bs)}\n")
        for p in bs:
            xyz = np.stack((p % plane % nx, p % plane // nx, p // plane), axis=-1)
            assert (np.abs(np.diff(xyz, axis=0)).sum(axis=1) == 1).all()
            f.write(str(len(p)) + " " + " ".join(map(str, xyz.ravel().tolist())) + "\n")
result = {"stage": "diagnostic-parallel-track-detours-only", "whole_system_qualified": False,
          "route_qualified": False, "changes": changes, "history": history,
          "initial_conflict_vertices": initial, "remaining_conflict_vertices": after,
          "removed_conflict_vertices": total_removed, "inputs": {str(p): digest(p) for p in (graph, src, receipt)},
          "output_sha256": digest(route)}
(out / "diagnostic.json").write_text(json.dumps(result, indent=2))
