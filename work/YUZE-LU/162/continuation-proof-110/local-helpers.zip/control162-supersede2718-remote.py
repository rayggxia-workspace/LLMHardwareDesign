from pathlib import Path
import hashlib
import json
import os

b = Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
q = b / 'dynamic-04/node25'
st = json.loads((q / 'queue-state.json').read_text())
assert os.getuid() == 10011 and st['job'] == '95204' and len(st['active']) == st['slots'] == 6
old = q / 'pending/00-a-sready2548-openroad-region-fastroute50.json'
new = b / 'dynamic-06/node26/pending/00-a-sready2558-openroad-region-fastroute50.json'
receipt = b / 'r256-openroad-region-2558/fastroute50/receipt.json'
log = receipt.parent / 'case-0/openroad.log'
audit = b / 'r256-openroad-region-source-audit-2558/receipt.json'
old_data, new_data = json.loads(old.read_text()), json.loads(new.read_text())
assert old_data['forecast_gib'] == new_data['forecast_gib'] == 8
assert old_data['script'] == new_data['script'] == 'system_upper.py'
assert old_data['source_root'] == str(b / 'source-2543') and new_data['source_root'] == str(b / 'source-2557')
assert [x.replace('/r256-openroad-region-2548/', '/r256-openroad-region-2558/') for x in old_data['args']] == new_data['args']
assert json.loads(audit.read_text())['passed'] and str(audit) in new_data['requires']
new_r = json.loads(receipt.read_text())
assert new_r['passed'] is False and new_r['whole_system_qualified'] is False
assert 'GRT-0116' in log.read_text(errors='replace')
assert old.stem not in st['active'] and not (q / 'commands' / old.name).exists() and not (q / 'results' / old.name).exists()
r = b / 'route-selection-102/sready2718-superseded-own-regional-probe'
assert not r.exists() and old.is_file()
r.mkdir()
park = r / old.name
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = sha(old)
st = json.loads((q / 'queue-state.json').read_text())
assert len(st['active']) == st['slots'] == 6 and old.stem not in st['active']
assert not (q / 'commands' / old.name).exists() and not (q / 'results' / old.name).exists()
old.rename(park)
assert sha(park) == expected
z = dict(passed=True, whole_system_qualified=False, pending_only=True, original=str(old),
         preserved=str(park), original_sha256=expected, corrected_probe=str(new),
         corrected_receipt_sha256=sha(receipt), corrected_log_sha256=sha(log), corrected_audit_sha256=sha(audit),
         reason='The corrected source already ran the identical regional FastRoute input and failed GRT-0116. Preserve this never-started obsolete probe byte for byte. All existing running jobs, independent CUGR and original system gates remain.')
(r / 'receipt.json').write_text(json.dumps(z, indent=2))
print(json.dumps(z))
