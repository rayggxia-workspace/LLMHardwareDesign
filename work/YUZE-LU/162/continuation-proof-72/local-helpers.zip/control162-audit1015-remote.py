from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-972';new=b/'source-1013';reg=b/'r256-coarse-grid-regression-1014';out=b/'r256-coarse-grid-source-audit-1015';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=json.loads((reg/'receipt.json').read_text());assert root['passed']and root['stage']=='ordinary-coarse-focused-regression-only';child=reg/'coarse-grid/receipt.json';assert root['inputs'][str(child)]==sha(child);r=json.loads(child.read_text());assert r['passed']and not r['whole_system_qualified']and not r['route_qualified']and len(r['full_route_positives'])==2 and len(r['rejected'])==3 and r['coarse_full_failure_rejected']and len(r['oracle_checks'])==89
assert sum(x['exact_full_grid_oracle']for x in r['oracle_checks'])==64 and r['oracle_checks'][-1]['returned_vertices']==0
for p,v in r['inputs'].items():assert sha(p)==v
for x in r['full_route_positives']:assert x['proof']['final_conflicts']==0 and any(t['coarse_hits']>0 for t in x['proof']['ordinary_coarse_trace'])
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','ordinary_coarse_grid.h','coarse_grid_regression.py']};assert set(a['files'])<=set(z['files'])and len(z['files'])==1012
for p,v in z['files'].items():assert sha(new/p)==v
rules=b/'backout1015.json';cfg=json.loads(rules.read_text());rows=[]
for name,changes in cfg['rules'].items():
 original=old/'project/experiments/control_v1'/name;current=new/'project/experiments/control_v1'/name;s=current.read_text()
 if name=='system_upper.py':assert s.count(cfg['dispatch'])==1;s=s.replace(cfg['dispatch'],'',1)
 for a,z in reversed(changes):assert s.count(z)==1,(name,z);s=s.replace(z,a,1)
 assert s==original.read_text();rows.append(dict(name=name,previous_sha256=sha(original),current_sha256=sha(current),remove_only_coarse_candidate_additions_recovers_previous_byte_exact=True))
invariants=json.loads((b/'r256-native-warm-source-audit-980/receipt.json').read_text())['invariants']+[dict(name='native_warm_regression.py',sha256=sha(new/'project/experiments/control_v1/native_warm_regression.py'))]
for x in invariants:assert sha(new/'project/experiments/control_v1'/x['name'])==sha(old/'project/experiments/control_v1'/x['name'])==x['sha256']
artifacts=[]
for seed in [975,976]:
 folder=reg/'coarse-grid'/('full-'+str(seed))
 for p in folder.iterdir():
  if p.is_file()and p.name!='router':artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
out.mkdir();result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1012,unchanged_manifest_files=1007,changed_files=sorted(changed),backouts=rows,invariants=invariants,full_route_positive=2,rejected=3,oracle_cases=89,old71_actual_replays=True,old_warm2_actual_bytes_exact=True,actual_artifacts=artifacts,inputs={str(rules):sha(rules),str(child):sha(child),str(reg/'receipt.json'):sha(reg/'receipt.json'),str(new/'source-manifest.json'):sha(new/'source-manifest.json')},scope='Actual1014 independent fine-grid oracle and valid coarse/capped searches,2actualfull routes withcoarsehits,old71/warm/refresh/release actual byte replays. Compressed candidates only for ordinary pairs; fallback dense/native finite solvers and all final geometry/PG/3RC300MHz gates unchanged. No fullscene qualification inferred.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1012,unchanged=1007,backouts=3,invariants=22,positives=2,oracle=89,rejected=3)))
