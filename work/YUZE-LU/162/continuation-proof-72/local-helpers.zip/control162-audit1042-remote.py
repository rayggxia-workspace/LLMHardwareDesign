from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1013';new=b/'source-1040';reg=b/'r256-coarse-access-regression-1041';out=b/'r256-coarse-access-source-audit-1042';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=json.loads((reg/'receipt.json').read_text());assert root['passed']and root['stage']=='ordinary-coarse-access-focused-regression-only';child=reg/'coarse-access/receipt.json';assert root['inputs'][str(child)]==sha(child);r=json.loads(child.read_text());assert r['passed']and not r['whole_system_qualified']and not r['route_qualified']and len(r['full_route_positives'])==2 and len(r['rejected'])==2 and r['access_global_failure_rejected']and len(r['oracle_checks'])==104
assert sum(x['exact_cost_oracle']for x in r['oracle_checks'])==64
fences=[x for x in r['oracle_checks']if x['endpoint_fence']];assert len(fences)==16 and all(bool(x['returned_vertices'])==x['local_access']for x in fences)
assert all(x['expanded']<=x['graph_states']for x in r['oracle_checks']if x['local_access'])
for p,v in r['inputs'].items():assert sha(p)==v
for x in r['full_route_positives']:assert x['proof']['final_conflicts']==0 and x['proof']['coarse_access_trace']and any(t['coarse_hits']>0 for t in x['proof']['ordinary_coarse_trace'])
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','ordinary_coarse_grid.h','coarse_access_regression.py']};assert set(a['files'])<=set(z['files'])and len(z['files'])==1013
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='b33b0489eb3c82a316ec3aaff9b500346cf624a76257c95e156c06d286750cba'
for p,v in z['files'].items():assert sha(new/p)==v
out.mkdir();scratch=out/'reverse-copies';scratch.mkdir();files=['tree_router.cpp','tree_router_cpp.py','system_upper.py','ordinary_coarse_grid.h'];rows=[]
for name in files:
 rel=Path('project/experiments/control_v1')/name;target=scratch/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((new/rel).read_bytes())
patch=b/'backout1042.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in files:
 rel=Path('project/experiments/control_v1')/name;assert(scratch/rel).read_bytes()==(old/rel).read_bytes();rows.append(dict(name=name,current_sha256=sha(new/rel),previous_sha256=sha(old/rel),reconstructed_sha256=sha(scratch/rel),only_scratch_copies_modified=True,exact=True))
invariants=json.loads((b/'r256-coarse-grid-source-audit-1015/receipt.json').read_text())['invariants']+[dict(name='coarse_grid_regression.py',sha256=sha(new/'project/experiments/control_v1/coarse_grid_regression.py'))]
for x in invariants:assert sha(new/'project/experiments/control_v1'/x['name'])==sha(old/'project/experiments/control_v1'/x['name'])==x['sha256']
artifacts=[]
for seed in [971,972]:
 for p in(reg/'coarse-access'/('full-'+str(seed))).iterdir():
  if p.is_file()and p.name!='router':artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1013,unchanged_manifest_files=1008,changed_files=sorted(changed),backouts=rows,invariants=invariants,full_route_positive=2,rejected=2,oracle_cases=104,same_input_fence_pairs=8,old71_actual_replays=True,old_coarse2_and89oracle_actual_bytes_exact=True,actual_artifacts=artifacts,inputs={str(patch):sha(patch),str(child):sha(child),str(reg/'receipt.json'):sha(reg/'receipt.json'),str(new/'source-manifest.json'):sha(new/'source-manifest.json')},scope='Actual1041 independent104checks/64minimumcosts/24weightedcandidates/8pairedpinentryfail-success fixtures andsettledstatebound;2actualfullroutes/2contexts/globalfailure rejection. Oldcoarse2fullpaths/main/native logs and89oraclebytes identical;old71/warm/release/refresh actual helperreplays. Fourproductionfiles reconstructed exactly to1013 inowned scratchcopies, frozen source files nevermutated;23native/finalgate/helper invariants unchanged. No physical/system pass inferred.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1013,unchanged=1008,backouts=4,invariants=23,positives=2,oracle=104,fence_pairs=8,rejected=2)))
