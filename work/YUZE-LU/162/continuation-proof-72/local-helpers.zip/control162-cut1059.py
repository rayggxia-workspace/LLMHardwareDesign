from pathlib import Path
import hashlib,json
h=Path(__file__).parent;inp=h/'control162-frozen-disconnection940/input.txt';lines=inp.read_text().splitlines();header=list(map(int,lines[0].split()));nx,ny,count=header[:3];diffx=[0]*(nx+1);diffy=[0]*(ny+1);nets=[]
for line in lines[1:]:
 row=line.split();name=row[0];n=int(row[1]);ends=[tuple(map(int,row[2+2*i:4+2*i]))for i in range(n)];xs=[x for x,y in ends];ys=[y for x,y in ends];a,b=min(xs),max(xs);c,d=min(ys),max(ys);diffx[a]+=1;diffx[b]-=1;diffy[c]+=1;diffy[d]-=1;nets.append(dict(name=name,xmin=a,xmax=b,ymin=c,ymax=d))
assert len(nets)==count
def sweep(diff,start,stop,capacity):
 value=0;rows=[]
 for i,delta in enumerate(diff):
  value+=delta
  if start<=i<stop:rows.append(dict(cut=i,demand=value,capacity=capacity,deficit=max(0,value-capacity)))
 return dict(peak=max(rows,key=lambda x:x['demand']),violated_cuts=sum(x['deficit']>0 for x in rows),rows=rows)
x=sweep(diffx,4,nx-5,2*(ny-8));y=sweep(diffy,4,ny-5,2*(nx-8));r=dict(input=str(inp),input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),nx=nx,ny=ny,nets=count,vertical=x,horizontal=y,whole_system_qualified=False,scope='Necessary terminal-span cut bound only. Each net whose actual terminals lie on both sides must occupy at least one distinct unit edge across the cut. Two layers provide at most twice the interior rows/columns. Ignores pin obstacles, finite wire budgets and actual wire competition, so a positive deficit proves current grid impossible; no deficit does not prove routing or physical acceptance.')
out=h/'control162-cut1059.json';out.write_text(json.dumps(r,indent=2));print(json.dumps(dict(vertical=x['peak'],horizontal=y['peak'],vertical_violations=x['violated_cuts'],horizontal_violations=y['violated_cuts'])))
