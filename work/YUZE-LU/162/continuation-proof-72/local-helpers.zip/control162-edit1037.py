from pathlib import Path
p=Path(__file__).parent/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'
def edit(name,changes):
 f=p/name;s=f.read_text(encoding='utf-8')
 for a,z in changes:assert s.count(a)==1,(name,a);s=s.replace(a,z,1)
 f.write_bytes(s.encode())
edit('tree_router.cpp',[
 ('argc>21','argc>22'),
 ('int ordinary_coarse=0;', 'bool ordinary_coarse_access=false;int ordinary_coarse=0;'),
 ('  if(option=="--ordinary-coarse=8"', '  if(option=="--ordinary-coarse-access"){if(ordinary_coarse_access)throw runtime_error("duplicate coarse access option");ordinary_coarse_access=true;}\n  else if(option=="--ordinary-coarse=8"'),
 (' if(ordinary_coarse&&', ' if(ordinary_coarse_access&&!ordinary_coarse)throw runtime_error("coarse access requires explicit coarse grid");\n if(ordinary_coarse&&'),
 ('coarse_expanded,coarse_checks);','coarse_expanded,coarse_checks,65536,ordinary_coarse_access);'),
 ('  if(ordinary_coarse)cout', '  if(ordinary_coarse_access)cout<<"{\\\"round\\\":"<<iteration<<",\\\"coarse_local_access\\\":true,\\\"coarse_settle_once\\\":true}"<<endl;\n  if(ordinary_coarse)cout'),
])
edit('tree_router_cpp.py',[
 ('ordinary_coarse_grid_stride=0):','ordinary_coarse_grid_stride=0,ordinary_coarse_access=False):'),
 ("    if ordinary_coarse_grid_stride:extra_cli.append('--ordinary-coarse='+str(ordinary_coarse_grid_stride))", "    if ordinary_coarse_grid_stride:extra_cli.append('--ordinary-coarse='+str(ordinary_coarse_grid_stride))\n    assert not ordinary_coarse_access or ordinary_coarse_grid_stride\n    if ordinary_coarse_access:extra_cli.append('--ordinary-coarse-access')"),
 ('        ordinary_coarse_grid_stride=ordinary_coarse_grid_stride,','        ordinary_coarse_access=ordinary_coarse_access,coarse_access_trace=[r for r in trace if \'coarse_local_access\'in r],\n        ordinary_coarse_grid_stride=ordinary_coarse_grid_stride,'),
])
edit('system_upper.py',[
 ("    p.add_argument('--route-ordinary-coarse',type=int,choices=[0,8,16,32],default=0)", "    p.add_argument('--route-ordinary-coarse',type=int,choices=[0,8,16,32],default=0)\n    p.add_argument('--route-ordinary-coarse-access',action='store_true')"),
 ('    assert not a.route_ordinary_coarse or','    assert not a.route_ordinary_coarse_access or a.route_ordinary_coarse\n    assert not a.route_ordinary_coarse or'),
 ('ordinary_coarse_grid_stride=a.route_ordinary_coarse)', 'ordinary_coarse_grid_stride=a.route_ordinary_coarse,ordinary_coarse_access=a.route_ordinary_coarse_access)'),
])
print('opt-in adjacent pin access and settled coarse graph; old mode unchanged')
