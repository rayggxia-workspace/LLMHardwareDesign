from pathlib import Path
p=Path(__file__).parent/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'
def edit(name,changes):
 f=p/name;s=f.read_text(encoding='utf-8')
 for a,z in changes:assert s.count(a)==1,(name,a);s=s.replace(a,z,1)
 f.write_bytes(s.encode())
edit('tree_router.cpp',[
 ('argc>22','argc>24'),
 ('bool ordinary_coarse_access=false;', 'bool ordinary_coarse_static=false;int global_snapshot=0;bool ordinary_coarse_access=false;'),
 ('  if(option=="--ordinary-coarse-access")', '  if(option=="--ordinary-coarse-static"){if(ordinary_coarse_static)throw runtime_error("duplicate static coarse option");ordinary_coarse_static=true;}\n  else if(option=="--global-route-snapshot=8"||option=="--global-route-snapshot=16"||option=="--global-route-snapshot=32"||option=="--global-route-snapshot=64"){if(global_snapshot)throw runtime_error("duplicate global snapshot option");global_snapshot=stoi(option.substr(option.find(\'=\')+1));}\n  else if(option=="--ordinary-coarse-access")'),
 (' if(ordinary_coarse_access&&', ' if(ordinary_coarse_static&&!ordinary_coarse_access)throw runtime_error("static coarse requires local access mode");\n if(global_snapshot&&!native_flexible)throw runtime_error("global snapshot requires flexible native mode");\n if(ordinary_coarse_access&&'),
 ('     int ox=(n*7+iteration*3)%ordinary_coarse,oy=(n*11+iteration*5)%ordinary_coarse;oy=(oy&~1)|(ox&1);', '     uint64_t phase=ordinary_coarse_static?uint32_t(seed):uint32_t(iteration);\n     int ox=(uint64_t(n)*7+phase*3)%ordinary_coarse,oy=(uint64_t(n)*11+phase*5)%ordinary_coarse;oy=(oy&~1)|(ox&1);'),
 ('  if(ordinary_coarse_access)cout', '  if(ordinary_coarse_static)cout<<"{\\\"round\\\":"<<iteration<<",\\\"coarse_static_grid\\\":true,\\\"grid_phase\\\":"<<uint32_t(seed)<<"}"<<endl;\n  if(ordinary_coarse_access)cout'),
 ('  previous_conflicts=conflicts;', '''  if(global_snapshot&&!native_stage&&iteration+1==global_snapshot){
   ofstream diagnostic(string(argv[2])+".global-round-"+to_string(global_snapshot)+".txt");diagnostic<<count<<'\\n';
   for(int n=0;n<count;++n){diagnostic<<names[n]<<' '<<branches[n].size()<<'\\n';for(auto&branch:branches[n]){
    diagnostic<<branch.size();for(int v:branch){auto c=coord(v);diagnostic<<' '<<c[0]<<' '<<c[1]<<' '<<c[2];}diagnostic<<'\\n';}}
   if(!diagnostic)throw runtime_error("cannot write diagnostic global snapshot");diagnostic.close();
   cout<<"{\\"round\\":"<<iteration<<",\\"global_snapshot_round\\":"<<global_snapshot<<",\\"global_snapshot_nets\\":"<<count<<",\\"diagnostic_only\\":true}"<<endl;
  }
  previous_conflicts=conflicts;'''),
])
edit('tree_router_cpp.py',[
 ('ordinary_coarse_access=False):','ordinary_coarse_access=False,ordinary_coarse_static=False,global_snapshot_round=0):'),
 ("    if ordinary_coarse_access:extra_cli.append('--ordinary-coarse-access')", "    if ordinary_coarse_access:extra_cli.append('--ordinary-coarse-access')\n    assert not ordinary_coarse_static or ordinary_coarse_access\n    if ordinary_coarse_static:extra_cli.append('--ordinary-coarse-static')\n    assert global_snapshot_round in (0,8,16,32,64)and(not global_snapshot_round or native_prefix_flexible)\n    snapshot_cli=['--global-route-snapshot='+str(global_snapshot_round)]if global_snapshot_round else[]"),
 ('str(inp),str(result)]+extra_cli,','str(inp),str(result)]+extra_cli+snapshot_cli,'),
 ("str(folder/'output.txt')]+extra_cli,folder/'router.log'", "str(folder/'output.txt')]+extra_cli+(snapshot_cli if index==0 else[]),folder/'router.log'"),
 ("command=[str(binary),str(folder/'input.txt'),str(folder/'output.txt')]+extra_cli", "command=[str(binary),str(folder/'input.txt'),str(folder/'output.txt')]+extra_cli+(snapshot_cli if index==0 else[])"),
 ('        ordinary_coarse_access=ordinary_coarse_access,', '        ordinary_coarse_static=ordinary_coarse_static,coarse_static_trace=[r for r in trace if \'coarse_static_grid\'in r],global_snapshot_round=global_snapshot_round,global_snapshot_trial_index=(0 if global_snapshot_round else None),\n        ordinary_coarse_access=ordinary_coarse_access,'),
])
edit('system_upper.py',[
 ("    p.add_argument('--route-ordinary-coarse-access',action='store_true')", "    p.add_argument('--route-ordinary-coarse-access',action='store_true')\n    p.add_argument('--route-ordinary-coarse-static',action='store_true')\n    p.add_argument('--route-global-snapshot-round',type=int,choices=[0,8,16,32,64],default=0)"),
 ('    assert not a.route_ordinary_coarse_access or','    assert not a.route_ordinary_coarse_static or a.route_ordinary_coarse_access\n    assert not a.route_global_snapshot_round or a.route_native_prefix_flexible\n    assert not a.route_ordinary_coarse_access or'),
 ('ordinary_coarse_access=a.route_ordinary_coarse_access)', 'ordinary_coarse_access=a.route_ordinary_coarse_access,ordinary_coarse_static=a.route_ordinary_coarse_static,global_snapshot_round=a.route_global_snapshot_round)'),
])
print('opt-in static per-trial coarse tracks and one diagnostic snapshot in trial0 only')
