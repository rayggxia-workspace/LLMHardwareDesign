from pathlib import Path
import sys,ast
h=Path(__file__).parent;source=h/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1/coarse_access_regression.py';sys.path.insert(0,str(source.parent));import coarse_access_regression as m
out=h/'control162-access-oracle1039';out.mkdir();s=source.read_text(encoding='utf-8');a=s.index("    header=Path(__file__).with_name('ordinary_coarse_grid.h')");z=s.index("    fixture=out/",a);code='def test():\n'+s[a:z]+'    return locals()\n'
scope=dict(m.__dict__);scope['out']=out;exec(compile(code,str(source),'exec'),scope);result=scope['test']();print(dict(checked=len(result['checks']),exact64=True,coarse_hits=sum(x['returned_vertices']>0 for x in result['checks'][64:88]),fence_pairs=sum(x.get('endpoint_fence',False)for x in result['checks'])//2))

