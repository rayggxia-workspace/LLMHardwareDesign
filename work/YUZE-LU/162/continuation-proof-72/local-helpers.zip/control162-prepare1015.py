from pathlib import Path
import ast,json,subprocess
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';m=ast.parse((h/'control162-edit1007.py').read_text(encoding='utf-8'));rules={}
for item in m.body:
 if isinstance(item,ast.Expr)and isinstance(item.value,ast.Call)and isinstance(item.value.func,ast.Name)and item.value.func.id=='edit':rules[ast.literal_eval(item.value.args[0])]=ast.literal_eval(item.value.args[1])
rules['system_upper.py'].append(("    p.add_argument('--native-warm-regression-config',type=Path)","    p.add_argument('--native-warm-regression-config',type=Path)\n    p.add_argument('--coarse-grid-regression-config',type=Path)"))
s=(repo/'project/experiments/control_v1/system_upper.py').read_text(encoding='utf-8');a=s.index('        if a.coarse_grid_regression_config:');z=s.index('        if a.native_warm_regression_config:',a);dispatch=s[a:z]
for name,changes in rules.items():
 s=(repo/'project/experiments/control_v1'/name).read_text(encoding='utf-8')
 if name=='system_upper.py':s=s.replace(dispatch,'',1)
 for a,z in reversed(changes):assert s.count(z)==1,(name,z);s=s.replace(z,a,1)
 old=subprocess.check_output(['git','show','7620434e568dfba16a7229642ffa8cd8b85f7132:project/experiments/control_v1/'+name],cwd=repo).decode();assert s==old,name
(h/'control162-backout1015.json').write_text(json.dumps(dict(rules=rules,dispatch=dispatch),indent=2),encoding='utf-8');print('all3 production files exact recover972')
