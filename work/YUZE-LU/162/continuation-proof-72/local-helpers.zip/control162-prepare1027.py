from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-audit1025.py').read_text(encoding='utf-8')
s=s.replace("assert not any(x.startswith('--native-refresh=')for x in cmd);", "assert not any(x.startswith('--native-refresh=')for x in cmd);assert '--ordinary-coarse='+('16'if seed==10160 else'8')in cmd;")
a=s.index("scope='");z=s.index("')\nexcept",a)
s=s[:a]+"scope='Actual10160/10161 each16owned source1013 children on node6.32actualinput bodies and32importedzero-prefix bytes match validated actual9060trial0 seed. Every coarse16/8 flag bound in realchildcommand; nativefinite and fallbackdense search unchanged. All4active16CPU masks for9281/9811/10160/10161 pairwise disjoint and actual256GiB forecast/323.2GiB admission verified. Require1014actual89oraclechecks/2fullroutes/3rejects/old71warmreplay,1015threeexactbackouts/22invariants and1017strict14fullstagebindings. No fullscene route or physical/system pass inferred"+s[z:]
compile(s,'audit1025','exec');(h/'control162-audit1025.py').write_text(s,encoding='utf-8');print('prepared1025 actualcoarseflags and correct32child/node6 scope')
