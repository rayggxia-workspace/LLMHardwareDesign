from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-audit1036.py').read_text(encoding='utf-8')
s=s.replace('r256-coarse-c96-active-pool-audit-1036','r256-coarse-access-active-pool-audit-1069').replace('for seed in [10300,10301,10302,10303]','for seed in [10430,10431,10550,10551]')
s=s.replace("[(95204,25,'dynamic-04/node25',[10300,10301],[4661,5400,6562,7581,10300,10301]),(96222,24,'dynamic-06/node26',[10302,10303],[5494,5495,7920,7921,10302,10303])]","[(95155,5,'dynamic-03/node5',[10430],[6360,8301,9810,10430]),(97097,6,'dynamic-08/node6',[10431],[10160,10161,10431]),(95098,3,'dynamic-02/node3',[10550,10551],[5260,6561,10550,10551])]")
s=s.replace('{10300:16,10301:8,10302:32,10303:16}','{10430:16,10431:8,10550:16,10551:16}')
s=s.replace("assert '--ordinary-coarse='+str(","assert '--ordinary-coarse-access'in cmd;assert '--ordinary-coarse-static'not in cmd;assert '--ordinary-coarse='+str(")
s=s.replace("assert p.read_bytes().split(b'\\n',1)[1]==body","assert p.read_bytes().split(b'\\n',1)[1]==body;assert int(p.read_text().splitlines()[0].split()[15])=={10430:2,10431:2,10550:8,10551:32}[seed]")
s=s.replace('four16cpu_masks_pairwise_disjoint=True','observed16cpu_masks_pairwise_disjoint=True').replace('new_owned_children=32','new_owned_children=64').replace('four16cpu_masks_disjoint_both_nodes=True','observed16cpu_masks_disjoint_three_nodes=True')
a=s.index("scope='");z=s.index("')\n",a)
s=s[:a]+"scope='Actual64 owned source1040 access-coarse children10430/10431/10550/10551,allactualinputbody andimportedzero-native bytesmatch9060trial0. Realcommandaccessflags/stride16-8-16-16 andinputnonpreferredcost2-2-8-32verified. Actualownedrouting16CPUmasksdisjointonthreec64nodes;node6 fourth16CPUslot runs1065regression separately. Actualcontrolleravailablememoryexceedsadmissionthreshold. OriginalnativeM1-M10 andfinitewirebudget/finalgatesunchanged. Diagnosticonly,no fullscene route/physical/systempass inferred'"+s[z+1:]
compile(s,'audit1069','exec');(h/'control162-audit1069.py').write_text(s,encoding='utf-8')
print('Prepared64actual accesschildren audit')
