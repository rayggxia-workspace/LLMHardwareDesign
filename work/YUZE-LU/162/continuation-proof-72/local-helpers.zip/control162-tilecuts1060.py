from pathlib import Path
import json,hashlib,collections,time
h=Path(__file__).parent;inp=h/'control162-frozen-disconnection940/input.txt';lines=inp.read_text().splitlines();nx,ny,count=map(int,lines[0].split()[:3]);nets=[]
for line in lines[1:]:
 row=line.split();k=int(row[1]);nets.append((row[0],[tuple(map(int,row[2+2*i:4+2*i]))for i in range(k)]))
started=time.monotonic();violations=[];maximum=[]
for side in (8,16,32,64,128,256,512,1024):
 for ox in (0,side//2):
  for oy in (0,side//2):
   demand=collections.Counter();cross={}
   for name,ends in nets:
    tiles={(int((x-ox)//side),int((y-oy)//side))for x,y in ends}
    if len(tiles)<2:continue
    for tile in tiles:demand[tile]+=1;cross.setdefault(tile,[]).append(name)
   rows=[]
   for(i,j),value in demand.items():
    x0=max(4,ox+i*side);x1=min(nx-5,ox+(i+1)*side-1);y0=max(4,oy+j*side);y1=min(ny-5,oy+(j+1)*side-1);w=x1-x0+1;hh=y1-y0+1;capacity=2*((int(x0>4)+int(x1<nx-5))*hh+(int(y0>4)+int(y1<ny-5))*w)
    row=dict(side=side,offset=[ox,oy],bounds=[x0,y0,x1,y1],demand=value,capacity=capacity,deficit=max(0,value-capacity))
    if value>capacity:row['crossing_nets']=cross[(i,j)];violations.append(row)
    rows.append(row)
   maximum.append(max(rows,key=lambda x:x['demand']/x['capacity']))
r=dict(input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),whole_system_qualified=False,seconds=time.monotonic()-started,violations=violations,largest_utilizations=maximum,scope='Necessary rectangular-cut bound for32 tilings of actual endpoint geometry. Each net with terminals in tile and outside must occupy at least one distinct boundary edge. Capacity is exact available unit edges across rectangle on both layers, ignoring all obstacles and finite budgets. Positive deficit proves current geometry impossible; no deficit never proves simultaneous routing or physical acceptance.')
(h/'control162-tilecuts1060.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(seconds=r['seconds'],violations=len(violations),worst=sorted(violations,key=lambda x:x['deficit'],reverse=True)[:4],maximum_utilization=max(x['demand']/x['capacity']for x in maximum))))
