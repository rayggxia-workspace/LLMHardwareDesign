from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [10160,10161]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log';rounds={}
 if not p.exists():continue
 for line in p.read_text().splitlines():
  if not line.startswith('{'):continue
  try:r=json.loads(line)
  except ValueError:continue
  if 'round'not in r:continue
  if any(k in r for k in ['conflict_nodes','zero_pattern_attempts','zero_maze_attempts','endpoint_escape_attempts','finite_resource_calls','weighted_bidirectional_search_weight','ordinary_coarse_stride']):rounds.setdefault(r['round'],{}).update(r)
 rows.append(dict(candidate=tag,rounds=rounds))
print(json.dumps(rows))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]);out=Path(__file__).parent/'control162-trajectory1028';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
for x in json.loads(raw):print(json.dumps(dict(candidate=x['candidate'],rounds=[{k:v for k,v in r.items()if k in ['round','conflict_nodes','excess_occupancy','summed_tree_vertices','zero_pattern_hits','zero_pattern_attempts','zero_maze_hits','zero_maze_attempts','weighted_bidirectional_search_weight','maximum_resource_labels','coarse_hits','coarse_attempts','coarse_expanded','coarse_point_checks']}for r in x['rounds'].values()])))

