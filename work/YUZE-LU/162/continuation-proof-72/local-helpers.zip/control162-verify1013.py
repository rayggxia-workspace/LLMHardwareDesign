import subprocess,shlex
q='''import json,hashlib
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1013')
m=json.loads((b/'source-manifest.json').read_text());f=json.loads((b/'freeze-import.json').read_text())
assert m['commit']=='fd4820853d823a6ac150877cece59d3c881aee9d'and len(m['files'])==1012
assert f['archive_sha256']=='f29970e78149ce1a0cc6f1273f0aaa7cbf6f319dabc166ce5036b97d431d85ab'
assert all(hashlib.sha256((b/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
print('source1013 manifest1012/freeze verified')
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
