import subprocess,shlex
q='''import json,hashlib
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1040')
m=json.loads((b/'source-manifest.json').read_text());f=json.loads((b/'freeze-import.json').read_text())
assert m['commit']=='259db98950c32fa616f633e3643f2211fddb805e'and len(m['files'])==1013
assert f['archive_sha256']=='b33b0489eb3c82a316ec3aaff9b500346cf624a76257c95e156c06d286750cba'
assert all(hashlib.sha256((b/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
print('source1040 manifest1013/freeze verified')
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
