import subprocess,shlex
q='''import json,hashlib
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1064')
m=json.loads((b/'source-manifest.json').read_text());f=json.loads((b/'freeze-import.json').read_text())
assert m['commit']=='ebaf9e14ab147534863f379c26e7b249311e8d21'and len(m['files'])==1015
assert f['archive_sha256']=='f38194b46c14175e120fd7f0a3984c51b1e939e4395372f302436a0a5e91c32e'
assert all(hashlib.sha256((b/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
print('source1064 manifest1015/freeze verified')
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
