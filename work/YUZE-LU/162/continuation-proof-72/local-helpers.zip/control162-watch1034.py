from pathlib import Path
import subprocess,shlex,json,time,collections
h=Path(__file__).parent;out=h/'control162-watch1034';out.mkdir();began=time.monotonic()
q='''from pathlib import Path
import json,time,collections
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [10160,10161,10300,10301,10302,10303]:
 root=b/'r256-composition-453/upper-candidates'/str(tag);route=root/'route';row=dict(candidate=tag,last_global=None,last_coarse=None,attempts=0,failures={},receipts={})
 p=route/'trial-0/router.log'
 if p.exists():
  lines=p.read_text().splitlines()
  for line in reversed(lines):
   if not line.startswith('{'):continue
   try:d=json.loads(line)
   except ValueError:continue
   if row['last_global']is None and'conflict_nodes'in d:row['last_global']=d
   if row['last_coarse']is None and'coarse_hits'in d:row['last_coarse']=d
   if row['last_global']is not None and row['last_coarse']is not None:break
 failed=collections.Counter()
 for p in route.glob('trial-*/router.log'):
  row['attempts']+=1
  with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-1024));lines=f.read().decode(errors='replace').splitlines()
  if lines and not lines[-1].startswith('{'):failed[lines[-1]]+=1
 row['failures']=dict(failed)
 for name in ['route','geometry','pg-audit','timing/low','timing/base','timing/high','delivery']:
  p=root/name/'receipt.json'
  if p.exists():
   d=json.loads(p.read_text());row['receipts'][name]=dict(passed=d.get('passed'),error=d.get('error'))
 rows.append(row)
print(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False)))
'''
previous=None
while time.monotonic()-began<3600:
 try:
  raw=subprocess.check_output(['ssh','-o','ConnectTimeout=12','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);d=json.loads(raw);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
  signature=[(x['candidate'],(x['last_global']or{}).get('round'),x['failures'],x['receipts'])for x in d['rows']]
  if signature!=previous:print(json.dumps(d),flush=True);previous=signature
  if any('delivery'in x['receipts']or'route'in x['receipts']for x in d['rows']):break
 except(subprocess.SubprocessError,ValueError)as e:print(json.dumps(dict(retry=str(e))),flush=True)
 time.sleep(30)
print(json.dumps(dict(ended=True)),flush=True)
