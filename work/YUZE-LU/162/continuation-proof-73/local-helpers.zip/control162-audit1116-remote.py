from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1094';new=b/'source-1104';reg=b/'r256-coarse-multicast-regression-1115';out=b/'r256-coarse-multicast-source-audit-1116';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=json.loads((reg/'receipt.json').read_text());assert root['passed']and root['stage']=='ordinary-coarse-multicast-focused-regression-only';child=reg/'coarse-multicast/receipt.json';assert root['inputs'][str(child)]==sha(child);r=json.loads(child.read_text());assert r['passed']and not r['whole_system_qualified']and not r['route_qualified']and len(r['full_route_positives'])==2 and len(r['rejected'])==2 and r['multicast_global_failure_rejected']
for p,v in r['inputs'].items():assert sha(p)==v
for x in r['full_route_positives']:assert x['proof']['final_conflicts']==0 and x['proof']['coarse_multicast_trace']and sum(t['coarse_multicast_hits']for t in x['proof']['coarse_multicast_trace'])>0 and x['independent_final']['all_trees_flood_verified']and x['independent_final']['all_wire_budgets_verified']and x['independent_final']['conflict_nodes']==0
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','coarse_multicast_regression.py']};assert set(a['files'])<=set(z['files'])and len(z['files'])==1016
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='1eeb775b94563cd3a0edde6e825fed06b9c71d7c4afe3be1651a0c0bcb3604b7'
for p,v in z['files'].items():assert sha(new/p)==v
out.mkdir();scratch=out/'reverse-copies';scratch.mkdir();files=['tree_router.cpp','tree_router_cpp.py','system_upper.py'];rows=[]
for name in files:
 rel=Path('project/experiments/control_v1')/name;target=scratch/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((new/rel).read_bytes())
patch=b/'backout1106.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in files:
 rel=Path('project/experiments/control_v1')/name;assert(scratch/rel).read_bytes()==(old/rel).read_bytes();rows.append(dict(name=name,current_sha256=sha(new/rel),previous_sha256=sha(old/rel),reconstructed_sha256=sha(scratch/rel),only_scratch_copies_modified=True,exact=True))
invariants=json.loads((b/'r256-static-grid-source-audit-1066/receipt.json').read_text())['invariants']+[dict(name=n,sha256=sha(new/'project/experiments/control_v1'/n))for n in ['static_grid_regression.py','global_snapshot_analysis.py']]
for x in invariants:assert sha(new/'project/experiments/control_v1'/x['name'])==sha(old/'project/experiments/control_v1'/x['name'])==x['sha256']
artifacts=[]
for seed in [971,972]:
 for p in(reg/'coarse-multicast'/('full-'+str(seed))).iterdir():
  if p.is_file()and p.name!='router':artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1016,unchanged_manifest_files=1012,changed_files=sorted(changed),backouts=rows,invariants=invariants,full_route_positive=2,rejected=2,old_static_two_routes_main_native_snapshot_bytes_exact=True,actual_artifacts=artifacts,inputs={str(patch):sha(patch),str(child):sha(child),str(reg/'receipt.json'):sha(reg/'receipt.json'),str(new/'source-manifest.json'):sha(new/'source-manifest.json')},scope='Actual1115 two40x40syntheticfull24net routes containing3/6terminalordinarynets and8finite native nets,actualmulticast coarsehits/independentwholefinaltree/budget/occupancy andround8replay;2invalidcontexts/globalfailurewithsnapshotbutnofinaloutput. Previousstatic2paths/main/native/snapshotbytesexact andallnestedactualoldregressionsretained. Threeproductionfilesexactlybackoutto1094inownedscratch;26priornative/resource/finalgate/helperinvariantsunchanged. Real453die9380/grids2345andallphysicalgatesunchanged;microfixture40isnotfloorplan change. No physical/systempassinferred.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1016,unchanged=1012,backouts=3,invariants=len(invariants),positives=2,rejected=2)))
