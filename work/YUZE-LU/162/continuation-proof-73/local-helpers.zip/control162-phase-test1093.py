from pathlib import Path
import sys,tempfile,random,json,collections,hashlib
h=Path(__file__).parent;sys.path.insert(0,str(h/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from global_snapshot_analysis import phase_conflicts,inputs
rng=random.Random(162);checks=[];out=h/'control162-phase-test1093';out.mkdir()
for case in range(32):
 stride=(8,16,32)[case%3];nets={};paths={};owners=collections.defaultdict(list);locked=3
 for index in range(50):
  x=rng.randrange(4,13);y=rng.randrange(4,13);points=[(x,y,0),(x+1,y,0)];name='net_'+str(index);terminals=[(x,y),(x+1,y)];
  if index%7==0:terminals.append((x,y))
  nets[name]=terminals;paths[name]=points
  for v in points:owners[v].append(index)
 raw=[str(len(nets))]
 for name,points in paths.items():raw+=[name+' 1',str(len(points))+' '+' '.join(str(c)for v in points for c in v)]
 p=out/('case-'+str(case)+'.txt');p.write_text('\n'.join(raw)+'\n',encoding='utf-8');actual=phase_conflicts(p,nets,20,20,locked,stride);expected=collections.Counter();hist=collections.Counter()
 for vertex,indices in owners.items():
  if len(indices)<2:continue
  hist[str(len(indices))]+=1
  if any(i<locked for i in indices):key='includes-native'
  elif any(len(nets['net_'+str(i)])!=2 for i in indices):key='includes-ordinary-multicast'
  elif len({i%stride for i in indices})==1:key='ordinary-pairs-one-phase'
  else:key='ordinary-pairs-multiple-phases'
  expected[key]+=1
 assert actual['categories']==dict(expected)and actual['occupancy_histogram']==dict(hist)and actual['conflict_nodes']==sum(expected.values());checks.append(dict(case=case,actual=actual,independent_expected=dict(expected)))
base=(h/'control162-release-fixture946/input-971.txt').read_text(encoding='utf-8');header,body=base.split('\n',1);fields=header.split();valid=[];invalid=[]
for cost in [2,8,32]:
 f=fields.copy();f[15]=str(cost);p=out/('cost-'+str(cost)+'.txt');p.write_text(' '.join(f)+'\n'+body,encoding='utf-8');assert inputs(p)[0][15]==cost;valid.append(cost)
for index,value in [(7,'0'),(13,'0'),(15,'3'),(16,'0'),(4,'81')]:
 f=fields.copy();f[index]=value;p=out/('invalid-'+str(index)+'.txt');p.write_text(' '.join(f)+'\n'+body,encoding='utf-8')
 try:inputs(p)
 except AssertionError:invalid.append(index)
 else:raise AssertionError('Malformed input accepted')
result=dict(passed=True,whole_system_qualified=False,independent_phase_cases=checks,valid_current_costs=valid,invalid_headers_rejected=invalid,source_sha256=hashlib.sha256(Path(sys.path[0],'global_snapshot_analysis.py').read_bytes()).hexdigest());(out/'receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print('32independentphasehistograms/3validcosts/5invalidheaders passed')
