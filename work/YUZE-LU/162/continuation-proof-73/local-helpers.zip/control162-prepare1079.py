from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-read1073.py').read_text(encoding='utf-8').replace("[(95098,'dynamic-02/node3',10551)]","[(97097,'dynamic-08/node6',10161)]").replace('r256-static-grid-slot-admission-1073','r256-global-diagnostic-slot-admission-1078')
(h/'control162-read1078.py').write_text(s,encoding='utf-8')
s=(h/'control162-refill1067-remote.py').read_text(encoding='utf-8').replace('sready1067-static-grid-reg-refill','sready1079-global-diagnostic-refill').replace('sready1065-static-grid-controls','sready1076-global-diagnostic').replace("[(6,97097,'dynamic-08/node6',9811,'source-972',0)]","[(6,97097,'dynamic-08/node6',10161,'source-1013',0)]").replace('r256-access-warm-slot-admission-1051','r256-global-diagnostic-slot-admission-1078')
a=s.index("reason='");z=s.index("')\n",a)
s=s[:a]+"reason='Replace exactown10161source1013 oldcoarse8partial withsource1064actual10710round8completepathdiagnostic1076 oncomputeonly. Actual1065/1066/1072passed; UID10011/job97097/node6/PID/cmd/source/out/currentgraph/raw1078SHA andfresh323.2GiBavailable forfuture256GiBforecast verified. No finalrouteorwinningtrial mayexist. Everyoldsource/spec/raw/partial preserved, keep10160oldcoarse and10430/10431/10550accesscontrols and10710/10711newstaticchains.8parents4x16c64/6x16c96dynamic,foreign/externalR/parentsuntouched. Analysis32GiB only,complete snapshots notqualification'"+s[z+1:]
compile(s,'1079','exec');(h/'control162-refill1079-remote.py').write_text(s,encoding='utf-8');print('Prepared1078freshspec and1079computeanalysis slotguard')
