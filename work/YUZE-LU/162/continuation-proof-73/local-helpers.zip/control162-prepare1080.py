from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-audit1069.py').read_text(encoding='utf-8')
s=s.replace('r256-coarse-access-active-pool-audit-1069','r256-static-grid-active-pool-audit-1080').replace('for seed in [10430,10431,10550,10551]','for seed in [10710,10711]').replace('{10430:2,10431:2,10550:8,10551:32}','{10710:8,10711:2}')
s=s.replace("[(95155,5,'dynamic-03/node5',[10430],[6360,8301,9810,10430]),(97097,6,'dynamic-08/node6',[10431],[10160,10161,10431]),(95098,3,'dynamic-02/node3',[10550,10551],[5260,6561,10550,10551])]","[(97097,6,'dynamic-08/node6',[10710],[10160,10431,10710]),(95098,3,'dynamic-02/node3',[10711],[5260,6561,10550,10711])]")
s=s.replace("assert '--ordinary-coarse-static'not in cmd","assert '--ordinary-coarse-static'in cmd;assert ('--global-route-snapshot=8'in cmd)==(Path(cmd[1]).parent.name=='trial-0')").replace('{10430:16,10431:8,10550:16,10551:16}','{10710:16,10711:8}')
s=s.replace("r['comparisons'].append(","assert snapshot.with_name('output.txt.global-round-8.txt').is_file()==(i==0);r['comparisons'].append(")
s=s.replace('new_owned_children=64','new_owned_children=32').replace('observed16cpu_masks_disjoint_three_nodes=True','observed16cpu_masks_disjoint_two_nodes=True')
a=s.index("scope='");z=s.index("')\n",a)
s=s[:a]+"scope='Actual10710/10711 each16owned source1064staticgridchildren;32actualinputbodies/importedzero-prefixbytesmatch9060trial0. Realcommandsstatic/access/stride16-8 andheadercost8-2;onlytrial0hassnapshotCLI andactualround8file,noneofother30children requestsorwritesglobaldump. Observedownedrouting16CPUmasksdisjointnode6three/node3four;fourthnode6slot analysis1085isnotclaimedasroutingmask. Allactualcontrolleradmissionspassed. NativeM1-M10/finitewirebudget/finalgatesunchanged. Snapshotandsearchdiagnosticsonly,no physical/systempassinferred'"+s[z+1:]
compile(s,'1080','exec');(h/'control162-audit1080.py').write_text(s,encoding='utf-8');print('Prepared32actualstaticchildandsnapshotpolicy audit')
