from pathlib import Path
h=Path(__file__).parent
for old,new in [('queue1081','queue1090'),('audit1082','audit1091')]:
 s=(h/('control162-'+old+'-remote.py')).read_text(encoding='utf-8').replace('sready1081','sready1090').replace('r256-final-chain-binding-audit-1082','r256-final-chain-binding-audit-1091').replace('10810','10900').replace('r256-global-round-diagnostic-1076','r256-global-round-diagnostic-1085')
 compile(s,new,'exec');(h/('control162-'+new+'-remote.py')).write_text(s,encoding='utf-8')
print('Preparedreplacement10900 chain after1085; faileddependency10810immutable retained')
