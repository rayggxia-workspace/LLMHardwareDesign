from pathlib import Path
import json,hashlib
h=Path(__file__).parent;b='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';fixture=h/'control162-multicast-probe1103/fixture-input.txt';(h/'control162-config1105.json').write_text(json.dumps(dict(previous_static=b+'/r256-static-grid-regression-1065',static_config=b+'/config1065.json',multicast_fixture=b+'/multicast-fixture1105.txt',multicast_fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest()),indent=2),encoding='utf-8')
s=(h/'control162-queue1065.py').read_text(encoding='utf-8').replace('source-1064','source-1104').replace('r256-static-grid-regression-1065','r256-coarse-multicast-regression-1105').replace('sready1065-static-grid-controls','sready1105-coarse-multicast-controls').replace('00-u-sready1065-static-grid-regression','00-y-sready1105-coarse-multicast-regression').replace('--static-grid-regression-config','--coarse-multicast-regression-config').replace('config1065.json','config1105.json')
s=s.replace('r256-coarse-access-regression-1041','r256-static-grid-regression-1065').replace('r256-coarse-access-source-audit-1042','r256-static-grid-source-audit-1066')
# Source verification is independent from and precedes queue creation.
marker='q="""';i=s.index(marker)+len(marker)
verification="""import hashlib
from pathlib import Path
import json
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1104');m=json.loads((r/'source-manifest.json').read_text());assert m['commit']=='fee54929b6f3f0a13de1360a76d8d272db23205a'and len(m['files'])==1016;assert json.loads((r/'freeze-import.json').read_text())['archive_sha256']=='1eeb775b94563cd3a0edde6e825fed06b9c71d7c4afe3be1651a0c0bcb3604b7';assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
"""
s=s[:i]+verification+s[i:];compile(s,'1105','exec');(h/'control162-queue1105.py').write_text(s,encoding='utf-8')
print('Prepared1105strictsource-first queue and3/6sinkfixture config')
