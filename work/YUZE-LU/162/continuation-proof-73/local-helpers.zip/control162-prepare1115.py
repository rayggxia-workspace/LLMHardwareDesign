from pathlib import Path
import json,hashlib
h=Path(__file__).parent;p=h/'control162-multicast-probe1103/fixture-input.txt';data=p.read_bytes().replace(b'\r\n',b'\n');assert b'\r'not in data;(h/'control162-multicast-fixture1115.txt').write_bytes(data)
cfg=json.loads((h/'control162-config1105.json').read_text(encoding='utf-8'));cfg['multicast_fixture']=cfg['multicast_fixture'].replace('multicast-fixture1105','multicast-fixture1115');cfg['multicast_fixture_sha256']=hashlib.sha256(data).hexdigest();(h/'control162-config1115.json').write_bytes((json.dumps(cfg,indent=2)+'\n').encode())
s=(h/'control162-queue1105.py').read_text(encoding='utf-8').replace('r256-coarse-multicast-regression-1105','r256-coarse-multicast-regression-1115').replace('sready1105','sready1115').replace('config1105.json','config1115.json');(h/'control162-queue1115.py').write_text(s,encoding='utf-8')
s=(h/'control162-audit1106-remote.py').read_text(encoding='utf-8').replace('r256-coarse-multicast-regression-1105','r256-coarse-multicast-regression-1115').replace('r256-coarse-multicast-source-audit-1106','r256-coarse-multicast-source-audit-1116').replace('Actual1105','Actual1115');(h/'control162-audit1116-remote.py').write_text(s,encoding='utf-8')
for old,new in [('queue1110','queue1120'),('audit1111','audit1121')]:
 s=(h/('control162-'+old+'-remote.py')).read_text(encoding='utf-8').replace('sready1110','sready1120').replace('r256-final-chain-binding-audit-1111','r256-final-chain-binding-audit-1121').replace('r256-coarse-multicast-regression-1105','r256-coarse-multicast-regression-1115').replace('r256-coarse-multicast-source-audit-1106','r256-coarse-multicast-source-audit-1116')
 for a,z in [(11100,11200),(11101,11201),(11102,11202),(11103,11203),(11104,11204),(11105,11205)]:s=s.replace(str(a),str(z))
 compile(s,new,'exec');(h/('control162-'+new+'-remote.py')).write_text(s,encoding='utf-8')
print('1115LFfixture/confignewimmutable retry;original1105CRLFfailurepreserved,1116auditand1120/1121chainsready')
