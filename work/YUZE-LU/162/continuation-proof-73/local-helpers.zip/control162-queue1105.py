from pathlib import Path
import subprocess,shlex
q="""import hashlib
from pathlib import Path
import json
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1104');m=json.loads((r/'source-manifest.json').read_text());assert m['commit']=='fee54929b6f3f0a13de1360a76d8d272db23205a'and len(m['files'])==1016;assert json.loads((r/'freeze-import.json').read_text())['archive_sha256']=='1eeb775b94563cd3a0edde6e825fed06b9c71d7c4afe3be1651a0c0bcb3604b7';assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1104';assert(source/'freeze-import.json').is_file()and(source/'source-manifest.json').is_file();out=b/'r256-coarse-multicast-regression-1105';record=b/'route-selection-102/sready1105-coarse-multicast-controls';assert not record.exists();record.mkdir();name='00-y-sready1105-coarse-multicast-regression';p=b/'dynamic-08/node6/pending'/(name+'.json');assert not p.exists()and not out.exists()
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=16,requires=[str(b/'r256-static-grid-regression-1065/receipt.json'),str(b/'r256-static-grid-source-audit-1066/receipt.json'),str(b/'r256-coarse-c96-active-pool-audit-1036/receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--coarse-multicast-regression-config',str(b/'config1105.json'),'--out',str(out)])
tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),spec=spec)],whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=True,path=str(p),source=str(source))))
"""
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],universal_newlines=True))
