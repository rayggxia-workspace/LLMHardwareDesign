from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-global-round-diagnostic-1085/receipt.json';r=dict(time=time.time(),receipt=json.loads(p.read_text())if p.exists()else None)
code="import os,json;rows=[]\\nfor n in os.listdir('/proc'):\\n if not n.isdigit():continue\\n try:\\n  p='/proc/'+n;assert os.stat(p).st_uid==10011;cmd=open(p+'/cmdline','rb').read().decode().split(chr(0))\\n  if any(x.endswith('/source-1084/project/experiments/control_v1/system_upper.py')for x in cmd):rows.append(dict(pid=n,command=cmd,status=open(p+'/status').read(),stat=open(p+'/stat').read(),cpu_affinity=sorted(os.sched_getaffinity(int(n)))))\\n except (OSError,AssertionError):pass\\nprint(json.dumps(rows))"
r['processes']=json.loads(subprocess.check_output(['srun','--jobid=97097','--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-read1092';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);d=json.loads(raw)
print(json.dumps(dict(receipt=d['receipt'],processes=[dict(pid=p['pid'],mask=p['cpu_affinity'],memory=[l for l in p['status'].splitlines()if l.startswith(('VmRSS:','VmHWM:','State:'))],stat=p['stat'])for p in d['processes']])))
