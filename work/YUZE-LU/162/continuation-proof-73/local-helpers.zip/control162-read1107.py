from pathlib import Path
import subprocess,shlex
q='''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[];forecasts=[]
for job,node,folder,target in [(95098,3,'dynamic-02/node3',5260),(95341,2,'dynamic-05/node2',4660),(95391,4,'dynamic-05/node4',4670),(95204,25,'dynamic-04/node25',4661),(96222,24,'dynamic-06/node26',5494)]:
 queue=b/folder;state=json.loads((queue/'queue-state.json').read_text());fs=[]
 for name in state['active']:
  p=queue/'pending'/(name+'.json');raw=p.read_bytes();s=json.loads(raw);fs.append([name,s['forecast_gib']]);a=s['args']
  if '--out'in a and Path(a[a.index('--out')+1]).parent.name==str(target):rows.append(dict(job=job,node=node,folder=folder,target=target,path=str(p),sha256=hashlib.sha256(raw).hexdigest(),spec=s))
 forecasts.append(dict(job=job,node=node,forecasts=fs))
out=b/'r256-multicast-slot-admission-1107';assert not out.exists()and len(rows)==5;out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,forecasts=forecasts,whole_system_qualified=False),indent=2));print(json.dumps(dict(forecasts=forecasts,selected=[dict(target=r['target'],source=r['spec']['source_root'],graph=r['spec']['args'][r['spec']['args'].index('--graph')+1],out=r['spec']['args'][r['spec']['args'].index('--out')+1])for r in rows])))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
