import ast,subprocess,shlex
from pathlib import Path
tree=ast.parse(Path(r'D:\Data\电路实验\control162-capacity-route106.py').read_text(encoding='utf-8'));q=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='q'for t in n.targets))
q=q.replace("'source-106'","'source-107'").replace('[(1060,1070,4,8),(1061,1071,6,16)]','[(1061,1081,2,16)]').replace('router-weight-regression-02','router-weight-regression-03')
for a in ['route','geometry','pg-audit','upper-sta','final-delivery']:q=q.replace('drive-capacity-'+a+'-01','drive-capacity-'+a+'-02')
q=q.replace('capacity-route-source106.json','equal-score-capacity-route-source107-1081.json').replace('Two larger routing-space placements','One larger routing-space placement').replace('Refilled2 released placement slots with2 full routes and12 dependent actual geometry/PG/3cornerSTA/joint steps.','Queued second equal-score candidate1081 and6dependent actual physical gates; takes the released trace slot after the higher-priority trace finishes.')
assert '1081,2,16'in q
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
