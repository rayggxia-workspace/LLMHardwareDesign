from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1104';new=b/'source-1134';reg=b/'r256-coarse-zero-regression-1135';out=b/'r256-coarse-zero-source-audit-1136';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=json.loads((reg/'receipt.json').read_text());assert root['passed']and root['stage']=='ordinary-coarse-zero-focused-regression-only';child=reg/'coarse-zero/receipt.json';assert root['inputs'][str(child)]==sha(child);r=json.loads(child.read_text());assert r['passed']and not r['whole_system_qualified']and not r['route_qualified']and len(r['full_route_positives'])==2 and len(r['rejected'])==2 and r['coarse_zero_global_failure_rejected']
for p,v in r['inputs'].items():assert sha(p)==v
for x in r['full_route_positives']:assert x['proof']['final_conflicts']==0 and x['proof']['coarse_zero_trace']and sum(t['coarse_zero_hits']for t in x['proof']['coarse_zero_trace'])>0 and x['independent_final']['all_trees_flood_verified']and x['independent_final']['all_wire_budgets_verified']and x['independent_final']['conflict_nodes']==0
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','coarse_zero_regression.py']};assert set(a['files'])<=set(z['files'])and len(z['files'])==1017
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='cd533b18af196e18d6461a09c9ec5c84f98921da26d02540092fea47b7dbf12a'
for p,v in z['files'].items():assert sha(new/p)==v
out.mkdir();scratch=out/'reverse-copies';scratch.mkdir();files=['tree_router.cpp','tree_router_cpp.py','system_upper.py'];rows=[]
for name in files:
 rel=Path('project/experiments/control_v1')/name;target=scratch/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((new/rel).read_bytes())
patch=b/'backout1136.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in files:
 rel=Path('project/experiments/control_v1')/name;assert(scratch/rel).read_bytes()==(old/rel).read_bytes();rows.append(dict(name=name,current_sha256=sha(new/rel),previous_sha256=sha(old/rel),reconstructed_sha256=sha(scratch/rel),only_scratch_copies_modified=True,exact=True))
invariants=json.loads((b/'r256-coarse-multicast-source-audit-1116/receipt.json').read_text())['invariants']+[dict(name='coarse_multicast_regression.py',sha256=sha(new/'project/experiments/control_v1/coarse_multicast_regression.py'))]
for x in invariants:assert sha(new/'project/experiments/control_v1'/x['name'])==sha(old/'project/experiments/control_v1'/x['name'])==x['sha256']
artifacts=[]
for seed in [971,972]:
 for p in(reg/'coarse-zero'/('full-'+str(seed))).iterdir():
  if p.is_file()and p.name!='router':artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1017,unchanged_manifest_files=1013,changed_files=sorted(changed),backouts=rows,invariants=invariants,full_route_positive=2,rejected=2,old_multicast_two_routes_main_native_snapshot_bytes_exact=True,actual_artifacts=artifacts,inputs={str(patch):sha(patch),str(child):sha(child),str(reg/'receipt.json'):sha(reg/'receipt.json'),str(new/'source-manifest.json'):sha(new/'source-manifest.json')},scope='Actual1135twofullsynthetic24net routes with3/6terminalordinarynets and8finite native nets,actualfreecoarsehits auditedagainstcurrentoccupancyinC++,independentfinalwhole-tree/budget/occupancy andround8replay.2invalidcontexts/globalfailurewithsnapshotbutnofinaloutput. Previousmulticast2fullpaths/main/native/snapshotbytesexact andnestedactual104oracle/earlierreplaysretained. Threeproductionfilesexactlybackoutto1104inownedscratch;27priornative/resource/finalgate/helperinvariantsunchanged. Actual453die/grid/nativefinite solver/fullgeometryPG3RC300MHz unchanged. Freeatselectiontime nevergrantsfinalsystemacceptance.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1017,unchanged=1013,backouts=3,invariants=len(invariants),positives=2,rejected=2)))
