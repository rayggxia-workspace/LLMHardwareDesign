from pathlib import Path
b=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control/project/experiments/control_v1')
p=b/'tree_router_cpp.py';s=p.read_text(encoding='utf-8');a='global_snapshot_round=0,ordinary_coarse_multicast=False):';assert s.count(a)==1;s=s.replace(a,'global_snapshot_round=0,ordinary_coarse_multicast=False,ordinary_coarse_zero=False):')
a='    assert not ordinary_coarse_multicast or ordinary_coarse_static';assert s.count(a)==1;s=s.replace(a,"    assert not ordinary_coarse_zero or ordinary_coarse_multicast\n    if ordinary_coarse_zero:extra_cli.append('--ordinary-coarse-zero')\n"+a)
a='        ordinary_coarse_multicast=ordinary_coarse_multicast,';assert s.count(a)==1;s=s.replace(a,"        ordinary_coarse_zero=ordinary_coarse_zero,coarse_zero_trace=[r for r in trace if 'coarse_zero_attempts'in r],\n"+a);p.write_bytes(s.encode())
p=b/'system_upper.py';s=p.read_text(encoding='utf-8');a="    p.add_argument('--route-ordinary-coarse-multicast',action='store_true')";assert s.count(a)==1;s=s.replace(a,a+"\n    p.add_argument('--route-ordinary-coarse-zero',action='store_true')")
a="    p.add_argument('--coarse-multicast-regression-config',type=Path)";assert s.count(a)==1;s=s.replace(a,a+"\n    p.add_argument('--coarse-zero-regression-config',type=Path)")
a='    assert not a.route_ordinary_coarse_multicast or a.route_ordinary_coarse_static';assert s.count(a)==1;s=s.replace(a,'    assert not a.route_ordinary_coarse_zero or a.route_ordinary_coarse_multicast\n'+a)
a='ordinary_coarse_multicast=a.route_ordinary_coarse_multicast)';assert s.count(a)==1;s=s.replace(a,'ordinary_coarse_multicast=a.route_ordinary_coarse_multicast,ordinary_coarse_zero=a.route_ordinary_coarse_zero)')
a='        if a.coarse_multicast_regression_config:';assert s.count(a)==1;s=s.replace(a,"""        if a.coarse_zero_regression_config:
            from coarse_zero_regression import run
            config=a.coarse_zero_regression_config;helper=Path(__file__).with_name('coarse_zero_regression.py')
            for path in (a.manifest,a.graph,config,Path(__file__),helper):receipt['inputs'][str(path)]=sha(path)
            child=a.out/'coarse-zero';result=run(config,child)
            assert result['passed']and not result['whole_system_qualified']and not result['route_qualified']
            receipt['inputs'].update(result['inputs']);receipt['inputs'][str(child/'receipt.json')]=sha(child/'receipt.json')
            receipt.update(passed=True,stage=result['stage'],scope=result['scope'])
            return
"""+a);p.write_bytes(s.encode());print('Addeddefaultoffstrictzerocoarse switchandfocusedregression dispatch')
