from pathlib import Path
b=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control/project/experiments/control_v1')
p=b/'tree_router_cpp.py';s=p.read_text(encoding='utf-8');a='ordinary_coarse_multicast=False,ordinary_coarse_zero=False):';assert s.count(a)==1;s=s.replace(a,'ordinary_coarse_multicast=False,ordinary_coarse_zero=False,global_batch_ripup=False):')
a='    assert not ordinary_coarse_zero or ordinary_coarse_multicast';assert s.count(a)==1;s=s.replace(a,"    assert not global_batch_ripup or(ordinary_coarse_zero and native_prefix_flexible)\n    if global_batch_ripup:extra_cli.append('--global-batch-ripup')\n"+a)
a='        ordinary_coarse_zero=ordinary_coarse_zero,';assert s.count(a)==1;s=s.replace(a,"        global_batch_ripup=global_batch_ripup,global_batch_trace=[r for r in trace if 'global_batch_native_trees'in r],\n"+a);p.write_bytes(s.encode())
p=b/'system_upper.py';s=p.read_text(encoding='utf-8');a="    p.add_argument('--route-ordinary-coarse-zero',action='store_true')";assert s.count(a)==1;s=s.replace(a,a+"\n    p.add_argument('--route-global-batch-ripup',action='store_true')")
a="    p.add_argument('--coarse-zero-regression-config',type=Path)";assert s.count(a)==1;s=s.replace(a,a+"\n    p.add_argument('--global-batch-regression-config',type=Path)")
a='    assert not a.route_ordinary_coarse_zero or a.route_ordinary_coarse_multicast';assert s.count(a)==1;s=s.replace(a,'    assert not a.route_global_batch_ripup or(a.route_ordinary_coarse_zero and a.route_native_prefix_flexible)\n'+a)
a='ordinary_coarse_zero=a.route_ordinary_coarse_zero)';assert s.count(a)==1;s=s.replace(a,'ordinary_coarse_zero=a.route_ordinary_coarse_zero,global_batch_ripup=a.route_global_batch_ripup)')
a='        if a.coarse_zero_regression_config:';assert s.count(a)==1;s=s.replace(a,"""        if a.global_batch_regression_config:
            from global_batch_regression import run
            config=a.global_batch_regression_config;helper=Path(__file__).with_name('global_batch_regression.py')
            for path in (a.manifest,a.graph,config,Path(__file__),helper):receipt['inputs'][str(path)]=sha(path)
            child=a.out/'global-batch';result=run(config,child)
            assert result['passed']and not result['whole_system_qualified']and not result['route_qualified']
            receipt['inputs'].update(result['inputs']);receipt['inputs'][str(child/'receipt.json')]=sha(child/'receipt.json')
            receipt.update(passed=True,stage=result['stage'],scope=result['scope'])
            return
"""+a);p.write_bytes(s.encode());print('Addeddefaultoff fullstage dirty-upper batch andexplicitregressiondispatch')
