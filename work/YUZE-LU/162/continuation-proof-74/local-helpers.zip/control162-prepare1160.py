from pathlib import Path
h=Path(__file__).parent
mapping={'source-1134':'source-1154','sready1140':'sready1160','11400':'11600','11401':'11601','r256-coarse-zero-regression-1135':'r256-global-batch-regression-1155','r256-coarse-zero-source-audit-1136':'r256-global-batch-source-audit-1156','r256-final-chain-binding-audit-1141':'r256-final-chain-binding-audit-1161'}
for old,new in [('queue1140','queue1160'),('audit1141','audit1161')]:
 s=(h/('control162-'+old+'-remote.py')).read_text(encoding='utf-8')
 for a,b in mapping.items():s=s.replace(a,b)
 if old=='queue1140':
  s=s.replace("'--route-ordinary-coarse-zero',","'--route-ordinary-coarse-zero','--route-global-batch-ripup',")
  s=s.replace('Frozen1134all1017','Frozen1154all1018').replace('actual1135focusedregressionand1136threeexactbackouts27invariants plus1141','actual1155focusedregressionand1156threeexactbackouts28invariants plus1161').replace('11600uses1135','11600uses1155').replace('5890source587guardafterraw1132','7200source717guardafterraw1152').replace('Firststrictlyfreecoarsecandidatebeforeunchangedweighted/densefallback','Batchripallgloballydirtynativeandordinaryuppercandidatestogetherbeforeexistingnativefirstfiniteandordinaryrouting').replace('plus11400node5','plus11600node5')
 else:s=s.replace("assert '--route-ordinary-coarse-zero'in route['args']","assert '--route-global-batch-ripup'in route['args'];assert '--route-ordinary-coarse-zero'in route['args']")
 compile(s,new,'exec');(h/('control162-'+new+'-remote.py')).write_bytes(s.encode())
s=(h/'control162-refill1142-remote.py').read_text(encoding='utf-8')
for a,b in mapping.items():s=s.replace(a,b)
s=s.replace('sready1142-coarse-zero-node7','sready1162-global-batch-node7').replace("5890,'source-587'","7200,'source-717'").replace('r256-coarse-zero-slot-admission-1132','r256-global-batch-slot-admission-1152').replace('5890source587','7200source717').replace('raw1132','raw1152').replace('actual1135/1136and1141','actual1155/1156and1161').replace('source1134cost32strictzerocoarse','source1154cost32globalbatch').replace('KeepCUGR3751old359and5640/7200','KeepCUGR3751old359and5640/11401')
compile(s,'1162','exec');(h/'control162-refill1162-remote.py').write_bytes(s.encode())
print('Prepared1160fullchains1161bindings1162exact7200guard')
