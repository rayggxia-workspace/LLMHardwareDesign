from pathlib import Path
p=Path(__file__).parent
s=(p/'control162-progress1144.py').read_text(encoding='utf-8').replace('11400','11600').replace('11401','11601').replace('progress1144','progress1163')
(p/'control162-progress1163.py').write_bytes(s.encode())
s=(p/'control162-audit1145.py').read_text(encoding='utf-8').replace('r256-coarse-zero-active-audit-1145','r256-global-batch-active-audit-1164').replace('11400','11600').replace('11401','11601').replace('6360,9810,10430,11600','6360,10430,11400,11600').replace('5640,7200,11601','5640,11401,11601').replace('source1134','source1154')
s=s.replace("assert '--ordinary-coarse-zero'in cmd","assert '--global-batch-ripup'in cmd;assert '--ordinary-coarse-zero'in cmd")
s=s.replace("assert trace and sum(t['coarse_zero_attempts']for t in trace)>0;","assert trace and sum(t['coarse_zero_attempts']for t in trace)>0;batch=[json.loads(line)for line in(p.parent/'router.log').read_text().splitlines()if line.startswith('{')and 'global_batch_native_trees'in line];assert batch and sum(t['global_batch_native_trees']for t in batch)>0 and sum(t['global_batch_ordinary_trees']for t in batch)>0;")
s=s.replace('Eachactualchildexecutedfreecoarseattempts','Eachactualchildexecutedfreecoarseattemptsandbatchremovedbothnativeandordinarytrees')
compile(s,'1164','exec');(p/'control162-audit1164.py').write_bytes(s.encode())
