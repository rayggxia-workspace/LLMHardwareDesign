from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-phase-progress1126.py').read_text(encoding='utf-8').replace('[11200,11201,11202,11203,11204,11205]','[11600,11601]').replace('phase-progress1126','phase-progress1165')
s=s.replace("last_native=next", "last_batch=next((r for r in reversed(records)if 'global_batch_native_trees'in r),None),last_zero=next((r for r in reversed(records)if 'coarse_zero_hits'in r),None),last_native=next")
(h/'control162-phase-progress1165.py').write_bytes(s.encode())
