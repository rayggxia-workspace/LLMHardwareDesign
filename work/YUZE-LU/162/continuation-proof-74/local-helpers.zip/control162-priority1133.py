from pathlib import Path
import ast,subprocess,shlex
s=Path(r'D:\Data\电路实验\control162-queue113.py').read_text(encoding='utf-8');tree=ast.parse(s)
# Reuse the already reviewed full-pipeline template, append a fresh seed only.
tree0=ast.parse(Path(r'D:\Data\电路实验\control162-capacity-route106.py').read_text(encoding='utf-8'));q=next(ast.literal_eval(n.value)for n in tree0.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='q'for t in n.targets))
q=q.replace("'source-106'","'source-113'").replace('[(1060,1070,4,8),(1061,1071,6,16)]','[(1066,1133,3,1)]').replace('router-weight-regression-02','router-weight-regression-07')
for a in ['route','geometry','pg-audit','upper-sta','final-delivery']:q=q.replace('drive-capacity-'+a+'-01','drive-deferred-access-'+a+'-01')
q=q.replace("'--route-trials','16'","'--route-trials','16','--negotiate-priority-routes','--defer-access-vias','--lock-native-output-routes'").replace("'01-c-capacity-route-'","'01-b-deferred-priority-'").replace('capacity-route-source106.json','deferred-access-route-source113-1133.json')
q=q.replace('Refilled2 released placement slots with2 full routes and12 dependent actual geometry/PG/3cornerSTA/joint steps.','Queued a fresh priority-access candidate1133 before other new routes, plus all6 physical successors; no existing specs altered. ')
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
