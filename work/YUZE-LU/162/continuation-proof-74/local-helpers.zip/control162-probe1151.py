from pathlib import Path
import json,subprocess,concurrent.futures,random
h=Path(__file__).parent;out=h/'control162-globalbatch-probe1151';out.mkdir();base=(h/'control162-release-fixture946/input-971.txt').read_text(encoding='utf-8');header,body=base.split('\n',1);prefix=h/'control162-release-fixture946/before-971.txt.native-prefix-paths.txt';used=set();f=header.split();f[:2]=[str(40),str(40)];header=chr(32).join(f)
for line in body.splitlines():
 row=line.split();used.update(tuple(map(int,row[2+2*i:4+2*i]))for i in range(int(row[1])))
lines=prefix.read_text(encoding='utf-8').splitlines();at=1
for _ in range(int(lines[0])):
 name,k=lines[at].split();at+=1
 for _ in range(int(k)):
  row=list(map(int,lines[at].split()));at+=1;used.update((row[i],row[i+1])for i in range(1,len(row),3))
free=[(x,y)for x in range(4,36)for y in range(4,36)if(x,y)not in used];random.Random(162).shuffle(free);assert len(free)>=5
rows=[line.split()for line in body.splitlines()]
for n,extra in [(8,free[:1]),(9,free[1:5])]:
 r=rows[n];r[1]=str(2+len(extra));rows[n]=r[:-1]+[str(c)for p in extra for c in p]+r[-1:]
body='\n'.join(' '.join(r)for r in rows)+'\n';(out/'fixture-input.txt').write_text(header+'\n'+body,encoding='utf-8');binary=h/'control162-globalbatch1150.exe'
def one(seed):
 p=out/str(seed);p.mkdir();fields=header.split();fields[3]=str(seed);(p/'input.txt').write_text(' '.join(fields)+'\n'+body,encoding='utf-8')
 with(p/'log.txt').open('w')as log:r=subprocess.run([str(binary),str(p/'input.txt'),str(p/'output.txt'),'--critical-first','--native-prefix-first','--pin-access=none','--native-prefix-flexible','--native-prefix-input='+str(prefix),'--weighted-bidirectional','--ordinary-zero-pattern','--ordinary-coarse=16','--ordinary-coarse-access','--ordinary-coarse-static','--ordinary-coarse-multicast','--ordinary-coarse-zero','--global-batch-ripup','--global-route-snapshot=8'],stdout=log,stderr=subprocess.STDOUT)
 return dict(seed=seed,passed=r.returncode==0,last=(p/'log.txt').read_text().splitlines()[-1])
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:result=list(pool.map(one,range(971,1003)))
(out/'receipt.json').write_text(json.dumps(dict(rows=result,multicast_sizes=[3,6],new_sinks=free[:5]),indent=2),encoding='utf-8');print(json.dumps(result))
