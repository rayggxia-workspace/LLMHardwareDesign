from pathlib import Path
import subprocess,shlex
q="""import hashlib
from pathlib import Path
import json
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1134');m=json.loads((r/'source-manifest.json').read_text());assert m['commit']=='16f7082fae1c256cb5bb2a0ffe7e14300e709a77'and len(m['files'])==1017;assert json.loads((r/'freeze-import.json').read_text())['archive_sha256']=='cd533b18af196e18d6461a09c9ec5c84f98921da26d02540092fea47b7dbf12a';assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1134';assert(source/'freeze-import.json').is_file()and(source/'source-manifest.json').is_file();out=b/'r256-coarse-zero-regression-1135';record=b/'route-selection-102/sready1135-coarse-zero-controls';assert not record.exists();record.mkdir();name='00-z-sready1135-coarse-zero-regression';p=b/'dynamic-03/node5/pending'/(name+'.json');assert not p.exists()and not out.exists()
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=16,requires=[str(b/'r256-coarse-multicast-regression-1115/receipt.json'),str(b/'r256-coarse-multicast-source-audit-1116/receipt.json'),str(b/'r256-multicast-six-node-active-audit-1124/receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--coarse-zero-regression-config',str(b/'config1135.json'),'--out',str(out)])
tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),spec=spec)],whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=True,path=str(p),source=str(source))))
"""
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],universal_newlines=True))
