from pathlib import Path
import subprocess,shlex
q="""import hashlib
from pathlib import Path
import json
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1154');m=json.loads((r/'source-manifest.json').read_text());assert m['commit']=='a5dce0c738e77133e509a368d7e950a9d05564d8'and len(m['files'])==1018;assert json.loads((r/'freeze-import.json').read_text())['archive_sha256']=='78e8713dc82a301b0060dfa12c2574cda7c902126b42d259a1026706739e87d4';assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1154';assert(source/'freeze-import.json').is_file()and(source/'source-manifest.json').is_file();out=b/'r256-global-batch-regression-1155';record=b/'route-selection-102/sready1155-global-batch-controls';assert not record.exists();record.mkdir();name='00-za-sready1155-global-batch-regression';p=b/'dynamic-03/node5/pending'/(name+'.json');assert not p.exists()and not out.exists()
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=16,requires=[str(b/'r256-coarse-zero-regression-1135/receipt.json'),str(b/'r256-coarse-zero-source-audit-1136/receipt.json'),str(b/'r256-coarse-zero-active-audit-1145/receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--global-batch-regression-config',str(b/'config1155.json'),'--out',str(out)])
tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),spec=spec)],whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=True,path=str(p),source=str(source))))
"""
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],universal_newlines=True))
