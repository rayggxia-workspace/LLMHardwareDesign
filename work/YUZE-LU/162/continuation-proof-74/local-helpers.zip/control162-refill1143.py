import ast,subprocess,shlex
from pathlib import Path
tree=ast.parse(Path(r'D:\Data\电路实验\control162-capacity-route106.py').read_text(encoding='utf-8'));q=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='q'for t in n.targets))
q=q.replace("'source-106'","'source-114'").replace('[(1060,1070,4,8),(1061,1071,6,16)]','[(1060,1143,2,1)]').replace('router-weight-regression-02','router-weight-regression-09')
for a in ['route','geometry','pg-audit','upper-sta','final-delivery']:q=q.replace('drive-capacity-'+a+'-01','drive-wire-resource-'+a+'-01')
q=q.replace("'--route-trials','16'","'--route-trials','16','--negotiate-priority-routes','--defer-access-vias','--lock-native-output-routes'").replace("'01-c-capacity-route-'","'01-a-budget-priority-'").replace('capacity-route-source106.json','wire-resource-route-source114-1143.json')
q=q.replace('Refilled2 released placement slots with2 full routes and12 dependent actual geometry/PG/3cornerSTA/joint steps.','Refilled completed native-cap audit slot with1143 full route plus6real physical gates on source-bound parent1060, zero violations in strengthened native-ground-plus-upper necessary test. ')
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
