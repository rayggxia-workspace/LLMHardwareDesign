from pathlib import Path
import subprocess,shlex
q=r'''from pathlib import Path
import json,hashlib,time,subprocess,traceback
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates';out=b/'r256-product-history-active-audit-1173';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();r=dict(passed=False,whole_system_qualified=False,time=time.time(),comparisons=[],pools=[]);out.mkdir()
try:
 for seed in [11700,11701]:
  manifest=b/'r256-composition-453'/('warm-seed-'+str(seed)+'.json');cfg=json.loads(manifest.read_text());original=Path(cfg['input']);prefix=Path(cfg['prefix']);assert sha(original)==cfg['input_sha256']and sha(prefix)==cfg['prefix_sha256']
  h,body=original.read_bytes().split(b'\n',1)
  for i in range(16):
   p=root/str(seed)/'route'/('trial-'+str(i))/'input.txt';assert p.read_bytes().split(b'\n',1)[1]==body;assert int(p.read_text().splitlines()[0].split()[11])==1;assert int(p.read_text().splitlines()[0].split()[15])=={11700:8,11701:32}[seed]
   snapshot=p.parent/'output.txt.native-prefix-paths.txt';assert sha(snapshot)==cfg['prefix_sha256']
   log=p.parent/'output.txt.native-prefix.log';lines=[json.loads(x)for x in log.read_text().splitlines()if x.startswith('{')];rows=[x for x in lines if'conflict_nodes'in x];assert len(rows)==1 and rows[0]['conflict_nodes']==0 and rows[0]['round']==0
   assert i==0 or not snapshot.with_name('output.txt.global-round-8.txt').exists();trace=[json.loads(line)for line in(p.parent/'router.log').read_text().splitlines()if line.startswith('{')and 'coarse_zero_hits'in line];assert trace and sum(t['coarse_zero_attempts']for t in trace)>0;r['comparisons'].append(dict(candidate=seed,trial=i,input_sha256=sha(p),seed_manifest=str(manifest),seed_manifest_sha256=sha(manifest),seed_native_prefix_sha256=sha(prefix),actual_imported_prefix_sha256=sha(snapshot),native_rounds=rows,original_input_body_byte_exact=True,actual_warm_zero_prefix_byte_exact=True))
 for job,node,folder,selected,all_seeds in [(95098,3,'dynamic-02/node3',[11700],[6561,10711,11201,11700]),(97097,6,'dynamic-08/node6',[11701],[10710,10900,11200,11701])]:
  details=subprocess.check_output(['scontrol','show','job',str(job),'-o'],universal_newlines=True);assert 'UserId=yuzelu(10011)'in details and 'JobName=yzl-ctl162-'in details and 'NodeList=node'+str(node)+' 'in details
  binaries={str(root/str(seed)/'route/router'):seed for seed in all_seeds}
  code="import os,json;rows=[]\nfor n in os.listdir('/proc'):\n if not n.isdigit():continue\n try:\n  p='/proc/'+n;assert os.stat(p).st_uid==10011\n  e=os.readlink(p+'/exe')\n  if e in "+repr(binaries)+":\n   cmd=open(p+'/cmdline','rb').read().decode().split(chr(0));rows.append(dict(pid=n,binary=e,seed="+repr(binaries)+"[e],command=[x for x in cmd if x],cpu_affinity=sorted(os.sched_getaffinity(int(n)))))\n except (OSError,AssertionError):pass\nprint(json.dumps(rows))"
  procs=json.loads(subprocess.check_output(['srun','--jobid='+str(job),'--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));masks={}
  for seed in all_seeds:
   found=[x for x in procs if x['seed']==seed];assert found,(seed,'no live owned child');mask=found[0]['cpu_affinity'];assert len(mask)==16 and all(x['cpu_affinity']==mask for x in found);masks[seed]=set(mask)
   if seed not in selected:continue
   assert len(found)==16,(seed,len(found))
   for row in found:
    cmd=row['command'];assert all(flag in cmd for flag in ['--ordinary-endpoint-escape','--weighted-bidirectional','--trace-routing-phases','--ordinary-zero-maze=16384','--native-prefix-first','--pin-access=none','--native-prefix-flexible','--critical-first','--ordinary-zero-pattern','--resource-labels=8000000'])
    assert '--native-prefix-input='+json.loads((b/'r256-composition-453'/('warm-seed-'+str(seed)+'.json')).read_text())['prefix']in cmd;assert not any(x.startswith('--native-refresh=')for x in cmd);assert '--ordinary-coarse-access'in cmd;assert '--global-batch-ripup'not in cmd;assert '--ordinary-coarse-zero'in cmd and '--ordinary-coarse-multicast'in cmd;assert '--ordinary-coarse-static'in cmd;assert ('--global-route-snapshot=8'in cmd)==(Path(cmd[1]).parent.name=='trial-0');assert '--ordinary-coarse='+str({11700:16,11701:16}[seed])in cmd;assert not any(x.startswith(('--native-zero-maze=','--ordinary-search-margin','--ordinary-congestion-scale'))for x in cmd)
   queue=b/folder;name=next(n for n in json.loads((queue/'queue-state.json').read_text())['active']if n.endswith('-'+str(seed)));p=queue/'commands'/(name+'.json');command=json.loads(p.read_text());a=command['admission'];assert a['admitted']and a['available_bytes']>a['required_bytes'];r.setdefault('actual_admissions',[]).append(dict(seed=seed,path=str(p),sha256=sha(p),admission=a))
  assert all(not(masks[a]&masks[z])for a in masks for z in masks if a<z)
  r['pools'].append(dict(job=job,node=node,selected=selected,all_owned_live_processes=procs,observed16cpu_masks_pairwise_disjoint=True,job_details=details))
 r.update(passed=True,scope='Actual32owned source1154existingproducthistorychildren11700/11701;32actualinputbodies/importedprefixesmatch9060trial0withheaderhistory_product1andcost8/32,notglobalbatch. Actualfreecoarseattemptsobserved,realzero/multicast/static/access/stride16flagsandfirsttrialonlysnapshotCLIverified. Actualnode3/node6eachfour16CPU masksdisjointandactualcontrolleradmissionchecked.8parents36x16dynamicwithc96sixmasksunchanged. Existinghistoryparameteralreadycoveredbyoriginalactualrouterregression,noproductioncodechange;exactfullcombinationsmustpassownfinalgates,no physical/systemacceptanceinferred')
except BaseException as e:r.update(error=str(e),traceback=traceback.format_exc());raise
finally:(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(passed=r['passed'],new_owned_children=32,input_and_live_native_prefix_pairs=len(r['comparisons']),observed16cpu_masks_disjoint_two_nodes=True)))
'''
compile(q,'audit961remote','exec');print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())

