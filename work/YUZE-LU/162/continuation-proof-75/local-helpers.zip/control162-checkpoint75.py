from pathlib import Path
import json,hashlib,zipfile,io,re,datetime
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';out=repo/'work/YUZE-LU/162/continuation-proof-75';sha=lambda b:hashlib.sha256(b).hexdigest();index=json.loads((out/'index.json').read_text(encoding='utf-8'));raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==index['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in index['files'].values()if v['copied']};assert set(z.namelist())==set(rows)and z.testzip()is None
 for n,v in rows.items():b=z.read(n);assert sha(b)==v['sha256']and len(b)==v['bytes']
 reg=json.loads(z.read('r256-coarse-neighbors-regression-1185/coarse-neighbors/receipt.json'));assert reg['passed']and len(reg['candidate_checks'])==144
 audit=json.loads(z.read('r256-coarse-neighbors-source-audit-1186/receipt.json'));assert audit['passed']and len(audit['invariants'])==29 and audit['native_finite_branch_bytes_exact']
entries={}
for name in ['control162-proof75-remote.py','control162-checkpoint75.py','control162-verify75.py']:
 p=h/name;entries[name]=p
for p in h.glob('control162-*'):
 m=re.search(r'(\d+)(?:-remote|-verified)?\.(?:py|json|patch)$',p.name)
 if p.is_file()and m and 1166<=int(m.group(1))<=1202 and p.stat().st_size<3000000:entries[p.relative_to(h).as_posix()]=p
for name in ['control162-neighbor-probe1179','control162-neighbor-probe1180','control162-neighbor-probe1181','control162-neighbor-candidates1183','control162-neighbors-probe1183','control162-failures1191','control162-compare1167','control162-profile1200']:
 p=h/name
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file()and f.suffix!='.exe'and f.stat().st_size<3000000:entries[f.relative_to(h).as_posix()]=f
diag=h/'LLMHardwareDesign-deliveries/issue-162/route-diagnostic1177'
for f in diag.iterdir():
 if f.is_file()and f.stat().st_size<3000000:entries[f.relative_to(h).as_posix()]=f
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Local orchestration,actual SHA-bound frame replay/attribution/heatmap,exploratory candidate probes including failures,and copied actual5s profile.66MB original frame remains indexed onauthorizedserver. Not full physical acceptance.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint75

更新时间：{now}。YUZE-LU，Issue [#162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162)、Draft PR [#163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)，承接[Checkpoint74](continuation-checkpoint-74.md)。继续实施、不合并。

**完整组合尚未通过。** 当前仍无完整零冲突全图及最终几何、PG、low/base/high分布RC下300MHz setup/hold/电气联合通过。六宏、R256、S1350内部驱动、23类/138原生文件和345状态宿主保留。472三初态8数值程序和473/480外部AXI握手、host计划、结束故障事件继续绑定，不冒称内部dispatch波形。外部R修订和其他任务不动。

11700/11701复用冻结source1154，仅打开已有乘法历史拥塞参数，不打开global batch，其他条件对照11400/11401。1171严格核验14份完整七阶段规格/六键验收/当前453图和函数事件及各自未来几何/PG/三档时序/交付路径。1173实核32进程、32输入体/导入前缀逐字一致、header history=1、真实参数、两节点各4×16CPU互斥和实际内存。随后已有尝试触发原`finite-resource search label memory envelope exhausted`，1191记录拒绝且无最终输出，原内存上限未提高；候选仍按原尝试队列运行，不能据中间最小冲突值称其通过。1167对原11400/1与成组重布11600/1做同trial同轮匹配，前八轮成组方案超额占用更大；仅是这些前缀的观察，不宣称最终收敛或普遍性能结论。

本地1177对SHA绑定的实际10710 trial0第8轮66MB全路径再次执行原树连通/单位边/有限线长预算/占用检查，所有指标及tile排名与1085相同：968340冲突点、1006134超额占用。新增归属统计为跨源块或TOP的网-冲突顶点参与数1864707、源块内109767，二者合计是网参与数1974474，不是去重物理冲突数；前者约94.4%。1178独立重新累积全部网占用生成双层热图，四项总指标逐项与1177一致。主要热点在S仲裁与适配器交汇区域；这不证明物理不可行，也不单凭此改宏边界。原全路径仅服务器索引；本地包含小型报告和图。

相邻搜索线的本地探索1180/1181分别覆盖32/256条确定采样的实际普通双端网，移除本网络原路径后，使用人为的64×当前占用搜索代价、weight1和方向代价8，对比原稀疏候选及加入相邻单位坐标的候选。256例中220例代价降低，累计经过已占用点的步数42432→38292；该代价不是实际历史拥塞状态，不能推成全图收益。每条实际单位边、端点、固定pin和棋盘via检查，扩展候选图最小代价不增。初次1179确定抽样条件只取得不足32例而拒绝，失败目录原样保留；1180/1181是新目录修订，未改生产源或真实网格。

source1184为`4c05fcb63046ff7c6a33e77564fba668a641a811`，1019源，归档SHA256 `68ce9a135b6bfcf1b878795106c7278d8217b4ee4b4893f665a6720794a340b6`。1014项旧源只读硬链接，6项复制含清单；首次在传tar之前调用导入器只留下空目录，随后保留为source-1184-empty-import-01，上传后冻结并完整核验，未在空导入时排队。新增默认关闭的相邻候选搜索线选项，仅普通粗网格加入±1真实单位坐标；物理2345×2345格、4µm pitch、9380µm die、M1–M10、pin/棋盘via、native有限求解器/预算及最终门不变。

实际1185通过144份独立压缩图比较（96精确代价、48加权合法性），包含相邻候选图超集可达/最小代价、单位边和状态展开上界。两份完整40×40合成路线971/972零冲突、独立最终树/预算/占用和第8轮重算通过；两个非法上下文及974全局失败有诊断而无最终输出均拒绝。原1155两路线主/native日志、路径、快照逐字回放，全部嵌套旧实际回归通过。1186核验完整1019源/1014旧项、四生产文件自有scratch精确回退到1154、29项native/resource/最终门/helper不变量及native有限分支字节完全一致。最初未执行audit1186.py草稿把不变量数写28，正式audit1186-final.py读原28项加global_batch_regression.py实核29；二者都保留，不把草稿当实际回执。

11920/11921已进入当前453/S5380/R256原七阶段链，node5/node7、stride16、方向代价8/32、拥塞比例1、加法历史、global batch关闭。1193严格核验14规格及自己的未来route/geometry/PG/low-base-high/delivery路径；1195实核32真实子进程和输入体/导入前缀逐字一致、header history=0、实际相邻候选尝试、所有参数与仅trial0诊断CLI、CPU互斥和实际内存准入。全部六组11200–11205及11400/1、11600/1、11700/1对照继续。原生单块、小合成、native零前缀、首轮或诊断图都不是系统物理验收。

资源仍8父节点36×16CPU动态补位、c64 4×16/c96 6×16。1172仅核验替换本人10550/source1040/95098.171和10431/source1040/97097.50；1188仅6360/source633/95155.124，1194仅5640/source474/96297.70。每次先验证原规格SHA、UID10011/job/实际node/PID/cmd/source/out/当前453图、全部日志、无最终/获胜输出及实时内存；全部旧源/规格/失败/部分产物保留。11920用1185结束空位，node5未来256GiB预测/323.2GiB准入；node7未来224/284.8。1197读回实际准入均通过，未降低并发、未取消父节点或操作外部R/CUGR3751。实际1200只对node5本人11920 trial0运行进程做5秒CPU-clock采样：495样本/无丢样，coarse函数自身39.60%、main18.99%、std队列pop11.52%；只代表该进程这5秒，不是全局运行时间份额或收益证明，未改变进程亲和或暂停任务。

[远程源索引](continuation-proof-75/index.json)核对{index['indexed_files']}项文件SHA，{index['copied_files']}原字节在[ZIP](continuation-proof-75/selected-originals.zip)逐entry SHA/CRC验证；失败内存上限日志也保留。14份live日志为不可变读取前缀，未冒称最终输出。[本地辅助索引](continuation-proof-75/local-index.json)/[ZIP](continuation-proof-75/local-helpers.zip)含{len(meta)}项编排、图、报告和局部探索原件；实际Git blob提交时另核验。源码已精确非强推发布，未合并。

规则rayggxia-project-collab1.0.0；project_id llm-hardware-design；管理结构检查PASS。登记management-hub PR5 pending；缺board.json，看板unverified/同步pending，处理人待指定；审查人待指定。Issue in_progress、PR Draft/open/未合并。继续读取真实全图，失败持续定位，完成全部声明组合最终六文件、版图、真实M11/M12、三档300MHz及源绑定，不放宽门、不提前宣布通过。
'''
(repo/'work/YUZE-LU/162/continuation-checkpoint-75.md').write_bytes(doc.encode())
summary=f'''# Issue162：相邻搜索线回归通过，完整组合物理验收继续

更新时间：{now}。[Checkpoint75](../work/YUZE-LU/162/continuation-checkpoint-75.md) / [源绑定索引](../work/YUZE-LU/162/continuation-proof-75/index.json)。实际1185通过144独立候选检查、2完整合成路线/独立最终树预算占用与第8轮、旧batch主/native/路径/快照逐字回放及嵌套旧回归；1186实核1019源、4代码精确回退、29不变量/native有限分支不变。11920/11921进入原7阶段，1193严格14规格，1195实核32进程/输入/前缀/真实相邻尝试/CPU和内存。1177/1178对实际第8轮完整线路归属与热图独立重算；11700/1部分尝试触及原有限搜索内存上限被拒绝，未提高上限。

**仍无完整零冲突全图及几何/PG/三档RC300MHz联合通过，任务继续、不合并。** 保留六宏/R256/S内部驱动/23类原生文件及345状态宿主。8父节点36×16动态、c96六独立任务，全部旧原件保留，外部R/其他任务不动。继续最终六文件/版图/组合验证/源绑定。登记PR5 pending；看板unverified/同步pending；审查人待指定。

'''
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;old=p.read_text(encoding='utf-8');second=old.find('\n# ',1);assert second>0;p.write_bytes((summary.replace('../work/',prefix+'work/')+old[second+1:]).encode())
print(json.dumps(dict(indexed=index['indexed_files'],copied=index['copied_files'],helpers=len(meta),all_ZIP_SHA_CRC=True)))
