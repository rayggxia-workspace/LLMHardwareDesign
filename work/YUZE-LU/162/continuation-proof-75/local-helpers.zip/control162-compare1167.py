from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates';rows=[]
for old,new in [(11400,11600),(11401,11601)]:
 trials=[]
 for i in range(16):
  logs=[]
  for seed in [old,new]:
   p=root/str(seed)/'route'/('trial-'+str(i))/'router.log'
   with p.open('rb')as f:raw=f.read(4000000)
   records=[]
   for line in raw.decode(errors='replace').splitlines():
    if line.startswith('{'):
     try:records.append(json.loads(line))
     except ValueError:pass
   global_rows={r['round']:r for r in records if'conflict_nodes'in r and r['conflict_nodes']!=0};zero={r['round']:r for r in records if'coarse_zero_hits'in r};batch={r['round']:r for r in records if'global_batch_native_trees'in r}
   logs.append(dict(candidate=seed,path=str(p),prefix_bytes=len(raw),prefix_sha256=hashlib.sha256(raw).hexdigest(),global_rows=global_rows,zero=zero,batch=batch))
  common=sorted(set(logs[0]['global_rows'])&set(logs[1]['global_rows']))
  trials.append(dict(trial=i,logs=logs,common_rounds=common))
 summary=[]
 for k in range(8):
  eligible=[x for x in trials if k in x['common_rounds']]
  if eligible:
   r=dict(round=k,matched_trials=len(eligible))
   for j,label in enumerate(['retained_dirty','batch_dirty']):
    r[label]=dict(mean_excess=sum(x['logs'][j]['global_rows'][k]['excess_occupancy']for x in eligible)/len(eligible),mean_zero_hits=sum(x['logs'][j]['zero'].get(k,{}).get('coarse_zero_hits',0)for x in eligible)/len(eligible))
   summary.append(r)
 rows.append(dict(control=old,candidate=new,trials=trials,matched_summary=summary))
print(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False,scope='Bounded actual diagnostic log prefix read;same-trial same-round matched counts,not final performance or physical qualification.')))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-compare1167';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
for r in json.loads(raw)['rows']:print(json.dumps(dict(control=r['control'],candidate=r['candidate'],matched_summary=r['matched_summary'])))
