from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for seed in [11700,11701]:
 route=b/'r256-composition-453/upper-candidates'/str(seed)/'route';failures=[]
 for p in route.glob('trial-*/router.log'):
  with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-3000));tail=f.read().decode(errors='replace')
  lines=tail.splitlines();last=lines[-1]if lines else''
  if last.startswith(('Locked-source optimistic wire budget exceeded by this search:','disconnected','finite-resource','negotiation did not converge','resource'))or 'terminate called'in tail:
   raw=p.read_bytes();failures.append(dict(path=str(p),bytes=size,sha256=hashlib.sha256(raw).hexdigest(),tail=tail,final_route_exists=(p.parent/'output.txt').exists()))
 rows.append(dict(candidate=seed,trials=len(list(route.glob('trial-*/router.log'))),failures=failures,whole_system_qualified=False))
print(json.dumps(dict(time=time.time(),rows=rows)))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-failures1191';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
for row in json.loads(raw)['rows']:print(json.dumps(dict(candidate=row['candidate'],trials=row['trials'],failures=[dict(path=x['path'],tail=x['tail'][-500:],final_route_exists=x['final_route_exists'])for x in row['failures']])))
