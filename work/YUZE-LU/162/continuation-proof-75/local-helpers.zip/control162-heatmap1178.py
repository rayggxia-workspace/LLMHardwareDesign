from pathlib import Path
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import json,hashlib,time
h=Path(__file__).parent;b=h/'LLMHardwareDesign-deliveries/issue-162/route-diagnostic1177';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proof=json.loads((b/'cluster-attribution.json').read_text());snapshot=b/'output.txt.global-round-8.txt';assert sha(snapshot)==proof['inputs'][str(snapshot)];nx=ny=2345;plane=nx*ny;usage=np.zeros(2*plane,dtype=np.uint16)
with snapshot.open()as f:
 assert int(f.readline())==11149
 for _ in range(11149):
  name,branches=f.readline().split();points=set()
  for _ in range(int(branches)):
   raw=list(map(int,f.readline().split()));assert len(raw)==1+3*raw[0]
   points.update(raw[j+2]*plane+raw[j+1]*nx+raw[j]for j in range(1,len(raw),3))
  usage[np.fromiter(points,dtype=np.int64)]+=1
 assert not f.read().strip()
counts=dict(conflict_nodes=int(np.count_nonzero(usage>1)),excess_occupancy=int(np.maximum(usage.astype(np.int32)-1,0).sum()),occupied_cells=int(np.count_nonzero(usage)),summed_tree_vertices=int(usage.sum()))
assert all(counts[k]==proof['diagnostic'][k]for k in counts)
g=json.loads((b/'boundary-graph.json').read_text());p=json.loads((b/'placement.json').read_text());m=json.loads((b/'physical.json').read_text());fig,axes=plt.subplots(1,2,figsize=(15,7),constrained_layout=True);rows=[]
for layer,ax in enumerate(axes):
 indices=np.flatnonzero(usage[layer*plane:(layer+1)*plane]>1);x=indices%nx;y=indices//nx;grid,_,_=np.histogram2d(y,x,bins=32,range=[[0,ny],[0,nx]]);rows.append(grid.astype(int).tolist())
 image=ax.imshow(grid,origin='lower',extent=[0,9.38,0,9.38],cmap='magma',vmin=0,vmax=4000,interpolation='nearest')
 for name,origin in p['placements_um'].items():
  width,height=m['leaves'][g['instances'][name]]['die_um'];xx,yy=np.array(origin)/1000;ax.add_patch(Rectangle((xx,yy),width/1000,height/1000,fill=False,edgecolor='cyan',linewidth=.35,alpha=.75))
  if not name.startswith('link_'):ax.text(xx+width/2000,yy+height/2000,name,ha='center',va='center',fontsize=5,color='cyan')
 ax.set(title='M'+str(11+layer)+' conflicted vertices / tile',xlabel='x (mm)',ylabel='y (mm)',xlim=(0,9.38),ylim=(0,9.38));ax.set_aspect('equal')
fig.colorbar(image,ax=axes,shrink=.8,label='Actual conflicted vertices (32 x 32 bins)');fig.suptitle('10710 trial 0, completed round 8: intermediate wiring, not physical acceptance')
out=b/'round8-conflict-map.png';fig.savefig(out,dpi=180);plt.close(fig)
r=dict(passed=True,counts=counts,all_counts_match_independent1177=True,tiles=rows,whole_system_qualified=False,inputs={str(q):sha(q)for q in [snapshot,b/'input.txt',b/'placement.json',b/'physical.json',b/'boundary-graph.json',b/'cluster-attribution.json',Path(__file__)]},plot_sha256=sha(out));(b/'heatmap.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(dict(passed=True,counts=counts,plot=str(out))))
