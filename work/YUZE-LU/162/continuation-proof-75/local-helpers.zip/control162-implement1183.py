from pathlib import Path
import ast
h=Path(__file__).parent;r=h/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'
def change(name,edits):
 p=r/name;s=p.read_text(encoding='utf-8')
 for a,b,n in edits:assert s.count(a)==n,(name,a,s.count(a));s=s.replace(a,b)
 if name.endswith('.py'):ast.parse(s)
 p.write_bytes(s.encode())
change('ordinary_coarse_grid.h',[
 ('int expansion_limit=65536,bool local_access=false){','int expansion_limit=65536,bool local_access=false,bool neighbor_tracks=false){\n if(neighbor_tracks&&!local_access)throw runtime_error("neighbor tracks require local access");',1),
 (' for(int x=4+offset_x;x<nx-4;x+=stride)xs.push_back(x);',' for(int x=4+offset_x;x<nx-4;x+=stride){xs.push_back(x);if(neighbor_tracks)for(int d:{-1,1})if(x+d>=4&&x+d<nx-4)xs.push_back(x+d);}',1),
 (' for(int y=4+offset_y;y<ny-4;y+=stride)ys.push_back(y);',' for(int y=4+offset_y;y<ny-4;y+=stride){ys.push_back(y);if(neighbor_tracks)for(int d:{-1,1})if(y+d>=4&&y+d<ny-4)ys.push_back(y+d);}',1)])
change('tree_router.cpp',[
 ('argc>27','argc>28',1),
 ('bool global_batch=false,','bool ordinary_coarse_neighbors=false;bool global_batch=false,',1),
 ('  if(option=="--global-batch-ripup")','  if(option=="--ordinary-coarse-neighbors"){if(ordinary_coarse_neighbors)throw runtime_error("duplicate coarse neighbor option");ordinary_coarse_neighbors=true;}\n  else if(option=="--global-batch-ripup")',1),
 (' if(global_batch&&',' if(ordinary_coarse_neighbors&&!ordinary_coarse_zero)throw runtime_error("coarse neighbors require free coarse local-access mode");\n if(global_batch&&',1),
 ('65536,ordinary_coarse_access);','65536,ordinary_coarse_access,ordinary_coarse_neighbors);',2),
 ('  if(ordinary_coarse_zero)cout','  if(ordinary_coarse_neighbors)cout<<"{\\\"round\\\":"<<iteration<<",\\\"coarse_neighbor_tracks\\\":true,\\\"coarse_neighbor_attempts\\\":"<<coarse_attempts<<"}"<<endl;\n  if(ordinary_coarse_zero)cout',1)])
change('tree_router_cpp.py',[
 ('global_batch_ripup=False):','global_batch_ripup=False,ordinary_coarse_neighbors=False):',1),
 ('    assert not global_batch_ripup','    assert not ordinary_coarse_neighbors or ordinary_coarse_zero\n    if ordinary_coarse_neighbors:extra_cli.append(\'--ordinary-coarse-neighbors\')\n    assert not global_batch_ripup',1),
 ('        global_batch_ripup=global_batch_ripup,','        ordinary_coarse_neighbors=ordinary_coarse_neighbors,coarse_neighbors_trace=[r for r in trace if \'coarse_neighbor_tracks\'in r],\n        global_batch_ripup=global_batch_ripup,',1)])
change('system_upper.py',[
 ("    p.add_argument('--route-global-batch-ripup'","    p.add_argument('--route-ordinary-coarse-neighbors',action='store_true',help='Candidate search only: add adjacent unit coordinates to each coarse track; physical grid and all final gates unchanged')\n    p.add_argument('--route-global-batch-ripup'",1),
 ("    p.add_argument('--global-batch-regression-config'","    p.add_argument('--coarse-neighbors-regression-config',type=Path)\n    p.add_argument('--global-batch-regression-config'",1),
 ('        if a.global_batch_regression_config:',"        if a.coarse_neighbors_regression_config:\n            from coarse_neighbors_regression import run\n            config=a.coarse_neighbors_regression_config;helper=Path(__file__).with_name('coarse_neighbors_regression.py')\n            for path in (a.manifest,a.graph,Path(__file__),helper,config):receipt['inputs'][str(path)]=sha(path)\n            child=a.out/'coarse-neighbors';result=run(config,child)\n            assert result['passed']and not result['whole_system_qualified']\n            receipt['inputs'].update(result['inputs']);receipt['inputs'][str(child/'receipt.json')]=sha(child/'receipt.json')\n            receipt.update(passed=True,stage='ordinary-coarse-neighbors-focused-regression-only',whole_system_qualified=False)\n            return\n        if a.global_batch_regression_config:",1),
 ('global_batch_ripup=a.route_global_batch_ripup)','global_batch_ripup=a.route_global_batch_ripup,ordinary_coarse_neighbors=a.route_ordinary_coarse_neighbors)',1)])
print('Implemented default-off adjacent coarse search tracks;native solver and physical grid unchanged')
