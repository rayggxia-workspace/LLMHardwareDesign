from pathlib import Path
import json,subprocess,shlex,time
h=Path(__file__).parent;d=json.loads((h/'control162-diagnostic1085.json').read_text(encoding='utf-8'))['diagnostic'];names=[x['net']for x in d['top_nets']]
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');g=json.loads((b/'r256-composition-453/topology/boundary-graph.json').read_text());names=NAMES;links={r['instance']:r['source_instance']for r in g['boundary_links']['links']};rows=[]
for name in names:
 c=g['connections'].get(name[4:]);row=dict(net=name)
 if c:
  ends=[c['driver']]+c['sinks'];row.update(driver=c['driver'],sinks=c['sinks'][:6],sink_count=len(c['sinks']),parent_hosts=sorted(set(links.get(e['instance'],e['instance'])for e in ends)))
 rows.append(row)
print(json.dumps(rows))
'''.replace('NAMES',repr(names))
rows=json.loads(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50))
for x,y in zip(rows,d['top_nets']):assert x['net']==y['net'];x.update(y)
r=dict(time=time.time(),top_nets=rows,top_tiles=d['top_tiles'],all_diagnostic_metrics={k:d[k]for k in ['conflict_nodes','excess_occupancy','occupied_cells','summed_tree_vertices']},whole_system_qualified=False)
(h/'control162-map1176.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
print(json.dumps(dict(top_nets=[{k:x.get(k)for k in ['net','terminal_count','conflict_vertices','driver','parent_hosts']}for x in rows[:15]],top_tiles=d['top_tiles'][:10])))
