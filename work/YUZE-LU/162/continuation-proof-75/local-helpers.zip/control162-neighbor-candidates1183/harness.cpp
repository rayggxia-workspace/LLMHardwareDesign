#include <bits/stdc++.h>
using namespace std;
struct Item{int64_t priority,cost;int node;bool operator<(const Item&q)const{return priority!=q.priority?priority>q.priority:cost!=q.cost?cost>q.cost:node>q.node;}};
#include "ordinary_coarse_grid.h"
int main(){int n;cin>>n;while(n--){int nx,ny,s,g,stride,ox,oy,weight,np,neighbor;cin>>nx>>ny>>s>>g>>stride>>ox>>oy>>weight>>np>>neighbor;vector<int>cost(nx*ny*2),blocked(cost.size());for(int&v:cost)cin>>v;for(int&v:blocked)cin>>v;uint64_t expanded=0,checks=0;auto path=ordinary_coarse_grid(nx,ny,s,g,stride,ox,oy,weight,np,[&](int v){return cost[v];},[&](int v){return !blocked[v];},expanded,checks,65536,true,neighbor);cout<<path.size()<<' '<<expanded<<' '<<checks;for(int v:path)cout<<' '<<v;cout<<char(10);}}
