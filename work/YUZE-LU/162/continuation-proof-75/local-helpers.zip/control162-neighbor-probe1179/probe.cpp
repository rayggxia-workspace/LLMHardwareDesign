#include <bits/stdc++.h>
using namespace std;
struct Item{int64_t priority,cost;int node;bool operator<(const Item&q)const{if(priority!=q.priority)return priority>q.priority;if(cost!=q.cost)return cost<q.cost;return node>q.node;}};
#include "base.h"
#include "neighbors.h"
int main(int argc,char**argv){
 if(argc!=3)throw runtime_error("input and complete snapshot required");ifstream f(argv[1]);string line;getline(f,line);istringstream hs(line);vector<int>header;int v;while(hs>>v)header.push_back(v);if(header.size()!=17)throw runtime_error("header");int nx=header[0],ny=header[1],count=header[2],plane=nx*ny,size=plane*2;vector<string>names(count);vector<vector<int>>pins(count),trees(count);vector<int>fixed(size,-1),usage(size,0);vector<int>samples;
 for(int n=0;n<count;++n){int k,x,y,limit;f>>names[n]>>k;for(int j=0;j<k;++j){f>>x>>y;int q=y*nx+x;pins[n].push_back(q);if(fixed[q]!=-1&&fixed[q]!=n)throw runtime_error("foreign terminal collision");fixed[q]=n;}f>>limit;if(n>=header[6]&&k==2&&n%307==0&&samples.size()<32)samples.push_back(n);}
 if(samples.size()!=32)throw runtime_error("samples");ifstream dump(argv[2]);int total;dump>>total;if(total!=count)throw runtime_error("count");
 for(int n=0;n<count;++n){string name;int branches;dump>>name>>branches;if(name!=names[n])throw runtime_error("name");auto&tree=trees[n];for(int j=0;j<branches;++j){int k;dump>>k;for(int q=0;q<k;++q){int x,y,l;dump>>x>>y>>l;tree.push_back(l*plane+y*nx+x);}}sort(tree.begin(),tree.end());tree.erase(unique(tree.begin(),tree.end()),tree.end());for(int q:tree)++usage[q];}
 uint64_t conflicts=0,excess=0;for(int u:usage){conflicts+=u>1;excess+=max(0,u-1);}if(conflicts!=968340||excess!=1006134)throw runtime_error("snapshot metrics");
 cout<<"{\"snapshot_conflicts\":"<<conflicts<<",\"snapshot_excess\":"<<excess<<",\"cases\":[";bool comma=false;
 for(int n:samples){for(int q:trees[n])--usage[q];int ox=(uint64_t(n)*7+uint32_t(header[3])*3)%16,oy=(uint64_t(n)*11+uint32_t(header[3])*5)%16;oy=(oy&~1)|(ox&1);auto allowed=[&](int q){return fixed[q]<0||fixed[q]==n;};auto penalty=[&](int q){return int64_t(64)*usage[q];};
  struct Stats{int64_t cost=0;int conflicts=0;uint64_t expanded=0,checks=0;int vertices=0;};array<Stats,2>stats;
  for(int mode=0;mode<2;++mode){auto&s=stats[mode];vector<int>path=mode?ordinary_coarse_neighbors_grid(nx,ny,pins[n][1],pins[n][0],16,ox,oy,1,8,penalty,allowed,s.expanded,s.checks,65536,true):ordinary_coarse_grid(nx,ny,pins[n][1],pins[n][0],16,ox,oy,1,8,penalty,allowed,s.expanded,s.checks,65536,true);if(path.empty())throw runtime_error("candidate missing");s.vertices=path.size();if(path.front()!=pins[n][1]||path.back()!=pins[n][0])throw runtime_error("endpoint");
   for(size_t j=1;j<path.size();++j){int a=path[j-1],q=path[j],la=a/plane,lq=q/plane,x=a%nx,y=(a%plane)/nx,xx=q%nx,yy=(q%plane)/nx;int delta=abs(x-xx)+abs(y-yy)+abs(la-lq);if(delta!=1||!allowed(q)||(la!=lq&&(x+y)%2))throw runtime_error("physical unit edge");int base=la!=lq?3:(x!=xx?(la==0?1:8):(la==1?1:8));s.cost+=base+penalty(q);s.conflicts+=usage[q]>0;}
  }
  if(stats[1].cost>stats[0].cost)throw runtime_error("superset exact candidate cost increased");if(comma)cout<<',';comma=true;cout<<"{\"net\":\""<<names[n]<<"\",\"index\":"<<n<<",\"baseline\":{\"cost\":"<<stats[0].cost<<",\"conflict_steps\":"<<stats[0].conflicts<<",\"vertices\":"<<stats[0].vertices<<",\"expanded\":"<<stats[0].expanded<<"},\"neighbors\":{\"cost\":"<<stats[1].cost<<",\"conflict_steps\":"<<stats[1].conflicts<<",\"vertices\":"<<stats[1].vertices<<",\"expanded\":"<<stats[1].expanded<<"}}";
  for(int q:trees[n])++usage[q];
 }
 cout<<"]}"<<endl;
}
