from pathlib import Path
import subprocess,json,hashlib,time
h=Path(__file__).parent;root=h/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1';b=h/'LLMHardwareDesign-deliveries/issue-162/route-diagnostic1177';out=h/'control162-neighbor-probe1180';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=(root/'ordinary_coarse_grid.h').read_text(encoding='utf-8')
new=source.replace('ordinary_coarse_grid(', 'ordinary_coarse_neighbors_grid(')
for axis in ['x','y']:
 anchor=f' for(int {axis}=4+offset_{axis};{axis}<n{axis}-4;{axis}+=stride){axis}s.push_back({axis});'
 replacement=f' for(int {axis}=4+offset_{axis};{axis}<n{axis}-4;{axis}+=stride)for(int delta:{{-1,0,1}})if({axis}+delta>=4&&{axis}+delta<n{axis}-4){axis}s.push_back({axis}+delta);'
 assert new.count(anchor)==1;new=new.replace(anchor,replacement)
(out/'base.h').write_bytes(source.encode());(out/'neighbors.h').write_bytes(new.encode())
code=r'''#include <bits/stdc++.h>
using namespace std;
struct Item{int64_t priority,cost;int node;bool operator<(const Item&q)const{if(priority!=q.priority)return priority>q.priority;if(cost!=q.cost)return cost<q.cost;return node>q.node;}};
#include "base.h"
#include "neighbors.h"
int main(int argc,char**argv){
 if(argc!=3)throw runtime_error("input and complete snapshot required");ifstream f(argv[1]);string line;getline(f,line);istringstream hs(line);vector<int>header;int v;while(hs>>v)header.push_back(v);if(header.size()!=17)throw runtime_error("header");int nx=header[0],ny=header[1],count=header[2],plane=nx*ny,size=plane*2;vector<string>names(count);vector<vector<int>>pins(count),trees(count);vector<int>fixed(size,-1),usage(size,0);vector<int>samples;
 for(int n=0;n<count;++n){int k,x,y,limit;f>>names[n]>>k;for(int j=0;j<k;++j){f>>x>>y;int q=y*nx+x;pins[n].push_back(q);if(fixed[q]!=-1&&fixed[q]!=n)throw runtime_error("foreign terminal collision");fixed[q]=n;}f>>limit;if(n>=header[6]&&k==2)samples.push_back(n);}
 if(samples.size()<32)throw runtime_error("samples");vector<int>selected;for(int j=0;j<32;++j)selected.push_back(samples[(samples.size()-1)*j/31]);samples=selected;ifstream dump(argv[2]);int total;dump>>total;if(total!=count)throw runtime_error("count");
 for(int n=0;n<count;++n){string name;int branches;dump>>name>>branches;if(name!=names[n])throw runtime_error("name");auto&tree=trees[n];for(int j=0;j<branches;++j){int k;dump>>k;for(int q=0;q<k;++q){int x,y,l;dump>>x>>y>>l;tree.push_back(l*plane+y*nx+x);}}sort(tree.begin(),tree.end());tree.erase(unique(tree.begin(),tree.end()),tree.end());for(int q:tree)++usage[q];}
 uint64_t conflicts=0,excess=0;for(int u:usage){conflicts+=u>1;excess+=max(0,u-1);}if(conflicts!=968340||excess!=1006134)throw runtime_error("snapshot metrics");
 cout<<"{\"snapshot_conflicts\":"<<conflicts<<",\"snapshot_excess\":"<<excess<<",\"cases\":[";bool comma=false;
 for(int n:samples){for(int q:trees[n])--usage[q];int ox=(uint64_t(n)*7+uint32_t(header[3])*3)%16,oy=(uint64_t(n)*11+uint32_t(header[3])*5)%16;oy=(oy&~1)|(ox&1);auto allowed=[&](int q){return fixed[q]<0||fixed[q]==n;};auto penalty=[&](int q){return int64_t(64)*usage[q];};
  struct Stats{int64_t cost=0;int conflicts=0;uint64_t expanded=0,checks=0;int vertices=0;};array<Stats,2>stats;
  for(int mode=0;mode<2;++mode){auto&s=stats[mode];vector<int>path=mode?ordinary_coarse_neighbors_grid(nx,ny,pins[n][1],pins[n][0],16,ox,oy,1,8,penalty,allowed,s.expanded,s.checks,65536,true):ordinary_coarse_grid(nx,ny,pins[n][1],pins[n][0],16,ox,oy,1,8,penalty,allowed,s.expanded,s.checks,65536,true);if(path.empty())throw runtime_error("candidate missing");s.vertices=path.size();if(path.front()!=pins[n][1]||path.back()!=pins[n][0])throw runtime_error("endpoint");
   for(size_t j=1;j<path.size();++j){int a=path[j-1],q=path[j],la=a/plane,lq=q/plane,x=a%nx,y=(a%plane)/nx,xx=q%nx,yy=(q%plane)/nx;int delta=abs(x-xx)+abs(y-yy)+abs(la-lq);if(delta!=1||!allowed(q)||(la!=lq&&(x+y)%2))throw runtime_error("physical unit edge");int base=la!=lq?3:(x!=xx?(la==0?1:8):(la==1?1:8));s.cost+=base+penalty(q);s.conflicts+=usage[q]>0;}
  }
  if(stats[1].cost>stats[0].cost)throw runtime_error("superset exact candidate cost increased");if(comma)cout<<',';comma=true;cout<<"{\"net\":\""<<names[n]<<"\",\"index\":"<<n<<",\"baseline\":{\"cost\":"<<stats[0].cost<<",\"conflict_steps\":"<<stats[0].conflicts<<",\"vertices\":"<<stats[0].vertices<<",\"expanded\":"<<stats[0].expanded<<"},\"neighbors\":{\"cost\":"<<stats[1].cost<<",\"conflict_steps\":"<<stats[1].conflicts<<",\"vertices\":"<<stats[1].vertices<<",\"expanded\":"<<stats[1].expanded<<"}}";
  for(int q:trees[n])++usage[q];
 }
 cout<<"]}"<<endl;
}
'''
(out/'probe.cpp').write_bytes(code.encode());subprocess.run(['g++','-std=c++17','-O2',str(out/'probe.cpp'),'-o',str(out/'probe.exe')],check=True);start=time.time();p=subprocess.run([str(out/'probe.exe'),str(b/'input.txt'),str(b/'output.txt.global-round-8.txt')],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'stdout.json').write_bytes(p.stdout);(out/'stderr.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace');d=json.loads(p.stdout);assert len(d['cases'])==32
r=dict(passed=True,whole_system_qualified=False,seconds=time.time()-start,cases=d['cases'],inputs={str(p):sha(p)for p in [Path(__file__),root/'ordinary_coarse_grid.h',b/'input.txt',b/'output.txt.global-round-8.txt',out/'probe.cpp',out/'base.h',out/'neighbors.h',out/'probe.exe']},scope='Local exploratory candidate graph only:32deterministic actual ordinary pairs,removeownactualtreefromSHA-bound10710round8 occupancy. Compare exact weight1 coarsegraph candidates using fixed artificial64*usage cost,nonpreferred8;not actual historical negotiation costs. Neighborgraph adds +/-1coordinate to each coarse track without changing realunitgrid/pins/vias or any repository production file. Each returned unit edge and endpoints checked; superset cost never higher. This is not a full reroute or native/RC/physical qualification.')
(out/'receipt.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(dict(passed=True,cases=32,strict_cost_improvements=sum(x['neighbors']['cost']<x['baseline']['cost']for x in d['cases']),baseline_conflict_steps=sum(x['baseline']['conflict_steps']for x in d['cases']),neighbor_conflict_steps=sum(x['neighbors']['conflict_steps']for x in d['cases']),seconds=r['seconds'])))
