from pathlib import Path
p=Path(__file__).parent;s=(p/'control162-probe1151.py').read_text(encoding='utf-8').replace('globalbatch-probe1151','neighbors-probe1183').replace('control162-globalbatch1150.exe','control162-neighbors1183.exe').replace("'--global-batch-ripup'","'--ordinary-coarse-neighbors'")
compile(s,'1183','exec');(p/'control162-probe1183.py').write_bytes(s.encode())
