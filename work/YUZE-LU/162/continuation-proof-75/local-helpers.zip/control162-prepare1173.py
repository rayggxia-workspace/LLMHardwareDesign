from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1164.py').read_text(encoding='utf-8').replace('r256-global-batch-active-audit-1164','r256-product-history-active-audit-1173').replace('11600','11700').replace('11601','11701').replace("[(95155,5,'dynamic-03/node5',[11700],[6360,10430,11400,11700]),(96297,7,'dynamic-07/node7',[11701],[5640,11401,11701])]","[(95098,3,'dynamic-02/node3',[11700],[6561,10711,11201,11700]),(97097,6,'dynamic-08/node6',[11701],[10710,10900,11200,11701])]")
s=s.replace("assert all((root/str(seed)/'route'/('trial-'+str(i))/'input.txt').exists()for seed in [9490,9491]for i in range(16));",'')
s=s.replace("assert int(p.read_text().splitlines()[0].split()[15])", "assert int(p.read_text().splitlines()[0].split()[11])==1;assert int(p.read_text().splitlines()[0].split()[15])")
a=s.index("batch=[json.loads(line)");z=s.index("r['comparisons'].append",a);s=s[:a]+s[z:]
s=s.replace("assert '--global-batch-ripup'in cmd;","assert '--global-batch-ripup'not in cmd;")
a=s.index("scope='");z=s.index("')\n",a);s=s[:a]+"scope='Actual32owned source1154existingproducthistorychildren11700/11701;32actualinputbodies/importedprefixesmatch9060trial0withheaderhistory_product1andcost8/32,notglobalbatch. Actualfreecoarseattemptsobserved,realzero/multicast/static/access/stride16flagsandfirsttrialonlysnapshotCLIverified. Actualnode3/node6eachfour16CPU masksdisjointandactualcontrolleradmissionchecked.8parents36x16dynamicwithc96sixmasksunchanged. Existinghistoryparameteralreadycoveredbyoriginalactualrouterregression,noproductioncodechange;exactfullcombinationsmustpassownfinalgates,no physical/systemacceptanceinferred'"+s[z+1:]
compile(s,'1173','exec');(h/'control162-audit1173.py').write_bytes(s.encode())
s=(h/'control162-progress1163.py').read_text(encoding='utf-8').replace('11600','11700').replace('11601','11701').replace('progress1163','progress1175');(h/'control162-progress1175.py').write_bytes(s.encode())
print('Prepared1173actualhistoryheaderandCPUaudit')
