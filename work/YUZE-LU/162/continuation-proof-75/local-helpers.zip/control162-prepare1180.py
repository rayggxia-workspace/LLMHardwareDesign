from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-neighbor-probe1179.py').read_text(encoding='utf-8').replace('control162-neighbor-probe1179','control162-neighbor-probe1180')
s=s.replace('&&n%307==0&&samples.size()<32','')
s=s.replace('if(samples.size()!=32)throw runtime_error("samples");','if(samples.size()<32)throw runtime_error("samples");vector<int>selected;for(int j=0;j<32;++j)selected.push_back(samples[(samples.size()-1)*j/31]);samples=selected;')
compile(s,'1180','exec');(h/'control162-neighbor-probe1180.py').write_bytes(s.encode())
