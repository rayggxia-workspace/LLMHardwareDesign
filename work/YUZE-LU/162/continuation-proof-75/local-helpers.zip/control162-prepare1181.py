from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-neighbor-probe1180.py').read_text(encoding='utf-8').replace('control162-neighbor-probe1180','control162-neighbor-probe1181')
for a,b in [('if(samples.size()<32)','if(samples.size()<256)'),('for(int j=0;j<32;++j)','for(int j=0;j<256;++j)'),('*j/31','*j/255'),("len(d['cases'])==32","len(d['cases'])==256"),('cases=32','cases=256'),('32deterministic actual','256deterministic actual')]:s=s.replace(a,b)
compile(s,'1181','exec');(h/'control162-neighbor-probe1181.py').write_bytes(s.encode())
