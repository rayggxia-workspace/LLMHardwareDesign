from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-read1152.py').read_text(encoding='utf-8').replace('9810','6360').replace('7200','5640').replace('r256-global-batch-slot-admission-1152','r256-coarse-neighbors-slot-admission-1187')
(h/'control162-read1187.py').write_bytes(s.encode())
