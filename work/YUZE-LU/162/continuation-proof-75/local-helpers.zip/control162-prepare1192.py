from pathlib import Path
h=Path(__file__).parent
mapping={'source-1154':'source-1184','sready1160':'sready1192','11600':'11920','11601':'11921','r256-global-batch-regression-1155':'r256-coarse-neighbors-regression-1185','r256-global-batch-source-audit-1156':'r256-coarse-neighbors-source-audit-1186','r256-final-chain-binding-audit-1161':'r256-final-chain-binding-audit-1193'}
for old,new in [('queue1160','queue1192'),('audit1161','audit1193')]:
 s=(h/('control162-'+old+'-remote.py')).read_text(encoding='utf-8')
 for a,b in mapping.items():s=s.replace(a,b)
 s=s.replace('--route-global-batch-ripup','--route-ordinary-coarse-neighbors')
 if old=='queue1160':
  s=s.replace('a5dce0c738e77133e509a368d7e950a9d05564d8','4c05fcb63046ff7c6a33e77564fba668a641a811').replace("len(m['files'])==1018","len(m['files'])==1019").replace('78e8713dc82a301b0060dfa12c2574cda7c902126b42d259a1026706739e87d4','68ce9a135b6bfcf1b878795106c7278d8217b4ee4b4893f665a6720794a340b6').replace('>284.8','>323.2')
  a=s.index("scope='");z=s.index("'),indent=2)",a);s=s[:a]+"scope='Twofullcurrent453/S5380/R256sevenstagechains11920node5stride16cost8 and11921node7stride16cost32cong1,additivehistory/globalbatchOFF. Defaultoffadjacentcoarsecandidatecoordinates,physicalunitgrid/pins/vias/M1-M10unchanged. Frozen1184all1019sources/archiveverifiedbeforequeue;actual1185/1186regressionandfourbackouts29invariants plus1193strict14bindingsrequired. Preserve11400/11401and11600/11601and11700/11701andallsixmulticastcontrols.11920uses1185completionfree16CPUslot;11921onlyexactown5640source474guardafterraw1187SHA/UID/job/node/PID/cmd/source/out/graph/memory/nofinalorwinnerchecks. Node5future256GiBforecast/323.2GiBavailable,node7future224/284.8;8parents36x16dynamic,c96sixmasks. Alloldrawretained,noforeign/externalR/parentops,no physicalqualificationinferred'"+s[z+1:]
 compile(s,new,'exec');(h/('control162-'+new+'-remote.py')).write_bytes(s.encode())
s=(h/'control162-refill1162-remote.py').read_text(encoding='utf-8')
for a,b in mapping.items():s=s.replace(a,b)
s=s.replace('sready1162-global-batch-node7','sready1194-coarse-neighbors-node7').replace("7200,'source-717'","5640,'source-474'").replace('r256-global-batch-slot-admission-1152','r256-coarse-neighbors-slot-admission-1187').replace('>246.4','>284.8').replace('maximum_forecasts_gib=192','maximum_forecasts_gib=224').replace('required_available_gib=246.4','required_available_gib=284.8')
a=s.index("reason='");z=s.index("')\n",a);s=s[:a]+"reason='Onlyown5640source474partial on96297actualnode7replacedafterfreshraw1187specSHA/UID10011/job/node7/PID/cmd/source/out/current453graph/alllogs/nofinalorwinnerandactual284.8GiBavailableforfuture224GiBforecastchecked. New11921source1184neighborcandidatefullchainafteractual1185/1186/1193passed. PreserveCUGR3751and11401/11601controls,allsixmulticastandhistory11700/11701,8parents36x16dynamic,c96six16masks. Alloldrawsource/spec/failure/partialretained,noforeign/externalR/parentops. Physicalgrid/pitch/M1-M10/nativefinitebudgets/finalgeometryPG3RC300MHzunchanged,no systempassinferred'"+s[z+1:]
compile(s,'1194','exec');(h/'control162-refill1194-remote.py').write_bytes(s.encode())
print('Prepared1192chains1193bindings1194node7guard;do not execute before1185/1186PASS')
