from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1164.py').read_text(encoding='utf-8').replace('r256-global-batch-active-audit-1164','r256-coarse-neighbors-active-audit-1195').replace('11600','11920').replace('11601','11921').replace('source1154','source1184').replace("[6360,10430,11400,11920]","[10430,11400,11600,11920]").replace("[5640,11401,11921]","[11401,11601,11921]")
s=s.replace("assert all((root/str(seed)/'route'/('trial-'+str(i))/'input.txt').exists()for seed in [9490,9491]for i in range(16));",'')
s=s.replace("assert int(p.read_text().splitlines()[0].split()[15])","assert int(p.read_text().splitlines()[0].split()[11])==0;assert int(p.read_text().splitlines()[0].split()[15])")
a=s.index("batch=[json.loads(line)");z=s.index("r['comparisons'].append",a)
s=s[:a]+"neighbor=[json.loads(line)for line in(p.parent/'router.log').read_text().splitlines()if line.startswith('{')and 'coarse_neighbor_tracks'in line];assert neighbor and sum(t['coarse_neighbor_attempts']for t in neighbor)>0;"+s[z:]
s=s.replace("assert '--global-batch-ripup'in cmd;","assert '--global-batch-ripup'not in cmd and '--ordinary-coarse-neighbors'in cmd;")
a=s.index("scope='");z=s.index("')\n",a);s=s[:a]+"scope='Actual32owned source1184adjacentcoarsecandidatechildren11920/11921;32actualinputbodies/importedprefixesmatch9060trial0,additivehistoryandcost8/32,globalbatchOFF. Eachactualchildexecutedneighborcandidateattempts;realzero/multicast/static/access/stride16/neighborflagsandfirsttrialonlysnapshotCLIverified. Actualnode5four16CPU masksdisjoint,node7threeobservedrouter16CPUmasksdisjoint(CUGR3751notclaimedasrouterprocess);actualcontrolleradmissionchecked.8parents36x16dynamicwithc96sixmasksunchanged. Nativefinitebudget/realphysicalgrid/M1-M10/finalgeometryPG3RC300MHzgates unchanged. No finalrouteorphysical/systempassinferred'"+s[z+1:]
compile(s,'1195','exec');(h/'control162-audit1195.py').write_bytes(s.encode())
s=(h/'control162-progress1163.py').read_text(encoding='utf-8').replace('11600','11920').replace('11601','11921').replace('progress1163','progress1196');(h/'control162-progress1196.py').write_bytes(s.encode())
print('Prepared1195actual32neighborchildrenaudit/1196progress')
