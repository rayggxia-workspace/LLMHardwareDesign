from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-profile772-remote.py').read_text(encoding='utf-8').replace('r256-router-hotspot-profile-772','r256-coarse-neighbor-hotspot-profile-1200').replace("job='95391'","job='95155'").replace('NodeList=node4 ','NodeList=node5 ').replace('upper-candidates/7370','upper-candidates/11920').replace('compute node4 within own95391','compute node5 within own95155')
s=s.replace('import os,subprocess,json,shutil,time','import os,subprocess,json,shutil,time,hashlib')
needle="if perf:\n args="
assert s.count(needle)==1
s=s.replace(needle,"r['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(binary),Path(binary).parent/'trial-0/input.txt',Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1184/source-manifest.json'),Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/topology/boundary-graph.json')]}\nassert r['inputs']['/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/topology/boundary-graph.json']=='49ba0e348f3583f6facdf60e771fe6f1329b46fe5aac872c3828d4b61ddb1a68'\nif perf:\n args=")
compile(s,'1200','exec');(h/'control162-profile1200-remote.py').write_bytes(s.encode())
