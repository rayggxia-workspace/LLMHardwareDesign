from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [11700,11701]:
 root=b/'r256-composition-453/upper-candidates'/str(tag);r=dict(candidate=tag,receipts={},snapshots=[],trials=[])
 for folder in ['route','geometry','pg-audit','timing/low','timing/base','timing/high','delivery']:
  p=root/folder/'receipt.json'
  if p.exists():
   d=json.loads(p.read_text());r['receipts'][folder]={k:d[k]for k in ['passed','stage','error']if k in d}
 for p in sorted((root/'route').glob('trial-*/router.log')):
  with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-400000));raw=f.read().decode(errors='replace')
  records=[]
  for l in raw.splitlines():
   if l.startswith('{'):
    try:records.append(json.loads(l))
    except ValueError:pass
  r['trials'].append(dict(trial=p.parent.name,bytes=size,last_global=next((d for d in reversed(records)if 'conflict_nodes'in d),None),last_zero=next((d for d in reversed(records)if 'coarse_zero_hits'in d),None)))
 for p in (root/'route').glob('trial-*/output.txt.global-round-8.txt'):r['snapshots'].append(dict(path=str(p),bytes=p.stat().st_size))
 rows.append(r)
print(json.dumps(rows))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-progress1175';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
for r in json.loads(raw):
 v=[t['last_global']for t in r['trials']if t['last_global']];print(json.dumps(dict(candidate=r['candidate'],receipts=r['receipts'],trials=len(r['trials']),rounds=sorted(set(x['round']for x in v)),minimum_excess=min((x['excess_occupancy']for x in v),default=None),snapshots=r['snapshots'],zero_hits=[t.get('last_zero')for t in r['trials'][:2]])))
