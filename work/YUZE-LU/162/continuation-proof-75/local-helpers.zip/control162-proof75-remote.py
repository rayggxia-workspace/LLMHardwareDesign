from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-75';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set();indexed={}
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(root):
 root=Path(root);assert root.is_dir(),root
 for p in root.glob('*'):
  if p.is_file()and p.suffix in('.json','.txt','.log','.patch','.py')and p.stat().st_size<3000000:add(p)
for name in ['r256-final-chain-binding-audit-1171','r256-product-history-active-audit-1173','r256-product-history-slot-admission-1168','r256-coarse-neighbors-regression-1185','r256-coarse-neighbors-source-audit-1186','r256-coarse-neighbors-slot-admission-1187','r256-final-chain-binding-audit-1193','r256-coarse-neighbors-active-audit-1195']:
 assert(b/name/'receipt.json').is_file(),name;shallow(b/name)
root=b/'r256-coarse-neighbors-regression-1185/coarse-neighbors';shallow(root);shallow(root/'candidate-checks')
for p in root.glob('full-*'):shallow(p)
shallow(root/'coarse-neighbors-failure')
for label in ['sready1172-product-history-refill','sready1188-coarse-neighbors-reg-refill','sready1194-coarse-neighbors-node7']:shallow(b/'route-selection-102'/label)
for label in ['sready1170-native-warm-fullchains','sready1185-coarse-neighbors-controls','sready1192-native-warm-fullchains']:
 p=b/'route-selection-102'/label/'tasks.json';assert p.is_file();add(p)
 for r in json.loads(p.read_text())['tasks']:add(r['path'])
for n in [1154,1184]:
 for name in ['source-manifest.json','freeze-import.json']:add(b/('source-'+str(n))/name)
for name in ['config1185.json','backout1186.patch','audit1186.py','audit1186-final.py']:add(b/name)
out.mkdir();live=out/'live-route-snapshots';live.mkdir();progress=[]
for seed in [11200,11201,11202,11203,11204,11205,11400,11401,11600,11601,11700,11701,11920,11921]:
 route=b/'r256-composition-453/upper-candidates'/str(seed)/'route';p=route/'trial-0/router.log';assert p.is_file();target=live/(str(seed)+'-trial0.log');target.write_bytes(p.read_bytes());add(target);records=[]
 for line in target.read_text().splitlines():
  if line.startswith('{'):
   try:records.append(json.loads(line))
   except ValueError:pass
 for name in ['router-input.txt','router-distance-oracle.json','trial-0/input.txt','trial-0/output.txt.native-prefix.log']:add(route/name)
 snap=route/'trial-0/output.txt.global-round-8.txt'
 if snap.is_file()and any(r.get('global_snapshot_round')==8 for r in records):indexed[str(snap)]=dict(bytes=snap.stat().st_size,sha256=sha(snap),copied=False,scope='Intermediate complete trees,not final route')
 progress.append(dict(candidate=seed,time=time.time(),original_log=str(p),immutable_prefix=str(target),last_complete_global=next((r for r in reversed(records)if'conflict_nodes'in r),None),last_zero=next((r for r in reversed(records)if'coarse_zero_hits'in r),None),last_neighbor=next((r for r in reversed(records)if'coarse_neighbor_tracks'in r),None),last_batch=next((r for r in reversed(records)if'global_batch_native_trees'in r),None),whole_system_qualified=False))
 if seed in [11700,11701]:
  for trial in sorted(route.glob('trial-*')):
   log=trial/'router.log'
   if not log.is_file():continue
   with log.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-1000));tail=f.read().decode(errors='replace')
   if tail.endswith('finite-resource search label memory envelope exhausted\n'):
    target=live/(str(seed)+'-'+trial.name+'-failed.log');target.write_bytes(log.read_bytes());add(target);assert not(trial/'output.txt').exists()
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
for p in selected:
 indexed[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))
 if p.suffix=='.json':
  try:d=json.loads(p.read_text())
  except ValueError:continue
  if isinstance(d,dict):
   for source,expected in d.get('inputs',{}).items():
    q=Path(source)
    if q.is_file()and str(q).startswith(str(b)+'/'):
     actual=sha(q);assert actual==expected,(q,actual,expected)
     if source not in indexed:indexed[source]=dict(bytes=q.stat().st_size,sha256=actual,copied=False)
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
p=out/'selected-originals.zip';index=dict(time=time.time(),whole_system_qualified=False,files=indexed,copied_files=len(selected),indexed_files=len(indexed),archive=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)),scope='Actual1185/1186regression/sourceaudit/1195actual32processaudit/1173historyaudit/14specbindings/exactownguards;immutable diagnostic log prefixes and failed resource-envelope attempts retained. Intermediate paths only indexed,full composition not accepted.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(indexed=len(indexed),copied=len(selected),zip_bytes=p.stat().st_size,zip_sha256=sha(p))))
