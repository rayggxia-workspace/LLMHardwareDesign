from pathlib import Path
import subprocess,shlex
q="""import hashlib
from pathlib import Path
import json
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1184');m=json.loads((r/'source-manifest.json').read_text());assert m['commit']=='4c05fcb63046ff7c6a33e77564fba668a641a811'and len(m['files'])==1019;assert json.loads((r/'freeze-import.json').read_text())['archive_sha256']=='68ce9a135b6bfcf1b878795106c7278d8217b4ee4b4893f665a6720794a340b6';assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');cfg=b/'config1185.json';assert not cfg.exists();cfg.write_text(json.dumps(dict(previous_batch=str(b/'r256-global-batch-regression-1155'),batch_config=str(b/'config1155.json'))))
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1184';assert(source/'freeze-import.json').is_file()and(source/'source-manifest.json').is_file();out=b/'r256-coarse-neighbors-regression-1185';record=b/'route-selection-102/sready1185-coarse-neighbors-controls';assert not record.exists();record.mkdir();name='00-zb-sready1185-coarse-neighbors-regression';p=b/'dynamic-03/node5/pending'/(name+'.json');assert not p.exists()and not out.exists()
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=16,requires=[str(b/'r256-global-batch-regression-1155/receipt.json'),str(b/'r256-global-batch-source-audit-1156/receipt.json'),str(b/'r256-product-history-active-audit-1173/receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--coarse-neighbors-regression-config',str(b/'config1185.json'),'--out',str(out)])
tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),spec=spec)],whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=True,path=str(p),source=str(source))))
"""
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],universal_newlines=True))
