from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');queue=b/'dynamic-07/node7';state=json.loads((queue/'queue-state.json').read_text());rows=[]
for name in state['active']:
 if '3751'not in name:continue
 p=queue/'pending'/(name+'.json');spec=json.loads(p.read_text());a=spec['args'];out=Path(a[a.index('--out')+1]);logs=[]
 for f in [queue/(name+'.log'),out/'router.log',out/'cugr.log',out/'receipt.json']:
  if f.is_file():
   with f.open('rb')as h:h.seek(0,2);n=h.tell();h.seek(max(0,n-4000));tail=h.read().decode(errors='replace')
   logs.append(dict(path=str(f),bytes=n,mtime=f.stat().st_mtime,tail=tail))
 rows.append(dict(name=name,spec=spec,logs=logs,output_entries=[p.name for p in out.iterdir()]if out.is_dir()else[]))
print(json.dumps(dict(time=time.time(),rows=rows)))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);(Path(__file__).parent/'control162-read1174.json').write_bytes(raw);print(raw.decode())
