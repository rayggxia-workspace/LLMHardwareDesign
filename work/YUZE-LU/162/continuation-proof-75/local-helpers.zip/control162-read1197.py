from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for folder in ['dynamic-03/node5','dynamic-07/node7']:
 queue=b/folder;state=json.loads((queue/'queue-state.json').read_text());r=dict(folder=folder,active=state['active'],selected={k:v for k,v in state['finished'].items()if any(s in k for s in ['sready1185','sready1192'])},files=[])
 for p in queue.glob('*sready1192*'):
  if p.is_file():
   with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-2000));tail=f.read().decode(errors='replace')
   r['files'].append(dict(path=str(p),bytes=size,tail=tail))
 for p in(queue/'commands').glob('*sready1192*'):
  d=json.loads(p.read_text());r.setdefault('admissions',[]).append(dict(path=str(p),admission=d.get('admission')))
 rows.append(r)
print(json.dumps(dict(time=time.time(),rows=rows)))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);(Path(__file__).parent/'control162-read1197.json').write_bytes(raw);print(raw.decode())
