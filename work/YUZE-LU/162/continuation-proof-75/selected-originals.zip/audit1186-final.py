from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1154';new=b/'source-1184';reg=b/'r256-coarse-neighbors-regression-1185';out=b/'r256-coarse-neighbors-source-audit-1186';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=json.loads((reg/'receipt.json').read_text());assert root['passed']and root['stage']=='ordinary-coarse-neighbors-focused-regression-only';child=reg/'coarse-neighbors/receipt.json';assert root['inputs'][str(child)]==sha(child);r=json.loads(child.read_text());assert r['passed']and not r['whole_system_qualified']and not r['route_qualified']and len(r['full_route_positives'])==2 and len(r['rejected'])==2 and r['coarse_neighbors_global_failure_rejected']
for p,v in r['inputs'].items():assert sha(p)==v
for x in r['full_route_positives']:assert x['proof']['final_conflicts']==0 and x['proof']['coarse_neighbors_trace']and sum(t['coarse_neighbor_attempts']for t in x['proof']['coarse_neighbors_trace'])>0 and x['independent_final']['all_trees_flood_verified']and x['independent_final']['all_wire_budgets_verified']and x['independent_final']['conflict_nodes']==0
assert len(r['candidate_checks'])==144 and sum(x['weight']==1 for x in r['candidate_checks'])==96 and all(x['expanded']<=x['states']for x in r['candidate_checks'])
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','ordinary_coarse_grid.h','coarse_neighbors_regression.py']};assert set(a['files'])<=set(z['files'])and len(z['files'])==1019
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='68ce9a135b6bfcf1b878795106c7278d8217b4ee4b4893f665a6720794a340b6'
for p,v in z['files'].items():assert sha(new/p)==v
out.mkdir();scratch=out/'reverse-copies';scratch.mkdir();files=['tree_router.cpp','tree_router_cpp.py','system_upper.py','ordinary_coarse_grid.h'];rows=[]
for name in files:
 rel=Path('project/experiments/control_v1')/name;target=scratch/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((new/rel).read_bytes())
patch=b/'backout1186.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in files:
 rel=Path('project/experiments/control_v1')/name;assert(scratch/rel).read_bytes()==(old/rel).read_bytes();rows.append(dict(name=name,current_sha256=sha(new/rel),previous_sha256=sha(old/rel),reconstructed_sha256=sha(scratch/rel),only_scratch_copies_modified=True,exact=True))
invariants=[x for x in json.loads((b/'r256-global-batch-source-audit-1156/receipt.json').read_text())['invariants']if x['name']!='ordinary_coarse_grid.h']+[dict(name='global_batch_regression.py',sha256=sha(new/'project/experiments/control_v1/global_batch_regression.py'))]
assert len(invariants)==29
for x in invariants:assert sha(new/'project/experiments/control_v1'/x['name'])==sha(old/'project/experiments/control_v1'/x['name'])==x['sha256']
left=(old/'project/experiments/control_v1/tree_router.cpp').read_text();right=(new/'project/experiments/control_v1/tree_router.cpp').read_text();start='    if(pareto_wire_budget&&n<locked_count&&wire_limits[n]>=0){';end='    }else if(bidirectional_two_terminal';assert left[left.index(start):left.index(end,left.index(start))]==right[right.index(start):right.index(end,right.index(start))]

artifacts=[]
for seed in [971,972]:
 for p in(reg/'coarse-neighbors'/('full-'+str(seed))).iterdir():
  if p.is_file()and p.name!='router':artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1019,unchanged_manifest_files=1014,changed_files=sorted(changed),backouts=rows,invariants=invariants,native_finite_branch_bytes_exact=True,candidate_graph_checks=144,full_route_positive=2,rejected=2,old_batch_two_routes_main_native_snapshot_bytes_exact=True,actual_artifacts=artifacts,inputs={str(patch):sha(patch),str(child):sha(child),str(reg/'receipt.json'):sha(reg/'receipt.json'),str(new/'source-manifest.json'):sha(new/'source-manifest.json')},scope='Actual1185twofullsynthetic routes and144independent candidategraph comparisons(96exact48weighted),unitphysicaledges andgraphsupersetchecks. Previousbatch2paths/main/native/snapshotbyteexactandallnestedactualoldreplays. Fourproductionfilesexactlybackoutto1154inownedscratch;nativefinitebranchbytesand29native/resource/finalgate/helperfilesunchanged. Onlydefaultoffordinarycandidategraphaddsadjacentunitcoordinates;physical2345grid/pitch/M1-M10/nativefinitebudgets/geometryPG3RC300MHzgates unchanged. No systempassinferred.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1019,unchanged=1014,backouts=4,invariants=len(invariants),candidate_checks=144,positives=2,rejected=2)))
