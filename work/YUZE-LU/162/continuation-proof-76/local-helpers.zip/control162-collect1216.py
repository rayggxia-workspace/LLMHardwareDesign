from pathlib import Path
import subprocess,shlex,json,hashlib
h=Path(__file__).parent;out=h/'control162-profile1216';out.mkdir(exist_ok=True)
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-fullgrid-hotspot-profile-1216'
q="""from pathlib import Path
import json,hashlib,time
b=Path(REMOTE);r=json.loads((b/'receipt.json').read_text());assert r['record_returncode']==r['report_returncode']==0 and r['phase_before']['round']>=64
files={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in b.iterdir()if p.is_file()}
assert all(x['bytes']<30000000 for x in files.values());print(json.dumps(dict(time=time.time(),files=files,whole_system_qualified=False)))
""".replace('REMOTE',repr(remote))
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);(out/'index.json').write_bytes(raw);index=json.loads(raw)
selected=['report.stdout','record.stderr','receipt.json','before-log-tail.bin','report.stderr','launcher.stdout','launcher.stderr']
subprocess.run(['scp']+['yuzelu@10.129.166.172:'+remote+'/'+n for n in selected]+[str(out)],check=True,timeout=50)
for n in selected:assert hashlib.sha256((out/n).read_bytes()).hexdigest()==index['files'][remote+'/'+n]['sha256']
print(json.dumps(dict(local_raw_files=len(selected),all_sha_verified=True,perf_data_on_server=index['files'][remote+'/perf.data'])))
