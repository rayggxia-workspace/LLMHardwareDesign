from pathlib import Path
root=Path(__file__).parent/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'
def edit(name,items):
 p=root/name;s=p.read_text(encoding='utf-8')
 for old,new in items:
  assert s.count(old)==1,(name,old,s.count(old));s=s.replace(old,new)
 p.write_bytes(s.encode())
edit('tree_router.cpp',[
 ('argc>28','argc>29'),
 ('bool ordinary_coarse_neighbors=false;', 'int ordinary_coarse_rounds=64;bool coarse_rounds_option=false;bool ordinary_coarse_neighbors=false;'),
 ('if(option=="--ordinary-coarse-neighbors")', 'if(option.rfind("--ordinary-coarse-rounds=",0)==0){if(coarse_rounds_option)throw runtime_error("duplicate coarse round option");coarse_rounds_option=true;string value=option.substr(25);if(value!="8"&&value!="16"&&value!="32"&&value!="64")throw runtime_error("invalid coarse round limit");ordinary_coarse_rounds=stoi(value);}\n  else if(option=="--ordinary-coarse-neighbors")'),
 ('if(ordinary_coarse_neighbors&&!ordinary_coarse_zero)', 'if(coarse_rounds_option&&!ordinary_coarse)throw runtime_error("coarse round limit requires coarse candidate mode");\n if(ordinary_coarse_neighbors&&!ordinary_coarse_zero)'),
 ('if(path.empty()&&ordinary_coarse&&iteration<64&&', 'if(path.empty()&&ordinary_coarse&&iteration<ordinary_coarse_rounds&&'),
 ('  if(ordinary_coarse_neighbors)cout', '  if(coarse_rounds_option)cout<<"{\\\"round\\\":"<<iteration<<",\\\"coarse_round_limit\\\":"<<ordinary_coarse_rounds<<",\\\"coarse_phase_active\\\":"<<(iteration<ordinary_coarse_rounds?"true":"false")<<",\\\"coarse_attempts\\\":"<<coarse_attempts<<"}"<<endl;\n  if(ordinary_coarse_neighbors)cout')])
assert len('--ordinary-coarse-rounds=')==25
edit('tree_router_cpp.py',[
 ('ordinary_coarse_neighbors=False):','ordinary_coarse_neighbors=False,ordinary_coarse_rounds=64):'),
 ('    assert not ordinary_coarse_neighbors or ordinary_coarse_zero','    assert ordinary_coarse_rounds in (8,16,32,64)\n    assert ordinary_coarse_rounds==64 or ordinary_coarse_grid_stride\n    if ordinary_coarse_rounds!=64:extra_cli.append("--ordinary-coarse-rounds="+str(ordinary_coarse_rounds))\n    assert not ordinary_coarse_neighbors or ordinary_coarse_zero'),
 ('        ordinary_coarse_neighbors=ordinary_coarse_neighbors,','        ordinary_coarse_rounds=ordinary_coarse_rounds,coarse_round_limit_trace=[r for r in trace if "coarse_round_limit"in r],\n        ordinary_coarse_neighbors=ordinary_coarse_neighbors,')])
edit('system_upper.py',[
 ("    p.add_argument('--route-ordinary-coarse-neighbors',", "    p.add_argument('--route-ordinary-coarse-rounds',type=int,choices=[8,16,32,64],default=64,help='Candidate search schedule only: switch ordinary coarse candidates to original dense routing at this round; native solver and all final gates unchanged')\n    p.add_argument('--route-ordinary-coarse-neighbors',"),
 ("    p.add_argument('--coarse-neighbors-regression-config',type=Path)","    p.add_argument('--coarse-neighbors-regression-config',type=Path)\n    p.add_argument('--coarse-rounds-regression-config',type=Path)"),
 ('    assert not a.route_ordinary_coarse_multicast or', '    assert a.route_ordinary_coarse_rounds==64 or a.route_ordinary_coarse\n    assert not a.route_ordinary_coarse_multicast or'),
 ('        if a.coarse_neighbors_regression_config:', '''        if a.coarse_rounds_regression_config:
            from coarse_rounds_regression import run
            config=a.coarse_rounds_regression_config;helper=Path(__file__).with_name('coarse_rounds_regression.py')
            receipt['inputs'].update({str(config):sha(config),str(helper):sha(helper)})
            child=a.out/'coarse-rounds';result=run(config,child)
            assert result['passed'];receipt['outputs']['coarse-rounds/receipt.json']=sha(child/'receipt.json')
            receipt.update(passed=True,stage='ordinary-coarse-rounds-focused-regression-only',whole_system_qualified=False)
            return
        if a.coarse_neighbors_regression_config:'''),
 ('ordinary_coarse_neighbors=a.route_ordinary_coarse_neighbors)', 'ordinary_coarse_neighbors=a.route_ordinary_coarse_neighbors,ordinary_coarse_rounds=a.route_ordinary_coarse_rounds)')])
for name in ['tree_router_cpp.py','system_upper.py']:compile((root/name).read_text(encoding='utf-8'),name,'exec')
print('Implemented default64 optional8/16/32 transition; only ordinary candidate schedule changes')
