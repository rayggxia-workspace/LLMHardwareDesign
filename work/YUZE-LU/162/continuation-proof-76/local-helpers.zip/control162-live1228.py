from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import subprocess,json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
targets=[(95341,'dynamic-05/node2',4),(95098,'dynamic-02/node3',4),(95391,'dynamic-05/node4',4),(95155,'dynamic-03/node5',4),(97097,'dynamic-08/node6',4),(96297,'dynamic-07/node7',4),(95204,'dynamic-04/node25',6),(96222,'dynamic-06/node26',6)]
jobs=subprocess.check_output(['squeue','-h','-j',','.join(str(x[0])for x in targets),'-o','%i|%T|%N|%C|%j|%u'],universal_newlines=True)
assert len(jobs.splitlines())==8 and all('|RUNNING|'in l and l.endswith('|yuzelu')for l in jobs.splitlines())
for job,folder,limit in targets:
 queue=b/folder;d=json.loads((queue/'queue-state.json').read_text());active=[]
 for n in d['active']:
  p=queue/'pending'/(n+'.json');raw=p.read_bytes();s=json.loads(raw);a=s['args'];output=a[a.index('--out')+1]if '--out'in a else None
  active.append(dict(name=n,spec_sha256=hashlib.sha256(raw).hexdigest(),source=s['source_root'],forecast_gib=s['forecast_gib'],output=output))
 rows.append(dict(job=job,queue=str(queue),controller_active_count=len(active),nominal_independent16cpu_slots=limit,forecast_gib=sum(x['forecast_gib']for x in active),active=active))
assert sum(x['controller_active_count']for x in rows)==36 and all(x['controller_active_count']==x['nominal_independent16cpu_slots']for x in rows)
reg=b/'r256-coarse-rounds-regression-1219';subdirs=[dict(path=str(p.parent.relative_to(reg)),mtime=p.stat().st_mtime)for p in reg.rglob('router')if p.is_file()];subdirs.sort(key=lambda x:x['mtime']);r=dict(time=time.time(),whole_system_qualified=False,slurm=jobs,parents=rows,regression1219_completed_compile_directories=subdirs,scope='Read-only eight exact owned parents and controller active specifications;36 independent16CPU slots populated,c96sixslots. Controller state is not process-affinity or physical qualification proof; later actual process checks remain independent.')
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-live1228';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
r=json.loads(raw);print(json.dumps(dict(time=r['time'],parents=len(r['parents']),controller_active=sum(x['controller_active_count']for x in r['parents']),node_slots=[x['controller_active_count']for x in r['parents']],regression_compiled_directories=r['regression1219_completed_compile_directories'][-8:])))
