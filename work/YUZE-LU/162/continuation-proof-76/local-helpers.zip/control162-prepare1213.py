from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1195.py').read_text(encoding='utf-8')
s=s.replace('r256-coarse-neighbors-active-audit-1195','r256-neighbor-parameters-active-audit-1213').replace('11920','12100').replace('11921','12101')
s=s.replace('{12100:8,12101:32}','{12100:2,12101:8}').replace('{12100:16,12101:16}','{12100:16,12101:8}')
s=s.replace("[(95155,5,'dynamic-03/node5',[12100],[10430,11400,11600,12100]),(96297,7,'dynamic-07/node7',[12101],[11401,11601,12101])]","[(95098,3,'dynamic-02/node3',[12100],[6561,10711,11201,12100]),(97097,6,'dynamic-08/node6',[12101],[10710,10900,11200,12101])]")
a=s.index("scope='");z=s.index("')\nexcept",a)
s=s[:a]+"scope='Actual32owned source1184neighborparameterchildren12100/12101;32actualinputbodies/importedprefixesmatch9060trial0,additivehistoryandcost2/8,stride16/8,globalbatchOFF. Eachactualchildexecutedneighborcandidateattempts;actualzero/multicast/static/access/neighborflagsandfirsttrialonlysnapshotCLIverified. Actualnode3andnode6four16CPUmasksdisjoint;actualcontrolleradmissionchecked.8parents36x16dynamicwithc96sixmasksunchanged. Nativefinitebudget/realphysicalgrid/M1-M10/finalgeometryPG3RC300MHzgates unchanged. No finalrouteorphysical/systempassinferred'"+s[z+1:]
compile(s,'audit1213','exec');(h/'control162-audit1213.py').write_bytes(s.encode())
s=(h/'control162-progress1196.py').read_text(encoding='utf-8').replace('11920','12100').replace('11921','12101').replace('progress1196','progress1214')
compile(s,'progress1214','exec');(h/'control162-progress1214.py').write_bytes(s.encode())
print('Prepared actual parameter audit1213/progress1214')
