from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-compare1167.py').read_text(encoding='utf-8').replace('[(11400,11600),(11401,11601)]','[(11400,11920),(11401,11921)]').replace('compare1167','compare1215').replace("['retained_dirty','batch_dirty']","['without_neighbors','with_neighbors']")
s=s.replace('for k in range(8):','for k in range(16):')
compile(s,'compare1215','exec');(h/'control162-compare1215.py').write_bytes(s.encode())
