from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-profile1200-remote.py').read_text(encoding='utf-8').replace('r256-coarse-neighbor-hotspot-profile-1200','r256-fullgrid-hotspot-profile-1216').replace("job='95155'","job='96222'").replace('NodeList=node5 ','NodeList=node24 ').replace('upper-candidates/11920','upper-candidates/11205').replace('source-1184/source-manifest.json','source-1104/source-manifest.json').replace('compute node5 within own95155','compute node24 within own96222')
needle="if perf:\n args="
addition="""log=Path(binary).parent/'trial-0/router.log'
with log.open('rb')as f:
 f.seek(0,2);size=f.tell();f.seek(max(0,size-1000000));raw=f.read()
records=[json.loads(line)for line in raw.decode().splitlines()if line.startswith('{')]
progress=next(x for x in reversed(records)if 'routed'in x)
assert progress['round']>=64
(out/'before-log-tail.bin').write_bytes(raw);r['phase_before']=progress;r['log_before']=dict(path=str(log),bytes_at_read=size,tail_bytes=len(raw),tail_sha256=hashlib.sha256(raw).hexdigest())
if perf:
 args="""
assert s.count(needle)==1;s=s.replace(needle,addition)
compile(s,'profile1216','exec');(h/'control162-profile1216-remote.py').write_bytes(s.encode())
