from pathlib import Path
import subprocess
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control'
files=['tree_router.cpp','tree_router_cpp.py','system_upper.py']
patch=subprocess.check_output(['git','diff','4c05fcb63046ff7c6a33e77564fba668a641a811','16169058c4edc5e09b859c0a1a4e85f8baa0160e','--']+['project/experiments/control_v1/'+n for n in files],cwd=repo)
(h/'control162-backout1221.patch').write_bytes(patch)
s=r'''from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1184';new=b/'source-1218';reg=b/'r256-coarse-rounds-regression-1219';out=b/'r256-coarse-rounds-source-audit-1221';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=json.loads((reg/'receipt.json').read_text());assert root['passed']and root['stage']=='ordinary-coarse-rounds-focused-regression-only';child=reg/'coarse-rounds/receipt.json';assert root['inputs'][str(child)]==sha(child);r=json.loads(child.read_text());assert r['passed']and not r['whole_system_qualified']and len(r['full_route_positives'])==2 and len(r['rejected'])==4 and r['one_round_global_failure_rejected']
for p,v in r['inputs'].items():assert sha(p)==v
assert {x['cutoff']for x in r['full_route_positives']}=={8,16}
for x in r['full_route_positives']:
 assert x['proof']['final_conflicts']==0 and x['independent_final']['all_trees_flood_verified']and x['independent_final']['all_wire_budgets_verified']and x['independent_final']['conflict_nodes']==0
 trace=x['proof']['coarse_round_limit_trace'];assert any(not t['coarse_phase_active']for t in trace)and all(t['coarse_attempts']==0 for t in trace if not t['coarse_phase_active'])
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={'project/experiments/control_v1/'+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','coarse_rounds_regression.py']};assert set(a['files'])<=set(z['files'])and len(z['files'])==1020
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='b4a62c42851c22837ccdb72fdc81a5874b349839b1dc3a428ff8930d860859a3'
for p,v in z['files'].items():assert sha(new/p)==v
out.mkdir();scratch=out/'reverse-copies';scratch.mkdir();files=['tree_router.cpp','tree_router_cpp.py','system_upper.py'];rows=[]
for name in files:
 rel=Path('project/experiments/control_v1')/name;target=scratch/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((new/rel).read_bytes())
patch=b/'control162-backout1221.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in files:
 rel=Path('project/experiments/control_v1')/name;assert(scratch/rel).read_bytes()==(old/rel).read_bytes();rows.append(dict(name=name,current_sha256=sha(new/rel),previous_sha256=sha(old/rel),reconstructed_sha256=sha(scratch/rel),only_scratch_copies_modified=True,exact=True))
invariants=json.loads((b/'r256-coarse-neighbors-source-audit-1186/receipt.json').read_text())['invariants']+[dict(name=n,sha256=sha(new/'project/experiments/control_v1'/n))for n in ['ordinary_coarse_grid.h','coarse_neighbors_regression.py']]
assert len(invariants)==31 and len({x['name']for x in invariants})==31
for x in invariants:assert sha(new/'project/experiments/control_v1'/x['name'])==sha(old/'project/experiments/control_v1'/x['name'])==x['sha256']
left=(old/'project/experiments/control_v1/tree_router.cpp').read_text();right=(new/'project/experiments/control_v1/tree_router.cpp').read_text();start='    if(pareto_wire_budget&&n<locked_count&&wire_limits[n]>=0){';end='    }else if(bidirectional_two_terminal';assert left[left.index(start):left.index(end,left.index(start))]==right[right.index(start):right.index(end,right.index(start))]
assert left.split('struct BidirectionalSearch {',1)[1].split('#include "weighted_bidirectional.h"',1)[0]==right.split('struct BidirectionalSearch {',1)[1].split('#include "weighted_bidirectional.h"',1)[0]
assert 'int search_weight=1+((heuristic_weight-1)>>min(iteration/4,8));'in right
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1020,unchanged_manifest_files=1016,changed_files=sorted(changed),backouts=rows,invariants=invariants,native_finite_branch_bytes_exact=True,exact_bidirectional_class_bytes_exact=True,full_route_positive=2,rejected=4,old_neighbors_two_routes_main_native_snapshot_bytes_exact=True,inputs={str(patch):sha(patch),str(child):sha(child),str(reg/'receipt.json'):sha(reg/'receipt.json'),str(new/'source-manifest.json'):sha(new/'source-manifest.json')},scope='Actual1219two complete early8/16dense transition synthetic routes independently checked. Default64 fullneighbors2paths/main/native/snapshotbyteexact and allnestedactualoldreplays. Threeproductionfiles exactlybackoutto1184inownscratch;finitebranch/exactbalancedclass and31native/resource/finalgate/helper files unchanged. Original heuristic annealing and all geometryPG3RC300MHz gates unchanged. Onlyordinarycandidatecutoff schedule changes;no systempass inferred.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1020,unchanged=1016,backouts=3,invariants=len(invariants),positives=2,rejected=4)))
'''
compile(s,'audit1221','exec');(h/'control162-audit1221-remote.py').write_bytes(s.encode())
print('Prepared 3productionfilebackout and31invariant audit1221')
