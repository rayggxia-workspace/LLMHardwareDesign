from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-read1190.py').read_text(encoding='utf-8').replace('r256-coarse-neighbors-regression-1185','r256-coarse-rounds-regression-1219').replace('sready1185','sready1219').replace('00-zb-sready1219-coarse-neighbors-regression','00-zc-sready1219-coarse-rounds-regression').replace('read1190','read1227')
compile(s,'read1227','exec');(h/'control162-read1227.py').write_bytes(s.encode())
