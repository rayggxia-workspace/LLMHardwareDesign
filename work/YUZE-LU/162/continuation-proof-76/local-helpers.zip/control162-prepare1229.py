from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1195.py').read_text(encoding='utf-8').replace('r256-coarse-neighbors-active-audit-1195','r256-early-dense-active-audit-1229').replace('11920','12220').replace('11921','12221')
s=s.replace('{12220:8,12221:32}','{12220:8,12221:8}')
s=s.replace("[10430,11400,11600,12220]","[10430,11400,11920,12220]").replace('[11401,11601,12221]','[11401,11921,12221]')
s=s.replace("neighbor=[json.loads(line)for line in(p.parent/'router.log').read_text().splitlines()if line.startswith('{')and 'coarse_neighbor_tracks'in line];assert neighbor and sum(t['coarse_neighbor_attempts']for t in neighbor)>0;","schedule=[json.loads(line)for line in(p.parent/'router.log').read_text().splitlines()if line.startswith('{')and 'coarse_round_limit'in line];assert schedule and all(t['coarse_round_limit']=={12220:8,12221:16}[seed]and t['coarse_phase_active']==(t['round']<{12220:8,12221:16}[seed])for t in schedule);assert all(t['coarse_attempts']==0 for t in schedule if not t['coarse_phase_active']);")
s=s.replace("'--ordinary-coarse-neighbors'in cmd","'--ordinary-coarse-neighbors'not in cmd;assert '--ordinary-coarse-rounds='+str({12220:8,12221:16}[seed])in cmd")
a=s.index("scope='");z=s.index("')\nexcept",a);s=s[:a]+"scope='Actual32owned source1218earlydensechildren12220/12221;32actualinputbodies/importedprefixesmatch9060trial0,additivehistory/cost8/stride16/globalbatchOFF/neighborsOFF. Actualcoarseschedule8/16 traces andzero/multicast/static/access flags/onlyfirsttrialsnapshotCLIverified. Actualnode5four16CPU masksdisjoint,node7threeobservedrouter16CPUmasksdisjoint(CUGR3751notclaimed);actualcontrolleradmissionchecked. Thisactive audit doesnot require orclaim all32alreadycrossedthetransition.8parents36x16dynamic/c96sixmasks unchanged. Allphysical/nativefinite/M1-M10/finalgeometryPG3RC300MHzgates unchanged;no final/systempassinferred'"+s[z+1:]
assert 'coarse_neighbor_attempts'not in s
compile(s,'audit1229','exec');(h/'control162-audit1229.py').write_bytes(s.encode())
s=(h/'control162-progress1196.py').read_text(encoding='utf-8').replace('11920','12220').replace('11921','12221').replace('progress1196','progress1230')
compile(s,'progress1230','exec');(h/'control162-progress1230.py').write_bytes(s.encode())
print('Prepared actual active1229 /progress1230;notexecuted')
