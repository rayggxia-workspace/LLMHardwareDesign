from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-76';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set();indexed={}
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(root):
 root=Path(root);assert root.is_dir(),root
 for p in root.glob('*'):
  if p.is_file()and p.name!='router'and p.stat().st_size<4000000:add(p)
for name in ['r256-neighbor-parameter-slot-admission-1206','r256-final-chain-binding-audit-1211','r256-neighbor-parameters-active-audit-1213','r256-coarse-rounds-regression-1219','r256-coarse-rounds-slot-admission-1220','r256-coarse-rounds-source-audit-1221','r256-final-chain-binding-audit-1223','r256-early-dense-active-audit-1229']:
 assert json.loads((b/name/'receipt.json').read_text()).get('passed',True),name;shallow(b/name)
root=b/'r256-coarse-rounds-regression-1219/coarse-rounds';shallow(root)
for pattern in ['cutoff-*','one-round-failure']:
 for p in root.glob(pattern):shallow(p)
for p in(root/'unchanged-neighbors').glob('full-*'):shallow(p)
for label in ['sready1212-neighbor-parameters-refill','sready1226-coarse-rounds-reg-refill','sready1224-early-dense-refill']:shallow(b/'route-selection-102'/label)
for label in ['sready1210-native-warm-fullchains','sready1219-coarse-rounds-controls','sready1222-native-warm-fullchains']:
 p=b/'route-selection-102'/label/'tasks.json';assert p.is_file();add(p)
 for r in json.loads(p.read_text())['tasks']:add(r['path'])
for n in [1184,1218]:
 for name in ['source-manifest.json','freeze-import.json']:add(b/('source-'+str(n))/name)
for name in ['config1219.json','control162-backout1221.patch','control162-audit1221-remote.py','control162-profile1216-remote.py']:add(b/name)
profile=b/'r256-fullgrid-hotspot-profile-1216';shallow(profile)
selected.discard(profile/'perf.data');p=profile/'perf.data';indexed[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=False,scope='Completed five-second owner-only CPU-clock profile;not hardware evidence')
out.mkdir();live=out/'live-route-snapshots';live.mkdir();progress=[]
for seed in [11200,11201,11202,11203,11204,11205,11400,11401,11920,11921,12100,12101,12220,12221]:
 route=b/'r256-composition-453/upper-candidates'/str(seed)/'route';p=route/'trial-0/router.log';assert p.is_file();raw=p.read_bytes();target=live/(str(seed)+'-trial0.log');target.write_bytes(raw);add(target);records=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:records.append(json.loads(line))
   except ValueError:pass
 for name in ['router-distance-oracle.json','trial-0/output.txt.native-prefix.log']:add(route/name)
 snap=route/'trial-0/output.txt.global-round-8.txt'
 if snap.is_file()and any(r.get('global_snapshot_round')==8 for r in records):indexed[str(snap)]=dict(bytes=snap.stat().st_size,sha256=sha(snap),copied=False,scope='Intermediate complete trees,not final route')
 progress.append(dict(candidate=seed,time=time.time(),original_log=str(p),immutable_prefix=str(target),last_complete_global=next((r for r in reversed(records)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(records)if'routed'in r),None),last_schedule=next((r for r in reversed(records)if'coarse_round_limit'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
for p in selected:
 indexed[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))
 if p.suffix=='.json':
  try:d=json.loads(p.read_text())
  except ValueError:continue
  if isinstance(d,dict):
   for source,expected in d.get('inputs',{}).items():
    q=Path(source)
    if q.is_file()and str(q).startswith(str(b)+'/'):
     actual=sha(q);assert actual==expected,(q,actual,expected)
     if source not in indexed:indexed[source]=dict(bytes=q.stat().st_size,sha256=actual,copied=False)
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
p=out/'selected-originals.zip';index=dict(time=time.time(),whole_system_qualified=False,files=indexed,copied_files=len(selected),indexed_files=len(indexed),archive=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)),scope='Actual1219early8/16dense regression/default64byte replays/1221source audit/1213and1229live32process audits/1211and1223strict14specbindings/exactownslotguards. Immutable diagnostic log prefixes only;full composition has not passed. Large actual snapshots/perf.data left authorized server with SHA binding.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(indexed=len(indexed),copied=len(selected),zip_bytes=p.stat().st_size,zip_sha256=sha(p))))
