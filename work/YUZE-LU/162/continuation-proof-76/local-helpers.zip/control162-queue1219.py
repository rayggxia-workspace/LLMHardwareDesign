from pathlib import Path
import subprocess,shlex
q="""import hashlib
from pathlib import Path
import json
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1218');m=json.loads((r/'source-manifest.json').read_text());assert m['commit']=='16169058c4edc5e09b859c0a1a4e85f8baa0160e'and len(m['files'])==1020;assert json.loads((r/'freeze-import.json').read_text())['archive_sha256']=='b4a62c42851c22837ccdb72fdc81a5874b349839b1dc3a428ff8930d860859a3';assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in m['files'].items())
from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');cfg=b/'config1219.json';assert not cfg.exists();cfg.write_text(json.dumps(dict(previous_neighbors=str(b/'r256-coarse-neighbors-regression-1185'),neighbors_config=str(b/'config1185.json'))))
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1218';assert(source/'freeze-import.json').is_file()and(source/'source-manifest.json').is_file();out=b/'r256-coarse-rounds-regression-1219';record=b/'route-selection-102/sready1219-coarse-rounds-controls';assert not record.exists();record.mkdir();name='00-zc-sready1219-coarse-rounds-regression';p=b/'dynamic-03/node5/pending'/(name+'.json');assert not p.exists()and not out.exists()
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=16,requires=[str(b/'r256-coarse-neighbors-regression-1185/receipt.json'),str(b/'r256-coarse-neighbors-source-audit-1186/receipt.json'),str(b/'r256-coarse-neighbors-active-audit-1195/receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--coarse-rounds-regression-config',str(b/'config1219.json'),'--out',str(out)])
tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),spec=spec)],whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=True,path=str(p),source=str(source))))
"""
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],universal_newlines=True))
