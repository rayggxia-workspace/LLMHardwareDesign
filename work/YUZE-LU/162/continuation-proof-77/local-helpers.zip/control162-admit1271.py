from pathlib import Path
import subprocess,shlex
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');queue=b/'dynamic-05/node2';state=json.loads((queue/'queue-state.json').read_text());rows=[];fs=[]
for name in state['active']:
 p=queue/'pending'/(name+'.json');raw=p.read_bytes();s=json.loads(raw);fs.append([name,s['forecast_gib']]);a=s['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='6560':rows.append(dict(job=95341,node=2,folder='dynamic-05/node2',target=6560,path=str(p),sha256=hashlib.sha256(raw).hexdigest(),spec=s))
out=b/'r256-internal-trace-slot-admission-1271';assert not out.exists()and len(rows)==1;out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,forecasts=fs,whole_system_qualified=False),indent=2));print(json.dumps(dict(forecasts=fs,selected=[dict(source=r['spec']['source_root'],path=r['path'],sha256=r['sha256'])for r in rows])))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
