from pathlib import Path
import json,hashlib,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');new=b/'source-1250';old=b/'source-1240';out=b/'r256-weighted-settle-source-audit-1251';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='f2978da542dbc79b7a0330bbb6196f60b43f92dd'and len(z['files'])==1023
changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};prefix='project/experiments/control_v1/'
assert changed=={prefix+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','weighted_settled_bidirectional.h','weighted_settle_regression.py']}
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='43f1cfd2acb82326e07ba2a2b81fbc8212e9b3a7cd826c3fff3ef524ad6d2dbe'
assert all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for name in ['tree_router.cpp','tree_router_cpp.py','system_upper.py']:
 target=scratch/prefix/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((new/prefix/name).read_bytes())
patch=b/'control162-backout1251.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in ['tree_router.cpp','tree_router_cpp.py','system_upper.py']:assert(scratch/prefix/name).read_bytes()==(old/prefix/name).read_bytes()
t=(new/prefix/'tree_router.cpp').read_text();original=(old/prefix/'tree_router.cpp').read_text()
assert t[t.index('struct BidirectionalSearch {'):t.index('#include "weighted_bidirectional.h"')]==original[original.index('struct BidirectionalSearch {'):original.index('#include "weighted_bidirectional.h"')]
assert sha(new/prefix/'weighted_bidirectional.h')==sha(old/prefix/'weighted_bidirectional.h')
gates=['system_geometry.py','system_sta.py','system_accept.py','final_composition.py','native_pin_load.py','native_cap_residual.py','upper_cap_bound.py','steiner_wire_bound.py','placement_residual_budget.py','resource_search.h']
assert all(sha(new/prefix/p)==sha(old/prefix/p)for p in gates)
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1023,unchanged_manifest_files=1018,three_production_backouts_exact=True,exact_class_and_original_weighted_header_unchanged=True,final_gates_unchanged=gates,changed_files=sorted(changed),inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Five changed/new source files only; three production edits exactly reverse in own scratch. Exact class/original weighted header/resource solver/all final gates unchanged. Optional ordinary candidate changes require actual focused regression and final full-scene physical gates; this audit alone grants neither.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,source_files=1023,unchanged=1018)))
