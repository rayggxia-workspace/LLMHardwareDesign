from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1250';new=b/'source-1270';out=b/'r256-internal-trace-source-audit-1273';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='46c5820b42bf552d82e4e2d1a0446f7ff2925c6c'and len(z['files'])==1024
changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};prefix='project/experiments/control_v1/';assert changed=={prefix+n for n in ['program_event_trace.py','system_upper.py','internal_program_trace.py']}
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='e34fb39f43595d9f7000c8ba4f739c74c0754076a7f771b75f40b87855d229be'and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for name in ['program_event_trace.py','system_upper.py']:
 p=scratch/prefix/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/prefix/name).read_bytes())
patch=b/'control162-backout1273.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/prefix/n).read_bytes()==(old/prefix/n).read_bytes()for n in ['program_event_trace.py','system_upper.py'])
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1024,unchanged_manifest_files=1021,two_dispatch_observer_backouts_exact=True,all_rtl_and_router_and_physical_gates_unchanged=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only observational helper and two optional dispatch edits. Full1024source/archive hashes and two scratch exact backouts checked. All RTL, productionrouter, macros and physical gates among1021unchangedfiles. Actual new internal simulation not yet run; no physicalqualification.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,files=1024,unchanged=1021)))
