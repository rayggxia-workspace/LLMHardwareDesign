from pathlib import Path
p=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control\project\experiments\control_v1')
def replace(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def save(n,s): (p/n).write_bytes(s.encode())
s=(p/'weighted_bidirectional.h').read_text(encoding='utf-8');s=s[s.index('template<class Workspace,class Cost,class Allowed>'):]
s=replace(s,'weighted_bidirectional(','settled_weighted_bidirectional(')
s=replace(s,'int direction_cost,int weight){','int direction_cost,int weight,WeightedSettleState& state){')
s=replace(s,'const auto epoch=work.epoch;','const auto epoch=work.epoch;state.prepare(size,&work,epoch);++state.branches;')
s=replace(s,'work.df[qf.top().node]!=qf.top().cost)','work.df[qf.top().node]!=qf.top().cost||state.closed_f[qf.top().node]==epoch)')
s=replace(s,'work.db[qb.top().node]!=qb.top().cost)','work.db[qb.top().node]!=qb.top().cost||state.closed_b[qb.top().node]==epoch)')
s=replace(s,'auto& parent=reverse?work.pb:work.pf;','auto& parent=reverse?work.pb:work.pf;auto& closed=reverse?state.closed_b:state.closed_f;')
s=replace(s,'int v=item.node;auto c=coord(v);','int v=item.node;closed[v]=epoch;++state.expanded;auto c=coord(v);')
s=replace(s,'||!allowed(w))continue;','||!allowed(w)||closed[w]==epoch)continue;')
save('weighted_settled_bidirectional.h','''#pragma once

// Optional ordinary weighted search only. Each side expands a vertex once;
// this changes candidate paths and makes no shortest-path guarantee.
// Software scratch is allocated lazily, never hardware state or route evidence.
struct WeightedSettleState {
 std::vector<uint32_t> closed_f,closed_b;
 const void* owner=nullptr;uint32_t last_epoch=0;
 uint64_t branches=0,expanded=0;
 void prepare(size_t size,const void* workspace,uint32_t epoch){
  if(closed_f.size()!=size||owner!=workspace||epoch<=last_epoch){
   closed_f.assign(size,0);closed_b.assign(size,0);
  }
  owner=workspace;last_epoch=epoch;
 }
};

'''+s)
s=(p/'tree_router.cpp').read_text(encoding='utf-8')
for a,b in [('#include "weighted_bidirectional.h"','#include "weighted_bidirectional.h"\n#include "weighted_settled_bidirectional.h"'),('argc>29','argc>30'),('bool ordinary_coarse_neighbors=false;','bool weighted_settle_once=false;bool ordinary_coarse_neighbors=false;'),('  else if(option=="--ordinary-coarse-neighbors")','  else if(option=="--weighted-settle-once"){if(weighted_settle_once)throw runtime_error("duplicate weighted settle option");weighted_settle_once=true;}\n  else if(option=="--ordinary-coarse-neighbors")'),(' if(coarse_rounds_option&&!ordinary_coarse)',' if(weighted_settle_once&&(!weighted_bidir||!native_flexible||!ordinary_coarse_access))throw runtime_error("weighted settle requires weighted flexible native and coarse access mode");\n if(coarse_rounds_option&&!ordinary_coarse)'),(' BidirectionalSearch bidir(bidirectional_two_terminal?size:0);',' BidirectionalSearch bidir(bidirectional_two_terminal?size:0);WeightedSettleState weighted_settle_state;'),('path=weighted_bidirectional(bidir,nx,ny,start,tree[0],penalty,pair_allowed,nonpreferred_cost,search_weight);','path=weighted_settle_once?settled_weighted_bidirectional(bidir,nx,ny,start,tree[0],penalty,pair_allowed,nonpreferred_cost,search_weight,weighted_settle_state):weighted_bidirectional(bidir,nx,ny,start,tree[0],penalty,pair_allowed,nonpreferred_cost,search_weight);'),('  if(coarse_rounds_option)cout<<','  if(weighted_settle_once)cout<<"{\\"round\\":"<<iteration<<",\\"weighted_settle_once\\":true,\\"weighted_settle_branches\\":"<<weighted_settle_state.branches<<",\\"weighted_settle_expanded\\":"<<weighted_settle_state.expanded<<"}"<<endl;\n  if(coarse_rounds_option)cout<<')]:s=replace(s,a,b)
save('tree_router.cpp',s)
s=(p/'tree_router_cpp.py').read_text(encoding='utf-8')
for a,b in [('ordinary_coarse_rounds=64):','ordinary_coarse_rounds=64,weighted_settle_once=False):'),("    assert not weighted_bidirectional or bidirectional_two_terminal","    assert not weighted_settle_once or(weighted_bidirectional and native_prefix_flexible and ordinary_coarse_access)\n    if weighted_settle_once:extra_cli.append('--weighted-settle-once')\n    assert not weighted_bidirectional or bidirectional_two_terminal"),('        weighted_bidirectional=bool(weighted_bidirectional),',"        weighted_settle_once=bool(weighted_settle_once),weighted_settle_header_sha256=sha(source.with_name('weighted_settled_bidirectional.h')),\n        weighted_settle_trace=[r for r in trace if 'weighted_settle_once'in r],\n        weighted_bidirectional=bool(weighted_bidirectional),")]:s=replace(s,a,b)
save('tree_router_cpp.py',s)
s=(p/'system_upper.py').read_text(encoding='utf-8')
for a,b in [("    p.add_argument('--route-trace-phases'","    p.add_argument('--route-weighted-settle-once',action='store_true',help='Optional ordinary weighted candidate search closes each vertex once per side; exact weight1/native finite search and physical gates unchanged')\n    p.add_argument('--route-trace-phases'"),("    assert not a.route_trace_phases or a.route_weighted_bidirectional","    assert not a.route_weighted_settle_once or(a.route_weighted_bidirectional and a.route_native_prefix_flexible and a.route_ordinary_coarse_access)\n    assert not a.route_trace_phases or a.route_weighted_bidirectional"),('ordinary_coarse_rounds=a.route_ordinary_coarse_rounds)','ordinary_coarse_rounds=a.route_ordinary_coarse_rounds,weighted_settle_once=a.route_weighted_settle_once)')]:s=replace(s,a,b)
save('system_upper.py',s)
