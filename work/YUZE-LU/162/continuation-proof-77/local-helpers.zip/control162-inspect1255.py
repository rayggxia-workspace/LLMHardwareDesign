from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/function';text=(root/'obj/Vcontrol_system___024root.h').read_text();g=json.loads((b/'r256-composition-453/topology/boundary-graph.json').read_text());r=dict(headers_bytes=len(text),members=[l.strip()for l in text.splitlines()if re.search('Vcell(inp|out)__(controller|routes|endpoint_[0-7]|queue_[0-7]|s_port)__',l)],instances=list(g['instances']),example_connections=list(g['connections'].items())[:2])
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);(Path(__file__).parent/'control162-inspect1255.json').write_bytes(raw);r=json.loads(raw);print(json.dumps(r))
