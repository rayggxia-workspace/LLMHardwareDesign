from pathlib import Path
import sys,json
h=Path(__file__).parent;root=h/'LLMHardwareDesign-worktrees/issue-162-control';src=root/'project/experiments/control_v1';sys.path.insert(0,str(src))
import internal_program_trace,program_event_trace
out=h/'control162-internal1270-fixture';bench=(src/'test_system.cpp').read_text(encoding='utf-8');changed,recovered=program_event_trace.instrument(bench);assert recovered==bench
s,r,bindings=internal_program_trace.instrument(changed,out/'Vcontrol_system___024root.h',out/'boundary-graph.json',out);assert r==changed
(out/'instrumented.cpp').write_bytes(s.encode());rows=json.loads((out/'internal-signal-bindings.json').read_text())['bindings'];print(json.dumps(dict(local_instrumentation_only=True,graph_sha256=program_event_trace.sha(out/'boundary-graph.json'),bound_bits=len(rows),generated_bytes=len(s),removing_observations_recovers_original=True,not_compiled_or_simulated=True)))
