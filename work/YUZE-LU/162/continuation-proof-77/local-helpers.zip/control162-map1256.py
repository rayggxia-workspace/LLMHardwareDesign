from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');g=json.loads((b/'r256-composition-453/topology/boundary-graph.json').read_text());text=(b/'r256-composition-453/function/obj/Vcontrol_system___024root.h').read_text();members=set(re.findall(r'\b(control_system__DOT__\w+)\s*;',text));rows=[]
for bit,c in g['connections'].items():
 for p in [c['driver']]+c['sinks']:
  if p['instance']not in ['controller','routes'] and not p['instance'].startswith('queue_'):continue
  if not re.search('task_|cmd_|complete_|endpoint_|in_|out_',p['pin']):continue
  port=p['pin'].split('[')[0];m='control_system__DOT____Vcell'+('out'if p['direction']=='output'else'inp')+'__'+p['instance']+'__'+port;raw='control_system__DOT__net_'+bit
  chosen=m if m in members else raw if raw in members else None
  if chosen is None:
   for alt in [c['driver']]+c['sinks']:
    am='control_system__DOT____Vcell'+('out'if alt['direction']=='output'else'inp')+'__'+alt['instance']+'__'+alt['pin'].split('[')[0]
    if am in members:chosen=am+' via '+alt['pin'];break
  rows.append(dict(bit=bit,instance=p['instance'],pin=p['pin'],member=chosen))
print(json.dumps(dict(rows=rows,missing=[r for r in rows if r['member']is None])))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);(Path(__file__).parent/'control162-map1256.json').write_bytes(raw);r=json.loads(raw);print(json.dumps(dict(rows=len(r['rows']),missing_count=len(r['missing']),missing=r['missing'][:45],available=[x for x in r['rows']if x['member']][:22])))
