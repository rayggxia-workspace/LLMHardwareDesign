from pathlib import Path
import sys,subprocess,inspect,json,time,hashlib
h=Path(__file__).parent;src=h/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1';sys.path.insert(0,str(src))
import internal_program_trace as inner,program_event_trace as outer
out=h/'control162-prefix1278';out.mkdir(exist_ok=True)
subprocess.run(['scp','yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-internal-program-traces-1272/initial-1-162.jsonl',str(out/'live-read-prefix.jsonl')],check=True)
rows=[]
for line in(out/'live-read-prefix.jsonl').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:break
 rows.append(r)
 if r['event']=='program_end':break
assert rows[-1]['event']=='program_end'and rows[-1]['case']==1 and rows[-1]['run']==1
code=inspect.getsource(outer.audit);old='set(cases)==set(range(1,15))';assert code.count(old)==1;code=code.replace(old,'set(cases)=={1}')
outer_ns=dict(outer.__dict__);exec(compile(code,'external-prefix-observer','exec'),outer_ns)
code=inspect.getsource(inner.audit);old="len(programs)==18 and {p['case']for p in programs}==set(range(1,15))";assert code.count(old)==1;code=code.replace(old,"len(programs)==1 and {p['case']for p in programs}=={1}")
inner_ns=dict(inner.__dict__);inner_ns['external_audit']=outer_ns['audit'];exec(compile(code,'internal-prefix-observer','exec'),inner_ns);audit=inner_ns['audit']
def write(path,rs):path.write_bytes(('\n'.join(json.dumps(r)for r in rs)+'\n').encode())
path=out/'complete-first-program.jsonl';write(path,rows);result=audit(path,217396)
mutants=[]
for event,field in [('C_WORD','last'),('Q_CMD','endpoint'),('Q_TASK','words'),('Q_COMPLETE','words'),('Q_DONE','words'),('C_DONE','last')]:
 bad=json.loads(json.dumps(rows));idx=next(i for i,r in enumerate(bad)if r['event']==event)
 if field=='words':bad[idx]['words'][0]^=1
 else:bad[idx][field]^=1
 target=out/(event+'-corrupt.jsonl');write(target,bad)
 try:audit(target,217396)
 except(AssertionError,IndexError,KeyError)as e:mutants.append(dict(event=event,rejected=True,error=type(e).__name__))
 else:raise AssertionError(('Corruption accepted',event))
receipt=dict(passed=True,time=time.time(),whole_system_qualified=False,scope='Only actual completed first program from immutable captured live prefix. Exact full audit source changed solely final expected program/case cardinality to1; all packet and payload checks retained. Not full14case/threeinitial qualification; live source can continue growing.',first_program=result,negative_controls=mutants,source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [src/'internal_program_trace.py',src/'program_event_trace.py',path]})
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(passed=True,first_program=result['internal_programs'],negative_controls=mutants)))
