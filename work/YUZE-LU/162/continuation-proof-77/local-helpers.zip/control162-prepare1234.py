from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-phase-progress1198.py').read_text(encoding='utf-8').replace('11920','12220').replace('11921','12221').replace('phase-progress1198','phase-progress1234')
s=s.replace("last_batch=next((r for r in reversed(records)if 'global_batch_native_trees'in r),None)","last_schedule=next((r for r in reversed(records)if 'coarse_round_limit'in r),None)")
compile(s,'phase1234','exec');(h/'control162-phase-progress1234.py').write_bytes(s.encode())
