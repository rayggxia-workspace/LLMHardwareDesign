from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-compare1215.py').read_text(encoding='utf-8').replace('[(11400,11920),(11401,11921)]','[(11400,12220),(11400,12221)]').replace('compare1215','compare1237').replace("['without_neighbors','with_neighbors']","['coarse_until64','early_dense']").replace('for k in range(16):','for k in range(20):')
needle="for old,new in [(11400,12220),(11400,12221)]:"
s=s.replace(needle,"assert json.loads((b/'r256-early-dense-pretransition-audit-1236/receipt.json').read_text())['passed']\n"+needle)
compile(s,'compare1237','exec');(h/'control162-compare1237.py').write_bytes(s.encode())
