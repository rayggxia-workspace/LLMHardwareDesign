from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-read1206.py').read_text(encoding='utf-8').replace("[(95098,3,'dynamic-02/node3',11700),(97097,6,'dynamic-08/node6',11701)]","[(95341,2,'dynamic-05/node2',5550)]").replace('r256-neighbor-parameter-slot-admission-1206','r256-weighted-probe-slot-admission-1241').replace('len(rows)==2','len(rows)==1')
compile(s,'admit1241','exec');(h/'control162-read1241.py').write_bytes(s.encode())
