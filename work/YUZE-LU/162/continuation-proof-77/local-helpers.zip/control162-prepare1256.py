from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-queue1222-remote.py').read_text(encoding='utf-8')
s=s.replace("source-1218","source-1250").replace('16169058c4edc5e09b859c0a1a4e85f8baa0160e','f2978da542dbc79b7a0330bbb6196f60b43f92dd').replace('len(m[\'files\'])==1020','len(m[\'files\'])==1023').replace('b4a62c42851c22837ccdb72fdc81a5874b349839b1dc3a428ff8930d860859a3','43f1cfd2acb82326e07ba2a2b81fbc8212e9b3a7cd826c3fff3ef524ad6d2dbe')
s=s.replace('sready1222-native-warm-fullchains','sready1256-settled-fullchains').replace("[(12220,0,'dynamic-03/node5'),(12221,0,'dynamic-07/node7')]","[(12560,0,'dynamic-05/node2'),(12561,0,'dynamic-05/node4')]").replace("'sready1222'","'sready1256'").replace('seed==12220','seed==12560')
s=s.replace("a+=['--route-weighted-bidirectional'","a+=['--route-weighted-settle-once','--route-weighted-bidirectional'")
s=s.replace("str(b/'r256-final-chain-binding-audit-1223/receipt.json')","str(b/'r256-final-chain-binding-audit-1257/receipt.json'),str(b/'r256-weighted-settle-source-audit-1251/receipt.json'),str(b/'r256-weighted-settle-regression-1252/receipt.json')")
s=s.replace("record.mkdir();(record/'tasks.json')","assert json.loads((b/'r256-weighted-settle-regression-1252/receipt.json').read_text())['passed'];record.mkdir();(record/'tasks.json')")
a=s.index("scope='Controlled8/16");z=s.index("'),indent=2",a)
s=s[:a]+"scope='Optionalsettledweighted ordinarypair fullchains12560cutoff8node2/12561cutoff16node4. Same12220/12221controls stride16cost8cong1 additivehistory/seed4662/warm9060trial0,onlyordinaryweightedcandidate changes. All1023sourcefiles/archivesha verified; actual1252focusedfullregression/1251sourceaudit/1257strict14bindings requiredbeforelaunch. Exactcurrent453/S5380/R256/345statehosts/allM1-M10/finitebudget/geometry/PG/lowbasehigh300MHz gates unchanged.12560uses1252naturalcompletion slot;12561canonlyruninfreeexistingnode4slotorafterfreshspecificown6140replacementguard,neverparentorforeignops. Extra83.9MiBsoftwareclosedarrayspertrialremaininside64GiBouterforecast. Alloldraw/currentcontrols retained.8parents36x16dynamic/c96sixslots;no qualificationfromsmall/probeprefixes'"+s[z+1:]
s=s.replace('candidates=[12220,12221]','candidates=[12560,12561]')
compile(s,'queue1256','exec');(h/'control162-queue1256-remote.py').write_bytes(s.encode())
s=(h/'control162-audit1223-remote.py').read_text(encoding='utf-8').replace('r256-final-chain-binding-audit-1223','r256-final-chain-binding-audit-1257').replace('sready1222-native-warm-fullchains','sready1256-settled-fullchains').replace('[12220,12221]','[12560,12561]').replace('seed==12220','seed==12560').replace('source-1218','source-1250')
s=s.replace("assert '--route-ordinary-coarse-neighbors'not in route['args']","assert '--route-weighted-settle-once'in route['args']and str(b/'r256-weighted-settle-regression-1252/receipt.json')in route['requires'];assert '--route-ordinary-coarse-neighbors'not in route['args']")
s=s.replace('candidates12220/12221','candidates12560/12561')
compile(s,'audit1257','exec');(h/'control162-audit1257-remote.py').write_bytes(s.encode())
