from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-refill1224-remote.py').read_text(encoding='utf-8')
for a,b in [('sready1224-early-dense-refill','sready1259-settled-fullchain-refill'),('sready1222-native-warm-fullchains','sready1256-settled-fullchains'),('r256-coarse-rounds-regression-1219','r256-weighted-settle-regression-1252'),('r256-coarse-rounds-source-audit-1221','r256-weighted-settle-source-audit-1251'),('r256-final-chain-binding-audit-1223','r256-final-chain-binding-audit-1257'),("[(7,96297,'dynamic-07/node7',11601,'source-1154',0,224,284.8)]","[(4,95391,'dynamic-05/node4',6140,'source-613',0,224,284.8)]"),('r256-coarse-rounds-slot-admission-1220','r256-weighted-settle-slot-admission-1258')]:
 assert a in s,a;s=s.replace(a,b)
a=s.index("reason='");z=s.index("')\n",a)
s=s[:a]+"reason='Onlyexactown6140source613partial on95391node4replacedafterfresh1258specSHA/UID10011/job/actualnode/PID/cmd/source/out/current453graph/alllogs/nofinalandactual284.8GiBavailablefor224GiBforecast. Actual1252settledfullsmallregression/1251sourceaudit/1257strict14bindings allpassed beforecancel. Retainallrawandallcurrentold11200..05/11400..1/11920..1/12100..1/12220..1controlsandCUGR3751.8parents36x16dynamic/c96sixslots;no parent/foreign/externalRops;no fullphysicalqualificationinferred'"+s[z+1:]
compile(s,'refill1259','exec');(h/'control162-refill1259-remote.py').write_bytes(s.encode())
