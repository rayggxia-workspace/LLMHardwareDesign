from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1229.py').read_text(encoding='utf-8')
for a,b in [('r256-early-dense-active-audit-1229','r256-weighted-settle-active-audit-1261'),('12220','12560'),('12221','12561'),("[(95155,5,'dynamic-03/node5',[12560],[10430,11400,11920,12560]),(96297,7,'dynamic-07/node7',[12561],[11401,11921,12561])]","[(95341,2,'dynamic-05/node2',[12560],[6560,9920,11202,12560]),(95391,4,'dynamic-05/node4',[12561],[6563,9921,11203,12561])]"),('source1218earlydensechildren','source1250settledcandidatechildren'),('Actualnode5four16CPU masksdisjoint,node7threeobservedrouter16CPUmasksdisjoint(CUGR3751notclaimed)','Actualnode2andnode4four16CPUmaskseachpairwisedisjoint')]:
 assert a in s,a;s=s.replace(a,b)
s=s.replace("['--ordinary-endpoint-escape','--weighted-bidirectional'","['--weighted-settle-once','--ordinary-endpoint-escape','--weighted-bidirectional'")
compile(s,'active1261','exec');(h/'control162-audit1261.py').write_bytes(s.encode())
s=(h/'control162-phase-progress1234.py').read_text(encoding='utf-8').replace('[12220,12221]','[12560,12561]').replace('control162-phase-progress1234','control162-phase-progress1262')
compile(s,'progress1262','exec');(h/'control162-phase-progress1262.py').write_bytes(s.encode())
