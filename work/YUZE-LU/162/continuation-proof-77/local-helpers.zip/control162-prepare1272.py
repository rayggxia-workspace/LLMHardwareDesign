from pathlib import Path
import subprocess
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control'
files=['project/experiments/control_v1/'+n for n in ['program_event_trace.py','system_upper.py']]
(h/'control162-backout1273.patch').write_bytes(subprocess.check_output(['git','diff','f2978da542dbc79b7a0330bbb6196f60b43f92dd','46c5820b42bf552d82e4e2d1a0446f7ff2925c6c','--',*files],cwd=repo))
s=r'''from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1250';new=b/'source-1270';out=b/'r256-internal-trace-source-audit-1273';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='46c5820b42bf552d82e4e2d1a0446f7ff2925c6c'and len(z['files'])==1024
changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};prefix='project/experiments/control_v1/';assert changed=={prefix+n for n in ['program_event_trace.py','system_upper.py','internal_program_trace.py']}
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='e34fb39f43595d9f7000c8ba4f739c74c0754076a7f771b75f40b87855d229be'and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for name in ['program_event_trace.py','system_upper.py']:
 p=scratch/prefix/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/prefix/name).read_bytes())
patch=b/'control162-backout1273.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/prefix/n).read_bytes()==(old/prefix/n).read_bytes()for n in ['program_event_trace.py','system_upper.py'])
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1024,unchanged_manifest_files=1021,two_dispatch_observer_backouts_exact=True,all_rtl_and_router_and_physical_gates_unchanged=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only observational helper and two optional dispatch edits. Full1024source/archive hashes and two scratch exact backouts checked. All RTL, productionrouter, macros and physical gates among1021unchangedfiles. Actual new internal simulation not yet run; no physicalqualification.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,files=1024,unchanged=1021)))
'''
compile(s,'audit1273','exec');(h/'control162-audit1273-remote.py').write_bytes(s.encode())
s=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1270';record=b/'route-selection-102/sready1272-internal-program-traces';out=b/'r256-internal-program-traces-1272';assert not record.exists()and not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
requires=[b/'r256-internal-trace-source-audit-1273/receipt.json',b/'r256-padding-final-function-audit-472/receipt.json',b/'r256-padding-program-event-audit-480/receipt.json',b/'r256-weighted-settle-regression-1252/receipt.json'];assert all(json.loads(p.read_text())['passed']for p in requires)
m=json.loads((source/'source-manifest.json').read_text());assert m['commit']=='46c5820b42bf552d82e4e2d1a0446f7ff2925c6c'and len(m['files'])==1024 and all(sha(source/p)==v for p,v in m['files'].items())
cfg=b/'config1272.json';assert not cfg.exists();d=json.loads((b/'route-selection-102/sready473-padding-program-events/config.json').read_text());graph=b/'r256-composition-453/topology/boundary-graph.json';assert sha(graph)=='49ba0e348f3583f6facdf60e771fe6f1329b46fe5aac872c3828d4b61ddb1a68';d.update(signal_graph=str(graph),signal_graph_sha256=sha(graph));cfg.write_text(json.dumps(d,indent=2))
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=96,requires=list(map(str,requires)),args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(graph),'--internal-program-trace-config',str(cfg),'--out',str(out)])
p=b/'dynamic-05/node2/pending/00-zg-sready1272-internal-program-traces.json';assert not p.exists();tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);record.mkdir();(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),sha256=sha(p),spec=spec)],whole_system_qualified=False,scope='Actual same immutable compiled345instance finalcell model reusedread-only; observational bench compile only, threeinitialruns parallel insideown16CPUslot96GiBforecast. Cword/eightqueuecmd-task-complete-return/Cdone observations graphbit/rootmemberSHA-bound. Originalgolden checks/cycles/results exact plus independentinternalpacket/externalAXIreplayrequired. NoRTL/routing/physicalgatechanges or fullphysicalqualification. Canreplaceonlyown6560source653afterfresh1271rawguardand361.6GiBavailable288forecast;allcurrentfullgridcontrols kept.'),indent=2));print(json.dumps(dict(queued=True,path=str(p),forecast_gib=96)))
'''
compile(s,'queue1272','exec');(h/'control162-queue1272-remote.py').write_bytes(s.encode())
s=(h/'control162-refill1259-remote.py').read_text(encoding='utf-8')
for a,b in [('sready1259-settled-fullchain-refill','sready1274-internal-trace-refill'),('sready1256-settled-fullchains','sready1272-internal-program-traces'),("assert len(tasks['tasks'])==14","assert len(tasks['tasks'])==1"),('r256-final-chain-binding-audit-1257','r256-internal-trace-source-audit-1273'),("[(4,95391,'dynamic-05/node4',6140,'source-613',0,224,284.8)]","[(2,95341,'dynamic-05/node2',6560,'source-653',0,288,361.6)]"),('r256-weighted-settle-slot-admission-1258','r256-internal-trace-slot-admission-1271'),("current_forecast-spec['forecast_gib']+64<=forecast","current_forecast-spec['forecast_gib']+96<=forecast")]:
 assert a in s,a;s=s.replace(a,b)
a=s.index("reason='");z=s.index("')\n",a)
s=s[:a]+"reason='Onlyexactown6560source653partial on95341node2replacedafterfresh1271specSHA/UID10011/job/actualnode/PID/cmd/source/out/current453graph/alllogs/nofinalandactual361.6GiBavailablefor288GiBforecast. Actual1273sourceaudit/1252regression/1251sourceaudit passed first. Internalobservationalbenchmark usesunchangedcompiledfinalcell modelandoriginalgoldenchecks,96GiBforecastthreeparallelinitialrunswithin16CPUslot. Allrawandcurrent12560/12561/11200..5/11400..1/11920..1/12100..1/12220..1/CUGR retained.8parents36x16dynamic/c96sixslots;no parent/foreign/externalRops;no fullphysicalqualificationinferred'"+s[z+1:]
compile(s,'refill1274','exec');(h/'control162-refill1274-remote.py').write_bytes(s.encode())
