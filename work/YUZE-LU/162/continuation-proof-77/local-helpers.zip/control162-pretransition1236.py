from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates';out=b/'r256-early-dense-pretransition-audit-1236';assert not out.exists();rows=[];sha=lambda x:hashlib.sha256(x).hexdigest()
def records(seed,i,cutoff):
 p=root/str(seed)/'route'/('trial-'+str(i))/'router.log'
 with p.open('rb')as f:raw=f.read(4000000)
 parsed=[]
 for line in raw.decode().splitlines():
  if not line.startswith('{'):continue
  try:r=json.loads(line)
  except ValueError:continue
  if 'round'in r and r['round']<cutoff and 'routing_phase_event'not in r and 'coarse_round_limit'not in r:parsed.append(r)
 complete=[r['round']for r in parsed if'conflict_nodes'in r];assert complete==list(range(cutoff)),(seed,i,complete)
 return parsed,dict(path=str(p),prefix_bytes=len(raw),prefix_sha256=sha(raw),filtered_canonical_sha256=sha(json.dumps(parsed,sort_keys=True,separators=(',',':')).encode()))
for seed,cutoff in [(12220,8),(12221,16)]:
 for i in range(16):
  a=root/'11400/route'/('trial-'+str(i))/'input.txt';z=root/str(seed)/'route'/('trial-'+str(i))/'input.txt';assert a.read_bytes()==z.read_bytes()
  control,cb=records(11400,i,cutoff);candidate,nb=records(seed,i,cutoff);assert control==candidate,(seed,i)
  rows.append(dict(candidate=seed,trial=i,cutoff=cutoff,input_bytes_exact=True,input_sha256=sha(z.read_bytes()),control=cb,candidate_prefix=nb,all_pretransition_nontiming_records_byte_canonical_exact=True,complete_rounds=cutoff))
snapshots=[]
for seed in [11400,12220,12221]:
 p=root/str(seed)/'route/trial-0/output.txt.global-round-8.txt';snapshots.append(dict(candidate=seed,path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
assert len({x['sha256']for x in snapshots})==1
out.mkdir();r=dict(passed=True,time=time.time(),whole_system_qualified=False,comparisons=rows,round8_snapshots=snapshots,scope='Actual32before-transition comparisons against11400control.16cutoff8trial inputs andall rounds0..7nontiming records exact;16cutoff16trial inputs androunds0..15exact. Onlyphase timing records andnewcutoffdiagnostic excluded. Threeactualround8complete snapshots byte-SHAexact. Bounded4MBprefixes SHA-bound,not claimed final logs. No post-transition convergence/performance or physical qualification inferred.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,actual_trial_pairs=32,complete_round_pairs=sum(x['complete_rounds']for x in rows),all_three_round8_snapshots_sha_exact=True)))
'''
compile(q,'pretransition1236','exec');raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-pretransition1236.json';out.write_bytes(raw);print(raw.decode())
