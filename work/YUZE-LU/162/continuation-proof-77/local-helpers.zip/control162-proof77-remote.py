from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-77';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set();indexed={}
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for q in p.iterdir():
  if q.is_file()and q.name not in ['router','probe','test']and q.stat().st_size<4000000:add(q)
for name in ['r256-early-dense-pretransition-audit-1236','r256-weighted-probe-source-audit-1244','r256-weighted-settle-source-audit-1251','r256-weighted-settle-regression-1252','r256-final-chain-binding-audit-1257','r256-weighted-settle-slot-admission-1258','r256-weighted-settle-active-audit-1261','r256-internal-trace-source-audit-1273','r256-internal-trace-slot-admission-1271']:
 assert json.loads((b/name/'receipt.json').read_text()).get('passed',True);shallow(b/name)
for n in [1242,1248]:
 root=b/('r256-weighted-reopen-probe-'+str(n));assert json.loads((root/'receipt.json').read_text())['passed'];shallow(root);shallow(root/'weighted-reopen')
root=b/'r256-weighted-settle-regression-1252/weighted-settle';shallow(root);shallow(root/'production-selftest');shallow(root/'unchanged-rounds')
for pattern in ['settled-*','invalid-*','one-round-failure']:
 for p in root.glob(pattern):
  if p.is_dir():shallow(p)
for p in(root/'unchanged-rounds').glob('cutoff-*'):shallow(p)
for name in ['sready1243-weighted-reopen-probe-refill','sready1259-settled-fullchain-refill','sready1274-internal-trace-refill']:shallow(b/'route-selection-102'/name)
for name in ['sready1242-weighted-reopen-probe','sready1248-weighted-probe-second-frame','sready1252-weighted-settle-regression','sready1256-settled-fullchains','sready1272-internal-program-traces']:
 p=b/'route-selection-102'/name/'tasks.json';add(p)
 for r in json.loads(p.read_text())['tasks']:add(r['path'])
for n in [1240,1250,1270]:
 for name in ['source-manifest.json','freeze-import.json']:add(b/('source-'+str(n))/name)
for name in ['config1242.json','config1248.json','config1252.json','config1272.json','control162-backout1251.patch','control162-audit1251-remote.py','control162-audit1257-remote.py','control162-backout1273.patch','control162-audit1273-remote.py']:add(b/name)
for name in ['internal-signal-bindings.json','instrumentation.json','test_system_events.cpp','compile.log','link.log']:add(b/'r256-internal-program-traces-1272'/name)
out.mkdir();live=out/'live-route-snapshots';live.mkdir();progress=[]
for seed in [11200,11201,11202,11203,11204,11205,11400,11401,11920,11921,12100,12101,12220,12221,12560,12561]:
 route=b/'r256-composition-453/upper-candidates'/str(seed)/'route';p=route/'trial-0/router.log'
 if not p.is_file():continue
 raw=p.read_bytes();target=live/(str(seed)+'-trial0.log');target.write_bytes(raw);add(target);records=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:records.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=seed,time=time.time(),original_log=str(p),immutable_prefix=str(target),last_complete_global=next((r for r in reversed(records)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(records)if'routed'in r),None),last_settled=next((r for r in reversed(records)if'weighted_settle_once'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
trace_progress=[]
for p in(b/'r256-internal-program-traces-1272').glob('initial-*.jsonl'):
 raw=p.read_bytes();target=live/p.name;target.write_bytes(raw);add(target);rows=[]
 for line in raw.decode().splitlines():
  try:rows.append(json.loads(line))
  except ValueError:pass
 trace_progress.append(dict(original=str(p),immutable_live_prefix=str(target),bytes=len(raw),last_complete_event=rows[-1]if rows else None,complete_simulation=False))
(out/'live-internal-trace-progress.json').write_text(json.dumps(trace_progress,indent=2));add(out/'live-internal-trace-progress.json')
for p in selected:
 indexed[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))
 if p.suffix=='.json':
  try:d=json.loads(p.read_text())
  except ValueError:continue
  if isinstance(d,dict):
   for source,expected in d.get('inputs',{}).items():
    q=Path(source)
    if q.is_file()and str(q).startswith(str(b)+'/'):
     actual=sha(q);assert actual==expected,(q,actual,expected)
     if source not in indexed:indexed[source]=dict(bytes=q.stat().st_size,sha256=actual,copied=False)
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
p=out/'selected-originals.zip';index=dict(time=time.time(),whole_system_qualified=False,files=indexed,copied_files=len(selected),indexed_files=len(indexed),archive=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)),scope='Two actual bounded frame probes with artificialoccupancy costs;127validpaths/onebaseline timeout, independentPythonpath/cost replay;96productioncandidatepathreplays/weight1/epochreset and192Dijkstrachecks; actual1252nesteddefaultbyte/fullsmallroutes and newsettledfullsmallroutes;1251source/1257strict14bindings. Immutableliveprefixes only, nofullcompositionpass. AlllargeframesremainauthorizedserverSHA-bound.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(indexed=len(indexed),copied=len(selected),zip_bytes=p.stat().st_size,zip_sha256=sha(p))))
