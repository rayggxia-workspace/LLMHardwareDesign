from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');queue=b/'dynamic-05/node2';state=json.loads((queue/'queue-state.json').read_text());root=b/'r256-weighted-reopen-probe-1248';child=root/'weighted-reopen';r=dict(time=time.time(),active=state['active'],finished={k:v for k,v in state['finished'].items()if'sready1248'in k},receipt=None,case_headers=[])
if(root/'receipt.json').exists():
 d=json.loads((root/'receipt.json').read_text());r['receipt']={k:d[k]for k in ['passed','stage','error']if k in d}
for p in child.glob('net_*-w*-s*.json'):
 with p.open('rb')as f:head=f.read(4096)
 if b',"path":'not in head:continue
 d=json.loads(head.split(b',"path":',1)[0]+b'}');d['path']=str(p);r['case_headers'].append(d)
if(child/'self-test.stdout').exists():r['selftest']=(child/'self-test.stdout').read_text()
p=queue/'00-ze-sready1248-weighted-probe-second-frame.log'
if p.exists():
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-3000));r['log_tail']=f.read().decode(errors='replace')
if(child/'receipt.json').exists():
 d=json.loads((child/'receipt.json').read_text());r['actual_cases_summary']=dict(cases=len(d['cases']),timeouts=sum(x['timed_out']for x in d['cases']),returned_errors=sum(x['returncode']not in(None,0)for x in d['cases']),completed_successes=sum('result'in x for x in d['cases']))
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-read1249';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);r=json.loads(raw);print(json.dumps(dict(time=r['time'],active=r['active'],receipt=r['receipt'],selftest=r.get('selftest'),completed_case_headers=len(r['case_headers']),cases_summary=r.get('actual_cases_summary'),first_case_headers=r['case_headers'][:4],log_tail=r.get('log_tail'))))
