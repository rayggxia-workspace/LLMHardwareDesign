from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');queue=b/'dynamic-05/node2';state=json.loads((queue/'queue-state.json').read_text());root=b/'r256-weighted-settle-regression-1252';r=dict(time=time.time(),active=state['active'],finished={k:v for k,v in state['finished'].items()if'sready1252'in k},receipt=None)
if(root/'receipt.json').exists():r['receipt']=json.loads((root/'receipt.json').read_text())
p=queue/'00-zf-sready1252-weighted-settle-regression.log'
if p.exists():
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-4000));r['log_tail']=f.read().decode(errors='replace')
r['compiled']=[dict(path=str(p.parent.relative_to(root)),mtime=p.stat().st_mtime)for p in root.rglob('router')if p.is_file()]
if(root/'weighted-settle/production-selftest/stdout').exists():r['selftest']=(root/'weighted-settle/production-selftest/stdout').read_text()
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-read1254';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);r=json.loads(raw);r['compiled']=sorted(r['compiled'],key=lambda x:x['mtime'])[-5:];print(json.dumps(r))
