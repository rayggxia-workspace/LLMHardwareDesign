from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-internal-program-traces-1272';queue=b/'dynamic-05/node2';state=json.loads((queue/'queue-state.json').read_text());r=dict(time=time.time(),active=state['active'],finished={k:v for k,v in state['finished'].items()if'sready1272'in k},files=[dict(name=p.name,bytes=p.stat().st_size,mtime=p.stat().st_mtime)for p in root.glob('*')if p.is_file()])
if(root/'receipt.json').exists():r['receipt']=json.loads((root/'receipt.json').read_text())
r['trace_progress']=[]
for p in root.glob('initial-*.jsonl'):
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-5000));lines=f.read().decode(errors='replace').splitlines()
 rows=[]
 for line in lines:
  try:rows.append(json.loads(line))
  except ValueError:pass
 if rows:r['trace_progress'].append(dict(name=p.name,last_complete_event=rows[-1]))
for p in [queue/'00-zg-sready1272-internal-program-traces.log',root/'compile.log',root/'link.log']:
 if p.exists():
  with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-4500));r[p.name]=f.read().decode(errors='replace')
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-read1276';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);print(raw.decode())
