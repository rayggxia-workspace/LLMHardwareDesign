#include <bits/stdc++.h>
using namespace std;
struct Item {int64_t priority,cost;int node;bool operator<(const Item& q)const{
 if(priority!=q.priority)return priority>q.priority;
 // On an equal A* score, advance towards the existing tree rather than
 // expanding an arbitrary broad equal-score frontier. Physical checks stay
 // independent of this search-order decision.
 if(cost!=q.cost)return cost<q.cost;
 return node>q.node;
}};
struct BidirectionalSearch {
 vector<int64_t>df,db;vector<uint32_t>vf,vb;vector<int>pf,pb;uint32_t epoch=0;
 explicit BidirectionalSearch(size_t size):df(size),db(size),vf(size),vb(size),pf(size),pb(size){}
 template<class Cost,class Allowed>
 vector<int>find(int nx,int ny,int start,int goal,Cost penalty,Allowed allowed,int nonpreferred_cost=2){
  if(nonpreferred_cost!=2&&nonpreferred_cost!=8&&nonpreferred_cost!=32)throw runtime_error("invalid bidirectional direction cost");
  int plane=nx*ny,size=2*plane;const int64_t inf=numeric_limits<int64_t>::max()/4;
  if(!++epoch)throw runtime_error("bidirectional epoch overflow");
  auto coord=[&](int v){return array<int,3>{v%nx,(v%plane)/nx,v/plane};};
  auto s=coord(start),g=coord(goal);
  auto potential=[&](int v){auto p=coord(v);return abs(p[0]-g[0])+abs(p[1]-g[1])-abs(p[0]-s[0])-abs(p[1]-s[1]);};
  priority_queue<Item>qf,qb;qf.push({0,0,start});qb.push({0,0,goal});
  vf[start]=vb[goal]=epoch;df[start]=db[goal]=0;int meeting=-1;int64_t best=inf;
  auto consider=[&](int v){if(vf[v]==epoch&&vb[v]==epoch&&df[v]+db[v]<best){best=df[v]+db[v];meeting=v;}};
  consider(start);
  while(true){
   while(!qf.empty()&&(vf[qf.top().node]!=epoch||df[qf.top().node]!=qf.top().priority))qf.pop();
   while(!qb.empty()&&(vb[qb.top().node]!=epoch||db[qb.top().node]!=qb.top().priority))qb.pop();
   if(qf.empty()||qb.empty())break;
   if(best!=inf&&qf.top().priority+qb.top().priority>=best)break;
   bool reverse=qb.top().priority<qf.top().priority;auto& q=reverse?qb:qf;
   auto& d=reverse?db:df;auto& seen=reverse?vb:vf;auto& parent=reverse?pb:pf;
   auto item=q.top();q.pop();int v=item.node;auto c=coord(v);int x=c[0],y=c[1],l=c[2];
   array<pair<int,int>,5>next{{{v-1,l==0?1:nonpreferred_cost},{v+1,l==0?1:nonpreferred_cost},{v-nx,l==1?1:nonpreferred_cost},{v+nx,l==1?1:nonpreferred_cost},{(1-l)*plane+y*nx+x,3}}};
   for(int i=0;i<5;++i){if(i==4&&(x+y)%2)continue;int w=next[i].first;if(w<0||w>=size)continue;auto p=coord(w);
    if(p[0]<4||p[0]>=nx-4||p[1]<4||p[1]>=ny-4||!allowed(w))continue;
    int64_t cost=next[i].second+penalty(reverse?v:w);
    __int128 reduced=__int128(2)*cost+(reverse?potential(v)-potential(w):potential(w)-potential(v));
    if(reduced<0||__int128(item.priority)+reduced>=inf)throw runtime_error("invalid reduced bidirectional cost");
    int64_t alt=item.priority+int64_t(reduced);
    // Reduced costs can be zero across an empty Manhattan rectangle. The
    // tie key is twice the original accumulated cost, rather than the
    // reduced cost, so equal-score searches advance instead of sweeping
    // that whole rectangle. Distances and termination use reduced costs.
    int64_t original=alt+(reverse?potential(w)-potential(goal):potential(start)-potential(w));
    if(seen[w]!=epoch||alt<d[w]){seen[w]=epoch;d[w]=alt;parent[w]=v;q.push({alt,original,w});consider(w);}
   }
  }
  if(meeting<0)return{};
  vector<int>path{meeting};while(path.back()!=start)path.push_back(pf[path.back()]);reverse(path.begin(),path.end());
  for(int v=meeting;v!=goal;){v=pb[v];path.push_back(v);}return path;
 }
};

#include "baseline-weighted.h"
struct Stats{uint64_t expanded=0,reopened=0,unique=0;};
#include "probe-weighted.h"
#include "weighted_settled_bidirectional.h"

int64_t valid_path(const vector<int>&path,int nx,int ny,int start,int goal,int np,const vector<int>&fixed,int owner,const vector<int>&usage){
 if(path.empty())throw runtime_error("empty path");int plane=nx*ny;int64_t cost=0;
 if(path.front()!=start||path.back()!=goal)throw runtime_error("endpoints");
 for(size_t j=1;j<path.size();++j){int a=path[j-1],b=path[j],x=a%nx,y=(a%plane)/nx,l=a/plane,xx=b%nx,yy=(b%plane)/nx,ll=b/plane;
  if(b<0||b>=2*plane||xx<4||xx>=nx-4||yy<4||yy>=ny-4||abs(x-xx)+abs(y-yy)+abs(l-ll)!=1||(l!=ll&&(x+y)%2)||(fixed[b]>=0&&fixed[b]!=owner))throw runtime_error("unit edge/fixed landing");
  cost+=(l!=ll?3:(x!=xx?(l==0?1:np):(l==1?1:np)))+int64_t(64)*usage[b];
 }return cost;
}
int main(int argc,char**argv){try{
 if(argc==2&&string(argv[1])=="--self-test"){
  mt19937 random(1240);int checks=0,baseline_replays=0;uint64_t reopens=0;
  for(int i=0;i<96;++i){int nx=24,ny=26,plane=nx*ny,size=2*plane,np=i%2?8:2,weight= i%3==0?4:i%3==1?16:64;
   BidirectionalSearch work(size);vector<uint32_t>cf(size),cb(size);vector<int>fixed(size,-1),usage(size);
   for(int v=0;v<size;++v){if(random()%23==0)fixed[v]=1;usage[v]=random()%5;}int start=5+random()%12+nx*(5+random()%14),goal=5+random()%12+nx*(5+random()%14);fixed[start]=fixed[goal]=-1;
   auto penalty=[&](int v){return int64_t(64)*usage[v];};auto allowed=[&](int v){return fixed[v]<0;};
   auto baseline=weighted_bidirectional(work,nx,ny,start,goal,penalty,allowed,np,weight);Stats a;
   auto measured=probe_weighted_bidirectional(work,nx,ny,start,goal,penalty,allowed,np,weight,false,cf,cb,a);if(baseline!=measured)throw runtime_error("instrumentation changed baseline path");++baseline_replays;reopens+=a.reopened;
   Stats b;auto settled=probe_weighted_bidirectional(work,nx,ny,start,goal,penalty,allowed,np,weight,true,cf,cb,b);WeightedSettleState state;auto actual=settled_weighted_bidirectional(work,nx,ny,start,goal,penalty,allowed,np,weight,state);if(actual!=settled||state.expanded!=b.expanded||state.branches!=1)throw runtime_error("production candidate mismatch");auto exact=settled_weighted_bidirectional(work,nx,ny,start,goal,penalty,allowed,np,1,state);if(state.branches!=1)throw runtime_error("weight1 mutated settled state");auto expected=work.find(nx,ny,start,goal,penalty,allowed,np);if(exact!=expected)throw runtime_error("weight1 exact dispatch mismatch");state.last_epoch=work.epoch+100;actual=settled_weighted_bidirectional(work,nx,ny,start,goal,penalty,allowed,np,weight,state);if(actual!=settled)throw runtime_error("epoch reset mismatch");if(b.reopened)throw runtime_error("settled vertex reopened");
   const int64_t inf=numeric_limits<int64_t>::max()/4;vector<int64_t>d(size,inf);priority_queue<pair<int64_t,int>,vector<pair<int64_t,int>>,greater<pair<int64_t,int>>>q;d[start]=0;q.push({0,start});
   while(!q.empty()){auto [cost,v]=q.top();q.pop();if(cost!=d[v])continue;if(v==goal)break;int x=v%nx,y=(v%plane)/nx,l=v/plane;
    for(int delta:array<int,5>{-1,1,-nx,nx,(1-2*l)*plane}){int w=v+delta;if(w<0||w>=size)continue;int xx=w%nx,yy=(w%plane)/nx,ll=w/plane;
     if(xx<4||xx>=nx-4||yy<4||yy>=ny-4||!allowed(w)||(ll!=l&&(x+y)%2))continue;
     int64_t alt=cost+(ll!=l?3:(x!=xx?(l==0?1:np):(l==1?1:np)))+penalty(w);if(alt<d[w]){d[w]=alt;q.push({alt,w});}
    }
   }
   for(auto&path:array<vector<int>,2>{measured,settled}){if(path.empty()){if(d[goal]!=inf)throw runtime_error("reachable graph rejected");}else if(d[goal]==inf||valid_path(path,nx,ny,start,goal,np,fixed,0,usage)<d[goal])throw runtime_error("independent weighted path check");++checks;}
  }
  cout<<"{\"passed\":true,\"independent_path_checks\":"<<checks<<",\"baseline_exact_path_replays\":"<<baseline_replays<<",\"observed_synthetic_reopens\":"<<reopens<<"}"<<endl;return 0;
 }
 if(argc!=7)throw runtime_error("input/snapshot/net/weight/mode/output required");ifstream f(argv[1]);string line;getline(f,line);istringstream hs(line);vector<int>h;int value;while(hs>>value)h.push_back(value);if(h.size()!=17)throw runtime_error("header");
 int nx=h[0],ny=h[1],count=h[2],plane=nx*ny,size=plane*2,target=-1,weight=stoi(argv[4]);bool settle=stoi(argv[5]);if((weight!=16&&weight!=64)||(string(argv[5])!="0"&&string(argv[5])!="1"))throw runtime_error("probe options");
 vector<string>names(count);vector<vector<int>>pins(count),trees(count);vector<int>fixed(size,-1),usage(size);
 for(int n=0;n<count;++n){int k,x,y,limit;f>>names[n]>>k;for(int j=0;j<k;++j){f>>x>>y;int q=y*nx+x;pins[n].push_back(q);if(fixed[q]>=0&&fixed[q]!=n)throw runtime_error("foreign pin collision");fixed[q]=n;}f>>limit;if(names[n]==argv[3]){if(n<h[6]||k!=2||limit!=-1)throw runtime_error("not ordinary pair");target=n;}}
 if(target<0)throw runtime_error("unknown probe net");ifstream dump(argv[2]);int total;dump>>total;if(total!=count)throw runtime_error("snapshot count");
 for(int n=0;n<count;++n){string name;int branches;dump>>name>>branches;if(name!=names[n])throw runtime_error("snapshot net order");auto&tree=trees[n];for(int j=0;j<branches;++j){int k;dump>>k;for(int q=0;q<k;++q){int x,y,l;dump>>x>>y>>l;tree.push_back(l*plane+y*nx+x);}}sort(tree.begin(),tree.end());tree.erase(unique(tree.begin(),tree.end()),tree.end());for(int v:tree)++usage[v];}
 for(int v:trees[target])--usage[v];BidirectionalSearch work(size);vector<uint32_t>cf(size),cb(size);Stats stats;
 auto penalty=[&](int v){return int64_t(64)*usage[v];};auto allowed=[&](int v){return fixed[v]<0||fixed[v]==target;};auto before=chrono::steady_clock::now();
 auto path=probe_weighted_bidirectional(work,nx,ny,pins[target][1],pins[target][0],penalty,allowed,8,weight,settle,cf,cb,stats);
 auto elapsed=chrono::duration_cast<chrono::microseconds>(chrono::steady_clock::now()-before).count();auto cost=valid_path(path,nx,ny,pins[target][1],pins[target][0],8,fixed,target,usage);
 if(settle&&stats.reopened)throw runtime_error("settled actual vertex reopened");ofstream result(argv[6]);result<<"{\"passed\":true,\"net\":\""<<names[target]<<"\",\"weight\":"<<weight<<",\"settle\":"<<(settle?"true":"false")<<",\"expanded\":"<<stats.expanded<<",\"unique_expanded\":"<<stats.unique<<",\"reopened\":"<<stats.reopened<<",\"microseconds_search_only\":"<<elapsed<<",\"vertices\":"<<path.size()<<",\"cost\":"<<cost<<",\"path\":[";for(size_t j=0;j<path.size();++j){if(j)result<<',';result<<path[j];}result<<"]}"<<endl;return 0;
 }catch(const exception&e){cerr<<e.what()<<endl;return 1;}}
