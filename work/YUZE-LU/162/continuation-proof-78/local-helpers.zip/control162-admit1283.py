from pathlib import Path
import subprocess,shlex
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');queue=b/'dynamic-05/node4';state=json.loads((queue/'queue-state.json').read_text());rows=[];fs=[]
for name in state['active']:
 p=queue/'pending'/(name+'.json');raw=p.read_bytes();s=json.loads(raw);fs.append([name,s['forecast_gib']]);a=s['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='6563':rows.append(dict(job=95391,node=4,folder='dynamic-05/node4',target=6563,path=str(p),sha256=hashlib.sha256(raw).hexdigest(),spec=s))
out=b/'r256-settled-window-slot-admission-1283';assert not out.exists()and len(rows)==1;out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,forecasts=fs,whole_system_qualified=False),indent=2));print(json.dumps(dict(forecasts=fs,selected=rows)))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
