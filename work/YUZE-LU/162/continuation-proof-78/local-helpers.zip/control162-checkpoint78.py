from pathlib import Path
import subprocess,json,hashlib,zipfile,io,shutil,datetime
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-78';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-78/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert set(z.namelist())==set(rows)and z.testzip()is None
 for n,v in rows.items():data=z.read(n);assert sha(data)==v['sha256']and len(data)==v['bytes']
 for n in ['r256-internal-program-traces-1272','r256-final-chain-binding-audit-1285','r256-settled-window-node4-active-audit-1287','r256-settled-window-node2-active-audit-1293']:assert json.loads(z.read(n+'/receipt.json'))['passed']
delivery=h/'LLMHardwareDesign-deliveries/issue-162/internal-program-events-1272';rx=json.loads((delivery/'RECEPTION.json').read_text());archive=Path(rx['archive']['path']);assert sha(archive.read_bytes())==rx['archive']['sha256']
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and set(z.namelist())==set(rx['files'])
 for n,v in rx['files'].items():data=z.read(n);assert sha(data)==v['sha256']and len(data)==v['bytes'];assert data==(delivery/n).read_bytes()
audit=json.loads((delivery/'INDEPENDENT-AUDIT.json').read_text());assert audit['passed']and len(audit['results'])==3 and len(audit['negative_controls'])==6 and audit['external_traces_byteexact_to_473']
dest=base/'internal-program-events-current1272';assert not dest.exists();dest.mkdir();shutil.copyfile(archive,dest/'actual-events.zip');shutil.copyfile(delivery/'RECEPTION.json',dest/'reception.json')
index=dict(passed=True,whole_system_qualified=False,source_commit=audit['server_source'],canonical_physical_types='../block-delivery-r256-current363/index.json',graph_sha256='49ba0e348f3583f6facdf60e771fe6f1329b46fe5aac872c3828d4b61ddb1a68',instances=345,physical_types=23,internal_bound_bits=3226,initializations=3,program_invocations_each=18,cases_each=14,numerical_programs_each=8,checks_each=680884,cycles_each=217396,cpu_tensor_moves=0,negative_controls=6,archive=dict(path='actual-events.zip',bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),reception_sha256=sha((dest/'reception.json').read_bytes()),scope='Actual C/queue/task/completion/return handshake events in same final-cell zero-delay model; three independent initializations and complete independent protocol/payload replay. Not per-cycle waveform or full geometry/PG/three-RC300MHz qualification. Local newline-only replay correction is source-bound and recorded inside archive; simulation source1270 unchanged.')
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());(dest/'.gitattributes').write_bytes(b'* -text\n')
entries={}
for n in ['control162-proof78-remote.py','control162-checkpoint78.py','control162-internal1290.py','control162-internal1291.py','control162-internal1292.py','control162-audit1293.py','control162-live1294.py','control162-read1297.py','control162-read1298.py','control162-online1289-verified.json','control162-audit1287-executed.py','control162-audit1287-erratum.json','control162-profile1280-remote.py','control162-annotate1281.py','control162-annotate1282.py','control162-queue1284-remote.py','control162-audit1285-remote.py','control162-refill1286-remote.py','control162-admit1283.py']:
 p=h/n
 if p.is_file():entries[n]=p
for n in ['control162-live1294','control162-phase-progress1262','control162-phase-progress1288','control162-internal1292-repair']:
 p=h/n
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file()and f.stat().st_size<4000000:entries[f.relative_to(h).as_posix()]=f
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(files=meta,count=len(meta),archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Actual orchestration/snapshots and failed Windows newline bytes preserved; 1287 console label corrected by erratum, actual receipt is single node4. Metadata-only receiver failure1290 and newline-only local replay repair1292 do not change server simulation.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint78

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。承接[77](continuation-checkpoint-77.md)。

**完整组合仍未通过，任务继续，不合并。** 保留main六宏M/N/E/G/S/T、R256、S1350内部788驱动、23类型/138份单块六文件与345状态宿主。当前453图SHA `49ba0e348f3583f6facdf60e771fe6f1329b46fe5aac872c3828d4b61ddb1a68`、S5380位置、所有M1–M10及被动M11/M12边界不变；外部R修订及其他任务不动。规范宏交付仍见[current363](block-delivery-r256-current363/index.json)，状态归属见[current396](state-ownership-current396.json)/[453绑定](state-ownership-candidate453-binding.json)。

**1272三个初态的真实内部程序轨迹已实际完成并通过。** 冻结source1270 `46c5820b42bf552d82e4e2d1a0446f7ff2925c6c`（1024源，归档SHA `e34fb39f43595d9f7000c8ba4f739c74c0754076a7f771b75f40b87855d229be`）只重新编译观察bench并链接同一345实例/23类最终单元模型。3226位绑定当前图同一物理网的实际root成员；C_WORD、Q_CMD、Q_TASK、Q_COMPLETE、Q_DONE、C_DONE分别记录C接受的发射字、队列接受/组包后任务、适配器完成及返回/C接受完成。三个初态(1,162)/(2,162)/(2,163)均保留原680884检查、217396周期、8数值程序、14案例、18调用和CPU张量搬运0。逐包核C8指令字、任务载荷、标签/端点完成、返回及所有队列排空。每份完整内部JSONL1517533字节、SHA `3be8f1ff499c3e3f376b62012b7e3f7f040ace8e5ed1c45f4bfd8ad7305514bc`；外部过滤JSONL均与原473逐字一致，原480协议/已知读写payload证据保持。不是逐周期波形，也不是上层物理通过。

1292在接收端独立完整重放三份原始轨迹，并各破坏六种握手中的一项，六份完整破坏均被拒绝。1290接收器错误地要求顶层receipt直接列出dispatcher而停止，1291以冻结manifest/1273源审计另行绑定；随后Windows文本输出把本地一个外部过滤文件LF改为CRLF，SHA拒绝。1292先保存失败字节并从服务器恢复原件，再在自有本地scratch审计函数中仅加 `newline=''`；反向替换精确还原原函数、所有协议/载荷检查不变。服务器原始三态结果、源码、模型均未改动，无重跑仿真。两次接收端失败不解释为功能失败，修复也不掩盖原件。[完整轨迹/负控/来源归档索引](internal-program-events-current1272/index.json)已实收CRC/SHA核验，ZIP885077字节SHA `2d82990cc2dcb235f79ce6166c0c200595ca56fa3d7198bdc13abc88c64b5139`。

12840/12841仅复用已实现且有736/745实际回归的渐进双端窗口4/16，保持source1250、cutoff16/stride16/cost8/加法history/seed4662及9060 trial0真实暖前缀；无新增源/硬件/门变化。1285严格14份完整七阶段规格、六键验收及当前函数/事件绑定通过。1272自然结束后12840自动补位；1286仅核验替换本人6563/source653/95391.98子步骤，原始源/规格/所有失败及部分输出保留，未取消父任务。1287、1293分别实际核验node4/node2各16个路由进程及16对输入体/暖前缀、CLI、四个互不重叠16CPU掩码和内存准入，合计32个。1287控制台误把单节点结果标成two_nodes，执行原件和erratum保留；不能据此声称单份1287覆盖两节点，1293是独立node2证据。当前node2/node4预测256GiB、需323.2GiB可用，实核通过。8父节点36×16=576CPU，c64四槽/c96六槽动态补位不变。

1280对自有node4/95391的12561 trial0执行5秒99Hz用户CPU采样，495样本无丢失，settled函数74.55%、四叉pop22.22%、push3.23%；仅该进程该时间窗，不能推为全局收益。1281前缀符号annotate返回空原件保留，1282完整annotate76943字节；指令采样没有支持“除法为主要瓶颈”，未据此盲加缓存。1294只读35组当前候选实际日志尾：最小仍约613742冲突点，输出均非完整零冲突。11200等到63/64轮，12560/61和窗口4/16均未完成；不能从慢/非零推出全图不可行，也不能从小例或原生通过宣布系统通过。

[远程索引](continuation-proof-78/index.json)/[原字节ZIP](continuation-proof-78/selected-originals.zip)含{ix['copied_files']}项，SHA/CRC逐项验证；运行路由只收不可变读取前缀。[本地索引](continuation-proof-78/local-index.json)/[辅助ZIP](continuation-proof-78/local-helpers.zip)含{len(meta)}项执行/失败原件和只读报告。继续全图零冲突、真实M11/M12接入、最终几何/PG/low-base-high分布RC300MHz setup/hold/电气联合门及最终六文件、版图、源绑定交付；本检查点不结束任务。

规则rayggxia-project-collab1.0.0；project_id llm-hardware-design；本人YUZE-LU。管理结构检查PASS，不替代业务验收；登记management-hub PR5 pending；缺board.json，看板unverified/同步pending，管理员/审查人待指定；Issue in_progress、PR Draft/open/未合并。
'''
(base/'continuation-checkpoint-78.md').write_bytes(doc.encode())
summary=f'''# Issue162：真实内部程序三初态通过，完整组合布线继续

更新时间：{now}。[Checkpoint78](../work/YUZE-LU/162/continuation-checkpoint-78.md) / [源绑定索引](../work/YUZE-LU/162/continuation-proof-78/index.json) / [真实内部轨迹归档](../work/YUZE-LU/162/internal-program-events-current1272/index.json)。1272同一345实例/23类最终单元模型三初态全部实际通过680884检查、217396周期、8数值程序/14案例/18调用；3226位精确绑定C/八队列/任务/完成/返回。1292独立完整重放三份原轨迹、六份完整破坏均拒绝；外部事件与原473逐字一致。Windows接收端LF修复和dispatcher来源补绑定均记录，服务器仿真与源码不变；事件不是逐周期波形或系统物理通过。

12840/12841复用既有窗口4/16进入原完整七阶段，1285严格14份规格通过；1287/1293分别实际核验node4/node2共32进程/输入/前缀、各四组互斥16CPU与内存。8父节点36×16动态、c96六独立任务。**仍无完整零冲突全图及最终几何/PG/low-base-high分布RC300MHz联合通过。** 保留六宏/R256/S内部驱动/23类138文件/345状态宿主，外部R/其他任务不动；继续全部声明组合最终六文件/版图/真实M11/M12与源绑定，不放宽门、不合并。登记PR5 pending，看板unverified/同步pending，审查人待指定。

'''
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;old=p.read_text(encoding='utf-8');second=old.find('\n# ',1);assert second>0;p.write_bytes((summary.replace('../work/',prefix+'work/')+old[second+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8');old='新增内部观察1272已在同一最终单元模型编译链接并执行三个初态，3226位绑定当前图的实际C/八队列/适配器完成与返回握手；捕获时尚未完整执行通过。1278仅首个完整矩阵程序的5个任务包逐包/外部事件检查及六份破坏拒绝通过，不代替完整14案例/三初态或逐周期波形。';assert s.count(old)==1;s=s.replace(old,'新增内部观察1272已在同一最终单元模型完成三个初态，每态680884检查/217396周期/8数值程序/14案例/18调用通过；3226位绑定实际C/八队列/任务/适配器完成与返回，完整逐包重放及六份完整破坏拒绝通过。外部事件与原473逐字一致，接收端换行修复留有原字节及函数来源绑定，服务器仿真和源码未改。它是实际握手事件，不是逐周期波形或系统物理通过；完整归档见[内部轨迹索引](../work/YUZE-LU/162/internal-program-events-current1272/index.json)。');s=s.replace('当前接线绑定见[Checkpoint77源索引](../work/YUZE-LU/162/continuation-proof-77/index.json)','当前接线绑定见[Checkpoint78源索引](../work/YUZE-LU/162/continuation-proof-78/index.json)');s=s.replace('[本轮证据与限制](../work/YUZE-LU/162/continuation-checkpoint-77.md)','[本轮证据与限制](../work/YUZE-LU/162/continuation-checkpoint-78.md)');p.write_bytes(s.encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),completed_internal_initials=3,negative_controls=6,whole_system_qualified=False)))
