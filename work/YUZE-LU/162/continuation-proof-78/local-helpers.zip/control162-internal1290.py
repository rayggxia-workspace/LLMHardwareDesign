from pathlib import Path
import subprocess,shlex,json,hashlib,sys,time,zipfile
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';src=repo/'project/experiments/control_v1';sys.path.insert(0,str(src))
from internal_program_trace import audit
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=h/'LLMHardwareDesign-deliveries/issue-162/internal-program-events-1272';assert not out.exists()
q=r'''from pathlib import Path
import json,hashlib
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-internal-program-traces-1272';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();r=json.loads((root/'receipt.json').read_text());assert r['passed']and r['stage']=='actual-final-cell-internal-program-trace-only'and not r['whole_system_qualified']
cfg=json.loads((b/'config1272.json').read_text());old=Path(cfg['original_receipt']);assert sha(old)==cfg['original_receipt_sha256'];fr=json.loads(old.read_text());assert fr['passed']and fr['physical_instances']==345 and fr['actual_final_leaf_count']==23 and fr['real_program_count']==8
names=['receipt.json','instrumentation.json','internal-signal-bindings.json','test_system_events.cpp','trace-audit.json','compile.log','link.log'];pairs=[]
for mode,seed in [(1,162),(2,162),(2,163)]:
 n='initial-'+str(mode)+'-'+str(seed);names.extend([n+'.json',n+'.jsonl',n+'-audit.json',n+'-external-only.jsonl']);previous=b/'r256-padding-program-events-473'/(n+'.jsonl');current=root/(n+'-external-only.jsonl');pairs.append(dict(name=n,old_path=str(previous),current_path=str(current),old_sha256=sha(previous),current_sha256=sha(current),byte_exact=current.read_bytes()==previous.read_bytes()))
print(json.dumps(dict(passed=True,root=str(root),files={n:dict(bytes=(root/n).stat().st_size,sha256=sha(root/n))for n in names},old_function_receipt=dict(path=str(old),sha256=sha(old),initial_results=fr['initial_results']),external_replays=pairs,source_inputs=r['inputs'])))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);remote=json.loads(raw);out.mkdir(parents=True);(out/'REMOTE-RECEPTION.json').write_bytes(raw)
for name,row in remote['files'].items():
 target=out/name;subprocess.run(['scp','yuzelu@10.129.166.172:'+remote['root']+'/'+name,str(target)],check=True)
 assert target.stat().st_size==row['bytes']and sha(target)==row['sha256']
for name in ['internal_program_trace.py','program_event_trace.py','system_upper.py']:
 p=src/name;assert sha(p)==remote['source_inputs']['/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1270/project/experiments/control_v1/'+name]
results={}
for mode,seed in [(1,162),(2,162),(2,163)]:
 name='initial-'+str(mode)+'-'+str(seed);result=json.loads((out/(name+'.json')).read_text());assert result==remote['old_function_receipt']['initial_results'][name+'.json']and result['cycles']==217396
 r=audit(out/(name+'.jsonl'),result['cycles']);assert r['internal_dispatch_captured']and len(r['internal_programs'])==18
 assert sha(out/(name+'-external-only.jsonl'))==remote['files'][name+'-external-only.jsonl']['sha256'];results[name]=r
assert all(x['byte_exact']for x in remote['external_replays'])
original=[json.loads(x)for x in(out/'initial-1-162.jsonl').read_text().splitlines()];negative=out/'negative-controls';negative.mkdir();rejected=[]
for event,field in [('C_WORD','last'),('Q_CMD','endpoint'),('Q_TASK','words'),('Q_COMPLETE','words'),('Q_DONE','words'),('C_DONE','last')]:
 rows=json.loads(json.dumps(original));idx=next(i for i,r in enumerate(rows)if r['event']==event)
 if field=='words':rows[idx]['words'][0]^=1
 else:rows[idx][field]^=1
 target=negative/(event+'.jsonl');target.write_bytes(('\n'.join(json.dumps(r)for r in rows)+'\n').encode())
 try:audit(target,217396)
 except(AssertionError,IndexError,KeyError)as e:rejected.append(dict(event=event,error=type(e).__name__,path=str(target),sha256=sha(target),rejected=True))
 else:raise AssertionError(('Corrupt complete trace accepted',event))
r=dict(passed=True,time=time.time(),whole_system_qualified=False,stage='three-initial-real-internal-trajectories-and-independent-replay-only',server_source='46c5820b42bf552d82e4e2d1a0446f7ff2925c6c',results=results,negative_controls=rejected,external_traces_byteexact_to_473=True,remote_reception_sha256=sha(out/'REMOTE-RECEPTION.json'),inputs={str(src/n):sha(src/n)for n in ['internal_program_trace.py','program_event_trace.py']},scope='Actual same immutable345instance/23finalcell model, three complete original8numericalprograms/14cases/18invocations, original680884checks/217396cycles/CPU-tensor-moves0 preserved. Actual C-word/Q-cmd/assembled-task/adapter-complete/Q-return/C-accept data independently replayed; all three externalfiltered traces byteexact to actual473 and its passed480 protocol/knownpayload audit. Six real complete corrupted traces rejected. Event-only/zero-delay, not full upper geometry/PG/3RC300MHz qualification.')
(out/'INDEPENDENT-AUDIT.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
index={str(p.relative_to(out)).replace('\\','/'):dict(bytes=p.stat().st_size,sha256=sha(p))for p in out.rglob('*')if p.is_file()}
zip_path=out.parent/'internal-program-events-1272.zip';assert not zip_path.exists()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED)as z:
 for n in sorted(index):z.write(out/n,n)
with zipfile.ZipFile(zip_path)as z:
 assert z.testzip()is None and set(z.namelist())==set(index)
 for n,v in index.items():data=z.read(n);assert len(data)==v['bytes']and hashlib.sha256(data).hexdigest()==v['sha256']
(out/'RECEPTION.json').write_bytes((json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,files=index,archive=dict(path=str(zip_path),bytes=zip_path.stat().st_size,sha256=sha(zip_path)),scope='Actual source-bound internaltrajectories and six negativecontrols, independently replayed and CRC/SHA received. No systemphysicalqualification.'),indent=2)+'\n').encode())
print(json.dumps(dict(passed=True,local_files=len(index),ZIP_bytes=zip_path.stat().st_size,ZIP_sha256=sha(zip_path),initials=3,programs_each=18,negative_controls=len(rejected),all_three_external_traces_byte_exact=True)))
