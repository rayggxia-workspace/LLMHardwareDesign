"""Complete reception after1290 hit a missing dispatcher entry; no simulation rerun."""
from pathlib import Path
import subprocess,shlex,json,hashlib,sys,time,zipfile
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';src=repo/'project/experiments/control_v1';sys.path.insert(0,str(src))
from internal_program_trace import audit
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=h/'LLMHardwareDesign-deliveries/issue-162/internal-program-events-1272';remote=json.loads((out/'REMOTE-RECEPTION.json').read_text())
for name,row in remote['files'].items():assert(out/name).stat().st_size==row['bytes']and sha(out/name)==row['sha256']
for name in ['internal_program_trace.py','program_event_trace.py']:
 assert sha(src/name)==remote['source_inputs']['/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1270/project/experiments/control_v1/'+name]
q=r'''from pathlib import Path
import json,hashlib
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'source-1270';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();manifest=json.loads((root/'source-manifest.json').read_text());name='project/experiments/control_v1/system_upper.py';assert manifest['commit']=='46c5820b42bf552d82e4e2d1a0446f7ff2925c6c'and manifest['files'][name]==sha(root/name);audit=b/'r256-internal-trace-source-audit-1273/receipt.json';assert json.loads(audit.read_text())['passed'];freeze=json.loads((root/'freeze-import.json').read_text());assert freeze['archive_sha256']=='e34fb39f43595d9f7000c8ba4f739c74c0754076a7f771b75f40b87855d229be';print(json.dumps(dict(passed=True,commit=manifest['commit'],dispatcher=str(root/name),dispatcher_sha256=manifest['files'][name],manifest_sha256=sha(root/'source-manifest.json'),source_audit_sha256=sha(audit),archive_sha256=freeze['archive_sha256'],scope='Dispatcher not directly listed in1272trace receipt inputs; exact frozen manifest and passed1273source audit separately bind it. All19receivedoriginals rechecked;1290missing-key failure retained, no simulation rerun.')))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);binding=json.loads(raw);assert sha(src/'system_upper.py')==binding['dispatcher_sha256'];(out/'DISPATCHER-SOURCE-BINDING.json').write_bytes(raw)
original=(h/'control162-internal1290.py').read_text(encoding='utf-8');tail=original[original.index('results={}'):];exec(compile(tail,'1290-reception-and-replay-tail','exec'))
