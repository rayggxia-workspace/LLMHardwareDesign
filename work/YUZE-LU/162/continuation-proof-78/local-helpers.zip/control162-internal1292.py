"""Preserve LF during local replay; source1270 simulation remains unchanged."""
from pathlib import Path
import subprocess,json,hashlib,sys,time,zipfile,inspect
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';src=repo/'project/experiments/control_v1';sys.path.insert(0,str(src))
import internal_program_trace as observer
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=h/'LLMHardwareDesign-deliveries/issue-162/internal-program-events-1272';remote=json.loads((out/'REMOTE-RECEPTION.json').read_text());repair=h/'control162-internal1292-repair';repair.mkdir();repaired=[]
for name,row in remote['files'].items():
 target=out/name
 if target.stat().st_size!=row['bytes']or sha(target)!=row['sha256']:
  assert name.endswith('-external-only.jsonl')
  (repair/name).write_bytes(target.read_bytes());before=sha(target)
  subprocess.run(['scp','yuzelu@10.129.166.172:'+remote['root']+'/'+name,str(target)],check=True)
  repaired.append(dict(name=name,prior_sha256=before,restored_sha256=sha(target),prior_copy=str(repair/name)))
 assert target.stat().st_size==row['bytes']and sha(target)==row['sha256']
for name in ['internal_program_trace.py','program_event_trace.py']:
 assert sha(src/name)==remote['source_inputs']['/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1270/project/experiments/control_v1/'+name]
binding=json.loads((out/'DISPATCHER-SOURCE-BINDING.json').read_text());assert sha(src/'system_upper.py')==binding['dispatcher_sha256']
original=inspect.getsource(observer.audit);needle="with filtered.open('w')as ext:";assert original.count(needle)==1
corrected=original.replace(needle,"with filtered.open('w',newline='')as ext:")
assert corrected.replace("with filtered.open('w',newline='')as ext:",needle)==original
ns=dict(observer.__dict__);exec(compile(corrected,'newline-only-local-observer','exec'),ns);audit=ns['audit']
patch=dict(original_function_sha256=hashlib.sha256(original.encode()).hexdigest(),executed_function_sha256=hashlib.sha256(corrected.encode()).hexdigest(),only_change="filtered.open('w') -> filtered.open('w',newline='')",semantic_checks_unchanged=True,repaired_originals=repaired,scope='1290missingdispatcherentry handled by1291separatefrozenmanifestbinding.1291localtextfilterchangedLFtoCRLF;restoreonlythatknownfilteredoriginalfromserverSHAandpreservefailedlocalbytes. Localobservernewline-onlychange emitsoriginalLF, allprotocol/task/payload/assertions unchanged, no simulation rerun or source1270mutation.')
(out/'LOCAL-REPLAY-NEWLINE-BINDING.json').write_bytes((json.dumps(patch,indent=2)+'\n').encode());(repair/'receipt.json').write_bytes((json.dumps(patch,indent=2)+'\n').encode())
original_tail=(h/'control162-internal1290.py').read_text(encoding='utf-8');tail=original_tail[original_tail.index('results={}'):]
needle="inputs={str(src/n):sha(src/n)for n in ['internal_program_trace.py','program_event_trace.py']},scope=";assert tail.count(needle)==1
tail=tail.replace(needle,"inputs={**{str(src/n):sha(src/n)for n in ['internal_program_trace.py','program_event_trace.py']},str(Path(__file__)):sha(__file__)},local_newline_only_patch=patch,scope=")
exec(compile(tail,'1290-reception-tail-with-newline-binding','exec'))
