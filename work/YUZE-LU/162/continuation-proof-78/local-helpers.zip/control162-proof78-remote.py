from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-78';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.stat().st_size<4000000:add(f)
for name in ['r256-internal-program-traces-1272','r256-final-chain-binding-audit-1285','r256-settled-window-slot-admission-1283','r256-settled-window-node4-active-audit-1287','r256-settled-window-node2-active-audit-1293','r256-settled-hotspot-profile-1280','r256-settled-hotspot-annotate-1281','r256-settled-hotspot-annotate-1282']:
 shallow(b/name)
for name in ['r256-internal-program-traces-1272','r256-final-chain-binding-audit-1285','r256-settled-window-node4-active-audit-1287','r256-settled-window-node2-active-audit-1293']:
 assert json.loads((b/name/'receipt.json').read_text())['passed'],name
admission=json.loads((b/'r256-settled-window-slot-admission-1283/receipt.json').read_text());assert len(admission['rows'])==1 and len(admission['forecasts'])==4
profile=json.loads((b/'r256-settled-hotspot-profile-1280/receipt.json').read_text());assert profile['record_returncode']==profile['report_returncode']==0
for name in ['sready1284-settled-window-fullchains','sready1286-settled-window-refill']:shallow(b/'route-selection-102'/name)
for row in json.loads((b/'route-selection-102/sready1284-settled-window-fullchains/tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for tag in [1250,1270]:
 for name in ['source-manifest.json','freeze-import.json']:add(b/('source-'+str(tag))/name)
out.mkdir();live=out/'live-route-snapshots';live.mkdir();progress=[]
for tag in [11200,11201,11202,11203,11204,11205,11400,11401,11920,11921,12100,12101,12220,12221,12560,12561,12840,12841]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 if not p.exists():continue
 raw=p.read_bytes();target=live/(str(tag)+'-trial0.log');target.write_bytes(raw);add(target);records=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:records.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=tag,original=str(p),immutable_live_prefix=str(target),last_complete_global=next((r for r in reversed(records)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(records)if'routed'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)}
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
archive=out/'selected-originals.zip';index=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Completed source1270 actual three-initial internal traces and actual window1250 reuse/strict14bindings/owned slot refill, separate16process audits on node2 and node4, actual5second hotspot sample. Running routes are immutable read prefixes only; no full upper route or systemphysicalqualification. Local full independent three-trace replay and six mutations separately indexed on receiving host.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(passed=True,indexed=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
