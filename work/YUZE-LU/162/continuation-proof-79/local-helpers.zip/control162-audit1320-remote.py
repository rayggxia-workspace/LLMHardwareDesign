from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1270';new=b/'source-1318';out=b/'r256-settled-adaptive-source-audit-1320';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prefix='project/experiments/control_v1/'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='3966fd552b379b1ab6a2aa7806da848207c49913'and len(z['files'])==1025
changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={prefix+'system_upper.py',prefix+'settled_adaptive_regression.py'}
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']=='2f63b9ae78f9cdf5a95fcbe7a0250d8741930087cf7af289034f8b0aa9da43de'and all(sha(new/p)==v for p,v in z['files'].items())
assert sha(b/'source1318.tar.gz')=='2f63b9ae78f9cdf5a95fcbe7a0250d8741930087cf7af289034f8b0aa9da43de'
out.mkdir();scratch=out/'reverse-copies'
for n in ['system_upper.py','settled_adaptive_regression.py']:
 p=scratch/prefix/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/prefix/n).read_bytes())
patch=b/'control162-backout1318.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert(scratch/prefix/'system_upper.py').read_bytes()==(old/prefix/'system_upper.py').read_bytes()and not(scratch/prefix/'settled_adaptive_regression.py').exists()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1025,unchanged_files=1023,two_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only optional full small combination-regression helper/dispatcher and explicit weighted+settled adaptive frontend context. Core C++/wrapper/search/resource/RTL/all physical gates unchanged among1023sources. Fullmanifest/archiveSHA and scratch reverse copies checked. No source1318 fullphysical candidate permitted before actual combination regression; source1250 original failed unsupported13030/31 preserved, no acceptance gate relaxed.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1025,unchanged=1023)))
q=b/'dynamic-04/node25';state=json.loads((q/'queue-state.json').read_text());capture=[]
for name in state['active']:
 p=q/'pending'/(name+'.json');spec=json.loads(p.read_text());capture.append(dict(name=name,path=str(p),sha256=sha(p),spec=spec))
target=next(x for x in capture if x['name'].endswith('-10300'));p=b/'r256-settled-adaptive-slot-capture-1321';assert not p.exists();p.mkdir();(p/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=[target],all_active=capture,whole_system_qualified=False),indent=2));print(json.dumps(dict(target_source=target['spec']['source_root'],target=target['name'],forecast=[x['spec']['forecast_gib']for x in capture])))
