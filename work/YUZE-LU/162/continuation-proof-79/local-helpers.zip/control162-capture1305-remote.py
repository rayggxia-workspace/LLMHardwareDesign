from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[];forecasts=[]
for job,node,folder,target in [(95341,2,'dynamic-05/node2',9920),(95391,4,'dynamic-05/node4',9921)]:
 queue=b/folder;state=json.loads((queue/'queue-state.json').read_text());found=[]
 for name in state['active']:
  p=queue/'pending'/(name+'.json');raw=p.read_bytes();spec=json.loads(raw);forecasts.append(dict(node=node,name=name,forecast_gib=spec['forecast_gib']));a=spec['args']
  if '--out'in a and Path(a[a.index('--out')+1]).parent.name==str(target):found.append(dict(job=job,node=node,folder=folder,target=target,path=str(p),sha256=hashlib.sha256(raw).hexdigest(),spec=spec))
 assert len(found)==1;rows+=found
out=b/'r256-settled-adaptive-slot-capture-1305';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,forecasts=forecasts,whole_system_qualified=False),indent=2));print(json.dumps(dict(captured=len(rows),forecasts=forecasts)))
