from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-79';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-79/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 r=json.loads(z.read('r256-settled-adaptive-regression-1322/settled-adaptive/receipt.json'));assert r['passed']and len(r['cases'])==16 and sum(x['full_route']for x in r['cases'])==14 and len(r['rejected'])==2
 assert r['unchanged_default_byteexact']and r['one_round_failure_rejected']and len(r['covered'])==2
 chronology=json.loads(z.read('continuation-proof-79/combination-before-full-admission.json'));assert chronology['passed']and chronology['regression_finished']<=chronology['admission_file_mtime']and chronology['admission']['forecast_gib']==320
 for n in ['r256-settled-adaptive-source-audit-1320','r256-settled-adaptive-active-audit-1315','r256-settled-adaptive-c96-active-audit-1327','r256-final-chain-binding-audit-1325']:assert json.loads(z.read(n+'/receipt.json'))['passed']
entries={}
for p in h.glob('control162-*.py'):
 import re
 m=re.search(r'(\d+)(?:-remote)?\.py$',p.name)
 if m and 1293<=int(m.group(1))<=1328 and p.stat().st_size<4000000:entries[p.name]=p
for n in ['control162-checkpoint79.py','control162-proof79-remote.py','control162-verify79.py','control162-online1308-verified.json','control162-backout1318.patch']:
 p=h/n
 if p.is_file():entries[n]=p
for n in ['control162-read1310','control162-read1314','control162-read1326','control162-phase-progress1316','control162-phase-progress1328','control162-live1228']:
 p=h/n
 if p.is_dir():
  for f in p.glob('*.json'):
   if f.stat().st_size<4000000:entries[f.relative_to(h).as_posix()]=f
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Actual orchestration/raw metadata and observed failed unsupported13030/31 retained. A PowerShell-only quote/parser error while generating1323 did not execute remote work; the file-based generator was then used. live1228 briefly rejected the32+2-slot transition before1313 released dependencies; later actual36active and32process/mask proofs saved. No failed or live prefix counted as final physical pass.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds');covered=[dict(cost=x['cost'],seeds=x['seeds'])for x in r['covered']]
doc=f'''# Issue162 continuation checkpoint79

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。承接[78](continuation-checkpoint-78.md)。**完整组合尚未通过，任务继续，不合并。** 保留M/N/E/G/S/T六宏、R256、S1350内部驱动、23类型/138份单块六文件、345状态宿主、当前453图及S5380位置。所有M1–M10固定宏、M11/M12被动边界和最终物理门不变；外部R和其他任务不动。[规范六文件](block-delivery-r256-current363/index.json)/[状态归属](state-ownership-current396.json)/[已完成三初态真实内部轨迹](internal-program-events-current1272/index.json)继续有效，均不授予系统物理资格。

13030/13031编排错误已保留：source1250旧入口明确禁止adaptive与bidirectional组合，我漏查了该限制，实际两任务在原前端assertion拒绝、returncode1，未创建物理输出。1304只证明七阶段/六键/函数路径绑定正确，**不证明选项组合可运行**。没有改旧源或绕过旧assertion重跑。13120/13121立即在原空出的两个16CPU槽使用已支持的方向代价2/32，adaptive关闭，其余保持原12561参数；1313严格14规格和1315真实32进程/输入/9060前缀/两节点各四个互斥16CPU/实际内存通过。短暂槽位切换时live1228精确36断言拒绝，后续完整36恢复及实际进程证据保存；不把控制器状态当CPU亲和证据。

source1318 `3966fd552b379b1ab6a2aa7806da848207c49913`（1025源；归档SHA `2f63b9ae78f9cdf5a95fcbe7a0250d8741930087cf7af289034f8b0aa9da43de`）只增加组合回归助手/分派，并明确允许weighted+settled的adaptive前端上下文。原非双向adaptive模式保留，普通双向或只有weighted仍拒绝。1320逐SHA核全部1025源和归档；自有scratch逆补丁精确恢复原system_upper并删除新增助手，1023文件未变，包含整个C++搜索器、wrapper、精确/有限求解、RTL和全部几何/PG/三RC300MHz验收源。**扩展工具选项组合，物理验收门没有放宽。** 原source1250不改写，旧失败原件不伪装成新源通过。

1322已在node25/95204原16CPU槽实际完成。默认完整40×40小图相对1252既有settled-16-972的主路径、native日志/路径、主日志逐字相同。16个cost2/8×seed971–978独立任务在16CPU掩码内并行，14个完整零冲突、2个80轮未收敛；失败原件保留且无最终输出。两种代价均要求真实跨dense16、实际使用settled分支、高冲突adaptive256覆盖及第八轮周期的原退火探测，再独立核单位边、checkerboard via、完整树、有限线预算和跨网零占用；合格覆盖为 `{covered}`。两个不支持的真实CLI上下文仍在输出创建前拒绝，真实只一轮全图有冲突也必须失败。小图及源验证不授予真实系统资格。

13240仅在1322实际通过后，复用同一原c96槽自然补位。保持12561的cost8/cutoff16/stride16/加法history/seed4662/9060 trial0暖前缀，仅启用已有C++自适应日程；1325严格7规格/六键、当前453函数/完成内部轨迹前置以及各自几何/PG/low-base-high/交付路径通过。1327实核16个实际source1318进程、16对实际输入体/前缀与adaptive1 header、node25六组16CPU掩码两两互斥、实际内存320GiB预测/400GiB门。[实际完成先于新准入的时间证据](continuation-proof-79/index.json)绑定1322完成与13240 command文件mtime/SHA，不提前发射新组合。

1323只在新核1321原规格SHA、UID10011/job/实际node25/PID/完整cmd/source1013/out/453图/全部原始日志/无最终后，替换本人10300/95204.219子步骤，用于组合回归；预测272GiB需342.4GiB实际可用，通过后执行。原源/规格/全部失败与部分输出保留；原5400/6562/7581/10301/11204五槽、所有其他对照、父分配、CUGR3751、外部R及他人任务不动。1322结束后13240实际400GiB门通过，仍8父节点36×16=576CPU动态、c64四槽/c96六槽，不降并发。

当前13120/21已跨16轮，12560/61及窗口4/16、11200等继续；13240仍是未完成的全图候选。没有完整零冲突、真实M11/M12几何/PG、low/base/high分布RC300MHz setup/hold/电气联合通过；继续定位迭代及最终六文件/版图/源绑定交付，不借单块、轨迹、小图、前缀宣布系统通过。

[远程索引](continuation-proof-79/index.json)/[原字节ZIP](continuation-proof-79/selected-originals.zip)含{ix['copied_files']}项，实际SHA/CRC逐一通过；运行路由只收不可变读取前缀。[本地索引](continuation-proof-79/local-index.json)/[辅助ZIP](continuation-proof-79/local-helpers.zip)含{len(meta)}项编排与实际读取原件。提交另核实际Git blobs/ZIP条目。管理结构检查PASS；规则rayggxia-project-collab1.0.0、project_id llm-hardware-design、本人YUZE-LU。登记management-hub PR5 pending；缺board.json，看板unverified/同步pending，管理员/审查人待指定；Issue in_progress、PR Draft/open/未合并。
''';(base/'continuation-checkpoint-79.md').write_bytes(doc.encode())
summary=f'''# Issue162：搜索组合实际回归通过，完整物理候选继续

更新时间：{now}。[Checkpoint79](../work/YUZE-LU/162/continuation-checkpoint-79.md) / [源绑定索引](../work/YUZE-LU/162/continuation-proof-79/index.json)。13030/31因旧入口不支持选项组合而在布线前拒绝，原件保留；有效代价2/32候选13120/21已实际启动，1315真实32进程/输入/前缀/CPU掩码和内存通过。source1318只扩展weighted+settled的adaptive工具上下文并加回归，1023原文件含C++/wrapper/RTL/全部物理门未变，1320全部1025源/归档/自有scratch逆补丁通过。

1322实际16独立小图尝试中14个完整零冲突，两种代价均覆盖dense切换、自适应覆盖/周期原探测与独立路径/预算检查；两份未收敛原件、默认路径/日志逐字回放、两个CLI拒绝及真实一轮失败保留。13240在其实际通过后于原c96槽自然补位；1325严格7规格，1327实际16进程/输入/暖前缀/node25六组互斥16CPU、320GiB预测/400GiB实际内存门与先后时间绑定通过。

**仍无完整零冲突全图及最终几何/PG/low-base-high分布RC300MHz联合通过。** 保留六宏/R256/S内部驱动/23类138文件/345状态宿主；[完整三初态真实内部轨迹](../work/YUZE-LU/162/internal-program-events-current1272/index.json)保持，不代替物理结果。8父节点36×16动态、c96六独立任务，外部R/其他任务不动，继续全部声明组合最终六文件/版图/M11/M12与源绑定，不放宽门、不合并。登记PR5 pending，看板unverified/同步pending，审查人待指定。

'''
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;p.write_bytes((summary.replace('../work/',prefix+'work/')+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint78源索引](../work/YUZE-LU/162/continuation-proof-78/index.json)','Checkpoint79源索引](../work/YUZE-LU/162/continuation-proof-79/index.json)').replace('[本轮证据与限制](../work/YUZE-LU/162/continuation-checkpoint-78.md)','[本轮证据与限制](../work/YUZE-LU/162/continuation-checkpoint-79.md)');needle='本轮追加可选的普通候选搜索切换轮次8/16/32';at=s.index(needle);s=s[:at]+'source1318已加入weighted+settled的adaptive工具上下文；1322实际组合回归通过后才启动13240完整物理链，1327核验node25真实六组互斥16CPU。13030/31在旧源的非法上下文失败原件保留，13120/21是原源支持的代价2/32对照。C++/RTL/全部物理门不变，所有新全图结果仍未验收；见[Checkpoint79](../work/YUZE-LU/162/continuation-checkpoint-79.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');s='''# Issue162：已验证的搜索组合入口与未完成物理验收

当前仍为453接线/345实例/23类型，含R256和S内部驱动；上层系统物理资格未获得。完整证据与限制见[Checkpoint79](../work/YUZE-LU/162/continuation-checkpoint-79.md)，实际三初态内部握手轨迹见[索引](../work/YUZE-LU/162/internal-program-events-current1272/index.json)。下文旧阶段记录保留，不能覆盖当前入口或冒充系统已验收。

在分配的16CPU Slurm/ORFS容器中，冻结source1318后运行 `python3 <source>/project/experiments/control_v1/system_upper.py --manifest <selected/physical.json> --graph <453/topology/boundary-graph.json> --settled-adaptive-regression-config <config1322.json> --out <新目录>`，复用原已绑定40×40暖前缀、1252默认路线和source1250核心。实际1322完成16独立代价/种子任务；两种代价必须实际覆盖dense16、自适应高权重、周期原退火及独立最终零冲突/单位边/via/连通/线预算，另保留默认字节回放、真实一轮失败与非法CLI拒绝。新helper的源码和配置SHA见证据索引，不可指向修改后的既有结果。该入口只验证软件选项组合，不产生真实系统资格。

实际全图13240在上述回归通过后，使用原完整七阶段、独立真实几何/PG/low-base-high分布RC300MHz setup/hold/电气/交付门；所有M1–M10固定宏与被动M11/M12边界不变，原C++/wrapper/RTL/全部物理验收源未改。c96节点保持6×16独立任务动态补位；原控制与失败原件保留，不自行合并。

'''+s;p.write_bytes(s.encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),full_small_zero=14,full_small_failed=2,covered=covered,whole_system_qualified=False)))
