from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import json,time,collections
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [9920,11202,12560,12840,6561,10711,11201,12100,9921,11203,12561,12841,10430,11400,11920,12220,10710,10900,11200,12101,11401,11921,12221,5400,6562,7581,10300,10301,11204,5494,5495,7920,7921,10302,11205]:
 root=b/'r256-composition-453/upper-candidates'/str(tag);trials=[]
 for p in sorted((root/'route').glob('trial-*/router.log')):
  with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-524288));lines=f.read().decode(errors='replace').splitlines()
  records=[]
  for l in lines:
   if l.startswith('{'):
    try:records.append(json.loads(l))
    except ValueError:pass
  trials.append(dict(trial=p.parent.name,log=str(p),size=size,mtime=p.stat().st_mtime,last_global=next((r for r in reversed(records)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(records)if'routed'in r),None),last_line=lines[-1]if lines else None,complete_output=(p.parent/'output.txt').is_file()))
 rows.append(dict(candidate=tag,trials=trials,route_receipt=(root/'route/route-proof.json').exists(),final_receipt=(root/'acceptance/receipt.json').exists()))
print(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False,scope='Bounded actual-owned log tails only, not independent route validation.')))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-live1294';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw)
for row in json.loads(raw)['rows']:
 ts=row['trials'];gs=[t['last_global']for t in ts if t['last_global']];print(json.dumps(dict(candidate=row['candidate'],trials=len(ts),last_conflict_min=min((g['conflict_nodes']for g in gs),default=None),round_range=[min(g['round']for g in gs),max(g['round']for g in gs)]if gs else None,complete_outputs=sum(t['complete_output']for t in ts),failure_lines=list({t['last_line']for t in ts if t['last_line']and not t['last_line'].startswith('{')})[:2])))
