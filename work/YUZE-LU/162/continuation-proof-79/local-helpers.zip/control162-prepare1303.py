from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-queue1284-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1284-settled-window-fullchains','sready1303-settled-adaptive-fullchains').replace('r256-final-chain-binding-audit-1285','r256-final-chain-binding-audit-1304')
s=s.replace("b/'r256-pair-window-regression-736/receipt.json',b/'r256-pair-window-source-and-regression-audit-745/receipt.json'","b/'router-adaptive-regression-287/receipt.json',b/'r256-high-weight-regression-475/receipt.json'")
s=s.replace("[(12840,4,'dynamic-05/node2'),(12841,16,'dynamic-05/node4')]","[(13030,8,'dynamic-05/node2'),(13031,2,'dynamic-05/node4')]")
old="a+=['--route-weighted-pair-margin',str(margin)]";assert s.count(old)==1;s=s.replace(old,"assert '--route-adaptive-heuristic'not in a;a+=['--route-adaptive-heuristic'];a[a.index('--route-nonpreferred-cost')+1]=str(margin)")
s=s.replace(".replace('sready1256','sready1284')",".replace('sready1256','sready1303')")
start=s.index("scope='");end=s.index("'),indent=2)",start)
s=s[:start]+"scope='Reuseoriginaladaptivehighweight scheduler and source1250settledordinarycandidate;actual287/475scheduler and1252settledcomponent regressions/1251sourceaudit required,all1023frozen sourceSHA/archiveverified.13030cost8/node2 and13031cost2/node4, bothcutoff16/stride16/cong1/additivehistory/seed4662/9060trial0 warm/current453S5380. Onlyexistingadaptivescheduleflagandcostparameterchange,no newsourceorhardwareorphysicalgate. No separatefullsyntheticadaptive-plus-settledcrossproductregressionclaimed; theseareactualfullintegrationcandidates andmust independentlycompletealloriginalzero/geometryPG3RC300MHzgates. Eachonlyafterfreshspecificoldown9920/9921source972replacementguard, preserveallrawandcontrols/parents/foreign/externalR.8parents36x16/c96sixslots.'"+s[end+1:]
s=s.replace('candidates=[12840,12841]','candidates=[13030,13031]');compile(s,'queue1303','exec');(h/'control162-queue1303-remote.py').write_bytes(s.encode())
s=(h/'control162-audit1257-remote.py').read_text(encoding='utf-8').replace('r256-final-chain-binding-audit-1257','r256-final-chain-binding-audit-1304').replace('sready1256-settled-fullchains','sready1303-settled-adaptive-fullchains').replace('[12560,12561]','[13030,13031]')
s=s.replace("('8'if seed==12560 else'16')","'16'").replace("assert route['args'][route['args'].index('--route-nonpreferred-cost')+1]=='8'","assert route['args'][route['args'].index('--route-nonpreferred-cost')+1]==str({13030:8,13031:2}[seed]);assert '--route-adaptive-heuristic'in route['args'];assert '--route-weighted-pair-margin'not in route['args'];assert str(b/'router-adaptive-regression-287/receipt.json')in route['requires'];assert str(b/'r256-high-weight-regression-475/receipt.json')in route['requires']")
s=s.replace('candidates12560/12561','adaptivecandidates13030/13031');compile(s,'audit1304','exec');(h/'control162-audit1304-remote.py').write_bytes(s.encode())
s=(h/'control162-admit1283.py').read_text(encoding='utf-8')
a=s.index("q=r'''");z=s.index("'''",a+6);q=s[a+6:z]
q=q.replace("queue=b/'dynamic-05/node4';state=","allrows=[]\nfor job,node,folder,target in [(95341,2,'dynamic-05/node2',9920),(95391,4,'dynamic-05/node4',9921)]:\n queue=b/folder;state=")
# Generate a clearer standalone capture rather than reindent an executed helper.
q="""from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[];forecasts=[]
for job,node,folder,target in [(95341,2,'dynamic-05/node2',9920),(95391,4,'dynamic-05/node4',9921)]:
 queue=b/folder;state=json.loads((queue/'queue-state.json').read_text());found=[]
 for name in state['active']:
  p=queue/'pending'/(name+'.json');raw=p.read_bytes();spec=json.loads(raw);forecasts.append(dict(node=node,name=name,forecast_gib=spec['forecast_gib']));a=spec['args']
  if '--out'in a and Path(a[a.index('--out')+1]).parent.name==str(target):found.append(dict(job=job,node=node,folder=folder,target=target,path=str(p),sha256=hashlib.sha256(raw).hexdigest(),spec=spec))
 assert len(found)==1;rows+=found
out=b/'r256-settled-adaptive-slot-capture-1305';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,forecasts=forecasts,whole_system_qualified=False),indent=2));print(json.dumps(dict(captured=len(rows),forecasts=forecasts)))
"""
(h/'control162-capture1305-remote.py').write_bytes(q.encode())
s=(h/'control162-refill1286-remote.py').read_text(encoding='utf-8').replace('sready1286-settled-window-refill','sready1306-settled-adaptive-refill').replace('sready1284-settled-window-fullchains','sready1303-settled-adaptive-fullchains').replace('r256-final-chain-binding-audit-1285','r256-final-chain-binding-audit-1304').replace('r256-settled-window-slot-admission-1283','r256-settled-adaptive-slot-capture-1305')
s=s.replace("[(4,95391,'dynamic-05/node4',6563,'source-653',0,256,323.2)]","[(2,95341,'dynamic-05/node2',9920,'source-972',0,256,323.2),(4,95391,'dynamic-05/node4',9921,'source-972',0,256,323.2)]")
start=s.index("reason='");end=s.index("')\n",start)
s=s[:start]+"reason='Onlyfreshspecificown9920or9921/source972partial routes replaced afterspecSHA/UID10011/job/actualnode/PID/cmd/source/out/current453/alllogs/no final/winner andactual323.2GiBmemoryguard. New13030/13031reuseexisting source1250adaptiveflag/cost8or2/cutoff16/settle,strict14bindings andallcomponentregressionspassed. No separateadaptive-plus-settle smallcrossproductclaimed,no performanceorfullsystempass. Preservealloldraw/currentcontrols/parents/CUGR3751/foreign/externalR;8parents36x16/c96sixslots'"+s[end+1:]
compile(s,'refill1306','exec');(h/'control162-refill1306-remote.py').write_bytes(s.encode())
print('Prepared two existing-component physical chains, strict binding audit and exact-own replacement guards')
