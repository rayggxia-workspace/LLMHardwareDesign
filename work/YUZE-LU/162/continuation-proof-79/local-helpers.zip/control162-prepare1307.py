from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1261.py').read_text(encoding='utf-8').replace('r256-weighted-settle-active-audit-1261','r256-settled-adaptive-active-audit-1307').replace('12560','13030').replace('12561','13031')
s=s.replace('{13030:8,13031:8}','{13030:8,13031:2}').replace('{13030:8,13031:16}','{13030:16,13031:16}').replace('[6560,9920,11202,13030]','[12840,12560,11202,13030]').replace('[6563,9921,11203,13031]','[12841,12561,11203,13031]')
needle="assert int(p.read_text().splitlines()[0].split()[11])==0;";assert s.count(needle)==1;s=s.replace(needle,needle+"assert int(p.read_text().splitlines()[0].split()[14])==1;")
start=s.index("scope='");end=s.index("')\n",start)
s=s[:start]+"scope='Actual32owned source1250settledadaptivechildren13030/13031;32actualinputbodies/importedprefixesmatch9060trial0, headeradaptive1/cost8or2/additivehistory/stride16/cutoff16. ActualCLI/coarseschedule/zero/multicast/static/access flags andonlyfirsttrialsnapshot verified. Actualnode2/node4four16CPUmaskseachpairwisedisjoint;actualcontrolleradmissionschecked. No requirementorclaimall32alreadycrossedtransition;no separateadaptiveplussettledsyntheticcrossproductclaimed;thisisactualfullintegrationsearchonly.8parents36x16/c96sixslots,allphysical/nativefinite/M1-M10/finalgeometryPG3RC300MHzgates unchanged;no final/systempass'"+s[end+1:]
compile(s,'audit1307','exec');(h/'control162-audit1307.py').write_bytes(s.encode())
s=(h/'control162-phase-progress1288.py').read_text(encoding='utf-8').replace('[12840,12841]','[13030,13031]').replace('control162-phase-progress1288','control162-phase-progress1309');compile(s,'progress1309','exec');(h/'control162-phase-progress1309.py').write_bytes(s.encode())
print('Prepared actual32child audit and bounded phase progress')
