from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-audit1315.py').read_text(encoding='utf-8')
s=s.replace('r256-settled-adaptive-active-audit-1315','r256-settled-adaptive-c96-active-audit-1327').replace('for seed in [13120,13121]:','for seed in [13240]:').replace('{13120:2,13121:32}','{13240:8}').replace('{13120:16,13121:16}','{13240:16}').replace('split()[14])==0','split()[14])==1')
old="[(95341,2,'dynamic-05/node2',[13120],[12840,12560,11202,13120]),(95391,4,'dynamic-05/node4',[13121],[12841,12561,11203,13121])]";assert s.count(old)==1;s=s.replace(old,"[(95204,25,'dynamic-04/node25',[13240],[5400,6562,7581,10301,11204,13240])]")
s=s.replace('new_owned_children=32','new_owned_children=16').replace('observed16cpu_masks_disjoint_two_nodes=True','observed_six16cpu_masks_disjoint_single_c96_node25=True')
a=s.index("scope='");z=s.index("')\n",a);s=s[:a]+"scope='Actual16owned source1318qualifiedadaptivechildren13240;16actualinputbodies/importedprefixesmatch9060trial0,headeradaptive1/cost8/additivehistory/stride16/cutoff16. ActualCLI/schedule/zero/multicast/static/access/onlyfirstsnapshot andnode25six16CPUmaskspairwisedisjoint plusactualfuture320GiB/400GiBcontrolleradmissionchecked.1322actualcombinationregressioncompletedBEFOREnewcandidateadmission;1325strict7bindings. No all16crossedtransitionorfuturezero/geometryPG3RC300MHzclaim;allM1-M10/nativefinite/finalphysicalgatesunchanged.8parents36x16/c96sixslots.'"+s[z+1:]
# Refuse before creating the receipt directory when any first global round is incomplete.
needle=";r=dict(passed=False,whole_system_qualified=False,time=time.time(),comparisons=[],pools=[]);out.mkdir()";assert s.count(needle)==1
pre=""";r=dict(passed=False,whole_system_qualified=False,time=time.time(),comparisons=[],pools=[])
for i in range(16):
 p=root/'13240/route'/('trial-'+str(i))/'router.log';assert p.exists()
 ts=[json.loads(l)for l in p.read_text().splitlines()if l.startswith('{')and 'coarse_zero_hits'in l];assert any(t['coarse_zero_attempts']>0 for t in ts),'First global round still incomplete'
assert json.loads((b/'r256-settled-adaptive-regression-1322/receipt.json').read_text())['passed']
out.mkdir()"""
s=s.replace(needle,pre);compile(s,'audit1327','exec');(h/'control162-audit1327.py').write_bytes(s.encode())
s=(h/'control162-phase-progress1288.py').read_text(encoding='utf-8').replace('[12840,12841]','[13240]').replace('control162-phase-progress1288','control162-phase-progress1328');compile(s,'progress1328','exec');(h/'control162-phase-progress1328.py').write_bytes(s.encode())
print('Prepared actual c96 six-mask audit and phase progress')
