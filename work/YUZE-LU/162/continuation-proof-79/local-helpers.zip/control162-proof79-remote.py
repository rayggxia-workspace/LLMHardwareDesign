from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-79';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','test']and f.stat().st_size<4000000:add(f)
for n in ['r256-final-chain-binding-audit-1304','r256-final-chain-binding-audit-1313','r256-settled-adaptive-active-audit-1315','r256-settled-adaptive-source-audit-1320','r256-settled-adaptive-regression-1322','r256-final-chain-binding-audit-1325','r256-settled-adaptive-c96-active-audit-1327']:
 assert json.loads((b/n/'receipt.json').read_text())['passed'];shallow(b/n)
for n in ['r256-settled-adaptive-slot-capture-1305','r256-settled-adaptive-slot-capture-1321']:shallow(b/n)
root=b/'r256-settled-adaptive-regression-1322/settled-adaptive';r=json.loads((root/'receipt.json').read_text());assert r['passed']and len(r['cases'])==16 and sum(v['full_route']for v in r['cases'])==14 and len(r['rejected'])==2;shallow(root)
for p in root.iterdir():
 if p.is_dir():shallow(p)
for n in ['sready1303-settled-adaptive-fullchains','sready1306-settled-adaptive-refill','sready1312-settled-cost-fullchains','sready1322-settled-adaptive-regression','sready1323-settled-adaptive-regression-refill','sready1324-adaptive-qualified-fullchain']:
 p=b/'route-selection-102'/n;shallow(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for folder,tag in [('dynamic-05/node2',13030),('dynamic-05/node4',13031)]:
 q=b/folder;name='00-g-sready1303-r256-route-'+str(tag);log=q/(name+'.log');result=q/'results'/(name+'.json');assert 'not a.bidirectional_two_terminal'in log.read_text()and json.loads(result.read_text())['returncode']==1
 for p in [log,result,q/'commands'/(name+'.json')]:add(p)
 assert not(b/'r256-composition-453/upper-candidates'/str(tag)).exists(),'Rejected frontend unexpectedly created physical output'
for n in ['source-manifest.json','freeze-import.json']:add(b/'source-1318'/n)
for n in ['config1322.json','control162-backout1318.patch','control162-audit1320-remote.py']:add(b/n)
audit=json.loads((b/'r256-settled-adaptive-c96-active-audit-1327/receipt.json').read_text());admission=audit['actual_admissions'][0];assert admission['seed']==13240 and admission['admission']['forecast_gib']==320 and admission['admission']['required_bytes']==400*1024**3
command=Path(admission['path']);finished=json.loads((b/'dynamic-04/node25/results/00-a-sready1322-settled-adaptive-regression.json').read_text());assert finished['returncode']==0 and finished['finished']<=command.stat().st_mtime
out.mkdir();chronology=out/'combination-before-full-admission.json';chronology.write_text(json.dumps(dict(passed=True,regression_finished=finished['finished'],full_candidate_admission_file=str(command),admission_file_mtime=command.stat().st_mtime,admission_file_sha256=sha(command),admission=admission['admission'],whole_system_qualified=False),indent=2));add(chronology);add(command);add(b/'dynamic-04/node25/results/00-a-sready1322-settled-adaptive-regression.json')
live=out/'live-route-snapshots';live.mkdir();progress=[]
for tag in [11200,11201,11202,11203,11204,11205,11400,11401,12560,12561,12840,12841,13120,13121,13240]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 if not p.exists():continue
 raw=p.read_bytes();target=live/(str(tag)+'-trial0.log');target.write_bytes(raw);add(target);rs=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:rs.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=tag,original=str(p),immutable_live_prefix=str(target),last_complete_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(rs)if'routed'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)}
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
archive=out/'selected-originals.zip';ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Original unsupported13030/31frontend failures retained, valid13120/21 actual32process audit, newsource1318 all1025/archive/scratch audit, actual1322sixteen complete small attempts/fourteenzero/twofailed/twofrontendrejections/defaultbyteexact, strict7futurechain and actual13240singlec96sixmask audit. Newfullcandidate onlyafteractualcombinationregressionpassed. Running routes onlyimmutableliveprefixes;no wholephysicalqualification.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
