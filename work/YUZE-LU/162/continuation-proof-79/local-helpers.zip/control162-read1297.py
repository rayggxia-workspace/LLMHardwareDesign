from pathlib import Path
import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for n in ['r256-internal-program-traces-1272','r256-final-chain-binding-audit-1285','r256-settled-window-slot-admission-1283','r256-settled-window-node4-active-audit-1287','r256-settled-window-node2-active-audit-1293','r256-settled-hotspot-profile-1280']:
 d=json.loads((b/n/'receipt.json').read_text());print(n,list(d.keys()));print(json.dumps(d)[:3000]if n.endswith('1280')else d.get('passed'))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
