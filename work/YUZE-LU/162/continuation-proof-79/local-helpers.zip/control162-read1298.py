from pathlib import Path
import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-composition-453';a=b/'route-selection-102/sready1256-settled-fullchains/tasks.json';spec=next(v['spec']for v in json.loads(a.read_text())['tasks']if v['spec']['script']=='system_upper.py');print(json.dumps(spec,indent=2));print([(p.name,p.is_dir())for p in r.iterdir()]);print([(p.name,p.stat().st_size)for p in(r/'upper-candidates/12561').iterdir()]);
for n in ['r256-global-round-diagnostic-1080','r256-global-round-diagnostic-1070']:
 p=b/n/'receipt.json'
 if p.exists():print(n,json.loads(p.read_text()))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);(Path(__file__).parent/'control162-read1298.txt').write_bytes(raw);print(raw.decode()[:15000])
