from pathlib import Path
import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for n in ['r256-global-round-diagnostic-1076','r256-global-round-diagnostic-1085']:
 p=b/n/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print(n);print(json.dumps(d.get('diagnostic',d),indent=2)[:18000])
r=b/'r256-composition-453/cap-candidates/5380';print('placement files',[(p.name,p.stat().st_size)for p in r.iterdir()if p.is_file()])
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);(Path(__file__).parent/'control162-read1301.txt').write_bytes(raw);print(raw.decode())
