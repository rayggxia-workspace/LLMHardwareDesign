from pathlib import Path
import subprocess,shlex,json
h=Path(__file__).parent;out=h/'control162-placement1302';assert not out.exists();out.mkdir()
remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'
for name,path in [('placement.json','r256-composition-453/cap-candidates/5380/placement.json'),('physical-graph.json','r256-composition-453/cap-candidates/5380/physical-graph.json'),('diagnostic.json','r256-global-round-diagnostic-1085/global-snapshot/receipt.json')]:subprocess.run(['scp',remote+path,str(out/name)],check=True)
d=json.loads((out/'diagnostic.json').read_text());x=d['diagnostic'];print(json.dumps({k:v for k,v in x.items()if k not in ['top_nets','top_tiles']},indent=2));print('top nets',json.dumps(x['top_nets'][:8]));print('top tiles',x['top_tiles'][:6]);p=json.loads((out/'placement.json').read_text());print('placementkeys',list(p));print('placementpreview',str(p)[:2400])
