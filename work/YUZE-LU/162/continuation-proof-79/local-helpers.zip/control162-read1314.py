from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for folder in ['dynamic-05/node2','dynamic-05/node4']:
 queue=b/folder;d=json.loads((queue/'queue-state.json').read_text());r=dict(folder=folder,active=d['active'],finished={n:v for n,v in d['finished'].items()if 'sready1312'in n or n.endswith(('-9920','-9921'))},files=[])
 for p in queue.glob('*sready1312*.log'):
  with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-3000));tail=f.read().decode(errors='replace')
  r['files'].append(dict(path=str(p),bytes=size,tail=tail))
 for p in(queue/'commands').glob('*sready1312*.json'):
  c=json.loads(p.read_text());r.setdefault('admissions',[]).append(dict(path=str(p),admission=c.get('admission')))
 r['waiting']=[n for n in d['unfinished']if 'sready1312'in n];rows.append(r)
print(json.dumps(dict(time=time.time(),rows=rows)))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);out=Path(__file__).parent/'control162-read1314';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);print(raw.decode())
