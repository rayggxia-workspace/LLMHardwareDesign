from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-04/node25';d=json.loads((q/'queue-state.json').read_text());root=b/'r256-settled-adaptive-regression-1322';r=dict(time=time.time(),active=d['active'],finished={n:v for n,v in d['finished'].items()if'sready1322'in n},receipt=None,cases=[])
if(root/'receipt.json').exists():
 v=json.loads((root/'receipt.json').read_text());r['receipt']=dict(passed=v['passed'],stage=v.get('stage'))
for p in(root/'settled-adaptive').glob('cost-*/router.log'):
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-2500));tail=f.read().decode(errors='replace').splitlines()
 r['cases'].append(dict(case=p.parent.name,final=(p.parent/'router-output.txt').exists(),last_line=tail[-1]if tail else None))
p=q/'00-a-sready1322-settled-adaptive-regression.log'
if p.exists():
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-3000));r['tail']=f.read().decode(errors='replace')
r['job_details']=subprocess.check_output(['scontrol','show','job','95204','-o'],universal_newlines=True)
r['steps']=subprocess.check_output(['scontrol','show','step','95204','-o'],universal_newlines=True)
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);out=Path(__file__).parent/'control162-read1326';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);print(raw.decode())
