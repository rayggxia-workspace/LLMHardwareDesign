from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'r256-adaptive-weight-slot-capture-1334';assert not out.exists();rows=[];forecasts=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for job,node,folder,target in [(95204,25,'dynamic-04/node25',10301),(96222,24,'dynamic-06/node26',10302)]:
 q=b/folder;state=json.loads((q/'queue-state.json').read_text());found=[]
 for name in state['active']:
  p=q/'pending'/(name+'.json');s=json.loads(p.read_text());forecasts.append(dict(node=node,name=name,forecast=s['forecast_gib']));a=s['args']
  if '--out'in a and Path(a[a.index('--out')+1]).parent.name==str(target):found.append(dict(job=job,node=node,folder=folder,target=target,path=str(p),sha256=sha(p),spec=s))
 assert len(found)==1;rows+=found
out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,forecasts=forecasts,whole_system_qualified=False),indent=2));print(json.dumps(dict(captured=[dict(target=x['target'],source=x['spec']['source_root'])for x in rows],forecasts=forecasts)))
