from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-80';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-80/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 r=json.loads(z.read('r256-resource-front-regression-1344/resource-front/receipt.json'));assert r['passed']and len(r['cases'])==18 and sum(x['failed']for x in r['cases'])==3 and r['component']['identical_cap_failures']==454
 c=json.loads(z.read('continuation-proof-80/exact-replay-before-full-admission.json'));assert c['passed']and c['regression_finished']<=c['admission_file_mtime']
 f=json.loads(z.read('r256-resource-front-full-prefix-replay-1350/receipt.json'));assert f['passed']and f['complete_rounds_through']==7 and f['normalized_records']==3478
 assert not json.loads(z.read('r256-resource-front-and-adaptive-active-audit-1348/receipt.json'))['passed']
 a=json.loads(z.read('r256-resource-front-and-adaptive-active-audit-1349/receipt.json'));assert a['passed']and len(a['comparisons'])==48 and len(a['pools'])==2
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch)$',p.name)
  if m and 1330<=int(m.group(1))<=1350:entries[p.name]=p
for n in ['control162-checkpoint80.py','control162-proof80-remote.py','control162-verify80.py','control162-online1336-verified.json']:
 p=h/n
 if p.is_file():entries[n]=p
for n in ['control162-phase-progress1338','control162-live1228']:
 p=h/n
 if p.is_dir():
  for f in p.glob('*.json'):
   if f.stat().st_size<4000000:entries[f.relative_to(h).as_posix()]=f
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Actual owner-only orchestration, precise guards, profiling, regression and full-prefix evidence.1348 rejected premature first-round trace;1349 later passed same complete checks. PowerShell quoting avoided with file-based helpers. No failed/live prefix treated as final physical pass.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint80

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。承接[79](continuation-checkpoint-79.md)。**完整组合仍未通过，继续最终布局布线，不合并。** 六宏、R256、S1350内部驱动、23类型138文件、345状态宿主、453/S5380、M1–M10固定与M11/M12被动边界保留，外部R/其他任务不动。

原source1318的13320/13321为现有64/128初始权重对照，1333严格14规格、1334/1335两份source1013本人子步骤的UID/job/node/PID/命令/源/specSHA/全日志/无输出/400GiB内存门通过后替换，全部原件保留。不能把此前1322的256权重组合小图回归说成额外64/128交叉验证，完整候选仍独立受原最终门约束；当前高权重自适应并未改善早期冲突。

1337对本人95204/node25、13240 trial0进程作5秒99Hz采样，494样本、无丢失；约85.83%在ResourceSearch插入支配检查。源1340（commit `4ff5941060ec8048de6df9616730e453a33f3529`）仅摘除支配链中已失效标签，保留vector所有记录、ID、父路径、计数、堆顺序和8M生产上限；没有新增物理逻辑或搜索启发式。另加可选精确回放helper/入口。1342核对1026文件/归档SHA、1023不变项、三文件scratch逆补丁精确恢复原1318；原1322对旧核心SHA要求没有被放宽。

实际1344：2400组旧/新逐条路径/标签数量/报错相等，454份内存上限错误相等；旧/新各120次独立完整(vertex,wire)参考检查，共240。18份实际完整小图执行原路径及主/native日志逐字相等，其中15成功、原两份80轮未收敛与一轮失败共3份保留；成功者独立复核零冲突、单位边/via、全树连通和预算。测试是软件等价证据，不是完整系统通过或速度收益。

1343/1345只替换本人source735的7581子步骤95204.213，先核验specSHA、UID/job/node/PID/全命令/453/全部原日志/无输出与342.4GiB门，对272GiB预测准入；其旧结果不删除。1344结束后13460自然补入同一16CPU槽，保持原12561的非adaptive、cost8、cutoff16/stride16、4662/9060暖前缀，仅用等价搜索结构优化。1347严格核对7阶段、六键、345实例、当前函数及真实三档RC路径；原几何/PG/300MHz setup/hold/电气/交付门保留。已证明回归完成先于新全图准入。

1348在13460第一轮尚未完成时要求完整coarse记录，按原断言拒绝，原failed receipt保留；1349在首轮完成后原检查通过：真实48子进程/输入/前缀，64/128/256与adaptive1/1/0，两c96各六个互斥16CPU及实际内存准入。1350再核对真实453全图12561与13460第0–7轮3478条解析记录完全一致，仅忽略monotonic_ns；输入和native路径逐字一致。不推断后续收敛、性能或最终系统资格。

[远程184份原字节与索引](continuation-proof-80/index.json) / [本地编排索引](continuation-proof-80/local-index.json)。8父节点、36×16独立槽动态补位，c96六任务；无父节点/foreign/CUGR3751/外部R取消。**仍需完整零冲突M11/M12及实际几何/PG/low-base-high分布RC300MHz联合验收、组合最终六文件与版图。** 登记PR5 pending；缺board.json，看板unverified/同步pending；审查待指定。
'''
(base/'continuation-checkpoint-80.md').write_bytes(doc.encode())
summary=f'''# Issue162：有限线长搜索等价优化，完整物理验收继续

更新时间：{now}。[Checkpoint80](../work/YUZE-LU/162/continuation-checkpoint-80.md) / [源绑定索引](../work/YUZE-LU/162/continuation-proof-80/index.json)。本人进程实际494样本定位85.83%支配插入热点；source1340仅摘除失效查找链，1026源/1023不变/归档/精确回退通过，所有物理门与RTL保留。1344实际2400旧新路径/标签/报错（454上限拒绝）一致、240独立参考检查、18完整小图原路径/日志逐字相等，原3失败保留。

13460在真实回归通过后自然补位，非adaptive/cost8/cutoff16/当前453/S5380，7阶段与六键严格绑定。1349真实48子进程/输入/前缀及两c96各六个互斥16CPU通过；1348首轮未完导致的检查拒绝原件保留。1350真实全图第0–7轮3478记录除monotonic_ns外完全一致，不推断性能或最终通过。

**仍无完整零冲突全图及几何/PG/三档分布RC300MHz联合通过，任务继续，不合并。** 六宏/R256/S内部驱动/23类138文件/345状态宿主保留，外部R/其他任务不动。8父节点36×16动态、c96六独立任务；继续声明组合最终六文件/版图/M11/M12/源绑定。登记PR5 pending，看板unverified/同步pending，审查人待指定。

'''
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;p.write_bytes((summary.replace('../work/',prefix+'work/')+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8');s=s.replace('Checkpoint79源索引](../work/YUZE-LU/162/continuation-proof-79/index.json)','Checkpoint80源索引](../work/YUZE-LU/162/continuation-proof-80/index.json)');needle='本轮追加可选的普通候选搜索切换轮次8/16/32';at=s.index(needle);s=s[:at]+'source1340只优化有限线长标签支配查找，保留所有标签/父路径/计数/上限/顺序，1344实际2400旧新检查、240参考与18完整小图逐字回放通过后启动13460。真实全图前8轮3478记录等价、两c96六组16CPU核验通过；尚未形成全图零冲突或三档RC联合资格。原1322冻结核心与其证据不修改；见[Checkpoint80](../work/YUZE-LU/162/continuation-checkpoint-80.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');s='''# Issue162：等价支配链优化的实际回放入口

当前453/345实例/23类型/R256/S1350，完整系统物理仍未通过，继续原七阶段门。source1340保留有限资源搜索全部标签、父路径、计数、cap、堆顺序，仅从支配查找链摘除失效项。证据见[Checkpoint80](../work/YUZE-LU/162/continuation-checkpoint-80.md)。以下旧源/旧阶段记录不替代当前绑定。

在独占16CPU Slurm/ORFS槽，冻结source1340并核验完整源后执行 `python3 <source>/project/experiments/control_v1/system_upper.py --manifest <selected/physical.json> --graph <453/topology/boundary-graph.json> --resource-front-regression-config <config1344.json> --out <新目录>`。配置指定冻结source1318、原1322实际输出和原40×40暖前缀；2400旧新路径/计数/错误、240独立参考和18完整小图原字节回放全部必须通过。此入口不授予系统物理资格；真实13460独立执行零冲突、几何/PG、low/base/high分布RC300MHz与最终交付门。宏内部及物理门未变，c96保持6×16动态补位，不自行合并。

'''+s;p.write_bytes(s.encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
