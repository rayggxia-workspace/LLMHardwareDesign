from pathlib import Path
h=Path(__file__).parent
queue='''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=b/'r256-resource-front-source-audit-1342/receipt.json';previous=b/'r256-settled-adaptive-regression-1322';assert json.loads(audit.read_text())['passed']and json.loads((previous/'receipt.json').read_text())['passed']
out=b/'r256-resource-front-regression-1344';record=b/'route-selection-102/sready1344-resource-front-regression';p=b/'dynamic-04/node25/pending/00-a-sready1344-resource-front-regression.json';assert not record.exists()and not p.exists()and not out.exists()
prior=b/'r256-weighted-settle-regression-1252/weighted-settle';manifest=prior/'unchanged-rounds/unchanged-neighbors/unchanged-batch/unchanged-zero/unchanged-multicast/multicast-seed.json'
config=b/'config1344.json';assert not config.exists();config.write_text(json.dumps(dict(baseline_source=str(b/'source-1318/project/experiments/control_v1'),previous_adaptive=str(previous/'settled-adaptive'),fixture_manifest=str(manifest))))
spec=dict(script='system_upper.py',source_root=str(b/'source-1340'),forecast_gib=16,requires=[str(audit),str(previous/'receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--resource-front-regression-config',str(config),'--out',str(out)])
temp=p.with_suffix('.tmp');temp.write_text(json.dumps(spec));temp.rename(p);record.mkdir();(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),sha256=sha(p),spec=spec)],config_sha256=sha(config),whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=1,out=str(out))))
'''
(h/'control162-queue1344-remote.py').write_bytes(queue.encode())
s=(h/'control162-refill1335-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1335-adaptive-weight-refill','sready1345-resource-front-refill').replace('sready1332-adaptive-weight-fullchains','sready1344-resource-front-regression').replace("len(tasks['tasks'])==14","len(tasks['tasks'])==1")
s=s.replace("for name in ['r256-settled-adaptive-regression-1322','r256-settled-adaptive-source-audit-1320']","for name in ['r256-settled-adaptive-regression-1322','r256-resource-front-source-audit-1342']")
s=s.replace(";assert json.loads((b/'r256-final-chain-binding-audit-1333/receipt.json').read_text())['passed']",'')
s=s.replace("[(25,95204,'dynamic-04/node25',10301,'source-1013',0,320,400),(24,96222,'dynamic-06/node26',10302,'source-1013',0,320,400)]","[(25,95204,'dynamic-04/node25',7581,'source-735',0,272,342.4)]")
s=s.replace("current_forecast-spec['forecast_gib']+64<=forecast","current_forecast-spec['forecast_gib']+16<=forecast")
s=s.replace('r256-adaptive-weight-slot-capture-1334','r256-resource-front-slot-capture-1343')
start=s.index("reason='Freshspecificown10301");end=s.index("')\n (record/",start)
s=s[:start]+"reason='Fresh exact own7581 source735 partial only, verified1343specSHA/UID10011/job/node25/PID/fullcmd/source/out/current453/alllogs/nooutput/no winner and actual342.4GiB available for272GiB forecast. Preserve old raw. New source1340 exact ResourceSearch optimization regression only; no new physical candidate before actual regression. No parent/foreign/externalR/CUGR cancellation. Eight parents, c96 six dynamic16CPU slots, no gate/cap relaxation"+s[end:]
compile(s,'refill1345','exec');(h/'control162-refill1345-remote.py').write_bytes(s.encode())
print('Prepared1344queue/1345exactownguard')
