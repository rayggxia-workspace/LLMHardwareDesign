from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-queue1332-remote.py').read_text(encoding='utf-8')
s=s.replace("source=b/'source-1318'","source=b/'source-1340'").replace('sready1332-adaptive-weight-fullchains','sready1346-resource-front-fullchain')
s=s.replace("['r256-settled-adaptive-regression-1322','r256-settled-adaptive-source-audit-1320']","['r256-resource-front-regression-1344','r256-resource-front-source-audit-1342']")
s=s.replace("m['commit']=='3966fd552b379b1ab6a2aa7806da848207c49913'and len(m['files'])==1025","m['commit']=='4ff5941060ec8048de6df9616730e453a33f3529'and len(m['files'])==1026")
s=s.replace('r256-settled-adaptive-source-audit-1320/receipt.json','r256-resource-front-source-audit-1342/receipt.json')
s=s.replace("[(13320,64,'dynamic-04/node25'),(13321,128,'dynamic-06/node26')]","[(13460,256,'dynamic-04/node25')]")
s=s.replace("assert spec['source_root']==str(source)","assert spec['source_root']==str(b/'source-1318');spec['source_root']=str(source)")
s=s.replace("a[a.index('--route-heuristic-weight')+1]=str(weight);spec['requires'] += [str(b/'r256-final-chain-binding-audit-1333/receipt.json')]","a[a.index('--route-heuristic-weight')+1]=str(weight);a.remove('--route-adaptive-heuristic');spec['requires'] += [str(b/'r256-final-chain-binding-audit-1347/receipt.json'),str(b/'r256-resource-front-regression-1344/receipt.json'),str(b/'r256-resource-front-source-audit-1342/receipt.json')]")
s=s.replace(".replace('sready1324','sready1332')",".replace('sready1324','sready1346')")
start=s.index("scope='Existingallowedinitialweight");end=s.index("'),indent=2",start)
s=s[:start]+"scope='Exact resource-search active-only lookup source1340 after actual1344 component and18 full small byteexact replays. Full current453 S5380/plain nonadaptivecost8/cutoff16/stride16/additivehistory/seed4662/9060trial0; same routing semantics as12561. Only new source and output paths, all original seven geometry/PG/threeRC300MHz/finaldelivery gates retained. Natural free slot after1344, eight parents c96six independent16CPU slots, no foreign/parent/externalR action; no speedup or system qualification claim"+s[end:]
s=s.replace('queued=14,candidates=[13320,13321],no_source_changes=True','queued=7,candidates=[13460],exact_resource_lookup_optimization=True')
compile(s,'queue1346','exec');(h/'control162-queue1346-remote.py').write_bytes(s.encode())
s=(h/'control162-audit1333-remote.py').read_text(encoding='utf-8')
s=s.replace('r256-final-chain-binding-audit-1333','r256-final-chain-binding-audit-1347').replace('sready1332-adaptive-weight-fullchains','sready1346-resource-front-fullchain').replace('[13320,13321]','[13460]')
s=s.replace("str(b/'source-1318')","str(b/'source-1340')").replace("assert '--route-adaptive-heuristic'in route['args'];","assert '--route-adaptive-heuristic'not in route['args'];").replace('{13320:64,13321:128}','{13460:256}')
needle="assert str(b/'r256-settled-adaptive-regression-1322/receipt.json')in route['requires'];"
s=s.replace(needle,needle+"assert str(b/'r256-resource-front-regression-1344/receipt.json')in route['requires'];assert str(b/'r256-resource-front-source-audit-1342/receipt.json')in route['requires'];")
s=s.replace('candidates13320/13321 and14','candidate13460 and7').replace('launchrequiresactual1322combinationregressionpassed','launchrequiresactual1344exactoldnewreplaypassed')
compile(s,'audit1347','exec');(h/'control162-audit1347-remote.py').write_bytes(s.encode())
print('Prepared1346sevenstage chain and1347strictbindings')
