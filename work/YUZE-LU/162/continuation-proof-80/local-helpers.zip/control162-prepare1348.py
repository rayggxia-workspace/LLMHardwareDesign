from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-audit1327.py').read_text(encoding='utf-8')
s=s.replace('r256-settled-adaptive-c96-active-audit-1327','r256-resource-front-and-adaptive-active-audit-1348')
s=s.replace('for seed in [13240]:','for seed in [13320,13321,13460]:')
s=s.replace("split()[14])==1","split()[14])=={13320:1,13321:1,13460:0}[seed]")
s=s.replace('{13240:8}','{13320:8,13321:8,13460:8}').replace('{13240:16}','{13320:16,13321:16,13460:16}')
needle="assert int(p.read_text().splitlines()[0].split()[11])==0;"
s=s.replace(needle,needle+"assert int(p.read_text().splitlines()[0].split()[5])=={13320:64,13321:128,13460:256}[seed];")
s=s.replace("[(95204,25,'dynamic-04/node25',[13240],[5400,6562,7581,10301,11204,13240])]","[(95204,25,'dynamic-04/node25',[13320,13460],[5400,6562,13460,13320,11204,13240]),(96222,24,'dynamic-06/node26',[13321],[5494,5495,7920,7921,11205,13321])]")
start=s.index("scope='Actual16owned");end=s.index("')\nexcept",start)
s=s[:start]+"scope='Actual48 owned children13320/13321 source1318 and13460 source1340,48 exact full input bodies/warm native prefixes, actual weights64/128/256 and adaptive1/1/0. Both c96 nodes six disjoint16CPU masks and actual controller memory admissions checked. Software regression1322/1344 only, no full system route/geometryPG3RC300MHz qualification; physical gates unchanged. Original controls/foreign/externalR/parents untouched"+s[end:]
s=s.replace('new_owned_children=16','new_owned_children=48').replace('observed_six16cpu_masks_disjoint_single_c96_node25=True','observed_two_c96_six16cpu_masks_disjoint=True')
compile(s,'audit1348','exec');(h/'control162-audit1348.py').write_bytes(s.encode());print('Prepared actual48children and two c96 sixmask audit')
