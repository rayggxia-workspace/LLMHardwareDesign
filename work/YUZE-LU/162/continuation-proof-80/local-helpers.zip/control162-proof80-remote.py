from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-80';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','component']and f.stat().st_size<8000000:add(f)
for n in ['r256-final-chain-binding-audit-1333','r256-resource-front-source-audit-1342','r256-resource-front-regression-1344','r256-final-chain-binding-audit-1347','r256-resource-front-and-adaptive-active-audit-1349','r256-resource-front-full-prefix-replay-1350']:
 assert json.loads((b/n/'receipt.json').read_text())['passed'];shallow(b/n)
for n in ['r256-adaptive-weight-slot-capture-1334','r256-resource-front-slot-capture-1343','r256-adaptive-probe-hotspot-profile-1337','r256-resource-front-and-adaptive-active-audit-1348']:shallow(b/n)
assert not json.loads((b/'r256-resource-front-and-adaptive-active-audit-1348/receipt.json').read_text())['passed']
root=b/'r256-resource-front-regression-1344/resource-front';r=json.loads((root/'receipt.json').read_text());assert r['passed']and len(r['cases'])==18 and sum(x['failed']for x in r['cases'])==3 and r['component']['exact_path_and_label_checks']==2400 and r['component']['identical_cap_failures']==454 and r['component']['independent_oracles']==240;shallow(root)
for p in root.iterdir():
 if p.is_dir():shallow(p)
for n in ['sready1332-adaptive-weight-fullchains','sready1335-adaptive-weight-refill','sready1344-resource-front-regression','sready1345-resource-front-refill','sready1346-resource-front-fullchain']:
 p=b/'route-selection-102'/n;shallow(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for n in ['source-manifest.json','freeze-import.json']:add(b/'source-1340'/n)
for n in ['config1344.json','control162-backout1340.patch','control162-audit1342-remote.py']:add(b/n)
out.mkdir();audit=json.loads((b/'r256-resource-front-and-adaptive-active-audit-1349/receipt.json').read_text());admission=next(x for x in audit['actual_admissions']if x['seed']==13460);command=Path(admission['path']);finished=b/'dynamic-04/node25/results/00-a-sready1344-resource-front-regression.json';done=json.loads(finished.read_text());assert done['returncode']==0 and done['finished']<=command.stat().st_mtime
chronology=out/'exact-replay-before-full-admission.json';chronology.write_text(json.dumps(dict(passed=True,regression_finished=done['finished'],full_candidate_admission_file=str(command),admission_file_mtime=command.stat().st_mtime,admission_file_sha256=sha(command),admission=admission['admission'],whole_system_qualified=False),indent=2));add(chronology);add(command);add(finished)
live=out/'live-route-snapshots';live.mkdir();progress=[]
for tag in [12560,12561,12840,12841,13120,13121,13240,13320,13321,13460]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 if not p.exists():continue
 raw=p.read_bytes();target=live/(str(tag)+'-trial0.log');target.write_bytes(raw);add(target);rs=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:rs.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=tag,original=str(p),immutable_live_prefix=str(target),last_complete_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(rs)if'routed'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)}
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
archive=out/'selected-originals.zip';ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Actual13320/21 parameter candidates, two exact own source1013 replacements, owner-only494sample native dominance CPU profile; source1340 all1026/archive/backout exact; actual2400 old/new paths/counts/errors454 caps plus240 independent oracle and18 full small byteexact replays including3 failures. Native/ordinary routing semantics and physical gates retained,13460 independent7stage chain only after actual regression.1348 premature actual trace audit failure retained;1349 actual48process/two c96sixmask audit. Running logs immutable prefixes, no full system physical pass.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
