from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=b/'r256-resource-front-source-audit-1342/receipt.json';previous=b/'r256-settled-adaptive-regression-1322';assert json.loads(audit.read_text())['passed']and json.loads((previous/'receipt.json').read_text())['passed']
out=b/'r256-resource-front-regression-1344';record=b/'route-selection-102/sready1344-resource-front-regression';p=b/'dynamic-04/node25/pending/00-a-sready1344-resource-front-regression.json';assert not record.exists()and not p.exists()and not out.exists()
prior=b/'r256-weighted-settle-regression-1252/weighted-settle';manifest=prior/'unchanged-rounds/unchanged-neighbors/unchanged-batch/unchanged-zero/unchanged-multicast/multicast-seed.json'
config=b/'config1344.json';assert not config.exists();config.write_text(json.dumps(dict(baseline_source=str(b/'source-1318/project/experiments/control_v1'),previous_adaptive=str(previous/'settled-adaptive'),fixture_manifest=str(manifest))))
spec=dict(script='system_upper.py',source_root=str(b/'source-1340'),forecast_gib=16,requires=[str(audit),str(previous/'receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(b/'r256-composition-453/topology/boundary-graph.json'),'--resource-front-regression-config',str(config),'--out',str(out)])
temp=p.with_suffix('.tmp');temp.write_text(json.dumps(spec));temp.rename(p);record.mkdir();(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),sha256=sha(p),spec=spec)],config_sha256=sha(config),whole_system_qualified=False),indent=2));print(json.dumps(dict(queued=1,out=str(out))))
