from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1318';new=b/'source-1340';out=b/'r256-resource-front-source-audit-1342';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prefix='project/experiments/control_v1/'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='4ff5941060ec8048de6df9616730e453a33f3529'and len(z['files'])==1026
changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={prefix+n for n in ['resource_search.h','resource_front_regression.py','system_upper.py']}
expected='8eff23c2e85a8be6a6fca2c0901827eb3231775a3d4d18c69e66a28667b26534'
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and sha(b/'source1340.tar.gz')==expected
assert all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for n in ['resource_search.h','resource_front_regression.py','system_upper.py']:
 p=scratch/prefix/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/prefix/n).read_bytes())
patch=b/'control162-backout1340.patch'
subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/prefix/n).read_bytes()==(old/prefix/n).read_bytes()for n in ['resource_search.h','system_upper.py'])and not(scratch/prefix/'resource_front_regression.py').exists()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1026,unchanged_files=1023,three_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Active-only dominance lookup optimization plus optional exact replay helper/dispatcher. All label records/parents/caps preserved; independent actual regression required before any full candidate. All physical gates/RTL/wrapper/ordinary algorithms unchanged.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1026,unchanged=1023)))
queue=b/'dynamic-04/node25';state=json.loads((queue/'queue-state.json').read_text());rows=[]
for name in state['active']:
 p=queue/'pending'/(name+'.json');spec=json.loads(p.read_text());args=spec['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='7581':rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
assert len(rows)==1
capture=b/'r256-resource-front-slot-capture-1343';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(rows))
