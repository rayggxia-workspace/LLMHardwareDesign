
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <limits>
#include <queue>
#include <random>
#include <stdexcept>
#include <vector>
using namespace std;
struct Item {int64_t priority,cost;int node;bool operator<(const Item&q)const{
 if(priority!=q.priority)return priority>q.priority;
 if(cost!=q.cost)return cost<q.cost;return node>q.node;}};
#include "baseline.h"
#include "resource_search.h"
int main(){
 if(resource_oracle_test()!=120||baseline_resource_oracle_test()!=120)return 2;
 mt19937 rng(1621340);int checks=0,failures=0;
 for(int trial=0;trial<2400;++trial){
  int nx=24,ny=24,plane=nx*ny,size=2*plane;
  vector<int>blocked(size),penalty(size);
  for(int v=0;v<size;++v){blocked[v]=rng()%19==0;penalty[v]=rng()%501;}
  int start=(4+rng()%16)*nx+4+rng()%16,goal=(4+rng()%16)*nx+4+rng()%16;
  blocked[start]=blocked[goal]=0;
  int budget=rng()%80,weight=array<int,8>{1,4,8,16,32,64,128,256}[trial%8],cost=array<int,3>{2,8,32}[trial%3];
  BaselineResourceSearch a;ResourceSearch b;
  a.label_limit=b.label_limit=trial%4?8000000:array<int,5>{1,2,16,64,256}[trial%5];
  auto h=[&](int v){return abs(v%nx-goal%nx)+abs((v%plane)/nx-(goal%plane)/nx);};
  vector<int>pa,pb;string ea,eb;
  try{pa=a.find(nx,ny,start,budget,weight,cost,[&](int v){return penalty[v];},[&](int v){return !blocked[v];},[&](int v){return v==goal;},h);}catch(const runtime_error&e){ea=e.what();}
  try{pb=b.find(nx,ny,start,budget,weight,cost,[&](int v){return penalty[v];},[&](int v){return !blocked[v];},[&](int v){return v==goal;},h);}catch(const runtime_error&e){eb=e.what();}
  if(pa!=pb||ea!=eb||a.calls!=b.calls||a.maximum_labels!=b.maximum_labels)return 3;
  failures+=!ea.empty();++checks;
 }
 cout<<"{\"passed\":true,\"exact_path_and_label_checks\":"<<checks<<",\"identical_cap_failures\":"<<failures<<",\"independent_oracles\":240}"<<endl;
}
