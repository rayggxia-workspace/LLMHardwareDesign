from pathlib import Path
import subprocess,json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-resource-front-dense-hotspot-profile-1354';out=b/'r256-resource-front-dense-annotate-1364';assert not out.exists();out.mkdir();old=json.loads((root/'receipt.json').read_text());assert old['record_returncode']==0 and old['report_returncode']==0
job='95204';d=subprocess.check_output(['scontrol','show','job',job,'-o'],universal_newlines=True);assert'UserId=yuzelu(10011)'in d and'NodeList=node25 'in d
code="import subprocess,json;from pathlib import Path;r=Path("+repr(str(root))+ ");o=Path("+repr(str(out))+");v=subprocess.run(['perf','annotate','--stdio','-i',str(r/'perf.data')],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(o/'annotate.stdout').write_bytes(v.stdout);(o/'annotate.stderr').write_bytes(v.stderr);print(json.dumps(dict(returncode=v.returncode,bytes=len(v.stdout))))"
p=subprocess.run(['srun','--jobid='+job,'--overlap','-n1','-c1','python3','-c',code],stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'launcher.stdout').write_bytes(p.stdout);(out/'launcher.stderr').write_bytes(p.stderr);print(p.stdout.decode());assert p.returncode==0
