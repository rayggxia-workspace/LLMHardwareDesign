from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1340';new=b/'source-1368';out=b/'r256-coarse-refine-source-audit-1370';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prefix='project/experiments/control_v1/'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='27b2e3d85ec2a28535bf032f198b81d8c20db4e8'and len(z['files'])==1028
changed={p for p,v in z['files'].items()if a['files'].get(p)!=v};assert changed=={prefix+n for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','routing_corridor.h','coarse_refine_regression.py']}
expected='aa91e866f8cbd8afd0d12e36338b0c65d094aab29ae29988691d5132161c420e'
assert json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and sha(b/'source1368.tar.gz')==expected
assert all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py','routing_corridor.h','coarse_refine_regression.py']:
 p=scratch/prefix/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/prefix/n).read_bytes())
patch=b/'control162-backout1368.patch'
subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/prefix/n).read_bytes()==(old/prefix/n).read_bytes()for n in ['tree_router.cpp','tree_router_cpp.py','system_upper.py'])and all(not(scratch/prefix/n).exists()for n in ['routing_corridor.h','coarse_refine_regression.py'])
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1023,five_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Optional ordinary two-terminal coarse path used as software fine-search guide, plus helper/CLI/wrapper. Original ResourceSearch/native solver, ordinary settled core, macro RTL and all final physical gates unchanged among1023files. Default18whole-small byteexact and actual guided independent regression required before any new full candidate.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1023)))
queue=b/'dynamic-05/node4';state=json.loads((queue/'queue-state.json').read_text());rows=[]
for name in state['active']:
 p=queue/'pending'/(name+'.json');spec=json.loads(p.read_text());args=spec['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='11203':rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
assert len(rows)==1
capture=b/'r256-coarse-refine-slot-capture-1371';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(rows))
