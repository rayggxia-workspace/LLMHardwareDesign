from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1368';new=b/'source-1376';out=b/'r256-coarse-refine-multicast-source-audit-1378';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prefix='project/experiments/control_v1/'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='c0245bd54b0e91355460d6197c2c6bd7d272e3ff'and len(z['files'])==1028
names=['tree_router.cpp','coarse_refine_regression.py'];assert{p for p,v in z['files'].items()if a['files'].get(p)!=v}=={prefix+n for n in names}
expected='badf95dc1bf665fec8ffbcd6d4af85de2dca89e3b2ff402e40a0446f027e9f07';assert sha(b/'source1376.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for n in names:
 p=scratch/prefix/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/prefix/n).read_bytes())
patch=b/'control162-backout1376.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/prefix/n).read_bytes()==(old/prefix/n).read_bytes()for n in names)
assert json.loads((b/'r256-coarse-refine-source-audit-1370/receipt.json').read_text())['passed']
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1026,two_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Extend optional actual coarse-guided fine routing to ordinary multicast branches; actual old tree target retained, original first-tree-join truncation retained. New counter and actual successful multicast test requirement. Macro RTL/native ResourceSearch/ordinary settled core/all physical gates unchanged. Actual regression required before full candidate.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1026)))
