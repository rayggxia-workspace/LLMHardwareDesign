from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-81';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-81/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 for name,zero,failed in [('r256-coarse-refine-regression-1372',11,5),('r256-coarse-refine-multicast-regression-1380',13,3)]:
  r=json.loads(z.read(name+'/coarse-refine/receipt.json'));assert r['passed']and len(r['defaults'])==18 and len(r['cases'])==16 and sum(not x['failed']for x in r['cases'])==zero and sum(x['failed']for x in r['cases'])==failed
  assert r['component']['independent_membership_checks']==246018 and len(r['rejected'])==4
 assert sum(x['refinement_multicast']for x in r['cases'])==413
 c=json.loads(z.read('continuation-proof-81/multicast-regression-before-full-admission.json'));assert c['passed']and c['regression_finished']<=c['admission_file_mtime']and c['admission']['forecast_gib']==257
 a=json.loads(z.read('r256-coarse-guided-active-audit-1391/receipt.json'));assert a['passed']and len(a['comparisons'])==16 and len(a['pools'])==1
 assert not json.loads(z.read('r256-coarse-guided-active-audit-1385/receipt.json'))['passed']
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch|txt)$',p.name)
  if m and 1351<=int(m.group(1))<=1391:entries[p.name]=p
for n in ['control162-checkpoint81.py','control162-proof81-remote.py','control162-verify81.py']:
 p=h/n
 if p.is_file():entries[n]=p
for n in ['control162-read1374','control162-read1381','control162-phase-progress1352','control162-phase-progress1366','control162-phase-progress1388','control162-live1228']:
 p=h/n
 if p.is_dir():
  for f in p.glob('*.json'):
   if f.stat().st_size<4000000:entries[f.relative_to(h).as_posix()]=f
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Actual owner-only source freezes, memory refusals/relocation, two precise child replacements, hotspot profile, guide regressions and full actual process binding. Original failed observers/PowerShell local parser failure retained in errata; no result repaired or gate relaxed.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint81

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。承接[80](continuation-checkpoint-80.md)。**仍无完整组合零冲突/几何/PG/low-base-high分布RC300MHz联合通过，继续布局布线，不合并。** 六宏/R256/S1350/23类型138文件/345状态宿主/453/S5380保留；所有M1–M10宏与被动M11/M12边界不变，不动外部R和其他任务。

窗口16＋原source1340等价有限标签优化：1358因我低报替换后预测320GiB（实际需352）被原断言拒绝；1359改正预测后又因真实可用内存不足438.4GiB拒绝，均未取消5400。原精确MemAvailable未在断言前保存，不虚构；独立1389新读数为414.285095GiB，仍低于438.4。1360将7份未启动规格原字节留存并移到现有node3；1361重新严格绑定，1363对本人6561/source653逐UID/job/node/PID/全命令/specSHA/图/全日志/无输出与323.2GiB门核验后替换。13560实际node3四组互斥16CPU与16输入/前缀通过；真实全图对原12841前8轮3474记录除monotonic_ns外精确一致。没有降低并发或内存门。

1354对本人13460/node25进程5秒495采样，普通settled细搜约52.53%、堆pop32.32%、push15.15%；1364保留实际汇编采样。现有大范围细搜及多端点网过慢，因此只在软件搜索中增加默认关闭的粗路径引导细化，不改计算宏。借鉴[CUGR的连接矩形引导详细布线原则](https://github.com/cuhk-eda/cu-gr)，没有移植CUGR代码或继承其结果。

source1368（`27b2e3d85ec2a28535bf032f198b81d8c20db4e8`）增加可选引导：从已有实际粗单位路径建立两层XY走廊，宽度随轮次增加，仍按原fixed所有者/棋盘via/单位边搜索；没找到细路径显式失败。原ResourceSearch、settled核心、宏RTL与所有最终物理门不变，1028源/1023不变/归档/5文件精确回退通过。1372实际246018独立成员检查、尺寸复用/epoch溢出、3非法参数；18默认完整小图逐字回放；16新模式完整尝试11零/5失败，4CLI拒绝及一轮真实失败保留。不能称质量改善。

source1376（`c0245bd54b0e91355460d6197c2c6bd7d272e3ff`）将引导细化用于普通多端点分支：目标仍取原实际已布树点，保留首次实际入树处截断；不作用于native有限网。1028源/1026不变/归档/两文件精确回退通过。1380实际同246018成员检查及18默认字节回放；16新模式完整尝试13零/3失败，实际2375路径改变、413多端点细化、13案例跨原cutoff。两种代价都必须有真正成功的多端点细化，4CLI拒绝与一轮真实失败保留。只是组件/小图证据，不代表全图收敛或性能提升。

仅精确核验并替换本人11203/source1104子步骤95391.119，其他五个旧1104对照保留。1372与1380均在同一16CPU槽自然补位；13820再在1380真实通过后自然进入原7阶段/六键完整物理链。65GiB路由槽预测包括引导bitmap额外1GiB，当前node4总257GiB需324.4GiB可用；真实准入通过。1391核对16真实进程/输入/9060前缀、实际guide及multicast计数、四个互斥16CPU，1383当前函数/拓扑/R256/三档RC路径严格通过。没有借小图、单块或旧几何授予系统资格。

1385观察脚本错误地把guided上下文的assert表达式算成None，原failed receipt保留；1391修正观察上下文检查，物理门/运行源不改。1390只看6000字节尾部漏过旧轮完成计数，ready0是假阴性，不能当路由失败；1391读实际完整日志。一次本地PowerShell嵌套引号失败未执行远程操作，随后文件生成器成功。原件与限制见[513份远程源绑定](continuation-proof-81/index.json)/[本地辅助材料](continuation-proof-81/local-index.json)。

8父节点36×16独立任务动态，c96六槽；无父节点/foreign/外部R/CUGR3751取消。**下一步继续全图零冲突、最终实际M11/M12几何/native XOR/PG、三档RC300MHz setup/hold/电气和全部声明组合六文件/版图/源索引；失败持续定位，不在检查点收尾。** 登记PR5 pending，看板unverified/同步pending（缺board.json），审查人待指定。
'''
(base/'continuation-checkpoint-81.md').write_bytes(doc.encode())
summary=f'''# Issue162：粗路径引导细布线实际回归后进入完整物理链

更新时间：{now}。[Checkpoint81](../work/YUZE-LU/162/continuation-checkpoint-81.md) / [513份原字节与源索引](../work/YUZE-LU/162/continuation-proof-81/index.json)。node25内存门拒绝后，将未启动窗口方案原字节移到现有node3，四组16CPU与真实全图前8轮等价通过；不降低并发/内存门。普通细搜与多端点耗时采样后，只增加默认关闭的软件粗路径引导细化，宏/native有限搜索/原最终门不变。

源1368/1376全manifest/归档/精确回退通过；实际1372、1380各246018独立成员检查及18默认字节回放，后者16真实尝试13零/3失败、413多端点细化；全部失败保留。13820在实际回归通过后自然补位原七阶段，16真实进程/输入/前缀、node4四组互斥16CPU及257GiB预测/324.4GiB实际准入通过。观察器1385/1390错误原件和修正区分，不当作物理结果。

**仍无完整组合零冲突、几何/PG/三档RC300MHz联合通过，继续最终布局布线，不合并。** 六宏/R256/S1350/23类138文件/345状态宿主/453/S5380保留；8父节点36×16动态、c96六任务，不动外部R/其他任务。最终六文件、版图及源绑定仍须实际验收。登记PR5 pending，看板unverified/同步pending，审查待指定。

'''
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;p.write_bytes((summary.replace('../work/',prefix+'work/')+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint80源索引](../work/YUZE-LU/162/continuation-proof-80/index.json)','Checkpoint81源索引](../work/YUZE-LU/162/continuation-proof-81/index.json)');at=s.index('本轮追加可选的普通候选搜索切换轮次8/16/32');s=s[:at]+'source1376新增默认关闭的普通网粗路径引导细化，覆盖pair及实际多端点入树，1380组件/小图实际通过后启动13820完整7阶段。原native有限搜索、宏内部与全部物理门不变，尚无完整系统资格；node25内存拒绝/未启动任务迁移和所有观察器失败留有原件，见[Checkpoint81](../work/YUZE-LU/162/continuation-checkpoint-81.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');s='''# Issue162：粗路径引导细布线的已验证入口

当前453/345实例/23类型/R256/S1350，完整系统物理仍未通过。冻结source1376后，在独立16CPU Slurm/ORFS槽执行 `python3 <source>/project/experiments/control_v1/system_upper.py --manifest <selected/physical.json> --graph <453/topology/boundary-graph.json> --coarse-refine-regression-config <config1380.json> --out <新目录>`。配置绑定原source1340及实际1344默认18执行，实际检查246018 guide成员/epoch/拒绝、原18完整字节回放、16真实guided尝试及两种代价成功多端点，所有失败保留。证据见[Checkpoint81](../work/YUZE-LU/162/continuation-checkpoint-81.md)。

可选 `--route-ordinary-coarse-refine` 仅将已有实际普通粗路径作为两层XY细搜走廊，仍按原所有者/单位边/via并在原真实入树处截断；没有更改native有限搜索或任何固定宏/最终门。实际13820在回归通过后独立执行原7阶段M11/M12零冲突、几何/PG/三档RC300MHz/最终交付，不继承组件资格。65GiB路由槽、当前node4总257GiB预测/324.4GiB实际内存门，四个16CPU独立任务；八父节点和c96六槽规则保持，不合并。

'''+s;p.write_bytes(s.encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
