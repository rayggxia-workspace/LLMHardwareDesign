from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates';out=b/'r256-window-resource-full-prefix-replay-1387';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=root/'12841/route/trial-0';new=root/'13560/route/trial-0';assert(old/'input.txt').read_bytes()==(new/'input.txt').read_bytes()
assert(old/'output.txt.native-prefix-paths.txt').read_bytes()==(new/'output.txt.native-prefix-paths.txt').read_bytes()
def rows(p):
 with p.open('rb')as f:raw=f.read(4000000)
 lines=raw.splitlines(keepends=True)
 if lines and not lines[-1].endswith(b'\n'):lines.pop()
 records=[]
 for line in lines:
  s=line.decode()
  if s.startswith('{'):
   v=json.loads(s);v.pop('monotonic_ns',None);records.append(v)
 return raw,records
ar,a=rows(old/'router.log');zr,z=rows(new/'router.log');complete=[r['round']for r in z if'conflict_nodes'in r];assert complete and max(complete)>=3
last=min(max(complete),7)
def prefix(rs):
 result=[]
 for row in rs:
  if'round'in row and row['round']>last:break
  result.append(row)
 return result
x=prefix(a);y=prefix(z);assert x==y,(len(x),len(y),next(((i,p,q)for i,(p,q)in enumerate(zip(x,y))if p!=q),None))
out.mkdir();(out/'old-prefix.bin').write_bytes(ar);(out/'new-prefix.bin').write_bytes(zr)
r=dict(passed=True,time=time.time(),whole_system_qualified=False,complete_rounds_through=last,normalized_records=len(x),ignored_field='monotonic_ns only',actual_input_byteexact=True,warm_native_path_byteexact=True,inputs={str(p):sha(p)for p in[old/'input.txt',new/'input.txt',old/'output.txt.native-prefix-paths.txt',new/'output.txt.native-prefix-paths.txt',b/'source-1250/source-manifest.json',b/'source-1340/source-manifest.json']},snapshots={str(p):sha(p)for p in[out/'old-prefix.bin',out/'new-prefix.bin']},scope='Actual full current453 graph trial0 window1612841 vs resource lookup13560 initial complete rounds, exact input/native paths and all parsed router records excluding monotonic_ns. No future rounds, convergence, speedup or geometry/PG/RC qualification inferred.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,complete_rounds_through=last,normalized_records=len(x))))
