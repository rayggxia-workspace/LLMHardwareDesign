from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [12561,13460]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 if not p.exists():continue
 with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-1000000));lines=f.read().decode(errors='replace').splitlines()
 records=[]
 for l in lines:
  if l.startswith('{'):
   try:records.append(json.loads(l))
   except ValueError:pass
 rows.append(dict(candidate=tag,bytes=size,mtime=p.stat().st_mtime,last_phase=next((r for r in reversed(records)if 'routing_phase_event'in r),None),last_progress=next((r for r in reversed(records)if 'routed'in r),None),last_global=next((r for r in reversed(records)if 'conflict_nodes'in r),None),last_schedule=next((r for r in reversed(records)if 'coarse_round_limit'in r),None),last_zero=next((r for r in reversed(records)if 'coarse_zero_hits'in r),None),last_native=next((r for r in reversed(records)if 'finite_resource_calls'in r),None)))
print(json.dumps(dict(time=time.time(),rows=rows)))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);out=Path(__file__).parent/'control162-phase-progress1352';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);print(raw.decode())
