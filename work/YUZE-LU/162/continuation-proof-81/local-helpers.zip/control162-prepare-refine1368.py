from pathlib import Path
r=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control/project/experiments/control_v1')
p=r/'tree_router_cpp.py';s=p.read_text(encoding='utf-8');old='ordinary_coarse_rounds=64,weighted_settle_once=False):';assert s.count(old)==1;s=s.replace(old,'ordinary_coarse_rounds=64,weighted_settle_once=False,coarse_refine=False):')
needle="    if weighted_settle_once:extra_cli.append('--weighted-settle-once')";assert s.count(needle)==1;s=s.replace(needle,needle+"\n    assert not coarse_refine or(weighted_settle_once and ordinary_coarse_access and ordinary_coarse_grid_stride)\n    if coarse_refine:extra_cli.append('--ordinary-coarse-refine')")
p.write_bytes(s.encode())
p=r/'system_upper.py';s=p.read_text(encoding='utf-8');needle="    p.add_argument('--resource-front-regression-config',type=Path)";assert s.count(needle)==1;s=s.replace(needle,needle+"\n    p.add_argument('--coarse-refine-regression-config',type=Path)\n    p.add_argument('--route-ordinary-coarse-refine',action='store_true',help='Candidate search only: refine an actual ordinary coarse path inside a widening XY corridor; native search and all final physical gates unchanged')")
needle="    assert a.route_ordinary_coarse_rounds==64 or a.route_ordinary_coarse";assert s.count(needle)==1;s=s.replace(needle,needle+"\n    assert not a.route_ordinary_coarse_refine or(a.route_weighted_settle_once and a.route_ordinary_coarse_access and a.route_ordinary_coarse)")
needle='    try:\n        if a.resource_front_regression_config:';assert s.count(needle)==1
s=s.replace(needle,"""    try:
        if a.coarse_refine_regression_config:
            from coarse_refine_regression import run
            config=a.coarse_refine_regression_config;helper=Path(__file__).with_name('coarse_refine_regression.py')
            for path in (a.manifest,a.graph,Path(__file__),config,helper):receipt['inputs'][str(path)]=sha(path)
            child=a.out/'coarse-refine';result=run(config,child)
            assert result['passed']and not result['whole_system_qualified'];receipt['inputs'].update(result['inputs'])
            receipt['inputs'][str(child/'receipt.json')]=sha(child/'receipt.json')
            receipt.update(passed=True,stage=result['stage'],whole_system_qualified=False)
            return
        if a.resource_front_regression_config:""")
needle='weighted_settle_once=a.route_weighted_settle_once)';assert s.count(needle)==1;s=s.replace(needle,'weighted_settle_once=a.route_weighted_settle_once,coarse_refine=a.route_ordinary_coarse_refine)')
p.write_bytes(s.encode());print('Added optional coarse guide wrapper/CLI/dispatcher; old default unchanged')
