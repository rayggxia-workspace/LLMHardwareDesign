from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1357-remote.py').read_text(encoding='utf-8').replace('sready1356-window-resource-fullchain','sready1360-window-resource-transferred').replace('r256-final-chain-binding-audit-1357','r256-final-chain-binding-audit-1361')
compile(s,'audit1361','exec');(h/'control162-audit1361-remote.py').write_bytes(s.encode())
s=(h/'control162-refill1359-remote.py').read_text(encoding='utf-8').replace('sready1359-window-resource-refill','sready1363-window-resource-refill').replace('sready1356-window-resource-fullchain','sready1360-window-resource-transferred').replace('r256-final-chain-binding-audit-1357','r256-final-chain-binding-audit-1361')
s=s.replace("[(25,95204,'dynamic-04/node25',5400,'source-537',0,352,438.4)]","[(3,95098,'dynamic-02/node3',6561,'source-653',0,256,323.2)]").replace('r256-window-resource-slot-capture-1355','r256-window-resource-slot-capture-1362')
start=s.index("reason='Fresh exact own5400");end=s.index("')\n (record/",start)
s=s[:start]+"reason='Fresh exact own6561 source653 partial only,1362specSHA/UID/job95098/node3/PID/fullcmd/source/out/current453/alllogs/nooutput and actual323.2GiB for256GiB forecast. Same existing12841 progressivewindow16 with equivalent source1340 ResourceSearch; actual1344 plus strict1361passed. Original1358 forecast check and1359 node25 memory correctly rejected before cancellation;1360seven unstarted specs preserved and moved to node3. No new feature/gate/HW. Preservealloldraw/12841/13460/parents/foreign/externalR/CUGR;8parents36x16,c64four andc96six dynamic"+s[end:]
compile(s,'refill1363','exec');(h/'control162-refill1363-remote.py').write_bytes(s.encode());print('Prepared strict1361bindings and freshown1363guard')
