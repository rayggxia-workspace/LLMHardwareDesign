from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1327.py').read_text(encoding='utf-8').replace('r256-settled-adaptive-c96-active-audit-1327','r256-window-resource-active-audit-1384')
s=s.replace("root/'13240/route'","root/'13560/route'").replace('for seed in [13240]:','for seed in [13560]:').replace('split()[14])==1','split()[14])==0').replace('{13240:8}','{13560:8}').replace('{13240:16}','{13560:16}')
s=s.replace("[(95204,25,'dynamic-04/node25',[13240],[5400,6562,7581,10301,11204,13240])]","[(95098,3,'dynamic-02/node3',[13560],[13560,10711,11201,12100])]")
needle="cmd=row['command'];assert all(flag in cmd for flag in [";s=s.replace(needle,"cmd=row['command'];assert '--weighted-pair-margin=16'in cmd;assert all(flag in cmd for flag in [")
start=s.index("scope='Actual16owned");end=s.index("')\nexcept",start)
s=s[:start]+"scope='Actual16 source1340 window16 children13560 on ownednode3/95098, exact full inputs/warm native prefixes, actual adaptive0/cost8/cutoff16/stride16/window16; four disjoint16CPU masks and actual memoryadmission. Original node25 memory refusals1358/1359 and transfer1360 byte-preserved, only fresh own6561source653 retired. No new solver/hardware/physical gate in this candidate. No final route/geometryPG3RC300MHz qualification'"+s[end+1:]
s=s.replace('observed_six16cpu_masks_disjoint_single_c96_node25=True','observed_four16cpu_masks_disjoint_node3=True')
compile(s,'audit1384','exec');(h/'control162-audit1384.py').write_bytes(s.encode())
s=(h/'control162-audit1327.py').read_text(encoding='utf-8').replace('r256-settled-adaptive-c96-active-audit-1327','r256-coarse-guided-active-audit-1385')
s=s.replace("root/'13240/route'","root/'13820/route'").replace('for seed in [13240]:','for seed in [13820]:').replace('{13240:8}','{13820:8}').replace('{13240:16}','{13820:16}')
s=s.replace("[(95204,25,'dynamic-04/node25',[13240],[5400,6562,7581,10301,11204,13240])]","[(95391,4,'dynamic-05/node4',[13820],[13820,12561,12841,13121])]")
needle="cmd=row['command'];assert all(flag in cmd for flag in [";s=s.replace(needle,"cmd=row['command'];assert '--ordinary-coarse-refine'in cmd;assert all(flag in cmd for flag in [")
s=s.replace("assert all(t['coarse_attempts']==0 for t in schedule if not t['coarse_phase_active']);","assert all(t['coarse_attempts']==0 for t in schedule if not t['coarse_phase_active'])if seed!=13820 else None;")
# The legacy coarse cutoff field remains an old schedule indicator; explicit
# fine-refinement counters establish the new guided ordinary branch instead.
needle="r['comparisons'].append(dict(candidate=seed";s=s.replace(needle,"guide_rows=[json.loads(line)for line in(p.parent/'router.log').read_text().splitlines()if line.startswith('{')and 'coarse_refinement_attempts'in line];assert guide_rows and any(t['coarse_refinement_attempts']>0 and t['coarse_refinement_multicast']>0 for t in guide_rows);r['comparisons'].append(dict(candidate=seed")
start=s.index("scope='Actual16owned");end=s.index("')\nexcept",start)
s=s[:start]+"scope='Actual16 source1376 ordinary coarse-guided fine children13820 on ownednode4/95391, exact full inputs/warm native prefixes, actualadaptive1/cost8/cutoff16/stride16 and guide/multicast refinement counters. Four disjoint16CPU masks and actual257GiB forecast/324.4GiB memoryadmission. Original guide246018independentchecks/default18byteexact/16completeattempts/413multicastrefinements from1380 are software prerequisites only. No whole route/geometryPG3RC300MHz result inherited; all fixed macros/native finite solver/final physical gates unchanged'"+s[end+1:]
s=s.replace('observed_six16cpu_masks_disjoint_single_c96_node25=True','observed_four16cpu_masks_disjoint_node4=True')
compile(s,'audit1385','exec');(h/'control162-audit1385.py').write_bytes(s.encode());print('Prepared actual window1384 and guided1385process/input/mask audits')
