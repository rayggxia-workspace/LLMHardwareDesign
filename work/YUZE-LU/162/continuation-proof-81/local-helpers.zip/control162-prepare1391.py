from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-audit1385.py').read_text(encoding='utf-8')
old="assert all(t['coarse_attempts']==0 for t in schedule if not t['coarse_phase_active'])if seed!=13820 else None;"
assert s.count(old)==1
s=s.replace(old,"assert seed==13820 or all(t['coarse_attempts']==0 for t in schedule if not t['coarse_phase_active']);").replace('r256-coarse-guided-active-audit-1385','r256-coarse-guided-active-audit-1391')
compile(s,'actual1391','exec');(h/'control162-audit1391.py').write_bytes(s.encode())
print('Corrected1385assert conditional context; original failedreceipt preserved, no route/gate mutation')
