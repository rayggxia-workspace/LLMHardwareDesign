from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-81';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','component','corridor-test']and f.stat().st_size<8000000:add(f)
for n in ['r256-final-chain-binding-audit-1357','r256-final-chain-binding-audit-1361','r256-window-resource-active-audit-1384','r256-window-resource-full-prefix-replay-1387','r256-coarse-refine-source-audit-1370','r256-coarse-refine-regression-1372','r256-coarse-refine-multicast-source-audit-1378','r256-coarse-refine-multicast-regression-1380','r256-final-chain-binding-audit-1383','r256-coarse-guided-active-audit-1391']:
 assert json.loads((b/n/'receipt.json').read_text())['passed'];shallow(b/n)
for n in ['r256-window-resource-slot-capture-1355','r256-window-resource-slot-capture-1362','r256-coarse-refine-slot-capture-1371','r256-resource-front-dense-hotspot-profile-1354','r256-resource-front-dense-annotate-1364','r256-memory-admission-observation-1389','r256-coarse-guided-active-audit-1385']:shallow(b/n)
assert not json.loads((b/'r256-coarse-guided-active-audit-1385/receipt.json').read_text())['passed']
for name,success,fail in [('r256-coarse-refine-regression-1372',11,5),('r256-coarse-refine-multicast-regression-1380',13,3)]:
 root=b/name/'coarse-refine';r=json.loads((root/'receipt.json').read_text());assert r['passed']and len(r['defaults'])==18 and len(r['cases'])==16 and sum(not x['failed']for x in r['cases'])==success and sum(x['failed']for x in r['cases'])==fail and len(r['rejected'])==4 and r['component']['independent_membership_checks']==246018;shallow(root)
 for p in root.iterdir():
  if p.is_dir():shallow(p)
transfer=b/'route-selection-102/sready1360-window-resource-transferred/transfer.json';moves={x['original']:x for x in json.loads(transfer.read_text())['moves']}
for n in ['sready1356-window-resource-fullchain','sready1358-window-resource-refill','sready1359-window-resource-refill','sready1360-window-resource-transferred','sready1363-window-resource-refill','sready1372-coarse-refine-regression','sready1373-coarse-refine-regression-refill','sready1380-coarse-refine-multicast-regression','sready1382-coarse-guided-fullchain']:
 p=b/'route-selection-102'/n;shallow(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:
   target=Path(row['path'])
   if not target.exists():
    m=moves[str(target)];target=Path(m['held']);assert sha(target)==m['original_sha256']
   assert sha(target)==row['sha256'];add(target)
for source in ['1368','1376']:
 for n in ['source-manifest.json','freeze-import.json']:add(b/('source-'+source)/n)
for n in ['config1372.json','config1380.json','control162-backout1368.patch','control162-backout1376.patch','control162-audit1370-remote.py','control162-audit1378-remote.py']:add(b/n)
out.mkdir();audit=json.loads((b/'r256-coarse-guided-active-audit-1391/receipt.json').read_text());admission=next(x for x in audit['actual_admissions']if x['seed']==13820);command=Path(admission['path']);finished=b/'dynamic-05/node4/results/00-a-sready1380-coarse-refine-multicast-regression.json';done=json.loads(finished.read_text());assert done['returncode']==0 and done['finished']<=command.stat().st_mtime and admission['admission']['forecast_gib']==257 and abs(admission['admission']['required_bytes']/1024**3-324.4)<.000001
chronology=out/'multicast-regression-before-full-admission.json';chronology.write_text(json.dumps(dict(passed=True,regression_finished=done['finished'],full_candidate_admission_file=str(command),admission_file_mtime=command.stat().st_mtime,admission_file_sha256=sha(command),admission=admission['admission'],whole_system_qualified=False),indent=2));add(chronology);add(command);add(finished)
errata=out/'observer-and-admission-limitations.json';errata.write_text(json.dumps(dict(whole_system_qualified=False,node25_1358='Forecast incorrectly specified320; actual replacement32to64 requires352. Guard assertion refused before cancellation.',node25_1359='Correct352 forecast/438.4 threshold refused actual available memory; original exact MemAvailable not persisted before assertion.1389 is a distinct fresh414.285095GiB observation, never substituted as the original value.',readiness1390='6000byte tail missed earlier complete-round counters despite round1/2 progress; ready0 was a false-negative observer, not a routing result.1391 reads full actual logs.',audit1385='Python assert conditional returned None for guided mode, causing an observer-only failure.1391 corrects this context check; original failed receipt preserved, physical gates and route source unchanged.',local_prepare1391='PowerShell nested quote parser failure made no remote change. File-based generator then succeeded.'),indent=2));add(errata)
live=out/'live-route-snapshots';live.mkdir();progress=[]
for tag in [12561,12841,13240,13320,13321,13460,13560,13820]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 if not p.exists():continue
 raw=p.read_bytes();target=live/(str(tag)+'-trial0.log');target.write_bytes(raw);add(target);rs=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:rs.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=tag,original=str(p),immutable_live_prefix=str(target),last_complete_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(rs)if'routed'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)}
with zipfile.ZipFile(str(out/'selected-originals.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
archive=out/'selected-originals.zip';ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Memory refusals preserved without lowering threshold, seven unstarted specs relocated and old5400 retained; freshown6561 and11203 only replaced. Actual13560 process/window/full-prefix proofs;495sample ordinary dense hotspot. New optional guide source1368/1376 fullmanifest/archive/exact backouts, each18defaultbyteexact and16actualguided full small attempts incl all failures; final mode13zero/3fail/413actualmulticast. Actual13820 only after1380, strict7stage6key and16process/input/prefix/node4four16CPU/memoryadmission. Observer1385 and readiness mistakes retained. Running snapshots are not final whole-system physical qualification.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
