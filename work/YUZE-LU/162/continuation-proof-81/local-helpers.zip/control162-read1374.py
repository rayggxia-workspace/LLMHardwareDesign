from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-coarse-refine-regression-1372';rows=[]
for p in(root/'coarse-refine').glob('guided-cost-*/router.log'):
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-6000));lines=f.read().decode(errors='replace').splitlines()
 records=[]
 for l in lines:
  if l.startswith('{'):
   try:records.append(json.loads(l))
   except ValueError:pass
 rows.append(dict(case=p.parent.name,final=(p.parent/'router-output.txt').exists(),last_global=next((x for x in reversed(records)if'conflict_nodes'in x),None),last_guide=next((x for x in reversed(records)if'coarse_refinement_attempts'in x),None),tail=lines[-1]if lines else None))
r=dict(time=time.time(),rows=rows)
if(root/'receipt.json').exists():
 d=json.loads((root/'receipt.json').read_text());r['receipt']=dict(passed=d['passed'],stage=d.get('stage'))
p=b/'dynamic-05/node4/00-a-sready1372-coarse-refine-regression.log'
if p.exists():
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-1800));r['launcher_tail']=f.read().decode(errors='replace')
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);out=Path(__file__).parent/'control162-read1374';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);print(raw.decode())
