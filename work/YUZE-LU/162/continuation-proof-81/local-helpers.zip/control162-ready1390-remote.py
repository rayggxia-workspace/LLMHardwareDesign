from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for i in range(16):
 p=b/'r256-composition-453/upper-candidates/13820/route'/('trial-'+str(i))/'router.log';tail=[]
 if p.exists():
  with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-6000));tail=f.read().decode(errors='replace').splitlines()
 records=[]
 for l in tail:
  if l.startswith('{'):
   try:records.append(json.loads(l))
   except ValueError:pass
 rows.append(dict(trial=i,complete_round=next((r['round']for r in reversed(records)if'conflict_nodes'in r),None),guide=next((r for r in reversed(records)if'coarse_refinement_attempts'in r),None),progress=next((r for r in reversed(records)if'routed'in r),None)))
print(json.dumps(dict(time=time.time(),ready=sum(r['complete_round']is not None for r in rows),trials=rows)))
