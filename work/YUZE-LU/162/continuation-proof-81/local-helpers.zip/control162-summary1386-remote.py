from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for name in ['r256-coarse-refine-regression-1372','r256-coarse-refine-multicast-regression-1380']:
 p=b/name/'coarse-refine/receipt.json';r=json.loads(p.read_text());rows.append(dict(name=name,passed=r['passed'],component=r['component'],default_byteexact=len(r['defaults']),guided_zero=sum(not x['failed']for x in r['cases']),guided_failed=sum(x['failed']for x in r['cases']),changed_paths=sum(x['refinement_changed']for x in r['cases']),multicast_refinements=sum(x.get('refinement_multicast',0)for x in r['cases']),postcutoff=sum(x['refined_after_original_cutoff']for x in r['cases']),rejects=r['rejected'],covered={c:[x['seed']for x in r['cases']if x['cost']==c and not x['failed']and x.get('refinement_multicast',0)>0]for c in[2,8]}))
print(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False)))
