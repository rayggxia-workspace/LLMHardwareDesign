from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'route-selection-102/sready1356-window-resource-fullchain';out=b/'route-selection-102/sready1360-window-resource-transferred';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();tasks=json.loads((old/'tasks.json').read_text())['tasks'];assert len(tasks)==7
assert not(b/'r256-composition-453/upper-candidates/13560').exists()
for row in tasks:
 p=Path(row['path']);assert sha(p)==row['sha256']and p.parent==b/'dynamic-04/node25/pending'
 q=p.parent.parent
 assert not(q/'commands'/p.name).exists()and not(q/'results'/p.name).exists()and p.stem not in json.loads((q/'queue-state.json').read_text())['active']
out.mkdir();held=out/'unstarted-held';held.mkdir();rows=[];moves=[]
for row in tasks:
 p=Path(row['path']);saved=held/p.name;raw=p.read_bytes();p.rename(saved);assert saved.read_bytes()==raw
 spec=json.loads(raw)
 if spec['script']=='system_upper.py':spec['requires'].append(str(b/'r256-final-chain-binding-audit-1361/receipt.json'))
 target=b/'dynamic-02/node3/pending'/p.name.replace('sready1356','sready1360');assert not target.exists();tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(target);rows.append(dict(path=str(target),sha256=sha(target),spec=spec));moves.append(dict(original=str(p),held=str(saved),original_sha256=sha(saved),new=str(target)))
(out/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,scope='Same unstarted13560/window16/source1340 experiment relocated within existing eight parents after node25 new352GiB forecast requires438.4GiB and actual memory rejected. No task or parent cancelled by failed1358/1359. All seven original pending specs byte-preserved in unstarted-held; same config/out/graph/gates. New node3 slot requires fresh exact-own guard and original plus1361 binding before admission.'),indent=2));(out/'transfer.json').write_text(json.dumps(dict(time=time.time(),passed=True,moves=moves,no_old_admission=True,whole_system_qualified=False),indent=2));print(json.dumps(dict(transferred=7,candidate=13560,target_node=3)))
q=b/'dynamic-02/node3';state=json.loads((q/'queue-state.json').read_text());rows=[]
for name in state['active']:
 p=q/'pending'/(name+'.json');s=json.loads(p.read_text());args=s['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='6561':rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1
capture=b/'r256-window-resource-slot-capture-1362';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(target=6561,source=rows[0]['spec']['source_root'],forecast=rows[0]['spec']['forecast_gib'])))
