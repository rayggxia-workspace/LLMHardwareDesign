from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1376';new=b/'source-1396';out=b/'r256-coarse-guide-schedule-source-audit-1398';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();name='project/experiments/control_v1/coarse_refine_regression.py'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='1575c0a8a1e3729220970b8ee2c32d4a7e0eef05'and len(z['files'])==1028
assert{p for p,v in z['files'].items()if a['files'].get(p)!=v}=={name}
expected='75d66d3a1808342a35075f43047cd68bd39d2fc78ff280dc89b966d1be519fd7';assert sha(b/'source1396.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies';p=scratch/name;p.parent.mkdir(parents=True);p.write_bytes((new/name).read_bytes());patch=b/'control162-backout1396.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True);assert p.read_bytes()==(old/name).read_bytes()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1027,one_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only regression helper accepts explicit existing adaptive True/False schedule choice, defaultTrue unchanged. Router C++/wrapper/native/resource/guide/RTL/all final physical gates byteexact to1376. Actual nonadaptive guide combination regression required before full nonadaptive candidate.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1027)))
q=b/'dynamic-05/node2';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());args=s['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='11202':rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1
capture=b/'r256-coarse-guide-schedule-slot-capture-1399';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(target=11202,source=rows[0]['spec']['source_root'])))
