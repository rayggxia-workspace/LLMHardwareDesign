from pathlib import Path
import hashlib,json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'r256-local-diagnostic-binding-1409';assert not out.exists();out.mkdir()
source=b/'source-1396';manifest=json.loads((source/'source-manifest.json').read_text());assert manifest['commit']=='1575c0a8a1e3729220970b8ee2c32d4a7e0eef05'
paths=[b/'r256-composition-453/upper-candidates/14030/route/trial-0/input.txt',b/'r256-composition-453/upper-candidates/14030/route/trial-0/output.txt.global-round-8.txt',b/'r256-composition-453/topology/boundary-graph.json']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={}
for name in ['global_snapshot_analysis.py','router_conflict_snapshot.py','tree_router.cpp','routing_corridor.h']:
 p=source/'project/experiments/control_v1'/name;digest=sha(p);assert digest==manifest['files']['project/experiments/control_v1/'+name];sources[name]=digest
r=dict(time=time.time(),passed=True,whole_system_qualified=False,kind='Bounded metadata and immutable-file hashes only; local workstation performs route diagnostic. No server jobs changed.',commit=manifest['commit'],sources=sources,files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in paths})
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
