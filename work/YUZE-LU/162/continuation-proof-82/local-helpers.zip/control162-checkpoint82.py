from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-82';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-82/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 r=json.loads(z.read('r256-coarse-guide-original-schedule-regression-1400/coarse-refine/receipt.json'));assert r['passed']and r['guided_adaptive']is False and len(r['defaults'])==18 and len(r['cases'])==16 and sum(not x['failed']for x in r['cases'])==12 and sum(x['refinement_multicast']for x in r['cases'])==199
 r=json.loads(z.read('r256-guide-original-schedule-active-audit-1406/receipt.json'));assert r['passed']and len(r['comparisons'])==16 and len(r['pools'])==1
 r=json.loads(z.read('r256-local-diagnostic-binding-1409/local-independent-reception.json'));assert r['passed']and r['conflicts']==1643883 and not r['whole_system_qualified']
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch|txt)$',p.name)
  if m and 1393<=int(m.group(1))<=1410:entries[p.name]=p
for n in ['control162-checkpoint82.py','control162-proof82-remote.py','control162-verify82.py']:
 p=h/n
 if p.is_file():entries[n]=p
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Existing schedule choice regression, exact source audit, owner-only replacement/admission, full actual candidate binding, bounded monitors and local actual-path analysis. No new hardware or relaxed gate.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint82

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)，承接[81](continuation-checkpoint-81.md)。**完整组合仍未获得零冲突、实际几何/PG和low/base/high分布RC300MHz setup/hold/电气联合通过；继续任务，不合并。** 原六宏、R256、S1350内部驱动、23类型138份原生六文件、345状态宿主、453/S5380及M1–M10固定/M11–M12被动边界保留；不动外部R修订及其他任务。

source1396 `1575c0a8a1e3729220970b8ee2c32d4a7e0eef05` 只让已有回归helper显式选择原退火与adaptive策略。1398核对1028文件/1027不变、归档SHA及单文件精确反向补丁；路由C++/wrapper/guide/native/RTL/所有最终门与source1376逐字一致。实际1400在独立16CPU Slurm槽验证原退火：246018独立成员检查、18默认完整运行字节回放、16引导尝试12零/4失败、199多端点细化；四个CLI拒绝和一轮真实失败保留。这些只是小图正确性证据。

1399/1401精确核验本人node2/95341的11202/source1104、specSHA/UID/实际node/PID/全命令/图/全日志/无输出及实际内存后，只替换该子步骤；预测208GiB需265.6GiB实际可用，没有取消父节点或其他任务。1400回归后14030自然补位原七阶段/六键完整验收链，1404严格绑定通过；1406核对16实际进程/完整输入/原native前缀、nonadaptive256/cost8/cut16/stride16/实际细化计数、node2四个互斥16CPU及257GiB预测/324.4GiB实际准入。完整物理结果尚未通过，不能继承小图资格。

本地1408对14030 trial0实际第8轮快照复用原分析器，避免占用额外服务器计算槽。1409/1410独立核对冻结source1396的分析源码及远程不变输入/快照/图SHA：完整11149树连通及受限线长检查通过，但有1643883冲突点，其中跨候选相位普通pair1099035、同相位pair424579、含普通多端点85200、含native35069。它定位真实拥塞，绝非合法最终路由。67622191字节原快照保留在获授权项目存储，外置索引记录路径/字节/SHA；分析与绑定小文件已回存并归档。

本次[远程原字节及源绑定](continuation-proof-82/index.json)有{len(rows)}文件，所有ZIP条目CRC/字节/SHA接收核验通过；[本地辅助材料](continuation-proof-82/local-index.json)有{len(meta)}文件。实际暂存blob核验另外执行。初次1397发布因父1393仍在进行而被精确父检查拒绝、未改ref；待1393实际完成后1397成功精确快进，未强推。所有失败不抹除。

8父节点36×16独立任务动态补位，c96六槽。继续检查13820与14030及保留对照，推进完整零冲突/真实M11–M12/几何/native XOR/PG/三档RC300MHz和声明组合最终六文件、版图、源索引。登记PR5 pending；缺board.json，看板unverified/同步pending，处理人待指定；审查人待指定，Issue in_progress / PR Draft。
'''
(base/'continuation-checkpoint-82.md').write_bytes(doc.encode())
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0
 header=f'''# Issue162：原退火引导候选继续完整物理验收

更新时间：{now}。[Checkpoint82]({prefix}work/YUZE-LU/162/continuation-checkpoint-82.md) / [{len(rows)}份原字节与源索引]({prefix}work/YUZE-LU/162/continuation-proof-82/index.json)。source1396只选择已有回归日程，路由/RTL/全部物理门不变；实际1400原退火16尝试12零/4失败/199多端点，18默认字节回放通过。14030严格七阶段及16实际输入/进程、node2四个16CPU/真实内存准入通过，完整路由仍在运行。

本地复用分析器检查真实全图第8轮：11149树连通/线长预算通过，但1643883跨网冲突；远程快照/输入/图与冻结分析源独立SHA绑定。**仍无完整组合零冲突、实际几何/PG/三档RC300MHz联合通过，不合并，继续任务。** 六宏/R256/S1350/23类138文件/345状态宿主/453/S5380保留，8父节点36×16、c96六独立槽动态，不动其他任务。登记PR5 pending，看板unverified/同步pending（缺board.json），审查待指定。

'''
 p.write_bytes((header+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint81源索引](../work/YUZE-LU/162/continuation-proof-81/index.json)','Checkpoint82源索引](../work/YUZE-LU/162/continuation-proof-82/index.json)');marker='本轮追加可选的普通候选搜索切换轮次8/16/32';at=s.index(marker);s=s[:at]+'source1396只为回归显式选择已有原退火；1400实际通过后14030进入完整七阶段，1404/1406真实输入/进程/资源通过。1408实际11149树第8轮仍有1643883冲突，远程SHA与冻结分析源独立绑定；无最终系统资格，见[Checkpoint82](../work/YUZE-LU/162/continuation-checkpoint-82.md)。\n\n'+s[at:];p.write_bytes(s.encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
