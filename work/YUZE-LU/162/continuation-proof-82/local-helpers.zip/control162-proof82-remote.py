from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-82';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file() and f.name not in ['router','corridor-test'] and f.stat().st_size<8000000:add(f)
for name in ['r256-coarse-guide-schedule-source-audit-1398','r256-coarse-guide-original-schedule-regression-1400','r256-final-chain-binding-audit-1404','r256-guide-original-schedule-active-audit-1406','r256-local-diagnostic-binding-1409']:
 assert json.loads((b/name/'receipt.json').read_text())['passed'];shallow(b/name)
shallow(b/'r256-coarse-guide-schedule-slot-capture-1399')
root=b/'r256-coarse-guide-original-schedule-regression-1400/coarse-refine';r=json.loads((root/'receipt.json').read_text());assert r['passed'] and r['guided_adaptive']is False and len(r['defaults'])==18 and len(r['cases'])==16 and sum(not x['failed']for x in r['cases'])==12 and sum(x['refinement_multicast']for x in r['cases'])==199;shallow(root)
for p in root.iterdir():
 if p.is_dir():shallow(p)
for name in ['sready1400-coarse-guide-original-schedule-regression','sready1401-coarse-guide-schedule-regression-refill','sready1403-guide-original-schedule-fullchain']:
 p=b/'route-selection-102'/name;shallow(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for n in ['source-manifest.json','freeze-import.json']:add(b/'source-1396'/n)
for n in ['config1400.json','control162-backout1396.patch']:add(b/n)
out.mkdir();live=out/'live-route-snapshots';live.mkdir();progress=[]
for tag in [12561,12841,13240,13320,13321,13460,13560,13820,14030]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 if not p.exists():continue
 raw=p.read_bytes();dst=live/(str(tag)+'-trial0.log');dst.write_bytes(raw);add(dst);rs=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:rs.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=tag,original=str(p),immutable_prefix=str(dst),last_complete_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(rs)if'routed'in r),None),whole_system_qualified=False))
(out/'live-progress.json').write_text(json.dumps(progress,indent=2));add(out/'live-progress.json')
for name in ['r256-guided-progress-observations-1405','r256-all-pool-watch-1407']:
 for p in (b/name).glob('*.json'):add(p)
binding=json.loads((b/'r256-local-diagnostic-binding-1409/local-independent-reception.json').read_text());assert binding['passed'] and binding['conflicts']==1643883 and not binding['whole_system_qualified']
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)}
archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),external_immutable_files=json.loads((b/'r256-local-diagnostic-binding-1409/receipt.json').read_text())['files'],scope='Source1396 helper-only schedule choice, actual1400 nonadaptive16cases12zero4fail199multicast plus18default byteexact. Full14030 strict7/actual16input-process-node2fourmasks-memory checks and live route prefixes; no final routing or system physical qualification. Local actual full-round8 diagnostic independently remote/source-bound, all11149trees flood/budget checked but1643883conflicts. Large raw snapshot remains at indexed authorized project storage; no jobs changed by local diagnostic.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
