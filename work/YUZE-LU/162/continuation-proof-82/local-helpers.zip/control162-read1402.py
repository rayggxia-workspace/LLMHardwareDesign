from pathlib import Path
import subprocess,shlex,json,time
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-coarse-guide-original-schedule-regression-1400';r=dict(time=time.time(),receipt=None)
p=root/'coarse-refine/receipt.json'
if p.exists():
 d=json.loads(p.read_text());r.update(passed=d['passed'],guided_adaptive=d['guided_adaptive'],component=d['component'],zero=sum(not x['failed']for x in d['cases']),failed=sum(x['failed']for x in d['cases']),multicast_refinements=sum(x['refinement_multicast']for x in d['cases']),defaults=len(d['defaults']),postcutoff=sum(x['refined_after_original_cutoff']for x in d['cases']))
p=root/'receipt.json'
if p.exists():
 d=json.loads(p.read_text());r['receipt']=dict(passed=d['passed'],stage=d.get('stage'))
p=b/'dynamic-05/node2/00-a-sready1400-coarse-guide-original-schedule-regression.log'
if p.exists():
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-2000));r['launcher_tail']=f.read().decode(errors='replace')
print(json.dumps(r))
'''
raw=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);out=Path(__file__).parent/'control162-read1402';out.mkdir(exist_ok=True);(out/(str(time.time_ns())+'.json')).write_bytes(raw);print(raw.decode())
