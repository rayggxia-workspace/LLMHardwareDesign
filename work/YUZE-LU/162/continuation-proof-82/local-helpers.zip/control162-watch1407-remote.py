from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');pools=[];receipts=[]
for folder,slots in [('dynamic-05/node2',4),('dynamic-02/node3',4),('dynamic-05/node4',4),('dynamic-03/node5',4),('dynamic-08/node6',4),('dynamic-07/node7',4),('dynamic-04/node25',6),('dynamic-06/node26',6)]:
 q=b/folder;state=json.loads((q/'queue-state.json').read_text());active=[]
 for n in state['active']:
  p=q/'pending'/(n+'.json');s=json.loads(p.read_text());a=s['args'];out=Path(a[a.index('--out')+1])if'--out'in a else None
  row=dict(name=n,script=s['script'],source=s['source_root'],forecast=s['forecast_gib'],out=str(out)if out else None)
  if out:
   row['final_router_output']=(out/'router-output.txt').exists()
   for name in ['receipt.json','joint-system-audit.json','final-composition-audit.json']:
    r=out/name
    if r.is_file():
     d=json.loads(r.read_text());receipts.append(dict(path=str(r),passed=d.get('passed'),stage=d.get('stage'),whole_system_qualified=d.get('whole_system_qualified')))
  active.append(row)
 pools.append(dict(queue=str(q),active_count=len(active),slot_limit=slots,forecast_gib=sum(x['forecast']for x in active),scripts=[x['script']for x in active],active=active))
r=dict(time=time.time(),whole_system_qualified=False,pools=pools,receipts=receipts,scope='Read-only controller inventory of the same eight owned pools; final-file flags and receipt fields only, not inferred physical qualification. No queued/active task changed.')
out=b/'r256-all-pool-watch-1407';out.mkdir(exist_ok=True);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(dict(time=r['time'],active=sum(x['active_count']for x in pools),pools=[{k:v for k,v in x.items()if k!='active'}for x in pools],receipts=receipts,route_outputs=[x['out']for p in pools for x in p['active']if x.get('final_router_output')])))
