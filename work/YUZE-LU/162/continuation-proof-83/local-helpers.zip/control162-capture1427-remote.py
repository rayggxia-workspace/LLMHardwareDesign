from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-08/node6';rows=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((b/'r256-guide-history-source-audit-1414/receipt.json').read_text())['passed']
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());a=s['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='11200':
  assert s['source_root']==str(b/'source-1104');rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1;out=b/'r256-guide-history-original-slot-capture-1427';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print('Captured exact own11200/node6/source1104 spec')
