from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-83';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-83/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 for name,adaptive,multicast in [('r256-guide-history-regression-1416',True,315),('r256-guide-history-original-schedule-regression-1428',False,287)]:
  r=json.loads(z.read(name+'/coarse-refine/receipt.json'));assert r['passed']and r['guided_adaptive']is adaptive and r['guided_history_product']is True and len(r['defaults'])==18 and len(r['cases'])==16 and all(not c['failed']for c in r['cases'])and sum(c['refinement_multicast']for c in r['cases'])==multicast
 for name in ['r256-guide-history-active-audit-1424','r256-guide-history-original-active-audit-1433']:
  r=json.loads(z.read(name+'/receipt.json'));assert r['passed']and len(r['comparisons'])==16 and len(r['pools'])==1
 c=json.loads(z.read('continuation-proof-83/actual-regression-before-full-admission.json'));assert c['passed']and len(c['chains'])==2 and all(c['regression_finished']<=c['admission_mtime']for c in c['chains'])
 assert json.loads(z.read('route-selection-102/sready1417-guide-history-regression-refill/reason-text-erratum.json'))['passed']
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch|txt)$',p.name)
  if m and 1412<=int(m.group(1))<=1435:entries[p.name]=p
for n in ['control162-checkpoint83.py','control162-proof83-remote.py','control162-verify83.py']:
 p=h/n
 if p.is_file():entries[n]=p
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Existing history pressure combinations, exact immutable source audit, original reason typo plus separate erratum, two own-only replacements, actual32 full candidate input/process/memory proofs. No relaxed gate or new hardware.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint83

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)，承接[82](continuation-checkpoint-82.md)。**完整组合尚无零冲突、实际几何/PG及low/base/high分布RC300MHz setup/hold/电气联合通过，继续任务，不合并。** main六宏/R256/S1350内部驱动、23类型138份原生六文件、345状态宿主、453/S5380及M1–M10固定/M11–M12被动边界保留；不动外部R修订和其他任务。

source1412 `a4cab58ffdb118a8ccd1441cfa8cead01912e4ac` 仅让回归helper显式选择已存在的history_product，默认False保留。1414实际核对全部1028文件/1027不变、归档SHA `8156a5b8559fde3f008960f7610e5c9f67f85b7be9006a198669b87ae8bd6f73`、单文件精确反向补丁。所有路由生产代码、native有限求解、RTL、几何/PG/三档RC/最终门逐字不变；没有新增硬件或放宽物理条件。历史惩罚会改变搜索代价及后续路径，不宣称native后续轨迹不变。

实际1416在原16CPU槽完成adaptive+history_product+guide：16完整小图全部零冲突、315多端点细化，18默认完整字节回放、246018独立成员检查、4CLI拒绝和一轮真实失败通过。实际1428在另一原16CPU槽完成originalannealing+history_product+guide：同16小图全部零冲突、287多端点细化，同18默认回放/246018成员/4CLI拒绝/单轮失败通过。它们是组合正确性和覆盖证据，不能外推完整全图收敛或物理通过。

仅精确核验并替换本人13820/node4/source1376步骤95391.141及11200/node6/source1104步骤97097.71。两次均保留原spec/源/图/全部日志和部分输出，核对fresh specSHA/UID/job/实际node/PID/全命令/无最终输出/实际内存。回归槽预测208GiB需265.6GiB可用；未增加父节点。1417的说明字符串误留旧1401的11202/node2文字，原件未改；1419按原SHA记录勘误，执行断言、结构化target/command/spec和实际取消均为13820/node4/source1376，不能用错误说明冒充另一次操作。

14220（adaptive）与14310（原退火）各在真实回归完成后自然补位原七阶段/六键完整物理链，1423/1432严格绑定当前453/345实例/R256、原三初态八程序/473-480轨迹、各自未来路由/几何/PG/low-base-high/交付路径。1424/1433实际核对合计32进程/32完整输入、相对各自无乘积对照只改变输入头history位、原9060前缀逐字一致、node4/node6各四个互斥16CPU及257GiB预测/324.4GiB实际准入；原生树复用正确性不等于全图合法。真实controller回归finished早于完整链admission的原文件/时间/SHA已保存，未跳过前置条件。

[{len(rows)}份远程原字节/源绑定](continuation-proof-83/index.json)及[{len(meta)}份本地辅助材料](continuation-proof-83/local-index.json)全部ZIP条目CRC/字节/SHA接收核验通过；实际暂存blob核验另行执行。完整物理仍未通过；保留14030对照，不从本检查点收尾。8父节点36×16动态补位，c96六独立槽，不操作父节点/foreign/外部R/CUGR，不降低内存门。继续全图拥塞收敛和真实M11/M12、几何/native XOR/PG/三档RC300MHz、全部声明组合最终六文件/版图/源索引。

规则rayggxia-project-collab1.0.0；Issue in_progress / PR Draft，审查人待指定。登记PR5 pending；缺board.json，看板unverified/同步pending，处理人待指定。
'''
(base/'continuation-checkpoint-83.md').write_bytes(doc.encode())
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0
 header=f'''# Issue162：已有历史惩罚的两项组合回归通过，完整布局布线继续

更新时间：{now}。[Checkpoint83]({prefix}work/YUZE-LU/162/continuation-checkpoint-83.md) / [{len(rows)}份原字节源绑定]({prefix}work/YUZE-LU/162/continuation-proof-83/index.json)。source1412只让回归选择已有history_product，生产路由/native/RTL/全部物理门不变；1414全源/归档/精确回退通过。实际1416/1428分别adaptive/原退火，两组各16完整小图零冲突、315/287多端点细化及18默认字节回放通过。

14220/14310在各自实际回归完成后自然进入原七阶段，严格14规格及32实际输入/进程/原生前缀、两个node各四组16CPU/实际内存准入通过。原守卫1417说明文字错误与SHA绑定勘误均保存。**仍无完整全图零冲突、实际几何/PG/三档RC300MHz联合通过，继续任务，不合并。** 六宏/R256/S1350/23类138文件/345状态宿主/453/S5380保留；8父节点36×16动态，c96六槽，不动其他任务。登记PR5 pending，看板unverified/同步pending，审查待指定。

''';p.write_bytes((header+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint82源索引](../work/YUZE-LU/162/continuation-proof-82/index.json)','Checkpoint83源索引](../work/YUZE-LU/162/continuation-proof-83/index.json)');marker='本轮追加可选的普通候选搜索切换轮次8/16/32';at=s.index(marker);s=s[:at]+'source1412仅使回归显式选择已有history_product。1416/1428各16实际小图零冲突后，14220/14310进入原完整七阶段；32真实输入/进程/前缀、两个node四组16CPU/实际内存及真实回归早于准入通过。尚无完整物理资格，见[Checkpoint83](../work/YUZE-LU/162/continuation-checkpoint-83.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;header='''# Issue162：已有历史惩罚组合的已验证复现入口

当前453/345实例/23类型/R256/S1350，完整系统物理尚未通过。冻结并核验source1412后，在独立16CPU Slurm/ORFS槽执行 `python3 <source>/project/experiments/control_v1/system_upper.py --manifest <359/selected/physical.json> --graph <453/topology/boundary-graph.json> --coarse-refine-regression-config <config1416.json或config1428.json> --out <新目录>`。1416设置guided_adaptive=true/guided_history_product=true；1428设置false/true，均绑定原1340/1344及1252真实fixture。实际各16完整小图零冲突、315/287多端点细化，18默认字节回放/246018成员检查/非法拒绝/真实单轮失败通过。

生产代码不变，完整候选只组合已有 `--route-ordinary-coarse-refine --multiply-congestion-history`，14220保留adaptive，14310使用原退火。实际回归完成后各进入原七阶段，14规格/六键及32真实进程/输入/前缀、两node各四个16CPU和257GiB预测/324.4GiB实际准入通过；这些不授予最终零冲突、几何/PG/三档分布RC300MHz或系统资格。8父节点/c96六槽动态补位，证据见[Checkpoint83](../work/YUZE-LU/162/continuation-checkpoint-83.md)。

''';p.write_bytes((header+s[at+1:]).encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
