from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-progress1405-remote.py').read_text(encoding='utf-8').replace('[13820,14030]','[14030,14220]').replace('r256-guided-progress-observations-1405','r256-guide-history-progress-observations-1425');compile(s,'progress1425','exec');(h/'control162-progress1425-remote.py').write_bytes(s.encode())
