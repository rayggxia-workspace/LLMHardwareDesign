from pathlib import Path
import re
h=Path(__file__).parent
s="""from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-08/node6';rows=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((b/'r256-guide-history-source-audit-1414/receipt.json').read_text())['passed']
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());a=s['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='11200':
  assert s['source_root']==str(b/'source-1104');rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1;out=b/'r256-guide-history-original-slot-capture-1427';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print('Captured exact own11200/node6/source1104 spec')
"""
compile(s,'capture1427','exec');(h/'control162-capture1427-remote.py').write_bytes(s.encode())
s=(h/'control162-queue1400-remote.py').read_text(encoding='utf-8')
for a,b in [('r256-coarse-guide-schedule-source-audit-1398','r256-guide-history-source-audit-1414'),('r256-coarse-refine-multicast-regression-1380','r256-guide-history-regression-1416'),('r256-coarse-guide-original-schedule-regression-1400','r256-guide-history-original-schedule-regression-1428'),('sready1400-coarse-guide-original-schedule-regression','sready1428-guide-history-original-regression'),('dynamic-05/node2','dynamic-08/node6'),('config1400.json','config1428.json'),('config1380.json','config1416.json'),('source-1396','source-1412')]:s=s.replace(a,b)
s=s.replace("cfg['guided_adaptive']=False","cfg['guided_adaptive']=False;cfg['guided_history_product']=True")
s=s.replace('Existing original annealing schedule plus actual guide/multicast paths, explicitFalse.','Existing original annealing plus history_product=True and actual guide/multicast paths.').replace('freshown11202','freshown11200/node6').replace('actual1400passed','actual1428passed')
compile(s,'queue1428','exec');(h/'control162-queue1428-remote.py').write_bytes(s.encode())
s=(h/'control162-refill1417-remote.py').read_text(encoding='utf-8')
for a,b in [('sready1417-guide-history-regression-refill','sready1429-guide-history-original-refill'),('sready1416-guide-history-regression','sready1428-guide-history-original-regression'),('r256-guide-history-slot-capture-1415','r256-guide-history-original-slot-capture-1427')]:s=s.replace(a,b)
s=s.replace("(4,95391,'dynamic-05/node4',13820,'source-1376',0,208,265.6)","(6,97097,'dynamic-08/node6',11200,'source-1104',0,208,265.6)")
s,count=re.subn(r"reason='[^']*'","reason='Fresh exact own11200/source1104 partial only,1427 specSHA/UID/job97097/actualnode6/PID/fullcmd/source/out/current453/alllogs/nooutput and actual265.6GiB for208GiB forecast. Frozen1412 changes only test helper; all router/native/macro/gate code unchanged. Actual originalannealing plus history_product and guide regression1428 only, no full candidate before actual pass. All original evidence/other tasks/parents/externalR/CUGR preserved.'",s);assert count==1
compile(s,'refill1429','exec');(h/'control162-refill1429-remote.py').write_bytes(s.encode())
s=(h/'control162-read1418-remote.py').read_text(encoding='utf-8').replace('r256-guide-history-regression-1416','r256-guide-history-original-schedule-regression-1428').replace('dynamic-05/node4/00-a-sready1416-guide-history-regression.log','dynamic-08/node6/00-a-sready1428-guide-history-original-regression.log').replace('r256-guide-history-observations-1418','r256-guide-history-original-observations-1430');compile(s,'read1430','exec');(h/'control162-read1430-remote.py').write_bytes(s.encode());print('Prepared existing originalannealing+history combination in same8 parents, one exact own11200 slot only')
