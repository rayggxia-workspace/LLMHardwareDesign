from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-progress1425-remote.py').read_text(encoding='utf-8').replace('[14030,14220]','[14030,14220,14310]').replace('r256-guide-history-progress-observations-1425','r256-guide-three-mode-progress-1435');compile(s,'progress1435','exec');(h/'control162-progress1435-remote.py').write_bytes(s.encode())
