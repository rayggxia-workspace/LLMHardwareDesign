from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-83';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','corridor-test']and f.stat().st_size<8000000:add(f)
for name in ['r256-guide-history-source-audit-1414','r256-final-chain-binding-audit-1423','r256-guide-history-active-audit-1424','r256-final-chain-binding-audit-1432','r256-guide-history-original-active-audit-1433']:
 assert json.loads((b/name/'receipt.json').read_text())['passed'];shallow(b/name)
for name in ['r256-guide-history-slot-capture-1415','r256-guide-history-original-slot-capture-1427']:shallow(b/name)
for name,adaptive,multicast in [('r256-guide-history-regression-1416',True,315),('r256-guide-history-original-schedule-regression-1428',False,287)]:
 assert json.loads((b/name/'receipt.json').read_text())['passed'];shallow(b/name);root=b/name/'coarse-refine';r=json.loads((root/'receipt.json').read_text());assert r['passed']and r['guided_adaptive']is adaptive and r['guided_history_product']is True and len(r['defaults'])==18 and len(r['cases'])==16 and all(not x['failed']for x in r['cases'])and sum(x['refinement_multicast']for x in r['cases'])==multicast and r['component']['independent_membership_checks']==246018 and len(r['rejected'])==4;shallow(root)
 for p in root.iterdir():
  if p.is_dir():shallow(p)
for name in ['sready1416-guide-history-regression','sready1417-guide-history-regression-refill','sready1422-guide-history-fullchain','sready1428-guide-history-original-regression','sready1429-guide-history-original-refill','sready1431-guide-history-original-fullchain']:
 root=b/'route-selection-102'/name;shallow(root)
 if(root/'tasks.json').exists():
  for row in json.loads((root/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for n in ['source-manifest.json','freeze-import.json']:add(b/'source-1412'/n)
for n in ['config1416.json','config1428.json','control162-backout1412.patch','control162-audit1414-remote.py','control162-refill1417-remote.py','control162-refill1429-remote.py']:add(b/n)
out.mkdir();chronology=[]
for audit,seed,folder,label in [('r256-guide-history-active-audit-1424',14220,'dynamic-05/node4','00-a-sready1416-guide-history-regression'),('r256-guide-history-original-active-audit-1433',14310,'dynamic-08/node6','00-a-sready1428-guide-history-original-regression')]:
 actual=json.loads((b/audit/'receipt.json').read_text());a=next(x for x in actual['actual_admissions']if x['seed']==seed);command=Path(a['path']);finished=b/folder/'results'/(label+'.json');d=json.loads(finished.read_text());assert d['returncode']==0 and d['finished']<=command.stat().st_mtime and a['admission']['forecast_gib']==257 and abs(a['admission']['required_bytes']/1024**3-324.4)<.000001;add(command);add(finished);chronology.append(dict(passed=True,candidate=seed,regression_finished=d['finished'],full_admission_file=str(command),admission_mtime=command.stat().st_mtime,admission_sha256=sha(command),admission=a['admission']))
p=out/'actual-regression-before-full-admission.json';p.write_text(json.dumps(dict(passed=True,whole_system_qualified=False,chains=chronology),indent=2));add(p)
live=out/'live-route-snapshots';live.mkdir();progress=[]
for seed in [14030,14220,14310]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route/trial-0/router.log';raw=p.read_bytes();dst=live/(str(seed)+'-trial0.log');dst.write_bytes(raw);add(dst);rs=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:rs.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=seed,original=str(p),immutable_prefix=str(dst),last_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(rs)if'routed'in r),None),whole_system_qualified=False))
p=out/'live-progress.json';p.write_text(json.dumps(progress,indent=2));add(p)
for name in ['r256-guide-history-observations-1418','r256-guide-history-original-observations-1430','r256-guide-history-progress-observations-1425','r256-guide-three-mode-progress-1435']:
 for p in (b/name).glob('*.json'):add(p)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)}
archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Frozen1412 helper only selects existing history_product. Full source/archive/scratch backout verified, production/native/RTL/all gates unchanged. Actual adaptive and originalannealing guided-history combinations each16smallzero/18defaultbyteexact/246018component checks,315/287multicast. Two exact own partial replacements only, original1417 reason typo+1419 SHA-bound erratum preserved. Actual full14220/14310 strict7stage6key and32realinputs/processes/two node4x16/memory+real prerequisite chronology. Running full route prefixes are NOT final zero-conflict, geometry/PG/3RC300MHz or system qualification.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
