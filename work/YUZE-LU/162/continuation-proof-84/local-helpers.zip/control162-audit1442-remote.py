from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1412';new=b/'source-1440';out=b/'r256-guide-batch-source-audit-1442';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();name='project/experiments/control_v1/coarse_refine_regression.py'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='5b3023600afc49fc76366177c45838feceaeed3d'and len(z['files'])==1028
assert{p for p,v in z['files'].items()if a['files'].get(p)!=v}=={name}
expected='7a9de1ad9d54881b7d0a363ed6ad3e6dbb8df981aaa6483f972135e4e88b3a45';assert sha(b/'source1440.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies';p=scratch/name;p.parent.mkdir(parents=True);p.write_bytes((new/name).read_bytes());patch=b/'control162-backout1440.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True);assert p.read_bytes()==(old/name).read_bytes()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1027,one_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only regression helper selects existing global_batch_ripup for guided attempts, defaultFalse unchanged, and observes actual combined dirty trees. Router C++/wrapper/native/resource/guide/RTL/all final physical gates byteexact to1412. Actual guided batch combination regression required before full candidate.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1027)))
q=b/'dynamic-05/node4';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());args=s['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='14220':rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1
capture=b/'r256-guide-batch-slot-capture-1443';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(target=14220,source=rows[0]['spec']['source_root'])))
