from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-84';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-84/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 r=json.loads(z.read('r256-guide-batch-regression-1444/coarse-refine/receipt.json'));assert r['passed']and r['guided_adaptive']is False and r['guided_history_product']is False and r['guided_global_batch']is True and len(r['defaults'])==18 and len(r['cases'])==16 and sum(not c['failed']for c in r['cases'])==13 and sum(c['refinement_multicast']for c in r['cases'])==133
 a=json.loads(z.read('r256-guide-batch-active-audit-1449/receipt.json'));assert a['passed']and len(a['comparisons'])==16 and len(a['pools'])==1
 c=json.loads(z.read('continuation-proof-84/actual-regression-before-full-admission.json'));assert c['passed']and c['regression_finished']<=c['admission_mtime']
 failed=[n for n in z.namelist()if n.startswith(('r256-composition-453/upper-candidates/14220/','r256-composition-453/upper-candidates/14310/'))and n.endswith('/router.log')];assert len(failed)>=6 and all(z.read(n).splitlines()[-1]==b'finite-resource search label memory envelope exhausted'for n in failed)
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch|txt)$',p.name)
  if m and 1436<=int(m.group(1))<=1450:entries[p.name]=p
for n in ['control162-checkpoint84.py','control162-proof84-remote.py','control162-verify84.py','control162-git-data-publish-1436/receipt.json','control162-git-data-publish-1441/receipt.json']:
 p=h/n
 if p.is_file():entries[n]=p
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Actual history label-cap failures, frozen helper-only batch choice, old default replay, owner-only replacement, actual full candidate admission and source publications. No physical threshold or native memory envelope raised.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint84

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)，承接[83](continuation-checkpoint-83.md)。**仍无完整组合零冲突、实际几何/PG及low/base/high分布RC300MHz setup/hold/电气联合通过，继续布局布线，不合并。** 六宏/R256/S1350内部驱动、23类型138份原生六文件、345状态宿主、453/S5380、M1–M10固定/M11–M12被动边界保留；不动外部R和其他任务。

两项乘积历史候选实际出现6份 `finite-resource search label memory envelope exhausted`。1437保存日志原SHA；本包逐字接收6份完整失败日志并核对原SHA。它是搜索标签内存上限，不是物理不可行证明；没有提高上限或放宽线长、电容、时序门。其余尝试与全部原件保留。

source1440 `5b3023600afc49fc76366177c45838feceaeed3d` 只让回归选择已有global_batch_ripup，并检查实际native/ordinary冲突旧树共同撤除；默认False保留。1442全部1028源/归档SHA `7a9de1ad9d54881b7d0a363ed6ad3e6dbb8df981aaa6483f972135e4e88b3a45`/单文件精确反向补丁通过；1027生产路由/native/RTL/所有最终门与1412逐字不变。真实1444原退火+加法历史+batch+guide：18默认完整字节回放、246018独立成员检查、16完整小图13零/3失败、133多端点细化、4CLI拒绝/真实单轮失败及实际两类脏树共同撤除通过。3个小图失败保留，不能外推全图收敛。

1443/1445仅经fresh specSHA/UID/job/实际node/PID/全命令/源/当前图/全日志/无最终输出/实际内存守卫替换本人14220/source1412步骤95391.146，父节点、其他任务、外部R/CUGR均未操作。回归槽总预测208GiB需265.6GiB实际可用，原件全部保留。14470在真实1444完成后自然补位原七阶段，1448严格7规格/六键/当前函数与未来三档RC路径通过；1449实际16进程/完整17字段输入头相对14030逐字一致、原native前缀逐字一致、实际两类脏树撤除、node4四个互斥16CPU与257GiB预测/324.4GiB实际准入通过。controller真实回归finished早于full admission的文件/时间/SHA已实收。它仍须独立完成真实整图零冲突及全部最终物理门。

[{len(rows)}份原字节源绑定](continuation-proof-84/index.json)和[{len(meta)}份辅助材料](continuation-proof-84/local-index.json)全部ZIP CRC/字节/SHA接收通过，实际暂存blob另行核验。保留14030与14310对照，继续定位拥塞和完成最终六文件/版图/声明组合及源绑定，不在本检查点收尾。8父节点36×16动态、c96六槽，未降低并发或内存门。

规则rayggxia-project-collab1.0.0；Issue in_progress / PR Draft，审查待指定。登记PR5 pending；缺board.json，看板unverified/同步pending，处理人待指定。
''';(base/'continuation-checkpoint-84.md').write_bytes(doc.encode())
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0
 header=f'''# Issue162：保留搜索失败，验证共同撤线的真实组合

更新时间：{now}。[Checkpoint84]({prefix}work/YUZE-LU/162/continuation-checkpoint-84.md) / [{len(rows)}份原字节源绑定]({prefix}work/YUZE-LU/162/continuation-proof-84/index.json)。6份真实乘积历史标签内存上限失败日志按原SHA完整接收，不提高上限、不当作物理不可行证明。source1440仅让回归选择已有batch策略，1027项生产/native/RTL/全部物理门不变；全源/归档/反向补丁通过。

实际1444加法历史/原退火/batch/guide：16小图13零3失败/133多端点、18默认回放和真实两类脏树撤除通过。14470严格七阶段及16真实输入头/前缀/进程、node4四组16CPU/实际内存/真实前置完成时间通过。**仍无整图零冲突、实际几何/PG/三档RC300MHz联合通过，继续任务，不合并。** 六宏/R256/S1350/23类138文件/345宿主/453/S5380保留；8父节点36×16、c96六槽，不动其他任务。登记PR5 pending，看板unverified/同步pending，审查待指定。

''';p.write_bytes((header+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint83源索引](../work/YUZE-LU/162/continuation-proof-83/index.json)','Checkpoint84源索引](../work/YUZE-LU/162/continuation-proof-84/index.json)');at=s.index('本轮追加可选的普通候选搜索切换轮次8/16/32');s=s[:at]+'source1440仅为回归选择已有global_batch_ripup。1444实际13零/3失败及真实两类脏树共同撤除通过后，14470进入原七阶段；16真实输入/进程/前缀、四组16CPU/内存/前置完成时间通过。6份乘积历史标签上限失败按原SHA保留；无系统物理资格，见[Checkpoint84](../work/YUZE-LU/162/continuation-checkpoint-84.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;header='''# Issue162：已有共同撤线组合的已验证复现入口

当前453/345实例/23类型/R256/S1350，完整系统物理尚未通过。冻结并核验source1440后，在独立16CPU Slurm/ORFS槽执行 `python3 <source>/project/experiments/control_v1/system_upper.py --manifest <359/selected/physical.json> --graph <453/topology/boundary-graph.json> --coarse-refine-regression-config <config1444.json> --out <新目录>`。配置guided_adaptive=false/guided_history_product=false/guided_global_batch=true，绑定原1340/1344/1252真实fixture。实际18默认字节回放、246018成员、16小图13零3失败/133多端点、真实两类脏树撤除、拒绝及单轮失败通过。

生产代码不变，14470使用已有 `--route-ordinary-coarse-refine --route-global-batch-ripup`，保留原退火和加法历史。真实回归后执行原七阶段，严格7规格/六键及16实际输入头相对14030逐字一致、前缀/进程/两类撤线/node4四个16CPU、257GiB预测/324.4GiB实际准入通过。它不继承小图资格，仍须完成真实整图零冲突、几何/PG/三档分布RC300MHz及交付。8父节点/c96六槽动态保持，见[Checkpoint84](../work/YUZE-LU/162/continuation-checkpoint-84.md)。

''';p.write_bytes((header+s[at+1:]).encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
