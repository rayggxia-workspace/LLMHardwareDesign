from pathlib import Path
import json,time,hashlib
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [14220,14310]:
 for p in sorted((b/'r256-composition-453/upper-candidates'/str(tag)/'route').glob('trial-*/router.log')):
  with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-3000));tail=f.read().decode(errors='replace')
  last=tail.splitlines()[-1]if tail.splitlines()else ''
  if last.startswith(('finite-resource','Locked-source','disconnected','coarse-guided','negotiation did not converge')):rows.append(dict(candidate=tag,path=str(p),bytes=size,tail=tail,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
out=b/'r256-guide-history-failures-1437';out.mkdir(exist_ok=True);r=dict(time=time.time(),whole_system_qualified=False,failures=rows);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
