from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-progress1435-remote.py').read_text(encoding='utf-8').replace('[14030,14220,14310]','[14030,14310,14470]').replace('r256-guide-three-mode-progress-1435','r256-guide-batch-mode-progress-1450');compile(s,'progress1450','exec');(h/'control162-progress1450-remote.py').write_bytes(s.encode())
