from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-84';assert not out.exists();selected=set();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','corridor-test']and f.stat().st_size<8000000:add(f)
for n in ['r256-guide-batch-source-audit-1442','r256-guide-batch-regression-1444','r256-final-chain-binding-audit-1448','r256-guide-batch-active-audit-1449']:
 assert json.loads((b/n/'receipt.json').read_text())['passed'];shallow(b/n)
shallow(b/'r256-guide-batch-slot-capture-1443')
root=b/'r256-guide-batch-regression-1444/coarse-refine';r=json.loads((root/'receipt.json').read_text());assert r['passed']and r['guided_adaptive']is False and r['guided_history_product']is False and r['guided_global_batch']is True and len(r['defaults'])==18 and len(r['cases'])==16 and sum(not c['failed']for c in r['cases'])==13 and sum(c['refinement_multicast']for c in r['cases'])==133 and any(t['global_batch_native_trees']>0 and t['global_batch_ordinary_trees']>0 for c in r['cases']for t in c['global_batch_trace']);shallow(root)
for p in root.iterdir():
 if p.is_dir():shallow(p)
for n in ['sready1444-guide-batch-regression','sready1445-guide-batch-regression-refill','sready1447-guide-batch-fullchain']:
 root=b/'route-selection-102'/n;shallow(root)
 if(root/'tasks.json').exists():
  for row in json.loads((root/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for n in ['source-manifest.json','freeze-import.json']:add(b/'source-1440'/n)
for n in ['config1444.json','control162-backout1440.patch','control162-audit1442-remote.py','control162-refill1445-remote.py']:add(b/n)
failures=[]
for p in (b/'r256-guide-history-failures-1437').glob('*.json'):
 add(p)
 for row in json.loads(p.read_text())['failures']:
  f=Path(row['path']);assert sha(f)==row['sha256'];assert f.read_text().splitlines()[-1]=='finite-resource search label memory envelope exhausted';add(f);failures.append(row)
assert len(failures)>=6
out.mkdir();actual=json.loads((b/'r256-guide-batch-active-audit-1449/receipt.json').read_text());a=next(x for x in actual['actual_admissions']if x['seed']==14470);command=Path(a['path']);finished=b/'dynamic-05/node4/results/00-a-sready1444-guide-batch-regression.json';d=json.loads(finished.read_text());assert d['returncode']==0 and d['finished']<=command.stat().st_mtime and a['admission']['forecast_gib']==257;add(command);add(finished)
p=out/'actual-regression-before-full-admission.json';p.write_text(json.dumps(dict(passed=True,whole_system_qualified=False,candidate=14470,regression_finished=d['finished'],admission_mtime=command.stat().st_mtime,admission_path=str(command),admission_sha256=sha(command),admission=a['admission']),indent=2));add(p)
live=out/'live-route-snapshots';live.mkdir();progress=[]
for tag in [14030,14310,14470]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log';raw=p.read_bytes();dst=live/(str(tag)+'-trial0.log');dst.write_bytes(raw);add(dst);rs=[]
 for line in raw.decode().splitlines():
  if line.startswith('{'):
   try:rs.append(json.loads(line))
   except ValueError:pass
 progress.append(dict(candidate=tag,original=str(p),immutable_prefix=str(dst),last_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),whole_system_qualified=False))
p=out/'live-progress.json';p.write_text(json.dumps(progress,indent=2));add(p)
for n in ['r256-guide-batch-observations-1446','r256-guide-batch-mode-progress-1450']:
 for p in (b/n).glob('*.json'):add(p)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='At least6 actual global-history finite-resource label envelope failures raw logs independently exact1437SHA retained; no physical infeasibility inference or raised limit. Source1440 helper-only existing globalbatch switch, all1028/archive/backout verified,1027production/native/RTL/gates unchanged. Actual1444 additive/originalannealing/batch/guide13smallzero3fail/133multicast/18defaultsbyteexact; actual both dirty native/ordinary removals. Full14470 strict7/actual16 full headers exact14030/prefix/process/node4four16CPU/memory/real chronology. No final full route/geometry/PG/3RC300MHz/system qualification.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive),actual_memory_cap_failures=len(failures))))
