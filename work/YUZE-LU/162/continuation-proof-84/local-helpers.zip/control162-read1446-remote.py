from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-guide-batch-regression-1444';r=dict(time=time.time(),receipt=None)
for name in ['receipt.json','coarse-refine/receipt.json']:
 p=root/name
 if p.exists():
  d=json.loads(p.read_text());r[name]=dict(passed=d['passed'],stage=d.get('stage'))
  if 'cases'in d:r.update(guided_adaptive=d['guided_adaptive'],guided_history_product=d['guided_history_product'],guided_global_batch=d['guided_global_batch'],zero=sum(not x['failed']for x in d['cases']),failed=sum(x['failed']for x in d['cases']),multicast=sum(x['refinement_multicast']for x in d['cases']),defaults=len(d['defaults']))
p=b/'dynamic-05/node4/00-a-sready1444-guide-batch-regression.log'
if p.exists():
 with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-1200));r['launcher_tail']=f.read().decode(errors='replace')
out=b/'r256-guide-batch-observations-1446';out.mkdir(exist_ok=True);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
