from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1440';new=b/'source-1470';out=b/'r256-guided-cost-source-audit-1472';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();name='project/experiments/control_v1/coarse_refine_regression.py'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='a2e226702227541353ac22cce69b77963474d1cc'and len(z['files'])==1028
assert{p for p,v in z['files'].items()if a['files'].get(p)!=v}=={name}
expected='9f5122c9fdcd8ca25eca07a6f86a5895b30f8b70a47900b7229bbbc711d31c1b';assert sha(b/'source1470.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies';p=scratch/name;p.parent.mkdir(parents=True);p.write_bytes((new/name).read_bytes());patch=b/'control162-backout1470.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True);assert p.read_bytes()==(old/name).read_bytes()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1027,one_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only regression helper covers existing nonpreferred cost32 in optional guided_costs=[2,8,32], default[2,8] unchanged. Router C++/wrapper/native/resource/guide/RTL/all final physical gates byteexact to1440. Actual three-cost guided regression required before full cost32 candidate.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1027)))
q=b/'dynamic-02/node3';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());args=s['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='11201':rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1
capture=b/'r256-guided-cost-slot-capture-1473';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(target=11201,source=rows[0]['spec']['source_root'])))

q=b/'dynamic-03/node5';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');spec=json.loads(p.read_text());args=spec['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='10430':rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
assert len(rows)==1;out=b/'r256-guided-cost-secondary-slot-capture-1473';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(secondary_target=10430,actual_source=rows[0]['spec']['source_root'])))
