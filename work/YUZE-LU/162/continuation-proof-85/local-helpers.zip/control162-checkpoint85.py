from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-85';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-85/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 r=json.loads(z.read('r256-guided-three-cost-regression-1474/coarse-refine/receipt.json'));assert r['passed']and r['guided_costs']==[2,8,32]and len(r['cases'])==24 and sum(not c['failed']for c in r['cases'])==18 and sum(c['refinement_multicast']for c in r['cases'])==273 and len(r['defaults'])==18
 a=json.loads(z.read('r256-guided-cost-active-audit-1481/receipt.json'));assert a['passed']and len(a['comparisons'])==32 and len(a['pools'])==2
 c=json.loads(z.read('continuation-proof-85/actual-regression-before-full-admissions.json'));assert c['passed']and len(c['rows'])==2 and all(x['regression_finished']<=x['admission_mtime']for x in c['rows'])
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch|txt)$',p.name)
  if m and 1451<=int(m.group(1))<=1485:entries[p.name]=p
for n in ['control162-checkpoint85.py','control162-proof85-remote.py','control162-verify85.py','control162-git-data-publish-1451/receipt.json','control162-git-data-publish-1471/receipt.json']:
 p=h/n
 if p.is_file():entries[n]=p
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Existingcosts regression and two actual full chains; local necessary bounds and observers.1484closed-file observer failure preserved with distinct1485 correction; initial1481 readiness assertion before result-directory creation, later actualready verification passed. No physical gates or native code changed.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
text=f'''# Issue162 continuation checkpoint85

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。**完整组合零冲突、实际几何/PG及三档分布RC300MHz联合验收尚未通过，继续任务、不合并。** 保留23类型138份已验收单块、六宏/R256/S1350内部驱动、345状态宿主和453/S5380；外部R及其他任务不动。

source1470 `a2e226702227541353ac22cce69b77963474d1cc` 只扩展回归的已有非优选走向代价覆盖到2/8/32，默认仍2/8。1472核对1028项源、归档SHA `9f5122c9fdcd8ca25eca07a6f86a5895b30f8b70a47900b7229bbbc711d31c1b` 及单文件精确反向补丁；1027项生产/native/RTL/最终门与1440逐字不变。

实际1474：24完整小图18零冲突/6明确失败、273次多端点细化、每种代价均有成功多端点；18默认完整字节回放及原组件/拒绝检查通过。6个失败保留，不代表全图可布。14780(cost32)/14781(cost2)各进入原七阶段，1479严格14规格/六键/当前函数/各自未来几何PG三档RC路径通过；1481实际32输入头相对14030仅代价字段不同、全部原native前缀/输入主体一致、32实际进程、两节点各四组互斥16CPU及真实内存准入通过。各节点257GiB预测需324.4GiB实际可用，真实回归完成早于两个全图准入。只替换fresh核验的本人11201/source1104与10430/source1040子步骤，原件及父节点全部保留。8父节点36×16动态，c96各六槽。

1456实际11149树第8轮快照：1640227冲突，所有树连通/预算诊断通过；相同17字段输入头对照14030。1455/1459按冲突关联次数统计，约95%的普通pair冲突离自身端点超过64µm，仅说明这两份早期快照的争用主要在中段，不外推后续轮次。1460/1461在64个局部窗口做乐观必要出口最大流，均无必要容量失败；含3手工和24暴力割对照，1461额外核对流守恒/反对称/容量/最小割等式。它允许乐观端点选择并忽略线长/完整配对，**不能证明整图可布或物理通过**。

1484只读观察器因文件已关闭失败，原源保留，1485独立修正通过；1481首次在首轮未完成时拒绝，未创建结果目录，实际就绪后核验通过。未降低任何验收门。[{len(rows)}份远程原字节](continuation-proof-85/index.json)及[{len(meta)}份辅助材料](continuation-proof-85/local-index.json)已ZIP CRC/字节/SHA接收，暂存blob另行核验。承接[84](continuation-checkpoint-84.md)，继续全部声明组合最终六文件/版图/M11–M12/300MHz与源绑定交付。

规则rayggxia-project-collab1.0.0；Issue in_progress/PR Draft；登记PR5 pending，看板unverified/同步pending（无board.json），审查待指定。
'''
(base/'continuation-checkpoint-85.md').write_bytes(text.encode())
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0
 header=f'''# Issue162：两组已验证走向代价进入完整物理链

更新时间：{now}。[Checkpoint85]({prefix}work/YUZE-LU/162/continuation-checkpoint-85.md) / [原字节源绑定]({prefix}work/YUZE-LU/162/continuation-proof-85/index.json)。source1470仅扩展已有cost2/8/32回归，1027生产/native/RTL/门不变。实际1474的24小图18零6失败/273多端点/18默认字节回放通过；14780/14781各原七阶段，严格14规格及实际32输入头/前缀/进程、两节点各四组16CPU/真实内存/前置完成时间通过。64局部乐观必要出口流无容量失败，不证明全图可布。

**仍无全图零冲突、真实几何PG三档RC300MHz联合通过，继续布局布线、不合并。** 六宏/R256/S1350/23类138文件/345状态宿主/453/S5380保留；8父节点36×16动态、c96六槽，其他任务不动。登记PR5 pending，看板unverified/同步pending，审查待指定。

''';p.write_bytes((header+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint84源索引](../work/YUZE-LU/162/continuation-proof-84/index.json)','Checkpoint85源索引](../work/YUZE-LU/162/continuation-proof-85/index.json)');at=s.index('本轮追加可选的普通候选搜索切换轮次8/16/32');s=s[:at]+'source1470只扩展已有cost2/8/32回归。实际1474的24小图18零6失败、273多端点及18默认回放通过；14780/14781完整14阶段规格和32真实输入/前缀/进程、两节点四组16CPU/内存/前置时间通过。完整系统仍未验收，见[Checkpoint85](../work/YUZE-LU/162/continuation-checkpoint-85.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;header='''# Issue162：已有走向代价的真实组合复现

source1470冻结源运行原`system_upper.py --coarse-refine-regression-config <config1474.json>`，配置guided_adaptive=false/history_product=false/global_batch=false/guided_costs=[2,8,32]，其余fixture沿用实际1344/1252。实际24小图18零6失败、273多端点和18默认回放通过。完整14780/14781只相对14030改变`--route-nonpreferred-cost 32/2`，保留guide及原退火、加法历史、固定宏和全部最终门。两组各原七阶段，实际32输入/前缀/进程及两节点4×16/memory/真实前置时间核验通过。[Checkpoint85](../work/YUZE-LU/162/continuation-checkpoint-85.md)保留实际规格和源绑定；完整组合物理仍未通过。

''';p.write_bytes((header+s[at+1:]).encode())
print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
