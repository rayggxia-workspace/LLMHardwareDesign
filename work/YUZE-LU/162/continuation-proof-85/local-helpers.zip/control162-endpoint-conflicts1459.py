"""Local read-only classification of already verified actual full-round paths."""
from pathlib import Path
import array,collections,hashlib,json,sys,time
repo=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control');root=Path(r'D:\Data\电路实验\LLMHardwareDesign-deliveries\issue-162\actual-round-diagnostic-1456');out=root.parent/'endpoint-conflicts-1459';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((root/'analysis/receipt.json').read_text());binding=json.loads((root/'local-independent-reception.json').read_text());assert baseline['passed']and binding['passed']and not baseline['whole_system_qualified']
for p in [root/'input.txt',root/'snapshot.txt']:assert sha(p)==baseline['inputs'][str(p)]
sys.path.insert(0,str(repo/'project/experiments/control_v1'));from global_snapshot_analysis import inputs
h,nets,limits=inputs(root/'input.txt');nx,ny=h[:2];plane=nx*ny;usage=array.array('H',[0])*(2*plane);trees=[]
with(root/'snapshot.txt').open()as f:
 assert int(f.readline())==len(nets)
 for name in nets:
  row=f.readline().split();assert row[0]==name;points=set()
  for _ in range(int(row[1])):
   raw=list(map(int,f.readline().split()));assert len(raw)==1+3*raw[0]
   for i in range(1,len(raw),3):points.add(raw[i+2]*plane+raw[i+1]*nx+raw[i])
  packed=array.array('I',points);trees.append((name,packed));
  for v in packed:usage[v]+=1
 assert not f.read().strip()
conflicts=sum(u>1 for u in usage);excess=sum(max(0,u-1)for u in usage);assert conflicts==baseline['diagnostic']['conflict_nodes']and excess==baseline['diagnostic']['excess_occupancy']
totals={};top=[]
for number,(name,points)in enumerate(trees):
 group='native-finite'if number<h[6]else('ordinary-pair'if len(nets[name])==2 else'ordinary-multicast');bins=collections.Counter()
 for v in points:
  if usage[v]<2:continue
  x=v%nx;y=(v%plane)//nx;d=min(abs(x-a)+abs(y-b)for a,b in nets[name]);bins['0'if d==0 else'1-4'if d<=4 else'5-16'if d<=16 else'17-64'if d<=64 else'65+']+=1
 totals.setdefault(group,collections.Counter()).update(bins);top.append(dict(net=name,group=group,conflict_incidence=sum(bins.values()),own_terminal_distance_bins=dict(bins)))
assert sum(sum(v.values())for v in totals.values())==conflicts+excess
r=dict(passed=True,whole_system_qualified=False,time=time.time(),candidate=14470,round=8,conflict_nodes=conflicts,excess_occupancy=excess,conflict_incidence_by_group={k:dict(v)for k,v in totals.items()},top_nets=sorted(top,key=lambda r:r['conflict_incidence'],reverse=True)[:30],inputs={str(p):sha(p)for p in [Path(__file__),root/'input.txt',root/'snapshot.txt',root/'analysis/receipt.json',root/'local-independent-reception.json']},scope='Actual already flood/budget-verified full-round8 paths only, hashes rechecked. Manhattan XY distance in4um grid tracks from each conflicted incidence to its own nearest physical terminal. Incidence counts multiply shared vertices; totals equal conflicts+excess. This distinguishes local<=16tracks/64um versus longer runs, does not diagnose unique cause or establish feasibility/physical qualification. Local Windows computation only; no server tasks changed.')
(out/'receipt.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in r.items()if k not in ['top_nets','inputs']}))
