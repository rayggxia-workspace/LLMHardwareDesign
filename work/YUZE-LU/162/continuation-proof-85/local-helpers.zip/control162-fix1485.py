from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-admission1484-remote.py').read_text().replace('r256-guided-cost-admission-observations-1484','r256-guided-cost-admission-observations-1485')
s=s.replace("f.seek(max(0,f.tell()-150000));rs=[]","f.seek(max(0,f.tell()-150000));lines=f.read().decode(errors='replace').splitlines()\n  rs=[]").replace("for l in f.read().decode(errors='replace').splitlines():","for l in lines:")
compile(s,'observer1485','exec');(h/'control162-admission1485-remote.py').write_bytes(s.encode())
