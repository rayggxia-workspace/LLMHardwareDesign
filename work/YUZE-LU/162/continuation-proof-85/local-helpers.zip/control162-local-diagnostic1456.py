"""Read-only local analysis of a copied actual full-route round; no server compute/job changes."""
from pathlib import Path
import subprocess,hashlib,json,time,sys
b='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
repo=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control')
out=Path(r'D:\Data\电路实验\LLMHardwareDesign-deliveries\issue-162\actual-round-diagnostic-1456')
assert not out.exists();out.mkdir(parents=True)
paths={'input':b+'/r256-composition-453/upper-candidates/14470/route/trial-0/input.txt','snapshot':b+'/r256-composition-453/upper-candidates/14470/route/trial-0/output.txt.global-round-8.txt','log':b+'/r256-composition-453/upper-candidates/14470/route/trial-0/router.log','graph':b+'/r256-composition-453/topology/boundary-graph.json'}
local={}
for k,p in paths.items():
 dst=out/(k+'.txt' if k!='graph' else 'graph.json')
 subprocess.run(['scp','yuzelu@10.129.166.172:'+p,str(dst)],check=True)
 local[k]=dst
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cfg=dict(schema='control162-global-round-diagnostic-v1',round=8,phase_stride=16)
for k,p in local.items():cfg[k]=str(p);cfg[k+'_sha256']=sha(p)
config=out/'config.json';config.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
sys.path.insert(0,str(repo/'project/experiments/control_v1'))
from global_snapshot_analysis import run
r=run(config,out/'analysis')
g=json.loads(local['graph'].read_text());connections={'net_'+k:v for k,v in g['connections'].items()}
for row in r['diagnostic']['top_nets']:
 if row['net'] in connections:row['connection']=connections[row['net']]
(out/'annotated-diagnostic.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
(out/'reception.json').write_text(json.dumps(dict(time=time.time(),remote_origin=paths,received={k:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for k,p in local.items()},production_source='5b3023600afc49fc76366177c45838feceaeed3d',analysis_location='local Windows workstation; no additional server allocations or job mutation',whole_system_qualified=False),indent=2),encoding='utf-8')
print(json.dumps(dict(passed=r['passed'],qualified=False,conflicts=r['diagnostic']['conflict_nodes'],occupied=r['diagnostic']['occupied_cells'],top_nets=[{k:v for k,v in row.items()if k!='connection'}for row in r['diagnostic']['top_nets'][:8]],out=str(out))))
