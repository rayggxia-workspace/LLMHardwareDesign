from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for folder in ['dynamic-05/node2','dynamic-02/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 q=b/folder
 for name in json.loads((q/'queue-state.json').read_text())['active']:
  p=q/'pending'/(name+'.json');s=json.loads(p.read_text());a=s['args']
  if '--out'not in a:continue
  out=Path(a[a.index('--out')+1]);trials=[]
  for log in out.glob('trial-*/router.log'):
   with log.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-160000));lines=f.read().decode(errors='replace').splitlines()
   completed=[]
   for line in lines:
    if line.startswith('{'):
     try:d=json.loads(line)
     except ValueError:continue
     if 'conflict_nodes'in d:completed.append(d)
   trials.append(dict(trial=log.parent.name,last_global=completed[-1]if completed else None,last_line=lines[-1]if lines else None))
  live=[t['last_global']for t in trials if t['last_global']is not None]
  rows.append(dict(queue=folder,name=name,source=s['source_root'],out=str(out),final_output=(out/'router-output.txt').exists(),trial_count=len(trials),last_round_min_conflicts=min((x['conflict_nodes']for x in live),default=None),round_range=[min((x['round']for x in live),default=None),max((x['round']for x in live),default=None)],trials=trials))
out=b/'r256-whole-pool-progress-1482';out.mkdir(exist_ok=True);r=dict(time=time.time(),whole_system_qualified=False,rows=rows,scope='Read-only bounded logs of own eight controllers. Different rounds/seeds cannot establish comparative speed/QoR. No queued or active task changed.');(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(dict(time=r['time'],active=len(rows),rows=[{k:v for k,v in x.items()if k!='trials'}for x in rows])))
