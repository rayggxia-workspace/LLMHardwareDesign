from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-85';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','corridor-test']and f.stat().st_size<8000000:add(f)
for n in ['r256-guided-cost-source-audit-1472','r256-guided-three-cost-regression-1474','r256-final-chain-binding-audit-1479','r256-guided-cost-active-audit-1481']:
 assert json.loads((b/n/'receipt.json').read_text())['passed'];shallow(b/n)
root=b/'r256-guided-three-cost-regression-1474/coarse-refine';r=json.loads((root/'receipt.json').read_text());assert r['guided_costs']==[2,8,32]and len(r['cases'])==24 and sum(not c['failed']for c in r['cases'])==18 and sum(c['refinement_multicast']for c in r['cases'])==273;shallow(root)
for p in root.iterdir():
 if p.is_dir():shallow(p)
for n in ['r256-guided-cost-slot-capture-1473','r256-guided-cost-secondary-slot-capture-1473','r256-local-diagnostic-binding-1457','r256-local-flow-binding-1483']:
 shallow(b/n)
add(b/'r256-local-diagnostic-binding-1409/endpoint-conflicts-1455.json')
flows=b/'r256-local-flow-binding-1483';ix=json.loads((flows/'index.json').read_text())
for name,row in ix['files'].items():assert sha(flows/name)==row['sha256']and(flows/name).stat().st_size==row['bytes']
for n in ['sready1474-guided-three-cost-regression','sready1475-guided-three-cost-regression-refill','sready1478-guided-cost-fullchains','sready1480-guided-cost-fullchain-refill']:
 root=b/'route-selection-102'/n;shallow(root)
 if(root/'tasks.json').exists():
  for row in json.loads((root/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for n in ['source-manifest.json','freeze-import.json']:add(b/'source-1470'/n)
for n in ['config1474.json','control162-backout1470.patch','control162-admission1484-remote.py','control162-admission1485-remote.py']:add(b/n)
actual=json.loads((b/'r256-guided-cost-active-audit-1481/receipt.json').read_text());assert len(actual['comparisons'])==32 and len(actual['pools'])==2
out.mkdir();chronology=[];finished=b/'dynamic-02/node3/results/00-a-sready1474-guided-three-cost-regression.json';d=json.loads(finished.read_text());assert d['returncode']==0;add(finished)
for a in actual['actual_admissions']:
 p=Path(a['path']);assert d['finished']<=p.stat().st_mtime and a['admission']['forecast_gib']==257;add(p);chronology.append(dict(candidate=a['seed'],regression_finished=d['finished'],admission_mtime=p.stat().st_mtime,admission_path=str(p),admission_sha256=sha(p),admission=a['admission']))
p=out/'actual-regression-before-full-admissions.json';p.write_text(json.dumps(dict(passed=True,whole_system_qualified=False,rows=chronology),indent=2));add(p)
for n in ['r256-guided-three-cost-observations-1476','r256-guided-cost-admission-observations-1485','r256-whole-pool-progress-1482','r256-guide-round-metrics-1454']:
 for p in (b/n).glob('*.json'):add(p)
live=out/'live-route-snapshots';live.mkdir()
for tag in [14030,14310,14470,14780,14781]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log';dst=live/(str(tag)+'-trial0.log');dst.write_bytes(p.read_bytes());add(dst)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Source1470 helper-only existingcost32 coverage;1027production/native/RTL/gates unchanged. Actual24guided18zero6fail273multicast/18defaults. Full14780cost32/14781cost2 strict14 specs and actual32 input/header/prefix/process/two4x16 masks/memory and chronology. Early8 snapshot conflict distance and64 optimistic necessary egressflow windows are diagnostics, not whole-system feasibility.1484 read-only observer failed closed-file,1485 distinct corrected reader; original1484 preserved. No full zero-conflict route/geometryPG3RC300MHz qualification.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
