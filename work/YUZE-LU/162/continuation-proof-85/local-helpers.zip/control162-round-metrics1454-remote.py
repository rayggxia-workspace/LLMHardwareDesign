from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [14030,14310,14470]:
 p=b/'r256-composition-453/upper-candidates'/str(tag)/'route/trial-0/router.log'
 with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-1000000));lines=f.read().decode(errors='replace').splitlines()
 rs=[]
 for l in lines:
  if l.startswith('{'):
   try:rs.append(json.loads(l))
   except ValueError:pass
 final=next((r for r in reversed(rs)if'conflict_nodes'in r),None);number=final['round']if final else None
 metric={k:next((r for r in reversed(rs)if r.get('round')==number and k in r),None)for k in ['finite_resource_calls','coarse_zero_hits','coarse_refinement_attempts','global_batch_native_trees','zero_pattern_hits']}
 rows.append(dict(candidate=tag,whole_system_qualified=False,last_complete_global=final,same_round_metrics=metric,last_progress=next((r for r in reversed(rs)if'routed'in r),None),last_line=lines[-1]if lines else None))
r=dict(time=time.time(),rows=rows,scope='Bounded actual log records from same completed round per candidate. Different candidates/rounds cannot imply speed/quality or qualification. No tasks changed.');out=b/'r256-guide-round-metrics-1454';out.mkdir(exist_ok=True);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
