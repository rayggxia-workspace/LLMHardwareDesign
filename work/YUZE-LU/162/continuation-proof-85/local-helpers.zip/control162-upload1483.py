from pathlib import Path
import subprocess,json,hashlib
h=Path(__file__).parent;root=h/'LLMHardwareDesign-deliveries/issue-162';out=root/'local-flow-binding-1483';assert not out.exists();out.mkdir();files={}
for n in [1460,1461]:
 for p,name in [(root/('egress-flow-'+str(n))/'receipt.json','flow'+str(n)+'-receipt.json'),(h/('control162-egress-flow'+str(n)+'.py'),'flow'+str(n)+'-source.py')]:
  raw=p.read_bytes();dst=out/name;dst.write_bytes(raw);files[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 r=json.loads((root/('egress-flow-'+str(n))/'receipt.json').read_text());assert len(r['cases'])==64
receipt=dict(files=files,whole_system_qualified=False,scope='Local necessary optimistic egress maxflow64 windows; all passing is NOT full routability or final physical evidence. Distinct1461 adds skew/conservation/capacity and cut equality checks; original1460 preserved.')
(out/'index.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-local-flow-binding-1483'
subprocess.run(['ssh','yuzelu@10.129.166.172','mkdir '+remote],check=True)
subprocess.run(['scp']+[str(p)for p in out.iterdir()]+['yuzelu@10.129.166.172:'+remote+'/'],check=True)
print(json.dumps(dict(uploaded=len(files)+1,whole_system_qualified=False)))
