from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-egress-flow1460.py').read_text(encoding='utf-8').replace("OUT=ROOT.parent/'egress-flow-1460'","OUT=ROOT.parent/'egress-flow-1461'")
needle="value=int(flow.flow_value);residual=cap-flow.flow;";assert needle in s
s=s.replace(needle,"value=int(flow.flow_value);anti=flow.flow+flow.flow.T;anti.eliminate_zeros();assert anti.nnz==0;balance=np.asarray(flow.flow.sum(axis=1)).ravel();assert balance[src]==value and balance[sink]==-value;balance[src]=0;balance[sink]=0;assert not np.any(balance);residual=cap-flow.flow;")
s=s.replace("r=dict(demand=len(groups),","r=dict(independent_flow_conservation_and_skew_checked=True,demand=len(groups),")
s=s.replace("tests=test,cases=results,","tests=test,case_count=len(results),independent_flow_conservation_and_skew_checked=True,cases=results,")
s=s.replace("if __name__=='__main__':main()","if __name__=='__main__':main()")
compile(s,'flow1461','exec');target=h/'control162-egress-flow1461.py';assert not target.exists();target.write_bytes(s.encode());print('Prepared distinct replay with independent signed-flow conservation, skew symmetry, primal capacity and dual cut checks; original1460 unchanged')
