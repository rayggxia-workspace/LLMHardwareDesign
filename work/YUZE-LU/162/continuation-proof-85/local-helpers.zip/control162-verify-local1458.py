from pathlib import Path
import hashlib,json,time
root=Path(r'D:\Data\电路实验\LLMHardwareDesign-deliveries\issue-162\actual-round-diagnostic-1456');repo=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control')
bind=json.loads((root/'remote-binding.json').read_text());recv=json.loads((root/'reception.json').read_text());d=json.loads((root/'analysis/receipt.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert bind['passed'] and d['passed'] and not d['whole_system_qualified']
for k in ['input','snapshot','graph']:
 r=recv['received'][k];remote=bind['files'][recv['remote_origin'][k]];assert r['sha256']==remote['sha256']==sha(Path(r['path']));assert r['bytes']==remote['bytes']
for n,digest in bind['sources'].items():assert sha(repo/'project/experiments/control_v1'/n)==digest
categories=d['diagnostic']['candidate_phase_conflicts']['categories'];assert sum(categories.values())==d['diagnostic']['conflict_nodes']
out=root/'local-independent-reception.json';assert not out.exists();out.write_text(json.dumps(dict(passed=True,whole_system_qualified=False,time=time.time(),sources_and_remote_immutable_inputs_match=True,all_trees_flood_and_wire_budget_verified=True,conflict_categories=categories,conflicts=d['diagnostic']['conflict_nodes'],input_binding={p.name:sha(p)for p in [root/'remote-binding.json',root/'reception.json',root/'config.json',root/'analysis/receipt.json',root/'annotated-diagnostic.json']},scope='Local read-only actual round8 analysis; exact remote/source binding, no system qualification or feasibility claim.'),indent=2),encoding='utf-8');print(out.read_text())
