from pathlib import Path
import subprocess,json,hashlib,zipfile,io
h=Path(__file__).parent;r=h/'LLMHardwareDesign-worktrees/issue-162-control';rel='work/YUZE-LU/162/continuation-proof-85/';sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(n):
 b=subprocess.check_output(['git','show',':'+rel+n],cwd=r);assert b==(r/rel/n).read_bytes();return b
ix=json.loads(blob('index.json'));lx=json.loads(blob('local-index.json'));count=0
for n,rows,expected in [('selected-originals.zip',{v['zip_entry']:v for v in ix['files'].values()if v['copied']},ix['archive']['sha256']),('local-helpers.zip',lx['files'],lx['archive_sha256'])]:
 b=blob(n);assert sha(b)==expected
 with zipfile.ZipFile(io.BytesIO(b))as z:
  assert z.testzip()is None and set(z.namelist())==set(rows)
  for entry,v in rows.items():d=z.read(entry);assert len(d)==v['bytes']and sha(d)==v['sha256'];count+=1
blob('.gitattributes');print(json.dumps(dict(passed=True,actual_staged_blobs=5,ZIP_entries=count,source_binding=True)))


