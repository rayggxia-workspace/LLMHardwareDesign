from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for folder,seed in [('dynamic-02/node3',14780),('dynamic-03/node5',14781)]:
 q=b/folder;name='00-g-sready1478-r256-route-'+str(seed);p=q/'commands'/(name+'.json');r=dict(folder=folder,candidate=seed,command=json.loads(p.read_text())if p.exists()else None)
 for root in [q/name,b/'r256-composition-453/upper-candidates'/str(seed)/'route']:
  p=root.with_suffix('.log')if root==q/name else root/'router.log'
  if p.exists():
   with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-2500));r[str(p)]=f.read().decode(errors='replace')
 trials=[]
 for p in (b/'r256-composition-453/upper-candidates'/str(seed)/'route').glob('trial-*/router.log'):
  with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-150000));lines=f.read().decode(errors='replace').splitlines()
  rs=[]
  for l in lines:
   if l.startswith('{'):
    try:d=json.loads(l)
    except ValueError:continue
    if 'coarse_zero_attempts'in d or 'conflict_nodes'in d:rs.append(d)
  trials.append(dict(trial=p.parent.name,last=rs[-1]if rs else None))
 r['trials']=trials;rows.append(r)
out=b/'r256-guided-cost-admission-observations-1485';out.mkdir(exist_ok=True);r=dict(time=time.time(),rows=rows,whole_system_qualified=False);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
