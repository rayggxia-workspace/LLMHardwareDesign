"""Local necessary vertex-capacity bound on exact frozen upper-fabric landings."""
from pathlib import Path
import collections,concurrent.futures,hashlib,itertools,json,os,random,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import maximum_flow,breadth_first_order

ROOT=Path(r'D:\Data\电路实验\LLMHardwareDesign-deliveries\issue-162\actual-round-diagnostic-1456')
OUT=ROOT.parent/'egress-flow-1460'

def graph(region,canvas,groups,blocked):
 x0,y0,x1,y1=region;nx,ny=canvas;w=x1-x0+1;h=y1-y0+1;p=w*h;physical=2*p;n=len(groups);src=2*physical+n;sink=src+1
 good=np.ones(physical,dtype=bool)
 for x,y in blocked:good[(y-y0)*w+x-x0]=False
 ids=np.arange(physical,dtype=np.int64).reshape(2,h,w);rows=[];cols=[];data=[]
 def edges(a,z,c):
  a=np.asarray(a,dtype=np.int64).ravel();z=np.asarray(z,dtype=np.int64).ravel();assert len(a)==len(z);rows.append(a);cols.append(z);data.append(np.full(len(a),c,dtype=np.int64))
 v=np.flatnonzero(good);edges(2*v,2*v+1,1)
 for a,z in [(ids[:,:,:-1].ravel(),ids[:,:,1:].ravel()),(ids[:,:-1,:].ravel(),ids[:,1:,:].ravel())]:
  mask=good[a]&good[z];a=a[mask];z=z[mask];edges(2*a+1,2*z,max(1,n));edges(2*z+1,2*a,max(1,n))
 xx,yy=np.meshgrid(np.arange(x0,x1+1),np.arange(y0,y1+1));mask=((xx+yy)%2==0).ravel()&good[:p]&good[p:];a=np.flatnonzero(mask);z=a+p;edges(2*a+1,2*z,max(1,n));edges(2*z+1,2*a,max(1,n))
 exits=((xx==x0)&(x0>4))|((xx==x1)&(x1<nx-5))|((yy==y0)&(y0>4))|((yy==y1)&(y1<ny-5));ev=np.concatenate([np.flatnonzero(exits.ravel()),np.flatnonzero(exits.ravel())+p]);ev=ev[good[ev]];edges(2*ev+1,np.full(len(ev),sink),max(1,n))
 for i,pins in enumerate(groups):
  aux=2*physical+i;edges([src],[aux],1);v=[(y-y0)*w+x-x0 for x,y in pins];assert all(good[k]for k in v);edges(np.full(len(v),aux),2*np.asarray(v),max(1,n))
 cap=coo_matrix((np.concatenate(data),(np.concatenate(rows),np.concatenate(cols))),shape=(sink+1,sink+1)).tocsr();cap.sum_duplicates();return cap,src,sink,good,ev

def solve(region,canvas,groups,blocked,certificate=False):
 cap,src,sink,good,exits=graph(region,canvas,groups,blocked);flow=maximum_flow(cap,src,sink,method='dinic');value=int(flow.flow_value);residual=cap-flow.flow;residual.eliminate_zeros();assert not residual.nnz or residual.data.min()>0
 seen=np.zeros(cap.shape[0],dtype=bool);seen[breadth_first_order(residual,src,directed=True,return_predecessors=False)]=True;assert not seen[sink];dual=int(cap[seen,:][:,~seen].sum());assert dual==value
 r=dict(demand=len(groups),max_flow=value,dual_cut_capacity=dual,necessary_capacity_passed=value==len(groups),vertices=cap.shape[0],directed_edges=cap.nnz,blocked_foreign_m11_pins=len(blocked),physical_exit_vertices=len(exits))
 if certificate and value<len(groups):
  x0,y0,x1,y1=region;w=x1-x0+1;p=w*(y1-y0+1);cut=[]
  for v in np.flatnonzero(good):
   if seen[2*v]and not seen[2*v+1]:cut.append(dict(layer=11+int(v//p),x=x0+int(v%w),y=y0+int((v%p)//w),capacity=1))
  dropped=[i for i in range(len(groups))if not seen[2*len(good)+i]];assert len(cut)+len(dropped)==dual;r['cut_physical_vertices']=cut;r['cut_source_group_indices']=dropped
 return r

def brute(region,canvas,groups,blocked):
 x0,y0,x1,y1=region;nx,ny=canvas;phys={(x,y,l)for x in range(x0,x1+1)for y in range(y0,y1+1)for l in [0,1]if l or(x,y)not in blocked};aux=[('source',i)for i in range(len(groups))];resources=list(phys)+aux
 def connected(removed):
  todo=[v for v in aux if v not in removed];seen=set(todo)
  while todo:
   v=todo.pop()
   if v[0]=='source':nxt=[(x,y,0)for x,y in groups[v[1]]]
   else:
    x,y,l=v
    if(x==x0 and x0>4)or(x==x1 and x1<nx-5)or(y==y0 and y0>4)or(y==y1 and y1<ny-5):return True
    nxt=[(x+1,y,l),(x-1,y,l),(x,y+1,l),(x,y-1,l)]
    if(x+y)%2==0:nxt.append((x,y,1-l))
   for z in nxt:
    if z in phys and z not in removed and z not in seen:seen.add(z);todo.append(z)
  return False
 for count in range(len(groups)+1):
  for cut in itertools.combinations(resources,count):
   if not connected(set(cut)):return count
 raise AssertionError('Auxiliary source cut missing')

def tests():
 cases=[((9,9,13,13),(32,32),[[(10,11)],[(12,11)]],{(x,y)for x in range(9,14)for y in range(9,14)}-{(10,11),(11,11),(12,11)},1),((8,9,10,11),(32,32),[[(9,10)]],{(x,y)for x in range(8,11)for y in range(9,12)}-{(9,10)},0),((9,9,13,13),(32,32),[[(10,11)],[(12,11)]],set(),2)]
 for region,canvas,groups,blocked,expected in cases:assert solve(region,canvas,groups,blocked)['max_flow']==expected
 rng=random.Random(1621460);checks=0
 for _ in range(24):
  region=(8,8,10,10);points=[(x,y)for x in range(8,11)for y in range(8,11)];rng.shuffle(points);groups=[[points[0]],[points[1]]];blocked={p for p in points[2:]if rng.randrange(2)}
  assert solve(region,(32,32),groups,blocked)['max_flow']==brute(region,(32,32),groups,blocked);checks+=1
 return dict(passed=True,manual_shared_via_bottleneck=1,manual_isolated_odd_pin=0,manual_unblocked_pair=2,independent_exhaustive_vertex_cut_cases=checks)

NETS=None;CANVAS=None
def init(nets,canvas):
 global NETS,CANVAS;NETS=nets;CANVAS=canvas
def worker(region):
 x0,y0,x1,y1=region;groups=[];names=[];blocked=set()
 for name,ends in NETS.items():
  inside=[(x,y)for x,y in ends if x0<=x<=x1 and y0<=y<=y1]
  if not inside:continue
  if len(inside)<len(ends):groups.append(inside);names.append(name)
  else:blocked.update(inside)
 if not groups:return dict(region=region,demand=0,max_flow=0,necessary_capacity_passed=True)
 r=solve(region,CANVAS,groups,blocked,True);r['region']=region
 if not r['necessary_capacity_passed']:r['source_groups']=[dict(net=name,pins=pins)for name,pins in zip(names,groups)]
 return r

def main():
 assert not OUT.exists();OUT.mkdir();test=tests();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binding=json.loads((ROOT/'local-independent-reception.json').read_text());assert binding['passed'];raw=(ROOT/'input.txt').read_text().splitlines();h=list(map(int,raw[0].split()));nx,ny=h[:2];nets={};bins=collections.defaultdict(list)
 for line in raw[1:]:
  row=line.split();k=int(row[1]);pins=[(int(row[2+2*i]),int(row[3+2*i]))for i in range(k)];assert len(pins)==len(set(pins));nets[row[0]]=pins
  for x,y in pins:bins[(x//64,y//64)].append((x,y))
 assert len(nets)==11149;allpins=[p for ps in nets.values()for p in ps];assert len(allpins)==len(set(allpins));regions=set()
 for _,points in sorted(bins.items(),key=lambda r:len(r[1]),reverse=True)[:16]:
  cx=round(sum(x for x,y in points)/len(points));cy=round(sum(y for x,y in points)/len(points))
  for size in [32,64,128,256]:
   x0=max(4,min(nx-4-size,cx-size//2));y0=max(4,min(ny-4-size,cy-size//2));regions.add((x0,y0,x0+size-1,y0+size-1))
 workers=max(1,min(4,(os.cpu_count()or 4)//4));started=time.time()
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers,initializer=init,initargs=(nets,(nx,ny)))as pool:results=list(pool.map(worker,sorted(regions)))
 r=dict(passed=True,whole_system_qualified=False,time=time.time(),elapsed_seconds=time.time()-started,workers=workers,tests=test,cases=results,necessary_capacity_failures=sum(not x['necessary_capacity_passed']for x in results),inputs={str(p):sha(p)for p in [Path(__file__),ROOT/'input.txt',ROOT/'local-independent-reception.json',ROOT/'remote-binding.json']},scope='Local Windows computation on exact frozen453 landing input. Two layers, unit vertex capacity, original checkerboard vias and canvas margin. Noncrossing foreign M11 terminals blocked. Each crossing net injects ONE unit and can choose any inside terminal; other candidate-net pins optimistically traversable, all wire budgets/costs/other routed wires ignored. Maxflow is an optimistic necessary egress condition, never routability or final physical qualification. Failures require cut/source geometry review. Same input used in independently remote/source-bound actual-round1456 analysis; no server jobs/specs/gates changed.')
 (OUT/'receipt.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in r.items()if k not in ['cases','inputs']}))

if __name__=='__main__':main()
