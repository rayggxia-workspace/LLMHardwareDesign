from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1470';new=b/'source-1496';out=b/'r256-present-growth-source-audit-1498';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());names=['project/experiments/control_v1/'+n for n in ['coarse_refine_regression.py','system_upper.py','tree_router.cpp','tree_router_cpp.py']]
assert z['commit']=='c43f06aa7ec21062165130cb3aa98f7d3d5acd68'and len(z['files'])==1028 and{p for p,v in z['files'].items()if a['files'].get(p)!=v}==set(names)
expected='93e729220218463937a92d9d221928e4d6461aeab0e3ade09f691b055df2377f';assert sha(b/'source1496.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
before=(old/names[2]).read_text();after=(new/names[2]).read_text();native=lambda s:s.split('if(pareto_wire_budget&&n<locked_count&&wire_limits[n]>=0){',1)[1].split('}else if(bidirectional_two_terminal',1)[0]
assert native(before)==native(after)and before.split(' if(argc<3',1)[0]==after.split(' if(argc<3',1)[0]
out.mkdir();scratch=out/'reverse-copies'
for name in names:p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1496.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True);assert all((scratch/name).read_bytes()==(old/name).read_bytes()for name in names)
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1024,four_file_scratch_backout_exact=True,native_finite_resource_cost_block_byteexact=True,full_original_selftest_byteexact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Optional ordinary-only capped256x present occupancy growth periods4/8, default0. Native finite-resource branch and all solver/geometry/PG/RC/timing/RTL/hardmacros unchanged; ordinary fallback uses original coefficient when n<locked_count. All actual tests still required before full candidates. Reference principle VPR pres_fac_mult, separate integer implementation, no code copied.',reference='https://docs.verilogtorouting.org/en/latest/vpr/command_line_usage/')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1024,native_branch_byteexact=True)))
rows=[]
for folder,seed,source in [('dynamic-04/node25',6562,'source-653'),('dynamic-06/node26',7920,'source-790')]:
 q=b/folder;found=[]
 for n in json.loads((q/'queue-state.json').read_text())['active']:
  p=q/'pending'/(n+'.json');spec=json.loads(p.read_text());args=spec['args']
  if '--out'in args and Path(args[args.index('--out')+1]).parent.name==str(seed):found.append(dict(path=str(p),sha256=sha(p),spec=spec))
 assert len(found)==1 and found[0]['spec']['source_root']==str(b/source);rows+=found
capture=b/'r256-present-growth-slot-capture-1499';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(targets=[6562,7920])))
