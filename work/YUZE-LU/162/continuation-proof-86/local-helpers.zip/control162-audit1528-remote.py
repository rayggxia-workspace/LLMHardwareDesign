from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1514';new=b/'source-1526';out=b/'r256-present-pressure-source-audit-1528';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();name='project/experiments/control_v1/coarse_refine_regression.py'
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='6c066dc2eb5cf11e500b62f08f480b0844798962'and len(z['files'])==1028 and{p for p,v in z['files'].items()if a['files'].get(p)!=v}=={name}
expected='397ee4691c74117b29dd35b6648408371a96d0b18c8967b30db82f5293c025f4';assert sha(b/'source1526.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies';p=scratch/name;p.parent.mkdir(parents=True);p.write_bytes((new/name).read_bytes());patch=b/'control162-backout1526.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True);assert p.read_bytes()==(old/name).read_bytes()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1027,one_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Only regression helper adds distinct near-capacity1750to1850vertexlowerbound fixture below original2048preflight bound. Keeps original proven-overcapacity fixture and mandatoryearlyrejection, original24netfixture/default18/disabled16 and unchangedpost16coverageassertion. Production/native/RTL/gates byteexact1514. All failed1500/01/15110/11/15180/81 retained; newgrowthfull only after actual20case regression pass')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1027)))

q=b/'dynamic-06/node26';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');spec=json.loads(p.read_text());args=spec['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='7921':rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
assert len(rows)==1 and rows[0]['spec']['source_root']==str(b/'source-790');capture=b/'r256-present-pressure-slot-capture-1529';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print('Captured exact own7921/source790')
