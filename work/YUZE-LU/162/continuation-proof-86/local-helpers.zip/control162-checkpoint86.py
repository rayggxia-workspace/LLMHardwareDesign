from pathlib import Path
import json,subprocess,hashlib,zipfile,io,datetime,re
h=Path(__file__).parent;repo=h/'LLMHardwareDesign-worktrees/issue-162-control';base=repo/'work/YUZE-LU/162';out=base/'continuation-proof-86';assert not out.exists();out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-86/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
ix=json.loads((out/'index.json').read_text());raw=(out/'selected-originals.zip').read_bytes();assert sha(raw)==ix['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(raw))as z:
 rows={v['zip_entry']:v for v in ix['files'].values()};assert z.testzip()is None and set(z.namelist())==set(rows)
 for n,v in rows.items():d=z.read(n);assert len(d)==v['bytes']and sha(d)==v['sha256']
 for tag,multi in [(15300,905),(15301,993)]:
  r=json.loads(z.read('r256-present-pressure-regression-'+str(tag)+'/coarse-refine/receipt.json'));assert r['passed']and len(r['cases'])==20 and sum(not c['failed']for c in r['cases'])==16 and sum(c['refinement_multicast']for c in r['cases'])==multi and len(r['defaults'])==18 and len(r['guided_disabled_defaults'])==16 and any(c['refined_after_original_cutoff']for c in r['cases'])
 for prefix,tags in [('r256-present-growth-regression-',[1500,1501]),('r256-present-late-regression-',[15110,15111]),('r256-present-negative-regression-',[15180,15181])]:
  for tag in tags:assert json.loads(z.read(prefix+str(tag)+'/receipt.json'))['passed']is False
 a=json.loads(z.read('r256-present-growth-active-audit-1536/receipt.json'));assert a['passed']and len(a['comparisons'])==32 and len(a['pools'])==1
 c=json.loads(z.read('r256-current-cugr-actual-audit-1533/receipt.json'));assert c['passed']and c['actual_net_count']==11149 and c['six_live_disjoint16cpu_groups']
 chronology=json.loads(z.read('continuation-proof-86/actual-regression-before-full-admissions.json'));assert chronology['passed']and all(x['regression_finished']<=x['admission_mtime']for x in chronology['rows'])and[x['admission']['forecast_gib']for x in chronology['rows']]==[257,322]
entries={}
for p in h.glob('control162-*'):
 if p.is_file()and p.stat().st_size<4000000:
  m=re.search(r'(\d+)(?:-remote)?\.(?:py|json|patch|txt)$',p.name)
  if m and 1486<=int(m.group(1))<=1538:entries[p.name]=p
for n in ['control162-checkpoint86.py','control162-proof86-remote.py','control162-verify86.py']+[f'control162-git-data-publish-{i}/receipt.json'for i in[1486,1497,1509,1515,1527]]:
 p=h/n
 if p.is_file():entries[n]=p
meta={n:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for n,p in entries.items()}
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,p in sorted(entries.items()):z.writestr(n,p.read_bytes())
(out/'local-index.json').write_bytes((json.dumps(dict(count=len(meta),files=meta,archive_sha256=sha((out/'local-helpers.zip').read_bytes()),scope='Actual default-off ordinary-growth change and native/physical invariants, all failed coverage fixtures and successful pressure regressions, two full candidates and current453 CUGR with real bindings. Includes original1502 mistaken forecast refusal/1504correction,1524human-scope erratum1533, packaging86first257vssecond322 correction1538; no gate relaxed.'),indent=2)+'\n').encode());(out/'.gitattributes').write_bytes(b'* -text\n')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
doc=f'''# Issue162 continuation checkpoint86

更新时间：{now}。YUZE-LU；[Issue162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [Draft PR163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。承接[85](continuation-checkpoint-85.md)。**仍无完整整图零冲突、实际几何/PG及三档分布RC300MHz setup/hold/电气联合通过，继续任务、不合并。** 六宏/R256/S1350内部驱动、23类型138单块六文件、345状态宿主、453/S5380和外部R/其他任务边界保留。

source1496 `c43f06aa7ec21062165130cb3aa98f7d3d5acd68` 新增默认关闭的普通网占用惩罚增长：每4或8轮翻倍，上限256倍；只改变搜索代价。参考[VPR pres_fac_mult原则](https://docs.verilogtorouting.org/en/latest/vpr/command_line_usage/)，是独立整数实现，无代码移植。1498核对1028源/归档/四文件精确回退、原有限资源成本分支及全部selftest字节不变；1024其他源含RTL/固定宏/资源求解和全部最终门不变，通用fallback的native系数仍为原公式。source1508/1514/1526只修改回归刺激，生产代码与1496相同；各1028源/归档/单文件精确回退通过。当前冻结运行源1526为 `6c066dc2eb5cf11e500b62f08f480b0844798962`，归档SHA `397ee4691c74117b29dd35b6648408371a96d0b18c8967b30db82f5293c025f4`。

1500/1501的16原小图各全零，但没有第16轮后的实际细化，因此整体失败。15110/15111增加24交叉流仍缺覆盖；15180/15181的超容量负例被原容量门正确提前拒绝，也不满足晚轮覆盖。六份整体失败、全部原输出和门均保留。source1526保留超容量负例，另加顶点下界1750–1850、低于原2048容量门的独立压力刺激，未放宽任何门。实际15300/15301各20案例16零/4明确失败、18默认完整字节回放、16关闭新策略的实际guide字节回放、905/993多端点细化、7项拒绝、单轮失败及真实post16细化/实际增长系数通过。小图不授予全图资格。

15340/15341分别使用增长周期4/8，进入原七阶段。1535严格14规格/六键/当前453函数与各自未来几何PG三档RC路径通过；1536实际32份完整17字段输入头相对14030全部一致，主体/原native前缀一致，32实际进程及actualnode24六组互斥16CPU通过。两次动态准入依次为257GiB/322GiB预测，需要324.4GiB/402.4GiB实际可用；不是两次都322。真实回归finished早于各自准入的原文件/时间/SHA已保存。只经fresh specSHA/UID/job96222/actualnode24/PID/命令/源/453/全部日志/无最终输出/内存守卫替换本人7921/source790子步骤，原件及父节点保留。

现有CUGR/TritonRoute流程4项源与已实际通过的373预检逐字一致；15220将此已通过组件用于当前453/S5380，保留完整七阶段。1524严格7规格/六键/当前函数和各自未来物理门通过，1533核对实际11149连接、重构摆放与当前5380逐项一致、TCL确实执行CUGR50轮后TritonRoute/16线程、实际parser回归及node25六组互斥16CPU。它预测32GiB，使节点总320GiB需400GiB实际可用；若同槽放65GiB候选，总353GiB需439.6GiB，早先实际仅约414GiB。因此保留六槽并行并换用适合内存的已验证后端，没有降低门。旧359/CUGR3751未动。搜索marker/引导网格不是最终宏版图，必须通过实际导入/几何/native XOR/PG/三档RC300MHz后才可交付组合。

1502错误按64GiB估计旧6562，守卫在取消前拒绝；1503读回实际32GiB后，1504按node25的304GiB/380.8GiB、actualnode24的272GiB/342.4GiB重新核验才替换6562/7920。原失败保留。1533另按原SHA勘误1524继承的人类scope“warm-seed”措辞：15220实际是OpenROAD，无native warm导入，结构化七阶段/当前函数/未来门检查不变。1538只修正打包器对首个准入257GiB的错误期望，在已验证空的未完成86目录续包，不修改物理/准入门或原件。1536初次首轮未就绪拒绝，实际就绪后通过。

[{len(rows)}份远程原字节](continuation-proof-86/index.json)与[{len(meta)}份辅助材料](continuation-proof-86/local-index.json)已按ZIP CRC/字节/SHA接收，实际暂存blob另行核验。8父节点36×16动态、两c96各六槽保留。继续全部声明组合最终六文件/版图/实际M11–M12/300MHz及源绑定交付，不在本检查点收尾。

规则rayggxia-project-collab1.0.0；Issue in_progress/PR Draft；登记PR5 pending，看板unverified/同步pending（无board.json），审查待指定。
''';(base/'continuation-checkpoint-86.md').write_bytes(doc.encode())
for name,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=repo/name;s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0
 header=f'''# Issue162：普通网占用增长和当前CUGR进入完整物理链

更新时间：{now}。[Checkpoint86]({prefix}work/YUZE-LU/162/continuation-checkpoint-86.md) / [原字节源绑定]({prefix}work/YUZE-LU/162/continuation-proof-86/index.json)。默认关闭的普通网增长只改变搜索代价，native有限成本块/RTL/固定宏/物理门不变。六次覆盖失败原件保留，15300/15301各20小例16零4失败、18默认/16关闭策略字节回放、905/993多端点及真实post16覆盖通过后，15340/15341进入原14阶段；实际32输入头/前缀/进程、actualnode24六组16CPU/257后322GiB准入/前置时间通过。

当前453/S5380的15220复用373已验组件，4后端源逐字相同，严格7阶段/实际11149连接/摆放/16线程/原parser/node25六组16CPU与320GiB准入通过，旧CUGR3751未动。**仍无全图零冲突、真实几何PG三档RC300MHz联合通过，继续布局布线、不合并。** 六宏/R256/S1350/23类138文件/345状态宿主/453/S5380保留；8父节点36×16动态、c96六槽。登记PR5 pending，看板unverified/同步pending，审查待指定。

''';p.write_bytes((header+s[at+1:]).encode())
p=repo/'docs/CONTROL_V1.md';s=p.read_text(encoding='utf-8').replace('Checkpoint85源索引](../work/YUZE-LU/162/continuation-proof-85/index.json)','Checkpoint86源索引](../work/YUZE-LU/162/continuation-proof-86/index.json)');at=s.index('本轮追加可选的普通候选搜索切换轮次8/16/32');s=s[:at]+'默认关闭的普通网占用增长只改变搜索代价。六份覆盖失败保留，15300/15301实际20小例16零4失败与真实post16覆盖通过后，15340/15341进入原七阶段；32真实输入/前缀/进程及actualnode24六槽/内存/前置时间通过。15220复用已验CUGR后端跑当前453/S5380，严格7规格及实际11149连接/node25六槽通过；两路均无最终系统资格，见[Checkpoint86](../work/YUZE-LU/162/continuation-checkpoint-86.md)。\n\n'+s[at:];p.write_bytes(s.encode())
p=repo/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf-8');at=s.find('\n# ',1);assert at>0;header='''# Issue162：普通网占用增长与当前CUGR的复现入口

source1526的原`system_upper.py --coarse-refine-regression-config <config15300.json/config15301.json>`运行原fixture及近容量压力/超容量负例，guided_present_growth=4/8，其余guided_adaptive/history_product/global_batch均false。实际每项18默认+16关闭策略字节回放、20例16零4失败和post16覆盖通过。15340/15341分别增加`--route-ordinary-present-growth 4/8`，相对14030的完整17字段输入/主体/native前缀相同；原native有限成本块和全部物理门不变。两组各原七阶段，actualnode24六槽，动态257后322GiB预测，最大需要402.4GiB实际可用。

15220复用373已验CUGR/TritonRoute，4后端源与358逐字一致，当前453/S5380，50拥塞轮/guide pitch1.6/16线程；它的搜索marker/引导网格不能充当最终原生版图。实际11149连接/摆放/parser/node25六槽、严格7规格通过，最终实际几何/native XOR/PG/三档分布RC300MHz仍必须独立通过。[Checkpoint86](../work/YUZE-LU/162/continuation-checkpoint-86.md)记录全部源码/规格/原件/内存依据与失败；完整组合物理仍未通过。

''';p.write_bytes((header+s[at+1:]).encode());print(json.dumps(dict(passed=True,remote_originals=len(rows),local_helpers=len(meta),whole_system_qualified=False)))
