from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [1500,1501]:
 root=b/('r256-present-growth-regression-'+str(tag))/'coarse-refine';cases=json.loads((root/'attempts.json').read_text());r=dict(tag=tag,count=len(cases),zero=sum(not c['failed']for c in cases),failed=sum(c['failed']for c in cases),cases=[])
 for c in cases:
  p=root/('guided-cost-'+str(c['cost'])+'-seed-'+str(c['seed']))/'router.log';rs=[json.loads(l)for l in p.read_text().splitlines()if l.startswith('{')];globals=[r for r in rs if 'conflict_nodes'in r];r['cases'].append(dict(cost=c['cost'],seed=c['seed'],failed=c['failed'],multicast=c['refinement_multicast'],postcutoff=c['refined_after_original_cutoff'],last_global=globals[-1]if globals else None))
 fixture=root/'guided-cost-2-seed-971/router-input.txt';lines=fixture.read_text().splitlines();r['fixture_header']=lines[0];r['terminal_groups']=[int(l.split()[1])for l in lines[1:]];rows.append(r)
out=b/'r256-present-growth-failure-diagnostic-1506';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(rows))
