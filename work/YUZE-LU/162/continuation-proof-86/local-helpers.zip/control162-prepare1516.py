from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1510-remote.py').read_text(encoding='utf-8')
for a,b in [("old=b/'source-1496';new=b/'source-1508'","old=b/'source-1508';new=b/'source-1514'"),('r256-present-late-source-audit-1510','r256-present-negative-source-audit-1516'),('821934478185c43908633bf5151c6c6492d4276f','e19fa1a9a59a787f2c9f524987fb91973e73bf6b'),('f0c257826b301e5283601057d9006bd10ac3cbd794a6b5307fdfba8153413c09','ca35c60f2a2eafeeb86263deab5cbed6620bc837d85bf7e70322a8439cd399cd'),('source1508.tar.gz','source1514.tar.gz'),('control162-backout1508.patch','control162-backout1514.patch')]:s=s.replace(a,b)
start=s.index("scope='Only regression helper adds24");end=s.index("')\n",start)
s=s[:start]+"scope='Only regression helper replaces2 insufficient dense24 crossing stimuli by known over-capacity negative fixtures, adds96pairs avoiding originalpinhalos/nativeM11 and uses evencheckerboardlandings. Sum pair shortest vertex lowerbounds exceeds2048 gridcapacity, so expected explicit failure while preserving unchanged post16coverage assertion. Original24fixture/default18/disabled16 and production/native/RTL/gates unchanged1508. All failed1500/01/15110/11 remain failed and preserved; no growthfullcandidate before actual18case regression passes"+s[end:]
compile(s,'audit1516','exec');(h/'control162-audit1516-remote.py').write_bytes(s.encode())
s=(h/'control162-queue1511-remote.py').read_text(encoding='utf-8')
for a,b in [('r256-present-late-source-audit-1510','r256-present-negative-source-audit-1516'),('sready1511-present-late-regressions','sready1518-present-negative-regressions'),('15110','15180'),('15111','15181'),('r256-present-late-regression-','r256-present-negative-regression-'),('00-a-sready1511-present-late-regression-','00-a-sready1518-present-negative-regression-'),('source-1508','source-1514'),('16original+2densecases','16original+2known-overcapacitynegativecases')]:s=s.replace(a,b)
compile(s,'queue1518','exec');(h/'control162-queue1518-remote.py').write_bytes(s.encode())
s=(h/'control162-read1512-remote.py').read_text(encoding='utf-8')
for a,b in [('15110','15180'),('15111','15181'),('r256-present-late-regression-','r256-present-negative-regression-'),('00-a-sready1511-present-late-regression-','00-a-sready1518-present-negative-regression-'),('r256-present-late-observations-1512','r256-present-negative-observations-1519')]:s=s.replace(a,b)
compile(s,'read1519','exec');(h/'control162-read1519-remote.py').write_bytes(s.encode());print('Prepared1516 audit/1518 two negative-coverage regressions/1519 observer')
