from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-progress1490-remote.py').read_text(encoding='utf-8').replace('14030,14310,14470,14780,14781','14030,14310,14470,14780,14781,15340,15341').replace('r256-guided-cost-progress-1490','r256-present-growth-progress-1537')
s=s.replace("last_guide=next((r for r in reversed(rs)if'coarse_refinement_attempts'in r),None),","last_guide=next((r for r in reversed(rs)if'coarse_refinement_attempts'in r),None),last_growth=next((r for r in reversed(rs)if'ordinary_present_growth_period'in r),None),")
compile(s,'progress1537','exec');(h/'control162-progress1537-remote.py').write_bytes(s.encode())
