from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in[14030,14310,14470,14780,14781]:
 root=b/'r256-composition-453/upper-candidates'/str(tag)/'route';trials=[]
 for p in sorted(root.glob('trial-*/router.log')):
  with p.open('rb')as f:f.seek(0,2);size=f.tell();f.seek(max(0,size-200000));lines=f.read().decode(errors='replace').splitlines()
  rs=[]
  for l in lines:
   if l.startswith('{'):
    try:rs.append(json.loads(l))
    except ValueError:pass
  last=lines[-1]if lines else '';trials.append(dict(trial=p.parent.name,bytes=size,last_global=next((r for r in reversed(rs)if'conflict_nodes'in r),None),last_progress=next((r for r in reversed(rs)if'routed'in r),None),last_guide=next((r for r in reversed(rs)if'coarse_refinement_attempts'in r),None),explicit_failure=last if last.startswith(('Locked-source optimistic wire budget exceeded by this search:','disconnected','finite-resource search','coarse-guided','negotiation did not converge'))else None))
 completed=[r['last_global']for r in trials if r['last_global']is not None]
 rows.append(dict(candidate=tag,whole_system_qualified=False,final_router_output=(root/'router-output.txt').exists(),trial_count=len(trials),minimum_observed_conflicts=min((r['conflict_nodes']for r in completed),default=None),latest_completed_round_range=[min((r['round']for r in completed),default=None),max((r['round']for r in completed),default=None)],failed=sum(r['explicit_failure']is not None for r in trials),trials=trials))
r=dict(time=time.time(),candidates=rows,scope='Read-only bounded current logs; across-trial min at different rounds is NOT a speed/quality comparison or qualification. No jobs/specs changed.')
out=b/'r256-guided-cost-progress-1490';out.mkdir(exist_ok=True);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(dict(time=r['time'],candidates=[{k:v for k,v in c.items()if k!='trials'}for c in rows])))
