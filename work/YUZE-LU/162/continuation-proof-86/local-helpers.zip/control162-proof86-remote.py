from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-86';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def shallow(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.iterdir():
  if f.is_file()and f.name not in ['router','corridor-test']and f.stat().st_size<8000000:add(f)
for n in ['r256-present-growth-source-audit-1498','r256-present-late-source-audit-1510','r256-present-negative-source-audit-1516','r256-present-pressure-source-audit-1528','r256-final-chain-binding-audit-1535','r256-present-growth-active-audit-1536','r256-current-openroad-backend-audit-1525','r256-final-chain-binding-audit-1524','r256-current-cugr-actual-audit-1533']:
 assert json.loads((b/n/'receipt.json').read_text())['passed'];shallow(b/n)
for prefix,tags in [('r256-present-growth-regression-',[1500,1501]),('r256-present-late-regression-',[15110,15111]),('r256-present-negative-regression-',[15180,15181]),('r256-present-pressure-regression-',[15300,15301])]:
 for tag in tags:
  root=b/(prefix+str(tag));r=json.loads((root/'receipt.json').read_text());assert r['passed']==(tag in [15300,15301]);shallow(root);shallow(root/'coarse-refine')
  for p in (root/'coarse-refine').iterdir():
   if p.is_dir():shallow(p)
  if tag in [15300,15301]:
   r=json.loads((root/'coarse-refine/receipt.json').read_text());assert len(r['defaults'])==18 and len(r['guided_disabled_defaults'])==16 and len(r['cases'])==20 and sum(not c['failed']for c in r['cases'])==16 and sum(c['refinement_multicast']for c in r['cases'])=={15300:905,15301:993}[tag]and any(c['refined_after_original_cutoff']for c in r['cases'])and len(r['rejected'])==7
for n in ['r256-present-growth-slot-capture-1499','r256-present-growth-resource-readback-1503','r256-present-growth-failure-diagnostic-1506','r256-present-pressure-slot-capture-1529']:shallow(b/n)
for n in ['sready1500-present-growth-regressions','sready1502-present-growth-regression-refill','sready1504-present-growth-regression-refill','sready1511-present-late-regressions','sready1518-present-negative-regressions','sready1530-present-pressure-regressions','sready1532-present-pressure-regression-refill','sready1534-present-growth-fullchains','sready1522-current-cugr-fullchain']:
 root=b/'route-selection-102'/n;shallow(root)
 if(root/'tasks.json').exists():
  for row in json.loads((root/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for tag in [1496,1508,1514,1526]:
 for name in ['source-manifest.json','freeze-import.json']:add(b/('source-'+str(tag))/name)
 add(b/('control162-backout'+str(tag)+'.patch'))
for tag in [1500,1501,15110,15111,15180,15181,15300,15301]:add(b/('config'+str(tag)+'.json'))
out.mkdir();chronology=[];actual=json.loads((b/'r256-present-growth-active-audit-1536/receipt.json').read_text());assert len(actual['comparisons'])==32 and len(actual['pools'])==1
for a in actual['actual_admissions']:
 command=Path(a['path']);tag={15340:15300,15341:15301}[a['seed']];finished=b/'dynamic-06/node26/results'/('00-a-sready1530-present-pressure-regression-'+str(tag)+'.json');d=json.loads(finished.read_text());assert d['returncode']==0 and d['finished']<=command.stat().st_mtime and a['admission']['forecast_gib']==322;add(command);add(finished);chronology.append(dict(candidate=a['seed'],regression=tag,regression_finished=d['finished'],admission_mtime=command.stat().st_mtime,admission_sha256=sha(command),admission=a['admission']))
p=out/'actual-regression-before-full-admissions.json';p.write_text(json.dumps(dict(passed=True,whole_system_qualified=False,rows=chronology),indent=2));add(p)
for name in ['r256-present-growth-observations-1505','r256-present-late-observations-1512','r256-present-negative-observations-1519','r256-present-pressure-observations-1531','r256-present-growth-progress-1537']:
 for p in (b/name).glob('*.json'):add(p)
live=out/'live-route-snapshots';live.mkdir()
for seed in [14030,14310,14470,14780,14781,15340,15341]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route/trial-0/router.log';dst=live/(str(seed)+'-trial0.log');dst.write_bytes(p.read_bytes());add(dst)
p=b/'r256-composition-453/upper-candidates/15220/route/openroad-search/case-0/openroad.log';dst=live/'15220-openroad.log';dst.write_bytes(p.read_bytes());add(dst)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),copied=True,zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Optional ordinary-only capped present growth, source1496+helper1508/1514/1526, originalnativefiniteblock/selftest and allphysicalgates unchanged. Six real regression failures (missingpost16coverage, incl correctearlycapacityrejection) preserved; successful15300/01 each20cases16zero4fail,18legacy16disabledbyteexact,905/993multicast and latecoverage/7rejects. Actual15340/41 strict14/full32inputs/nativeprefix/process/node24six16CPU/322GiBforecast402.4GiBrealadmissions and realchronology. Actualcurrent453/S5380 CUGR15220 sourceexactacceptedbackend/strict7/11149terminals/node25six16CPU/320GiBforecast400GiBrealadmission; old3751 untouched.1502 wrongforecast refused before cancellation,1503actualreadback/1504correctedguard retained.1533 SHA-bounderratum corrects1524inheritedwarmseedhumanphrase withoutchangingoriginal. No fullzero-conflict route or geometryPG3RC300MHz system qualification.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
