from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=[]
for folder,seed in [('dynamic-04/node25',6562),('dynamic-06/node26',7920)]:
 q=b/folder;rows=[]
 for n in json.loads((q/'queue-state.json').read_text())['active']:
  p=q/'pending'/(n+'.json');s=json.loads(p.read_text());a=s['args'];rows.append(dict(path=str(p),forecast=s['forecast_gib'],out=a[a.index('--out')+1]))
 target=[x for x in rows if Path(x['out']).parent.name==str(seed)];assert len(target)==1;r.append(dict(folder=folder,active_forecast=sum(x['forecast']for x in rows),target=target[0],after_regression_forecast=sum(x['forecast']for x in rows)-target[0]['forecast']+16))
out=b/'r256-present-growth-resource-readback-1503';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=r,whole_system_qualified=False),indent=2));print(json.dumps(r))
