from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag,folder in [(15300,'dynamic-06/node26'),(15301,'dynamic-06/node26')]:
 root=b/('r256-present-pressure-regression-'+str(tag));r=dict(tag=tag,receipt=None,case_count=0)
 for name in ['receipt.json','coarse-refine/receipt.json']:
  p=root/name
  if p.exists():
   d=json.loads(p.read_text());r[name]=dict(passed=d['passed'],stage=d.get('stage'))
   if 'cases'in d:r.update(period=d['guided_present_growth'],defaults=len(d['defaults']),guided_disabled_defaults=len(d['guided_disabled_defaults']),case_count=len(d['cases']),zero=sum(not x['failed']for x in d['cases']),failed=sum(x['failed']for x in d['cases']),multicast=sum(x['refinement_multicast']for x in d['cases']),rejected=len(d['rejected']),actual_amplified=any(t['ordinary_present_coefficient']>t['native_present_coefficient']for c in d['cases']for t in c['ordinary_present_trace']))
 p=b/folder/('00-a-sready1530-present-pressure-regression-'+str(tag)+'.log')
 if p.exists():
  with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-1800));r['launcher_tail']=f.read().decode(errors='replace')
 rows.append(r)
out=b/'r256-present-pressure-observations-1531';out.mkdir(exist_ok=True);r=dict(time=time.time(),rows=rows,whole_system_qualified=False);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
