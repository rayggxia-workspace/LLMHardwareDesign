from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-proof86-remote.py').read_text(encoding='utf-8')
s=s.replace("assert not out.exists();sha=","assert out.is_dir()and not any(out.iterdir());sha=").replace('out.mkdir();chronology=[];','chronology=[];')
s=s.replace("a['admission']['forecast_gib']==322","a['admission']['forecast_gib']=={15340:257,15341:322}[a['seed']]")
needle='files={str(p):dict(bytes=';assert needle in s
repair="""correction=b/'r256-proof86-packaging-correction-1538';assert not correction.exists();correction.mkdir();p=correction/'receipt.json';p.write_text(json.dumps(dict(passed=True,whole_system_qualified=False,original_script_sha256=sha(b/'control162-proof86-remote.py'),original_error='AssertionError at first actual admission expected322, actual first257 and second322',reason='Dynamic queue admits two independent tasks sequentially in one scan, so first257GiB and second322GiB are both correct and independently over original memory gates. Only packaging expectation corrected to exactseed mapping; empty unfinishedproof86 directory verified before resume; no source/runtime/physical/admission gate changed, no original overwritten.'),indent=2));add(p);add(b/'control162-proof86-remote.py');add(b/'control162-proof86-resume1538-remote.py')
"""
s=s.replace(needle,repair+needle)
compile(s,'resume1538','exec');(h/'control162-proof86-resume1538-remote.py').write_bytes(s.encode());print('Prepared guarded resume of verified empty partialproof86; original script untouched')
