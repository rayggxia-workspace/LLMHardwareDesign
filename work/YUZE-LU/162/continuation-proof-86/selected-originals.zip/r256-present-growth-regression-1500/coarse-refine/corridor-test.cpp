
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <vector>
#include "routing_corridor.h"
int main(){
 std::mt19937 rng(1621368);RoutingCorridor guide;uint64_t checks=0;
 for(int t=0;t<120;++t){
  int nx=16+rng()%33,ny=16+rng()%33,plane=nx*ny,radius=t%9;
  int x=4+rng()%(nx-8),y=4+rng()%(ny-8),l=t%2;std::vector<int>path{l*plane+y*nx+x};
  for(int i=0;i<60;++i){int d=rng()%5;
   if(d==0&&x>4)--x;else if(d==1&&x<nx-5)++x;
   else if(d==2&&y>4)--y;else if(d==3&&y<ny-5)++y;else if(d==4&&(x+y)%2==0)l=1-l;
   path.push_back(l*plane+y*nx+x);
  }
  if(t%7==0)guide.epoch=std::numeric_limits<uint32_t>::max();
  guide.build(nx,ny,path,radius);uint64_t expected_count=0;
  for(int v=0;v<2*plane;++v){int xx=v%nx,yy=(v%plane)/nx;bool expected=false;
   if(xx>=4&&xx<nx-4&&yy>=4&&yy<ny-4)
    for(int p:path)if(std::max(abs(xx-p%nx),abs(yy-(p%plane)/nx))<=radius){expected=true;break;}
   if(guide.contains(v)!=expected)return 2;
   if(v<plane)expected_count+=expected;++checks;
  }
  if(guide.vertices!=expected_count||guide.contains(-1)||guide.contains(2*plane))return 3;
 }
 guide.build(16,16,std::vector<int>{4*16+4},0);
 guide.epoch=std::numeric_limits<uint32_t>::max();
 guide.build(16,16,std::vector<int>{5*16+5},0);
 if(guide.contains(4*16+4)||!guide.contains(5*16+5))return 5;
 checks+=2;int rejects=0;
 for(int t=0;t<3;++t)try{
  guide.build(t==0?8:16,16,t==1?std::vector<int>{}:std::vector<int>{999999},4);
 }catch(const std::runtime_error&){++rejects;}
 if(rejects!=3)return 4;
 std::cout<<"{\"passed\":true,\"independent_membership_checks\":"<<checks<<",\"invalid_rejections\":"<<rejects<<",\"epoch_wrap_and_size_reuse\":true}"<<std::endl;
}
