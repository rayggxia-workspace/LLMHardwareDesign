from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1526';new=b/'source-1550';out=b/'r256-openroad-track-source-audit-1552';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names={'project/experiments/control_v1/openroad_router_probe.py','project/experiments/control_v1/system_upper.py'}
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='91a5538e555eaff95e0e15c445c12da3094fe1a7'and len(z['files'])==1028 and {p for p,v in z['files'].items()if a['files'].get(p)!=v}==names
expected='688217c2d57ea964d8e3fa229db2b385c70c0ed88228d99eb67cd198a947676c';assert sha(b/'source1550.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for name in names:
 p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1550.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/name).read_bytes()==(old/name).read_bytes()for name in names)
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1026,two_file_scratch_backout_exact=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Optional OpenROAD search track pitch8um matches unchanged import DBU8000 lattice; existing pitch4 default preserved. Coordinate scaling, terminals, technology geometry, strict parser, native macros/RTL, C++ and all final gates unchanged. Only search track generation/propagation and metadata/context guard. Actual original and aligned3case preflights mandatory before new full candidate; not system qualification.')
(out/'receipt.json').write_text(json.dumps(r,indent=2))
q=b/'dynamic-04/node25';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());args=s['args']
 if '--out'in args and Path(args[args.index('--out')+1]).parent.name=='5400':rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1 and rows[0]['spec']['source_root']==str(b/'source-537') and rows[0]['spec']['forecast_gib']==32
capture=b/'r256-openroad-track-slot-capture-1552';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows,whole_system_qualified=False),indent=2));print(json.dumps(dict(passed=True,files=1028,unchanged=1026,own5400_captured=True)))
