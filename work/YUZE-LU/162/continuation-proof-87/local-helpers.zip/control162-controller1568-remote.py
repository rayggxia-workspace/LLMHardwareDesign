from pathlib import Path
import subprocess,json,time,hashlib,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for folder,job in [('dynamic-05/node2',95341),('dynamic-02/node3',95098),('dynamic-05/node4',95391),('dynamic-03/node5',95155),('dynamic-08/node6',97097),('dynamic-07/node7',96297),('dynamic-04/node25',95204),('dynamic-06/node26',96222)]:
 q=b/folder;state=json.loads((q/'queue-state.json').read_text());details=subprocess.check_output(['scontrol','show','job',str(job),'-o'],universal_newlines=True);assert 'UserId=yuzelu(10011)'in details
 match=re.search(r'Command=(.*?) WorkDir=',details);assert match,details;command=match.group(1);command_text=command if not Path(command).is_file()else Path(command).read_text();roots=re.findall(r'/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-\d+',command_text);assert roots,command;source=Path(roots[0]);f=source/'project/experiments/control_v1/dynamic_queue.py';text=f.read_text();limits=[l.strip()for l in text.splitlines()if'forecast_gib'in l and ('assert'in l or'forecast='in l)]
 rejects={n:d for n,d in state['finished'].items()if d.get('rejected_before_admission')and ('sready1544'in n or'sready1564'in n)}
 rows.append(dict(queue=folder,job=job,controller_pid=state['controller_pid'],active_count=len(state['active']),command=command,source=str(source),controller_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),limits=limits,new_sta_rejections=rejects))
out=b/'r256-controller-memory-cap-inspection-1568';out.mkdir(exist_ok=True);r=dict(time=time.time(),rows=rows,whole_system_qualified=False);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
