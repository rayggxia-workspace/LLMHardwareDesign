from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');oldq=b/'dynamic-04/node25';newq=b/'dynamic-08/node6';out=b/'r256-sta-controller-migration-1570';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();state=json.loads((oldq/'queue-state.json').read_text());rows=[]
controller=b/'source-269/project/experiments/control_v1/dynamic_queue.py';assert sha(controller)=='021f7d70424c4dcae47b4262e1d5c66cb5731b352dce7eb32d35799328ec4ae3'and "spec['forecast_gib']<=256"in controller.read_text()
for name,d in state['finished'].items():
 if not(('sready1544'in name and'-15220-'in name)or('sready1564'in name and'-15640-'in name)):continue
 assert d['returncode']==-2 and d['rejected_before_admission']and name not in state['active'];p=oldq/'pending'/(name+'.json');assert sha(p)==d['spec_sha256']and not(oldq/'commands'/(name+'.json')).exists();s=json.loads(p.read_text());assert s['script']=='system_sta.py'and s['forecast_gib']==224;a=s['args'];target=Path(a[a.index('--out')+1]);assert not target.exists();tag=target.parent.parent.name;assert tag in ['15220','15640']
 n=json.loads(json.dumps(s));n['requires'].append(str(b/'r256-sta-controller-migration-audit-1571/receipt.json'));np=newq/'pending'/('00-j-sready1570-r256-sta-'+tag+'-'+target.name+'.json');assert not np.exists();rows.append(dict(old_path=str(p),old_sha256=sha(p),old_spec=s,rejected=d,new_path=str(np),new_spec=n))
assert len(rows)==6
out.mkdir();(out/'verified-before.json').write_text(json.dumps(dict(time=time.time(),rows=rows),indent=2))
for row in rows:
 p=Path(row['new_path']);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(row['new_spec']));tmp.rename(p);row['new_sha256']=sha(p)
(out/'index.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,rows=rows,controller=str(controller),controller_sha256=sha(controller),scope='Six exactneveradmitted224GiB STA specs rejected by source93 max128 controller copied to existing node6/source269 max256 controller with unique1570 names/auditdependency. Originalfailedspecs/results untouched, args/source/outputs/physicalgates unchanged. No parent, active step or other work altered. Aggregate memory admission1.2sum+16 stillmandatory; no STA or systemqualification claimed.'),indent=2));print(json.dumps(dict(passed=True,new_tasks=6,forecast_gib=224,destination='existing node6/source269')))
