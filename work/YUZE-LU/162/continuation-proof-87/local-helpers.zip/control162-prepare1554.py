from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-refill1504-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1504-present-growth-regression-refill','sready1554-openroad-track-preflight-refill').replace('sready1500-present-growth-regressions','sready1553-openroad-track-preflights')
s=s.replace("[(25,95204,'dynamic-04/node25',6562,'source-653',0,304,380.8),(24,96222,'dynamic-06/node26',7920,'source-790',0,272,342.4)]","[(25,95204,'dynamic-04/node25',5400,'source-537',0,304,380.8)]")
s=s.replace('r256-present-growth-slot-capture-1499','r256-openroad-track-slot-capture-1552')
start=s.index("reason='Fresh exact own6562");end=s.index("')\n (record/",start)
s=s[:start]+"reason='Fresh exact own5400/source537/node25 partial only; capture1552 specSHA/UID/job/actualnode/PID/fullcmd/source/out/current453/alllogs/nooutput and actual304GiBforecast380.8GiB memoryguard. Replace only this old slow native-search child with two sequential16CPU original4/aligned8 CUGR preflights. No full candidate until both actual passes. All originals, eight parent allocations, other35tasks, currentCUGR15220, oldCUGR3751 and externalR untouched"+s[end:]
compile(s,'refill1554','exec');(h/'control162-refill1554-remote.py').write_bytes(s.encode())
