from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-queue1522-remote.py').read_text(encoding='utf-8')
for a,b in [('source-1514','source-1526'),('sready1522-current-cugr-fullchain','sready1564-current-fastroute-fullchain'),('e19fa1a9a59a787f2c9f524987fb91973e73bf6b','6c066dc2eb5cf11e500b62f08f480b0844798962'),('seed=15220','seed=15640'),(".replace('sready1324','sready1522')",".replace('sready1324','sready1564')"),('r256-final-chain-binding-audit-1524','r256-final-chain-binding-audit-1565'),('r256-composition-359/cugr-preflight373','r256-existing-fastroute-preflight-15620')]:s=s.replace(a,b)
s=s.replace("spec['source_root']=str(source)","spec['source_root']=str(source)\n if spec['script']=='system_sta.py':spec['forecast_gib']=224")
s=s.replace("spec['args']=a;spec['forecast_gib']=32;","a[a.index('--openroad-global-router')+1]='fastroute';spec['args']=a;spec['forecast_gib']=32;")
s=s.replace("str(b/'r256-existing-fastroute-preflight-15620/receipt.json')]","str(b/'r256-existing-fastroute-preflight-15620/receipt.json'),str(b/'r256-present-pressure-source-audit-1528/receipt.json')]")
start=s.index("scope='Existing actual-preflighted");end=s.index("'),indent=2)",start)
s=s[:start]+"scope='Actual15620 original3case FastRoute/TritonRoute preflight passed, existing source1526 original search4um/parser8000DBU at2000DBUperum. Full current453/S5380 FastRoute50/guide1.6/16threads,32GiB slot replaces completed preflight slot, other35tasks unchanged. Original7stages each ownroute/geometry/PG/lowbasehigh/delivery with224GiB futureSTAforecast. Native macros/RTL/physical gates unchanged; old3751 and currentCUGR15220 protected. No full result or systemqualification inherited"+s[end:]
s=s.replace("backend='Existing CUGR/TritonRoute'","backend='Existing FastRoute/TritonRoute'")
needle="template=json.loads"
pos=s.index(needle)
s=s[:pos]+"pr=b/'r256-existing-fastroute-preflight-15620';assert json.loads((pr/'receipt.json').read_text())['passed'];actual=json.loads((pr/'openroad-probe.json').read_text());assert actual['passed']and actual['global_router']=='fastroute'and len(actual['cases'])==3 and actual['independent_grid_verification_passed']\n"+s[pos:]
compile(s,'queue1564','exec');(h/'control162-queue1564-remote.py').write_bytes(s.encode())
s=(h/'control162-audit1524-remote.py').read_text(encoding='utf-8')
for a,b in [('r256-final-chain-binding-audit-1524','r256-final-chain-binding-audit-1565'),('sready1522-current-cugr-fullchain','sready1564-current-fastroute-fullchain'),('[15220]','[15640]'),('source-1514','source-1526'),("=='cugr'","=='fastroute'"),('r256-composition-359/cugr-preflight373','r256-existing-fastroute-preflight-15620')]:s=s.replace(a,b)
s=s.replace("ta=t['args'];assert", "assert t['forecast_gib']==224;ta=t['args'];assert")
start=s.index("scope='Read-only final-chain");end=s.index("')\nexcept",start)
s=s[:start]+"scope='Read-only strict7stage source/graph/function/ownfuturegeometryPG3RC binding for actualpreflight15620 FastRoute candidate15640 current453/S5380, no nativewarm import. Actual3fixture FastRoute preflight required, final original6key acceptance and all300MHz/geometry/nativeXOR/PG gates unchanged, threeSTAforecasts224GiB. No route or system qualification inherited; all other tasks protected"+s[end:]
compile(s,'audit1565','exec');(h/'control162-audit1565-remote.py').write_bytes(s.encode());print('Prepared existing FastRoute full7 and strict224GiB STA binding')
