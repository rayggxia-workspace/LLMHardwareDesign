from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-refill1504-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1504-present-growth-regression-refill','sready1576-current-cugr-snapshot-refill').replace('sready1500-present-growth-regressions','sready1575-current-cugr-drc').replace("assert len(tasks['tasks'])==2","assert len(tasks['tasks'])==1")
s=s.replace("[(25,95204,'dynamic-04/node25',6562,'source-653',0,304,380.8),(24,96222,'dynamic-06/node26',7920,'source-790',0,272,342.4)]","[(24,96222,'dynamic-06/node26',5494,'source-537',0,290,364.0)]")
s=s.replace("current_forecast-spec['forecast_gib']+16<=forecast","current_forecast-spec['forecast_gib']+32<=forecast").replace('r256-present-growth-slot-capture-1499','r256-current-cugr-snapshot-slot-1575')
start=s.index("reason='Fresh exact own6562");end=s.index("')\n (record/",start)
s=s[:start]+"reason='Fresh exact own5494/source537/actualnode24 partial only; captured1575 specSHA/UID/job/actualnode/PID/fullcmd/source/out/current453/alllogs/nooutput and actual290GiBforecast364GiB memoryguard. Replace only this slow native-search child with existing32GiB16CPU oneiteration currentCUGR snapshot diagnostic; original15220/3751/fullFastRoute15640/two growth controls untouched. All originals, eight parents and other35tasks/externalR preserved. Not a physicalpass or shortened acceptance run"+s[end:]
compile(s,'refill1576','exec');(h/'control162-refill1576-remote.py').write_bytes(s.encode())
