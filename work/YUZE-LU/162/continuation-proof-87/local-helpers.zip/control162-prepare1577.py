from pathlib import Path
h=Path(__file__).parent;s=(h/'control162-queue1575-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1575-current-cugr-drc','sready1577-current-cugr-drc').replace('15750','15770').replace('snapshot-slot-1575','snapshot-slot-1577').replace('dynamic-06/node26','dynamic-05/node4').replace("=='5494'","=='12841'").replace("str(b/'source-537')","str(b/'source-1250')").replace('ownlegacy5494','ownredundant12841')
compile(s,'queue1577','exec');(h/'control162-queue1577-remote.py').write_bytes(s.encode())
s=(h/'control162-refill1504-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1504-present-growth-regression-refill','sready1578-current-cugr-snapshot-refill').replace('sready1500-present-growth-regressions','sready1577-current-cugr-drc').replace("assert len(tasks['tasks'])==2","assert len(tasks['tasks'])==1")
s=s.replace("[(25,95204,'dynamic-04/node25',6562,'source-653',0,304,380.8),(24,96222,'dynamic-06/node26',7920,'source-790',0,272,342.4)]","[(4,95391,'dynamic-05/node4',12841,'source-1250',0,225,286.0)]")
s=s.replace("current_forecast-spec['forecast_gib']+16<=forecast","current_forecast-spec['forecast_gib']+32<=forecast").replace('r256-present-growth-slot-capture-1499','r256-current-cugr-snapshot-slot-1577')
start=s.index("reason='Fresh exact own6562");end=s.index("')\n (record/",start)
s=s[:start]+"reason='Fresh exact own12841/source1250/node4 partial only; captured1577 specSHA/UID/job/actualnode/PID/fullcmd/source/out/current453/alllogs/nooutput and actual225GiBforecast286GiB memoryguard. Existing1344component byteequivalence and13560 first8rounds exact12841 replay remain, so retire this redundant old search only for existing32GiB16CPU oneiteration currentCUGR snapshot diagnostic. Original15220/3751/fullFastRoute15640/two growth controls and all5494/5495 untouched. All old source/spec/logs/failures and eightparents/other35tasks/externalR retained.1575 guardrefused before any cancellation, false64GiB5494 assumption not used. Not a physicalpass or shortened acceptance run"+s[end:]
compile(s,'refill1578','exec');(h/'control162-refill1578-remote.py').write_bytes(s.encode())
