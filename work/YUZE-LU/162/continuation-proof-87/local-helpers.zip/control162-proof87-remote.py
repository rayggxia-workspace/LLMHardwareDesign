from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-87';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(p)
def tree(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.rglob('*'):
  if f.is_file()and f.stat().st_size<8000000:add(f)
for name in ['r256-openroad-track-source-audit-1552','r256-openroad-track-slot-capture-1552','r256-final-chain-binding-audit-1565','r256-current-fastroute-actual-audit-1572','r256-sta-controller-migration-1570','r256-sta-controller-migration-audit-1571','r256-controller-memory-cap-inspection-1569','r256-current-cugr-snapshot-slot-1577']:
 tree(b/name)
for name in ['r256-openroad-track-preflight-15530','r256-openroad-track-preflight-15531','r256-existing-fastroute-preflight-15620']:
 tree(b/name)
for name,passed in [('r256-openroad-track-preflight-15530',True),('r256-openroad-track-preflight-15531',False),('r256-existing-fastroute-preflight-15620',True)]:assert json.loads((b/name/'receipt.json').read_text())['passed']==passed
for name in ['sready1553-openroad-track-preflights','sready1554-openroad-track-preflight-refill','sready1562-existing-fastroute-preflight','sready1564-current-fastroute-fullchain','sready1577-current-cugr-drc','sready1578-current-cugr-snapshot-refill']:
 root=b/'route-selection-102'/name;tree(root)
 if(root/'tasks.json').exists():
  for row in json.loads((root/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for name in ['source-manifest.json','freeze-import.json']:add(b/'source-1550'/name)
for name in ['openroad_router_probe.py','system_upper.py']:add(b/'source-1550/project/experiments/control_v1'/name)
add(b/'control162-backout1550.patch');add(b/'source-269/project/experiments/control_v1/dynamic_queue.py');add(b/'source-93/project/experiments/control_v1/dynamic_queue.py')
for name in ['current-cugr-snapshot15750.json','current-cugr-snapshot15770.json','acceptance-15640.json']:add(b/'r256-composition-453'/name)
migration=json.loads((b/'r256-sta-controller-migration-1570/index.json').read_text())
for row in migration['rows']:
 for key in ['old_path','new_path']:add(row[key])
 p=Path(row['old_path']);add(p.parent.parent/'results'/p.name)
for folder in ['dynamic-04/node25','dynamic-05/node4']:
 q=b/folder
 for glob in ['*sready1553*','*sready1562*','*sready1564*','*sready1577*']:
  for f in q.glob(glob):add(f)
  for sub in ['commands','results']:
   for f in(q/sub).glob(glob):add(f)
for name in ['r256-present-growth-progress-1537','r256-growth-round-metrics-1540','r256-all-pool-watch-1407']:
 for p in(b/name).glob('*.json'):
  if p.stem.isdigit()and int(p.stem)>=1793812500000000:add(p)
out.mkdir();captures=out/'live-captures';captures.mkdir()
for name,p in [('15220-full',b/'r256-composition-453/upper-candidates/15220/route/openroad-search/case-0/openroad.log'),('15640-full',b/'r256-composition-453/upper-candidates/15640/route/openroad-search/case-0/openroad.log'),('15770-diagnostic',b/'r256-current-cugr-snapshot-15770/openroad.log')]:
 if p.exists():
  dst=captures/(name+'.log');dst.write_bytes(p.read_bytes());add(dst)
erratum=dict(passed=True,whole_system_qualified=False,default_units=dict(def_dbu_per_um=2000,parser_grid_dbu=8000,actual_um=4,original_track_pitch_um=4),correction='The proposed mismatch was a DBU-to-um interpretation error: original search4um and import8000DBU already agree at2000DBUperum. Optional8um was not a repair. Actual15530 default3cases passed,15531 optional8 firstcase emptyDRC but strictparser Off-grid X bus_9 240000 rejected; original rule not changed. Source1550 commit91a5538 tested variant, current60e489237 explicitly reverts both production files to1526 byteexact. No full8um candidate launched. Actual existing FastRoute15620 original3cases passed, full15640 uses original source1526 with full7gates. Original15531failure and all code are preserved.',scope='Unit correction and negativeexperiment record; not evidence of originalbackend bug or system pass.')
p=out/'units-and-revert-erratum.json';p.write_text(json.dumps(erratum,indent=2));add(p)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
ix=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Actual original/default CUGR preflight15530 passed, optionalpitch8 negative15531 failed unchanged strictparser and erroneous DBU premise explicitly corrected; both code files reverted. Existing FastRoute15620 actual3fixtures pass then full15640 strict7/current45311149pins/sixnode25CPU/320forecast400required actual. Six224GiB STA specs rejected by oldsource93 max128 retained and exactcopies migrated to existingnode6/source269 max256; actualpendingunrejected readback, noSTAexecution. Currentnode24 six growthSTA224 specs not rejected. Only own5400 and redundant12841 exactfreshUID/job/node/cmd/spec/source/graph/log/nooutput/memory guarded child retirements, originals kept.1575 prequeue guard refused beforecancel with config retained,1577/78 existing snapshot helper now currentCUGR15220 oneiteration diagnosis; originalfull15220/old3751/otherjobs/R untouched. Eightparents36x16dynamic, c96sixslots. No complete fullroute or nativegeometryPG3RC300MHz jointsystem qualification; continue physicalwork.')
(out/'index.json').write_text(json.dumps(ix,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
