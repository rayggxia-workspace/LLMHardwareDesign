"""Publish one exact local fast-forward commit through Git Data REST if Git transport fails."""
import base64,datetime,hashlib,json,re,subprocess,sys,concurrent.futures,threading,time
from pathlib import Path
repo=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control')
label=sys.argv[1] if len(sys.argv)>1 else '82';assert label.isdigit()
out=Path(r'D:\Data\电路实验')/('control162-git-data-publish-'+label);out.mkdir(exist_ok=True)
lock=threading.Lock();next_post=[0.]
prefix='repos/rayggxia-workspace/LLMHardwareDesign'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def api(endpoint,payload=None):
 args=['gh','api',prefix+'/'+endpoint]
 if payload is not None:
  encoded=json.dumps(payload);name=out/('request-'+hashlib.sha256((endpoint+encoded).encode()).hexdigest()+'.json');name.write_text(encoded,encoding='utf-8');args+=['--method','PATCH'if endpoint.startswith('git/refs/')else'POST','--input',str(name)]
 if payload is not None:
  with lock:
   delay=max(0,next_post[0]-time.monotonic());time.sleep(delay);next_post[0]=time.monotonic()+.65
 for attempt in range(6):
  try:return json.loads(subprocess.check_output(args,cwd=repo,timeout=35))
  except (subprocess.TimeoutExpired,subprocess.CalledProcessError):
   if attempt==5:raise
   time.sleep(min(5,attempt+1))
revision=sys.argv[2]if len(sys.argv)>2 else 'HEAD'
assert revision=='HEAD'or re.fullmatch('[0-9a-f]{40}',revision)
head=git('rev-parse',revision).decode().strip();parent=git('rev-parse',revision+'^').decode().strip();ref='heads/task/162-programmable-control'
remote=api('git/ref/'+ref)['object']['sha']
if remote==head:
 (out/'receipt.json').write_text(json.dumps(dict(passed=True,head=head,parent=parent,force=False,exact_local_commit_identity=True,remote_readback_sha=remote,recovered_after_readback_timeout=True),indent=2));print(json.dumps(dict(passed=True,head=head,recovered_readback=True)));sys.exit(0)
assert remote==parent,(remote,parent)
raw=git('cat-file','commit',head).decode('utf-8');headers,message=raw.split('\n\n',1)
assert 'gpgsig 'not in headers and 'encoding 'not in headers
def identity(kind):
 line=next(x for x in headers.splitlines()if x.startswith(kind+' '));m=re.fullmatch(kind+r' (.*) <([^<>]+)> (\d+) ([+-]\d{4})',line);assert m
 name,email,epoch,offset=m.groups();zone=datetime.timezone(datetime.timedelta(minutes=(1 if offset[0]=='+'else-1)*(int(offset[1:3])*60+int(offset[3:]))))
 return dict(name=name,email=email,date=datetime.datetime.fromtimestamp(int(epoch),zone).isoformat())
cache_path=out/'completed-blobs.json'
cache=json.loads(cache_path.read_text())if cache_path.exists()else{}
paths=[path for path in git('diff','--name-only','-z',parent,head).decode().split('\0')if path]
# Objects reachable from the exact verified remote parent already exist.
# Group identical new blobs before posting; retain all exact tree checks.
known={line.split(b' ',1)[0].decode()for line in git('rev-list','--objects',parent).splitlines()}
known.update(cache.values())
blobs={}
for entry in git('ls-tree','-r','-z',head).split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,kind,digest=meta.split()
 if kind==b'blob':blobs[path.decode()]=digest.decode()
groups={}
for path in paths:
 if path in blobs:groups.setdefault(blobs[path],[]).append(path)
def upload(path):
 blob=blobs[path]
 if blob not in known:
  data=git('cat-file','blob',blob);result=api('git/blobs',dict(content=base64.b64encode(data).decode(),encoding='base64'));assert result['sha']==blob
  with lock:
   cache[path]=blob;temporary=cache_path.with_suffix('.tmp');temporary.write_text(json.dumps(cache),encoding='utf-8')
   for retry in range(30):
    try:temporary.replace(cache_path);break
    except PermissionError:
     if retry==29:raise
     time.sleep(.2)
 return dict(path=path,mode='100644',type='blob',sha=blob)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 representatives=list(pool.map(upload,[members[0]for blob,members in groups.items()if blob not in known]))
elements=[dict(path=path,mode='100644',type='blob',sha=blobs.get(path))for path in paths]
root_tree=git('rev-parse',head+'^{tree}').decode().strip()
if label in ('430','870','922','1004','1077','1127','1166','1204','1233','1279','1300','1330','1351','1393','1411','1436','1451','1486','1539','1547','1551','1561'):
 # Build the exact same Git tree from small immediate directory entries.
 # The single flat-path request repeatedly returned HTTP502 before ref update.
 old_objects={line.split(b' ',1)[0].decode()for line in git('rev-list','--objects',parent).splitlines()}
 tree_cache=out/'completed-trees.json';trees=set(json.loads(tree_cache.read_text()))if tree_cache.exists()else set()
 def upload_tree(oid):
  if oid in old_objects or oid in trees:return oid
  entries=[]
  for raw_entry in git('ls-tree','-z',oid).split(b'\0'):
   if not raw_entry:continue
   meta,name=raw_entry.split(b'\t',1);mode,kind,digest=meta.decode().split()
   if kind=='tree':upload_tree(digest)
   entries.append(dict(path=name.decode(),mode=mode,type=kind,sha=digest))
  result=api('git/trees',dict(tree=entries));assert result['sha']==oid
  trees.add(oid);tree_cache.write_text(json.dumps(sorted(trees)),encoding='utf-8')
  return oid
 tree=upload_tree(root_tree)
else:tree=api('git/trees',dict(base_tree=git('rev-parse',parent+'^{tree}').decode().strip(),tree=elements))['sha']
assert tree==root_tree
commit=api('git/commits',dict(message=message,tree=tree,parents=[parent],author=identity('author'),committer=identity('committer')))
assert commit['sha']==head,('No ref updated: API commit differs from exact original local Git object',commit['sha'],head)
assert api('git/ref/'+ref)['object']['sha']==parent
updated=api('git/refs/'+ref,dict(sha=head,force=False));assert updated['object']['sha']==head
verified=api('git/ref/'+ref);assert verified['object']['sha']==head
(out/'receipt.json').write_text(json.dumps(dict(passed=True,head=head,parent=parent,tree=tree,blob_count=len(elements),force=False,exact_local_commit_identity=True,remote_readback=verified),indent=2),encoding='utf-8')
print(json.dumps(dict(passed=True,head=head,exact_commit=True,force=False)))
