from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453';record=b/'route-selection-102/sready1577-current-cugr-drc';assert not record.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();parent=root/'upper-candidates/15220/route';case=parent/'openroad-search/case-0';files={}
assert (b/'source-1526/project/experiments/control_v1/openroad_snapshot.py').read_bytes()==(b/'source-388/project/experiments/control_v1/openroad_snapshot.py').read_bytes()
for name in ['before.odb','route.guide','terminals.json','run.tcl']:
 p=case/name;assert p.is_file()and p.stat().st_size>0;files[name]=dict(path=str(p),sha256=sha(p))
place=json.loads((parent/'placement.json').read_text());terms=json.loads((case/'terminals.json').read_text());assert len(terms)==11149 and terms==place['terminals']and place==json.loads((root/'cap-candidates/5380/placement.json').read_text())
config=root/'current-cugr-snapshot15770.json';assert not config.exists();config.write_text(json.dumps(dict(schema='control162-openroad-search-snapshot-v1',iterations=1,inputs=files,nx=int(place['width_um']/4),ny=int(place['height_um']/4)),indent=2))
out=b/'r256-current-cugr-snapshot-15770';spec=dict(script='system_upper.py',source_root=str(b/'source-1526'),forecast_gib=32,requires=[str(b/'r256-current-cugr-actual-audit-1533/receipt.json'),str(b/'r256-present-pressure-source-audit-1528/receipt.json')],args=['--manifest',str(b/'r256-composition-359/selected/physical.json'),'--graph',str(root/'topology/boundary-graph.json'),'--openroad-snapshot-config',str(config),'--out',str(out)])
path=b/'dynamic-05/node4/pending/00-f-sready1577-current-cugr-drc-15770.json';assert not path.exists()and not out.exists()
# Exact capture before replacing one own legacy5494 child; no active task change here.
q=b/'dynamic-05/node4';rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');s=json.loads(p.read_text());a=s['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='12841':rows.append(dict(path=str(p),sha256=sha(p),spec=s))
assert len(rows)==1 and rows[0]['spec']['source_root']==str(b/'source-1250')and rows[0]['spec']['forecast_gib']==64
capture=b/'r256-current-cugr-snapshot-slot-1577';assert not capture.exists();capture.mkdir();(capture/'receipt.json').write_text(json.dumps(dict(time=time.time(),rows=rows),indent=2))
tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(path);record.mkdir();(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(path),sha256=sha(path),spec=spec)],config=str(config),config_sha256=sha(config),inputs=files,whole_system_qualified=False,scope='Existing sourceexact oneiteration diagnostic helper replaying immutable current453/S5380 CUGR15220 preDB/globalguide. Extract concrete shorts/spacing/pinaccess without waiting every fullDRTiteration. Does not alter originalfull15220 or old3751, and never replaces final route/geometry/PG/3RC300MHz acceptance. Only after fresh exact ownredundant12841 guard in same c96six16CPU allocation. Reports may be incomplete; no physicalqualification.'),indent=2));print(json.dumps(dict(queued=1,candidate=15770,forecast_gib=32)))
