from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');rows=[]
for tag in [15530,15531]:
 root=b/('r256-openroad-track-preflight-'+str(tag));row=dict(tag=tag,exists=root.exists(),receipt=None,cases=[])
 if(root/'receipt.json').exists():
  d=json.loads((root/'receipt.json').read_text());row['receipt']={k:d.get(k)for k in ['passed','stage','error','exception','whole_system_qualified']}
 for case in sorted(root.glob('case-*')):
  p=case/'openroad.log';tail=''
  if p.exists():
   with p.open('rb')as f:f.seek(0,2);f.seek(max(0,f.tell()-2000));tail=f.read().decode(errors='replace')
  row['cases'].append(dict(case=case.name,has_drc=(case/'drc.rpt').exists(),has_grid_proof=(case/'grid-proof.json').exists(),log_tail=tail))
 rows.append(row)
out=b/'r256-openroad-track-observations-1555';out.mkdir(exist_ok=True);r=dict(time=time.time(),rows=rows,whole_system_qualified=False);(out/(str(int(time.time()*1000000))+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
