from pathlib import Path
import json,re,collections,hashlib
base=Path(r'D:\Data\电路实验\control162-snapshot1582');graph=json.loads((base/'boundary-graph.json').read_bytes());place=json.loads((base/'placement.json').read_bytes());text=(base/'drc.rpt').read_text();pattern=r'violation type: ([^\n]+)\n\s*srcs: ([^\n]+)\n\s*bbox = \(([-\d.]+), ([-\d.]+)\) - \(([-\d.]+), ([-\d.]+)\) on Layer (\w+)'
records=[];types=collections.Counter();layers=collections.Counter();pairs=collections.Counter();drivers=collections.Counter();unknown=set()
for m in re.finditer(pattern,text):
 kind,src,x0,y0,x1,y1,layer=m.groups();nets=re.findall(r'net:(\S+)',src);boxes=list(map(float,[x0,y0,x1,y1]));types[kind]+=1;layers[layer]+=1;pairs[tuple(sorted(set(nets)))]+=1
 roots=[]
 for name in nets:
  key=name[4:]if name.startswith('net_')else None;c=graph['connections'].get(key)
  if c:
   driver=c['driver'];instance=driver['instance'];roots.append(dict(net=name,driver=driver,type=graph['instances'].get(instance,'TOP')));drivers[instance]+=1
  else:unknown.add(name)
 records.append(dict(type=kind,srcs=src,nets=nets,box_um=boxes,layer=layer,drivers=roots))
assert len(records)==text.count('violation type:'),('unparsed records',len(records),text.count('violation type:'))
log=(base/'openroad.log').read_text();counts=list(map(int,re.findall(r'Number of violations = (\d+)',log)));assert counts
result=dict(passed=True,whole_system_qualified=False,full_tool_violation_counts_by_iteration=counts,detailed_report_records=len(records),detailed_report_is_partial=len(records)<counts[-1],sample_extent_um=dict(x0=min(r['box_um'][0]for r in records),x1=max(r['box_um'][2]for r in records),y0=min(r['box_um'][1]for r in records),y1=max(r['box_um'][3]for r in records)),sample_type_counts=dict(types),sample_layer_counts=dict(layers),top_sample_net_pairs=[dict(nets=k,count=v)for k,v in pairs.most_common(15)],top_sample_driver_instances=drivers.most_common(15),unknown_sample_nets=sorted(unknown),die_um=[place['width_um'],place['height_um']],records=records,scope='Complete parse of returned detailed DRC text, compared to full-tool iteration counts. The text is a partial report, not an unbiased sample or allDRC positions. Source mapping covers report records only; no global region/cause/feasibility claim. Snapshot fails strictcheckerboard and DRC, not systemqualified.')
(base/'sample-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k!='records'}))
