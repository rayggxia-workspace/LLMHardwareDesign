from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453';out=b/'r256-halo-scene-audit-1587';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=root/'cap-candidates/5380/placement.json';q=root/'cap-candidates/15850/placement.json';a=json.loads(p.read_text());c=json.loads(q.read_text());expected=json.loads(p.read_text());expected['width_um']+=1024;expected['height_um']+=1024
expected['placements_um']={n:[x+512,y+512]for n,(x,y)in a['placements_um'].items()};mapping={}
for n,(x,y)in a['external_grid_pins'].items():
 if x==8:z=[8,y+128]
 elif x==a['width_um']//4-8:z=[x+256,y+128]
 elif y==8:z=[x+128,8]
 else:assert y==a['height_um']//4-8;z=[x+128,y+256]
 mapping[(x,y)]=z;expected['external_grid_pins'][n]=z
expected['terminals']={n:[mapping.get(tuple(v),[v[0]+128,v[1]+128])for v in vs]for n,vs in a['terminals'].items()}
assert expected==c and len(c['placements_um'])==345
assert c['graph_sha256']==sha(root/'topology/boundary-graph.json')=='49ba0e348f3583f6facdf60e771fe6f1329b46fe5aac872c3828d4b61ddb1a68'
receipt=root/'cap-candidates/15850/receipt.json';r=json.loads(receipt.read_text());assert r['passed'];cap=root/'cap-candidates/15850/wire-cap-lower-bound.json';d=json.loads(cap.read_text());assert d['executed']and d['low_variant_wire_only_violations']==0 and not d['whole_system_qualified']
counts={v:sum(row['wire_capacitance_lower_bound_ff'][v]>row['physical_driver']['max_capacitance_ff'] for row in d['rows'])for v in ['low','base','high']};assert counts==dict(low=0,base=0,high=0)
for f in ['placement.json','wire-cap-lower-bound.json']:assert r['outputs'][f]==sha(q.parent/f)
out.mkdir();result=dict(passed=True,time=time.time(),inputs={str(f):sha(f)for f in [p,q,receipt,cap]},macro_count=345,terminals=sum(map(len,c['terminals'].values())),die_um=[c['width_um'],c['height_um']],wire_only_necessary_violations=counts,whole_system_qualified=False,scope='Independent exact reconstruction: all345 macro origins translated512um, orientations/graph unchanged; external pins moved outward to new boundary, NOT a rigid translation of external wires. Every actual terminal reconstructed and exact. Necessary wire-only cap all3variants0, excludes pin capacitance and actual detours; final native geometry PG distributed RC300MHz mandatory. Existing source1526/no RTL or macro changes. Corrects earlier1585 queue human scope that incorrectly said all pinpair distances unchanged.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
