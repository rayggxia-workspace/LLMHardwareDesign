from pathlib import Path
import json,hashlib,collections
p=Path(r'D:\Data\电路实验\control162-snapshot1582');d=json.loads((p/'sample-analysis.json').read_bytes());s=json.loads((p/'placement.json').read_bytes());ends={tuple(v)for vv in s['terminals'].values()for v in vv};rows=[]
for r in d['records']:
 if r['type']!='Cut Short' or 'obstruction:'not in r['srcs']:continue
 x0,y0,x1,y1=r['box_um'];x=((x0+x1)/2-.095)/4;y=((y0+y1)/2-.07)/4;assert abs(x-round(x))<1e-5 and abs(y-round(y))<1e-5;x,y=round(x),round(y);assert(x+y)%2==1;rows.append(dict(grid=[x,y],at_actual_terminal=(x,y)in ends,nets=r['nets']))
assert len(rows)==2506 and sum(r['at_actual_terminal']for r in rows)==761
result=dict(passed=True,whole_system_qualified=False,inputs={f:hashlib.sha256((p/f).read_bytes()).hexdigest()for f in ['drc.rpt','placement.json','sample-analysis.json']},obstruction_cutshort_records=len(rows),all_reported_obstruction_cutshort_centers_on_forbidden_parity=True,at_actual_terminal=sum(r['at_actual_terminal']for r in rows),records=rows,scope='Exact classification of returned partial15995record report only; full iteration has1646347violations. Cut keepouts ARE recognized by DRT; current failed snapshot nevertheless places cuts there. This does not prove pinaccess is sole cause or all violations located here; no parser/gate/technology changes.')
(p/'obstruction-classification1593.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k!='records'}))

