import json
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453')
for f in ['cap-candidates/5380/placement.json','cap-candidates/15850/placement.json','cap-candidates/15850/wire-cap-lower-bound.json']:
 p=b/f;d=json.loads(p.read_text());print(f,list(d));print(json.dumps({k:v for k,v in d.items() if k not in ['placements_um','terminals','orientations','external_grid_pins','inputs','outputs','nets','violations']})[:3500])
