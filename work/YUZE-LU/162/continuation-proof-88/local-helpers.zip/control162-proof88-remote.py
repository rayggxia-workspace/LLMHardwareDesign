from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-88';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set()
def add(p):
 p=Path(p)
 if p.is_file()and p.stat().st_size<8000000:selected.add(p)
def tree(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.rglob('*'):add(f)
for f in ['r256-current-cugr-snapshot-15770','r256-halo-scene-audit-1587','r256-final-chain-binding-audit-1589','r256-halo-actual-audit-1590']:tree(b/f)
for f in ['sready1584-existing-routing-halo','sready1585-existing-routing-halo','sready1588-current-cugr-halo-fullchain']:
 p=b/'route-selection-102'/f;tree(p)
 for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for f in ['placement.json','routing-halo.json','wire-cap-lower-bound.json','receipt.json']:add(b/'r256-composition-453/cap-candidates/15850'/f)
for f in ['current-cugr-snapshot15770.json','acceptance-15860.json']:add(b/'r256-composition-453'/f)
for pattern in ['*sready1577*','*sready1584*','*sready1585*','*sready1588*']:
 q=b/'dynamic-05/node4'
 for sub in ['', 'commands','results']:
  for p in(q/sub).glob(pattern):add(p)
for folder in ['r256-present-growth-progress-1537','r256-all-pool-watch-1407']:
 for p in(b/folder).glob('*.json'):
  if p.stem.isdigit()and int(p.stem)>=1793816000000000:add(p)
for f in ['r256-halo-scene-audit-1587','r256-final-chain-binding-audit-1589','r256-halo-actual-audit-1590']:assert json.loads((b/f/'receipt.json').read_text())['passed']
snapshot=json.loads((b/'r256-current-cugr-snapshot-15770/snapshot.json').read_text());assert not snapshot['actual_router_drc_empty']and not snapshot['independent_original_grid_check']['passed']
out.mkdir();captures=out/'live-captures';captures.mkdir()
for seed in [15220,15640,15860]:
 root=b/'r256-composition-453/upper-candidates'/str(seed)/'route';p=root/'openroad-search/case-0/openroad.log';dst=captures/(str(seed)+'.log');dst.write_bytes(p.read_bytes());add(dst)
 for f in ['placement.json','openroad-search/case-0/run.tcl','openroad-search/case-0/terminals.json']:add(root/f)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
index=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Completed15770 bounded actualDRCdiagnosis fails strictDRC/checkerboard; detailed15995partial vs full1646347, no globalposition/cause claim. Existing512um halo cap15850, independent1587 exact345macro/24760terminal reconstruction including outward externalpins and all3wireonly necessary cap0. Original failed15840 illegalcap-only lockflag preserved. Current453/source1526 fullCUGR15860 sevenstages strictly1589 bound and actual1590 ownnode4 aggregate225forecast286required admission, originalfull15220/FastRoute15640 and allother/Rtasks untouched. Template queue display incorrectly still saysFastRoute in onefield; actualargs/TCL and1590 proveCUGR. Eightparents36x16dynamic,c96six. No complete fullroute/nativegeometryPG/3RC300MHz qualification; physicalwork continues.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive))))
