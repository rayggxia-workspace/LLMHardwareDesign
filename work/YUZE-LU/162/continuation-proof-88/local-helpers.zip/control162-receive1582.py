from pathlib import Path
import subprocess,json,hashlib,shlex
base=Path(r'D:\Data\电路实验');out=base/'control162-snapshot1582';assert not out.exists();out.mkdir();b='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';sources={name:b+'/r256-current-cugr-snapshot-15770/'+name for name in ['receipt.json','snapshot.json','drc.rpt','openroad.log','snapshot.tcl']}
sources.update({'boundary-graph.json':b+'/r256-composition-453/topology/boundary-graph.json','placement.json':b+'/r256-composition-453/upper-candidates/15220/route/placement.json','config.json':b+'/r256-composition-453/current-cugr-snapshot15770.json'})
hashes=subprocess.check_output(['ssh','-o','ConnectTimeout=15','yuzelu@10.129.166.172','sha256sum '+' '.join(shlex.quote(p)for p in sources.values())],timeout=45).decode().splitlines();expected={line.split(None,1)[1]:line.split(None,1)[0]for line in hashes};files={}
for name,path in sources.items():
 subprocess.check_call(['scp','-o','ConnectTimeout=15','yuzelu@10.129.166.172:'+path,str(out/name)])
 data=(out/name).read_bytes();digest=hashlib.sha256(data).hexdigest();assert digest==expected[path];files[name]=dict(source=path,sha256=digest,bytes=len(data))
(out/'reception.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,files=files),indent=2),encoding='utf-8');print(json.dumps(dict(passed=True,files=len(files),diagnostic=json.loads((out/'snapshot.json').read_bytes()))))
