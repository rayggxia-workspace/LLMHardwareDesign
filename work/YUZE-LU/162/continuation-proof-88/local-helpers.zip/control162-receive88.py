from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
base=Path(r'D:\Data\电路实验');root=base/'LLMHardwareDesign-worktrees/issue-162-control';dest=root/'work/YUZE-LU/162/continuation-proof-88';assert not dest.exists();dest.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-88/'
sha=lambda d:hashlib.sha256(d).hexdigest()
for name in ['index.json','selected-originals.zip']:subprocess.check_call(['scp','-o','ConnectTimeout=15','yuzelu@10.129.166.172:'+remote+name,str(dest/name)])
d=json.loads((dest/'index.json').read_bytes());assert sha((dest/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='e445290482f42783c59bd83891cd18e06606dab50eb0be3c8acfa3ebb70cdca0'
with zipfile.ZipFile(dest/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==51
 for r in d['files'].values():data=z.read(r['zip_entry']);assert len(data)==r['bytes']and sha(data)==r['sha256']
names=['control162-inspect1586-remote.py','control162-audit1587-remote.py','control162-queue1588-remote.py','control162-audit1589-remote.py','control162-actual1590-remote.py','control162-build1588.py','control162-router1592-remote.py','control162-receive1582.py','control162-analyze1583.py','control162-classify1593.py','control162-classify1593-original.py','control162-proof88-remote.py','control162-receive88.py','control162-online1581-verified.json']
for n in ['queue1584-remote','queue1585-remote']:names.append('control162-'+n+'.py')
files={n:(base/n).read_bytes()for n in names}
for n in ['sample-analysis.json','obstruction-classification1593.json','obstruction-classification1593-original.json','reception.json']:files['snapshot1582/'+n]=(base/'control162-snapshot1582'/n).read_bytes()
files['publish1579-receipt.json']=(base/'control162-git-data-publish-1579/receipt.json').read_bytes()
with zipfile.ZipFile(dest/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,data in files.items():z.writestr(n,data)
with zipfile.ZipFile(dest/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==data for n,data in files.items())
(dest/'local-index.json').write_text(json.dumps(dict(files={n:dict(bytes=len(data),sha256=sha(data),zip_entry=n)for n,data in files.items()},archive=dict(path='local-helpers.zip',bytes=(dest/'local-helpers.zip').stat().st_size,sha256=sha((dest/'local-helpers.zip').read_bytes()))),indent=2),encoding='utf-8')
(dest/'reception.json').write_text(json.dumps(dict(passed=True,remote_entries=51,local_entries=len(files),zip_crc_member_bytes_sha256_verified=True,whole_system_qualified=False,scope='Snapshot rawDRC/failure, exact halo preflight/audit/full7stage/actual11149terminal admission evidence. Local classification firstincorrecttype spelling produced0 and original is preserved; correctedexactCut Short asserts2506/761, allforbiddenparity. Rawpartialreport cannot establishglobalcause. No code/gate changes or systemqualification.'),indent=2),encoding='utf-8')
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
text='''# Issue162：当前组合DRC定位完成，外圈留白对照进入完整物理链

更新时间：{now}。承接[Checkpoint87]({prefix}work/YUZE-LU/162/continuation-checkpoint-87.md)，新证据见[Checkpoint88]({prefix}work/YUZE-LU/162/continuation-checkpoint-88.md)及[51项原件源绑定]({prefix}work/YUZE-LU/162/continuation-proof-88/index.json)。15770真实一轮诊断完成但失败：完整工具1646347违规、严格原棋盘过孔拒绝。详细报告仅15995项，其中2506项过孔撞禁用点障碍、761项位于实际接点；证明障碍被识别，不能据此声称全部失败源于引脚接入。

复用source1526已有512um留白功能，15850前置与1587独立核验345宏/24760接点通过：die9380²变10404²，宏相对摆放不变，外部引脚向新边界移动，部分外部连线会变长；三档仅线电容必要下界均0超限，不含pin/native实际RC。15860当前453完整CUGR七阶段已实际启动，1589严格当前函数/自己几何PG三档RC配置、1590实际11149网/接点/225GiB汇总预测需286GiB可用准入通过。后继STA224GiB在支持256GiB的原node4队列未拒绝。保留原失败15840与原15220/FastRoute15640完整任务，不动其他任务或R。

**仍无完整全图零冲突、实际几何/native XOR/PG/low-base-high分布RC300MHz setup/hold/电气联合通过。继续物理定位，不以此检查点收尾，不放宽门，不合并。** 保留main六宏、R256、S1350内部驱动、23类型138份六文件及345状态宿主。实际8父节点36×16，c96六独立槽动态补位；登记PR5 pending，看板unverified/同步pending，审查待指定。

'''
for path,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=root/path;p.write_text(text.format(now=now,prefix=prefix)+p.read_text(encoding='utf-8'),encoding='utf-8')
note='[Checkpoint88](../work/YUZE-LU/162/continuation-checkpoint-88.md)：15770诊断实际DRC/严格棋盘拒绝，15995项详细报告为部分记录；完整统计1646347。15850/1587核验已有512um外圈留白、三档wire-only必要电容0超限；宏相对位置不变，外部引脚外移。15860当前453/source1526完整CUGR七阶段实际接入11149网，225GiB预测/286GiB可用门通过，仍无系统物理资格。原组合继续，全部300MHz/native几何PG/三档RC门保持。\n\n'
for path in ['docs/CONTROL_V1.md','docs/ARCHITECTURE.md']:
 p=root/path;t=p.read_text(encoding='utf-8');first,rest=t.split('\n',1);p.write_text(first+'\n\n'+note+rest.lstrip('\n'),encoding='utf-8')
(root/'work/YUZE-LU/162/continuation-checkpoint-88.md').write_text(text.format(now=now,prefix='../../../')+'[实际接收核验](continuation-proof-88/reception.json)与[本地定位/辅助索引](continuation-proof-88/local-index.json)均按ZIP CRC、成员字节和SHA核验。源1526（6c066dc2eb5cf11e500b62f08f480b0844798962）复用，生产代码、RTL、M1–M10宏及全部验收门未变。1585队列说明中“全部pinpair距离不变”不准确，1587明确更正外部引脚向外移动；1588复用模板的一处显示字段仍写FastRoute，实际参数/TCL/1590均核实CUGR。原件均保留，不能用说明代替实际证据。\n',encoding='utf-8')
a=root/'.gitattributes';a.write_text(a.read_text(encoding='utf-8')+'\nwork/YUZE-LU/162/continuation-proof-88/** -text\n',encoding='utf-8');print(json.dumps(dict(passed=True,remote_entries=51,local_entries=len(files))))
