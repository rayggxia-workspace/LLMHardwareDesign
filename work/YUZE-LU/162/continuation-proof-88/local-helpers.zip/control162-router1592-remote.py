from pathlib import Path
import re,json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/upper-candidates')
for seed in [15220,15640,15860]:
 p=b/str(seed)/'route/openroad-search/case-0/openroad.log';t=p.read_text();lines=[s for s in t.splitlines()if any(x in s.lower()for x in ['wire length','wirelength','overflow','capacity','metal11','metal12','resources','final congestion'])];print(seed,json.dumps(lines[-30:]))
