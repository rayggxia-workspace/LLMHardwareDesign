from pathlib import Path
p=Path(r'D:\Data\电路实验');s=(p/'control162-audit1603-remote.py').read_text(encoding='utf-8-sig').replace('sready1606-existing-density-placement','sready1610-existing-density-hard-budget').replace('r256-density-placement-audit-1603','r256-density-placement-audit-1611').replace('16060','16100').replace('/cap-necessary-1606/','/cap-necessary-1610/').replace("='100000000'","='1000000000'")
s=s.replace("str(b/'route-selection-102/sready1604-density-placement-refill/receipt.json')]","str(b/'route-selection-102/sready1604-density-placement-refill/receipt.json'),str(b/'r256-composition-453/cap-necessary-1606/16060/native-pin-load/receipt.json')]")
s=s.replace("a=json.loads((record/'old-capture.json').read_text())","a=json.loads((b/'route-selection-102/sready1606-existing-density-placement/old-capture.json').read_text())")
s=s.replace('sole searchknob localdensity1e6 to1e8, seed4610 and budgetweight5000 unchanged','existing localdensity1e9 and existingbudgetpenalty1e9 instead5000, seed4610 unchanged; explicitly two objective scales, source/thresholds unchanged')
(p/'control162-audit1611-remote.py').write_text(s,encoding='utf-8')
