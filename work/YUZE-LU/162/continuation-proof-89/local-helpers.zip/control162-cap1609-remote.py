from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453')
for p in [b/'cap-candidates/16060/receipt.json',b/'cap-candidates/16060/wire-cap-lower-bound.json',b/'cap-necessary-1606/16060/native-residual/receipt.json',b/'cap-necessary-1606/16060/native-pin-load/receipt.json']:
 if p.exists():
  d=json.loads(p.read_text());print(str(p),json.dumps({k:v for k,v in d.items()if k not in ['inputs','outputs','rows']})[:1600])
