from pathlib import Path
import json,re,collections,hashlib,zipfile
base=Path(r'D:\Data\电路实验');dest=base/'control162-congestion1597';graph=json.loads((base/'control162-snapshot1582/boundary-graph.json').read_bytes());physical=json.loads((dest/'physical.json').read_bytes());z=zipfile.ZipFile(base/'LLMHardwareDesign-worktrees/issue-162-control/work/YUZE-LU/162/continuation-proof-88/selected-originals.zip');prefix='r256-composition-453/cap-candidates/15850/placement.json';halo=json.loads(z.read(prefix));original=json.loads((base/'control162-snapshot1582/placement.json').read_bytes());results=[]
for seed,scene,digest in [(15220,original,'36604274e96299439bad026456d1e7b25c00af471f3b8a3854f773cc4fb44ab4'),(15860,halo,'686c7ac926fc7ecaed418e268ebf31604e8adf2e2c6c0ba2f8866c9838f5fa52')]:
 p=dest/('congestion'+str(seed)+'.rpt');assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;raw=p.read_text();pat=r'violation type: ([^\n]+)\n\s*srcs: ([^\n]+)\n\s*comment: capacity:([\d.]+) usage:([\d.]+) congestion:([\d.]+)([^\n]*)\n\s*bbox = \(([-\d.]+), ([-\d.]+)\) - \(([-\d.]+), ([-\d.]+)\) on Layer (\w+)';records=[];drivers=collections.Counter();macro_bins=collections.Counter();bins=collections.Counter();net_hits=collections.Counter()
 for match in re.finditer(pat,raw):
  kind,src,capacity,usage,congestion,comment,x0,y0,x1,y1,layer=match.groups();box=list(map(float,[x0,y0,x1,y1]));nets=re.findall(r'net:(\S+)',src);c=float(congestion);r=dict(type=kind,nets=nets,capacity=float(capacity),usage=float(usage),congestion=c,via_comment=comment,box_um=box,layer=layer);records.append(r);bins[(int((box[0]+box[2])/2000),int((box[1]+box[3])/2000),layer)]+=c
  for n in set(nets):
   net_hits[n]+=1;key=n[4:];connection=graph['connections'].get(key)
   if connection:drivers[connection['driver']['instance']]+=c/max(1,len(set(nets)))
 assert len(records)==raw.count('violation type:'),(len(records),raw.count('violation type:'))
 hotspots=sorted(records,key=lambda r:-r['congestion'])[:15]
 for r in hotspots:
  x=(r['box_um'][0]+r['box_um'][2])/2;y=(r['box_um'][1]+r['box_um'][3])/2;inside=[]
  for n,(mx,my)in scene['placements_um'].items():
   w,h=physical['leaves'][graph['instances'][n]]['die_um']
   if mx<=x<=mx+w and my<=y<=my+h:inside.append(n)
  r['center_over_macro_footprint']=inside
 results.append(dict(candidate=seed,report_sha256=digest,records=len(records),sum_reported_congestion=sum(r['congestion']for r in records),layer_record_counts=dict(collections.Counter(r['layer']for r in records)),largest_reported_congestion=hotspots,weighted_driver_counts=drivers.most_common(12),top_1mm_bins=[dict(bin=list(k),congestion=v)for k,v in bins.most_common(10)],top_nets=net_hits.most_common(12)))
result=dict(passed=True,whole_system_qualified=False,reports=results,scope='Exact parse of returned OpenROAD GRT congestion reports, all returned records parsed. This is globalguide congestion, not final DRC or proof of preferred/wrongway physical capacity. Counts and weighted driver attribution describe these guide results only, no causal or infeasibility claim. Actual source453graph and exact scene positions used, macro footprints only M1-M10 and do not themselves forbid M11/M12 routing.')
(dest/'analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({**result,'reports':[{k:v for k,v in r.items()if k not in ['largest_reported_congestion','top_nets']}for r in results]}));print(json.dumps([dict(candidate=r['candidate'],largest=r['largest_reported_congestion'][:2])for r in results]))
