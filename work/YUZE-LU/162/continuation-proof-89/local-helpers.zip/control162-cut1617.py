from pathlib import Path
import json,hashlib,collections
b=Path(r'D:\Data\电路实验\control162-density1617');p=b/'placement.json';r=json.loads((b/'receipt.json').read_bytes());assert r['passed']and r['inputs']['/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/cap-candidates/16100/placement.json']==hashlib.sha256(p.read_bytes()).hexdigest();d=json.loads(p.read_bytes());axes=[]
for axis in [0,1]:
 delta=collections.Counter()
 for ends in d['terminals'].values():
  lo=min(v[axis]for v in ends);hi=max(v[axis]for v in ends)
  if lo<hi:delta[lo]+=1;delta[hi]-=1
 live=0;peak=(0,0)
 for k in sorted(delta):
  live+=delta[k]
  if live>peak[0]:peak=live,k
 capacity=d['height_um'if axis==0 else'width_um']//4-8;axes.append(dict(axis=axis,required_nets=peak[0],cut=peak[1],one_preferred_direction_tracks=capacity,two_layer_grid_upper_capacity=capacity*2))
result=dict(passed=True,whole_system_qualified=False,axes=axes,scope='All originalsource16100 actualterminals, failureonly straight-cut diagnosis; lackofviolations doesnotprove finalroutability or timing. Onepreferredlayer for OpenROADguide context, bothlayers for finalgrid context; optimisticcapacities excludeobstacles/pins. See3537869 proof88 original5380cut1596 keptoutside repo untilnextsourceindex.')
(b/'cut-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
