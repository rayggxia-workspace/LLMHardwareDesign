from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/cap-candidates')
for seed in [4610,4611,16060]:
 p=b/str(seed);rows=[]
 for i in range(16):
  f=p/('electrical-placement-'+str(i)+'.txt')
  if f.exists():rows.append(dict(trial=i,metrics=list(map(float,f.read_text().splitlines()[0].split()))))
 print(seed,json.dumps(dict(completed=len(rows),least_necessary_violations=min((r['metrics'][5]for r in rows),default=None),best=sorted(rows,key=lambda r:(r['metrics'][5],r['metrics'][0]))[:3],receipt=(p/'receipt.json').exists(),scene=(p/'placement.json').exists())))
