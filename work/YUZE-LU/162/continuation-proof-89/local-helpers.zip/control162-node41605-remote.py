from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/dynamic-05/node4');s=json.loads((b/'queue-state.json').read_text())
for n in s['active']:
 p=b/'pending'/(n+'.json');d=json.loads(p.read_text());a=d['args'];print(n,d['source_root'],d['forecast_gib'],a[a.index('--out')+1])
