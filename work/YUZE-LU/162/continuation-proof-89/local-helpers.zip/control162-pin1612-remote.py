from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/cap-necessary-1606/16060/native-pin-load/native-pin-load.json');d=json.loads(b.read_text());print('keys',list(d));print(json.dumps({k:v for k,v in d.items()if k!='placements'})[:1500])
for p in d['placements']:
 print('placement',json.dumps({k:v for k,v in p.items()if k!='rows'})[:1800]);print('rowexample',json.dumps(p['rows'][0])[:1200]);bad=[r for r in p['rows']if any('viola'in k and v is True for k,v in r.items())];print('badrows',json.dumps(bad)[:3000])
