from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453');p=b/'cap-necessary-1610/16100/native-pin-load/native-pin-load.json';print('ready',p.exists())
if p.exists():
 d=json.loads(p.read_text());print(json.dumps([dict(placement=x['placement'],violations=x['violations'])for x in d['placements']]))
q=b/'cap-candidates/16100/placement-search.json';d=json.loads(q.read_text());e=d['electrical_refinement'];print('selected',e['selected_seed']);print('dims',json.loads((q.parent/'placement.json').read_text())['width_um'],json.loads((q.parent/'placement.json').read_text())['height_um'])
