from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/cap-candidates';rows=[]
for p in sorted(root.iterdir(),key=lambda p:int(p.name)if p.name.isdigit()else 0):
 if not p.is_dir()or not(p/'placement-search.json').is_file():continue
 d=json.loads((p/'placement-search.json').read_text());e=d.get('electrical_refinement',d);r=json.loads((p/'receipt.json').read_text())if(p/'receipt.json').exists()else{};s=json.loads((p/'placement.json').read_text())if(p/'placement.json').exists()else{};rows.append(dict(seed=p.name,passed=r.get('passed'),capacity=e.get('capacity_target'),local_weight=e.get('local_density_weight'),local_model=e.get('local_density_model'),residual=e.get('native_ground_and_minimum_input_caps_in_objective'),selected=e.get('selected_seed'),die=[s.get('width_um'),s.get('height_um')]))
print(json.dumps(rows));print('count',len(rows))
