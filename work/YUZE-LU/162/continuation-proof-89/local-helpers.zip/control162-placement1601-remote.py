from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for seed in [4610,4611]:
 p=b/'r256-composition-453/cap-candidates'/str(seed)/'wire-cap-lower-bound.json';d=json.loads(p.read_text());print(seed,'wireviol',d['low_variant_wire_only_violations'])
 for f in b.glob('dynamic-*/node*/pending/*'+str(seed)+'*.json'):
  d=json.loads(f.read_text());print(str(f),json.dumps(d))
