from pathlib import Path
import json,hashlib,collections
p=Path(r'D:\Data\电路实验\control162-snapshot1582/placement.json');s=json.loads(p.read_bytes());axes=[]
for axis in [0,1]:
 delta=collections.Counter()
 for ends in s['terminals'].values():
  lo=min(v[axis]for v in ends);hi=max(v[axis]for v in ends)
  if lo<hi:delta[lo]+=1;delta[hi]-=1
 live=0;peak=0;cut=None
 for k in sorted(delta):
  live+=delta[k]
  if live>peak:peak=live;cut=k
 names=[n for n,v in s['terminals'].items()if min(t[axis]for t in v)<=cut<max(t[axis]for t in v)];assert len(names)==peak
 tracks=s['height_um'if axis==0 else'width_um']//4-8
 axes.append(dict(axis=axis,cut_grid=cut,required_distinct_nets=peak,original_preferred_only_available_tracks=tracks,original_two_layer_grid_upper_capacity=2*tracks,halo512_preferred_only_available_tracks=tracks+256,halo1024_preferred_only_available_tracks=tracks+512,net_names=names))
result=dict(passed=True,placement_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),whole_system_qualified=False,axes=axes,hpwl_um=sum(4*(max(t[0]for t in v)-min(t[0]for t in v)+max(t[1]for t in v)-min(t[1]for t in v))for v in s['terminals'].values()),scope='Failure-only preferred-direction grid cut diagnostic for OpenROAD guide search; M11 horizontal/M12 vertical leaves only one layer crossing each straight full-die cut. Both physical model layers allow wrong-way wires, so preferred-only excess is NOT a proof that final native accepted routing is impossible; not an acceptance gate. No obstructions/pin/spacing/PG reserved capacity removed, capacity optimistic. Original4um margin used. Halo1024 columns show original central cuts only and do NOT prove new externalpin cuts or actual routability/timing. Existing halo512 still allowed to finish; no cancelled task/source/gate change.')
out=Path(r'D:\Data\电路实验\control162-preferred-cut1596.json');out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({**result,'axes':[{k:v for k,v in a.items()if k!='net_names'}for a in axes]}))
