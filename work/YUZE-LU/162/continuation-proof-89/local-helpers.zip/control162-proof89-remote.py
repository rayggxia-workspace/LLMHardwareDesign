from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-89';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set();external={}
def add(p):
 p=Path(p)
 if not p.is_file():return
 if p.stat().st_size<=8000000:selected.add(p)
 else:external[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=False)
def tree(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.rglob('*'):add(f)
for name in ['r256-density-placement-audit-1603','r256-density-actual-audit-1607','r256-density-placement-audit-1611','r256-density-necessary-failure-1613','r256-density-completed-audit-1617','r256-final-chain-binding-audit-1619','r256-density-full-actual-audit-1620','r256-final-chain-binding-audit-1623']:tree(b/name)
for name in ['sready1606-existing-density-placement','sready1604-density-placement-refill','sready1610-existing-density-hard-budget','sready1618-current-cugr-density-fullchain','sready1622-current-fastroute-density-fullchain']:
 p=b/'route-selection-102'/name;tree(p)
 if(p/'tasks.json').is_file():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for seed,label in [(16060,1606),(16100,1610)]:
 tree(b/'r256-composition-453/cap-candidates'/str(seed));tree(b/'r256-composition-453'/('cap-necessary-'+str(label))/str(seed))
for seed in [16180,16220]:add(b/'r256-composition-453'/('acceptance-'+str(seed)+'.json'))
for folder in ['dynamic-05/node4','dynamic-04/node25','dynamic-08/node6']:
 for glob in ['*sready1606*','*sready1610*','*sready1618*','*sready1622*']:
  q=b/folder
  for sub in ['', 'commands','results']:
   for f in(q/sub).glob(glob):add(f)
add(b/'control162-queue1602-remote.py');add(b/'control162-actual1614-remote.py')
for n in ['linked_floorplan.py','floorplan.py','electrical_floorplan.py','electrical_floorplan.cpp','placement_residual_budget.py','placement_orientation.py']:add(b/'source-1526/project/experiments/control_v1'/n)
for name in ['r256-present-growth-progress-1537','r256-all-pool-watch-1407']:
 for p in(b/name).glob('*.json'):
  if p.stem.isdigit()and int(p.stem)>=1793817100000000:add(p)
out.mkdir();captures=out/'live-captures';captures.mkdir();states=[]
for seed in [15220,15640,15860,16180,16220]:
 root=b/'r256-composition-453/upper-candidates'/str(seed)/'route';log=root/'openroad-search/case-0/openroad.log'
 if log.exists():dst=captures/(str(seed)+'.log');dst.write_bytes(log.read_bytes());add(dst)
 for f in ['receipt.json','placement.json','openroad-search/case-0/run.tcl','openroad-search/case-0/terminals.json']:add(root/f)
 states.append(dict(candidate=seed,route_receipt_exists=(root/'receipt.json').is_file(),final_router_output=(root/'router-output.txt').is_file(),global_log_exists=log.exists()))
for seed,label in [(16060,1606),(16100,1610)]:
 p=b/'r256-composition-453'/('cap-necessary-'+str(label))/str(seed)/'native-pin-load/native-pin-load.json';d=json.loads(p.read_text());assert d['placements'][0]['violations']==(dict(low=0,base=0,high=4)if seed==16060 else dict(low=0,base=0,high=0))
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
index=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,external_files=external,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),actual_route_file_states=states,scope='Actual full CUGR512umhalo15860 globalcongestion370718.66 vs original375738.88 only1.34percent improvement, no physicalpass. Reuse6floorplanner helperbytes exact451/1526, fixed4610 RNG originalinput bodies equal. Exact own14470 source1440 step95391.151 afterall16logs40+rounds/UID/job/node/cmd/spec/source/currentgraph/nooutput/memoryguard retired, alloriginals/parents/other35fullchains/R retained; initial1602 wrong64 vsactual65 forecast refused beforequeue/cancel. New16060 density1e8 actual16outputs, high4native+pin necessaryfailures rejectfullroute;16100 existingdensity1e9 also activatesexistingbudgetpenalty1e9, actual16outputs/cost/nonoverlap and native/pinall3zero. Scene12412x14464,345macros11149nets24760terminals, originalmacros/graph/RTL/gates fixed; significantarea/wire cost not a pass. New16180 originalCUGR7stage/strict1619 and actual1620 exactscene/nets/4disjoint16CPU/192GiBforecast246.4GiB admission. Same16100FastRoute16220 queued ownnode25natural vacancy, 3future224GiBSTA existingnode6/source269 supports256, strict1623. Failed1614 livePIDaudit ran after floorplanner exited; no falseCPUclaim, completed1617 evidence authoritative. No fullzero/nativegeometryPG/3RC300MHz qualification; taskcontinues.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(passed=True,files=len(files),external_files=len(external),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive),route_states=states)))
