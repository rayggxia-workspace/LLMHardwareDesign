from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
base=Path(r'D:\Data\电路实验');root=base/'LLMHardwareDesign-worktrees/issue-162-control';dest=root/'work/YUZE-LU/162/continuation-proof-89';assert not dest.exists();dest.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-89/';sha=lambda d:hashlib.sha256(d).hexdigest()
for name in ['index.json','selected-originals.zip']:subprocess.check_call(['scp','-o','ConnectTimeout=15','yuzelu@10.129.166.172:'+remote+name,str(dest/name)])
d=json.loads((dest/'index.json').read_bytes());assert sha((dest/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='049c6aee758809515ee38d9be940a8c6438a9b8c620b0d0505fc02f6c11daecd'
with zipfile.ZipFile(dest/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==542
 for row in d['files'].values():data=z.read(row['zip_entry']);assert len(data)==row['bytes']and sha(data)==row['sha256']
names=['preferred-cut1596.py','congestion1597.py','snapshots1599-remote.py','placement1600-remote.py','placement1601-remote.py','queue1602-remote.py','node41605-remote.py','queue1606-remote.py','audit1603-remote.py','build1604.py','refill1604-remote.py','actual1607-remote.py','density1608-remote.py','cap1609-remote.py','queue1610-remote.py','audit1611-remote.py','build1611.py','pin1612-remote.py','failure1613-remote.py','actual1614-remote.py','density1615-remote.py','pin1616-remote.py','audit1617-remote.py','cut1617.py','build1618.py','queue1618-remote.py','audit1619-remote.py','actual1620-remote.py','build1622.py','queue1622-remote.py','audit1623-remote.py','proof89-remote.py','receive89.py']
files={'control162-'+n:(base/('control162-'+n)).read_bytes()for n in names}
for n in ['control162-online1598-verified.json','control162-preferred-cut1596.json']:files[n]=(base/n).read_bytes()
for n in ['physical.json','congestion15220.rpt','congestion15860.rpt','analysis.json']:files['congestion1597/'+n]=(base/'control162-congestion1597'/n).read_bytes()
for n in ['placement.json','receipt.json','cut-analysis.json']:files['density1617/'+n]=(base/'control162-density1617'/n).read_bytes()
files['publish1595-receipt.json']=(base/'control162-git-data-publish-1595/receipt.json').read_bytes()
with zipfile.ZipFile(dest/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,data in files.items():z.writestr(n,data)
with zipfile.ZipFile(dest/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==data for n,data in files.items())
(dest/'local-index.json').write_text(json.dumps(dict(files={n:dict(bytes=len(data),sha256=sha(data),zip_entry=n)for n,data in files.items()},archive=dict(path='local-helpers.zip',bytes=(dest/'local-helpers.zip').stat().st_size,sha256=sha((dest/'local-helpers.zip').read_bytes()))),indent=2),encoding='utf-8')
(dest/'reception.json').write_text(json.dumps(dict(passed=True,remote_entries=542,external_hashed_entries=4,local_entries=len(files),zip_crc_member_bytes_sha256_verified=True,whole_system_qualified=False,scope='Actual failed16060 fourhighnecessary caps rejected, completed16100 all3necessary0, originalfloorplanner input/corebytebinding; 16180 fullCUGR strict7/actual4CPUslots,16220 fullFastRoute queue with224STA on256capablecontroller. Original1602 guardfail beforequeue/cancel; onlyverifiedown14470child retired, allparents/otherjobs retained. Both GRTdetailedreports each10000 perlayer and globaltotalsmuchhigher: partial/coordinatebiased, cannot use sampletopdriver/bin asglobalcause. Preferredcutcomparisons failureonly, no finalroutability/timing proof.'),indent=2),encoding='utf-8')
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter='''# Issue162：收敛真实拥塞定位，固定宏重新摆放进入完整物理链

更新时间：{now}。[Checkpoint89]({prefix}work/YUZE-LU/162/continuation-checkpoint-89.md) / [542项原件源绑定与4项外置大文件]({prefix}work/YUZE-LU/162/continuation-proof-89/index.json)。原453/S5380 CUGR15220全局拥塞375738.88，512um外圈留白15860为370718.66，仅改善1.34%；两者详细布线仍未通过。返回GRT报告各层恰10000记录、合计远少于全量拥塞，不能用样本定位全局根因。原摆放两个截面的2591/2731网超过每个优选方向2337轨道；两层允许反向走线，所以不是最终不可布证明。

本轮复用source1526中与已通过451逐字相同的六个摆放组件，固定原4610随机种子与其余11178行输入，只用已有密度/预算参数。16060的16候选最少仍有4条高RC必要电容违例，实际native/pin复查确认，拒绝完整布线。16100启用已有density1e9及budget penalty1e9，16个候选经原独立代价/非重叠/输出SHA检查，选中465622；实际345宏/11149网/24760接点重构与low/base/high原生地电容＋最低输入负载＋最短上层线必要条件均0违例。die12412×14464，面积和线长明显增加；宏内部、有效逻辑图和全部门不变，不能当成物理通过。

16180原CUGR完整七阶段已实际运行；1619严格7规格/当前函数/自己的geometry-PG-三档RC配置，1620核实实际全部接点、四组互斥16CPU、192GiB预测需246.4GiB可用准入。16220同一新摆放的FastRoute完整七阶段已排入node25自然空槽；三个224GiB后继STA直接放支持256GiB的现有node6队列，1623严格核验通过，避免旧控制器128GiB上限。当前均未继承系统资格。

本轮仅fresh核验并替换本人14470/source1440子步骤95391.151：16日志均40+轮，specSHA/UID/job/实际node/PID/全命令/当前图/无输出/实际内存全部记录，旧源/规格/日志/失败保留。首次1602误填64GiB而实际65，被任何排队/取消前拒绝；1606按实际值重新核验。其余35活动链、八父分配及外部R不动，后续16100和16180自然补位。1614活进程审计晚于C++结束而拒绝，不宣称捕获其进程；已完成1617和后继真实1620为证据。

**仍无完整全图零冲突、实际几何/native XOR/PG和low/base/high分布RC300MHz setup/hold/电气联合通过。继续物理定位，不在检查点收尾，不放宽门，不合并。** main六宏/R256/S1350内部驱动、23类型138份六文件和345状态宿主保留。8父节点36×16动态，c96各六槽；实际内存门保持。登记PR5 pending，看板unverified/同步pending，审查待指定。

'''
for path,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=root/path;p.write_text(chapter.format(now=now,prefix=prefix)+p.read_text(encoding='utf-8'),encoding='utf-8')
note='[Checkpoint89](../work/YUZE-LU/162/continuation-checkpoint-89.md)：外圈留白全局拥塞仅改善1.34%，改用原已验摆放器及原4610 RNG优化内部密度。16060高RC必要电容4条失败拒绝完整布线；16100选中465622，345宏/11149网/24760接点及三档native/min-pin必要条件0违例。16180完整CUGR实际四组16CPU/192GiB预测246.4GiB准入通过；同摆放FastRoute16220七阶段排队，224GiBSTA放支持256GiB控制器。仍无完整零冲突/几何PG/三档RC300MHz联合通过，继续任务。\n\n'
for path in ['docs/CONTROL_V1.md','docs/ARCHITECTURE.md']:
 p=root/path;t=p.read_text(encoding='utf-8');first,rest=t.split('\n',1);p.write_text(first+'\n\n'+note+rest.lstrip('\n'),encoding='utf-8')
(root/'work/YUZE-LU/162/continuation-checkpoint-89.md').write_text(chapter.format(now=now,prefix='../../../')+'原件：[远程/外置源索引](continuation-proof-89/index.json)、[本地分析与辅助来源](continuation-proof-89/local-index.json)、[实际接收核验](continuation-proof-89/reception.json)，承接[88](continuation-checkpoint-88.md)。必要电容0仅排除该失败条件，不包含真实树/绕线/所有负载与分布RC；新布局比原布局更大、总线更长，真实300MHz验收仍可能失败。禁止将GRT部分报告的排序样本当作完整空间分布或归因；旧直截面超优选容量不代表两层反向走线不可行，新直截面未超同样不能证明布通。\n',encoding='utf-8')
a=root/'.gitattributes';a.write_text(a.read_text(encoding='utf-8')+'\nwork/YUZE-LU/162/continuation-proof-89/** -text\n',encoding='utf-8');print(json.dumps(dict(passed=True,remote_entries=542,local_entries=len(files),external_hashed_entries=4)))
