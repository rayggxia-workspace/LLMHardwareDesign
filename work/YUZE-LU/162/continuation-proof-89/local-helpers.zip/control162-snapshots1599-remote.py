from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-composition-453/upper-candidates')
for seed in [14030,14310,14470,14780,14781,15340,15341]:
 p=b/str(seed)/'route/trial-0';print(seed,json.dumps([dict(path=str(f),bytes=f.stat().st_size)for f in p.glob('*global-round*')]))
