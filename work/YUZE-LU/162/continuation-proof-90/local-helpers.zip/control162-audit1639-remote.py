from pathlib import Path
import json,hashlib,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1526';new=b/'source-1638';out=b/'r256-parity-source-audit-1639';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names={'project/experiments/control_v1/openroad_router_probe.py','project/experiments/control_v1/system_upper.py'}
a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());assert z['commit']=='e1bed24bb845af9c4840dd874649462d467b87dd' and len(z['files'])==1028 and {p for p,v in z['files'].items() if a['files'].get(p)!=v}==names
expected='9a507edfcd1c831439031b9b8386b5c9ef22f3e87c037218948626733108f4e3';assert sha(b/'source1638.tar.gz')==expected and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==expected and all(sha(new/p)==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for name in names:
 p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1638.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/name).read_bytes()==(old/name).read_bytes() for name in names)
gates=['system_geometry.py','system_sta.py','system_accept.py','final_composition.py','native_pin_load.py','native_cap_residual.py','upper_cap_bound.py','steiner_wire_bound.py','placement_residual_budget.py','openroad_grid.py']
for name in gates:assert (new/'project/experiments/control_v1'/name).read_bytes()==(old/'project/experiments/control_v1'/name).read_bytes()
r=dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1028,unchanged_files=1026,two_file_scratch_backout_exact=True,final_gates_byteexact=gates,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch)},scope='Experimental default-OFF parity-aware passive search markers. Odd local cut keepout duplicates original global forbidden center; unchanged pin area/origin, native masks/RTL, technology, original strict grid and all final gates. Actual5case preflight mandatory before new full candidate; no system qualification. First import failed before archive open due filename, empty directory preserved as source-1638-empty-import-01; exactnamed archive then imported and allfiles audited.')
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
