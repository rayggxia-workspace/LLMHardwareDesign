import subprocess,shlex
q='''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for n in ['r256-current-cugr-snapshot-15770','r256-custom-guide-snapshot-16340','r256-paired-parity-snapshot-16530','r256-paired-legacy-snapshot-16531']:
 p=b/n;f=p/'openroad.log'
 if f.exists():
  s=f.read_text();print(n,'completed_counts',re.findall(r'Number of violations = ([0-9]+)',s),'tail',s[-150:]);r=p/'snapshot.json';print('result',json.loads(r.read_text())if r.exists()else'notfinal')
for seed in [16220,16420]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if f.exists():
  with f.open('rb')as h:h.seek(max(0,f.stat().st_size-6000));s=h.read().decode(errors='replace')
  print('full',seed,s[-550:]);r=p/'receipt.json';print('final',json.loads(r.read_text()).get('passed')if r.exists()else'notfinal')
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
