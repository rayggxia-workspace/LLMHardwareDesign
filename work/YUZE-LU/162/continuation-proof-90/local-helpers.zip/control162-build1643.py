from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-audit1623-remote.py').read_text()
s=s.replace('r256-final-chain-binding-audit-1623','r256-final-chain-binding-audit-1643').replace('sready1622-current-fastroute-density-fullchain','sready1642-parity-density-fullchain').replace('16220','16420').replace('source-1526','source-1638')
s=s.replace("+1]=='fastroute'","+1]=='cugr'")
s=s.replace("str(b/'r256-current-openroad-backend-audit-1525/receipt.json')in route['requires']and str(b/'r256-existing-fastroute-preflight-15620/receipt.json')in route['requires']","str(b/'r256-parity-source-audit-1639/receipt.json')in route['requires']and str(b/'r256-parity-marker-preflight-16400/receipt.json')in route['requires'] and '--openroad-parity-aware-markers' in a")
s=s.replace('/dynamic-04/node25/','/dynamic-02/node3/').replace("actual_backend='fastroute'","actual_backend='cugr'")
start=s.index("scope='Read-only strict7stage");end=s.index("')",start)
s=s[:start]+"scope='Read-only strict7stage binding for source1638/CUGR parity-markers and unchanged scene16100/current453, actual5fixture16400 required. Original sixkey geometryPG threeRC300MHz gates unchanged, own future outputs and224GiBSTA node6. Diagnostic preflight is not fullsystemqualification; externalR/other tasks protected"+s[end:]
assert "+1]=='cugr'" in s and "source-1638" in s
(b/'control162-audit1643-remote.py').write_text(s)
