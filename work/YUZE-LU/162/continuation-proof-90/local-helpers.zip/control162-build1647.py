from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-actual1645-remote.py').read_text().replace('r256-parity-full-actual-audit-1645','r256-parity-full-actual-audit-1647').replace("adm['required_bytes']==int((224*1.2+16)*1024**3)","adm['required_bytes']==(224*1.2+16)*1024**3")
(b/'control162-actual1647-remote.py').write_text(s)
