from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-prepare1649-remote.py').read_text().replace('r256-parity-paired-inputs-1649','r256-parity-paired-inputs-1650').replace("nx=p['nx'],ny=p['ny']","nx=int(p['width_um']/4),ny=int(p['height_um']/4)")
s=s.replace("assert len(p['terminals'])==11149","assert len(p['terminals'])==11149 and p['width_um']%4==0 and p['height_um']%4==0")
(b/'control162-prepare1650-remote.py').write_text(s)
