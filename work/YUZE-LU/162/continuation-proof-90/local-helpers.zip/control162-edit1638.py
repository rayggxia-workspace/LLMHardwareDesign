from pathlib import Path
import ast
root=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control');p=root/'project/experiments/control_v1/openroad_router_probe.py';s=p.read_text(encoding='utf-8');assert 'parity_aware_markers'not in s
start=s.index('    marker_lef.write_text(');end=s.index('    records = []',start);old=s[start:end]
helper='''def landing_markers(parity_aware=False):
    """Keep legacy pins byteexact; odd masters duplicate existing cut keepouts."""
    text = 'VERSION 5.6 ;\\nBUSBITCHARS "[]" ;\\nDIVIDERCHAR "/" ;\\n'
    for direction in ('INPUT', 'OUTPUT'):
        for parity in ((0, 1) if parity_aware else (None,)):
            name = 'search_landing_' + direction.lower()
            if parity is not None:
                name += '_odd' if parity else '_even'
            text += (f'MACRO {name}\\n CLASS BLOCK ;\\n ORIGIN 0 0 ;\\n SIZE 2 BY 2 ;\\n'
                     f' PIN P\\n  DIRECTION {direction} ;\\n  USE SIGNAL ;\\n  PORT\\n   LAYER metal11 ;\\n'
                     '   RECT 0 0 2 2 ;\\n  END\\n END P\\n')
            if parity == 1:
                # The instance origin is landing_center minus1um. At2000DBU/um
                # this is exactly the same center+/-1DBU forbidden cut already
                # present in the block. Encode it in the master as well so PA
                # need not share a via-capable master across both parities.
                text += (' OBS\\n  LAYER via11 ;\\n'
                         '  RECT 0.9995 0.9995 1.0005 1.0005 ;\\n END\\n')
            text += 'END ' + name + '\\n'
    return text + 'END LIBRARY\\n'


'''
s=s.replace('def run(out, scene=None, congestion_iterations=5, global_router=\'cugr\',guide_pitch=4):',helper+'def run(out, scene=None, congestion_iterations=5, global_router=\'cugr\',guide_pitch=4,parity_aware_markers=False):',1);s=s.replace(old,'    marker_lef.write_text(landing_markers(parity_aware_markers))\n',1);s=s.replace('for mode in (range(3) if scene is None else [0]):','for mode in (range(5 if parity_aware_markers else 3) if scene is None else [0]):',1)
s=s.replace("        else:\n            terminals = {'bus_' + str(i)","        elif mode == 2:\n            terminals = {'bus_' + str(i)",1)
needle="        (folder / 'terminals.json').write_text";assert s.count(needle)==1;s=s.replace(needle,"        elif mode == 3:\n            terminals = {'odd_horizontal': [(8, 9), (38, 9)]}\n        else:\n            assert mode == 4\n            terminals = {'odd_vertical': [(9, 8), (9, 38)]}\n"+needle,1)
needle='                xx, yy = 190+8000*x, 140+8000*y\n';assert s.count(needle)==1;s=s.replace(needle,needle+"                master_name = 'search_landing_' + ('output' if index == 0 else 'input')\n                if parity_aware_markers:\n                    master_name += '_odd' if (x+y)%2 else '_even'\n",1)
needle="'set master [$db findMaster search_landing_' + ('output' if index == 0 else 'input') + ']'";assert s.count(needle)==1;s=s.replace(needle,"'set master [$db findMaster ' + master_name + ']'",1)
needle="    (out / 'openroad-probe.json').write_text";s=s.replace(needle,"    if parity_aware_markers:\n        result['parity_aware_search_landing_markers'] = True\n        result['scope'] += ' Search masters split by original via parity; odd master cut obstruction exactly duplicates an already forbidden site, with native masks and all original gates unchanged.'\n"+needle,1)
s=s.replace("def route(terminals, nx, ny, seed, out, wire_limits, congestion_iterations=5, global_router='cugr',guide_pitch=4):","def route(terminals, nx, ny, seed, out, wire_limits, congestion_iterations=5, global_router='cugr',guide_pitch=4,parity_aware_markers=False):",1)
s=s.replace("congestion_iterations,global_router,guide_pitch)\n", "congestion_iterations,global_router,guide_pitch,parity_aware_markers)\n",1);ast.parse(s);p.write_text(s,encoding='utf-8')
p=root/'project/experiments/control_v1/system_upper.py';s=p.read_text(encoding='utf-8');assert 'openroad_parity_aware_markers'not in s
needle="    p.add_argument('--openroad-snapshot-config'";s=s.replace(needle,"    p.add_argument('--openroad-parity-aware-markers',action='store_true',\n                   help='Search only: split passive landing masters by original via parity; duplicate odd cut keepouts, never alter native masks or gates')\n"+needle,1)
needle='    a=p.parse_args()\n';s=s.replace(needle,needle+"    assert not a.openroad_parity_aware_markers or (not(a.openroad_snapshot_config or a.cap_lower_bound_only or a.plan_only) and (a.openroad_router_probe_only or (a.router=='openroad' and a.reuse_placement))), 'Parity markers require actual OpenROAD probe or reused-placement routing'\n",1)
s=s.replace('guide_pitch=a.openroad_guide_pitch_um)\n','guide_pitch=a.openroad_guide_pitch_um,parity_aware_markers=a.openroad_parity_aware_markers)\n',1);s=s.replace('a.openroad_global_router,a.openroad_guide_pitch_um)\n','a.openroad_global_router,a.openroad_guide_pitch_um,a.openroad_parity_aware_markers)\n',1);ast.parse(s);p.write_text(s,encoding='utf-8')
print('Edited only passive OpenROAD search markers and CLI forwarding; original acceptance untouched')
