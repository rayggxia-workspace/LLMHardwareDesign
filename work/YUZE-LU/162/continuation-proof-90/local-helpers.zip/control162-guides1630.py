from pathlib import Path
import json,hashlib,collections,time
b=Path(r'D:\Data\电路实验');source=b/'LLMHardwareDesign-deliveries/issue-162/actual-round-diagnostic-1408';out=b/'LLMHardwareDesign-deliveries/issue-162/custom-grid-guides-1630';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=json.loads((source/'reception.json').read_bytes());snap=source/'snapshot.txt';inp=source/'input.txt';assert sha(snap)==rec['received']['snapshot']['sha256'];assert sha(inp)==rec['received']['input']['sha256'];diag=json.loads((source/'analysis/receipt.json').read_bytes());assert diag['passed']and not diag['whole_system_qualified']and diag['diagnostic']['conflict_nodes']==1643883
lines=inp.read_text().splitlines();header=list(map(int,lines[0].split()));nx,ny,count=header[:3];assert [nx,ny,count]==[2345,2345,11149];nets=[]
for line in lines[1:]:
 a=line.split();k=int(a[1]);assert len(a)==3+2*k;nets.append((a[0],[tuple(map(int,a[2+2*i:4+2*i]))for i in range(k)]))
assert len(nets)==count;assert len({n for n,_ in nets})==count
pitch=6;dbu=8000;phase=[190,140];guide=out/'route.guide';stats=collections.Counter();started=time.time()
def merge(cells):
 rects=[]
 for layer in [0,1]:
  ys=collections.defaultdict(list)
  for x,y,l in cells:
   if l==layer:ys[y].append(x)
  active={}
  for y in sorted(ys):
   xs=sorted(ys[y]);runs=[];lo=hi=xs[0]
   for x in xs[1:]:
    if x==hi+1:hi=x
    else:runs.append((lo,hi));lo=hi=x
   runs.append((lo,hi));current=set(runs)
   for key,(ya,yb)in list(active.items()):
    if key not in current or yb!=y-1:rects.append((key[0],ya,key[1],yb,layer));del active[key]
   for key in runs:
    if key in active:active[key][1]=y
    else:active[key]=[y,y]
  for key,(ya,yb)in active.items():rects.append((key[0],ya,key[1],yb,layer))
 check={(x,y,l)for x0,y0,x1,y1,l in rects for x in range(x0,x1+1)for y in range(y0,y1+1)};assert check==cells
 return sorted(rects,key=lambda r:(r[4],r[1],r[0],r[3],r[2]))
with snap.open()as f,guide.open('w',newline='\n')as g:
 assert int(f.readline())==count
 for name,ends in nets:
  row=f.readline().split();assert row[0]==name;branches=int(row[1]);points=set();cells=set();wire=wrong=via=0
  for _ in range(branches):
   a=list(map(int,f.readline().split()));assert len(a)==1+3*a[0];prev=None
   for i in range(1,len(a),3):
    p=tuple(a[i:i+3]);x,y,l=p;assert 4<=x<nx-4 and 4<=y<ny-4 and l in [0,1];points.add(p);cells.add((x//pitch,y//pitch,l))
    if prev is not None:
     assert sum(abs(x-y)for x,y in zip(prev,p))==1
     if l!=prev[2]:assert(x+y)%2==0;via+=1
     else:
      wire+=1
      if(l==0 and y!=prev[1])or(l==1 and x!=prev[0]):wrong+=1
    prev=p
  assert all((*xy,0)in points for xy in ends);rects=merge(cells);g.write(name+'\n(\n')
  for x0,y0,x1,y1,l in rects:
   xx0=phase[0]+pitch*dbu*x0;yy0=phase[1]+pitch*dbu*y0;xx1=min(nx*dbu,phase[0]+pitch*dbu*(x1+1));yy1=min(ny*dbu,phase[1]+pitch*dbu*(y1+1));assert 0<=xx0<xx1<=nx*dbu and 0<=yy0<yy1<=ny*dbu;g.write('%d %d %d %d metal%d\n'%(xx0,yy0,xx1,yy1,11+l))
  g.write(')\n');stats.update(nets=1,source_path_points=len(points),guide_cells=len(cells),guide_rectangles=len(rects),source_wire_steps=wire,source_wrongway_steps=wrong,source_via_steps=via)
 assert not f.read().strip()
assert stats['nets']==11149 and stats['source_wrongway_steps']>0
result=dict(passed=True,whole_system_qualified=False,time=time.time(),source={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in [snap,inp,source/'analysis/receipt.json',Path(__file__)]},guide=dict(path=str(guide),bytes=guide.stat().st_size,sha256=sha(guide)),grid=[nx,ny],dbu_per_um=2000,original_grid_pitch_dbu=8000,guide_cell_grid_pitch=6,guide_cell_pitch_um=24,phase_dbu=phase,stats=dict(stats),elapsed_seconds=time.time()-started,scope='Data-only generation from actual14030 round8 source-bound complete connected11149 failed trees. Original snapshots have1643883crossnetconflicts and are NOT accepted physicalroutes. Union of actualpath24um cells pernet/layer, exact rectangle-cell coverage independently reconstructed, all actualterminalM11 cells covered; legal original4um unitsteps/via checkerboard checked. Retains both originalallowed directions, no layer/track/technology/acceptance changes. Guides are hints only, no finalconductors imported or connectivity/DRC/RC pass claimed. To be replayed by unchanged frozen source1526 openroad_snapshot for bounded diagnosis; originalnative/finalacceptance stays mandatory.')
(out/'receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items()if k!='source'}))
