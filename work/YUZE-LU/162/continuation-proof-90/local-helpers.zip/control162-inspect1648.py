import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates'
for seed in [16180,16420]:
 p=root/str(seed)/'route/openroad-search/case-0'
 print(seed,[(n,(p/n).stat().st_size if(p/n).exists()else None)for n in ['before.odb','route.guide','terminals.json','run.tcl']])
q=b/'dynamic-02/node3';st=json.loads((q/'queue-state.json').read_text())
for n in st['active']:
 p=q/'pending'/(n+'.json');d=json.loads(p.read_text());a=d['args'];print(n,'source',d['source_root'],'forecast',d['forecast_gib'],'args',a if '10711'in n else 'omitted')
print('snapshotconfig', (b/'r256-custom-guide-preparation-1632/snapshot.json').read_text())
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
