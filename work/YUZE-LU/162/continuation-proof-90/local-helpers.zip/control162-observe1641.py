from pathlib import Path
import subprocess,shlex
q='''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-parity-marker-preflight-16400'
for name in ['receipt.json','probe-progress.json','openroad-probe.json']:
 f=p/name
 if f.exists(): print(name,f.read_text()[-8000:])
for f in sorted(p.glob('case-*/openroad.log')):
 s=f.read_text();print(str(f),s[-1500:]);print('PA',re.findall(r'.*(?:unique.*master|macro.*[Aa][Pp]|valid.*[Aa][Pp]|ERROR|WARN).*',s)[-15:])
for seed in [15220,15860,16180,16220]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if f.exists():
  with f.open('rb')as h: h.seek(max(0,f.stat().st_size-8000));s=h.read().decode(errors='replace')
  print('FULL',seed,s[-1600:]);r=p/'receipt.json';print('RECEIPT',r.read_text()[-1000:]if r.exists()else'notfinal')
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
