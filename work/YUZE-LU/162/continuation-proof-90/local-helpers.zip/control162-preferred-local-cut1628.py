from pathlib import Path
import json,collections,hashlib,numpy as np
b=Path(r'D:\Data\电路实验');g=json.loads((b/'control162-snapshot1582/boundary-graph.json').read_bytes());rows=[]
for label,p in [('S5380',b/'control162-snapshot1582/placement.json'),('new16100',b/'control162-density1617/placement.json')]:
 s=json.loads(p.read_bytes());names=list(s['terminals']);ids={n:i for i,n in enumerate(names)};points=[];netids=[]
 for n,vs in s['terminals'].items():points.extend(vs);netids.extend([ids[n]]*len(vs))
 points=np.array(points);netids=np.array(netids);x,y=points.T;total=np.bincount(netids,minlength=len(names));groups=collections.defaultdict(list)
 for k,c in g['connections'].items():
  n='net_'+k
  for e,point in zip([c['driver']]+c['sinks'],s['terminals'][n]):
   if e['instance']=='s_port'and e['pin'].split('[')[0].lower()not in ['clk','rst_n','reset_n','vdd','vss']:groups['s_port-all'].append(point)
 for key,ps in groups.items():
  xx,yy=zip(*ps)
  for margin in [0,4,8,16,32,64]:
   x0,y0,x1,y1=min(xx)-margin,min(yy)-margin,max(xx)+margin,max(yy)+margin;w=x1-x0+1;h=y1-y0+1;capacity=2*(w+h)
   demands={}
   for safety in [0,6,12]:
    inside=(x>=x0+safety)&(x<=x1-safety)&(y>=y0+safety)&(y<=y1-safety);outside=(x<x0-safety)|(x>x1+safety)|(y<y0-safety)|(y>y1+safety);i=np.bincount(netids[inside],minlength=len(names));o=np.bincount(netids[outside],minlength=len(names));demands[str(safety)]=int(((i>0)&(o>0)).sum())
   rows.append(dict(scene=label,group=key,margin_grid=margin,rect_grid=[x0,y0,x1,y1],optimistic_preferred_only_crossing_edges=capacity,required_nets_with_inner_outer_safety_grid=demands))
result=dict(passed=True,whole_system_qualified=False,rows=rows,scope='Conditional search-model cut only, one H layer and one V layer; fullphysical model allows wrongway, so these are NOT finalphysical infeasibility claims or acceptance gates. Counts with6/12grid erosion/dilation deliberately ignore endpoints near cut, to inspect sensitivity to24/48um GCell pinmapping; doesnot assert internal GRT mapping proof. Actual all11149 terminalsets sourcebound to scenes; exact S_port pinbbox and all signal endpoints, fixed macro unchanged. Useful to decide whether DRT guides need wrongway support instead of merely largerdie.')
(b/'control162-preferred-local-cut1628.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
