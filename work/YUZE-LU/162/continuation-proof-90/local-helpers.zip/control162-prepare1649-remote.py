from pathlib import Path
import json,hashlib,os,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');base=b/'r256-composition-453/upper-candidates';record=b/'r256-parity-paired-inputs-1649';assert not record.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=base/'16180/route/openroad-search/case-0';new=base/'16420/route/openroad-search/case-0';assert(old/'terminals.json').read_bytes()==(new/'terminals.json').read_bytes();p=json.loads((base/'16420/route/placement.json').read_text());assert p==json.loads((b/'r256-composition-453/cap-candidates/16100/placement.json').read_text());assert len(p['terminals'])==11149
assert json.loads((b/'r256-parity-full-actual-audit-1647/receipt.json').read_text())['passed']
guide=old/'route.guide';assert guide.stat().st_size>0;record.mkdir();cases=[]
for label,scene in [('parity',new),('legacy',old)]:
 folder=record/label;folder.mkdir();case=folder/'case-0';case.mkdir();inputs={}
 for n in ['before.odb','terminals.json','run.tcl','route.guide']:
  src=guide if n=='route.guide'else scene/n;dst=case/n;os.link(str(src),str(dst));inputs[n]=dict(path=str(dst),sha256=sha(dst))
 cfg=dict(schema='control162-openroad-search-snapshot-v1',iterations=1,nx=p['nx'],ny=p['ny'],inputs=inputs);(folder/'snapshot.json').write_text(json.dumps(cfg,indent=2));cases.append(dict(label=label,config=str(folder/'snapshot.json'),inputs=inputs))
assert cases[0]['inputs']['route.guide']['sha256']==cases[1]['inputs']['route.guide']['sha256'] and cases[0]['inputs']['terminals.json']['sha256']==cases[1]['inputs']['terminals.json']['sha256']
(record/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),cases=cases,whole_system_qualified=False,scope='Paired diagnostic: exact same16180globalguide, scene16100/11149terminals and unchanged snapshothelper1526; original16180preODB versus source1638 parity-aware16420preODB, each source/tcl SHA bound. No guide/wire/native-mask/grid change. Oneiteration only, never acceptedfullroute or systemqualification.'),indent=2));print(json.dumps(dict(passed=True,paired_configs=2,nets=11149)))
