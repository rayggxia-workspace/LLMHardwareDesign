from pathlib import Path
import json,hashlib,time,zipfile,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-90';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set();external={}
def add(p):
 p=Path(p)
 if not p.is_file():return
 if p.stat().st_size<=12000000:selected.add(p)
 else:external[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=False)
def tree(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.rglob('*'):add(f)
for name in ['r256-density-fastroute-actual-audit-1626','r256-original-fastroute-failure-1627','r256-custom-guide-data-1630','r256-custom-guide-preparation-1632','r256-custom-guide-snapshot-16340','r256-parity-source-audit-1639','r256-parity-marker-preflight-16400','r256-final-chain-binding-audit-1643','r256-parity-full-actual-audit-1647','r256-parity-paired-inputs-1649','r256-parity-paired-inputs-1650']:tree(b/name)
for name in ['sready1633-existing-custom-guide-snapshot','sready1635-custom-guide-snapshot-refill','sready1640-parity-marker-preflight','sready1642-parity-density-fullchain','sready1651-paired-parity-snapshot','sready1652-paired-parity-refill','sready1653-paired-parity-natural-refill']:
 p=b/'route-selection-102'/name;tree(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
for n in ['control162-actual1645-remote.py','control162-prepare1649-remote.py','control162-refill1652-remote.py','control162-backout1638.patch','source-1638/source-manifest.json','source-1638/freeze-import.json']:add(b/n)
for n in ['openroad_router_probe.py','system_upper.py','openroad_snapshot.py','openroad_grid.py']:add(b/'source-1638/project/experiments/control_v1'/n)
for folder in ['dynamic-02/node3','dynamic-04/node25','dynamic-08/node6']:
 q=b/folder
 for glob in ['*sready1633*','*sready1640*','*sready1642*','*sready1651*','*sready1653*']:
  for sub in ['','commands','results']:
   for f in(q/sub).glob(glob):add(f)
out.mkdir();captures=out/'live-captures';captures.mkdir();states=[]
for seed in [15220,15860,16180,16220,16420]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route';log=p/'openroad-search/case-0/openroad.log'
 if log.exists():f=captures/(str(seed)+'.log');f.write_bytes(log.read_bytes());add(f)
 for f in ['receipt.json','placement.json','openroad-search/case-0/run.tcl','openroad-search/case-0/terminals.json']:add(p/f)
 states.append(dict(seed=seed,route_receipt_exists=(p/'receipt.json').exists(),final_route_output_exists=(p/'router-output.txt').exists()))
for p in [b/'source1638.tar.gz',b/'r256-composition-453/acceptance-16420.json']:add(p)
files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
with zipfile.ZipFile(str(archive))as z:assert z.testzip()is None
index=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,external_files=external,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),actual_route_file_states=states,scope='Preserves actual15640globalcongestion failure,16340customguide diagnostic DRC/grid failure, defaultOFF paritymarkers source1638 all1028/sourcebackout audit1639; actual5fixtures16400 emptyDRC/strictgrid/9negativecases and oddPA0via. Full16420 same16100/current453 sevenstages strict1643/actual1647four16CPU/224forecast284.8GiBadmission, futureSTA224node6. Pair1650 same16180guides/terminals oldvsparityODB, bounded diagnostic only, queued1653naturalnode25vacancy. Attempt1652 retirement guard failed beforeanycancel as notall10711logs40+, old10711kept. Partial1649prep KeyError nx preserved; corrected1650 usesactual width/4 exactlysystem_upper. First1638freeze wrongarchivefilename failedbeforecopy, emptydir retained; fullimport1639audited. Actual1645observer beforeplacement refused, completed1647liveaudit authoritative. No completefullzero/nativegeometryPG/threeRC300MHz qualification; existingall8parents/otherjobs/externalR retained; taskcontinues.')
(out/'index.json').write_text(json.dumps(index,indent=2));print(json.dumps(dict(passed=True,files=len(files),external=len(external),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive),states=states)))
