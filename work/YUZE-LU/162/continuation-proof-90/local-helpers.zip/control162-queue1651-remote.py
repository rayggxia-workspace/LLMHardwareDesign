from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready1651-paired-parity-snapshot';assert not record.exists();prep=b/'r256-parity-paired-inputs-1650';assert json.loads((prep/'receipt.json').read_text())['passed'];q=b/'dynamic-02/node3';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for n in json.loads((q/'queue-state.json').read_text())['active']:
 p=q/'pending'/(n+'.json');d=json.loads(p.read_text());a=d['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='10711':rows.append(dict(path=str(p),sha256=sha(p),spec=d))
assert len(rows)==1 and rows[0]['spec']['source_root']==str(b/'source-1064') and rows[0]['spec']['forecast_gib']==64
template=json.loads((b/'route-selection-102/sready1633-existing-custom-guide-snapshot/tasks.json').read_text())['tasks'][0]['spec'];tasks=[]
for index,label in enumerate(['parity','legacy']):
 spec=json.loads(json.dumps(template));a=spec['args'];a[a.index('--openroad-snapshot-config')+1]=str(prep/label/'snapshot.json');a[a.index('--out')+1]=str(b/('r256-paired-'+label+'-snapshot-'+str(16510+index)));spec['requires']=[str(prep/'receipt.json'),str(b/'r256-present-pressure-source-audit-1528/receipt.json'),str(b/'route-selection-102/sready1652-paired-parity-refill/receipt.json')]
 if index:spec['requires'].append(str(b/'r256-paired-parity-snapshot-16510/receipt.json'))
 p=q/'pending'/('00-a-sready1651-paired-'+label+'-'+str(16510+index)+'.json');assert not p.exists();tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);tasks.append(dict(path=str(p),sha256=sha(p),spec=spec))
record.mkdir();(record/'old-capture.json').write_text(json.dumps(dict(passed=True,time=time.time(),rows=rows),indent=2));(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=tasks,whole_system_qualified=False,scope='Paired unchanged-helper diagnostic of original16180 and parity16420 preODB under identical16180guide/terminals/scene16100. Newparity first thenlegacy baseline in existing c64 one16CPU slot, original joblimit four16CPU. Freshguard own10711/source1064 old search only,64GiB replaced32GiB. Allsource/spec/logs/partialoutputs retained; no parent/externalR/old3751/otherjobs changed. EmptyDRC and original strictgrid remain, diagnostics never finalqualification.'),indent=2));print(json.dumps(dict(queued=2,forecast_gib=32,serial_reason='existing c64four16CPU slots; paired oneiteration diagnostics in one retiredownslot')))
