from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
base=Path(r'D:\Data\电路实验');root=base/'LLMHardwareDesign-worktrees/issue-162-control';dest=root/'work/YUZE-LU/162/continuation-proof-90';assert not dest.exists();dest.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-90/';sha=lambda d:hashlib.sha256(d).hexdigest()
for n in ['index.json','selected-originals.zip']:subprocess.check_call(['scp','yuzelu@10.129.166.172:'+remote+n,str(dest/n)])
d=json.loads((dest/'index.json').read_bytes());assert sha((dest/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='c9573b4dd8e559c39e059c3ddf675acc5d3f0356357f632dccc0b3f551eda91e'
with zipfile.ZipFile(dest/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==181
 for row in d['files'].values():data=z.read(row['zip_entry']);assert len(data)==row['bytes']and sha(data)==row['sha256']
names=['actual1626-remote.py','failure1627-remote.py','preferred-local-cut1628.py','guides1630.py','prepare1632-remote.py','queue1633-remote.py','build1635.py','refill1635-remote.py','edit1638.py','check1638.py','stage1638.py','audit1639-remote.py','queue1640-remote.py','observe1641.py','queue1642-remote.py','build1643.py','audit1643-remote.py','build1645.py','actual1645-remote.py','state1646.py','build1647.py','actual1647-remote.py','inspect1648.py','prepare1649-remote.py','build1650.py','prepare1650-remote.py','queue1651-remote.py','build1652.py','refill1652-remote.py','queue1653-remote.py','brief1654.py','proof90-remote.py','receive90.py']
files={'control162-'+n:(base/('control162-'+n)).read_bytes()for n in names}
for n in ['control162-preferred-local-cut1628.json','control162-online1636-verified.json','control162-backout1638.patch']:files[n]=(base/n).read_bytes()
files['publish1644-receipt.json']=(base/'control162-git-data-publish-1644/receipt.json').read_bytes();files['local1638-receipt.json']=(base/'control162-local1638/receipt.json').read_bytes();files['guides1630-receipt.json']=(base/'LLMHardwareDesign-deliveries/issue-162/custom-grid-guides-1630/receipt.json').read_bytes()
with zipfile.ZipFile(dest/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,data in files.items():z.writestr(n,data)
with zipfile.ZipFile(dest/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==v for n,v in files.items())
(dest/'local-index.json').write_text(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(dest/'local-helpers.zip').stat().st_size,sha256=sha((dest/'local-helpers.zip').read_bytes()))),indent=2),encoding='utf-8')
(dest/'reception.json').write_text(json.dumps(dict(passed=True,remote_entries=181,external_hashed_entries=5,local_entries=len(files),zip_crc_member_bytes_sha256_verified=True,whole_system_qualified=False,scope='DefaultOFF parity-source1638 legacybyteexact/localcontexts and actual5fixture16400 strictgrid/emptyDRC; full16420 strict7/actual11149/4disjoint16CPU/224forecast284.8memory;16340 diagnostic1193354DRC/gridfail preserved. 1652 guard failed beforeanycancel,10711unchanged; pair1653waits existingnode25naturalvacancy. No complete composition geometryPG/threeRC300MHz acceptance; taskcontinues.'),indent=2),encoding='utf-8')
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter='''# Issue162：实际端口访问修复通过小例，继续完整物理验收

更新时间：{now}。[Checkpoint90]({prefix}work/YUZE-LU/162/continuation-checkpoint-90.md) / [181项原件及5项外置大文件源绑定]({prefix}work/YUZE-LU/162/continuation-proof-90/index.json)。保留main六宏、R256、S1350内部驱动、23类型138份六文件和345实例状态归属。原FastRoute15640实际GRT-0116拥塞失败；自定义guide16340一轮完整1193354违规，严格棋盘过孔导入仍拒绝，失败路线不作为导体导入。

source1638只在两个搜索文件增加默认关闭的parity-aware passive marker。奇数master的1DBU过孔阻挡与原全局禁用点完全重合，不改变引脚面积/坐标、固定宏、RTL、工艺、原网格或最终门。默认LEF与提交前原表达式逐字一致，四个非法上下文在创建输出前拒绝；1028源文件及归档/两文件反向补丁审计通过，1026文件未变。实际16400五个OpenROAD用例全部空DRC、原严格网格/棋盘/连通通过，九项非法导入拒绝；新增奇数水平/垂直端点的pin-access统计via AP为0、planar AP可用。这只支持端口访问修复，不能证明全图短路根因全部解决。

16420按同一current453/16100摆放启动完整七阶段CUGR，供16180原CUGR及16220原FastRoute对照。1643严格绑定原六键、当前函数/345实例及自己的geometry/PG/low-base-high；1647实际11149网/24760端点、四组互斥16CPU和224GiB预测需284.8GiB可用准入通过；三个224GiB后继STA在支持256GiB的已有node6。当前完整零冲突、native几何/XOR/PG和三档RC300MHz联合验收仍未通过。

另用同一16180全局guide、同一11149端点和摆放，准备legacy/parity两份preODB一轮对照1650；1653已排入node25自然空位，原snapshothelper1526逐字复用。1652尝试替换本任务旧10711时，因并非每份旧日志都达到40轮，被任何取消前拒绝；10711继续运行，原排队和guard保留，对照改为自然补位。1649输入准备误读nx键失败保留，1650依据实际width_um/4与height_um/4修正，未改生产代码；1645观察早于placement生成被拒，后续1647实际捕获有效。

8父节点的c96各六16CPU/c64各四16CPU动态补位；未新增分配、未取消父任务/其他任务/外部R。全部原物理和300MHz门保持，继续定位迭代，不在检查点结束任务，不自行合并。登记PR5 pending，看板缺配置/unverified、同步pending，审查待指定。

'''
for path,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=root/path;p.write_text(chapter.format(now=now,prefix=prefix)+p.read_text(encoding='utf-8'),encoding='utf-8')
note='[Checkpoint90](../work/YUZE-LU/162/continuation-checkpoint-90.md)：默认关闭的搜索端口parity修复经过1028文件/反向补丁审计，实际五组OpenROAD空DRC及原网格通过；16420同一16100摆放完整七阶段已实际11149网/四组16CPU/224GiB准入核验。原FastRoute15640和自定义guide16340失败保留；同引导legacy/parity一轮对照待node25自然补位，1652取消guard拒绝、旧10711未动。全部最终门不变，组合物理/三档RC300MHz仍未通过，继续任务。\n\n'
for path in ['docs/CONTROL_V1.md','docs/ARCHITECTURE.md']:
 p=root/path;t=p.read_text(encoding='utf-8');first,rest=t.split('\n',1);p.write_text(first+'\n\n'+note+rest.lstrip('\n'),encoding='utf-8')
(root/'work/YUZE-LU/162/continuation-checkpoint-90.md').write_text(chapter.format(now=now,prefix='../../../')+'[原件](continuation-proof-90/index.json)、[本地来源](continuation-proof-90/local-index.json)、[实收](continuation-proof-90/reception.json)，承接[89](continuation-checkpoint-89.md)。\n',encoding='utf-8')
p=root/'.gitattributes';p.write_bytes(p.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-90/** -text\n');print(json.dumps(dict(passed=True,remote=181,external=5,local=len(files))))
