from pathlib import Path
import subprocess,json,hashlib
r=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control');home=r.parent.parent
git=lambda *args:subprocess.check_output(['git',*args],cwd=r)
assert git('rev-parse','HEAD').decode().strip()=='98f43450e2e351e876020712da3b3c648fc7ea23'
names=['project/experiments/control_v1/openroad_router_probe.py','project/experiments/control_v1/system_upper.py']
subprocess.check_call(['git','diff','--binary','--output='+str(home/'control162-backout1638.patch'),'--',*names],cwd=r)
out=r/'work/YUZE-LU/162/parity-marker-preflight1638';out.mkdir()
(out/'local-receipt.json').write_bytes((home/'control162-local1638/receipt.json').read_bytes())
(out/'check.py').write_bytes((home/'control162-check1638.py').read_bytes())
note='''# Search-only parity-marker experiment1638 — not physical acceptance

Refs #162 / PR #163. Preserves all accepted23 physical types and the current345-instance graph, RTL, native masks, geometry/PG/electrical/300MHz gates. Existing full CUGR/FastRoute candidates continue independently. Original15640 FastRoute actually failed GRT-0116 congestion; its failed receipt/log are retained remotely in r256-original-fastroute-failure-1627. Custom-guide16340 diagnosis executed but actual DRC and strict checkerboard import still failed; no failed route is imported as accepted metal.

The actual15770 pin-access log reused only two passive landing masters across even/odd sites, and the failed snapshot includes cuts overlapping forbidden landing sites. This motivates a hypothesis, not an established root cause: split search-only input/output marker masters by original parity and duplicate the already-existing odd-site 1DBU cut obstruction in each odd master. Actual pin size, location, direction, global cut keepouts, track/grid/technology remain fixed. No final conductor or logic is added by these passive markers.

`--openroad-parity-aware-markers` defaults OFF. Local legacy LEF byte comparison against the committed original expression passed; four masters retain identical2um square pins, both odd obstructions map exactly onto existing global center+/-1DBU keepouts at2000DBU/um. Four unsupported CLI contexts reject before creating output. Source compilation and management-structure check passed. Local receipt and its executed helper are included here.

Actual EDA is **not yet executed** at this source commit. After immutable-source/archive/backout audit, run the original three fixtures plus explicit odd-horizontal and odd-vertical fixtures in a16CPU independent slot using unchanged strict router DRC and original grid importer. Only actual passing preflight permits any new full candidate. Whole composition zero-conflict, actual geometry/PG and three-RC300MHz remain unpassed; no merge or completion claim.

Resource policy: existing8 parent allocations, c96 six16CPU independent jobs/c64 four, dynamic refill. This small preflight follows naturally completed own16340 in node3;16GiB forecast, original admission guard. No parent/external-R/foreign task cancelled. Project registration PR5 pending; board absent/unverified and synchronization pending; reviewer unassigned. Sources and final actual EDA receipts will be indexed in the next continuation evidence package.
'''
(out/'README.md').write_bytes(note.encode())
p=r/'progress/YUZE-LU/STATUS.md';data=p.read_bytes();entry='\n2026-11-05 CST · #162 / PR #163：search-only parity-marker1638本地兼容/禁用上下文通过；实际五例EDA待冻结审计后执行。原FastRoute15640与自定义guide16340失败保留；现有完整候选继续，组合物理/三档RC300MHz仍未通过。见work/YUZE-LU/162/parity-marker-preflight1638/README.md。\n';p.write_bytes(data+entry.encode())
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/parity-marker-preflight1638/** -text\n')
paths=names+['.gitattributes','progress/YUZE-LU/STATUS.md',str(out.relative_to(r)).replace('\\','/')]
subprocess.check_call(['git','add','--',*paths],cwd=r)
for name in names:assert git('show',':'+name)==(r/name).read_bytes()
subprocess.check_call(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r)
subprocess.check_call(['git','commit','-m','Add opt-in parity-aware passive landing markers for strict routing preflight'],cwd=r)
print(git('rev-parse','HEAD').decode().strip())
