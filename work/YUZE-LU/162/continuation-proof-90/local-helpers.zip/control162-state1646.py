import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-02/node3';s=json.loads((q/'queue-state.json').read_text());print('active',s['active']);record=b/'route-selection-102/sready1642-parity-density-fullchain/tasks.json'
for t in json.loads(record.read_text())['tasks']:
 if t['spec']['script']!='system_upper.py':continue
 print('route',t)
 for p in t['spec']['requires']:
  p=Path(p);print('dependency',str(p),p.exists(),json.loads(p.read_text()).get('passed') if p.exists()else None)
 for sub in ['results','commands']:
  p=q/sub/Path(t['path']).name
  if p.exists():print(sub,p.read_text()[-3500:])
for p in sorted(q.glob('*16420*')):print(str(p),p.read_text()[-2500:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
