read_lef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/technology/research12.tech.lef}
read_lef {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/search-landing-markers.lef}
set db [ord::get_db]
set chip [odb::dbChip_create $db [$db getTech]]
set block [odb::dbBlock_create $chip search_probe]
$block setDefUnits 2000
set die [odb::new_Rect 0 0 384000 384000]
$block setDieArea $die
set layer [[$db getTech] findLayer metal11]
set_thread_count 16
set net [odb::dbNet_create $block odd_vertical]
set master [$db findMaster search_landing_output_odd]
set inst [odb::dbInst_create $block $master odd_vertical_p0]
$inst setLocation 70190 62140
$inst setPlacementStatus FIRM
set term [$inst findITerm P]
$term connect $net
set master [$db findMaster search_landing_input_odd]
set inst [odb::dbInst_create $block $master odd_vertical_p1]
$inst setLocation 70190 302140
$inst setPlacementStatus FIRM
set term [$inst findITerm P]
$term connect $net
set guard_layer [[$db getTech] findLayer metal11]
odb::dbObstruction_create $block $guard_layer 0 0 26190 384000
odb::dbObstruction_create $block $guard_layer 350190 0 384000 384000
odb::dbObstruction_create $block $guard_layer 0 0 384000 26140
odb::dbObstruction_create $block $guard_layer 0 350140 384000 384000
set guard_layer [[$db getTech] findLayer metal12]
odb::dbObstruction_create $block $guard_layer 0 0 26190 384000
odb::dbObstruction_create $block $guard_layer 350190 0 384000 384000
odb::dbObstruction_create $block $guard_layer 0 0 384000 26140
odb::dbObstruction_create $block $guard_layer 0 350140 384000 384000
set cut_layer [[$db getTech] findLayer via11]
for {set x 4} {$x < 44} {incr x} { for {set y 4} {$y < 44} {incr y} {
 if {($x+$y)%2} { set xx [expr {190+8000*$x}]; set yy [expr {140+8000*$y}];
 odb::dbObstruction_create $block $cut_layer [expr {$xx-1}] [expr {$yy-1}] [expr {$xx+1}] [expr {$yy+1}] }
} }
for {set i 1} {$i <= 10} {incr i} { make_tracks metal$i -x_offset 0.095 -x_pitch 1.6 -y_offset 0.070 -y_pitch 1.6 }
source {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/search-custom-tracks.tcl}
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
help global_route
help detailed_route
write_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/before.odb}
global_route -use_cugr -grid_origin {190 140} -congestion_iterations 50 -congestion_report_file {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/congestion.rpt} -congestion_report_iter_step 50 -guide_file {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/route.guide} -verbose
detailed_route -output_drc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/drc.rpt} -output_maze {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/maze.log} -via_in_pin_bottom_layer metal11 -via_in_pin_top_layer metal11 -verbose 1
write_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/routed.odb}
write_def {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/routed.def}
source {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/source-1638/project/experiments/block_v1/odb_geometry.tcl}
bvgeom::export {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-marker-preflight-16400/case-4/geometry.tsv}
