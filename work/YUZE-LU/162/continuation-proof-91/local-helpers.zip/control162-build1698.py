from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-actual1647-remote.py').read_text().replace('r256-parity-full-actual-audit-1647','r256-compact-full-actual-audit-1698').replace('sready1642-parity-density-fullchain','sready1696-compact-keepout-fullchain').replace('16420','16960').replace('cap-candidates/16100','cap-candidates/16800').replace('source-1638','source-1690').replace('dynamic-02/node3','dynamic-03/node5').replace('95098','95155').replace('node3','node5').replace('[10711,12100,13560]','[11400,11920,12220]').replace('[10711,12100,13560,16960]','[11400,11920,12220,16960]')
s=s.replace("tasks=json.loads", "assert '[expr {$xx-1000}]' in tcl and '[expr {$yy+1000}]' in tcl\ntasks=json.loads")
s=s.replace('replacement16100','compact16800').replace('placement16100_byteexact','placement16800_byteexact').replace('own16960futurethree224GiB','own16960futurethree224GiB')
(b/'control162-actual1698-remote.py').write_text(s)
compile(s,'actual1698','exec')
