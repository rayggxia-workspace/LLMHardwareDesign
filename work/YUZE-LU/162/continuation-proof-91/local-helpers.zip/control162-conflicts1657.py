import subprocess,shlex
q='''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates'
for seed in [12560,12561,13120,13121,13320,13460,13560,14030,14310,14781,15340,15341]:
 rows=[]
 for f in(root/str(seed)/'route').glob('trial-*/router.log'):
  with f.open('rb')as h:h.seek(max(0,f.stat().st_size-200000));s=h.read().decode(errors='replace')
  a=[json.loads(l)for l in s.splitlines()if l.startswith('{')and'"conflict_nodes"'in l]
  if a:rows.append(a[-1])
 print(seed,dict(attempts=len(rows),rounds=[min(r['round']for r in rows),max(r['round']for r in rows)]if rows else None,min_conflicts=min(r['conflict_nodes']for r in rows)if rows else None,max_conflicts=max(r['conflict_nodes']for r in rows)if rows else None))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
