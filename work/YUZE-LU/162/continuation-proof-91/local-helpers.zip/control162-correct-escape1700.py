from pathlib import Path
import subprocess
b=Path(r'D:\Data\电路实验');p=b/'control162-terminal-escape1659.py';old=p.read_bytes();(b/'control162-terminal-escape1659-original.py').write_bytes(old);data=b/'control162-terminal-escape1659.json';data.rename(b/'control162-terminal-escape1659-original.json');s=old.decode('utf-8').replace("owners=sorted(owner[p])","owners=sorted(owner.get(p,set()))").replace("if owner[p]-{n}","if owner.get(p,set())-{n}");assert s!=old.decode('utf-8');p.write_bytes(s.encode());subprocess.check_call(['python',str(p)])
