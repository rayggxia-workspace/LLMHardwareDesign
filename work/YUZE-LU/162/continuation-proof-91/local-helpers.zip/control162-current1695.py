import subprocess,shlex
q='''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-03/node5';print('active',json.loads((q/'queue-state.json').read_text())['active'])
for d in ['r256-legacy-isolated-snapshot-16780','r256-cut-keepout-preflight-16920']:
 p=b/d;r=p/'receipt.json';print(d,'receipt',json.loads(r.read_text()).get('passed')if r.exists()else'notfinal')
 f=p/'openroad.log'
 if f.exists():
  t=f.read_text();print('counts',re.findall(r'Number of violations = ([0-9]+)',t),'tail',t[-400:])
 f=p/'openroad-probe.json'
 if f.exists():
  v=json.loads(f.read_text());print('probe',dict(passed=v['passed'],cases=len(v['cases']),strict=v['independent_grid_verification_passed'],keepout=v.get('parity_aware_odd_cut_keepout_um')))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
