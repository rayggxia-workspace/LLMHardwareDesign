from pathlib import Path
r=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control');p=r/'project/experiments/control_v1/system_upper.py';s=p.read_bytes().decode();assert 'cluster_translation_proposal'not in s
old="    p.add_argument('--s-translation-proposal',type=Path,help='Diagnostic only: verify a prior S-only translation and freshly reconstruct all actual pins before original cap diagnostic')"
assert s.count(old)==1;s=s.replace(old,old+"\n    p.add_argument('--cluster-translation-proposal',type=Path,help='Placement diagnostic only: verify rigid29cluster shifts, reconstruct all actual pins, then run original cap bound; no route qualification')")
old='    assert not a.s_translation_proposal or(a.reuse_placement and a.cap_lower_bound_only and not a.expand_routing_halo_um and not a.lock_native_output_routes)';assert s.count(old)==1;s=s.replace(old,old+"\n    assert not a.cluster_translation_proposal or(a.reuse_placement and a.cap_lower_bound_only and not(a.expand_routing_halo_um or a.s_translation_proposal or a.lock_native_output_routes)), 'Cluster shifts require only reused-placement cap diagnostic'")
old='a.cap_lower_bound_only and not(a.expand_routing_halo_um or a.s_translation_proposal)';assert s.count(old)==1;s=s.replace(old,'a.cap_lower_bound_only and not(a.expand_routing_halo_um or a.s_translation_proposal or a.cluster_translation_proposal)')
old="            reused=json.loads(path.read_text());placement=reused['placements_um'];orientations=reused['orientations']";assert s.count(old)==1;s=s.replace(old,"""            reused=json.loads(path.read_text())
            if a.cluster_translation_proposal:
                from cluster_shift_proposal import apply
                reused,cluster_shift_proof,bindings=apply(a.cluster_translation_proposal,path,a.manifest,a.graph,reused,m,g)
                receipt['inputs'].update(bindings)
            placement=reused['placements_um'];orientations=reused['orientations']""")
old="        if reused:assert json.loads((a.out/'placement.json').read_text())==reused,'Reconstructed actual pins/PG/terminals differ from selected placement'";assert s.count(old)==1;s=s.replace(old,old+"""
        if a.cluster_translation_proposal:
            cluster_shift_proof.update(actual_pin_reconstruction_pending=False,actual_pin_reconstruction_passed=True)
            (a.out/'cluster-shift-proof.json').write_text(json.dumps(cluster_shift_proof,indent=2)+'\\n')""")
compile(s,str(p),'exec');p.write_bytes(s.replace('\r\n','\n').encode())
