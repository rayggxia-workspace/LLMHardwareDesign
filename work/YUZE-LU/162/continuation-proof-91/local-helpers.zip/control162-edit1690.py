from pathlib import Path
r=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control');p=r/'project/experiments/control_v1/openroad_router_probe.py';s=p.read_bytes().decode();assert 'cut_guard_dbu'not in s
old="        # One-nanometer search-only cut keepouts exclude exactly the original\n        # forbidden checkerboard sites. Adjacent legal centers remain 4um away,\n        # exceeding cut half-width + 2.2um spacing. No final mask shape is added."
new="""        # Original mode retains minimal1nm keepouts byteexact. Parity-aware
        # mode uses1um keepouts: nearest legal4um center has2.5um edge clearance
        # (4-1um cut halfwidth-.5um guard), above original2.2um cut spacing.
        # Both modes exclude the same original forbidden grid sites only.
        # This is search geometry; no final/native mask shape is added.
        cut_guard_dbu = 1000 if parity_aware_markers else 1"""
assert s.count(old)==1;s=s.replace(old,new)
old="            ' odb::dbObstruction_create $block $cut_layer [expr {$xx-1}] [expr {$yy-1}] [expr {$xx+1}] [expr {$yy+1}] }',"
new="            f' odb::dbObstruction_create $block $cut_layer [expr {{$xx-{cut_guard_dbu}}}] [expr {{$yy-{cut_guard_dbu}}}] [expr {{$xx+{cut_guard_dbu}}}] [expr {{$yy+{cut_guard_dbu}}}] }}',"
assert s.count(old)==1;s=s.replace(old,new)
old="        result['parity_aware_search_landing_markers'] = True";assert s.count(old)==1;s=s.replace(old,old+"\n        result['parity_aware_odd_cut_keepout_um'] = 1.0")
old="Search masters split by original via parity; odd master cut obstruction exactly duplicates an already forbidden site, with native masks and all original gates unchanged."
new="Search masters split by original via parity; odd master cut obstruction exactly duplicates an already forbidden site, global1um cut keepouts preserve all original legal via centers with2.5um minimum clearance, native masks and all original gates unchanged."
assert s.count(old)==1;s=s.replace(old,new);compile(s,str(p),'exec');p.write_bytes(s.replace('\r\n','\n').encode())
