from pathlib import Path
import json,collections,hashlib
b=Path(r'D:\Data\电路实验');out=b/'control162-escape-matching1662.json';assert not out.exists();report=[]
for src in [b/'LLMHardwareDesign-deliveries/issue-162/actual-round-diagnostic-1408/input.txt',b/'control162-density1617/placement.json']:
 if src.suffix=='.json':tm=json.loads(src.read_bytes())['terminals']
 else:
  tm={}
  for line in src.read_text().splitlines()[1:]:
   a=line.split();tm[a[0]]=[list(map(int,a[2+2*i:4+2*i]))for i in range(int(a[1]))]
 owner={tuple(p):n for n,pts in tm.items()for p in pts};assert len(owner)==sum(len(set(map(tuple,p)))for p in tm.values())
 candidates={};groups=collections.defaultdict(set);already=0
 for n,pts in tm.items():
  for x,y in set(map(tuple,pts)):
   if not(x+y)%2:continue
   adj={(x+dx,y+dy)for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]}
   if any(owner.get(p)==n for p in adj):already+=1;continue
   key=(n,x,y);candidates[key]={p for p in adj if p not in owner}
   for p in candidates[key]:groups[n,p].add(key)
 excluded=set().union(*(s for s in groups.values()if len(s)>1))if groups else set();graph={k:sorted(v)for k,v in candidates.items()if k not in excluded};left={};right={};distance={}
 def dfs(u):
  for v in graph[u]:
   mate=right.get(v)
   if mate is None or (distance.get(mate)==distance[u]+1 and dfs(mate)):
    left[u]=v;right[v]=u;return True
  distance[u]=-1;return False
 while True:
  todo=collections.deque();distance={u:0 for u in graph if u not in left};todo.extend(distance);reachable=False
  while todo:
   u=todo.popleft()
   for v in graph[u]:
    mate=right.get(v)
    if mate is None:reachable=True
    elif mate not in distance:distance[mate]=distance[u]+1;todo.append(mate)
  if not reachable:break
  for u in list(distance):
   if u not in left and distance[u]==0:dfs(u)
 assert len(left)==len(right) and all(v in graph[u]and right[v]==u for u,v in left.items())
 missing=set(graph)-set(left);seen=set(missing);todo=list(missing)
 while todo:
  u=todo.pop()
  for v in graph[u]:
   mate=right.get(v)
   if mate is not None and mate not in seen:seen.add(mate);todo.append(mate)
 neighbors=set().union(*(set(graph[u])for u in seen))if seen else set()
 if missing:assert len(neighbors)<len(seen)
 report.append(dict(path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest(),odd_owned_even_access=already,excluded_same_net_sharing=len(excluded),necessary_distinct_demands=len(graph),maximum_matching=len(left),no_initial_escape_hall_obstruction_found=not missing,hall_witness=dict(left=[list(u)for u in seen],right=[list(v)for v in neighbors])if missing else None))
out.write_text(json.dumps(dict(results=report,whole_system_qualified=False,scope='Necessary firststep matching only. Include odd M11 terminals without own even neighbor; exclude any demand able to share an even neighbor with same-net demand. Remaining terminals require distinct unoccupied adjacent even M11 sites under unchanged strict grid. Maximum matching failure gives independentlycheckable Hall witness; success only excludes this obstruction, never routes or timing proof. No production source or physical changes.'),indent=2));print(json.dumps(report))
