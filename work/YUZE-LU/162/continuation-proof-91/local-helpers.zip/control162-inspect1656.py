import subprocess,shlex
q='''from pathlib import Path
import re,json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates/10711/route'
for f in sorted(root.glob('trial-*/router.log')):
 with f.open('rb')as h:h.seek(max(0,f.stat().st_size-200000));s=h.read().decode(errors='replace')
 rounds=[json.loads(l)['round']for l in s.splitlines()if l.startswith('{')and '"conflict_nodes"'in l]
 print(f.parent.name,'bytes',f.stat().st_size,'last_round',max(rounds)if rounds else None,'last',s.splitlines()[-1]if s.splitlines()else'')
for seed in [16420]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route/openroad-search/case-0/openroad.log'
 with p.open('rb')as h:h.seek(max(0,p.stat().st_size-5000));s=h.read().decode(errors='replace')
 print('current',seed,s[-1600:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
