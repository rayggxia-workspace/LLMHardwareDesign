from pathlib import Path
import json,zipfile,hashlib,collections
b=Path(r'D:\Data\电路实验');r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-lp1664';assert not out.exists();out.mkdir();src=r/'work/YUZE-LU/162/continuation-proof-89';idx=json.loads((src/'index.json').read_bytes());sha=lambda v:hashlib.sha256(v).hexdigest()
with zipfile.ZipFile(src/'selected-originals.zip')as z:
 for short in ['placement.json','placement-search.json','electrical-placement-input.txt']:
  n='r256-composition-453/cap-candidates/16060/'+short;v=z.read(n);row=next(a for a in idx['files'].values()if a['zip_entry']==n);assert sha(v)==row['sha256'];(out/short).write_bytes(v)
p=json.loads((out/'placement.json').read_bytes());s=json.loads((out/'placement-search.json').read_bytes());e=s['electrical_refinement'];cl=e['clusters'];lines=(out/'electrical-placement-input.txt').read_text().splitlines();n,k,*rest=lines[0].split();assert int(n)==29;names=sorted(cl['dimensions']);rows=[]
for i,line in enumerate(lines[1+29:]):
 a=line.split();budget=float(a[0]);ext=int(a[1]);count=int(a[2]);ends=[(int(a[3+3*j]),float(a[4+3*j]),float(a[5+3*j]))for j in range(count)];rows.append(dict(budget=budget,external=ext,ends=ends))
assert len(rows)==int(k)
g=json.loads((b/'control162-snapshot1582/boundary-graph.json').read_bytes());assert sha((b/'control162-snapshot1582/boundary-graph.json').read_bytes())==p['graph_sha256'];print(json.dumps(dict(die=[p['width_um'],p['height_um']],nets=len(rows),positive_budget=sum(x['budget']>0 for x in rows),internal_cluster=sum(len({v[0]for v in x['ends']})==1 for x in rows),selected=e['selected_seed'],cluster_names=names)))
(out/'input-binding.json').write_text(json.dumps(dict(source_archive_sha256=sha((src/'selected-originals.zip').read_bytes()),source_index_sha256=sha((src/'index.json').read_bytes()),files={n:sha((out/n).read_bytes())for n in ['placement.json','placement-search.json','electrical-placement-input.txt']},whole_system_qualified=False),indent=2))
