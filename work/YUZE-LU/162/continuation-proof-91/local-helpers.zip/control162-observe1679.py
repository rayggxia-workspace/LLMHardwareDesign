import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-03/node5';s=json.loads((q/'queue-state.json').read_text());print('active',s['active'])
for d in ['r256-composition-453/cap-candidates/16740','r256-composition-453/cap-necessary-1672/16740/native-residual','r256-composition-453/cap-necessary-1672/16740/native-pin-load']:
 p=b/d;r=p/'receipt.json';print(d,'files',[x.name for x in p.glob('*.json')]);print('receipt',r.read_text()[-1600:]if r.exists()else'notfinal')
 f=p/'cluster-shift-proof.json'
 if f.exists():print('pinproof',f.read_text())
for p in sorted(q.glob('*16740*.log')):print(str(p),p.read_text()[-2000:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
