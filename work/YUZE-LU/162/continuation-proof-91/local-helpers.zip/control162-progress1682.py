import subprocess,shlex
q='''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for d in ['r256-composition-453/cap-candidates/16800','r256-composition-453/cap-necessary-1680/16800/native-residual','r256-composition-453/cap-necessary-1680/16800/native-pin-load']:
 p=b/d;r=p/'receipt.json';print(d,'receipt',json.loads(r.read_text()).get('passed')if r.exists()else'notfinal')
 for n in ['cluster-shift-proof.json','native-pin-load.json']:
  f=p/n
  if f.exists():
   v=json.loads(f.read_text());print(n,v if n.startswith('cluster')else [x['violations']for x in v['placements']])
q=b/'dynamic-03/node5';print('active',json.loads((q/'queue-state.json').read_text())['active'])
for f in sorted(q.glob('*16800*.log')):print(str(f),f.read_text()[-1500:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
