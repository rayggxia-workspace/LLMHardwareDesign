from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-91';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selected=set();external={}
def add(p):
 p=Path(p)
 if not p.is_file():return
 if p.stat().st_size<=12000000:selected.add(p)
 else:external[str(p)]=dict(bytes=p.stat().st_size,sha256=sha(p),copied=False)
def tree(p):
 p=Path(p);assert p.is_dir(),p
 for f in p.rglob('*'):add(f)
for n in ['r256-parity-isolated-snapshot-16600','r256-cluster-proposal-data-1670','r256-cluster-shift-source-audit-1671','r256-cluster-completed-audit-1693','r256-legacy-isolated-snapshot-16780','r256-cut-keepout-source-audit-1691','r256-cut-keepout-preflight-16920','r256-final-chain-binding-audit-1697','r256-compact-full-actual-audit-1698']:tree(b/n)
for n in ['sready1660-parity-snapshot','sready1661-parity-snapshot-refill','sready1672-cluster-shift-preflight','sready1680-cluster-shift-preflight','sready1678-isolated-legacy-control','sready1692-cut-keepout-preflight','sready1696-compact-keepout-fullchain']:
 p=b/'route-selection-102'/n;tree(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:assert sha(row['path'])==row['sha256'];add(row['path'])
tree(b/'r256-composition-453/cap-candidates/16800');tree(b/'r256-composition-453/cap-necessary-1680/16800')
for n in ['source1670.tar.gz','source1690.tar.gz','source-1670/source-manifest.json','source-1670/freeze-import.json','source-1690/source-manifest.json','source-1690/freeze-import.json','control162-backout1670.patch','control162-backout1690.patch']:add(b/n)
for n in ['system_upper.py','cluster_shift_proposal.py','openroad_router_probe.py']:add(b/'source-1690/project/experiments/control_v1'/n)
for folder in ['dynamic-03/node5','dynamic-08/node6']:
 q=b/folder
 for glob in ['*sready1660*','*sready1672*','*sready1680*','*sready1678*','*sready1692*','*sready1696*']:
  for sub in ['','commands','results']:
   for p in(q/sub).glob(glob):add(p)
out.mkdir();captures=out/'live-captures';captures.mkdir();states=[]
for seed in [15220,15860,16180,16220,16420,16960]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if f.exists():dst=captures/(str(seed)+'.log');dst.write_bytes(f.read_bytes());add(dst)
 for n in ['receipt.json','placement.json','openroad-search/case-0/run.tcl','openroad-search/case-0/terminals.json']:add(p/n)
 states.append(dict(seed=seed,receipt_exists=(p/'receipt.json').exists(),final_route_output_exists=(p/'router-output.txt').exists()))
add(b/'r256-composition-453/acceptance-16960.json');files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p),zip_entry=str(p.relative_to(b)))for p in sorted(selected)};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(str(p),str(p.relative_to(b)))
with zipfile.ZipFile(str(archive))as z:assert z.testzip()is None
(out/'index.json').write_text(json.dumps(dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,external_files=external,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),actual_route_file_states=states,scope='Actual16600bounded DR C1379494/crossnetfailure, partial17499report4396forbidden obstruction cuts0atports; legacy16780sameboundedparameters/guide forcontrolledcomparison. Only freshguarded own14781/source1470 step95155.208 replaced after16all40+roundlogs/UID/job/node/PID/fullcmd/specSHA/nooutputs/memoryguard, allold evidence retained/other35/eightparents/externalR untouched. Source1670new29rigidgroup proposalvalidator+caller,1029allfiles/backoutaudit1671; first1672seedcontextfailurebeforeoutputs preserved,1680correctseed reusedplacement/noRNG actual16800same10676x10892die/all345signalPGpins reconstructed and originalnative/mininput threeRC0 via1693. Source1690onlyoptinsearch globaloddcutkeepout1nmto1um, alllegalvia centers remain2.5umclearance>2.2, defaultTcl/LEFs byteexact, actual5fixture16920preflight required. New16960same23types345instances/current453 full7stage owngeometryPGthreeRC300MHz, strict1697 and actual1698. No completefullzero/nativegeometryPG/3RC300MHz qualification; taskcontinues.'),indent=2));print(json.dumps(dict(passed=True,files=len(files),external=len(external),zip_bytes=archive.stat().st_size,zip_sha256=sha(archive),states=states)))
