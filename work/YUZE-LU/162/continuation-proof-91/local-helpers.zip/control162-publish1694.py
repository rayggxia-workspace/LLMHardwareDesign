from pathlib import Path
import subprocess
b=Path(r'D:\Data\电路实验');p=b/'control162-publish-exact.py';s=p.read_text();assert "'1694'"not in s;p.write_text(s.replace("'1673'):","'1673','1694'):"));subprocess.check_call(['python',str(p),'1694','72dd15a5ab1b67ba854707707ae17456b1cce288'])
