import subprocess,shlex
q='''from pathlib import Path
import subprocess,json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-composition-453/upper-candidates/16960/route';out=b/'r256-compact-full-actual-audit-1698'
ready=all((r/p).exists()for p in ['placement.json','openroad-search/case-0/run.tcl','openroad-search/case-0/terminals.json'])
if (out/'receipt.json').exists():print('AlreadyAudited',json.loads((out/'receipt.json').read_text())['passed'])
elif ready:subprocess.run(['python3',str(b/'control162-actual1698-remote.py')],check=True)
else:print('NotReadyYet',str(r))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
