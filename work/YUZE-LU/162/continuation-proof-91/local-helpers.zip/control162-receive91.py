from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime,re,collections
b=Path(r'D:\Data\电路实验');r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/continuation-proof-91';assert not out.exists();out.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-91/';sha=lambda d:hashlib.sha256(d).hexdigest()
for n in ['index.json','selected-originals.zip']:subprocess.check_call(['scp','yuzelu@10.129.166.172:'+remote+n,str(out/n)])
d=json.loads((out/'index.json').read_bytes());assert sha((out/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='5d7742e01a34781d6c6990480b8c824e2245529dfd5e25e19ec2b7a78bf3af78'
with zipfile.ZipFile(out/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==385
 for row in d['files'].values():v=z.read(row['zip_entry']);assert len(v)==row['bytes'] and sha(v)==row['sha256']
 legacy=z.read('r256-legacy-isolated-snapshot-16780/drc.rpt').decode();log=z.read('r256-legacy-isolated-snapshot-16780/openroad.log').decode()
names=['inspect1656.py','conflicts1657.py','terminal-escape1659.py','terminal-escape1659-original.py','escape-matching1662.py','lp1664.py','milp1665.py','build1666.py','milp1666.py','queue1660-remote.py','build1661.py','refill1661-remote.py','edit1670.py','check1670.py','stage1670.py','audit1671-remote.py','queue1672-remote.py','summary1673.py','queue1678-remote.py','observe1679.py','build1680.py','queue1680-remote.py','snapshot1681.py','progress1682.py','edit1690.py','check1690.py','stage1690.py','audit1691-remote.py','queue1692-remote.py','audit1693-remote.py','publish1694.py','current1695.py','build1696.py','queue1696-remote.py','audit1697-remote.py','build1698.py','actual1698-remote.py','ready1699.py','correct-escape1700.py','proof91-remote.py','receive91.py']
files={'control162-'+n:(b/('control162-'+n)).read_bytes()for n in names}
for n in ['control162-terminal-escape1659.json','control162-terminal-escape1659-original.json','control162-escape-matching1662.json','control162-online1658-verified.json','control162-backout1670.patch','control162-backout1690.patch']:files[n]=(b/n).read_bytes()
for folder,ns in [('control162-lp1664',['input-binding.json']),('control162-milp1665',['receipt.json']),('control162-milp1666',['receipt.json']),('control162-cluster1670',['receipt.json','proposal.json']),('control162-local1690',['receipt.json']),('control162-snapshot16600',['receipt.json','snapshot.json','snapshot.tcl','openroad.log','drc.rpt','analysis.json'])]:
 for n in ns:files[folder+'/'+n]=(b/folder/n).read_bytes()
for label in [1673,1694]:files['publish'+str(label)+'-receipt.json']=(b/('control162-git-data-publish-'+str(label))/'receipt.json').read_bytes()
pattern=r'violation type: (.*?)\n\s*srcs: (.*?)\n\s*bbox = \(([-\d.]+), ([-\d.]+)\) - \(([-\d.]+), ([-\d.]+)\) on Layer (\S+)';rows=re.findall(pattern,legacy);assert len(rows)==legacy.count('violation type:');tm=json.loads((b/'control162-density1617/placement.json').read_bytes())['terminals'];sites={tuple(p)for ps in tm.values()for p in ps};cuts=[]
for typ,src,x0,y0,x1,y1,layer in rows:
 if typ=='Cut Short' and 'obstruction:'in src:
  x=((float(x0)+float(x1))/2-.095)/4;y=((float(y0)+float(y1))/2-.07)/4;assert abs(x-round(x))<1e-5 and abs(y-round(y))<1e-5 and(round(x)+round(y))%2==1;cuts.append((round(x),round(y)))
comparison=dict(legacy_bounded_iterations=list(map(int,re.findall(r'Number of violations = ([0-9]+)',log))),legacy_partial_records=len(rows),legacy_obstruction_cutshort=len(cuts),legacy_at_actual_terminal=sum(p in sites for p in cuts),parity_bounded_iterations=[789467,1379494],parity_partial_obstruction_cutshort=4396,parity_at_actual_terminal=0,whole_system_qualified=False,scope='Same guide/terminals/placement/16threads/oneiteration snapshothelper1526; onlylegacy16180 versusparity16420preODB. Each router report is partial/capped. TotalDRC changes onlyslightly, pinlocation symptom is not the whole congestion failure. Both actual DRC and strictgrid fail.')
files['paired-16780-16600-analysis.json']=(json.dumps(comparison,indent=2)+'\n').encode()
large=r/'work/YUZE-LU/162/search-cut-keepout1690/snapshot16600-analysis.json';original=large.read_bytes();assert original==(b/'control162-snapshot16600/analysis.json').read_bytes();files['snapshot16600-analysis-original.json']=original
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,v in files.items():z.writestr(n,v)
with zipfile.ZipFile(out/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==v for n,v in files.items())
(out/'local-index.json').write_text(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(out/'local-helpers.zip').stat().st_size,sha256=sha((out/'local-helpers.zip').read_bytes()))),indent=2),encoding='utf-8');(out/'reception.json').write_text(json.dumps(dict(passed=True,remote_entries=385,external_hashed_entries=5,local_entries=len(files),zip_crc_member_bytes_sha256_verified=True,whole_system_qualified=False),indent=2),encoding='utf-8')
summary=json.loads(original);summary.pop('records');large.write_bytes((json.dumps(dict(archive='../continuation-proof-91/local-helpers.zip',zip_entry='snapshot16600-analysis-original.json',original_bytes=len(original),original_sha256=sha(original),summary=summary,scope='Exact original35251line source evidence compressed for review; rawbytes retained in verified archive and sourcecommit72dd15a5ab1b67ba854707707ae17456b1cce288.'),indent=2)+'\n').encode())
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds');chapter='''# Issue162：较小die真实必要电容0，继续完整物理链

更新时间：{now}。[Checkpoint91]({prefix}work/YUZE-LU/162/continuation-checkpoint-91.md) / [385项原件及5项外置大文件]({prefix}work/YUZE-LU/162/continuation-proof-91/index.json)。全部23物理类型/138六文件、main六宏、R256、S1350内部驱动和345状态宿主保留。

source1670新增29固定宏组平移候选验证；16060原10676x10892die不扩大，整数4um平移最大232um，成员相对位置/固定mask/外部端口/朝向不变。source/archive1029文件与反向补丁审计通过，实际16800全真实信号/PG接点重建和原nativeground/mininputpin low/base/high必要电容均0违例，1693复核通过。数学解与必要电容0仅准入完整测试，绕线、过孔、耦合和分布时序仍未通过。首次1672遗漏seed>=24上下文被输出创建前拒绝；1680补seed16800，实际复用坐标、不跑RNG、不改门，原失败保留。

端口parity诊断16600仍1379494DRC，跨网占用拒绝；其17499项部分报告4396禁用过孔obstruction、实际端口位置0项。同引导/端点/摆放/16线程/同一轮数legacy16780为1383828DRC，总体只略改善，不能把端口症状修复当成拥塞根因全部解决。完整legacy/parity统计见本地索引中的paired-16780-16600-analysis.json；两者都未获得路由资格。

source1690只在已有opt-in搜索模式将全局奇数过孔阻挡1nm扩大为1um：最近合法中心仍2.5um净距，大于原2.2um；所有原合法棋盘中心保留，默认Tcl及两种markerLEF逐字一致，工艺/固定宏/RTL/最终门不变。1029文件/反向补丁审计通过，实际16920五例空DRC/原网格/棋盘/连通和九项非法导入拒绝通过。16960基于actual16800进入原完整七阶段；1697严格当前函数、原六键与自己的geometry/PG/三档RC绑定，1698核实实际11149网/24760接点、四组互斥16CPU、224GiB预测需284.8GiB可用及原1um阻挡。三份后继224GiB STA在已有node6/source269上限256控制器。

本轮仅fresh验证替换本任务14781/source1470子步骤95155.208：16日志全部40+轮、无最终输出、specSHA/UID/job/node/PID/全命令/当前图/实际内存核验通过；原规格/源码/日志/部分结果留存。其余35链、8父节点及外部R不动；新预检/对照/完整链动态自然补位，c96六16CPU、c64四16CPU。旧10711此前guard拒绝未动，所有历史失败保留。首次端口诊断unique_sites统计因defaultdict查询插入空键而膨胀，修正为get并同时保留原helper/JSON；碰撞/阻塞0结论未变，独立必要匹配也通过但不构成路由证明。

**仍无全图零冲突、实际native几何/XOR/PG及low/base/high分布RC300MHz setup/hold/电气联合通过；继续定位迭代，不在检查点停止，不放宽门，不借单块宣布系统通过，不自行合并。** 35251行原始诊断JSON已逐字压缩保留在91本地归档，原路径改为精确hash索引，便于审查。登记PR5 pending；看板缺配置/unverified、同步pending；审查待指定。

'''
for path,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;p.write_text(chapter.format(now=now,prefix=prefix)+p.read_text(encoding='utf-8'),encoding='utf-8')
note='[Checkpoint91](../work/YUZE-LU/162/continuation-checkpoint-91.md)：固定23类型/345实例、16060较小die不扩大，29宏组平移actual16800真实引脚/三档native-minpin必要电容0；source1690扩大搜索阻挡但保留全部合法中心，实际五例通过后16960完整七阶段已严格/实际核验。16600/16780同参数对照总体仅略改善、均失败；所有最终native几何PG/三RC300MHz门不变且尚未联合通过，继续任务。\n\n'
for path in ['docs/CONTROL_V1.md','docs/ARCHITECTURE.md']:
 p=r/path;t=p.read_text(encoding='utf-8');first,rest=t.split('\n',1);p.write_text(first+'\n\n'+note+rest.lstrip('\n'),encoding='utf-8')
(r/'work/YUZE-LU/162/continuation-checkpoint-91.md').write_text(chapter.format(now=now,prefix='../../../')+'[远程原件](continuation-proof-91/index.json)、[本地来源/同参数对照](continuation-proof-91/local-index.json)、[实收](continuation-proof-91/reception.json)，承接[90](continuation-checkpoint-90.md)。\n',encoding='utf-8');p=r/'.gitattributes';p.write_bytes(p.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-91/** -text\n');print(json.dumps(dict(passed=True,remote=385,external=5,local=len(files),comparison=comparison)))
