read_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-paired-inputs-1650/parity/case-0/before.odb}
set_thread_count 16
set_routing_layers -signal metal11-metal12 -clock metal11-metal12
help read_guides
read_guides {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-paired-inputs-1650/parity/case-0/route.guide}
detailed_route -droute_end_iter 1 -drc_report_iter_step 1 -output_drc {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-isolated-snapshot-16600/drc.rpt} -via_in_pin_bottom_layer metal11 -via_in_pin_top_layer metal11 -verbose 1
write_def {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-isolated-snapshot-16600/snapshot.def}
write_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-isolated-snapshot-16600/snapshot.odb}
