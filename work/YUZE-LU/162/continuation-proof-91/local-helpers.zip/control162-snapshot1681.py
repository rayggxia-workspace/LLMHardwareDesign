from pathlib import Path
import subprocess,json,hashlib,re,collections
b=Path(r'D:\Data\电路实验');out=b/'control162-snapshot16600';assert not out.exists();out.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-parity-isolated-snapshot-16600/';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['receipt.json','snapshot.json','snapshot.tcl','openroad.log','drc.rpt']:subprocess.check_call(['scp','yuzelu@10.129.166.172:'+remote+n,str(out/n)])
r=json.loads((out/'receipt.json').read_bytes());assert r['passed'] and not r['whole_system_qualified']
for n in ['snapshot.json','snapshot.tcl','openroad.log','drc.rpt']:assert sha(out/n)==r['outputs'][n]
p=json.loads((b/'control162-density1617/placement.json').read_bytes());terminals={tuple(v)for vv in p['terminals'].values()for v in vv};raw=(out/'drc.rpt').read_text();pattern=r'violation type: (.*?)\n\s*srcs: (.*?)\n\s*bbox = \(([-\d.]+), ([-\d.]+)\) - \(([-\d.]+), ([-\d.]+)\) on Layer (\S+)';records=re.findall(pattern,raw);assert len(records)==raw.count('violation type:');counter=collections.Counter();cut=[]
for typ,src,x0,y0,x1,y1,layer in records:
 counter[typ+'|'+layer]+=1
 if typ=='Cut Short' and 'obstruction:'in src:
  x=((float(x0)+float(x1))/2-.095)/4;y=((float(y0)+float(y1))/2-.07)/4
  assert abs(x-round(x))<1e-5 and abs(y-round(y))<1e-5 and (round(x)+round(y))%2==1
  cut.append(dict(point=[round(x),round(y)],at_terminal=(round(x),round(y))in terminals,src=src))
log=(out/'openroad.log').read_text();result=dict(passed=True,whole_system_qualified=False,inputs={n:sha(out/n)for n in ['receipt.json','snapshot.json','snapshot.tcl','openroad.log','drc.rpt']},full_iteration_drc=list(map(int,re.findall(r'Number of violations = ([0-9]+)',log))),partial_report_records=len(records),partial_types=dict(counter),forbidden_cut_obstruction_records=len(cut),at_actual_terminal=sum(v['at_terminal']for v in cut),records=cut,scope='SHA-bound actual16600 bounded diagnostic only. Returned detailed reports are partial/ordercapped, not full spatial distribution or proof of rootcause. Same-parameter legacy16780 still required; full16180 counts are not a controlled baseline because droute_end_iter differs. No routing/physical qualification.')
(out/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='records'}))
