import subprocess,shlex
q='''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-parity-isolated-snapshot-16600';s=(p/'openroad.log').read_text();print('16600counts',re.findall(r'Number of violations = ([0-9]+)',s));print('16600pa',re.findall(r'.*(?:macroGenAp|macroValidPlanarAp|macroValidViaAp|macroNoAp).*',s));r=p/'snapshot.json';print('16600final',r.read_text()if r.exists()else'notfinal')
old=b/'r256-composition-453/upper-candidates/16180/route/openroad-search/case-0/openroad.log';s=old.read_text();print('16180counts',re.findall(r'Number of violations = ([0-9]+)',s)[:3])
for p in [b/'r256-composition-453/cap-candidates/16740',b/'r256-composition-453/cap-necessary-1672/16740/native-residual',b/'r256-composition-453/cap-necessary-1672/16740/native-pin-load']:
 f=p/'receipt.json';print('NEW',str(p),json.loads(f.read_text()).get('passed')if f.exists()else'notfinal');cp=p/'cluster-shift-proof.json'
 if cp.exists():print('pins',cp.read_text())
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
b=__import__('pathlib').Path(r'D:\Data\电路实验');p=b/'control162-publish-exact.py';s=p.read_text();assert "'1673'"not in s;p.write_text(s.replace("'1655'):","'1655','1673'):"))
