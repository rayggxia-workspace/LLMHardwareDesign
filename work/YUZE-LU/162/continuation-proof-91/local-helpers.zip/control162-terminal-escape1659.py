from pathlib import Path
import json,hashlib,collections
b=Path(r'D:\Data\电路实验');out=b/'control162-terminal-escape1659.json';assert not out.exists();sources=[b/'LLMHardwareDesign-deliveries/issue-162/actual-round-diagnostic-1408/input.txt',b/'control162-density1617/placement.json'];results=[]
for src in sources:
 if src.suffix=='.json':d=json.loads(src.read_bytes());tm=d['terminals'];nx,ny=int(d['width_um']/4),int(d['height_um']/4)
 else:
  lines=src.read_text().splitlines();nx,ny,k=map(int,lines[0].split()[:3]);tm={}
  for line in lines[1:]:
   row=line.split();k=int(row[1]);tm[row[0]]=[list(map(int,row[2+2*i:4+2*i]))for i in range(k)]
 owner=collections.defaultdict(set)
 for n,pts in tm.items():
  for x,y in pts:owner[x,y].add(n)
 collisions={str(p):list(ns)for p,ns in owner.items()if len(ns)>1};isolated=[]
 for n,pts in tm.items():
  for x,y in set(map(tuple,pts)):
   if (x+y)%2==0:continue
   adj=[(x+dx,y+dy)for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]]
   blockers=[dict(point=p,owners=sorted(owner.get(p,set())))for p in adj if owner.get(p,set())-{n}]
   if len(blockers)==4:isolated.append(dict(net=n,terminal=[x,y],blocked_neighbors=blockers))
 results.append(dict(path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest(),grid=[nx,ny],nets=len(tm),terminal_count=sum(map(len,tm.values())),unique_sites=len(owner),collisions=collisions,isolated_odd_terminals=isolated))
out.write_text(json.dumps(dict(results=results,whole_system_qualified=False,scope='Necessary terminal escape diagnostic on existing strict4um/checkerboard graph: M11 terminal, four planar neighbors; odd forbids via. Occupancy by another net blocks that vertex. An odd terminal with all4neighbors owned by other nets has no legal first step. Absence is not routing proof. No source, mask, search or gate change.'),indent=2));print(json.dumps([dict(path=r['path'],collisions=len(r['collisions']),isolated_odd=len(r['isolated_odd_terminals']))for r in results]))
