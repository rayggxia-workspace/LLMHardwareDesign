from pathlib import Path
import json,hashlib,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453';route=root/'upper-candidates/17170/route';out=b/'r256-hpwl-full-actual-audit-1719';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();graph=root/'topology/boundary-graph.json';assert sha(graph)=='49ba0e348f3583f6facdf60e771fe6f1329b46fe5aac872c3828d4b61ddb1a68'
p=json.loads((route/'placement.json').read_text());assert p==json.loads((root/'cap-candidates/17130/placement.json').read_text());tm=json.loads((route/'openroad-search/case-0/terminals.json').read_text());assert tm==p['terminals']and len(tm)==11149
script=route/'openroad-search/case-0/run.tcl';tcl=script.read_text();global_command=next(l for l in tcl.splitlines()if l.startswith('global_route '));assert '-use_cugr'in global_command and '-congestion_iterations 50'in global_command and 'set_thread_count 16'in tcl and 'detailed_route -output_drc'in tcl
assert '[expr {$xx-1000}]' in tcl and '[expr {$yy+1000}]' in tcl
tasks=json.loads((b/'route-selection-102/sready1717-hpwl-keepout-fullchain/tasks.json').read_text())['tasks'];row=next(t for t in tasks if t['spec']['script']=='system_upper.py');assert sha(row['path'])==row['sha256'];command=b/'dynamic-05/node2/commands'/Path(row['path']).name;adm=json.loads(command.read_text())['admission'];assert adm['admitted']and adm['forecast_gib']==224 and adm['required_bytes']==(224*1.2+16)*1024**3 and adm['available_bytes']>adm['required_bytes']
details=subprocess.check_output(['scontrol','show','job','95341','-o'],universal_newlines=True);assert 'UserId=yuzelu(10011)'in details and 'NodeList=node2 'in details
binaries={str(root/'upper-candidates'/str(seed)/'route/router'):seed for seed in [12560,12840,13120]};scripts={str(root/'upper-candidates'/str(seed)/'route/openroad-search/case-0/run.tcl'):seed for seed in [17170]}
code="import os,json;rows=[]\nfor n in os.listdir('/proc'):\n if not n.isdigit():continue\n try:\n  p='/proc/'+n;assert os.stat(p).st_uid==10011;cmd=open(p+'/cmdline','rb').read().decode().split(chr(0));e=os.readlink(p+'/exe');seed="+repr(binaries)+".get(e)\n  for script,tag in "+repr(scripts)+".items():\n   if script in cmd:seed=tag\n  if seed is not None:rows.append(dict(pid=n,seed=seed,command=cmd,cpu_affinity=sorted(os.sched_getaffinity(int(n)))))\n except (OSError,AssertionError):pass\nprint(json.dumps(rows))"
procs=json.loads(subprocess.check_output(['srun','--jobid=95341','--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));masks={}
for seed in [12560,12840,13120,17170]:
 found=[v for v in procs if v['seed']==seed];assert found,seed;mask=found[0]['cpu_affinity'];assert len(mask)==16 and all(v['cpu_affinity']==mask for v in found);masks[seed]=set(mask)
assert all(not(masks[a]&masks[z])for a in masks for z in masks if a<z)

markers=route/'openroad-search/search-landing-markers.lef'
if not markers.exists():markers=route/'openroad-search/search-landing-markers.lef'
assert markers.read_text().count('MACRO ')==4 and markers.read_text().count(' LAYER via11 ;')==2
assert row['spec']['source_root']==str(b/'source-1690') and '--openroad-parity-aware-markers' in row['spec']['args']
state=json.loads((b/'dynamic-08/node6/queue-state.json').read_text());sta=[]
for row in tasks:
 if row['spec']['script']=='system_sta.py':
  sp=Path(row['path']);assert '/dynamic-08/node6/'in str(sp)and row['spec']['forecast_gib']==224 and sp.stem in state['unfinished']and sp.stem not in state['finished'];sta.append(str(sp))
assert len(sta)==3
out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,current_nets=11149,placement17130_byteexact=True,actual_cugr_command=global_command,node2_four_disjoint16cpu=True,processes=procs,actual_admission=adm,own224_sta_pending_unrejected=sta,scope='Actual full current453/compact17130 parity-aware CUGR process/11149terminals/placement/16threads and node2four16CPU masks plus actual224GiB/284.8GiB admission. Own17170 futurethree224GiBSTA specs explicitly queued under existingnode6/source269(max256), verifybelow. Geometry notyetready so noSTAexecuted. No full zero-conflict or system qualification.'),indent=2));print(json.dumps(dict(passed=True,current_nets=11149,four_live_disjoint16cpu=True,whole_system_qualified=False)))
