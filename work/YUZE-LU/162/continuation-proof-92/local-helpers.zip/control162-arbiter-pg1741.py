"""Independently advance genuinely accepted R256 control leaves to fixed PG."""
import subprocess,shlex
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1736';record=b/'route-selection-102/sready1741-arbiter-perimeter-pg';assert not record.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[];record.mkdir()
def add(node,name,script,args,deps,out,memory):
 p=b/'dynamic-05'/('node'+str(node))/'pending'/(name+'.json');assert not p.exists()and not out.exists()
 spec=dict(script=script,source_root=str(source),forecast_gib=memory,requires=list(map(str,deps)),args=list(map(str,args))+['--out',str(out)])
 temp=p.with_suffix('.tmp');temp.write_text(json.dumps(spec));temp.rename(p);rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
for n,node in [(17380,4)]:
 folder=b/'r256-arbiter-perimeter-1738'/str(n)/'gates/deliver';receipt=json.loads((folder/'receipt.json').read_text());assert receipt['passed']
 delivery=folder/'delivery.json';assert sha(delivery)==receipt['outputs']['delivery.json'];d=json.loads(delivery.read_text());assert d['passed']and d['native_leaf_accepted']and d['top']=='control_s_arbiter_r7'and d['die_um']==[3200,3200]
 assert set(d['gate_receipts'])=={'physical','drc','function','formal'}
 for op,r in d['gate_receipts'].items():
  p=Path(r['path']);assert sha(p)==r['sha256'];g=json.loads(p.read_text());assert g['passed']
  name={'physical':'five-macro-physical.json','drc':'five-macro-drc.json','function':'final-function.json','formal':'formal.json'}[op]
  p=p.parent/name;assert sha(p)==r['report_sha256']==g['outputs'][name];report=json.loads(p.read_text());assert report['passed']and report['source_receipt_sha256']==d['source_receipt_sha256']
 assert set(d['final_files'])=={'6_final.'+s for s in ['v','sdc','def','odb','spef','gds']}
 for f in d['final_files'].values():assert sha(f['path'])==f['sha256']
 pins=folder/'pins.json';assert sha(pins)==d['pins_sha256'];top=d['top']
 manifest=record/(top+'-physical.json');manifest.write_text(json.dumps(dict(leaves={top:dict(pins=str(pins),pins_sha256=sha(pins),final_files=d['final_files'],die_um=d['die_um'],selection_delivery=dict(path=str(delivery),sha256=sha(delivery),receipt=str(folder/'receipt.json'),receipt_sha256=sha(folder/'receipt.json')))},whole_system_qualified=False),indent=2))
 root=b/'r256-arbiter-fixed-pg-1741'/str(n);wrapper=root/'wrapper';checks=root/'checks';final=root/'delivery'
 common=['--manifest',manifest,'--leaf',top]
 add(node,'00-e-sready1741-pg-'+str(n),'pg_fixed_access.py',common,[folder/'receipt.json',b/'r256-arbiter-dispatch-source-audit-1737/receipt.json'],wrapper,32)
 for mode in ['physical','timing']:
  add(node,'00-f-sready1741-'+mode+'-'+str(n),'pg_fixed_timing.py',common+['--wrapper',wrapper]+(['--physical-only']if mode=='physical'else[]),[wrapper/'receipt.json'],checks/mode,32)
 add(node,'00-g-sready1741-deliver-'+str(n),'pg_fixed_timing.py',common+['--wrapper',wrapper,'--deliver','--physical-check',checks/'physical','--timing-check',checks/'timing'],[checks/mode/'receipt.json'for mode in ['physical','timing']],final,32)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,scope='Only newlyqualified3200umSarbiter17380 afteractual allfourfreshnativegates andsixfiledelivery, originalfixedPG completeDRC/XOR/nativecontinuity/freshRC300MHz/fullviewidentity/delivery. Existingownnode4 16CPU dynamicslots andoriginalmemoryguard. Currentcanonical1470version andalloldcompositionresults retained; noautomaticwholecompositionqualification.'),indent=2))
print(json.dumps(dict(queued=len(rows),record=str(record))))
'''
compile(q,'r256_pg235','exec')
print(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=60).decode())
