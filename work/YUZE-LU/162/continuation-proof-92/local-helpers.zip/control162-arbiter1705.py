import subprocess,shlex
q='''import json
from pathlib import Path
p=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-fixed-pg-246/2333/delivery/receipt.json')
d=json.loads(p.read_text());print('keys',list(d))
for k,v in d.items():
 if k not in ['files','outputs','inputs']: print(k,json.dumps(v)[:3000])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
