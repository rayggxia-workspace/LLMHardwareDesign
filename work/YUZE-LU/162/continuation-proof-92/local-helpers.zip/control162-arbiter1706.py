import subprocess,shlex
q='''import json
from pathlib import Path
p=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-fixed-pg-246/2333/delivery/receipt.json')
d=json.loads(p.read_text());print(json.dumps(d['inputs'],indent=2)[:5000])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
