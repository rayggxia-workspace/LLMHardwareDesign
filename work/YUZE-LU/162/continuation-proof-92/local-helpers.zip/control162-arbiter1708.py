import subprocess,shlex
q='''import json
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for rel in ['r256-fixed-pg-246/2333/wrapper/receipt.json','r256-native-233/2333/gates/receipt.json']:
 p=b/rel;d=json.loads(p.read_text());print(rel,'keys',list(d))
 for k in ['producer','producer_receipt_sha256','source','source_root','verified_producer','top','commands','spec']:
  if k in d:print(k,json.dumps(d[k])[:3500])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
