import subprocess,shlex
q='''import json
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for rel in ['r256-fixed-pg-246/2333/wrapper','r256-native-233/2333/gates','r256-native-233/2333']:
 p=b/rel;print(rel,[x.name for x in p.iterdir()][:35])
p=b/'route-selection-102/sready246-r256-pg/control_s_arbiter_r7-physical.json';print('spec',p.read_text()[:3000])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
