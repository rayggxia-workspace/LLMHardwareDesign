import subprocess,shlex
q='''import json
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-native-233/2333/native/receipt.json';d=json.loads(p.read_text());print('keys',list(d))
for k in ['top','verified_producer','verified_rtl_source_root','source_sha256','failed_hold_budget_retry']: print(k,json.dumps(d.get(k)))
p=b/'r256-native-233/2333/gates/physical/receipt.json';d=json.loads(p.read_text());print('physical keys',list(d));print(json.dumps({k:v for k,v in d.items()if k not in ['inputs','outputs','commands','files']})[:2400])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
