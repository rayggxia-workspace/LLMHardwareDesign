import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-native-233/2333/gates/physical';d=json.loads((p/'receipt.json').read_text());print('outputs',list(d['outputs']))
for name in d['outputs']:
 if name.endswith('.json'):
  f=p/name
  if f.exists()and f.stat().st_size<50000:
   a=json.loads(f.read_text());print(name,'keys',list(a))
   print(json.dumps({k:v for k,v in a.items()if 'slack'in k or 'violation'in k or k in ['passed','setup','hold','setup_wns_ns','hold_wns_ns']})[:2000])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
