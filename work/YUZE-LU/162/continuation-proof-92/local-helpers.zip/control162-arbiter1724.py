import subprocess,shlex
q='''from pathlib import Path
import json,math
p=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-native-233/2333/gates/physical/timed-endpoints/endpoints.tsv');rows=[l.split()for l in p.read_text().splitlines()];print(json.dumps(dict(endpoints=len(rows),setup=min((float(r[1]),r[0])for r in rows if math.isfinite(float(r[1]))),hold=min((float(r[2]),r[0])for r in rows if math.isfinite(float(r[2]))))))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
