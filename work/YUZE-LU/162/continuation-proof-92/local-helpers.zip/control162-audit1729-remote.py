from pathlib import Path
import json,hashlib,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1690';new=b/'source-1728';out=b/'r256-arbiter-perimeter-source-audit-1729';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());names=['project/experiments/block_v2/physical.py','project/experiments/control_v1/physical_only.py'];assert z['commit']=='acda394e0bed0f552114a8c37b7b62d5b1413b17'and len(z['files'])==1029 and{p for p,v in z['files'].items()if a['files'].get(p)!=v}==set(names)
digest='6bede7661c0a5088fc22e22c0162b992de4e426db35eceea9a3cbdff5f329479';assert sha(b/'source1728.tar.gz')==digest and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==digest and all(sha(new/p)==v for p,v in z['files'].items());out.mkdir();scratch=out/'reverse-copies'
for name in names:
 p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1728.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/n).read_bytes()==(old/n).read_bytes()for n in names)
for name in z['files']:
 if name not in names:assert z['files'][name]==a['files'][name]
v=b/'r256-native-229/2293/native/receipt.json';r=json.loads(v.read_text());assert not r['passed']and r['rtl_passed']and r['mapped']['passed']and r['top']=='control_s_arbiter_r7'and len(r['runs'])==3
for n,d in r['source_sha256'].items():
 assert sha(b/'source-232'/n)==d
 if n!='project/experiments/control_v1/run.py':assert sha(new/n)==d
last=r['commands'][-1];assert last['returncode']==2 and 'do-cts'in last['command'];log=v.parent/last['log'];assert sha(log)==last['sha256']and '[ERROR RSZ-0060] Max buffer count reached.'in log.read_text()
(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1029,unchanged_files=1027,scratch_backout_exact=True,verified_rtl_mapping_source232_bound=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch),str(v):sha(v)},scope='Only optional3200um R7S-arbiter nativefloorplan/pinperimeter; exactoldRTL/mapping reused, native implementation must be fresh. Allother1027sourcefiles unchanged including every finalnative/gds/function/LEC/PG and systemgeometry/3RC300MHz acceptance gate, routers, models, graph. No old qualification inherited; default floorplan unchanged. Allold failed2293 andpassed2333 results retained.'),indent=2));print(json.dumps(dict(passed=True,files=1029,unchanged=1027,backout=True)))
