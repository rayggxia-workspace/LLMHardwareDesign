from pathlib import Path
import json,hashlib,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1728';new=b/'source-1736';out=b/'r256-arbiter-dispatch-source-audit-1737';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());names=['project/experiments/control_v1/run.py'];assert z['commit']=='4a3b992bb57f93e7c1638f34bf9b823194a6336c'and len(z['files'])==1029 and{p for p,v in z['files'].items()if a['files'].get(p)!=v}==set(names)
digest='2cbb9aa66a55d7ed9d50d4043ea692e803136d79fdc38abc373b57c5f579d0ea';assert sha(b/'source1736.tar.gz')==digest and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==digest and all(sha(new/p)==v for p,v in z['files'].items());out.mkdir();scratch=out/'reverse-copies'
for name in names:
 p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1736.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/n).read_bytes()==(old/n).read_bytes()for n in names)
for name in z['files']:
 if name not in names:assert z['files'][name]==a['files'][name]
assert json.loads((b/'r256-arbiter-perimeter-source-audit-1729/receipt.json').read_text())['passed']
v=b/'r256-native-229/2293/native/receipt.json';r=json.loads(v.read_text());assert not r['passed']and r['rtl_passed']and r['mapped']['passed']and r['top']=='control_s_arbiter_r7'and len(r['runs'])==3
for n,d in r['source_sha256'].items():
 assert sha(b/'source-232'/n)==d
 if n!='project/experiments/control_v1/run.py':assert sha(new/n)==d
last=r['commands'][-1];assert last['returncode']==2 and 'do-cts'in last['command'];log=v.parent/last['log'];assert sha(log)==last['sha256']and '[ERROR RSZ-0060] Max buffer count reached.'in log.read_text()
(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1029,unchanged_files=1028,scratch_backout_exact=True,verified_rtl_mapping_source232_bound=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch),str(v):sha(v)},scope='Only4line run.py sentinel dispatch to unchanged physical_only.main; oldcontroller136 supports run.py but rejected physical_only beforeadmission. All1028otherfiles including1728nativecandidate andeveryfinalgate unchanged. Defaults exactbackout, originalRTL/mapping232 bindings preserved. No newparent/controller/cpu/memory/gate change. Old1731failedspec/6unstarted successors retained; noEDAoutput fromrejectedattempt.'),indent=2));print(json.dumps(dict(passed=True,files=1029,unchanged=1028,backout=True)))
