from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-milp1666.py').read_text(encoding='utf-8')
s=s.replace("out=b/'control162-milp1666'","out=b/'control162-milp1710'")
s=s.replace('c=np.zeros(var);c[58]=1;integrality=',"c=np.zeros(var)\nfor i in range(len(nets)):c[59+4*i:59+4*i+4]=[-1,1,-1,1]\nintegrality=")
s=s.replace("time_limit=30","time_limit=45")
s=s.replace("original pairwise separation preserved; all10930", "original pairwise separation preserved; objective minimizes total necessary HPWL of all10930 budgeted signal nets; all10930")
s=s.replace("shifts={n:","baseline_total_um=sum((max(v[1]for v in ends)-min(v[1]for v in ends)+max(v[2]for v in ends)-min(v[2]for v in ends))*4 for _,ends,_ in nets)\n r['baseline_total_budgeted_hpwl_um']=baseline_total_um\n r['objective_budgeted_hpwl_um']=float(res.fun)*4\n shifts={n:")
p=b/'control162-milp1710.py';assert not p.exists();p.write_text(s,encoding='utf-8')
