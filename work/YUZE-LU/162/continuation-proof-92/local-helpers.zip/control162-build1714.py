from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-refill1661-remote.py').read_text(encoding='utf-8')
s=s.replace('sready1661-parity-snapshot-refill','sready1714-hpwl-preflight-refill').replace('sready1660-parity-snapshot/tasks.json','sready1713-hpwl-cluster-preflight/tasks.json').replace("assert len(tasks['tasks'])==1","assert len(tasks['tasks'])==3").replace("(5,95155,'dynamic-03/node5',14781,'source-1470',0,224,284.8)","(2,95341,'dynamic-05/node2',14030,'source-1396',0,257,324.4)")
s=s.replace("sready1660-parity-snapshot/old-capture.json","../r256-cluster-proposal-data-1712/old-capture.json")
s=s.replace("b/'route-selection-102/../r256-cluster-proposal-data-1712/old-capture.json'","b/'r256-cluster-proposal-data-1712/old-capture.json'")
s=s.replace("['rows']if x['path']", "['active']if x['path']")
s=s.replace("current_forecast-spec['forecast_gib']+32<=forecast","current_forecast-spec['forecast_gib']+64<=forecast")
s=s.replace("assert rounds and max(rounds)>=40;attempts.append", "assert rounds and max(rounds)>=26;attempts.append")
s=s.replace("failed=last.startswith(('Locked-source optimistic wire budget exceeded by this search:','disconnected tree:','disconnected finite-resource tree:'))", "failed=last=='negotiation did not converge'")
s=s.replace("assert 16<=len(attempts)<=64;", "assert 32<=len(attempts)<=64;assert sum(r['last_completed_round']==79 and r['failed_message']=='negotiation did not converge'for r in attempts)>=16;")
start=s.index("reason='Fresh exact");end=s.index("')",start)
s=s[:start]+"reason='Fresh exact own14030/source1396 child only. All16firstattempts completedfull80rounds andfailednegotiation, allremainingattempts have26+rounds; noacceptedoutput. This is searchpriority replacement, NOT proof remainingattempts impossible. Fullsource/specSHA/UID/job/node/PID/cmd/current453 andactual257GiBforecast324.4GiBmemoryguard retained. Existing source1690 actualnativecap preflight17130 for same23types/345masks,29rigidgroupHPWL12.22percentreduction, unchangeddie/externalpins. Alloldsource/spec/logs/partials andother35tasks/eightparents/old3751/externalR retained. Nofinalgatechange orqualification'"+s[end+1:]
s=s.replace("scope='Only freshverified own14781child; alloriginalevidence and parentallocation retained. Immediate parity diagnostic enabled; not final qualification.'","scope='Only freshverified own14030child;16originalfull80roundfailedattempts andallpartialretries preserved. Existingfrozen source1690 HPWLcandidate nativepreflight enabled, not finalqualification.'")
compile(s,'refill1714','exec');(b/'control162-refill1714-remote.py').write_text(s,encoding='utf-8')
