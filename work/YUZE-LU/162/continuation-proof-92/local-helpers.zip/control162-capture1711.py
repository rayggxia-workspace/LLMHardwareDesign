import subprocess,shlex
q='''import json,hashlib
from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-05/node2';state=json.loads((q/'queue-state.json').read_text());rows=[]
for name in state['active']:
 p=q/'pending'/(name+'.json');s=json.loads(p.read_text());a=s['args']
 if '--out'not in a:continue
 out=Path(a[a.index('--out')+1]);r=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source=s['source_root'],out=str(out),forecast=s['forecast_gib'])
 if out.parent.name=='14030':
  r['attempts']=[]
  for f in out.glob('trial-*/router.log'):
   t=f.read_text().splitlines();rounds=[json.loads(l)['round']for l in t if l.startswith('{')and '"conflict_nodes"'in l];r['attempts'].append(dict(file=str(f),round=max(rounds)if rounds else None,last=t[-1][:180]if t else ''))
 rows.append(r)
print(json.dumps(dict(active=rows),indent=2))
'''
data=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]);from pathlib import Path
p=Path(r'D:\Data\电路实验\control162-capture1711.json');assert not p.exists();p.write_bytes(data);print(data.decode())
