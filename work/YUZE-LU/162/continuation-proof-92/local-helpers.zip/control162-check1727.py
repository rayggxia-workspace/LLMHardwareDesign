from pathlib import Path
import subprocess,shlex,json,sys,hashlib
b=Path(r'D:\Data\电路实验');r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-arbiter1727';assert not out.exists();out.mkdir()
q="import json;from pathlib import Path;p=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-native-229/2293/native/mapping/control_s_arbiter_r7/receipt.json');d=json.loads(p.read_text());assert d['passed'] and d['mapped'];print(json.dumps(d['ports']))"
data=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]);(out/'verified-mapping-ports.json').write_bytes(data);ports=json.loads(data)
sys.path.insert(0,str(r/'project/experiments/block_feed_v1'));from pins import generate
tech=json.loads((r/'project/experiments/block_v1/technology-2um-v1.json').read_bytes());rows=[]
for side in [1470,3200]:
 plan,fixture,proof=generate(ports,side,tech);(out/('pins-'+str(side)+'.json')).write_text(json.dumps(plan,indent=2),encoding='utf-8')
 rows.append(dict(side_um=side,ports=plan['ports'],geometry=proof,track_demand=plan['track_demand'],track_capacity=plan['track_capacity']))
assert rows[0]['ports']==rows[1]['ports'];names=['project/experiments/control_v1/physical_only.py','project/experiments/block_v2/physical.py']
for name in names:compile((r/name).read_bytes(),name,'exec')
(out/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,rows=rows,scope='Actual verified2293 mapping ports and original geometry2um checker;1470/3200 pin candidates only. No native P&R, PG, DRC, RC/timing or final function/LEC qualification inherited.',files={n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names}),indent=2),encoding='utf-8');print(json.dumps(dict(passed=True,ports=rows[0]['ports'],track_demand=rows[0]['track_demand'],new_capacity=rows[1]['track_capacity'])))
