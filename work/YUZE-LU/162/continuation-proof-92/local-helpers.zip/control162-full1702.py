import subprocess,shlex
q='''from pathlib import Path
import re,json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates'
for seed in [15220,15860,16180,16220,16420,16960]:
 p=root/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if not f.exists():continue
 t=f.read_text();totals=[s for s in t.splitlines()if any(x in s.lower()for x in ['final congestion','total wirelength'])];counts=re.findall(r'Number of violations = ([0-9]+)',t);print(seed,json.dumps(dict(global_totals=totals,full_drc_iterations=counts[-3:],receipt=json.loads((p/'receipt.json').read_text()).get('passed')if(p/'receipt.json').exists()else None,last=t[-400:])))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
