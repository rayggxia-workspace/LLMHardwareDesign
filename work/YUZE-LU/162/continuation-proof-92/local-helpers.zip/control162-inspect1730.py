import subprocess,shlex
q='''from pathlib import Path
import json,hashlib,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'route-selection-102/sready246-r256-pg';print('pg-record-files',[p.name for p in r.iterdir()]);p=r/'tasks.json'
if p.exists():
 d=json.loads(p.read_text());print('pg-recordkeys',list(d));print(json.dumps([v for v in d['tasks']if'2333'in str(v)])[:6000])
q=b/'dynamic-05/node4';state=json.loads((q/'queue-state.json').read_text());rows=[]
for n in state['active']:
 p=q/'pending'/(n+'.json');d=json.loads(p.read_text());a=d['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='15860':
  f=Path(a[a.index('--out')+1])/'openroad-search/case-0/openroad.log';t=f.read_text();rows.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source=d['source_root'],counts=re.findall(r'Number of violations = (\d+)',t),last=t[-500:]))
print('old',json.dumps(rows))
'''
from pathlib import Path
d=subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]);(Path(r'D:\Data\电路实验')/'control162-inspect1730.txt').write_bytes(d);print(d.decode())
