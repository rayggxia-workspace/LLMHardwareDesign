from pathlib import Path
import subprocess
b=Path(r'D:\Data\电路实验');host='yuzelu@10.129.166.172';root='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
for name in ['audit1716','queue1717','audit1718']:
 p=b/('control162-'+name+'-remote.py');subprocess.check_call(['scp',str(p),host+':'+root+'/'+name+'.py']);subprocess.check_call(['ssh',host,'python3',root+'/'+name+'.py'])
