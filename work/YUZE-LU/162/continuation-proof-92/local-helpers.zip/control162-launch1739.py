from pathlib import Path
import subprocess,shlex
b=Path(r'D:\Data\电路实验');host='yuzelu@10.129.166.172';root='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
for name,target in [('control162-backout1736.patch','control162-backout1736.patch'),('control162-audit1737-remote.py','audit1737.py'),('control162-queue1738-remote.py','queue1738.py')]:subprocess.check_call(['scp',str(b/name),host+':'+root+'/'+target])
for name in ['audit1737','queue1738']:subprocess.check_call(['ssh',host,'python3',root+'/'+name+'.py'])
q="""from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready1731-arbiter-perimeter';q=b/'dynamic-05/node4';state=json.loads((q/'queue-state.json').read_text());rows=json.loads((record/'tasks.json').read_text())['tasks'];assert len(rows)==7
assert not(b/'r256-arbiter-perimeter-1731/17310').exists()
native=next(r for r in rows if r['spec']['script']=='physical_only.py');failed=state['finished'][Path(native['path']).stem];assert failed['rejected_before_admission']and failed['returncode']==-2 and failed['error']=='Unsupported task script'
for r in rows:
 p=Path(r['path']);assert p.parent==q/'pending'and p.stem not in state['active']and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];assert not(q/'commands'/p.name).exists()
dest=record/'retired-before-EDA';dest.mkdir()
for r in rows:
 p=Path(r['path']);p.rename(dest/p.name)
(dest/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,failed_native=failed,preserved=rows,scope='Exact7ownspecs archived afternative unsupportedscript rejection beforeadmission;6successors neverstarted andnooutputs/commands. Existingresults/queuehistory retained. New1738 usesauditedsupportedrun.py dispatch.')));print('Archived7original1731specs, noEDAwaslaunched')
"""
subprocess.check_call(['ssh',host,'python3 -c '+shlex.quote(q)])
