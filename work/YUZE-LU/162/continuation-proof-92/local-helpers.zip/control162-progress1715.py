import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for d in ['r256-composition-453/cap-candidates/17130','r256-composition-453/cap-necessary-1713/17130/native-residual','r256-composition-453/cap-necessary-1713/17130/native-pin-load']:
 p=b/d;r=p/'receipt.json';print(d,'receipt',json.loads(r.read_text()).get('passed')if r.exists()else'notfinal')
 for n in ['cluster-shift-proof.json','native-pin-load.json']:
  f=p/n
  if f.exists():
   v=json.loads(f.read_text());print(n,dict(actual_pin_reconstruction_passed=v.get('actual_pin_reconstruction_passed'))if n.startswith('cluster')else[x['violations']for x in v['placements']])
q=b/'dynamic-05/node2';state=json.loads((q/'queue-state.json').read_text());print('active',state['active'])
for f in sorted(q.glob('*17130*.log')):print(str(f),f.read_text()[-1000:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
