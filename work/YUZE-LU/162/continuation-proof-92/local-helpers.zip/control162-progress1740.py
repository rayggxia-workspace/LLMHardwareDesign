import subprocess,shlex
q='''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-perimeter-1738/17380';q=b/'dynamic-05/node4';s=json.loads((q/'queue-state.json').read_text());print('active',s['active'])
for name in ['native','gates/sealed','gates/physical','gates/drc','gates/function','gates/formal','gates/deliver']:
 p=root/name/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print(name,'passed',d.get('passed'),'last',[(v.get('log'),v.get('returncode'))for v in d.get('commands',[])[-2:]])
p=root/'native/pnr/native-flow.json'
if p.exists():
 d=json.loads(p.read_text());print('nativeflow',dict(die=d['die_um'],stages=d['stages'],qualified=d['qualified_hard_macro']))
logs=sorted((root/'native/pnr').glob('[0-9][0-9]-*.log'))
if logs:print('last-native-stage',logs[-1].name,logs[-1].read_text()[-900:])
for f in sorted(q.glob('*17380*.log')):print(f.name,f.read_text()[-1200:])
p=b/'r256-composition-453/upper-candidates/17170/route/openroad-search/case-0/openroad.log'
if p.exists():
 t=p.read_text();print('full17170',t[-700:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
