from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-92';assert not out.exists();selected=set()
def add(p):
 p=Path(p)
 if p.is_file()and p.stat().st_size<=12000000:selected.add(p)
def tree(p):
 p=Path(p);assert p.is_dir(),str(p)
 for f in p.rglob('*'):add(f)
for n in ['r256-cluster-proposal-data-1712','r256-cluster-completed-audit-1716','r256-final-chain-binding-audit-1718','r256-hpwl-full-actual-audit-1719','r256-arbiter-perimeter-source-audit-1729','r256-arbiter-dispatch-source-audit-1737','r256-arbiter-perimeter-actual-audit-1742']:tree(b/n)
records=['sready1713-hpwl-cluster-preflight','sready1714-hpwl-preflight-refill','sready1717-hpwl-keepout-fullchain','sready1731-arbiter-perimeter','sready1732-arbiter-native-refill','sready1738-arbiter-perimeter']
for n in records:
 p=b/'route-selection-102'/n;tree(p)
 if(p/'tasks.json').exists():
  for row in json.loads((p/'tasks.json').read_text())['tasks']:
   f=Path(row['path'])
   if not f.exists():f=p/'retired-before-EDA'/f.name
   assert hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256'];add(f)
tree(b/'r256-composition-453/cap-candidates/17130');tree(b/'r256-composition-453/cap-necessary-1713/17130')
for n in ['source1728.tar.gz','source1736.tar.gz','source-1728/source-manifest.json','source-1728/freeze-import.json','source-1736/source-manifest.json','source-1736/freeze-import.json','control162-backout1728.patch','control162-backout1736.patch','r256-composition-453/acceptance-17170.json']:add(b/n)
for folder in ['dynamic-05/node2','dynamic-05/node4','dynamic-08/node6']:
 q=b/folder
 for pattern in ['*sready1713*','*sready1717*','*sready1731*','*sready1738*']:
  for sub in ['','commands','results']:
   for p in(q/sub).glob(pattern):add(p)
native=b/'r256-arbiter-perimeter-1738/17380'
for n in ['native/receipt.json','native/pnr/native-flow.json','native/pnr/pins.json','native/pnr/config.mk','native/pnr/structural-proof.json']:add(native/n)
for f in(native/'native/pnr').glob('*.log'):add(f)
for op in ['sealed','physical','drc','function','formal','deliver']:
 p=native/'gates'/op
 if p.exists():
  for n in ['receipt.json','five-macro-physical.json','five-macro-drc.json','final-function.json','formal.json','delivery.json']:add(p/n)
for f in ['project/experiments/control_v1/run.py','project/experiments/control_v1/physical_only.py','project/experiments/block_v2/physical.py']:add(b/'source-1736'/f)
out.mkdir();live=out/'live';live.mkdir();states=[]
for seed in [15220,15860,16180,16220,16420,16960,17170]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if f.exists():dst=live/(str(seed)+'.log');dst.write_bytes(f.read_bytes());add(dst)
 for name in ['receipt.json','placement.json','openroad-search/case-0/run.tcl','openroad-search/case-0/terminals.json']:add(p/name)
 states.append(dict(candidate=seed,receipt_exists=(p/'receipt.json').exists(),final_trees_exist=(p/'trees.json').exists(),routed_odb_exists=(p/'openroad-search/case-0/routed.odb').exists()))
queues=[]
for folder in ['dynamic-05/node2','dynamic-02/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 p=b/folder/'queue-state.json';d=json.loads(p.read_text());dst=live/(folder.replace('/','-')+'-queue-state.json');dst.write_bytes(p.read_bytes());add(dst);queues.append(dict(folder=folder,job=d['job'],slots=d['slots'],active=len(d['active'])))
files={};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):
  data=p.read_bytes();entry=str(p.relative_to(b));z.writestr(entry,data);files[str(p)]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),zip_entry=entry)
with zipfile.ZipFile(str(archive))as z:assert z.testzip()is None
scope='Actual17130 fresh345pin reconstruction and all3native/minpin necessarycap0,17170 fullcurrent453 sevenstage/strict1718/live1719. Exact own14030 retiredafter16complete80roundfailedattempts andall26+roundpartialretries, preservedall; actualUID/source/spec/memoryguarantees. NewR7Sarbiter3200um candidate reusesonly2293RTL/mapping andsource232, freshnativeP&R/allfinalgates, source1728full1029/backoutaudit1729. Oldcontroller136 rejected1731physical_only beforeadmission, noEDA/nooutputs;7specs preservedarchived,4line supportedrun.pydispatch source1736full1029/backoutaudit1737 then1738nativeactuallyrunning/live1742four16CPUmasks/208GiBforecast265.6admission. Exactownhalo15860 stoppedafter6nonzeroDRCcounts plateau, allpartials/source/spec preserved, notproof remainingiterations impossible. No parent/foreignR/otherjob changes, nofinalgate relaxation, current23typecanonical1470R7retained; nofullzero/geometryPG/threeRC300MHz qualification. Live logs are captured prefixes, not finalreceipts.'
idx=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,external_files={},archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),actual_route_file_states=states,queue_snapshots=queues,scope=scope);(out/'index.json').write_text(json.dumps(idx,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=idx['archive']['sha256'],states=states,queues=queues)))
