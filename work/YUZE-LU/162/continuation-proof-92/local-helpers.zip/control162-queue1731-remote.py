from pathlib import Path
import json,time,hashlib
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready1731-arbiter-perimeter';assert not record.exists();source=b/'source-1728';audit=b/'r256-arbiter-perimeter-source-audit-1729/receipt.json';assert json.loads(audit.read_text())['passed'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();template=json.loads((b/'route-selection-102/sready233-r256-hold-retry/tasks.json').read_text())['tasks'];oldroot=str(b/'r256-native-233/2333');newroot=str(b/'r256-arbiter-perimeter-1731/17310');rows=[]
for old in template:
 if oldroot not in str(old['spec']['args']):continue
 spec=json.loads(json.dumps(old['spec']));spec['source_root']=str(source)
 for k in ['args','requires']:spec[k]=[x.replace(oldroot,newroot)for x in spec[k]]
 spec['args'][spec['args'].index('--source-root')+1]=str(source);spec['requires'].append(str(audit))
 if spec['script']=='physical_only.py':
  assert spec['args'][spec['args'].index('--verified')+1]==str(b/'r256-native-229/2293/native')
  spec['args']+=['--verified-source-root',str(b/'source-232'),'--s-arbiter-side-um','3200'];assert '--failed-producer-hold-budget'in spec['args']and'--strong-output-drivers'in spec['args']
 p=b/'dynamic-05/node4/pending'/(Path(old['path']).stem.replace('sready233','sready1731').replace('2333','17310')+'.json');assert not p.exists();tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(spec));tmp.rename(p);rows.append(dict(path=str(p),sha256=sha(p),spec=spec,old_spec_path=old['path'],old_spec_sha256=sha(old['path'])))
assert len(rows)==7;record.mkdir();(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,scope='Existingownnode4 dynamic16CPU, one targeted3200umR7arbiter physicalcandidate. Reuse ONLY exact2293 successfulRTL/mapping, originalsource232 explicitbinding, retainedRSZ0060failure, sameholdhook/strongoutputs. FreshnativeP&R then sealed physical300MHz/electrical/nativeGDSDRC/threeinitialfinalfunction/strictLEC/sixfilelayoutdelivery. Exact1029sourceaudit1729PASS, defaults/othermacros/routers/finalqualification unchanged. ActualfixedPGfourtaskchain addedonlyafterfreshnative6filedelivery; noqualificationinherited. Preservecurrent23typecanonical1470arbiter andallcompositionevidence.'),indent=2));print(json.dumps(dict(queued=7,candidate=17310,source_commit='acda394e0bed0f552114a8c37b7b62d5b1413b17',side_um=3200)))
