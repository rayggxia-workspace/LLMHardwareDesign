import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');q=b/'dynamic-05/node4';s=json.loads((q/'queue-state.json').read_text());print('state',{k:[v for v in a if'173'in str(v)]if isinstance(a,list)else str(a)[:200]for k,a in s.items()});print('files',[v.name for v in q.iterdir()if '173'in v.name or v.is_dir()]);print('pending',[v.name for v in(q/'pending').iterdir()if'173'in v.name])
print('finished1731',{k:v for k,v in s.get('finished',{}).items()if'1731'in k})
for folder in [q/'results',q/'commands']:
 for p in folder.glob('*1731*'):print(str(p),p.read_text()[-2500:])
for p in q.glob('*173*'):
 if p.is_file():print(p.name,p.read_text()[-1400:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
