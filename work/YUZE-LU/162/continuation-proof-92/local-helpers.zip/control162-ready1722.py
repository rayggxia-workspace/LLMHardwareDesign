import subprocess,shlex
from pathlib import Path
host='yuzelu@10.129.166.172';root='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';local=Path(r'D:\Data\电路实验\control162-actual1719-remote.py')
q="from pathlib import Path;import json; b=Path('"+root+"'); p=b/'r256-composition-453/upper-candidates/17170/route'; print(json.dumps(dict(ready=(p/'placement.json').exists()and(p/'openroad-search/case-0/run.tcl').exists(),audited=(b/'r256-hpwl-full-actual-audit-1719/receipt.json').exists())))"
import json
d=json.loads(subprocess.check_output(['ssh',host,'python3 -c '+shlex.quote(q)]));print(d)
if d['ready']and not d['audited']:
 subprocess.check_call(['scp',str(local),host+':'+root+'/actual1719.py']);subprocess.check_call(['ssh',host,'python3',root+'/actual1719.py'])
