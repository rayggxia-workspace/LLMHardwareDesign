from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
b=Path(r'D:\Data\电路实验');r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/continuation-proof-92';assert not out.exists();out.mkdir();sha=lambda v:hashlib.sha256(v).hexdigest();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-92/'
for n in ['index.json','selected-originals.zip']:subprocess.check_call(['scp','yuzelu@10.129.166.172:'+remote+n,str(out/n)])
d=json.loads((out/'index.json').read_bytes());assert sha((out/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='d18fd0842e7de7e9959f3a80afc5a349cc5ce2c32e715ea6e923ce2d96f55244'
with zipfile.ZipFile(out/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==330
 for v in d['files'].values():raw=z.read(v['zip_entry']);assert len(raw)==v['bytes']and sha(raw)==v['sha256']
 for name in ['r256-cluster-completed-audit-1716','r256-final-chain-binding-audit-1718','r256-hpwl-full-actual-audit-1719','r256-arbiter-perimeter-source-audit-1729','r256-arbiter-dispatch-source-audit-1737','r256-arbiter-perimeter-actual-audit-1742']:assert json.loads(z.read(name+'/receipt.json'))['passed']
 old=json.loads(z.read('route-selection-102/sready1731-arbiter-perimeter/retired-before-EDA/receipt.json'));assert old['passed']and old['failed_native']['rejected_before_admission']and len(old['preserved'])==7
 assert sum(v['active']for v in d['queue_snapshots'])==sum(v['slots']for v in d['queue_snapshots'])==36
names=['full1702.py','arbiter1703.py','arbiter1705.py','arbiter1706.py','arbiter1708.py','arbiter1709.py','build1710.py','milp1710.py','capture1711.py','prepare1712.py','queue1713-remote.py','upload1713.py','build1714.py','refill1714-remote.py','progress1715.py','build1716.py','audit1716-remote.py','queue1717-remote.py','audit1718-remote.py','build1719.py','actual1719-remote.py','arbiter1720.py','launch1721.py','ready1722.py','arbiter1723.py','arbiter1724.py','check1725.py','check1727.py','stage1728.py','audit1729-remote.py','inspect1730.py','queue1731-remote.py','build1732.py','refill1732-remote.py','progress1734.py','queue1735.py','build1737.py','audit1737-remote.py','queue1738-remote.py','launch1739.py','progress1740.py','build1741.py','arbiter-pg1741.py','actual1742-remote.py','proof92-remote.py','receive92.py'];files={'control162-'+n:(b/('control162-'+n)).read_bytes()for n in names}
for n in ['control162-capture1711.json','control162-inspect1730.txt','control162-backout1728.patch','control162-backout1736.patch']:files[n]=(b/n).read_bytes()
for folder,names in [('control162-milp1710',['receipt.json']),('control162-cluster1712',['proposal.json','receipt.json']),('control162-arbiter1725',['receipt.json','pins-2400.json']),('control162-arbiter1727',['receipt.json','verified-mapping-ports.json','pins-1470.json','pins-3200.json'])]:
 for n in names:files[folder+'/'+n]=(b/folder/n).read_bytes()
for label in [1701,1728,1736]:
 p=b/('control162-git-data-publish-'+str(label))/'receipt.json';a=json.loads(p.read_bytes());assert a['passed']and a['force']is False;files['publish'+str(label)+'-receipt.json']=p.read_bytes()
rawpins={}
for n in ['pins-1470.json','pins-3200.json']:
 p=r/'work/YUZE-LU/162/s-arbiter-perimeter1727'/n;data=p.read_bytes();assert data==(b/'control162-arbiter1727'/n).read_bytes();entry='source1728-original-pin-plans/'+n;files[entry]=data;rawpins[n]=dict(bytes=len(data),sha256=sha(data),zip_entry=entry)
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,data in files.items():z.writestr(n,data)
with zipfile.ZipFile(out/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==v for n,v in files.items())
(out/'local-index.json').write_text(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(out/'local-helpers.zip').stat().st_size,sha256=sha((out/'local-helpers.zip').read_bytes()))),indent=2),encoding='utf-8');(out/'reception.json').write_text(json.dumps(dict(passed=True,remote_entries=330,local_entries=len(files),all_actual_member_crc_bytes_sha256=True,whole_system_qualified=False),indent=2),encoding='utf-8')
index=r/'work/YUZE-LU/162/s-arbiter-perimeter1727/pin-plans-index.json';index.write_text(json.dumps(dict(archive='../continuation-proof-92/local-helpers.zip',original_commit='acda394e0bed0f552114a8c37b7b62d5b1413b17',files=rawpins,scope='Original54000line pin plan evidence compressed byteexact for review, retained both in sourcecommit and this verifiedarchive. Plans are not finalnative layout qualification.'),indent=2),encoding='utf-8')
for n in rawpins:(index.parent/n).unlink()
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter='''# Issue162：真实低HPWL组合及S仲裁器原生重验收继续

更新时间：{now}。[Checkpoint92]({prefix}work/YUZE-LU/162/continuation-checkpoint-92.md) / [330项服务器原字节及源绑定]({prefix}work/YUZE-LU/162/continuation-proof-92/index.json)。既有23类/138六文件、main六宏、R256、S1350内部驱动与345状态宿主保留；外部R/其他任务不动。

同一10676×10892um die和29固定宏组，局部数学优化1710将10930条带预算网总HPWL由24579336降至21575160um（12.22%），仅为候选。实际17130完成全部345宏/11149网/24760接点的原生信号与PG重构，三档原生地电容、实际最小输入pin及必要线长检查均0违例；1716复核通过。17170进入原完整七阶段，1718严格当前函数及自身geometry/PG/三档RC绑定、1719实际四组16CPU与224GiB预测/284.8GiB准入通过。详细布线仍有大量冲突，未获得组合物理资格。

原1470um S仲裁器有1402个M10端口。首选方向模型下局部引脚出口接近容量，实际最终图允许wrongway，因此不宣称不可布通。原885个最终端点最差setup+1.237522ns、hold+0.021788ns。新增单一3200um候选仅调整这个新增控制块的物理周长，复用原2293成功RTL/mapping及明确source232绑定；无RTL/状态/协议修改。真实面积10.24mm²相对2.1609mm²必须计入后续组合，旧摆放/RC资格不转移。全部1402pin原几何规则本地验证通过，source1728的1029项/反向补丁审计1729通过；旧版仍是当前规范，不在新候选通过前替换。

1731因旧source136控制器不支持physical_only入口，在内存准入/发射前明确拒绝，没有EDA或输出。原失败及7份规格（含6个从未启动后继）完整保留归档。source1736只增加4行run.py转发到同一个physical_only.main，1029项/反向补丁审计1737通过，其他1028源文件及全部最终门逐字不变。1738实际启动原生布局布线，1742核实node4四个互不重叠16CPU进程、208GiB预测/265.6GiB实际准入；3200um原生P&R及全量300MHz/电气/DRC/最终函数/严格LEC/六文件门仍在运行，不称已验收。固定PG后继只能在实际四门交付后加入。

仅精确退役本任务14030/95341.133和留白15860/95391.158子步骤：前者首批16次已完成80轮失败、后续16次26+轮部分结果；后者6个完整DRC统计均非0且后三次仍超过200万。均经UID/job/node/PID/完整命令/source/specSHA/无最终输出/实际内存核实，所有原始/部分结果保留；这是搜索优先级调整，不宣称剩余搜索不可能。8个既有父节点、36个独立16CPU槽实际全占用快照，c96六×16/c64四×16；不增加分配、不取消父任务/旧3751/外部R。未更改内存或验收门。

**完整组合全网零冲突、实际native几何/XOR/PG、low/base/high分布RC下300MHz setup/hold/电气及联合六文件/版图/源索引仍未通过。继续定位迭代，不在检查点停止，不放宽门，不借单块宣布系统通过，不合并。** 源1728/1736已精确非强推发布；原54k行引脚JSON逐字压缩保存并有SHA/原commit索引。规则1.0.0；登记PR5 pending；缺board.json，看板unverified/同步pending；处理人及审查待指定；Issue in_progress / PR Draft。

'''
for path,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;p.write_bytes((chapter.format(now=now,prefix=prefix)+p.read_text(encoding='utf-8')).encode())
note='[Checkpoint92](../work/YUZE-LU/162/continuation-checkpoint-92.md)：17130真实345宏pin/三档native-minpin必要0，17170完整七阶段已严格及实际核验但仍有冲突。S仲裁器3200um物理候选source1728/1736均冻结/全源审计通过；旧队列入口拒绝保留，受支持转发1738已实际启动且1742核验四×16CPU/265.6GiB准入。旧23类规范不替换；原最终几何PG/三档RC300MHz门未联合通过，继续任务。\n\n'
for path in ['docs/CONTROL_V1.md','docs/ARCHITECTURE.md']:
 p=r/path;t=p.read_text(encoding='utf-8');first,rest=t.split('\n',1);p.write_bytes((first+'\n\n'+note+rest.lstrip('\n')).encode())
(r/'work/YUZE-LU/162/continuation-checkpoint-92.md').write_bytes((chapter.format(now=now,prefix='../../../')+'[原件](continuation-proof-92/index.json)、[辅助材料](continuation-proof-92/local-index.json)、[实收](continuation-proof-92/reception.json)，承接[91](continuation-checkpoint-91.md)。\n').encode());p=r/'.gitattributes';p.write_bytes(p.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-92/** -text\n');print(json.dumps(dict(passed=True,remote=330,local=len(files),archive=d['archive']['sha256'])))
