from pathlib import Path
import json,hashlib,subprocess,re,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready1732-arbiter-native-refill';assert not record.exists();assert json.loads((b/'r256-arbiter-perimeter-source-audit-1729/receipt.json').read_text())['passed'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
replacement=b/'route-selection-102/sready1731-arbiter-perimeter/tasks.json';tasks=json.loads(replacement.read_text());assert len(tasks['tasks'])==7
for row in tasks['tasks']:assert sha(row['path'])==row['sha256']
for name in ['r256-settled-adaptive-regression-1322','r256-resource-front-source-audit-1342']:assert json.loads((b/name/'receipt.json').read_text())['passed']
assert json.loads((b/'r256-weighted-settle-regression-1252/receipt.json').read_text())['passed'];assert json.loads((b/'r256-weighted-settle-source-audit-1251/receipt.json').read_text())['passed'];assert json.loads((b/'r256-resource-front-regression-1344/receipt.json').read_text())['passed']and json.loads((b/'r256-present-growth-source-audit-1498/receipt.json').read_text())['passed'];record.mkdir();verified=[]
(record/'replacement.json').write_text(json.dumps(dict(path=str(replacement),sha256=sha(replacement),whole_system_qualified=False)))
for node,job,folder,seed,expected_source,minimum_failed,forecast,threshold in [(4,95391,'dynamic-05/node4',15860,'source-1526',0,224,284.8)]:
 mem=json.loads(subprocess.check_output(['srun','--jobid='+str(job),'--overlap','-n1','-c1','python3','-c',"import json;print(json.dumps({k:int(v.split()[0]) for k,v in [l.split(':',1)for l in open('/proc/meminfo')]if k=='MemAvailable'}))"],universal_newlines=True));assert mem['MemAvailable']/1048576>threshold;(record/('fresh-memory-'+str(seed)+'.json')).write_text(json.dumps(dict(time=time.time(),mem=mem,required_available_gib=threshold,forecast_gib=forecast,passed=True)))
 queue=b/folder;state=json.loads((queue/'queue-state.json').read_text());matches=[];current_forecast=sum(json.loads((queue/'pending'/(n+'.json')).read_text())['forecast_gib']for n in state['active'])
 for name in state['active']:
  path=queue/'pending'/(name+'.json');spec=json.loads(path.read_text());a=spec['args']
  if '--out'in a and Path(a[a.index('--out')+1]).parent.name==str(seed):matches.append((path,spec))
 assert len(matches)==1;(path,spec)=matches[0];assert current_forecast-spec['forecast_gib']+64<=forecast and abs(forecast*1.2+16-threshold)<.0001;a=spec['args'];out=a[a.index('--out')+1];source=Path(spec['source_root']);assert spec['script']=='system_upper.py'and source.parent==b and re.fullmatch('source-[0-9]+',source.name)and(source/'source-manifest.json').is_file()
 graph=Path(a[a.index('--graph')+1]);g=json.loads(graph.read_text());assert len(g['instances'])==345 and 'macro_r'in g['instances']
 current=b/'r256-composition-453/topology/boundary-graph.json';cg=json.loads(current.read_text());assert len(cg['instances'])==345 and 'macro_r'in cg['instances']
 details=subprocess.check_output(['scontrol','show','job',str(job),'-o'],universal_newlines=True);assert 'UserId=yuzelu(10011)'in details and 'JobName=yzl-ctl162-'in details and 'NodeList=node'+str(node)+' 'in details
 steps=subprocess.check_output(['scontrol','show','step',str(job),'-o'],universal_newlines=True);found=[m.groups()for m in re.finditer(r'StepId=('+str(job)+r'\.\d+).*?SrunHost:Pid=(node\d+):(\d+)',steps)]
 code="import os,json;d={}"+chr(10)+"for p in "+repr([r[2]for r in found])+":"+chr(10)+" try:"+chr(10)+"  assert os.stat('/proc/'+p).st_uid==10011;d[p]=open('/proc/'+p+'/cmdline','rb').read().decode().split(chr(0))"+chr(10)+" except OSError:pass"+chr(10)+"print(json.dumps(d))"
 procs=json.loads(subprocess.check_output(['srun','--jobid='+str(job),'--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));targets=[]
 for step,host,pid in found:
  cmd=procs.get(pid,[])
  if '--out'in cmd and cmd[cmd.index('--out')+1]==out and str(source/'project/experiments/control_v1/system_upper.py')in cmd:targets.append(dict(step=step,host=host,pid=pid,command=cmd))
 assert len(targets)==1 and targets[0]['host']=='node'+str(node)
 assert source.name==expected_source and graph==current and sha(path)=='240e0c58650e354fcdb37caad9cce20b9ec07860055795f7788e115ef7f40067'
 f=Path(out)/'openroad-search/case-0/openroad.log';text=f.read_text();counts=list(map(int,re.findall(r'Number of violations = (\d+)',text)));assert len(counts)>=6 and min(counts[-3:])>2000000 and max(counts[-3:])-min(counts[-3:])<10000
 logs=[dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size,last=text[-1600:])];attempts=[dict(completed_optimization_drc_counts=counts,whole_system_qualified=False)]
 for relative in ['receipt.json','trees.json','openroad-search/case-0/routed.odb','openroad-search/case-0/routed.def']:assert not(Path(out)/relative).exists(),relative
 row=dict(time=time.time(),target=targets[0],job_details=details,spec=str(path),spec_sha256=sha(path),old_graph=str(graph),old_graph_sha256=sha(graph),expected_old_graph=str(current),expected_old_graph_sha256=sha(current),logs=logs,prior_attempts=attempts,whole_system_qualified=False,reason='Fresh exact own15860/source1526 haloCUGR child only, sixcompletedDRCcounts allnonzero andlastthree>2million within10000range, nofinalroutedODB/DEF/trees/receipt. This is searchpriority replacement, NOT proof futureiterations impossible. ExactspecSHA/UID/job/node/PID/fullcmd/current453/frozensource andfresh224GiBforecast284.8GiBadmission. Prioritize source1728 S-arbiter3200um nativeP&R plusfull original300MHz/electrical/nativeGDS/function/LEC/sixfile chain. Alloldsource/spec/logs/partials andremainingfullcontrols15220/16180/16420/16960/17170/old3751, parentallocations/foreignR preserved. No qualification or gate relaxation.')
 (record/(str(seed)+'-verified-before.json')).write_text(json.dumps(row,indent=2));verified.append((seed,targets[0],out))
for seed,target,out in verified:
 for relative in ['receipt.json','trees.json','openroad-search/case-0/routed.odb','openroad-search/case-0/routed.def']:assert not(Path(out)/relative).exists(),relative
 assert not(Path(out)/'router-output.txt').exists()and not list(Path(out).glob('trial-*/output.txt'))
 subprocess.run(['scancel',target['step']],check=True);(record/(str(seed)+'-cancelled.json')).write_text(json.dumps(dict(time=time.time(),step=target['step'])));print('Refilledverifiedexactownpartial',seed,target['step'])

(record/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,retired_exact_own_steps=[t['step']for _,t,_ in verified],scope='Only freshverified own15860 halochild; alloriginalevidence andparentallocation retained. New3200umSarbiterfullnative chain enabled, not qualification.')))
