from pathlib import Path
import subprocess,shlex,json
b=Path(r'D:\Data\电路实验');remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';host='yuzelu@10.129.166.172'
subprocess.check_call(['ssh',host,'python3 -c '+shlex.quote("from pathlib import Path; Path('"+remote+"/r256-cluster-proposal-data-1712').mkdir()")])
for local,target in [(b/'control162-cluster1712/proposal.json','r256-cluster-proposal-data-1712/proposal.json'),(b/'control162-cluster1712/receipt.json','r256-cluster-proposal-data-1712/local-receipt.json'),(b/'control162-capture1711.json','r256-cluster-proposal-data-1712/old-capture.json'),(b/'control162-queue1713-remote.py','queue1713.py')]:subprocess.check_call(['scp',str(local),host+':'+remote+'/'+target])
q="from pathlib import Path; import json,hashlib; b=Path('"+remote+"'); p=b/'r256-cluster-proposal-data-1712/proposal.json'; r=json.loads((p.parent/'local-receipt.json').read_text()); assert r['passed'] and r['proposal_sha256']==hashlib.sha256(p.read_bytes()).hexdigest(); exec(compile((b/'queue1713.py').read_text(),'queue1713','exec'))"
subprocess.check_call(['ssh',host,'python3 -c '+shlex.quote(q)])
