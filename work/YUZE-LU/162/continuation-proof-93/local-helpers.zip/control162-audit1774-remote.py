from pathlib import Path
import json,hashlib,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1736';new=b/'source-1772';out=b/'r256-link-grouping-source-audit-1774';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());names=['project/experiments/control_v1/topology.py'];assert z['commit']=='f3fd1ac0791a1254fbb9971d0a5c989ac2312987'and len(z['files'])==1029 and{p for p,v in z['files'].items()if a['files'].get(p)!=v}==set(names)
digest='e5305a1d3ea7958b1d83c8fb4cd000008cc093fb2fbb438080b63dec8d4b1c1c';assert sha(b/'source1772.tar.gz')==digest and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==digest and all(sha(new/p)==v for p,v in z['files'].items());out.mkdir();scratch=out/'reverse-copies'
for name in names:
 p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1772.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
assert all((scratch/n).read_bytes()==(old/n).read_bytes()for n in names)
for name in z['files']:
 if name not in names:assert z['files'][name]==a['files'][name]
assert json.loads((b/'r256-arbiter-perimeter-source-audit-1729/receipt.json').read_text())['passed']
v=b/'r256-native-229/2293/native/receipt.json';r=json.loads(v.read_text());assert not r['passed']and r['rtl_passed']and r['mapped']['passed']and r['top']=='control_s_arbiter_r7'and len(r['runs'])==3
for n,d in r['source_sha256'].items():
 assert sha(b/'source-232'/n)==d
 if n!='project/experiments/control_v1/run.py':assert sha(new/n)==d
last=r['commands'][-1];assert last['returncode']==2 and 'do-cts'in last['command'];log=v.parent/last['log'];assert sha(log)==last['sha256']and '[ERROR RSZ-0060] Max buffer count reached.'in log.read_text()
(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1029,unchanged_files=1028,scratch_backout_exact=True,verified_rtl_mapping_source232_bound=True,inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch),str(v):sha(v)},scope='Onlytopology.py optional groupingreference. All1028otherfiles includingallRTL/nativephysical/router/finalgates unchanged. Full1029/archive andscratchreversepatch exact. Old1470pincoordinates selectacceptedlogicalgroups only; actualnew3200pins/dimensions remainauthoritative forallphysicalchecks. Existing316link/25bank/contractionassertions retained. No nativePGqualificationoroldcompositionqualificationtransfer.'),indent=2));print(json.dumps(dict(passed=True,files=1029,unchanged=1028,backout=True)))
