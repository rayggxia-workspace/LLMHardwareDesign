from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-function472-remote.py').read_text(encoding='utf-8')
for a,z in [("root=b/'r256-composition-453'","root=b/'r256-arbiter-composition-1757'"),("out=b/'r256-padding-final-function-audit-472'","out=root/'function-audit'"),("b/'r256-composition-359/selected/physical.json'","root/'selected/physical.json'"),("b/'source-451/project/experiments/control_v1'","b/'source-1736/project/experiments/control_v1'")]:
 assert a in s,a;s=s.replace(a,z)
s=s.replace('Actual padding-only candidate453 eight-program final-cell simulations passed all three independent initialization runs.','Actual new3200umSarbiter candidate1757 eight-program final-cell simulations passed all three independent initialization runs.')
s=s.replace('No current359 program/event qualification inheritance.','No old359/453 program or event qualification inheritance; newnative17380 andfixedPG1741 selected actualviews.')
compile(s,'functionaudit1762','exec');(h/'control162-functionaudit1762-remote.py').write_bytes(s.encode())
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-composition-1757';record=b/'route-selection-102/sready1762-arbiter-real-traces';source=b/'source-1736';out=root/'internal-program-traces'
assert not record.exists()and not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=root/'function/receipt.json';audit=root/'function-audit/receipt.json';assert json.loads(original.read_text())['passed']and json.loads(audit.read_text())['passed']
graph=root/'topology/boundary-graph.json';record.mkdir();cfg=record/'config.json';cfg.write_text(json.dumps(dict(schema='control162-program-event-trace/1',original_receipt=str(original),original_receipt_sha256=sha(original),original_independent_audit=str(audit),original_independent_audit_sha256=sha(audit),signal_graph=str(graph),signal_graph_sha256=sha(graph)),indent=2))
spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=96,requires=[str(original),str(audit),str(b/'r256-arbiter-dispatch-source-audit-1737/receipt.json')],args=list(map(str,['--manifest',root/'selected/physical.json','--graph',graph,'--internal-program-trace-config',cfg,'--out',out])))
p=b/'dynamic-02/node3/pending/00-d-sready1762-internal-traces.json';assert not p.exists();t=p.with_suffix('.tmp');t.write_text(json.dumps(spec));t.rename(p)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=[dict(path=str(p),sha256=sha(p),spec=spec)],whole_system_qualified=False,scope='New1757actualcompiled23type345instance finalcell model only; immutablecompiledassets reusedreadonly withcurrenthashes afterfresh3initial8programs andindependentaudit. ObservationalC/8queue/adapter/externalAXI traces3initials insideown16CPUslot96GiBforecast. Originalgoldenchecks/cycles/results exact andinternal/externalpacketreplayrequired. No old473/1272 qualificationtransfer, noRTL orphysicalgatechange; fullM11/M12 stillindependent.'),indent=2));print(json.dumps(dict(queued=True,record=str(record))))
'''
compile(q,'traces1762','exec');(h/'control162-traces1762-remote.py').write_bytes(q.encode())
print('Prepared fresh function audit and trace queue, not executed')
