from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-audit1737-remote.py').read_text(encoding='utf-8')
for a,z in [("old=b/'source-1728';new=b/'source-1736'","old=b/'source-1736';new=b/'source-1772'"),('r256-arbiter-dispatch-source-audit-1737','r256-link-grouping-source-audit-1774'),("names=['project/experiments/control_v1/run.py']","names=['project/experiments/control_v1/topology.py']"),('4a3b992bb57f93e7c1638f34bf9b823194a6336c','f3fd1ac0791a1254fbb9971d0a5c989ac2312987'),('2cbb9aa66a55d7ed9d50d4043ea692e803136d79fdc38abc373b57c5f579d0ea','e5305a1d3ea7958b1d83c8fb4cd000008cc093fb2fbb438080b63dec8d4b1c1c'),('source1736.tar.gz','source1772.tar.gz'),('backout1736.patch','backout1772.patch')]:
 assert a in s,a;s=s.replace(a,z)
start=s.index("scope='Only4line");end=s.index("'),indent=2)",start)
s=s[:start]+"scope='Onlytopology.py optional groupingreference. All1028otherfiles includingallRTL/nativephysical/router/finalgates unchanged. Full1029/archive andscratchreversepatch exact. Old1470pincoordinates selectacceptedlogicalgroups only; actualnew3200pins/dimensions remainauthoritative forallphysicalchecks. Existing316link/25bank/contractionassertions retained. No nativePGqualificationoroldcompositionqualificationtransfer.'"+s[end+1:]
compile(s,'audit1774','exec');(h/'control162-audit1774-remote.py').write_bytes(s.encode())
s=(h/'control162-scene1757.py').read_text(encoding='utf-8')
s=s.replace("source=b/'source-1736'","source=b/'source-1772'").replace('r256-arbiter-composition-1757','r256-arbiter-composition-1773').replace('sready1757-arbiter-qualified-scene','sready1773-arbiter-qualified-scene').replace('sready1757-','sready1773-').replace('r256-arbiter-dispatch-source-audit-1737','r256-link-grouping-source-audit-1774')
s=s.replace("'--r256-scene','--link-padding-local-reset'","'--r256-scene','--link-padding-local-reset','--link-grouping-reference',b/'r256-composition-359/selected/physical.json'")
s=s.replace('Source1736 frozenfullaudit1737','Source1772 frozenfullaudit1774; original1757automaticnewpin groupingfailed existing316Link8assertion, preserved; old1470referenceusedONLYlogicalgrouping, allnewphysicalpins retained')
compile(s,'scene1773','exec');(h/'control162-scene1773.py').write_bytes(s.encode())
for old,new in [('refine1759','refine1775')]:
 s=(h/('control162-'+old+'.py')).read_text(encoding='utf-8').replace('source-1736','source-1772').replace('r256-arbiter-composition-1757','r256-arbiter-composition-1773').replace('sready1759-','sready1775-').replace('cap-necessary-1759','cap-necessary-1775').replace('17590','17750')
 compile(s,new,'exec');(h/('control162-'+new+'.py')).write_bytes(s.encode())
print('Prepared audit1774, scene1773 and one17750 refinement; not executed')
