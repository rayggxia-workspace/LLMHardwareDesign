from pathlib import Path
h=Path(__file__).parent
s=(h/'control162-watch1765.py').read_text(encoding='utf-8').replace('watch1765.jsonl','watch1777.jsonl')
s=s.replace("wait('r256-arbiter-fixed-pg-1741/17380/delivery/receipt.json')\n+",'')if False else s
s=s.replace(" wait('r256-arbiter-fixed-pg-1741/17380/delivery/receipt.json')\n p=h/'control162-scene1757.py';record(dispatch=str(p));subprocess.run([sys.executable,str(p)],check=True)\n",'')
s=s.replace('r256-arbiter-composition-1757','r256-arbiter-composition-1773').replace('control162-refine1759.py','control162-refine1775.py')
needle="q=\"from pathlib import Path;import json;p=Path(\"+repr(b+'/'+relative)+\");print(json.dumps(json.loads(p.read_text())['passed'] if p.exists()else None))\""
assert needle in s
s=s.replace(needle,"q=\"from pathlib import Path;import json;p=Path(\"+repr(b+'/'+relative)+\");r=Path(\"+repr(b+'/dynamic-03/node5/results/00-b-sready1773-topology.json')+\");print(json.dumps(json.loads(p.read_text())['passed'] if p.exists()else (False if r.exists()and json.loads(r.read_text())['returncode']!=0 else None)))\"")
compile(s,'watch1777','exec');(h/'control162-watch1777.py').write_bytes(s.encode())
for old,new in [('binding1771-remote','binding1778-remote'),('refill1769-remote','refill1779-remote'),('functionaudit1762-remote','functionaudit1780-remote'),('traces1762-remote','traces1780-remote'),('full1764-remote','full1781-remote')]:
 s=(h/('control162-'+old+'.py')).read_text(encoding='utf-8').replace('r256-arbiter-composition-1757','r256-arbiter-composition-1773').replace('source-1736','source-1772').replace('sready1757-arbiter-qualified-scene','sready1773-arbiter-qualified-scene').replace('sready1769-arbiter','sready1779-arbiter').replace('sready1762-arbiter','sready1780-arbiter').replace('sready1762-','sready1780-').replace('sready1764-arbiter','sready1781-arbiter').replace('sready1764-','sready1781-').replace('r256-arbiter-dispatch-source-audit-1737','r256-link-grouping-source-audit-1774').replace('cap-necessary-1759','cap-necessary-1775').replace('17590','17750').replace('17640','17810')
 if old=='binding1771-remote':s=s.replace("and g['boundary_links']==og['boundary_links']","and {k:v for k,v in g['boundary_links'].items()if k!='grouping_reference'}==og['boundary_links']")
 if old=='full1764-remote':s=s.replace("'project/experiments/control_v1/run.py'}","'project/experiments/control_v1/run.py','project/experiments/control_v1/topology.py'}").replace('source1690_only_three_nonrouter_changes','source1690_only_four_nonrouter_changes')
 compile(s,new,'exec');(h/('control162-'+new+'.py')).write_bytes(s.encode())
s=(h/'control162-scene1770.py').read_text(encoding='utf-8').replace('r256-arbiter-composition-1757','r256-arbiter-composition-1773').replace('1757','1773').replace('17590','17750').replace('cap-necessary-1759','cap-necessary-1775')
compile(s,'scene1782','exec');(h/'control162-scene1782.py').write_bytes(s.encode())
print('Prepared bounded1777 watch,1778 binding,1779 memory guard,1780 trace,1781 fullchain; no successor run yet')
