from pathlib import Path
import subprocess
h=Path(__file__).parent;r=h/'LLMHardwareDesign-worktrees/issue-162-control';name='project/experiments/control_v1/topology.py'
compile((r/name).read_bytes(),name,'exec')
out=r/'work/YUZE-LU/162/link-grouping1772';assert not out.exists();out.mkdir()
(out/'README.md').write_bytes('''# Preserve accepted Link8 grouping for the new S-arbiter interface

Refs #162 / PR #163. The new3200um `control_s_arbiter_r7` completed all native and fixed-PG gates at `r256-arbiter-perimeter-1738/17380` and `r256-arbiter-fixed-pg-1741/17380`; setup/hold +1.194584/+0.022119ns. This is individual block qualification only.

Fresh1757 selection passed. Automatic grouping from the changed pin geometry hit the existing reset-bank316-Link8 assertion before generating a topology receipt. Preserve the failed output and task result; its dependent function/STA/placement tasks have not run. No new reset block or weakened assertion is introduced.

The optional `--link-grouping-reference` uses the actual previous1470um physical manifest solely to reproduce the accepted logical lane grouping. It requires the3200um selected arbiter, the same1402 port names and identical other22 physical rows. New selected dimensions, pins and six-file identities stay authoritative for every physical checker; only the grouping recipe uses the reference coordinates. Existing contraction,316-link/25-bank checks and all validation remain intact. Default invocation is unchanged. Full fresh topology, function, placement, native and upper RC/geometry/PG/300MHz still have to run; no previous composition qualification transfers.

Rule1.0.0; registration PR5 pending; board unverified/sync pending; reviewer unassigned; Draft PR, no merge.
'''.encode())
p=r/'progress/YUZE-LU/STATUS.md';p.write_bytes(p.read_bytes()+'\n2026-11-05 CST · #162/PR163：新3200um S仲裁器17380已通过全部原生与固定PG验收及六文件，setup/hold+1.194584/+0.022119ns。1757库选择通过，拓扑按新pin自动分组触发既有316Link8断言失败；保留失败及未启动后继，新增仅逻辑分组参考选项，保持原316Link8/25复位bank。待冻结/全源审计后重跑新组合全部验收，系统未通过，不合并。\n'.encode())
files=[name,'progress/YUZE-LU/STATUS.md',str((out/'README.md').relative_to(r))]
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True)
subprocess.run(['git','add','--',*files],cwd=r,check=True)
for p in files:assert subprocess.check_output(['git','show',':'+p.replace('\\','/')],cwd=r)==(r/p).read_bytes()
subprocess.run(['git','diff','--cached','--binary','--output='+str(h/'control162-backout1772.patch'),'--',name],cwd=r,check=True)
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Preserve accepted Link8 grouping when requalifying S arbiter interface'],cwd=r,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip())
