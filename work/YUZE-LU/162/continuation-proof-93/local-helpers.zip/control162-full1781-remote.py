from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-composition-1773';source=b/'source-1772';record=b/'route-selection-102/sready1781-arbiter-fullchain';audit=root/'final-chain-binding-audit';assert not record.exists()and not audit.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
graph=root/'topology/boundary-graph.json';topology=root/'topology/topology.json';physical=root/'selected/physical.json';functions=root/'selected/functions.json';g=json.loads(graph.read_text());m=json.loads(physical.read_text());assert len(g['instances'])==345 and len(m['leaves'])==23 and g['instances']['s_port']=='control_s_arbiter_r7'and m['leaves']['control_s_arbiter_r7']['die_um']==[3200,3200]
assert g['instances']==json.loads((b/'r256-composition-453/topology/boundary-graph.json').read_text())['instances']
assert g['inputs'][str(physical)]==sha(physical)
fn=root/'function';fr=json.loads((fn/'receipt.json').read_text());fa=root/'function-audit/receipt.json';assert json.loads(fa.read_text())['passed']and fr['passed']and fr['R_integrated']and fr['real_program_count']==8 and fr['physical_instances']==345 and fr['actual_final_leaf_count']==23
assert fr['inputs'][str(graph)]==sha(graph)and fr['inputs'][str(physical)]==sha(physical)and fr['inputs'][str(topology)]==sha(topology)
for n,r in fr['initial_results'].items():assert r==json.loads((fn/n).read_text())and r['passed']and r['cpu_tensor_moves']==0 and r['real_compositions']==8
trace=root/'internal-program-traces/receipt.json';tr=json.loads(trace.read_text());assert tr['passed']and tr['stage']=='actual-final-cell-internal-program-trace-only'and tr['inputs'][str(graph)]==sha(graph)and tr['inputs'][str(fn/'receipt.json')]==sha(fn/'receipt.json')
place=root/'cap-candidates/17750';pr=json.loads((place/'receipt.json').read_text());assert pr['passed']and pr['stage']=='wire-cap-lower-bound-only'
necessary=root/'cap-necessary-1775/17750';pin=necessary/'native-pin-load/native-pin-load.json';pd=json.loads(pin.read_text());assert pd['passed']and len(pd['placements'])==1 and pd['placements'][0]['placement']==str(place)and pd['placements'][0]['violations']==dict(low=0,base=0,high=0)
for s in ['native-residual','native-pin-load']:assert json.loads((necessary/s/'receipt.json').read_text())['passed']
placement=json.loads((place/'placement.json').read_text());assert placement['graph_sha256']==sha(graph)and len(placement['placements_um'])==345 and len(placement['terminals'])==11149 and sum(map(len,placement['terminals'].values()))==24760
for n in ['r256-link-grouping-source-audit-1774','r256-cut-keepout-source-audit-1691','r256-cut-keepout-preflight-16920']:assert json.loads((b/n/'receipt.json').read_text())['passed']
original=json.loads((b/'source-1690/source-manifest.json').read_text());current=json.loads((source/'source-manifest.json').read_text());changed={p for p,v in current['files'].items()if original['files'].get(p)!=v};assert changed=={'project/experiments/block_v2/physical.py','project/experiments/control_v1/physical_only.py','project/experiments/control_v1/run.py','project/experiments/control_v1/topology.py'}
template=json.loads((b/'route-selection-102/sready1717-hpwl-keepout-fullchain/tasks.json').read_text())['tasks'];assert len(template)==7;seed=17810;scene=root/'upper-candidates'/str(seed);config=root/('acceptance-'+str(seed)+'.json');assert not config.exists();cfg=dict(geometry=str(scene/'geometry'),pg_audit=str(scene/'pg-audit'),function_run=str(fn),topology=str(topology),signal_graph=str(graph),timing={v:str(scene/'timing'/v)for v in ['low','base','high']});config.write_text(json.dumps(cfg,indent=2));rows=[]
for old in template:
 spec=json.loads(json.dumps(old['spec']));spec['source_root']=str(source)
 def remap(x):return x.replace('/r256-composition-359/selected/', '/r256-arbiter-composition-1773/selected/').replace('/r256-composition-359/fixed-pg-wrappers','/r256-arbiter-composition-1773/fixed-pg-wrappers').replace('/r256-composition-453/','/r256-arbiter-composition-1773/').replace('/upper-candidates/17170/','/upper-candidates/17810/').replace('acceptance-17170.json','acceptance-17810.json').replace('/cap-candidates/17130','/cap-candidates/17750')
 spec['args']=[remap(x)for x in spec['args']]
 if spec['script']=='system_upper.py':
  a=spec['args'];a[a.index('--seed')+1]=str(seed)
  spec['requires']=list(map(str,[necessary/'native-pin-load/receipt.json',root/'topology/receipt.json',fn/'receipt.json',fa,trace,place/'receipt.json',b/'r256-link-grouping-source-audit-1774/receipt.json',b/'r256-cut-keepout-source-audit-1691/receipt.json',b/'r256-cut-keepout-preflight-16920/receipt.json',audit/'receipt.json']))
 else:spec['requires']=[remap(x)for x in spec['requires']]
 folder='dynamic-05/node4'if spec['script']=='system_sta.py'else'dynamic-03/node5'
 p=b/folder/'pending'/(Path(old['path']).stem.replace('sready1717','sready1764').replace('17170',str(seed))+'.json');assert not p.exists();rows.append(dict(path=str(p),spec=spec))
# Validate the complete reviewable seven-stage chain before exposing any task.
assert set(cfg)=={'geometry','pg_audit','function_run','topology','signal_graph','timing'}and set(cfg['timing'])=={'low','base','high'}
for row in rows:
 s=row['spec'];a=s['args'];out=Path(a[a.index('--out')+1]);assert scene in out.parents and s['source_root']==str(source)
 assert a[a.index('--manifest')+1]==str(physical)
 if s['script']=='system_sta.py':
  v=a[a.index('--rc-variant')+1];assert s['forecast_gib']==224 and out==scene/'timing'/v and a[a.index('--graph')+1]==str(graph)and a[a.index('--functional-views')+1]==str(functions)and a[a.index('--upper-geometry')+1]==cfg['geometry']and '--stitch-native-access'in a and '--audit-native-coverage'in a
 elif s['script']=='system_upper.py':assert out==scene/'route'and a[a.index('--graph')+1]==str(graph)and a[a.index('--reuse-placement')+1]==str(place)and a[a.index('--router')+1]=='openroad'and a[a.index('--openroad-global-router')+1]=='cugr'and '--openroad-parity-aware-markers'in a and '--lock-native-output-routes'in a and '--defer-access-vias'in a
 else:
  assert a[a.index('--route')+1]==str(scene/'route')and a[a.index('--graph')+1]==str(scene/'route/physical-graph.json')
  if '--acceptance'in a:assert a[a.index('--acceptance')+1]==str(config)and out==scene/'delivery'
  elif '--pg-audit'in a:assert a[a.index('--pg-audit')+1]==cfg['geometry']and out==scene/'pg-audit'
  else:assert out==scene/'geometry'
audit.mkdir();inputs={str(p):sha(p)for p in [graph,topology,physical,functions,fn/'receipt.json',fa,trace,pin,place/'receipt.json',place/'placement.json',config,source/'source-manifest.json']}
(audit/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,inputs=inputs,specifications=rows,source1690_only_four_nonrouter_changes=sorted(changed),scope='Strictfresh1757selected23types345instances,new3200Sarbiteractualpins/area,actualfresh3initial8programs andfreshinternal/externaltraces, necessaryall3zero, ownsevenstagecfg geometryPGnativeXORall3RC300MHz andfinaldeliverypaths. Existingfullgates unchanged; no fullqualification untilactualjoin. Old453/source1690routingcode byteexact, oldscenequalifications notinherited.'),indent=2))
record.mkdir()
for row in rows:
 p=Path(row['path']);t=p.with_suffix('.tmp');t.write_text(json.dumps(row['spec']));t.rename(p);row['sha256']=sha(p)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,strict_binding_audit=str(audit/'receipt.json'),scope='Onefreshfullcandidate17810 only, original7stage backendCUGR/geometryPG/XOR/lowbasehigh224GiB300MHz/jointdelivery. Existingnode5naturallyfreeddiagnosticslot andnode4STA withoriginalmemoryguard, no newparent orcancel. No singleblock/necessarycap/functionpass substitutedforactualjointacceptance.'),indent=2));print(json.dumps(dict(queued=7,candidate=seed,whole_system_qualified=False)))
