import subprocess,shlex
q='''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-perimeter-1738/17380/gates'
for op in ['physical','drc','function','formal','deliver']:
 p=root/op/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print(op,d.get('passed'),[(v.get('log'),v.get('returncode'))for v in d.get('commands',[])[-2:]])
for folder in ['dynamic-02/node3','dynamic-03/node5','dynamic-05/node4']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print(folder,[n for n in d['active']if'17380'in n])
 for sub in ['', 'results']:
  for f in(p/sub).glob('*sready1747*'):
   if f.is_file():print(str(f),f.read_text()[-1000:])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
