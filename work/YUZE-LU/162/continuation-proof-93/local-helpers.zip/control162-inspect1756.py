import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for sub in ['wrapper','checks/physical','checks/timing','delivery']:
 p=b/'r256-arbiter-fixed-pg-1741/17380'/sub/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print(sub,d.get('passed'),str(d)[-700:])
for folder in ['dynamic-05/node4','dynamic-02/node3','dynamic-03/node5','dynamic-07/node7']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print(folder,'active',d['active'])
 for n in d['active']:
  f=p/'pending'/(n+'.json');s=json.loads(f.read_text());print(n,s['forecast_gib'],s['script'])
for sub in ['topology/topology.json','topology/boundary-graph.json']:
 d=json.loads((b/'r256-composition-453'/sub).read_text());print('oldgraph',sub,list(d),{k:len(v) for k,v in d.items()if isinstance(v,(dict,list))})
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
