import subprocess,shlex
q=r'''from pathlib import Path
import json,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-arbiter-fixed-pg-1741/17380/wrapper'
print('time',time.time())
for f in p.iterdir():
 if f.is_file():print(f.name,f.stat().st_size,round(time.time()-f.stat().st_mtime))
code="""from pathlib import Path
import os,json
for p in Path('/proc').glob('[0-9]*'):
 try:
  if p.stat().st_uid!=10011:continue
  a=(p/'cmdline').read_bytes().decode().split(chr(0))
  if not any('/r256-arbiter-fixed-pg-1741/17380/'in x for x in a):continue
  stat=(p/'stat').read_text().split();print(json.dumps(dict(pid=p.name,cmd=a,cpu_ticks=stat[13:15],state=stat[2],rss_pages=stat[23],wchan=(p/'wchan').read_text())))
 except (OSError,UnicodeDecodeError):pass
"""
print(subprocess.check_output(['srun','--jobid=95391','--overlap','-n1','-c1','python3','-c',code],universal_newlines=True))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
