import subprocess,shlex
q=r'''from pathlib import Path
import subprocess,json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'dynamic-05/node4';d=json.loads((p/'queue-state.json').read_text());total=sum(json.loads((p/'pending'/(n+'.json')).read_text())['forecast_gib']for n in d['active']);mem=json.loads(subprocess.check_output(['srun','--jobid=95391','--overlap','-n1','-c1','python3','-c',"import json;print(json.dumps({k:int(v.split()[0])for k,v in [l.split(':',1)for l in open('/proc/meminfo')]if k in ['MemTotal','MemAvailable']}))"],universal_newlines=True));print(json.dumps(dict(time=time.time(),node='node4',current_forecast_gib=total,actual_mem_gib={k:v/1048576 for k,v in mem.items()},future_STA_forecast=224,STA_total_if_others_unchanged=160+224,required_available_gib=476.8,no_admission_claim=True)))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
