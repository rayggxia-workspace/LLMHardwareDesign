import subprocess,shlex
q='''from pathlib import Path
import json,math
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-arbiter-perimeter-1738/17380/gates';f=p/'physical/timed-endpoints/endpoints.tsv';a=[l.split()for l in f.read_text().splitlines()];print('timing',json.dumps(dict(endpoints=len(a),setup=min((float(v[1]),v[0])for v in a if math.isfinite(float(v[1]))),hold=min((float(v[2]),v[0])for v in a if math.isfinite(float(v[2]))))))
for name in ['native-drc.log','gds.log','full-deck.log']:
 f=p/'drc'/name
 if f.exists():print(name,f.read_text()[-1100:])
print('drcfiles',[f.name for f in(p/'drc').iterdir()if f.is_file()])
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)]).decode())
