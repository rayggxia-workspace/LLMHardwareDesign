import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-fixed-pg-1741/17380'
for sub in ['wrapper','checks/physical','checks/timing','delivery']:
 p=root/sub
 if not p.exists():continue
 print(sub)
 for n in ['receipt.json','pg-fixed-access.json','pg-fixed-timing.json']:
  f=p/n
  if f.exists():
   d=json.loads(f.read_text());print(n,d.get('passed'),str(d)[-450:])
 for f in p.glob('*.log'):print(f.name,f.read_text(errors='replace')[-600:])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
