import subprocess,shlex,json
from pathlib import Path
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'dynamic-05/node4';state=json.loads((p/'queue-state.json').read_text());rows=[]
for n in state['active']:
 f=p/'pending'/(n+'.json');s=json.loads(f.read_text());a=s['args']
 if '--out'not in a or Path(a[a.index('--out')+1]).parent.name!='12561':continue
 out=Path(a[a.index('--out')+1]);attempts=[]
 for log in out.glob('trial-*/router.log'):
  lines=log.read_text().splitlines();rounds=[json.loads(v)['round']for v in lines if v.startswith('{')and'"conflict_nodes"'in v];attempts.append(dict(path=str(log),bytes=log.stat().st_size,maximum_round=max(rounds)if rounds else None,last=lines[-1]if lines else None))
 rows.append(dict(spec_path=str(f),spec_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),spec=s,attempts=attempts,final_outputs={v:(out/v).exists()for v in ['receipt.json','trees.json','router-output.txt','openroad-search/case-0/routed.odb']},trial_outputs=list(map(str,out.glob('trial-*/output.txt')))))
print(json.dumps(dict(time=time.time(),rows=rows,no_retirement=True)))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50)
d=json.loads(raw);p=Path(__file__).with_suffix('.json');assert not p.exists();p.write_bytes(raw)
for r in d['rows']:print(json.dumps(dict(spec=r['spec_path'],sha=r['spec_sha256'],source=r['spec']['source_root'],forecast=r['spec']['forecast_gib'],attempts=len(r['attempts']),rounds=[v['maximum_round']for v in r['attempts']],completed_failed=sum(v['last']=='negotiation did not converge'for v in r['attempts']),outputs=r['final_outputs'],trial_outputs=r['trial_outputs'],no_retirement=True)))
