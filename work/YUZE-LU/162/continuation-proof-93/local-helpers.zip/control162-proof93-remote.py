from pathlib import Path
import json,hashlib,time,zipfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'continuation-proof-93';assert not out.exists();chosen=set()
def add(p):
 p=Path(p)
 if p.is_file()and p.stat().st_size<=12000000:chosen.add(p)
def tree(p):
 p=Path(p);assert p.is_dir(),str(p)
 for f in p.rglob('*'):add(f)
for sub in ['r256-arbiter-perimeter-1738/17380/gates','r256-arbiter-fixed-pg-1741/17380','r256-link-grouping-source-audit-1774','r256-arbiter-composition-1757/selected','r256-arbiter-composition-1757/topology','r256-arbiter-composition-1773/selected','r256-arbiter-composition-1773/topology','r256-arbiter-composition-1773/source-binding-audit']:tree(b/sub)
for record in ['sready1747-parallel-arbiter-gates','sready1749-parallel-arbiter-refill','sready1741-arbiter-perimeter-pg','sready1757-arbiter-qualified-scene','sready1776-failed-topology-successors','sready1773-arbiter-qualified-scene','sready1775-arbiter-native-aware-placement','sready1779-arbiter-sta-memory-refill']:tree(b/'route-selection-102'/record)
for sub in ['source1772.tar.gz','source-1772/source-manifest.json','source-1772/freeze-import.json','control162-backout1772.patch','control162-audit1774-remote.py','control162-binding1778-remote.py','control162-refill1779-remote.py']:add(b/sub)
for folder in ['dynamic-05/node4','dynamic-02/node3','dynamic-03/node5']:
 q=b/folder
 for pattern in ['*1741*','*1747*','*1757*','*1773*','*1775*']:
  for sub in ['','commands','results']:
   for f in(q/sub).glob(pattern):add(f)
out.mkdir();live=out/'live';live.mkdir();states=[]
for seed in [15220,16180,16220,17170]:
 p=b/'r256-composition-453/upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if f.exists():to=live/(str(seed)+'.log');to.write_bytes(f.read_bytes());add(to)
 states.append(dict(candidate=seed,receipt_exists=(p/'receipt.json').exists(),final_trees_exist=(p/'trees.json').exists(),routed_odb_exists=(p/'openroad-search/case-0/routed.odb').exists()))
for sub in ['function','native-sta','cap-initial']:
 p=b/'r256-arbiter-composition-1773'/sub
 if not p.exists():continue
 for f in p.glob('*.log'):
  if f.stat().st_size<=12000000:to=live/(sub+'-'+f.name);to.write_bytes(f.read_bytes());add(to)
 for name in ['receipt.json','initial-1-162.json','initial-2-162.json','initial-2-163.json','hierarchical-inputs.json','native-system-audit.json','placement.json','wire-cap-lower-bound.json']:add(p/name)
queues=[]
for folder in ['dynamic-05/node2','dynamic-02/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 p=b/folder/'queue-state.json';d=json.loads(p.read_text());to=live/(folder.replace('/','-')+'-queue-state.json');to.write_bytes(p.read_bytes());add(to);queues.append(dict(folder=folder,job=d['job'],slots=d['slots'],active=len(d['active'])))
files={};archive=out/'selected-originals.zip'
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(chosen):
  raw=p.read_bytes();entry=str(p.relative_to(b));z.writestr(entry,raw);files[str(p)]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),zip_entry=entry)
with zipfile.ZipFile(str(archive))as z:assert z.testzip()is None
native=b/'r256-arbiter-perimeter-1738/17380/gates/deliver';pg=b/'r256-arbiter-fixed-pg-1741/17380/delivery'
assert json.loads((native/'receipt.json').read_text())['passed']and json.loads((pg/'receipt.json').read_text())['passed'];delivery=json.loads((pg/'delivery.json').read_text());assert delivery['passed']and delivery['native_leaf_accepted']and delivery['die_um']==[3200,3200]
idx=dict(time=time.time(),whole_system_qualified=False,indexed_files=len(files),copied_files=len(files),files=files,external_files={name:row for name,row in delivery['final_files'].items()},archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),actual_route_file_states=states,queue_snapshots=queues,scope='Actual3200R7native4gates/6file +fixedPG completeGDSDRC/nativecontinuity/freshRC300MHz/fullviewidentity accepted.1757selectionpassed butautomaticgeometrygroupingfailed316Link8assertion; failedtopology/result and3neverstarted successors preserved. Source1772onlytopologygroupingreference full1029/archive/backoutaudit1774. Actual1773regeneratedgraph andsourcebinding1778passed exact345owners/316links/logical453 connections; onlySarbiterphysicalrowdiffers, other22exact. Area+8.0791mm2 chargedfreshplacement. Actual3initialfunction/nativeSTA/initialplacement running, noqualificationtransfer. Exactown16180step95391.169retiredONLYafterfreshUID/source/spec/nooutputs/5+nonzeroDRCcounts/452.816GiBavailable below476.8butabove438.4GiB; actualSTA352GiBaggregate admission captured. Otherjobs/parents/R/old3751 untouched;8parents35of36active snapshot, onevacancy dueactualmemory. FullzeroM11/M12/nativegeometryXOR/PG/lowbasehigh300MHz/jointdelivery notpassed. Live logs capturedprefixes only.')
(out/'index.json').write_text(json.dumps(idx,indent=2));print(json.dumps(dict(passed=True,files=len(files),zip_bytes=archive.stat().st_size,zip_sha256=idx['archive']['sha256'],queues=queues)))
