from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
h=Path(__file__).parent;r=h/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/continuation-proof-93';assert not out.exists();out.mkdir();sha=lambda v:hashlib.sha256(v).hexdigest();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-93/'
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-93/** -text\nwork/YUZE-LU/162/source-binding-current1773.json -text\nwork/YUZE-LU/162/state-ownership-current1773.json -text\n')
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp','yuzelu@10.129.166.172:'+remote+n,str(out/n)],check=True)
d=json.loads((out/'index.json').read_bytes());assert sha((out/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='6f987f11fc81caaed61671a8525a3bf5798a86c0e809e4fad6532e6d37dbdb8d'
with zipfile.ZipFile(out/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==695
 for v in d['files'].values():raw=z.read(v['zip_entry']);assert len(raw)==v['bytes']and sha(raw)==v['sha256']
 def read(p):return json.loads(z.read(p))
 for op in ['physical','drc','function','formal','deliver']:assert read('r256-arbiter-perimeter-1738/17380/gates/'+op+'/receipt.json')['passed']
 for op in ['wrapper','checks/physical','checks/timing','delivery']:assert read('r256-arbiter-fixed-pg-1741/17380/'+op+'/receipt.json')['passed']
 pg=read('r256-arbiter-fixed-pg-1741/17380/delivery/delivery.json');assert pg['passed']and pg['native_leaf_accepted']and pg['die_um']==[3200,3200]and pg['minimum_setup_ns']==1.194584 and pg['minimum_hold_ns']==.022119
 a=read('r256-arbiter-composition-1773/source-binding-audit/receipt.json');assert a['passed']and a['physical_types']==23 and a['instances']==345 and a['other22_physical_rows_byte_content_equal']and a['logical_ports_instances_connections_and316links_exact_old453']
 assert read('r256-link-grouping-source-audit-1774/receipt.json')['passed']and read('route-selection-102/sready1776-failed-topology-successors/receipt.json')['passed']and read('route-selection-102/sready1779-arbiter-sta-memory-refill/receipt.json')['passed']
 adm=read('dynamic-05/node4/commands/00-c-sready1773-native-sta.json')['admission'];assert adm['admitted']and adm['forecast_gib']==352 and adm['required_bytes']==(352*1.2+16)*1024**3 and adm['available_bytes']>adm['required_bytes']
 images=[n for n in z.namelist()if n.endswith('.png')and ('gates/deliver/'in n or '/17380/delivery/'in n)]
 for n in images:p=out/'layouts'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
 actual=sum(v['active']for v in d['queue_snapshots']);assert actual==34
 (out/'capture-scope-erratum.json').write_bytes(json.dumps(dict(actual_active=actual,max_slots=36,incorrect_scope_text='8parents35of36active snapshot',correction='Actual indexed queue snapshots total34: node4three because224GiBSTA memory andnode5three becauseinitialplacementcompleted andnativeaware successorswaitactualnativeSTA. Preserve originalindexbytes; thiserratum correctsonlystale scopephrase.',archive_sha256=d['archive']['sha256'],whole_system_qualified=False),indent=2).encode())
 index=dict(passed=True,whole_system_qualified=False,physical_types=23,instances=345,individually_qualified_only=True,leaves=a['leaves'],inputs=a['inputs'],owners=a['owners'],arbiter_area_mm2=a['arbiter_area_mm2'],source_binding_receipt_zip_entry='r256-arbiter-composition-1773/source-binding-audit/receipt.json',archive='continuation-proof-93/selected-originals.zip',archive_sha256=d['archive']['sha256'],scope=a['scope'])
 (r/'work/YUZE-LU/162/source-binding-current1773.json').write_bytes(json.dumps(index,indent=2).encode())
 old=json.loads((r/'work/YUZE-LU/162/state-ownership-current396.json').read_bytes());descs={v['instance']:v for v in old['owners']};assert set(descs)=={v['instance']for v in a['owners']}
 owners=[]
 for row in a['owners']:
  previous=descs[row['instance']];assert row['physical_type']==previous['physical_type'];v=dict(previous,**row);v['canonical_leaf_ref']='source-binding-current1773.json#/leaves/'+row['physical_type'];owners.append(v)
 old.update(owners=owners,inputs=a['inputs'],captured_at=a['time'],scope=a['scope'],source_binding='source-binding-current1773.json',ownership_rule=a['state_ownership_rule'],whole_system_qualified=False)
 (r/'work/YUZE-LU/162/state-ownership-current1773.json').write_bytes(json.dumps(old,indent=2,ensure_ascii=False).encode())
names=['gates1751.py','metrics1753.py','inspect1756.py','scene1757.py','pg1758.py','refine1759.py','live1760.py','build1762.py','functionaudit1762-remote.py','traces1762-remote.py','template1763.py','full1764-remote.py','watch1765.py','memory1767.py','preflight1768.py','refill1769-remote.py','scene1770.py','binding1771-remote.py','commit1772.py','build1774.py','audit1774-remote.py','scene1773.py','refine1775.py','retire1776.py','build1777.py','watch1777.py','binding1778-remote.py','refill1779-remote.py','functionaudit1780-remote.py','traces1780-remote.py','full1781-remote.py','scene1782.py','proof93-remote.py','receive93.py']
files={'control162-'+n:(h/('control162-'+n)).read_bytes()for n in names}
for n in ['control162-preflight1768.json','control162-watch1765.jsonl','control162-watch1777.jsonl','control162-online1755-verified.json','control162-backout1772.patch']:files[n]=(h/n).read_bytes()
for label in [1748,1772]:
 p=h/('control162-git-data-publish-'+str(label))/'receipt.json';v=json.loads(p.read_bytes());assert v['passed']and v['force']is False;files['publish'+str(label)+'-receipt.json']=p.read_bytes()
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,raw in files.items():z.writestr(n,raw)
with zipfile.ZipFile(out/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==raw for n,raw in files.items())
(out/'local-index.json').write_bytes(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(out/'local-helpers.zip').stat().st_size,sha256=sha((out/'local-helpers.zip').read_bytes()))),indent=2).encode())
(out/'reception.json').write_bytes(json.dumps(dict(passed=True,remote_entries=695,local_entries=len(files),all_actual_member_crc_bytes_sha256=True,external_native_six_files_downloaded=False,actual_layout_images=images,scope_erratum='capture-scope-erratum.json',whole_system_qualified=False),indent=2).encode())
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter='''# Issue162：新S仲裁器全部单块验收通过，新组合重新实测

更新时间：{now}。[Checkpoint93]({prefix}work/YUZE-LU/162/continuation-checkpoint-93.md) / [695项实际原件]({prefix}work/YUZE-LU/162/continuation-proof-93/index.json) / [23类六文件与源绑定]({prefix}work/YUZE-LU/162/source-binding-current1773.json) / [345项状态归属]({prefix}work/YUZE-LU/162/state-ownership-current1773.json)。main六宏、S1350内部驱动及R均保留，外部R工作不动。

新增控制块S仲裁器3200um的原生P&R、300MHz时序/电气、完整native/GDS DRC、三初态功能、严格LEC、六文件/图全部通过；固定PG完整GDS DRC、VDD/VSS连通、freshRC时序和完整功能视图同一性亦通过。setup/hold最差+1.194584/+0.022119ns。相对原1470um面积增加8.0791mm²，必须计入新组合，不能继承旧摆放/RC。

1757库选择通过，但按新pin自动分组触发既有316Link8/25bank断言失败；失败拓扑/原规格/结果保留，三个从未启动的后继按原字节归档。source1772仅拓扑生成器新增“逻辑分组参考”，1029项/归档/反向补丁审计1774通过，其余1028源文件及全部验收门不变。实际1773拓扑通过，345宿主/316Link8/全部逻辑连接与453精确相同；1778源绑定审计通过，其他22物理类型完整行相同，只有S仲裁器选用新的合格六文件。所有实际物理检查仍使用新3200um引脚与尺寸。

新组合功能编译、原生STA及初始摆放已独立启动；初始摆放已完成仅线容下界阶段，后继等实际原生STA。node4实测452.816GiB低于全部三个旧搜索加224GiB STA所需476.8GiB；只退役本任务16180/95391.169，原5+次非零DRC/全部部分结果保留、UID/spec/source/PID/无最终输出核验通过。余两项搜索加STA预测352GiB需438.4GiB，实际准入记录通过；不降低门槛。8父节点快照实际34/36活跃：node4内存限制三项，node5初始完成后等依赖三项；原索引scope旧文字35项已另附勘误，原件不修改。c96六×16动态补位，父任务、旧3751、其他工作不动。

**仍未获得完整组合全网零冲突、native几何/XOR/PG、三档分布RC 300MHz及联合最终交付资格。继续布局布线定位迭代，不在检查点停止，不借单块通过宣布系统通过，不合并。** 规则1.0.0；登记PR5 pending；看板缺配置unverified/同步pending；审查待指定；Issue in_progress / PR Draft。

'''
for path,prefix in [('docs/STATUS.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;p.write_bytes((chapter.format(now=now,prefix=prefix)+p.read_text(encoding='utf-8')).encode())
note='[Checkpoint93](../work/YUZE-LU/162/continuation-checkpoint-93.md)：新3200um S仲裁器全部原生及固定PG/300MHz/六文件通过；新1773真实拓扑和345项状态/23类源绑定已重验，其他22类型不变。1757拓扑失败/未启动后继保留，source1772逻辑分组参考仅一文件改变，全部验收门不变。新组合功能/原生STA/摆放继续，尚无联合物理资格。\n\n'
for path in ['docs/CONTROL_V1.md','docs/ARCHITECTURE.md']:
 p=r/path;t=p.read_text(encoding='utf-8');first,rest=t.split('\n',1);p.write_bytes((first+'\n\n'+note+rest.lstrip('\n')).encode())
(r/'work/YUZE-LU/162/continuation-checkpoint-93.md').write_bytes((chapter.format(now=now,prefix='../../../')+'承接[92](continuation-checkpoint-92.md)。[实收](continuation-proof-93/reception.json)、[原索引计数勘误](continuation-proof-93/capture-scope-erratum.json)。\n').encode());print(json.dumps(dict(passed=True,remote=695,local=len(files),images=len(images),owners=len(owners),actual_active=actual)))
