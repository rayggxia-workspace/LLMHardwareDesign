from pathlib import Path
import json,hashlib,subprocess,re,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready1769-arbiter-sta-memory-refill';assert not record.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();queue=b/'dynamic-05/node4';job=95391
root=b/'r256-arbiter-composition-1757';graph=root/'topology/boundary-graph.json';assert json.loads((root/'topology/receipt.json').read_text())['passed']and len(json.loads(graph.read_text())['instances'])==345
assert json.loads((b/'r256-arbiter-fixed-pg-1741/17380/delivery/receipt.json').read_text())['passed']
task=next(r for r in json.loads((b/'route-selection-102/sready1757-arbiter-qualified-scene/tasks.json').read_text())['tasks']if r['spec']['script']=='system_sta.py');sp=Path(task['path']);assert sha(sp)==task['sha256']and task['spec']['forecast_gib']==224 and task['spec']['source_root']==str(b/'source-1736')
state=json.loads((queue/'queue-state.json').read_text());assert sp.stem in state['unfinished']and sp.stem not in state['active']and sp.stem not in state['finished'];assert not(root/'native-sta/receipt.json').exists()
original=json.loads((b/'route-selection-102/sready1618-current-cugr-density-fullchain/tasks.json').read_text())['tasks'];matches=[];current_forecast=0
for n in state['active']:
 p=queue/'pending'/(n+'.json');s=json.loads(p.read_text());current_forecast+=s['forecast_gib'];a=s['args']
 if '--out'in a and Path(a[a.index('--out')+1]).parent.name=='16180':matches.append((p,s))
assert len(matches)==1;p,s=matches[0];a=s['args'];out=Path(a[a.index('--out')+1]);assert s['script']=='system_upper.py'and s['source_root']==str(b/'source-1526')and s['forecast_gib']==32
old=next(r for r in original if r['path']==str(p));assert sha(p)==old['sha256']and s==old['spec']
assert current_forecast==160;full=current_forecast+224;after=current_forecast-32+224;assert full==384 and after==352
mem=json.loads(subprocess.check_output(['srun','--jobid='+str(job),'--overlap','-n1','-c1','python3','-c',"import json;print(json.dumps({k:int(v.split()[0])for k,v in [l.split(':',1)for l in open('/proc/meminfo')]if k=='MemAvailable'}))"],universal_newlines=True));available=mem['MemAvailable']/1048576;assert after*1.2+16<available<full*1.2+16
details=subprocess.check_output(['scontrol','show','job',str(job),'-o'],universal_newlines=True);assert 'UserId=yuzelu(10011)'in details and 'JobName=yzl-ctl162-'in details and 'NodeList=node4 'in details
steps=subprocess.check_output(['scontrol','show','step',str(job),'-o'],universal_newlines=True);found=[m.groups()for m in re.finditer(r'StepId=('+str(job)+r'\.[0-9]+).*?SrunHost:Pid=(node[0-9]+):([0-9]+)',steps)]
code="import os,json;d={}"+chr(10)+"for p in "+repr([r[2]for r in found])+":"+chr(10)+" try:"+chr(10)+"  assert os.stat('/proc/'+p).st_uid==10011;d[p]=open('/proc/'+p+'/cmdline','rb').read().decode().split(chr(0))"+chr(10)+" except OSError:pass"+chr(10)+"print(json.dumps(d))"
procs=json.loads(subprocess.check_output(['srun','--jobid='+str(job),'--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));targets=[]
for step,host,pid in found:
 cmd=procs.get(pid,[])
 if '--out'in cmd and cmd[cmd.index('--out')+1]==str(out)and str(b/'source-1526/project/experiments/control_v1/system_upper.py')in cmd:targets.append(dict(step=step,host=host,pid=pid,command=cmd))
assert len(targets)==1 and targets[0]['host']=='node4'
oldgraph=b/'r256-composition-453/topology/boundary-graph.json';assert a[a.index('--graph')+1]==str(oldgraph)and len(json.loads(oldgraph.read_text())['instances'])==345
log=out/'openroad-search/case-0/openroad.log';text=log.read_text();counts=list(map(int,re.findall(r'Number of violations = ([0-9]+)',text)));assert len(counts)>=5 and min(counts[-3:])>2000000
for relative in ['receipt.json','trees.json','router-output.txt','openroad-search/case-0/routed.odb','openroad-search/case-0/routed.def']:assert not(out/relative).exists()
record.mkdir();row=dict(time=time.time(),target=targets[0],job_details=details,spec_path=str(p),spec_sha256=sha(p),spec=s,original_record=str(b/'route-selection-102/sready1618-current-cugr-density-fullchain/tasks.json'),replacement_task=task,old_graph_sha256=sha(oldgraph),new_graph_sha256=sha(graph),old_full_log_sha256=sha(log),old_full_log_bytes=log.stat().st_size,old_completed_drc_counts=counts,last_log=text[-2000:],memory=dict(actual_available_gib=available,current_forecast=160,with_all_three_old_tasks_forecast=384,required_with_all_three=476.8,with_two_remaining_forecast=352,required_with_two_remaining=438.4),whole_system_qualified=False,reason='Onlyexactown16180/source1526old1470Sarbiter large-die fullsearch child retired toadmitactualreadyfresh1757nativeSTA224GiB. Existingmemoryguard rejects476.8GiB whileactualavailablebelowthat butabove438.4GiB; noforecast/guardreduction. Atleast5completednonzeroDRCcounts,last3>2million, nofinaloutputs; allsource/spec/logs/partials retained. Searchpriority/memory adjustment only, notproof futureiterations impossible. Parentallocations, old3751, current17170, pairedFastRoute16220, baseline15220, compiled12561/13121 andforeignR/otherjobs untouched. Node4temporarily3 independent16CPUtasks becauseactualmemorylimit; remainingnodesdynamicc96six16CPU. Allfinalgates unchanged.')
(record/'verified-before.json').write_text(json.dumps(row,indent=2));assert sha(p)==old['sha256']
for relative in ['receipt.json','trees.json','openroad-search/case-0/routed.odb','openroad-search/case-0/routed.def']:assert not(out/relative).exists()
subprocess.run(['scancel',targets[0]['step']],check=True)
(record/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,retired_exact_own_step=targets[0]['step'],memory=row['memory'],scope=row['reason']),indent=2));print(json.dumps(dict(passed=True,retired=targets[0]['step'],required_available_gib=438.4,actual_available_gib=available)))
