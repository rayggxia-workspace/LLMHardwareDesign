import subprocess,shlex
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');source=b/'source-1736';root=b/'r256-arbiter-composition-1757';record=b/'route-selection-102/sready1757-arbiter-qualified-scene'
assert not root.exists()and not record.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pg=b/'r256-arbiter-fixed-pg-1741/17380/delivery';assert json.loads((pg/'receipt.json').read_text())['passed']
configs=json.loads((b/'r256-composition-359/configurations.json').read_text());assert len(configs)==7
configs['control_s_arbiter_r7']=str(pg)
assert json.loads((b/'r256-arbiter-dispatch-source-audit-1737/receipt.json').read_text())['passed']
for folder in configs.values():assert json.loads((Path(folder)/'receipt.json').read_text())['passed']
root.mkdir();record.mkdir();rows=[];config=root/'configurations.json';config.write_text(json.dumps(configs,indent=2))
wrappers=root/'fixed-pg-wrappers';wrappers.mkdir();old=b/'s-ready-composition-01/1391/selected';m=json.loads((old/'physical.json').read_text());replace={'control_c','control_route','control_s_arbiter','control_status','control_reset_distribution'}
for top,row in m['leaves'].items():
 if top in replace:continue
 d=json.loads(Path(row['fixed_pg_delivery']['path']).read_text());assert d['passed'];(wrappers/top).symlink_to(Path(d['fixed_pg_receipt']).parent)
for top,folder in configs.items():
 d=json.loads((Path(folder)/'delivery.json').read_text());assert d['passed']and d['top']==top;(wrappers/top).symlink_to(Path(d['fixed_pg_receipt']).parent)
assert len(list(wrappers.iterdir()))==23
def add(folder,name,script,args,deps,out,memory=32):
 p=b/folder/'pending'/(name+'.json');assert not p.exists()and not out.exists()
 spec=dict(script=script,source_root=str(source),forecast_gib=memory,requires=list(map(str,deps)),args=list(map(str,args))+['--out',str(out)])
 t=p.with_suffix('.tmp');t.write_text(json.dumps(spec));t.rename(p);rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
sel=root/'selected';top=root/'topology';graph=top/'boundary-graph.json';manifest=sel/'physical.json'
add('dynamic-03/node5','00-a-sready1757-selection','select_leaves.py',['--physical',old/'physical.json','--functions',old/'functions.json','--r256-configurations',config],[Path(p)/'receipt.json'for p in configs.values()]+[b/'r256-arbiter-dispatch-source-audit-1737/receipt.json'],sel)
args=['--manifest',manifest,'--r256-scene','--link-padding-local-reset']
for n in ['macro_1','macro_2','macro_3','macro_4','macro_t','macro_r']:args+=['--link-native-output',n]
for n in ['s_port:dout','controller:task_data','controller:task_last']:args+=['--split-output-fanout',n]
add('dynamic-03/node5','00-b-sready1757-topology','topology.py',args,[sel/'receipt.json'],top)
add('dynamic-02/node3','00-c-sready1757-function','final_composition.py',['--manifest',sel/'functions.json','--physical',manifest,'--graph',graph,'--topology',top/'topology.json','--hierarchical'],[top/'receipt.json'],root/'function',128)
add('dynamic-05/node4','00-c-sready1757-native-sta','system_sta.py',['--manifest',manifest,'--functional-views',sel/'functions.json','--topology',top/'topology.json','--graph',graph,'--stitch-native-access','--audit-native-coverage'],[top/'receipt.json'],root/'native-sta',224)
add('dynamic-03/node5','00-c-sready1757-initial-placement','system_upper.py',['--manifest',manifest,'--graph',graph,'--pg-wrappers',wrappers,'--cap-lower-bound-only','--pin-aware-placement','--seed',17570,'--channel-gap-um',256],[top/'receipt.json'],root/'cap-initial',64)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,configurations_sha256=sha(config),whole_system_qualified=False,scope='Fresh23type selection uses onlyactuallyaccepted native17380+fixedPG1741Sarbiter3200um; other22qualified physical types unchanged. Regeneratecurrent453functionalgraph including267unusedLink8inputsresetbankbinding. Fresh actualfullhierarchicalprograms3initials andfreshnativeSPEF/RC coverage; actualnewarea/pins usedbyinitialplacement. Source1736 frozenfullaudit1737; noRTL/protocol/Rwork edits. Existingnode3/node5naturalvacancies, node4afterPG slots ready. NativeSTA224GiB includes128+96 internalcomponents; originalruntimeavailablememory andaggregateforecastguardmandatory, node4otherthreecurrentforecasts64+64+32=160, combined384 requires476.8GiB underoriginalguard. No foreigncancels orparentchanges. Diagnostic gates notwholequalification; newnecessary0 andfull7stage M11/M12/PG/XOR/threeRC300MHz stillmandatory.'),indent=2));print(json.dumps(dict(queued=len(rows),root=str(root),whole_system_qualified=False)))
'''
compile(q,'arbiter_scene1757','exec')
print(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=60).decode())
