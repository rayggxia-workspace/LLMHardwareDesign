import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-composition-1773'
for sub in ['wrapper','checks/physical','checks/timing','delivery']:
 p=b/'r256-arbiter-fixed-pg-1741/17380'/sub/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print('PG',sub,{k:d.get(k)for k in ['passed','native_pg_connected','minimum_setup_ns','minimum_hold_ns','fresh_native_extraction','native_leaf_qualified']if k in d})
for sub in ['selected','topology','function','native-sta','cap-initial','cap-initial-necessary/native-residual','cap-initial-necessary/native-pin-load','cap-candidates/17750','cap-necessary-1775/17750/native-pin-load']:
 p=root/sub
 if not p.exists():continue
 r=p/'receipt.json'
 if r.exists():
  d=json.loads(r.read_text());print(sub,{k:d.get(k)for k in ['passed','stage','minimum_setup_ns','minimum_hold_ns','physical_instances','actual_final_leaf_count','real_program_count']if k in d})
 for f in sorted(p.glob('*.log'),key=lambda f:f.stat().st_mtime)[-2:]:print(sub,f.name,f.read_text(errors='replace')[-380:])
for folder in ['dynamic-05/node4','dynamic-02/node3','dynamic-03/node5']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print(folder,{k:d[k]for k in ['active']})
 for f in p.glob('*1773*.log'):print('TASKLOG',f.name,f.read_text(errors='replace')[-2200:])
 for sub in ['results','commands']:
  for f in(p/sub).glob('*1773*'):
   d=json.loads(f.read_text());print(sub,f.name,{k:d[k]for k in ['returncode','admission']if k in d})
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
