import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d=json.loads((b/'route-selection-102/sready1717-hpwl-keepout-fullchain/tasks.json').read_text())
for r in d['tasks']:print(json.dumps(dict(path=r['path'],spec=r['spec'])))
print('CONFIG', (b/'r256-composition-453/acceptance-17170.json').read_text())
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
