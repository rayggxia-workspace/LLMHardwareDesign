"""Local metadata-only dependency watcher; all EDA stays in existing Slurm queues."""
from pathlib import Path
import subprocess,shlex,json,time,sys
h=Path(__file__).parent;b='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';journal=h/'control162-watch1777.jsonl'
assert not journal.exists()
def record(**row):
 row['time']=time.time()
 with journal.open('a',encoding='utf-8')as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
 print(json.dumps(row,ensure_ascii=False),flush=True)
def state(relative):
 q="from pathlib import Path;import json;p=Path("+repr(b+'/'+relative)+");r=Path("+repr(b+'/dynamic-03/node5/results/00-b-sready1773-topology.json')+");print(json.dumps(json.loads(p.read_text())['passed'] if p.exists()else (False if r.exists()and json.loads(r.read_text())['returncode']!=0 else None)))"
 return json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35))
def wait(relative):
 record(waiting=relative)
 for _ in range(360):
  try:s=state(relative)
  except (subprocess.SubprocessError,OSError)as e:
   record(connection_retry=type(e).__name__);time.sleep(30);continue
  if s is False:raise RuntimeError('Actual dependency failed: '+relative)
  if s is True:record(passed=relative);return
  time.sleep(30)
 raise TimeoutError(relative)
try:
 wait('r256-arbiter-composition-1773/topology/receipt.json')
 p=h/'control162-refine1775.py';record(dispatch=str(p));subprocess.run([sys.executable,str(p)],check=True)
 record(completed=True,scope='Freshselection/topology/function/nativeSTA/initialplacement andnative-aware successors queued; nofullcompositionpassclaimed')
except BaseException as e:
 record(failed=True,error=str(e));raise
