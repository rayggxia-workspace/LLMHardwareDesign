import pya
v=pya.LayoutView()
v.load_layout('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-fixed-pg-1741/17380/delivery/6_final.gds',0)
v.max_hier()
v.add_missing_layers()
v.zoom_fit()
v.save_image('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-fixed-pg-1741/17380/delivery/layout.png',1600,1600)
