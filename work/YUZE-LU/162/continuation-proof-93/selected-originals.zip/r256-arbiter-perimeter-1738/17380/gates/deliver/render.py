import pya
v=pya.LayoutView()
v.load_layout('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-perimeter-1738/17380/gates/deliver/6_final.gds',0)
v.max_hier()
v.add_missing_layers()
v.zoom_fit()
v.save_image('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-perimeter-1738/17380/gates/deliver/layout.png',1600,1600)
