module projection_probe(input clk,d,output q,y); wire t; LOGIC0_X1 constant_before(.Z(t)); XOR2_X1 g(.A(d),.B(t),.Z(y)); DFF_X1 u0(.CK(clk),.D(d),.Q(q)); endmodule
