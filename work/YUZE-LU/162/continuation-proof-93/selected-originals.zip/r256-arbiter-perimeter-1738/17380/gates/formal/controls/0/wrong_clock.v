module projection_probe(input clk,d,output q,y); wire t; LOGIC0_X1 constant_after(.Z(t)); XOR2_X1 g(.A(d),.B(t),.Z(y)); DFF_X2 u0(.CK(d),.D(d),.Q(q)); ANTENNA_X1 protection(.A(d)); endmodule
