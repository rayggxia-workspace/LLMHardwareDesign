module formal_probe(input clk,d,output q); DFF_X1 u0(.CK(clk),.D(1'b0),.Q(q)); endmodule
