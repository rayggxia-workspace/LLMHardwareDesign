read_liberty {/OpenROAD-flow-scripts/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.tech.lef}
read_lef {/OpenROAD-flow-scripts/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef}
read_verilog {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-perimeter-1738/17380/gates/physical/controls/sta/bad-setup/probe.v}
link_design sta_probe
write_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-perimeter-1738/17380/gates/physical/controls/sta/bad-setup/probe.odb}
