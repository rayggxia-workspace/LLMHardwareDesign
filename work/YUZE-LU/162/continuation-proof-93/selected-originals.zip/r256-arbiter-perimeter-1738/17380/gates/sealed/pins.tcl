set planned_pins [dict create]
dict set planned_pins {addr[0]} 1
place_pin -pin_name {addr[0]} -layer metal10 -location {800.095 24.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[1]} 1
place_pin -pin_name {addr[1]} -layer metal10 -location {804.095 28.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[2]} 1
place_pin -pin_name {addr[2]} -layer metal10 -location {800.095 32.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[3]} 1
place_pin -pin_name {addr[3]} -layer metal10 -location {804.095 36.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[4]} 1
place_pin -pin_name {addr[4]} -layer metal10 -location {800.095 40.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[5]} 1
place_pin -pin_name {addr[5]} -layer metal10 -location {804.095 44.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[6]} 1
place_pin -pin_name {addr[6]} -layer metal10 -location {800.095 48.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[7]} 1
place_pin -pin_name {addr[7]} -layer metal10 -location {804.095 52.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[8]} 1
place_pin -pin_name {addr[8]} -layer metal10 -location {800.095 56.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[9]} 1
place_pin -pin_name {addr[9]} -layer metal10 -location {804.095 60.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[10]} 1
place_pin -pin_name {addr[10]} -layer metal10 -location {800.095 64.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[11]} 1
place_pin -pin_name {addr[11]} -layer metal10 -location {804.095 68.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[12]} 1
place_pin -pin_name {addr[12]} -layer metal10 -location {800.095 72.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[13]} 1
place_pin -pin_name {addr[13]} -layer metal10 -location {804.095 76.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[14]} 1
place_pin -pin_name {addr[14]} -layer metal10 -location {800.095 80.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[15]} 1
place_pin -pin_name {addr[15]} -layer metal10 -location {804.095 84.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[16]} 1
place_pin -pin_name {addr[16]} -layer metal10 -location {2400.095 24.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[17]} 1
place_pin -pin_name {addr[17]} -layer metal10 -location {2396.095 28.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[18]} 1
place_pin -pin_name {addr[18]} -layer metal10 -location {2400.095 32.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[19]} 1
place_pin -pin_name {addr[19]} -layer metal10 -location {2396.095 36.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[20]} 1
place_pin -pin_name {addr[20]} -layer metal10 -location {2400.095 40.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[21]} 1
place_pin -pin_name {addr[21]} -layer metal10 -location {2396.095 44.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[22]} 1
place_pin -pin_name {addr[22]} -layer metal10 -location {2400.095 48.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[23]} 1
place_pin -pin_name {addr[23]} -layer metal10 -location {2396.095 52.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[24]} 1
place_pin -pin_name {addr[24]} -layer metal10 -location {2400.095 56.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[25]} 1
place_pin -pin_name {addr[25]} -layer metal10 -location {2396.095 60.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[26]} 1
place_pin -pin_name {addr[26]} -layer metal10 -location {2400.095 64.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[27]} 1
place_pin -pin_name {addr[27]} -layer metal10 -location {2396.095 68.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[28]} 1
place_pin -pin_name {addr[28]} -layer metal10 -location {2400.095 72.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[29]} 1
place_pin -pin_name {addr[29]} -layer metal10 -location {2396.095 76.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[30]} 1
place_pin -pin_name {addr[30]} -layer metal10 -location {2400.095 80.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[31]} 1
place_pin -pin_name {addr[31]} -layer metal10 -location {2396.095 84.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[32]} 1
place_pin -pin_name {addr[32]} -layer metal10 -location {24.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[33]} 1
place_pin -pin_name {addr[33]} -layer metal10 -location {28.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[34]} 1
place_pin -pin_name {addr[34]} -layer metal10 -location {32.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[35]} 1
place_pin -pin_name {addr[35]} -layer metal10 -location {36.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[36]} 1
place_pin -pin_name {addr[36]} -layer metal10 -location {40.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[37]} 1
place_pin -pin_name {addr[37]} -layer metal10 -location {44.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[38]} 1
place_pin -pin_name {addr[38]} -layer metal10 -location {48.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[39]} 1
place_pin -pin_name {addr[39]} -layer metal10 -location {52.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[40]} 1
place_pin -pin_name {addr[40]} -layer metal10 -location {56.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[41]} 1
place_pin -pin_name {addr[41]} -layer metal10 -location {60.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[42]} 1
place_pin -pin_name {addr[42]} -layer metal10 -location {64.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[43]} 1
place_pin -pin_name {addr[43]} -layer metal10 -location {68.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[44]} 1
place_pin -pin_name {addr[44]} -layer metal10 -location {72.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[45]} 1
place_pin -pin_name {addr[45]} -layer metal10 -location {76.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[46]} 1
place_pin -pin_name {addr[46]} -layer metal10 -location {80.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[47]} 1
place_pin -pin_name {addr[47]} -layer metal10 -location {84.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[48]} 1
place_pin -pin_name {addr[48]} -layer metal10 -location {24.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[49]} 1
place_pin -pin_name {addr[49]} -layer metal10 -location {28.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[50]} 1
place_pin -pin_name {addr[50]} -layer metal10 -location {32.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[51]} 1
place_pin -pin_name {addr[51]} -layer metal10 -location {36.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[52]} 1
place_pin -pin_name {addr[52]} -layer metal10 -location {40.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[53]} 1
place_pin -pin_name {addr[53]} -layer metal10 -location {44.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[54]} 1
place_pin -pin_name {addr[54]} -layer metal10 -location {48.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[55]} 1
place_pin -pin_name {addr[55]} -layer metal10 -location {52.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[56]} 1
place_pin -pin_name {addr[56]} -layer metal10 -location {56.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[57]} 1
place_pin -pin_name {addr[57]} -layer metal10 -location {60.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[58]} 1
place_pin -pin_name {addr[58]} -layer metal10 -location {64.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[59]} 1
place_pin -pin_name {addr[59]} -layer metal10 -location {68.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[60]} 1
place_pin -pin_name {addr[60]} -layer metal10 -location {72.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[61]} 1
place_pin -pin_name {addr[61]} -layer metal10 -location {76.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[62]} 1
place_pin -pin_name {addr[62]} -layer metal10 -location {80.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[63]} 1
place_pin -pin_name {addr[63]} -layer metal10 -location {84.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[64]} 1
place_pin -pin_name {addr[64]} -layer metal10 -location {88.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[65]} 1
place_pin -pin_name {addr[65]} -layer metal10 -location {92.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[66]} 1
place_pin -pin_name {addr[66]} -layer metal10 -location {96.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[67]} 1
place_pin -pin_name {addr[67]} -layer metal10 -location {100.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[68]} 1
place_pin -pin_name {addr[68]} -layer metal10 -location {104.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {addr[69]} 1
place_pin -pin_name {addr[69]} -layer metal10 -location {108.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {clk} 1
place_pin -pin_name {clk} -layer metal10 -location {88.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[0]} 1
place_pin -pin_name {din[0]} -layer metal10 -location {800.095 88.07} -pin_size {2.0 2.0}
dict set planned_pins {din[1]} 1
place_pin -pin_name {din[1]} -layer metal10 -location {804.095 92.07} -pin_size {2.0 2.0}
dict set planned_pins {din[2]} 1
place_pin -pin_name {din[2]} -layer metal10 -location {800.095 96.07} -pin_size {2.0 2.0}
dict set planned_pins {din[3]} 1
place_pin -pin_name {din[3]} -layer metal10 -location {804.095 100.07} -pin_size {2.0 2.0}
dict set planned_pins {din[4]} 1
place_pin -pin_name {din[4]} -layer metal10 -location {800.095 104.07} -pin_size {2.0 2.0}
dict set planned_pins {din[5]} 1
place_pin -pin_name {din[5]} -layer metal10 -location {804.095 108.07} -pin_size {2.0 2.0}
dict set planned_pins {din[6]} 1
place_pin -pin_name {din[6]} -layer metal10 -location {800.095 112.07} -pin_size {2.0 2.0}
dict set planned_pins {din[7]} 1
place_pin -pin_name {din[7]} -layer metal10 -location {804.095 116.07} -pin_size {2.0 2.0}
dict set planned_pins {din[8]} 1
place_pin -pin_name {din[8]} -layer metal10 -location {800.095 120.07} -pin_size {2.0 2.0}
dict set planned_pins {din[9]} 1
place_pin -pin_name {din[9]} -layer metal10 -location {804.095 124.07} -pin_size {2.0 2.0}
dict set planned_pins {din[10]} 1
place_pin -pin_name {din[10]} -layer metal10 -location {800.095 128.07} -pin_size {2.0 2.0}
dict set planned_pins {din[11]} 1
place_pin -pin_name {din[11]} -layer metal10 -location {804.095 132.07} -pin_size {2.0 2.0}
dict set planned_pins {din[12]} 1
place_pin -pin_name {din[12]} -layer metal10 -location {800.095 136.07} -pin_size {2.0 2.0}
dict set planned_pins {din[13]} 1
place_pin -pin_name {din[13]} -layer metal10 -location {804.095 140.07} -pin_size {2.0 2.0}
dict set planned_pins {din[14]} 1
place_pin -pin_name {din[14]} -layer metal10 -location {800.095 144.07} -pin_size {2.0 2.0}
dict set planned_pins {din[15]} 1
place_pin -pin_name {din[15]} -layer metal10 -location {804.095 148.07} -pin_size {2.0 2.0}
dict set planned_pins {din[16]} 1
place_pin -pin_name {din[16]} -layer metal10 -location {2400.095 88.07} -pin_size {2.0 2.0}
dict set planned_pins {din[17]} 1
place_pin -pin_name {din[17]} -layer metal10 -location {2396.095 92.07} -pin_size {2.0 2.0}
dict set planned_pins {din[18]} 1
place_pin -pin_name {din[18]} -layer metal10 -location {2400.095 96.07} -pin_size {2.0 2.0}
dict set planned_pins {din[19]} 1
place_pin -pin_name {din[19]} -layer metal10 -location {2396.095 100.07} -pin_size {2.0 2.0}
dict set planned_pins {din[20]} 1
place_pin -pin_name {din[20]} -layer metal10 -location {2400.095 104.07} -pin_size {2.0 2.0}
dict set planned_pins {din[21]} 1
place_pin -pin_name {din[21]} -layer metal10 -location {2396.095 108.07} -pin_size {2.0 2.0}
dict set planned_pins {din[22]} 1
place_pin -pin_name {din[22]} -layer metal10 -location {2400.095 112.07} -pin_size {2.0 2.0}
dict set planned_pins {din[23]} 1
place_pin -pin_name {din[23]} -layer metal10 -location {2396.095 116.07} -pin_size {2.0 2.0}
dict set planned_pins {din[24]} 1
place_pin -pin_name {din[24]} -layer metal10 -location {2400.095 120.07} -pin_size {2.0 2.0}
dict set planned_pins {din[25]} 1
place_pin -pin_name {din[25]} -layer metal10 -location {2396.095 124.07} -pin_size {2.0 2.0}
dict set planned_pins {din[26]} 1
place_pin -pin_name {din[26]} -layer metal10 -location {2400.095 128.07} -pin_size {2.0 2.0}
dict set planned_pins {din[27]} 1
place_pin -pin_name {din[27]} -layer metal10 -location {2396.095 132.07} -pin_size {2.0 2.0}
dict set planned_pins {din[28]} 1
place_pin -pin_name {din[28]} -layer metal10 -location {2400.095 136.07} -pin_size {2.0 2.0}
dict set planned_pins {din[29]} 1
place_pin -pin_name {din[29]} -layer metal10 -location {2396.095 140.07} -pin_size {2.0 2.0}
dict set planned_pins {din[30]} 1
place_pin -pin_name {din[30]} -layer metal10 -location {2400.095 144.07} -pin_size {2.0 2.0}
dict set planned_pins {din[31]} 1
place_pin -pin_name {din[31]} -layer metal10 -location {2396.095 148.07} -pin_size {2.0 2.0}
dict set planned_pins {din[32]} 1
place_pin -pin_name {din[32]} -layer metal10 -location {92.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[33]} 1
place_pin -pin_name {din[33]} -layer metal10 -location {96.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[34]} 1
place_pin -pin_name {din[34]} -layer metal10 -location {100.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[35]} 1
place_pin -pin_name {din[35]} -layer metal10 -location {104.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[36]} 1
place_pin -pin_name {din[36]} -layer metal10 -location {108.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[37]} 1
place_pin -pin_name {din[37]} -layer metal10 -location {112.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[38]} 1
place_pin -pin_name {din[38]} -layer metal10 -location {116.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[39]} 1
place_pin -pin_name {din[39]} -layer metal10 -location {120.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[40]} 1
place_pin -pin_name {din[40]} -layer metal10 -location {124.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[41]} 1
place_pin -pin_name {din[41]} -layer metal10 -location {128.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[42]} 1
place_pin -pin_name {din[42]} -layer metal10 -location {132.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[43]} 1
place_pin -pin_name {din[43]} -layer metal10 -location {136.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[44]} 1
place_pin -pin_name {din[44]} -layer metal10 -location {140.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[45]} 1
place_pin -pin_name {din[45]} -layer metal10 -location {144.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[46]} 1
place_pin -pin_name {din[46]} -layer metal10 -location {148.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[47]} 1
place_pin -pin_name {din[47]} -layer metal10 -location {152.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[48]} 1
place_pin -pin_name {din[48]} -layer metal10 -location {112.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[49]} 1
place_pin -pin_name {din[49]} -layer metal10 -location {116.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[50]} 1
place_pin -pin_name {din[50]} -layer metal10 -location {120.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[51]} 1
place_pin -pin_name {din[51]} -layer metal10 -location {124.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[52]} 1
place_pin -pin_name {din[52]} -layer metal10 -location {128.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[53]} 1
place_pin -pin_name {din[53]} -layer metal10 -location {132.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[54]} 1
place_pin -pin_name {din[54]} -layer metal10 -location {136.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[55]} 1
place_pin -pin_name {din[55]} -layer metal10 -location {140.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[56]} 1
place_pin -pin_name {din[56]} -layer metal10 -location {144.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[57]} 1
place_pin -pin_name {din[57]} -layer metal10 -location {148.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[58]} 1
place_pin -pin_name {din[58]} -layer metal10 -location {152.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[59]} 1
place_pin -pin_name {din[59]} -layer metal10 -location {156.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[60]} 1
place_pin -pin_name {din[60]} -layer metal10 -location {160.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[61]} 1
place_pin -pin_name {din[61]} -layer metal10 -location {164.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[62]} 1
place_pin -pin_name {din[62]} -layer metal10 -location {168.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[63]} 1
place_pin -pin_name {din[63]} -layer metal10 -location {172.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[64]} 1
place_pin -pin_name {din[64]} -layer metal10 -location {800.095 152.07} -pin_size {2.0 2.0}
dict set planned_pins {din[65]} 1
place_pin -pin_name {din[65]} -layer metal10 -location {804.095 156.07} -pin_size {2.0 2.0}
dict set planned_pins {din[66]} 1
place_pin -pin_name {din[66]} -layer metal10 -location {800.095 160.07} -pin_size {2.0 2.0}
dict set planned_pins {din[67]} 1
place_pin -pin_name {din[67]} -layer metal10 -location {804.095 164.07} -pin_size {2.0 2.0}
dict set planned_pins {din[68]} 1
place_pin -pin_name {din[68]} -layer metal10 -location {800.095 168.07} -pin_size {2.0 2.0}
dict set planned_pins {din[69]} 1
place_pin -pin_name {din[69]} -layer metal10 -location {804.095 172.07} -pin_size {2.0 2.0}
dict set planned_pins {din[70]} 1
place_pin -pin_name {din[70]} -layer metal10 -location {800.095 176.07} -pin_size {2.0 2.0}
dict set planned_pins {din[71]} 1
place_pin -pin_name {din[71]} -layer metal10 -location {804.095 180.07} -pin_size {2.0 2.0}
dict set planned_pins {din[72]} 1
place_pin -pin_name {din[72]} -layer metal10 -location {800.095 184.07} -pin_size {2.0 2.0}
dict set planned_pins {din[73]} 1
place_pin -pin_name {din[73]} -layer metal10 -location {804.095 188.07} -pin_size {2.0 2.0}
dict set planned_pins {din[74]} 1
place_pin -pin_name {din[74]} -layer metal10 -location {800.095 192.07} -pin_size {2.0 2.0}
dict set planned_pins {din[75]} 1
place_pin -pin_name {din[75]} -layer metal10 -location {804.095 196.07} -pin_size {2.0 2.0}
dict set planned_pins {din[76]} 1
place_pin -pin_name {din[76]} -layer metal10 -location {800.095 200.07} -pin_size {2.0 2.0}
dict set planned_pins {din[77]} 1
place_pin -pin_name {din[77]} -layer metal10 -location {804.095 204.07} -pin_size {2.0 2.0}
dict set planned_pins {din[78]} 1
place_pin -pin_name {din[78]} -layer metal10 -location {800.095 208.07} -pin_size {2.0 2.0}
dict set planned_pins {din[79]} 1
place_pin -pin_name {din[79]} -layer metal10 -location {804.095 212.07} -pin_size {2.0 2.0}
dict set planned_pins {din[80]} 1
place_pin -pin_name {din[80]} -layer metal10 -location {2400.095 152.07} -pin_size {2.0 2.0}
dict set planned_pins {din[81]} 1
place_pin -pin_name {din[81]} -layer metal10 -location {2396.095 156.07} -pin_size {2.0 2.0}
dict set planned_pins {din[82]} 1
place_pin -pin_name {din[82]} -layer metal10 -location {2400.095 160.07} -pin_size {2.0 2.0}
dict set planned_pins {din[83]} 1
place_pin -pin_name {din[83]} -layer metal10 -location {2396.095 164.07} -pin_size {2.0 2.0}
dict set planned_pins {din[84]} 1
place_pin -pin_name {din[84]} -layer metal10 -location {2400.095 168.07} -pin_size {2.0 2.0}
dict set planned_pins {din[85]} 1
place_pin -pin_name {din[85]} -layer metal10 -location {2396.095 172.07} -pin_size {2.0 2.0}
dict set planned_pins {din[86]} 1
place_pin -pin_name {din[86]} -layer metal10 -location {2400.095 176.07} -pin_size {2.0 2.0}
dict set planned_pins {din[87]} 1
place_pin -pin_name {din[87]} -layer metal10 -location {2396.095 180.07} -pin_size {2.0 2.0}
dict set planned_pins {din[88]} 1
place_pin -pin_name {din[88]} -layer metal10 -location {2400.095 184.07} -pin_size {2.0 2.0}
dict set planned_pins {din[89]} 1
place_pin -pin_name {din[89]} -layer metal10 -location {2396.095 188.07} -pin_size {2.0 2.0}
dict set planned_pins {din[90]} 1
place_pin -pin_name {din[90]} -layer metal10 -location {2400.095 192.07} -pin_size {2.0 2.0}
dict set planned_pins {din[91]} 1
place_pin -pin_name {din[91]} -layer metal10 -location {2396.095 196.07} -pin_size {2.0 2.0}
dict set planned_pins {din[92]} 1
place_pin -pin_name {din[92]} -layer metal10 -location {2400.095 200.07} -pin_size {2.0 2.0}
dict set planned_pins {din[93]} 1
place_pin -pin_name {din[93]} -layer metal10 -location {2396.095 204.07} -pin_size {2.0 2.0}
dict set planned_pins {din[94]} 1
place_pin -pin_name {din[94]} -layer metal10 -location {2400.095 208.07} -pin_size {2.0 2.0}
dict set planned_pins {din[95]} 1
place_pin -pin_name {din[95]} -layer metal10 -location {2396.095 212.07} -pin_size {2.0 2.0}
dict set planned_pins {din[96]} 1
place_pin -pin_name {din[96]} -layer metal10 -location {156.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[97]} 1
place_pin -pin_name {din[97]} -layer metal10 -location {160.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[98]} 1
place_pin -pin_name {din[98]} -layer metal10 -location {164.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[99]} 1
place_pin -pin_name {din[99]} -layer metal10 -location {168.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[100]} 1
place_pin -pin_name {din[100]} -layer metal10 -location {172.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[101]} 1
place_pin -pin_name {din[101]} -layer metal10 -location {176.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[102]} 1
place_pin -pin_name {din[102]} -layer metal10 -location {180.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[103]} 1
place_pin -pin_name {din[103]} -layer metal10 -location {184.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[104]} 1
place_pin -pin_name {din[104]} -layer metal10 -location {188.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[105]} 1
place_pin -pin_name {din[105]} -layer metal10 -location {192.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[106]} 1
place_pin -pin_name {din[106]} -layer metal10 -location {196.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[107]} 1
place_pin -pin_name {din[107]} -layer metal10 -location {200.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[108]} 1
place_pin -pin_name {din[108]} -layer metal10 -location {204.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[109]} 1
place_pin -pin_name {din[109]} -layer metal10 -location {208.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[110]} 1
place_pin -pin_name {din[110]} -layer metal10 -location {212.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[111]} 1
place_pin -pin_name {din[111]} -layer metal10 -location {216.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[112]} 1
place_pin -pin_name {din[112]} -layer metal10 -location {176.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[113]} 1
place_pin -pin_name {din[113]} -layer metal10 -location {180.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[114]} 1
place_pin -pin_name {din[114]} -layer metal10 -location {184.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[115]} 1
place_pin -pin_name {din[115]} -layer metal10 -location {188.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[116]} 1
place_pin -pin_name {din[116]} -layer metal10 -location {192.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[117]} 1
place_pin -pin_name {din[117]} -layer metal10 -location {196.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[118]} 1
place_pin -pin_name {din[118]} -layer metal10 -location {200.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[119]} 1
place_pin -pin_name {din[119]} -layer metal10 -location {204.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[120]} 1
place_pin -pin_name {din[120]} -layer metal10 -location {208.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[121]} 1
place_pin -pin_name {din[121]} -layer metal10 -location {212.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[122]} 1
place_pin -pin_name {din[122]} -layer metal10 -location {216.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[123]} 1
place_pin -pin_name {din[123]} -layer metal10 -location {220.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[124]} 1
place_pin -pin_name {din[124]} -layer metal10 -location {224.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[125]} 1
place_pin -pin_name {din[125]} -layer metal10 -location {228.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[126]} 1
place_pin -pin_name {din[126]} -layer metal10 -location {232.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[127]} 1
place_pin -pin_name {din[127]} -layer metal10 -location {236.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[128]} 1
place_pin -pin_name {din[128]} -layer metal10 -location {800.095 216.07} -pin_size {2.0 2.0}
dict set planned_pins {din[129]} 1
place_pin -pin_name {din[129]} -layer metal10 -location {804.095 220.07} -pin_size {2.0 2.0}
dict set planned_pins {din[130]} 1
place_pin -pin_name {din[130]} -layer metal10 -location {800.095 224.07} -pin_size {2.0 2.0}
dict set planned_pins {din[131]} 1
place_pin -pin_name {din[131]} -layer metal10 -location {804.095 228.07} -pin_size {2.0 2.0}
dict set planned_pins {din[132]} 1
place_pin -pin_name {din[132]} -layer metal10 -location {800.095 232.07} -pin_size {2.0 2.0}
dict set planned_pins {din[133]} 1
place_pin -pin_name {din[133]} -layer metal10 -location {804.095 236.07} -pin_size {2.0 2.0}
dict set planned_pins {din[134]} 1
place_pin -pin_name {din[134]} -layer metal10 -location {800.095 240.07} -pin_size {2.0 2.0}
dict set planned_pins {din[135]} 1
place_pin -pin_name {din[135]} -layer metal10 -location {804.095 244.07} -pin_size {2.0 2.0}
dict set planned_pins {din[136]} 1
place_pin -pin_name {din[136]} -layer metal10 -location {800.095 248.07} -pin_size {2.0 2.0}
dict set planned_pins {din[137]} 1
place_pin -pin_name {din[137]} -layer metal10 -location {804.095 252.07} -pin_size {2.0 2.0}
dict set planned_pins {din[138]} 1
place_pin -pin_name {din[138]} -layer metal10 -location {800.095 256.07} -pin_size {2.0 2.0}
dict set planned_pins {din[139]} 1
place_pin -pin_name {din[139]} -layer metal10 -location {804.095 260.07} -pin_size {2.0 2.0}
dict set planned_pins {din[140]} 1
place_pin -pin_name {din[140]} -layer metal10 -location {800.095 264.07} -pin_size {2.0 2.0}
dict set planned_pins {din[141]} 1
place_pin -pin_name {din[141]} -layer metal10 -location {804.095 268.07} -pin_size {2.0 2.0}
dict set planned_pins {din[142]} 1
place_pin -pin_name {din[142]} -layer metal10 -location {800.095 272.07} -pin_size {2.0 2.0}
dict set planned_pins {din[143]} 1
place_pin -pin_name {din[143]} -layer metal10 -location {804.095 276.07} -pin_size {2.0 2.0}
dict set planned_pins {din[144]} 1
place_pin -pin_name {din[144]} -layer metal10 -location {2400.095 216.07} -pin_size {2.0 2.0}
dict set planned_pins {din[145]} 1
place_pin -pin_name {din[145]} -layer metal10 -location {2396.095 220.07} -pin_size {2.0 2.0}
dict set planned_pins {din[146]} 1
place_pin -pin_name {din[146]} -layer metal10 -location {2400.095 224.07} -pin_size {2.0 2.0}
dict set planned_pins {din[147]} 1
place_pin -pin_name {din[147]} -layer metal10 -location {2396.095 228.07} -pin_size {2.0 2.0}
dict set planned_pins {din[148]} 1
place_pin -pin_name {din[148]} -layer metal10 -location {2400.095 232.07} -pin_size {2.0 2.0}
dict set planned_pins {din[149]} 1
place_pin -pin_name {din[149]} -layer metal10 -location {2396.095 236.07} -pin_size {2.0 2.0}
dict set planned_pins {din[150]} 1
place_pin -pin_name {din[150]} -layer metal10 -location {2400.095 240.07} -pin_size {2.0 2.0}
dict set planned_pins {din[151]} 1
place_pin -pin_name {din[151]} -layer metal10 -location {2396.095 244.07} -pin_size {2.0 2.0}
dict set planned_pins {din[152]} 1
place_pin -pin_name {din[152]} -layer metal10 -location {2400.095 248.07} -pin_size {2.0 2.0}
dict set planned_pins {din[153]} 1
place_pin -pin_name {din[153]} -layer metal10 -location {2396.095 252.07} -pin_size {2.0 2.0}
dict set planned_pins {din[154]} 1
place_pin -pin_name {din[154]} -layer metal10 -location {2400.095 256.07} -pin_size {2.0 2.0}
dict set planned_pins {din[155]} 1
place_pin -pin_name {din[155]} -layer metal10 -location {2396.095 260.07} -pin_size {2.0 2.0}
dict set planned_pins {din[156]} 1
place_pin -pin_name {din[156]} -layer metal10 -location {2400.095 264.07} -pin_size {2.0 2.0}
dict set planned_pins {din[157]} 1
place_pin -pin_name {din[157]} -layer metal10 -location {2396.095 268.07} -pin_size {2.0 2.0}
dict set planned_pins {din[158]} 1
place_pin -pin_name {din[158]} -layer metal10 -location {2400.095 272.07} -pin_size {2.0 2.0}
dict set planned_pins {din[159]} 1
place_pin -pin_name {din[159]} -layer metal10 -location {2396.095 276.07} -pin_size {2.0 2.0}
dict set planned_pins {din[160]} 1
place_pin -pin_name {din[160]} -layer metal10 -location {220.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[161]} 1
place_pin -pin_name {din[161]} -layer metal10 -location {224.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[162]} 1
place_pin -pin_name {din[162]} -layer metal10 -location {228.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[163]} 1
place_pin -pin_name {din[163]} -layer metal10 -location {232.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[164]} 1
place_pin -pin_name {din[164]} -layer metal10 -location {236.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[165]} 1
place_pin -pin_name {din[165]} -layer metal10 -location {240.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[166]} 1
place_pin -pin_name {din[166]} -layer metal10 -location {244.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[167]} 1
place_pin -pin_name {din[167]} -layer metal10 -location {248.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[168]} 1
place_pin -pin_name {din[168]} -layer metal10 -location {252.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[169]} 1
place_pin -pin_name {din[169]} -layer metal10 -location {256.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[170]} 1
place_pin -pin_name {din[170]} -layer metal10 -location {260.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[171]} 1
place_pin -pin_name {din[171]} -layer metal10 -location {264.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[172]} 1
place_pin -pin_name {din[172]} -layer metal10 -location {268.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[173]} 1
place_pin -pin_name {din[173]} -layer metal10 -location {272.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[174]} 1
place_pin -pin_name {din[174]} -layer metal10 -location {276.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[175]} 1
place_pin -pin_name {din[175]} -layer metal10 -location {280.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[176]} 1
place_pin -pin_name {din[176]} -layer metal10 -location {240.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[177]} 1
place_pin -pin_name {din[177]} -layer metal10 -location {244.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[178]} 1
place_pin -pin_name {din[178]} -layer metal10 -location {248.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[179]} 1
place_pin -pin_name {din[179]} -layer metal10 -location {252.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[180]} 1
place_pin -pin_name {din[180]} -layer metal10 -location {256.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[181]} 1
place_pin -pin_name {din[181]} -layer metal10 -location {260.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[182]} 1
place_pin -pin_name {din[182]} -layer metal10 -location {264.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[183]} 1
place_pin -pin_name {din[183]} -layer metal10 -location {268.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[184]} 1
place_pin -pin_name {din[184]} -layer metal10 -location {272.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[185]} 1
place_pin -pin_name {din[185]} -layer metal10 -location {276.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[186]} 1
place_pin -pin_name {din[186]} -layer metal10 -location {280.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[187]} 1
place_pin -pin_name {din[187]} -layer metal10 -location {284.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[188]} 1
place_pin -pin_name {din[188]} -layer metal10 -location {288.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[189]} 1
place_pin -pin_name {din[189]} -layer metal10 -location {292.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[190]} 1
place_pin -pin_name {din[190]} -layer metal10 -location {296.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[191]} 1
place_pin -pin_name {din[191]} -layer metal10 -location {300.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[192]} 1
place_pin -pin_name {din[192]} -layer metal10 -location {800.095 280.07} -pin_size {2.0 2.0}
dict set planned_pins {din[193]} 1
place_pin -pin_name {din[193]} -layer metal10 -location {804.095 284.07} -pin_size {2.0 2.0}
dict set planned_pins {din[194]} 1
place_pin -pin_name {din[194]} -layer metal10 -location {800.095 288.07} -pin_size {2.0 2.0}
dict set planned_pins {din[195]} 1
place_pin -pin_name {din[195]} -layer metal10 -location {804.095 292.07} -pin_size {2.0 2.0}
dict set planned_pins {din[196]} 1
place_pin -pin_name {din[196]} -layer metal10 -location {800.095 296.07} -pin_size {2.0 2.0}
dict set planned_pins {din[197]} 1
place_pin -pin_name {din[197]} -layer metal10 -location {804.095 300.07} -pin_size {2.0 2.0}
dict set planned_pins {din[198]} 1
place_pin -pin_name {din[198]} -layer metal10 -location {800.095 304.07} -pin_size {2.0 2.0}
dict set planned_pins {din[199]} 1
place_pin -pin_name {din[199]} -layer metal10 -location {804.095 308.07} -pin_size {2.0 2.0}
dict set planned_pins {din[200]} 1
place_pin -pin_name {din[200]} -layer metal10 -location {800.095 312.07} -pin_size {2.0 2.0}
dict set planned_pins {din[201]} 1
place_pin -pin_name {din[201]} -layer metal10 -location {804.095 316.07} -pin_size {2.0 2.0}
dict set planned_pins {din[202]} 1
place_pin -pin_name {din[202]} -layer metal10 -location {800.095 320.07} -pin_size {2.0 2.0}
dict set planned_pins {din[203]} 1
place_pin -pin_name {din[203]} -layer metal10 -location {804.095 324.07} -pin_size {2.0 2.0}
dict set planned_pins {din[204]} 1
place_pin -pin_name {din[204]} -layer metal10 -location {800.095 328.07} -pin_size {2.0 2.0}
dict set planned_pins {din[205]} 1
place_pin -pin_name {din[205]} -layer metal10 -location {804.095 332.07} -pin_size {2.0 2.0}
dict set planned_pins {din[206]} 1
place_pin -pin_name {din[206]} -layer metal10 -location {800.095 336.07} -pin_size {2.0 2.0}
dict set planned_pins {din[207]} 1
place_pin -pin_name {din[207]} -layer metal10 -location {804.095 340.07} -pin_size {2.0 2.0}
dict set planned_pins {din[208]} 1
place_pin -pin_name {din[208]} -layer metal10 -location {2400.095 280.07} -pin_size {2.0 2.0}
dict set planned_pins {din[209]} 1
place_pin -pin_name {din[209]} -layer metal10 -location {2396.095 284.07} -pin_size {2.0 2.0}
dict set planned_pins {din[210]} 1
place_pin -pin_name {din[210]} -layer metal10 -location {2400.095 288.07} -pin_size {2.0 2.0}
dict set planned_pins {din[211]} 1
place_pin -pin_name {din[211]} -layer metal10 -location {2396.095 292.07} -pin_size {2.0 2.0}
dict set planned_pins {din[212]} 1
place_pin -pin_name {din[212]} -layer metal10 -location {2400.095 296.07} -pin_size {2.0 2.0}
dict set planned_pins {din[213]} 1
place_pin -pin_name {din[213]} -layer metal10 -location {2396.095 300.07} -pin_size {2.0 2.0}
dict set planned_pins {din[214]} 1
place_pin -pin_name {din[214]} -layer metal10 -location {2400.095 304.07} -pin_size {2.0 2.0}
dict set planned_pins {din[215]} 1
place_pin -pin_name {din[215]} -layer metal10 -location {2396.095 308.07} -pin_size {2.0 2.0}
dict set planned_pins {din[216]} 1
place_pin -pin_name {din[216]} -layer metal10 -location {2400.095 312.07} -pin_size {2.0 2.0}
dict set planned_pins {din[217]} 1
place_pin -pin_name {din[217]} -layer metal10 -location {2396.095 316.07} -pin_size {2.0 2.0}
dict set planned_pins {din[218]} 1
place_pin -pin_name {din[218]} -layer metal10 -location {2400.095 320.07} -pin_size {2.0 2.0}
dict set planned_pins {din[219]} 1
place_pin -pin_name {din[219]} -layer metal10 -location {2396.095 324.07} -pin_size {2.0 2.0}
dict set planned_pins {din[220]} 1
place_pin -pin_name {din[220]} -layer metal10 -location {2400.095 328.07} -pin_size {2.0 2.0}
dict set planned_pins {din[221]} 1
place_pin -pin_name {din[221]} -layer metal10 -location {2396.095 332.07} -pin_size {2.0 2.0}
dict set planned_pins {din[222]} 1
place_pin -pin_name {din[222]} -layer metal10 -location {2400.095 336.07} -pin_size {2.0 2.0}
dict set planned_pins {din[223]} 1
place_pin -pin_name {din[223]} -layer metal10 -location {2396.095 340.07} -pin_size {2.0 2.0}
dict set planned_pins {din[224]} 1
place_pin -pin_name {din[224]} -layer metal10 -location {284.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[225]} 1
place_pin -pin_name {din[225]} -layer metal10 -location {288.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[226]} 1
place_pin -pin_name {din[226]} -layer metal10 -location {292.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[227]} 1
place_pin -pin_name {din[227]} -layer metal10 -location {296.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[228]} 1
place_pin -pin_name {din[228]} -layer metal10 -location {300.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[229]} 1
place_pin -pin_name {din[229]} -layer metal10 -location {304.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[230]} 1
place_pin -pin_name {din[230]} -layer metal10 -location {308.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[231]} 1
place_pin -pin_name {din[231]} -layer metal10 -location {312.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[232]} 1
place_pin -pin_name {din[232]} -layer metal10 -location {316.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[233]} 1
place_pin -pin_name {din[233]} -layer metal10 -location {320.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[234]} 1
place_pin -pin_name {din[234]} -layer metal10 -location {324.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[235]} 1
place_pin -pin_name {din[235]} -layer metal10 -location {328.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[236]} 1
place_pin -pin_name {din[236]} -layer metal10 -location {332.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[237]} 1
place_pin -pin_name {din[237]} -layer metal10 -location {336.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[238]} 1
place_pin -pin_name {din[238]} -layer metal10 -location {340.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[239]} 1
place_pin -pin_name {din[239]} -layer metal10 -location {344.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[240]} 1
place_pin -pin_name {din[240]} -layer metal10 -location {304.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[241]} 1
place_pin -pin_name {din[241]} -layer metal10 -location {308.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[242]} 1
place_pin -pin_name {din[242]} -layer metal10 -location {312.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[243]} 1
place_pin -pin_name {din[243]} -layer metal10 -location {316.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[244]} 1
place_pin -pin_name {din[244]} -layer metal10 -location {320.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[245]} 1
place_pin -pin_name {din[245]} -layer metal10 -location {324.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[246]} 1
place_pin -pin_name {din[246]} -layer metal10 -location {328.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[247]} 1
place_pin -pin_name {din[247]} -layer metal10 -location {332.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[248]} 1
place_pin -pin_name {din[248]} -layer metal10 -location {336.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[249]} 1
place_pin -pin_name {din[249]} -layer metal10 -location {340.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[250]} 1
place_pin -pin_name {din[250]} -layer metal10 -location {344.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[251]} 1
place_pin -pin_name {din[251]} -layer metal10 -location {348.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[252]} 1
place_pin -pin_name {din[252]} -layer metal10 -location {352.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[253]} 1
place_pin -pin_name {din[253]} -layer metal10 -location {356.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[254]} 1
place_pin -pin_name {din[254]} -layer metal10 -location {360.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[255]} 1
place_pin -pin_name {din[255]} -layer metal10 -location {364.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[256]} 1
place_pin -pin_name {din[256]} -layer metal10 -location {800.095 344.07} -pin_size {2.0 2.0}
dict set planned_pins {din[257]} 1
place_pin -pin_name {din[257]} -layer metal10 -location {804.095 348.07} -pin_size {2.0 2.0}
dict set planned_pins {din[258]} 1
place_pin -pin_name {din[258]} -layer metal10 -location {800.095 352.07} -pin_size {2.0 2.0}
dict set planned_pins {din[259]} 1
place_pin -pin_name {din[259]} -layer metal10 -location {804.095 356.07} -pin_size {2.0 2.0}
dict set planned_pins {din[260]} 1
place_pin -pin_name {din[260]} -layer metal10 -location {800.095 360.07} -pin_size {2.0 2.0}
dict set planned_pins {din[261]} 1
place_pin -pin_name {din[261]} -layer metal10 -location {804.095 364.07} -pin_size {2.0 2.0}
dict set planned_pins {din[262]} 1
place_pin -pin_name {din[262]} -layer metal10 -location {800.095 368.07} -pin_size {2.0 2.0}
dict set planned_pins {din[263]} 1
place_pin -pin_name {din[263]} -layer metal10 -location {804.095 372.07} -pin_size {2.0 2.0}
dict set planned_pins {din[264]} 1
place_pin -pin_name {din[264]} -layer metal10 -location {800.095 376.07} -pin_size {2.0 2.0}
dict set planned_pins {din[265]} 1
place_pin -pin_name {din[265]} -layer metal10 -location {804.095 380.07} -pin_size {2.0 2.0}
dict set planned_pins {din[266]} 1
place_pin -pin_name {din[266]} -layer metal10 -location {800.095 384.07} -pin_size {2.0 2.0}
dict set planned_pins {din[267]} 1
place_pin -pin_name {din[267]} -layer metal10 -location {804.095 388.07} -pin_size {2.0 2.0}
dict set planned_pins {din[268]} 1
place_pin -pin_name {din[268]} -layer metal10 -location {800.095 392.07} -pin_size {2.0 2.0}
dict set planned_pins {din[269]} 1
place_pin -pin_name {din[269]} -layer metal10 -location {804.095 396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[270]} 1
place_pin -pin_name {din[270]} -layer metal10 -location {800.095 400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[271]} 1
place_pin -pin_name {din[271]} -layer metal10 -location {804.095 404.07} -pin_size {2.0 2.0}
dict set planned_pins {din[272]} 1
place_pin -pin_name {din[272]} -layer metal10 -location {2400.095 344.07} -pin_size {2.0 2.0}
dict set planned_pins {din[273]} 1
place_pin -pin_name {din[273]} -layer metal10 -location {2396.095 348.07} -pin_size {2.0 2.0}
dict set planned_pins {din[274]} 1
place_pin -pin_name {din[274]} -layer metal10 -location {2400.095 352.07} -pin_size {2.0 2.0}
dict set planned_pins {din[275]} 1
place_pin -pin_name {din[275]} -layer metal10 -location {2396.095 356.07} -pin_size {2.0 2.0}
dict set planned_pins {din[276]} 1
place_pin -pin_name {din[276]} -layer metal10 -location {2400.095 360.07} -pin_size {2.0 2.0}
dict set planned_pins {din[277]} 1
place_pin -pin_name {din[277]} -layer metal10 -location {2396.095 364.07} -pin_size {2.0 2.0}
dict set planned_pins {din[278]} 1
place_pin -pin_name {din[278]} -layer metal10 -location {2400.095 368.07} -pin_size {2.0 2.0}
dict set planned_pins {din[279]} 1
place_pin -pin_name {din[279]} -layer metal10 -location {2396.095 372.07} -pin_size {2.0 2.0}
dict set planned_pins {din[280]} 1
place_pin -pin_name {din[280]} -layer metal10 -location {2400.095 376.07} -pin_size {2.0 2.0}
dict set planned_pins {din[281]} 1
place_pin -pin_name {din[281]} -layer metal10 -location {2396.095 380.07} -pin_size {2.0 2.0}
dict set planned_pins {din[282]} 1
place_pin -pin_name {din[282]} -layer metal10 -location {2400.095 384.07} -pin_size {2.0 2.0}
dict set planned_pins {din[283]} 1
place_pin -pin_name {din[283]} -layer metal10 -location {2396.095 388.07} -pin_size {2.0 2.0}
dict set planned_pins {din[284]} 1
place_pin -pin_name {din[284]} -layer metal10 -location {2400.095 392.07} -pin_size {2.0 2.0}
dict set planned_pins {din[285]} 1
place_pin -pin_name {din[285]} -layer metal10 -location {2396.095 396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[286]} 1
place_pin -pin_name {din[286]} -layer metal10 -location {2400.095 400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[287]} 1
place_pin -pin_name {din[287]} -layer metal10 -location {2396.095 404.07} -pin_size {2.0 2.0}
dict set planned_pins {din[288]} 1
place_pin -pin_name {din[288]} -layer metal10 -location {348.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[289]} 1
place_pin -pin_name {din[289]} -layer metal10 -location {352.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[290]} 1
place_pin -pin_name {din[290]} -layer metal10 -location {356.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[291]} 1
place_pin -pin_name {din[291]} -layer metal10 -location {360.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[292]} 1
place_pin -pin_name {din[292]} -layer metal10 -location {364.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[293]} 1
place_pin -pin_name {din[293]} -layer metal10 -location {368.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[294]} 1
place_pin -pin_name {din[294]} -layer metal10 -location {372.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[295]} 1
place_pin -pin_name {din[295]} -layer metal10 -location {376.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[296]} 1
place_pin -pin_name {din[296]} -layer metal10 -location {380.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[297]} 1
place_pin -pin_name {din[297]} -layer metal10 -location {384.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[298]} 1
place_pin -pin_name {din[298]} -layer metal10 -location {388.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[299]} 1
place_pin -pin_name {din[299]} -layer metal10 -location {392.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[300]} 1
place_pin -pin_name {din[300]} -layer metal10 -location {396.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[301]} 1
place_pin -pin_name {din[301]} -layer metal10 -location {400.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[302]} 1
place_pin -pin_name {din[302]} -layer metal10 -location {404.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[303]} 1
place_pin -pin_name {din[303]} -layer metal10 -location {408.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[304]} 1
place_pin -pin_name {din[304]} -layer metal10 -location {368.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[305]} 1
place_pin -pin_name {din[305]} -layer metal10 -location {372.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[306]} 1
place_pin -pin_name {din[306]} -layer metal10 -location {376.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[307]} 1
place_pin -pin_name {din[307]} -layer metal10 -location {380.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[308]} 1
place_pin -pin_name {din[308]} -layer metal10 -location {384.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[309]} 1
place_pin -pin_name {din[309]} -layer metal10 -location {388.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[310]} 1
place_pin -pin_name {din[310]} -layer metal10 -location {392.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[311]} 1
place_pin -pin_name {din[311]} -layer metal10 -location {396.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[312]} 1
place_pin -pin_name {din[312]} -layer metal10 -location {400.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[313]} 1
place_pin -pin_name {din[313]} -layer metal10 -location {404.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[314]} 1
place_pin -pin_name {din[314]} -layer metal10 -location {408.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[315]} 1
place_pin -pin_name {din[315]} -layer metal10 -location {412.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[316]} 1
place_pin -pin_name {din[316]} -layer metal10 -location {416.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[317]} 1
place_pin -pin_name {din[317]} -layer metal10 -location {420.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[318]} 1
place_pin -pin_name {din[318]} -layer metal10 -location {424.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[319]} 1
place_pin -pin_name {din[319]} -layer metal10 -location {428.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[320]} 1
place_pin -pin_name {din[320]} -layer metal10 -location {800.095 408.07} -pin_size {2.0 2.0}
dict set planned_pins {din[321]} 1
place_pin -pin_name {din[321]} -layer metal10 -location {804.095 412.07} -pin_size {2.0 2.0}
dict set planned_pins {din[322]} 1
place_pin -pin_name {din[322]} -layer metal10 -location {800.095 416.07} -pin_size {2.0 2.0}
dict set planned_pins {din[323]} 1
place_pin -pin_name {din[323]} -layer metal10 -location {804.095 420.07} -pin_size {2.0 2.0}
dict set planned_pins {din[324]} 1
place_pin -pin_name {din[324]} -layer metal10 -location {800.095 424.07} -pin_size {2.0 2.0}
dict set planned_pins {din[325]} 1
place_pin -pin_name {din[325]} -layer metal10 -location {804.095 428.07} -pin_size {2.0 2.0}
dict set planned_pins {din[326]} 1
place_pin -pin_name {din[326]} -layer metal10 -location {800.095 432.07} -pin_size {2.0 2.0}
dict set planned_pins {din[327]} 1
place_pin -pin_name {din[327]} -layer metal10 -location {804.095 436.07} -pin_size {2.0 2.0}
dict set planned_pins {din[328]} 1
place_pin -pin_name {din[328]} -layer metal10 -location {800.095 440.07} -pin_size {2.0 2.0}
dict set planned_pins {din[329]} 1
place_pin -pin_name {din[329]} -layer metal10 -location {804.095 444.07} -pin_size {2.0 2.0}
dict set planned_pins {din[330]} 1
place_pin -pin_name {din[330]} -layer metal10 -location {800.095 448.07} -pin_size {2.0 2.0}
dict set planned_pins {din[331]} 1
place_pin -pin_name {din[331]} -layer metal10 -location {804.095 452.07} -pin_size {2.0 2.0}
dict set planned_pins {din[332]} 1
place_pin -pin_name {din[332]} -layer metal10 -location {800.095 456.07} -pin_size {2.0 2.0}
dict set planned_pins {din[333]} 1
place_pin -pin_name {din[333]} -layer metal10 -location {804.095 460.07} -pin_size {2.0 2.0}
dict set planned_pins {din[334]} 1
place_pin -pin_name {din[334]} -layer metal10 -location {800.095 464.07} -pin_size {2.0 2.0}
dict set planned_pins {din[335]} 1
place_pin -pin_name {din[335]} -layer metal10 -location {804.095 468.07} -pin_size {2.0 2.0}
dict set planned_pins {din[336]} 1
place_pin -pin_name {din[336]} -layer metal10 -location {2400.095 408.07} -pin_size {2.0 2.0}
dict set planned_pins {din[337]} 1
place_pin -pin_name {din[337]} -layer metal10 -location {2396.095 412.07} -pin_size {2.0 2.0}
dict set planned_pins {din[338]} 1
place_pin -pin_name {din[338]} -layer metal10 -location {2400.095 416.07} -pin_size {2.0 2.0}
dict set planned_pins {din[339]} 1
place_pin -pin_name {din[339]} -layer metal10 -location {2396.095 420.07} -pin_size {2.0 2.0}
dict set planned_pins {din[340]} 1
place_pin -pin_name {din[340]} -layer metal10 -location {2400.095 424.07} -pin_size {2.0 2.0}
dict set planned_pins {din[341]} 1
place_pin -pin_name {din[341]} -layer metal10 -location {2396.095 428.07} -pin_size {2.0 2.0}
dict set planned_pins {din[342]} 1
place_pin -pin_name {din[342]} -layer metal10 -location {2400.095 432.07} -pin_size {2.0 2.0}
dict set planned_pins {din[343]} 1
place_pin -pin_name {din[343]} -layer metal10 -location {2396.095 436.07} -pin_size {2.0 2.0}
dict set planned_pins {din[344]} 1
place_pin -pin_name {din[344]} -layer metal10 -location {2400.095 440.07} -pin_size {2.0 2.0}
dict set planned_pins {din[345]} 1
place_pin -pin_name {din[345]} -layer metal10 -location {2396.095 444.07} -pin_size {2.0 2.0}
dict set planned_pins {din[346]} 1
place_pin -pin_name {din[346]} -layer metal10 -location {2400.095 448.07} -pin_size {2.0 2.0}
dict set planned_pins {din[347]} 1
place_pin -pin_name {din[347]} -layer metal10 -location {2396.095 452.07} -pin_size {2.0 2.0}
dict set planned_pins {din[348]} 1
place_pin -pin_name {din[348]} -layer metal10 -location {2400.095 456.07} -pin_size {2.0 2.0}
dict set planned_pins {din[349]} 1
place_pin -pin_name {din[349]} -layer metal10 -location {2396.095 460.07} -pin_size {2.0 2.0}
dict set planned_pins {din[350]} 1
place_pin -pin_name {din[350]} -layer metal10 -location {2400.095 464.07} -pin_size {2.0 2.0}
dict set planned_pins {din[351]} 1
place_pin -pin_name {din[351]} -layer metal10 -location {2396.095 468.07} -pin_size {2.0 2.0}
dict set planned_pins {din[352]} 1
place_pin -pin_name {din[352]} -layer metal10 -location {412.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[353]} 1
place_pin -pin_name {din[353]} -layer metal10 -location {416.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[354]} 1
place_pin -pin_name {din[354]} -layer metal10 -location {420.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[355]} 1
place_pin -pin_name {din[355]} -layer metal10 -location {424.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[356]} 1
place_pin -pin_name {din[356]} -layer metal10 -location {428.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[357]} 1
place_pin -pin_name {din[357]} -layer metal10 -location {432.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[358]} 1
place_pin -pin_name {din[358]} -layer metal10 -location {436.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[359]} 1
place_pin -pin_name {din[359]} -layer metal10 -location {440.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[360]} 1
place_pin -pin_name {din[360]} -layer metal10 -location {444.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[361]} 1
place_pin -pin_name {din[361]} -layer metal10 -location {448.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[362]} 1
place_pin -pin_name {din[362]} -layer metal10 -location {452.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[363]} 1
place_pin -pin_name {din[363]} -layer metal10 -location {456.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[364]} 1
place_pin -pin_name {din[364]} -layer metal10 -location {460.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[365]} 1
place_pin -pin_name {din[365]} -layer metal10 -location {464.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[366]} 1
place_pin -pin_name {din[366]} -layer metal10 -location {468.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[367]} 1
place_pin -pin_name {din[367]} -layer metal10 -location {472.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[368]} 1
place_pin -pin_name {din[368]} -layer metal10 -location {432.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[369]} 1
place_pin -pin_name {din[369]} -layer metal10 -location {436.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[370]} 1
place_pin -pin_name {din[370]} -layer metal10 -location {440.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[371]} 1
place_pin -pin_name {din[371]} -layer metal10 -location {444.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[372]} 1
place_pin -pin_name {din[372]} -layer metal10 -location {448.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[373]} 1
place_pin -pin_name {din[373]} -layer metal10 -location {452.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[374]} 1
place_pin -pin_name {din[374]} -layer metal10 -location {456.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[375]} 1
place_pin -pin_name {din[375]} -layer metal10 -location {460.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[376]} 1
place_pin -pin_name {din[376]} -layer metal10 -location {464.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[377]} 1
place_pin -pin_name {din[377]} -layer metal10 -location {468.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[378]} 1
place_pin -pin_name {din[378]} -layer metal10 -location {472.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[379]} 1
place_pin -pin_name {din[379]} -layer metal10 -location {476.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[380]} 1
place_pin -pin_name {din[380]} -layer metal10 -location {480.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[381]} 1
place_pin -pin_name {din[381]} -layer metal10 -location {484.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[382]} 1
place_pin -pin_name {din[382]} -layer metal10 -location {488.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[383]} 1
place_pin -pin_name {din[383]} -layer metal10 -location {492.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[384]} 1
place_pin -pin_name {din[384]} -layer metal10 -location {476.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[385]} 1
place_pin -pin_name {din[385]} -layer metal10 -location {480.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[386]} 1
place_pin -pin_name {din[386]} -layer metal10 -location {484.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[387]} 1
place_pin -pin_name {din[387]} -layer metal10 -location {488.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[388]} 1
place_pin -pin_name {din[388]} -layer metal10 -location {492.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[389]} 1
place_pin -pin_name {din[389]} -layer metal10 -location {496.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[390]} 1
place_pin -pin_name {din[390]} -layer metal10 -location {500.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[391]} 1
place_pin -pin_name {din[391]} -layer metal10 -location {504.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[392]} 1
place_pin -pin_name {din[392]} -layer metal10 -location {508.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[393]} 1
place_pin -pin_name {din[393]} -layer metal10 -location {512.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[394]} 1
place_pin -pin_name {din[394]} -layer metal10 -location {516.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[395]} 1
place_pin -pin_name {din[395]} -layer metal10 -location {520.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[396]} 1
place_pin -pin_name {din[396]} -layer metal10 -location {524.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[397]} 1
place_pin -pin_name {din[397]} -layer metal10 -location {528.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[398]} 1
place_pin -pin_name {din[398]} -layer metal10 -location {532.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[399]} 1
place_pin -pin_name {din[399]} -layer metal10 -location {536.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[400]} 1
place_pin -pin_name {din[400]} -layer metal10 -location {800.095 472.07} -pin_size {2.0 2.0}
dict set planned_pins {din[401]} 1
place_pin -pin_name {din[401]} -layer metal10 -location {804.095 476.07} -pin_size {2.0 2.0}
dict set planned_pins {din[402]} 1
place_pin -pin_name {din[402]} -layer metal10 -location {800.095 480.07} -pin_size {2.0 2.0}
dict set planned_pins {din[403]} 1
place_pin -pin_name {din[403]} -layer metal10 -location {804.095 484.07} -pin_size {2.0 2.0}
dict set planned_pins {din[404]} 1
place_pin -pin_name {din[404]} -layer metal10 -location {800.095 488.07} -pin_size {2.0 2.0}
dict set planned_pins {din[405]} 1
place_pin -pin_name {din[405]} -layer metal10 -location {804.095 492.07} -pin_size {2.0 2.0}
dict set planned_pins {din[406]} 1
place_pin -pin_name {din[406]} -layer metal10 -location {800.095 496.07} -pin_size {2.0 2.0}
dict set planned_pins {din[407]} 1
place_pin -pin_name {din[407]} -layer metal10 -location {804.095 500.07} -pin_size {2.0 2.0}
dict set planned_pins {din[408]} 1
place_pin -pin_name {din[408]} -layer metal10 -location {800.095 504.07} -pin_size {2.0 2.0}
dict set planned_pins {din[409]} 1
place_pin -pin_name {din[409]} -layer metal10 -location {804.095 508.07} -pin_size {2.0 2.0}
dict set planned_pins {din[410]} 1
place_pin -pin_name {din[410]} -layer metal10 -location {800.095 512.07} -pin_size {2.0 2.0}
dict set planned_pins {din[411]} 1
place_pin -pin_name {din[411]} -layer metal10 -location {804.095 516.07} -pin_size {2.0 2.0}
dict set planned_pins {din[412]} 1
place_pin -pin_name {din[412]} -layer metal10 -location {800.095 520.07} -pin_size {2.0 2.0}
dict set planned_pins {din[413]} 1
place_pin -pin_name {din[413]} -layer metal10 -location {804.095 524.07} -pin_size {2.0 2.0}
dict set planned_pins {din[414]} 1
place_pin -pin_name {din[414]} -layer metal10 -location {800.095 528.07} -pin_size {2.0 2.0}
dict set planned_pins {din[415]} 1
place_pin -pin_name {din[415]} -layer metal10 -location {804.095 532.07} -pin_size {2.0 2.0}
dict set planned_pins {din[416]} 1
place_pin -pin_name {din[416]} -layer metal10 -location {2400.095 472.07} -pin_size {2.0 2.0}
dict set planned_pins {din[417]} 1
place_pin -pin_name {din[417]} -layer metal10 -location {2396.095 476.07} -pin_size {2.0 2.0}
dict set planned_pins {din[418]} 1
place_pin -pin_name {din[418]} -layer metal10 -location {2400.095 480.07} -pin_size {2.0 2.0}
dict set planned_pins {din[419]} 1
place_pin -pin_name {din[419]} -layer metal10 -location {2396.095 484.07} -pin_size {2.0 2.0}
dict set planned_pins {din[420]} 1
place_pin -pin_name {din[420]} -layer metal10 -location {2400.095 488.07} -pin_size {2.0 2.0}
dict set planned_pins {din[421]} 1
place_pin -pin_name {din[421]} -layer metal10 -location {2396.095 492.07} -pin_size {2.0 2.0}
dict set planned_pins {din[422]} 1
place_pin -pin_name {din[422]} -layer metal10 -location {2400.095 496.07} -pin_size {2.0 2.0}
dict set planned_pins {din[423]} 1
place_pin -pin_name {din[423]} -layer metal10 -location {2396.095 500.07} -pin_size {2.0 2.0}
dict set planned_pins {din[424]} 1
place_pin -pin_name {din[424]} -layer metal10 -location {2400.095 504.07} -pin_size {2.0 2.0}
dict set planned_pins {din[425]} 1
place_pin -pin_name {din[425]} -layer metal10 -location {2396.095 508.07} -pin_size {2.0 2.0}
dict set planned_pins {din[426]} 1
place_pin -pin_name {din[426]} -layer metal10 -location {2400.095 512.07} -pin_size {2.0 2.0}
dict set planned_pins {din[427]} 1
place_pin -pin_name {din[427]} -layer metal10 -location {2396.095 516.07} -pin_size {2.0 2.0}
dict set planned_pins {din[428]} 1
place_pin -pin_name {din[428]} -layer metal10 -location {2400.095 520.07} -pin_size {2.0 2.0}
dict set planned_pins {din[429]} 1
place_pin -pin_name {din[429]} -layer metal10 -location {2396.095 524.07} -pin_size {2.0 2.0}
dict set planned_pins {din[430]} 1
place_pin -pin_name {din[430]} -layer metal10 -location {2400.095 528.07} -pin_size {2.0 2.0}
dict set planned_pins {din[431]} 1
place_pin -pin_name {din[431]} -layer metal10 -location {2396.095 532.07} -pin_size {2.0 2.0}
dict set planned_pins {din[432]} 1
place_pin -pin_name {din[432]} -layer metal10 -location {496.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[433]} 1
place_pin -pin_name {din[433]} -layer metal10 -location {500.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[434]} 1
place_pin -pin_name {din[434]} -layer metal10 -location {504.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[435]} 1
place_pin -pin_name {din[435]} -layer metal10 -location {508.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[436]} 1
place_pin -pin_name {din[436]} -layer metal10 -location {512.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[437]} 1
place_pin -pin_name {din[437]} -layer metal10 -location {516.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[438]} 1
place_pin -pin_name {din[438]} -layer metal10 -location {520.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[439]} 1
place_pin -pin_name {din[439]} -layer metal10 -location {524.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[440]} 1
place_pin -pin_name {din[440]} -layer metal10 -location {528.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[441]} 1
place_pin -pin_name {din[441]} -layer metal10 -location {532.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[442]} 1
place_pin -pin_name {din[442]} -layer metal10 -location {536.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[443]} 1
place_pin -pin_name {din[443]} -layer metal10 -location {540.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[444]} 1
place_pin -pin_name {din[444]} -layer metal10 -location {544.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[445]} 1
place_pin -pin_name {din[445]} -layer metal10 -location {548.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[446]} 1
place_pin -pin_name {din[446]} -layer metal10 -location {552.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[447]} 1
place_pin -pin_name {din[447]} -layer metal10 -location {556.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[448]} 1
place_pin -pin_name {din[448]} -layer metal10 -location {540.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[449]} 1
place_pin -pin_name {din[449]} -layer metal10 -location {544.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[450]} 1
place_pin -pin_name {din[450]} -layer metal10 -location {548.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[451]} 1
place_pin -pin_name {din[451]} -layer metal10 -location {552.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[452]} 1
place_pin -pin_name {din[452]} -layer metal10 -location {556.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[453]} 1
place_pin -pin_name {din[453]} -layer metal10 -location {560.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[454]} 1
place_pin -pin_name {din[454]} -layer metal10 -location {564.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[455]} 1
place_pin -pin_name {din[455]} -layer metal10 -location {568.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[456]} 1
place_pin -pin_name {din[456]} -layer metal10 -location {572.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[457]} 1
place_pin -pin_name {din[457]} -layer metal10 -location {576.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[458]} 1
place_pin -pin_name {din[458]} -layer metal10 -location {580.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[459]} 1
place_pin -pin_name {din[459]} -layer metal10 -location {584.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[460]} 1
place_pin -pin_name {din[460]} -layer metal10 -location {588.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[461]} 1
place_pin -pin_name {din[461]} -layer metal10 -location {592.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[462]} 1
place_pin -pin_name {din[462]} -layer metal10 -location {596.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[463]} 1
place_pin -pin_name {din[463]} -layer metal10 -location {600.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[464]} 1
place_pin -pin_name {din[464]} -layer metal10 -location {800.095 536.07} -pin_size {2.0 2.0}
dict set planned_pins {din[465]} 1
place_pin -pin_name {din[465]} -layer metal10 -location {804.095 540.07} -pin_size {2.0 2.0}
dict set planned_pins {din[466]} 1
place_pin -pin_name {din[466]} -layer metal10 -location {800.095 544.07} -pin_size {2.0 2.0}
dict set planned_pins {din[467]} 1
place_pin -pin_name {din[467]} -layer metal10 -location {804.095 548.07} -pin_size {2.0 2.0}
dict set planned_pins {din[468]} 1
place_pin -pin_name {din[468]} -layer metal10 -location {800.095 552.07} -pin_size {2.0 2.0}
dict set planned_pins {din[469]} 1
place_pin -pin_name {din[469]} -layer metal10 -location {804.095 556.07} -pin_size {2.0 2.0}
dict set planned_pins {din[470]} 1
place_pin -pin_name {din[470]} -layer metal10 -location {800.095 560.07} -pin_size {2.0 2.0}
dict set planned_pins {din[471]} 1
place_pin -pin_name {din[471]} -layer metal10 -location {804.095 564.07} -pin_size {2.0 2.0}
dict set planned_pins {din[472]} 1
place_pin -pin_name {din[472]} -layer metal10 -location {800.095 568.07} -pin_size {2.0 2.0}
dict set planned_pins {din[473]} 1
place_pin -pin_name {din[473]} -layer metal10 -location {804.095 572.07} -pin_size {2.0 2.0}
dict set planned_pins {din[474]} 1
place_pin -pin_name {din[474]} -layer metal10 -location {800.095 576.07} -pin_size {2.0 2.0}
dict set planned_pins {din[475]} 1
place_pin -pin_name {din[475]} -layer metal10 -location {804.095 580.07} -pin_size {2.0 2.0}
dict set planned_pins {din[476]} 1
place_pin -pin_name {din[476]} -layer metal10 -location {800.095 584.07} -pin_size {2.0 2.0}
dict set planned_pins {din[477]} 1
place_pin -pin_name {din[477]} -layer metal10 -location {804.095 588.07} -pin_size {2.0 2.0}
dict set planned_pins {din[478]} 1
place_pin -pin_name {din[478]} -layer metal10 -location {800.095 592.07} -pin_size {2.0 2.0}
dict set planned_pins {din[479]} 1
place_pin -pin_name {din[479]} -layer metal10 -location {804.095 596.07} -pin_size {2.0 2.0}
dict set planned_pins {din[480]} 1
place_pin -pin_name {din[480]} -layer metal10 -location {2400.095 536.07} -pin_size {2.0 2.0}
dict set planned_pins {din[481]} 1
place_pin -pin_name {din[481]} -layer metal10 -location {2396.095 540.07} -pin_size {2.0 2.0}
dict set planned_pins {din[482]} 1
place_pin -pin_name {din[482]} -layer metal10 -location {2400.095 544.07} -pin_size {2.0 2.0}
dict set planned_pins {din[483]} 1
place_pin -pin_name {din[483]} -layer metal10 -location {2396.095 548.07} -pin_size {2.0 2.0}
dict set planned_pins {din[484]} 1
place_pin -pin_name {din[484]} -layer metal10 -location {2400.095 552.07} -pin_size {2.0 2.0}
dict set planned_pins {din[485]} 1
place_pin -pin_name {din[485]} -layer metal10 -location {2396.095 556.07} -pin_size {2.0 2.0}
dict set planned_pins {din[486]} 1
place_pin -pin_name {din[486]} -layer metal10 -location {2400.095 560.07} -pin_size {2.0 2.0}
dict set planned_pins {din[487]} 1
place_pin -pin_name {din[487]} -layer metal10 -location {2396.095 564.07} -pin_size {2.0 2.0}
dict set planned_pins {din[488]} 1
place_pin -pin_name {din[488]} -layer metal10 -location {2400.095 568.07} -pin_size {2.0 2.0}
dict set planned_pins {din[489]} 1
place_pin -pin_name {din[489]} -layer metal10 -location {2396.095 572.07} -pin_size {2.0 2.0}
dict set planned_pins {din[490]} 1
place_pin -pin_name {din[490]} -layer metal10 -location {2400.095 576.07} -pin_size {2.0 2.0}
dict set planned_pins {din[491]} 1
place_pin -pin_name {din[491]} -layer metal10 -location {2396.095 580.07} -pin_size {2.0 2.0}
dict set planned_pins {din[492]} 1
place_pin -pin_name {din[492]} -layer metal10 -location {2400.095 584.07} -pin_size {2.0 2.0}
dict set planned_pins {din[493]} 1
place_pin -pin_name {din[493]} -layer metal10 -location {2396.095 588.07} -pin_size {2.0 2.0}
dict set planned_pins {din[494]} 1
place_pin -pin_name {din[494]} -layer metal10 -location {2400.095 592.07} -pin_size {2.0 2.0}
dict set planned_pins {din[495]} 1
place_pin -pin_name {din[495]} -layer metal10 -location {2396.095 596.07} -pin_size {2.0 2.0}
dict set planned_pins {din[496]} 1
place_pin -pin_name {din[496]} -layer metal10 -location {560.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[497]} 1
place_pin -pin_name {din[497]} -layer metal10 -location {564.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[498]} 1
place_pin -pin_name {din[498]} -layer metal10 -location {568.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[499]} 1
place_pin -pin_name {din[499]} -layer metal10 -location {572.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[500]} 1
place_pin -pin_name {din[500]} -layer metal10 -location {576.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[501]} 1
place_pin -pin_name {din[501]} -layer metal10 -location {580.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[502]} 1
place_pin -pin_name {din[502]} -layer metal10 -location {584.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[503]} 1
place_pin -pin_name {din[503]} -layer metal10 -location {588.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[504]} 1
place_pin -pin_name {din[504]} -layer metal10 -location {592.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[505]} 1
place_pin -pin_name {din[505]} -layer metal10 -location {596.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[506]} 1
place_pin -pin_name {din[506]} -layer metal10 -location {600.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[507]} 1
place_pin -pin_name {din[507]} -layer metal10 -location {604.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[508]} 1
place_pin -pin_name {din[508]} -layer metal10 -location {608.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[509]} 1
place_pin -pin_name {din[509]} -layer metal10 -location {612.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[510]} 1
place_pin -pin_name {din[510]} -layer metal10 -location {616.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[511]} 1
place_pin -pin_name {din[511]} -layer metal10 -location {620.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[512]} 1
place_pin -pin_name {din[512]} -layer metal10 -location {604.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[513]} 1
place_pin -pin_name {din[513]} -layer metal10 -location {608.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[514]} 1
place_pin -pin_name {din[514]} -layer metal10 -location {612.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[515]} 1
place_pin -pin_name {din[515]} -layer metal10 -location {616.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[516]} 1
place_pin -pin_name {din[516]} -layer metal10 -location {620.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[517]} 1
place_pin -pin_name {din[517]} -layer metal10 -location {624.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[518]} 1
place_pin -pin_name {din[518]} -layer metal10 -location {628.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[519]} 1
place_pin -pin_name {din[519]} -layer metal10 -location {632.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[520]} 1
place_pin -pin_name {din[520]} -layer metal10 -location {636.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[521]} 1
place_pin -pin_name {din[521]} -layer metal10 -location {640.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[522]} 1
place_pin -pin_name {din[522]} -layer metal10 -location {644.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[523]} 1
place_pin -pin_name {din[523]} -layer metal10 -location {648.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[524]} 1
place_pin -pin_name {din[524]} -layer metal10 -location {652.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[525]} 1
place_pin -pin_name {din[525]} -layer metal10 -location {656.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[526]} 1
place_pin -pin_name {din[526]} -layer metal10 -location {660.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[527]} 1
place_pin -pin_name {din[527]} -layer metal10 -location {664.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[528]} 1
place_pin -pin_name {din[528]} -layer metal10 -location {800.095 600.07} -pin_size {2.0 2.0}
dict set planned_pins {din[529]} 1
place_pin -pin_name {din[529]} -layer metal10 -location {804.095 604.07} -pin_size {2.0 2.0}
dict set planned_pins {din[530]} 1
place_pin -pin_name {din[530]} -layer metal10 -location {800.095 608.07} -pin_size {2.0 2.0}
dict set planned_pins {din[531]} 1
place_pin -pin_name {din[531]} -layer metal10 -location {804.095 612.07} -pin_size {2.0 2.0}
dict set planned_pins {din[532]} 1
place_pin -pin_name {din[532]} -layer metal10 -location {800.095 616.07} -pin_size {2.0 2.0}
dict set planned_pins {din[533]} 1
place_pin -pin_name {din[533]} -layer metal10 -location {804.095 620.07} -pin_size {2.0 2.0}
dict set planned_pins {din[534]} 1
place_pin -pin_name {din[534]} -layer metal10 -location {800.095 624.07} -pin_size {2.0 2.0}
dict set planned_pins {din[535]} 1
place_pin -pin_name {din[535]} -layer metal10 -location {804.095 628.07} -pin_size {2.0 2.0}
dict set planned_pins {din[536]} 1
place_pin -pin_name {din[536]} -layer metal10 -location {800.095 632.07} -pin_size {2.0 2.0}
dict set planned_pins {din[537]} 1
place_pin -pin_name {din[537]} -layer metal10 -location {804.095 636.07} -pin_size {2.0 2.0}
dict set planned_pins {din[538]} 1
place_pin -pin_name {din[538]} -layer metal10 -location {800.095 640.07} -pin_size {2.0 2.0}
dict set planned_pins {din[539]} 1
place_pin -pin_name {din[539]} -layer metal10 -location {804.095 644.07} -pin_size {2.0 2.0}
dict set planned_pins {din[540]} 1
place_pin -pin_name {din[540]} -layer metal10 -location {800.095 648.07} -pin_size {2.0 2.0}
dict set planned_pins {din[541]} 1
place_pin -pin_name {din[541]} -layer metal10 -location {804.095 652.07} -pin_size {2.0 2.0}
dict set planned_pins {din[542]} 1
place_pin -pin_name {din[542]} -layer metal10 -location {800.095 656.07} -pin_size {2.0 2.0}
dict set planned_pins {din[543]} 1
place_pin -pin_name {din[543]} -layer metal10 -location {804.095 660.07} -pin_size {2.0 2.0}
dict set planned_pins {din[544]} 1
place_pin -pin_name {din[544]} -layer metal10 -location {2400.095 600.07} -pin_size {2.0 2.0}
dict set planned_pins {din[545]} 1
place_pin -pin_name {din[545]} -layer metal10 -location {2396.095 604.07} -pin_size {2.0 2.0}
dict set planned_pins {din[546]} 1
place_pin -pin_name {din[546]} -layer metal10 -location {2400.095 608.07} -pin_size {2.0 2.0}
dict set planned_pins {din[547]} 1
place_pin -pin_name {din[547]} -layer metal10 -location {2396.095 612.07} -pin_size {2.0 2.0}
dict set planned_pins {din[548]} 1
place_pin -pin_name {din[548]} -layer metal10 -location {2400.095 616.07} -pin_size {2.0 2.0}
dict set planned_pins {din[549]} 1
place_pin -pin_name {din[549]} -layer metal10 -location {2396.095 620.07} -pin_size {2.0 2.0}
dict set planned_pins {din[550]} 1
place_pin -pin_name {din[550]} -layer metal10 -location {2400.095 624.07} -pin_size {2.0 2.0}
dict set planned_pins {din[551]} 1
place_pin -pin_name {din[551]} -layer metal10 -location {2396.095 628.07} -pin_size {2.0 2.0}
dict set planned_pins {din[552]} 1
place_pin -pin_name {din[552]} -layer metal10 -location {2400.095 632.07} -pin_size {2.0 2.0}
dict set planned_pins {din[553]} 1
place_pin -pin_name {din[553]} -layer metal10 -location {2396.095 636.07} -pin_size {2.0 2.0}
dict set planned_pins {din[554]} 1
place_pin -pin_name {din[554]} -layer metal10 -location {2400.095 640.07} -pin_size {2.0 2.0}
dict set planned_pins {din[555]} 1
place_pin -pin_name {din[555]} -layer metal10 -location {2396.095 644.07} -pin_size {2.0 2.0}
dict set planned_pins {din[556]} 1
place_pin -pin_name {din[556]} -layer metal10 -location {2400.095 648.07} -pin_size {2.0 2.0}
dict set planned_pins {din[557]} 1
place_pin -pin_name {din[557]} -layer metal10 -location {2396.095 652.07} -pin_size {2.0 2.0}
dict set planned_pins {din[558]} 1
place_pin -pin_name {din[558]} -layer metal10 -location {2400.095 656.07} -pin_size {2.0 2.0}
dict set planned_pins {din[559]} 1
place_pin -pin_name {din[559]} -layer metal10 -location {2396.095 660.07} -pin_size {2.0 2.0}
dict set planned_pins {din[560]} 1
place_pin -pin_name {din[560]} -layer metal10 -location {624.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[561]} 1
place_pin -pin_name {din[561]} -layer metal10 -location {628.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[562]} 1
place_pin -pin_name {din[562]} -layer metal10 -location {632.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[563]} 1
place_pin -pin_name {din[563]} -layer metal10 -location {636.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[564]} 1
place_pin -pin_name {din[564]} -layer metal10 -location {640.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[565]} 1
place_pin -pin_name {din[565]} -layer metal10 -location {644.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[566]} 1
place_pin -pin_name {din[566]} -layer metal10 -location {648.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[567]} 1
place_pin -pin_name {din[567]} -layer metal10 -location {652.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[568]} 1
place_pin -pin_name {din[568]} -layer metal10 -location {656.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[569]} 1
place_pin -pin_name {din[569]} -layer metal10 -location {660.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[570]} 1
place_pin -pin_name {din[570]} -layer metal10 -location {664.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[571]} 1
place_pin -pin_name {din[571]} -layer metal10 -location {668.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[572]} 1
place_pin -pin_name {din[572]} -layer metal10 -location {672.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[573]} 1
place_pin -pin_name {din[573]} -layer metal10 -location {676.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[574]} 1
place_pin -pin_name {din[574]} -layer metal10 -location {680.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[575]} 1
place_pin -pin_name {din[575]} -layer metal10 -location {684.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[576]} 1
place_pin -pin_name {din[576]} -layer metal10 -location {668.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[577]} 1
place_pin -pin_name {din[577]} -layer metal10 -location {672.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[578]} 1
place_pin -pin_name {din[578]} -layer metal10 -location {676.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[579]} 1
place_pin -pin_name {din[579]} -layer metal10 -location {680.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[580]} 1
place_pin -pin_name {din[580]} -layer metal10 -location {684.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[581]} 1
place_pin -pin_name {din[581]} -layer metal10 -location {688.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[582]} 1
place_pin -pin_name {din[582]} -layer metal10 -location {692.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[583]} 1
place_pin -pin_name {din[583]} -layer metal10 -location {696.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[584]} 1
place_pin -pin_name {din[584]} -layer metal10 -location {700.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[585]} 1
place_pin -pin_name {din[585]} -layer metal10 -location {704.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[586]} 1
place_pin -pin_name {din[586]} -layer metal10 -location {708.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[587]} 1
place_pin -pin_name {din[587]} -layer metal10 -location {712.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[588]} 1
place_pin -pin_name {din[588]} -layer metal10 -location {716.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[589]} 1
place_pin -pin_name {din[589]} -layer metal10 -location {720.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[590]} 1
place_pin -pin_name {din[590]} -layer metal10 -location {724.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[591]} 1
place_pin -pin_name {din[591]} -layer metal10 -location {728.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[592]} 1
place_pin -pin_name {din[592]} -layer metal10 -location {800.095 664.07} -pin_size {2.0 2.0}
dict set planned_pins {din[593]} 1
place_pin -pin_name {din[593]} -layer metal10 -location {804.095 668.07} -pin_size {2.0 2.0}
dict set planned_pins {din[594]} 1
place_pin -pin_name {din[594]} -layer metal10 -location {800.095 672.07} -pin_size {2.0 2.0}
dict set planned_pins {din[595]} 1
place_pin -pin_name {din[595]} -layer metal10 -location {804.095 676.07} -pin_size {2.0 2.0}
dict set planned_pins {din[596]} 1
place_pin -pin_name {din[596]} -layer metal10 -location {800.095 680.07} -pin_size {2.0 2.0}
dict set planned_pins {din[597]} 1
place_pin -pin_name {din[597]} -layer metal10 -location {804.095 684.07} -pin_size {2.0 2.0}
dict set planned_pins {din[598]} 1
place_pin -pin_name {din[598]} -layer metal10 -location {800.095 688.07} -pin_size {2.0 2.0}
dict set planned_pins {din[599]} 1
place_pin -pin_name {din[599]} -layer metal10 -location {804.095 692.07} -pin_size {2.0 2.0}
dict set planned_pins {din[600]} 1
place_pin -pin_name {din[600]} -layer metal10 -location {800.095 696.07} -pin_size {2.0 2.0}
dict set planned_pins {din[601]} 1
place_pin -pin_name {din[601]} -layer metal10 -location {804.095 700.07} -pin_size {2.0 2.0}
dict set planned_pins {din[602]} 1
place_pin -pin_name {din[602]} -layer metal10 -location {800.095 704.07} -pin_size {2.0 2.0}
dict set planned_pins {din[603]} 1
place_pin -pin_name {din[603]} -layer metal10 -location {804.095 708.07} -pin_size {2.0 2.0}
dict set planned_pins {din[604]} 1
place_pin -pin_name {din[604]} -layer metal10 -location {800.095 712.07} -pin_size {2.0 2.0}
dict set planned_pins {din[605]} 1
place_pin -pin_name {din[605]} -layer metal10 -location {804.095 716.07} -pin_size {2.0 2.0}
dict set planned_pins {din[606]} 1
place_pin -pin_name {din[606]} -layer metal10 -location {800.095 720.07} -pin_size {2.0 2.0}
dict set planned_pins {din[607]} 1
place_pin -pin_name {din[607]} -layer metal10 -location {804.095 724.07} -pin_size {2.0 2.0}
dict set planned_pins {din[608]} 1
place_pin -pin_name {din[608]} -layer metal10 -location {2400.095 664.07} -pin_size {2.0 2.0}
dict set planned_pins {din[609]} 1
place_pin -pin_name {din[609]} -layer metal10 -location {2396.095 668.07} -pin_size {2.0 2.0}
dict set planned_pins {din[610]} 1
place_pin -pin_name {din[610]} -layer metal10 -location {2400.095 672.07} -pin_size {2.0 2.0}
dict set planned_pins {din[611]} 1
place_pin -pin_name {din[611]} -layer metal10 -location {2396.095 676.07} -pin_size {2.0 2.0}
dict set planned_pins {din[612]} 1
place_pin -pin_name {din[612]} -layer metal10 -location {2400.095 680.07} -pin_size {2.0 2.0}
dict set planned_pins {din[613]} 1
place_pin -pin_name {din[613]} -layer metal10 -location {2396.095 684.07} -pin_size {2.0 2.0}
dict set planned_pins {din[614]} 1
place_pin -pin_name {din[614]} -layer metal10 -location {2400.095 688.07} -pin_size {2.0 2.0}
dict set planned_pins {din[615]} 1
place_pin -pin_name {din[615]} -layer metal10 -location {2396.095 692.07} -pin_size {2.0 2.0}
dict set planned_pins {din[616]} 1
place_pin -pin_name {din[616]} -layer metal10 -location {2400.095 696.07} -pin_size {2.0 2.0}
dict set planned_pins {din[617]} 1
place_pin -pin_name {din[617]} -layer metal10 -location {2396.095 700.07} -pin_size {2.0 2.0}
dict set planned_pins {din[618]} 1
place_pin -pin_name {din[618]} -layer metal10 -location {2400.095 704.07} -pin_size {2.0 2.0}
dict set planned_pins {din[619]} 1
place_pin -pin_name {din[619]} -layer metal10 -location {2396.095 708.07} -pin_size {2.0 2.0}
dict set planned_pins {din[620]} 1
place_pin -pin_name {din[620]} -layer metal10 -location {2400.095 712.07} -pin_size {2.0 2.0}
dict set planned_pins {din[621]} 1
place_pin -pin_name {din[621]} -layer metal10 -location {2396.095 716.07} -pin_size {2.0 2.0}
dict set planned_pins {din[622]} 1
place_pin -pin_name {din[622]} -layer metal10 -location {2400.095 720.07} -pin_size {2.0 2.0}
dict set planned_pins {din[623]} 1
place_pin -pin_name {din[623]} -layer metal10 -location {2396.095 724.07} -pin_size {2.0 2.0}
dict set planned_pins {din[624]} 1
place_pin -pin_name {din[624]} -layer metal10 -location {688.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[625]} 1
place_pin -pin_name {din[625]} -layer metal10 -location {692.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[626]} 1
place_pin -pin_name {din[626]} -layer metal10 -location {696.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[627]} 1
place_pin -pin_name {din[627]} -layer metal10 -location {700.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[628]} 1
place_pin -pin_name {din[628]} -layer metal10 -location {704.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[629]} 1
place_pin -pin_name {din[629]} -layer metal10 -location {708.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[630]} 1
place_pin -pin_name {din[630]} -layer metal10 -location {712.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[631]} 1
place_pin -pin_name {din[631]} -layer metal10 -location {716.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[632]} 1
place_pin -pin_name {din[632]} -layer metal10 -location {720.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[633]} 1
place_pin -pin_name {din[633]} -layer metal10 -location {724.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[634]} 1
place_pin -pin_name {din[634]} -layer metal10 -location {728.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[635]} 1
place_pin -pin_name {din[635]} -layer metal10 -location {732.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[636]} 1
place_pin -pin_name {din[636]} -layer metal10 -location {736.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[637]} 1
place_pin -pin_name {din[637]} -layer metal10 -location {740.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[638]} 1
place_pin -pin_name {din[638]} -layer metal10 -location {744.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[639]} 1
place_pin -pin_name {din[639]} -layer metal10 -location {748.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[640]} 1
place_pin -pin_name {din[640]} -layer metal10 -location {732.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[641]} 1
place_pin -pin_name {din[641]} -layer metal10 -location {736.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[642]} 1
place_pin -pin_name {din[642]} -layer metal10 -location {740.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[643]} 1
place_pin -pin_name {din[643]} -layer metal10 -location {744.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[644]} 1
place_pin -pin_name {din[644]} -layer metal10 -location {748.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[645]} 1
place_pin -pin_name {din[645]} -layer metal10 -location {752.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[646]} 1
place_pin -pin_name {din[646]} -layer metal10 -location {756.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[647]} 1
place_pin -pin_name {din[647]} -layer metal10 -location {760.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[648]} 1
place_pin -pin_name {din[648]} -layer metal10 -location {764.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[649]} 1
place_pin -pin_name {din[649]} -layer metal10 -location {768.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[650]} 1
place_pin -pin_name {din[650]} -layer metal10 -location {772.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[651]} 1
place_pin -pin_name {din[651]} -layer metal10 -location {776.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[652]} 1
place_pin -pin_name {din[652]} -layer metal10 -location {780.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[653]} 1
place_pin -pin_name {din[653]} -layer metal10 -location {784.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[654]} 1
place_pin -pin_name {din[654]} -layer metal10 -location {788.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[655]} 1
place_pin -pin_name {din[655]} -layer metal10 -location {792.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[656]} 1
place_pin -pin_name {din[656]} -layer metal10 -location {800.095 728.07} -pin_size {2.0 2.0}
dict set planned_pins {din[657]} 1
place_pin -pin_name {din[657]} -layer metal10 -location {804.095 732.07} -pin_size {2.0 2.0}
dict set planned_pins {din[658]} 1
place_pin -pin_name {din[658]} -layer metal10 -location {800.095 736.07} -pin_size {2.0 2.0}
dict set planned_pins {din[659]} 1
place_pin -pin_name {din[659]} -layer metal10 -location {804.095 740.07} -pin_size {2.0 2.0}
dict set planned_pins {din[660]} 1
place_pin -pin_name {din[660]} -layer metal10 -location {800.095 744.07} -pin_size {2.0 2.0}
dict set planned_pins {din[661]} 1
place_pin -pin_name {din[661]} -layer metal10 -location {804.095 748.07} -pin_size {2.0 2.0}
dict set planned_pins {din[662]} 1
place_pin -pin_name {din[662]} -layer metal10 -location {800.095 752.07} -pin_size {2.0 2.0}
dict set planned_pins {din[663]} 1
place_pin -pin_name {din[663]} -layer metal10 -location {804.095 756.07} -pin_size {2.0 2.0}
dict set planned_pins {din[664]} 1
place_pin -pin_name {din[664]} -layer metal10 -location {800.095 760.07} -pin_size {2.0 2.0}
dict set planned_pins {din[665]} 1
place_pin -pin_name {din[665]} -layer metal10 -location {804.095 764.07} -pin_size {2.0 2.0}
dict set planned_pins {din[666]} 1
place_pin -pin_name {din[666]} -layer metal10 -location {800.095 768.07} -pin_size {2.0 2.0}
dict set planned_pins {din[667]} 1
place_pin -pin_name {din[667]} -layer metal10 -location {804.095 772.07} -pin_size {2.0 2.0}
dict set planned_pins {din[668]} 1
place_pin -pin_name {din[668]} -layer metal10 -location {800.095 776.07} -pin_size {2.0 2.0}
dict set planned_pins {din[669]} 1
place_pin -pin_name {din[669]} -layer metal10 -location {804.095 780.07} -pin_size {2.0 2.0}
dict set planned_pins {din[670]} 1
place_pin -pin_name {din[670]} -layer metal10 -location {800.095 784.07} -pin_size {2.0 2.0}
dict set planned_pins {din[671]} 1
place_pin -pin_name {din[671]} -layer metal10 -location {804.095 788.07} -pin_size {2.0 2.0}
dict set planned_pins {din[672]} 1
place_pin -pin_name {din[672]} -layer metal10 -location {2400.095 728.07} -pin_size {2.0 2.0}
dict set planned_pins {din[673]} 1
place_pin -pin_name {din[673]} -layer metal10 -location {2396.095 732.07} -pin_size {2.0 2.0}
dict set planned_pins {din[674]} 1
place_pin -pin_name {din[674]} -layer metal10 -location {2400.095 736.07} -pin_size {2.0 2.0}
dict set planned_pins {din[675]} 1
place_pin -pin_name {din[675]} -layer metal10 -location {2396.095 740.07} -pin_size {2.0 2.0}
dict set planned_pins {din[676]} 1
place_pin -pin_name {din[676]} -layer metal10 -location {2400.095 744.07} -pin_size {2.0 2.0}
dict set planned_pins {din[677]} 1
place_pin -pin_name {din[677]} -layer metal10 -location {2396.095 748.07} -pin_size {2.0 2.0}
dict set planned_pins {din[678]} 1
place_pin -pin_name {din[678]} -layer metal10 -location {2400.095 752.07} -pin_size {2.0 2.0}
dict set planned_pins {din[679]} 1
place_pin -pin_name {din[679]} -layer metal10 -location {2396.095 756.07} -pin_size {2.0 2.0}
dict set planned_pins {din[680]} 1
place_pin -pin_name {din[680]} -layer metal10 -location {2400.095 760.07} -pin_size {2.0 2.0}
dict set planned_pins {din[681]} 1
place_pin -pin_name {din[681]} -layer metal10 -location {2396.095 764.07} -pin_size {2.0 2.0}
dict set planned_pins {din[682]} 1
place_pin -pin_name {din[682]} -layer metal10 -location {2400.095 768.07} -pin_size {2.0 2.0}
dict set planned_pins {din[683]} 1
place_pin -pin_name {din[683]} -layer metal10 -location {2396.095 772.07} -pin_size {2.0 2.0}
dict set planned_pins {din[684]} 1
place_pin -pin_name {din[684]} -layer metal10 -location {2400.095 776.07} -pin_size {2.0 2.0}
dict set planned_pins {din[685]} 1
place_pin -pin_name {din[685]} -layer metal10 -location {2396.095 780.07} -pin_size {2.0 2.0}
dict set planned_pins {din[686]} 1
place_pin -pin_name {din[686]} -layer metal10 -location {2400.095 784.07} -pin_size {2.0 2.0}
dict set planned_pins {din[687]} 1
place_pin -pin_name {din[687]} -layer metal10 -location {2396.095 788.07} -pin_size {2.0 2.0}
dict set planned_pins {din[688]} 1
place_pin -pin_name {din[688]} -layer metal10 -location {752.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[689]} 1
place_pin -pin_name {din[689]} -layer metal10 -location {756.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[690]} 1
place_pin -pin_name {din[690]} -layer metal10 -location {760.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[691]} 1
place_pin -pin_name {din[691]} -layer metal10 -location {764.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[692]} 1
place_pin -pin_name {din[692]} -layer metal10 -location {768.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[693]} 1
place_pin -pin_name {din[693]} -layer metal10 -location {772.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[694]} 1
place_pin -pin_name {din[694]} -layer metal10 -location {776.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[695]} 1
place_pin -pin_name {din[695]} -layer metal10 -location {780.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[696]} 1
place_pin -pin_name {din[696]} -layer metal10 -location {784.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[697]} 1
place_pin -pin_name {din[697]} -layer metal10 -location {788.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[698]} 1
place_pin -pin_name {din[698]} -layer metal10 -location {792.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[699]} 1
place_pin -pin_name {din[699]} -layer metal10 -location {796.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[700]} 1
place_pin -pin_name {din[700]} -layer metal10 -location {800.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[701]} 1
place_pin -pin_name {din[701]} -layer metal10 -location {804.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[702]} 1
place_pin -pin_name {din[702]} -layer metal10 -location {808.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[703]} 1
place_pin -pin_name {din[703]} -layer metal10 -location {812.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[704]} 1
place_pin -pin_name {din[704]} -layer metal10 -location {796.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[705]} 1
place_pin -pin_name {din[705]} -layer metal10 -location {800.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[706]} 1
place_pin -pin_name {din[706]} -layer metal10 -location {804.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[707]} 1
place_pin -pin_name {din[707]} -layer metal10 -location {808.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[708]} 1
place_pin -pin_name {din[708]} -layer metal10 -location {812.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[709]} 1
place_pin -pin_name {din[709]} -layer metal10 -location {816.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[710]} 1
place_pin -pin_name {din[710]} -layer metal10 -location {820.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[711]} 1
place_pin -pin_name {din[711]} -layer metal10 -location {824.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[712]} 1
place_pin -pin_name {din[712]} -layer metal10 -location {828.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[713]} 1
place_pin -pin_name {din[713]} -layer metal10 -location {832.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[714]} 1
place_pin -pin_name {din[714]} -layer metal10 -location {836.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[715]} 1
place_pin -pin_name {din[715]} -layer metal10 -location {840.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[716]} 1
place_pin -pin_name {din[716]} -layer metal10 -location {844.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[717]} 1
place_pin -pin_name {din[717]} -layer metal10 -location {848.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[718]} 1
place_pin -pin_name {din[718]} -layer metal10 -location {852.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[719]} 1
place_pin -pin_name {din[719]} -layer metal10 -location {856.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[720]} 1
place_pin -pin_name {din[720]} -layer metal10 -location {800.095 792.07} -pin_size {2.0 2.0}
dict set planned_pins {din[721]} 1
place_pin -pin_name {din[721]} -layer metal10 -location {804.095 812.07} -pin_size {2.0 2.0}
dict set planned_pins {din[722]} 1
place_pin -pin_name {din[722]} -layer metal10 -location {800.095 816.07} -pin_size {2.0 2.0}
dict set planned_pins {din[723]} 1
place_pin -pin_name {din[723]} -layer metal10 -location {804.095 820.07} -pin_size {2.0 2.0}
dict set planned_pins {din[724]} 1
place_pin -pin_name {din[724]} -layer metal10 -location {800.095 824.07} -pin_size {2.0 2.0}
dict set planned_pins {din[725]} 1
place_pin -pin_name {din[725]} -layer metal10 -location {804.095 828.07} -pin_size {2.0 2.0}
dict set planned_pins {din[726]} 1
place_pin -pin_name {din[726]} -layer metal10 -location {800.095 832.07} -pin_size {2.0 2.0}
dict set planned_pins {din[727]} 1
place_pin -pin_name {din[727]} -layer metal10 -location {804.095 836.07} -pin_size {2.0 2.0}
dict set planned_pins {din[728]} 1
place_pin -pin_name {din[728]} -layer metal10 -location {800.095 840.07} -pin_size {2.0 2.0}
dict set planned_pins {din[729]} 1
place_pin -pin_name {din[729]} -layer metal10 -location {804.095 844.07} -pin_size {2.0 2.0}
dict set planned_pins {din[730]} 1
place_pin -pin_name {din[730]} -layer metal10 -location {800.095 848.07} -pin_size {2.0 2.0}
dict set planned_pins {din[731]} 1
place_pin -pin_name {din[731]} -layer metal10 -location {804.095 852.07} -pin_size {2.0 2.0}
dict set planned_pins {din[732]} 1
place_pin -pin_name {din[732]} -layer metal10 -location {800.095 856.07} -pin_size {2.0 2.0}
dict set planned_pins {din[733]} 1
place_pin -pin_name {din[733]} -layer metal10 -location {804.095 860.07} -pin_size {2.0 2.0}
dict set planned_pins {din[734]} 1
place_pin -pin_name {din[734]} -layer metal10 -location {800.095 864.07} -pin_size {2.0 2.0}
dict set planned_pins {din[735]} 1
place_pin -pin_name {din[735]} -layer metal10 -location {804.095 868.07} -pin_size {2.0 2.0}
dict set planned_pins {din[736]} 1
place_pin -pin_name {din[736]} -layer metal10 -location {2400.095 792.07} -pin_size {2.0 2.0}
dict set planned_pins {din[737]} 1
place_pin -pin_name {din[737]} -layer metal10 -location {2396.095 812.07} -pin_size {2.0 2.0}
dict set planned_pins {din[738]} 1
place_pin -pin_name {din[738]} -layer metal10 -location {2400.095 816.07} -pin_size {2.0 2.0}
dict set planned_pins {din[739]} 1
place_pin -pin_name {din[739]} -layer metal10 -location {2396.095 820.07} -pin_size {2.0 2.0}
dict set planned_pins {din[740]} 1
place_pin -pin_name {din[740]} -layer metal10 -location {2400.095 824.07} -pin_size {2.0 2.0}
dict set planned_pins {din[741]} 1
place_pin -pin_name {din[741]} -layer metal10 -location {2396.095 828.07} -pin_size {2.0 2.0}
dict set planned_pins {din[742]} 1
place_pin -pin_name {din[742]} -layer metal10 -location {2400.095 832.07} -pin_size {2.0 2.0}
dict set planned_pins {din[743]} 1
place_pin -pin_name {din[743]} -layer metal10 -location {2396.095 836.07} -pin_size {2.0 2.0}
dict set planned_pins {din[744]} 1
place_pin -pin_name {din[744]} -layer metal10 -location {2400.095 840.07} -pin_size {2.0 2.0}
dict set planned_pins {din[745]} 1
place_pin -pin_name {din[745]} -layer metal10 -location {2396.095 844.07} -pin_size {2.0 2.0}
dict set planned_pins {din[746]} 1
place_pin -pin_name {din[746]} -layer metal10 -location {2400.095 848.07} -pin_size {2.0 2.0}
dict set planned_pins {din[747]} 1
place_pin -pin_name {din[747]} -layer metal10 -location {2396.095 852.07} -pin_size {2.0 2.0}
dict set planned_pins {din[748]} 1
place_pin -pin_name {din[748]} -layer metal10 -location {2400.095 856.07} -pin_size {2.0 2.0}
dict set planned_pins {din[749]} 1
place_pin -pin_name {din[749]} -layer metal10 -location {2396.095 860.07} -pin_size {2.0 2.0}
dict set planned_pins {din[750]} 1
place_pin -pin_name {din[750]} -layer metal10 -location {2400.095 864.07} -pin_size {2.0 2.0}
dict set planned_pins {din[751]} 1
place_pin -pin_name {din[751]} -layer metal10 -location {2396.095 868.07} -pin_size {2.0 2.0}
dict set planned_pins {din[752]} 1
place_pin -pin_name {din[752]} -layer metal10 -location {816.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[753]} 1
place_pin -pin_name {din[753]} -layer metal10 -location {820.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[754]} 1
place_pin -pin_name {din[754]} -layer metal10 -location {824.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[755]} 1
place_pin -pin_name {din[755]} -layer metal10 -location {828.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[756]} 1
place_pin -pin_name {din[756]} -layer metal10 -location {832.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[757]} 1
place_pin -pin_name {din[757]} -layer metal10 -location {836.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[758]} 1
place_pin -pin_name {din[758]} -layer metal10 -location {840.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[759]} 1
place_pin -pin_name {din[759]} -layer metal10 -location {844.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[760]} 1
place_pin -pin_name {din[760]} -layer metal10 -location {848.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[761]} 1
place_pin -pin_name {din[761]} -layer metal10 -location {852.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[762]} 1
place_pin -pin_name {din[762]} -layer metal10 -location {856.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[763]} 1
place_pin -pin_name {din[763]} -layer metal10 -location {860.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[764]} 1
place_pin -pin_name {din[764]} -layer metal10 -location {864.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[765]} 1
place_pin -pin_name {din[765]} -layer metal10 -location {868.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[766]} 1
place_pin -pin_name {din[766]} -layer metal10 -location {872.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[767]} 1
place_pin -pin_name {din[767]} -layer metal10 -location {876.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[768]} 1
place_pin -pin_name {din[768]} -layer metal10 -location {860.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[769]} 1
place_pin -pin_name {din[769]} -layer metal10 -location {864.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[770]} 1
place_pin -pin_name {din[770]} -layer metal10 -location {868.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[771]} 1
place_pin -pin_name {din[771]} -layer metal10 -location {872.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[772]} 1
place_pin -pin_name {din[772]} -layer metal10 -location {876.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[773]} 1
place_pin -pin_name {din[773]} -layer metal10 -location {880.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[774]} 1
place_pin -pin_name {din[774]} -layer metal10 -location {884.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[775]} 1
place_pin -pin_name {din[775]} -layer metal10 -location {888.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[776]} 1
place_pin -pin_name {din[776]} -layer metal10 -location {892.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[777]} 1
place_pin -pin_name {din[777]} -layer metal10 -location {896.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[778]} 1
place_pin -pin_name {din[778]} -layer metal10 -location {900.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[779]} 1
place_pin -pin_name {din[779]} -layer metal10 -location {904.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[780]} 1
place_pin -pin_name {din[780]} -layer metal10 -location {908.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[781]} 1
place_pin -pin_name {din[781]} -layer metal10 -location {912.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[782]} 1
place_pin -pin_name {din[782]} -layer metal10 -location {916.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[783]} 1
place_pin -pin_name {din[783]} -layer metal10 -location {920.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[784]} 1
place_pin -pin_name {din[784]} -layer metal10 -location {800.095 872.07} -pin_size {2.0 2.0}
dict set planned_pins {din[785]} 1
place_pin -pin_name {din[785]} -layer metal10 -location {804.095 876.07} -pin_size {2.0 2.0}
dict set planned_pins {din[786]} 1
place_pin -pin_name {din[786]} -layer metal10 -location {800.095 880.07} -pin_size {2.0 2.0}
dict set planned_pins {din[787]} 1
place_pin -pin_name {din[787]} -layer metal10 -location {804.095 884.07} -pin_size {2.0 2.0}
dict set planned_pins {din[788]} 1
place_pin -pin_name {din[788]} -layer metal10 -location {800.095 888.07} -pin_size {2.0 2.0}
dict set planned_pins {din[789]} 1
place_pin -pin_name {din[789]} -layer metal10 -location {804.095 892.07} -pin_size {2.0 2.0}
dict set planned_pins {din[790]} 1
place_pin -pin_name {din[790]} -layer metal10 -location {800.095 896.07} -pin_size {2.0 2.0}
dict set planned_pins {din[791]} 1
place_pin -pin_name {din[791]} -layer metal10 -location {804.095 900.07} -pin_size {2.0 2.0}
dict set planned_pins {din[792]} 1
place_pin -pin_name {din[792]} -layer metal10 -location {800.095 904.07} -pin_size {2.0 2.0}
dict set planned_pins {din[793]} 1
place_pin -pin_name {din[793]} -layer metal10 -location {804.095 908.07} -pin_size {2.0 2.0}
dict set planned_pins {din[794]} 1
place_pin -pin_name {din[794]} -layer metal10 -location {800.095 912.07} -pin_size {2.0 2.0}
dict set planned_pins {din[795]} 1
place_pin -pin_name {din[795]} -layer metal10 -location {804.095 916.07} -pin_size {2.0 2.0}
dict set planned_pins {din[796]} 1
place_pin -pin_name {din[796]} -layer metal10 -location {800.095 920.07} -pin_size {2.0 2.0}
dict set planned_pins {din[797]} 1
place_pin -pin_name {din[797]} -layer metal10 -location {804.095 924.07} -pin_size {2.0 2.0}
dict set planned_pins {din[798]} 1
place_pin -pin_name {din[798]} -layer metal10 -location {800.095 928.07} -pin_size {2.0 2.0}
dict set planned_pins {din[799]} 1
place_pin -pin_name {din[799]} -layer metal10 -location {804.095 932.07} -pin_size {2.0 2.0}
dict set planned_pins {din[800]} 1
place_pin -pin_name {din[800]} -layer metal10 -location {2400.095 872.07} -pin_size {2.0 2.0}
dict set planned_pins {din[801]} 1
place_pin -pin_name {din[801]} -layer metal10 -location {2396.095 876.07} -pin_size {2.0 2.0}
dict set planned_pins {din[802]} 1
place_pin -pin_name {din[802]} -layer metal10 -location {2400.095 880.07} -pin_size {2.0 2.0}
dict set planned_pins {din[803]} 1
place_pin -pin_name {din[803]} -layer metal10 -location {2396.095 884.07} -pin_size {2.0 2.0}
dict set planned_pins {din[804]} 1
place_pin -pin_name {din[804]} -layer metal10 -location {2400.095 888.07} -pin_size {2.0 2.0}
dict set planned_pins {din[805]} 1
place_pin -pin_name {din[805]} -layer metal10 -location {2396.095 892.07} -pin_size {2.0 2.0}
dict set planned_pins {din[806]} 1
place_pin -pin_name {din[806]} -layer metal10 -location {2400.095 896.07} -pin_size {2.0 2.0}
dict set planned_pins {din[807]} 1
place_pin -pin_name {din[807]} -layer metal10 -location {2396.095 900.07} -pin_size {2.0 2.0}
dict set planned_pins {din[808]} 1
place_pin -pin_name {din[808]} -layer metal10 -location {2400.095 904.07} -pin_size {2.0 2.0}
dict set planned_pins {din[809]} 1
place_pin -pin_name {din[809]} -layer metal10 -location {2396.095 908.07} -pin_size {2.0 2.0}
dict set planned_pins {din[810]} 1
place_pin -pin_name {din[810]} -layer metal10 -location {2400.095 912.07} -pin_size {2.0 2.0}
dict set planned_pins {din[811]} 1
place_pin -pin_name {din[811]} -layer metal10 -location {2396.095 916.07} -pin_size {2.0 2.0}
dict set planned_pins {din[812]} 1
place_pin -pin_name {din[812]} -layer metal10 -location {2400.095 920.07} -pin_size {2.0 2.0}
dict set planned_pins {din[813]} 1
place_pin -pin_name {din[813]} -layer metal10 -location {2396.095 924.07} -pin_size {2.0 2.0}
dict set planned_pins {din[814]} 1
place_pin -pin_name {din[814]} -layer metal10 -location {2400.095 928.07} -pin_size {2.0 2.0}
dict set planned_pins {din[815]} 1
place_pin -pin_name {din[815]} -layer metal10 -location {2396.095 932.07} -pin_size {2.0 2.0}
dict set planned_pins {din[816]} 1
place_pin -pin_name {din[816]} -layer metal10 -location {880.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[817]} 1
place_pin -pin_name {din[817]} -layer metal10 -location {884.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[818]} 1
place_pin -pin_name {din[818]} -layer metal10 -location {888.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[819]} 1
place_pin -pin_name {din[819]} -layer metal10 -location {892.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[820]} 1
place_pin -pin_name {din[820]} -layer metal10 -location {896.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[821]} 1
place_pin -pin_name {din[821]} -layer metal10 -location {900.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[822]} 1
place_pin -pin_name {din[822]} -layer metal10 -location {904.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[823]} 1
place_pin -pin_name {din[823]} -layer metal10 -location {908.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[824]} 1
place_pin -pin_name {din[824]} -layer metal10 -location {912.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[825]} 1
place_pin -pin_name {din[825]} -layer metal10 -location {916.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[826]} 1
place_pin -pin_name {din[826]} -layer metal10 -location {920.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[827]} 1
place_pin -pin_name {din[827]} -layer metal10 -location {924.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[828]} 1
place_pin -pin_name {din[828]} -layer metal10 -location {928.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[829]} 1
place_pin -pin_name {din[829]} -layer metal10 -location {932.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[830]} 1
place_pin -pin_name {din[830]} -layer metal10 -location {936.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[831]} 1
place_pin -pin_name {din[831]} -layer metal10 -location {940.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[832]} 1
place_pin -pin_name {din[832]} -layer metal10 -location {924.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[833]} 1
place_pin -pin_name {din[833]} -layer metal10 -location {928.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[834]} 1
place_pin -pin_name {din[834]} -layer metal10 -location {932.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[835]} 1
place_pin -pin_name {din[835]} -layer metal10 -location {936.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[836]} 1
place_pin -pin_name {din[836]} -layer metal10 -location {940.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[837]} 1
place_pin -pin_name {din[837]} -layer metal10 -location {944.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[838]} 1
place_pin -pin_name {din[838]} -layer metal10 -location {948.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[839]} 1
place_pin -pin_name {din[839]} -layer metal10 -location {952.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[840]} 1
place_pin -pin_name {din[840]} -layer metal10 -location {956.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[841]} 1
place_pin -pin_name {din[841]} -layer metal10 -location {960.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[842]} 1
place_pin -pin_name {din[842]} -layer metal10 -location {964.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[843]} 1
place_pin -pin_name {din[843]} -layer metal10 -location {968.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[844]} 1
place_pin -pin_name {din[844]} -layer metal10 -location {972.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[845]} 1
place_pin -pin_name {din[845]} -layer metal10 -location {976.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[846]} 1
place_pin -pin_name {din[846]} -layer metal10 -location {980.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {din[847]} 1
place_pin -pin_name {din[847]} -layer metal10 -location {984.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {din[848]} 1
place_pin -pin_name {din[848]} -layer metal10 -location {800.095 936.07} -pin_size {2.0 2.0}
dict set planned_pins {din[849]} 1
place_pin -pin_name {din[849]} -layer metal10 -location {804.095 940.07} -pin_size {2.0 2.0}
dict set planned_pins {din[850]} 1
place_pin -pin_name {din[850]} -layer metal10 -location {800.095 944.07} -pin_size {2.0 2.0}
dict set planned_pins {din[851]} 1
place_pin -pin_name {din[851]} -layer metal10 -location {804.095 948.07} -pin_size {2.0 2.0}
dict set planned_pins {din[852]} 1
place_pin -pin_name {din[852]} -layer metal10 -location {800.095 952.07} -pin_size {2.0 2.0}
dict set planned_pins {din[853]} 1
place_pin -pin_name {din[853]} -layer metal10 -location {804.095 956.07} -pin_size {2.0 2.0}
dict set planned_pins {din[854]} 1
place_pin -pin_name {din[854]} -layer metal10 -location {800.095 960.07} -pin_size {2.0 2.0}
dict set planned_pins {din[855]} 1
place_pin -pin_name {din[855]} -layer metal10 -location {804.095 964.07} -pin_size {2.0 2.0}
dict set planned_pins {din[856]} 1
place_pin -pin_name {din[856]} -layer metal10 -location {800.095 968.07} -pin_size {2.0 2.0}
dict set planned_pins {din[857]} 1
place_pin -pin_name {din[857]} -layer metal10 -location {804.095 972.07} -pin_size {2.0 2.0}
dict set planned_pins {din[858]} 1
place_pin -pin_name {din[858]} -layer metal10 -location {800.095 976.07} -pin_size {2.0 2.0}
dict set planned_pins {din[859]} 1
place_pin -pin_name {din[859]} -layer metal10 -location {804.095 980.07} -pin_size {2.0 2.0}
dict set planned_pins {din[860]} 1
place_pin -pin_name {din[860]} -layer metal10 -location {800.095 984.07} -pin_size {2.0 2.0}
dict set planned_pins {din[861]} 1
place_pin -pin_name {din[861]} -layer metal10 -location {804.095 988.07} -pin_size {2.0 2.0}
dict set planned_pins {din[862]} 1
place_pin -pin_name {din[862]} -layer metal10 -location {800.095 992.07} -pin_size {2.0 2.0}
dict set planned_pins {din[863]} 1
place_pin -pin_name {din[863]} -layer metal10 -location {804.095 996.07} -pin_size {2.0 2.0}
dict set planned_pins {din[864]} 1
place_pin -pin_name {din[864]} -layer metal10 -location {2400.095 936.07} -pin_size {2.0 2.0}
dict set planned_pins {din[865]} 1
place_pin -pin_name {din[865]} -layer metal10 -location {2396.095 940.07} -pin_size {2.0 2.0}
dict set planned_pins {din[866]} 1
place_pin -pin_name {din[866]} -layer metal10 -location {2400.095 944.07} -pin_size {2.0 2.0}
dict set planned_pins {din[867]} 1
place_pin -pin_name {din[867]} -layer metal10 -location {2396.095 948.07} -pin_size {2.0 2.0}
dict set planned_pins {din[868]} 1
place_pin -pin_name {din[868]} -layer metal10 -location {2400.095 952.07} -pin_size {2.0 2.0}
dict set planned_pins {din[869]} 1
place_pin -pin_name {din[869]} -layer metal10 -location {2396.095 956.07} -pin_size {2.0 2.0}
dict set planned_pins {din[870]} 1
place_pin -pin_name {din[870]} -layer metal10 -location {2400.095 960.07} -pin_size {2.0 2.0}
dict set planned_pins {din[871]} 1
place_pin -pin_name {din[871]} -layer metal10 -location {2396.095 964.07} -pin_size {2.0 2.0}
dict set planned_pins {din[872]} 1
place_pin -pin_name {din[872]} -layer metal10 -location {2400.095 968.07} -pin_size {2.0 2.0}
dict set planned_pins {din[873]} 1
place_pin -pin_name {din[873]} -layer metal10 -location {2396.095 972.07} -pin_size {2.0 2.0}
dict set planned_pins {din[874]} 1
place_pin -pin_name {din[874]} -layer metal10 -location {2400.095 976.07} -pin_size {2.0 2.0}
dict set planned_pins {din[875]} 1
place_pin -pin_name {din[875]} -layer metal10 -location {2396.095 980.07} -pin_size {2.0 2.0}
dict set planned_pins {din[876]} 1
place_pin -pin_name {din[876]} -layer metal10 -location {2400.095 984.07} -pin_size {2.0 2.0}
dict set planned_pins {din[877]} 1
place_pin -pin_name {din[877]} -layer metal10 -location {2396.095 988.07} -pin_size {2.0 2.0}
dict set planned_pins {din[878]} 1
place_pin -pin_name {din[878]} -layer metal10 -location {2400.095 992.07} -pin_size {2.0 2.0}
dict set planned_pins {din[879]} 1
place_pin -pin_name {din[879]} -layer metal10 -location {2396.095 996.07} -pin_size {2.0 2.0}
dict set planned_pins {din[880]} 1
place_pin -pin_name {din[880]} -layer metal10 -location {944.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[881]} 1
place_pin -pin_name {din[881]} -layer metal10 -location {948.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[882]} 1
place_pin -pin_name {din[882]} -layer metal10 -location {952.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[883]} 1
place_pin -pin_name {din[883]} -layer metal10 -location {956.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[884]} 1
place_pin -pin_name {din[884]} -layer metal10 -location {960.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[885]} 1
place_pin -pin_name {din[885]} -layer metal10 -location {964.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[886]} 1
place_pin -pin_name {din[886]} -layer metal10 -location {968.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[887]} 1
place_pin -pin_name {din[887]} -layer metal10 -location {972.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[888]} 1
place_pin -pin_name {din[888]} -layer metal10 -location {976.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[889]} 1
place_pin -pin_name {din[889]} -layer metal10 -location {980.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[890]} 1
place_pin -pin_name {din[890]} -layer metal10 -location {984.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[891]} 1
place_pin -pin_name {din[891]} -layer metal10 -location {988.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[892]} 1
place_pin -pin_name {din[892]} -layer metal10 -location {992.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[893]} 1
place_pin -pin_name {din[893]} -layer metal10 -location {996.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {din[894]} 1
place_pin -pin_name {din[894]} -layer metal10 -location {1000.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {din[895]} 1
place_pin -pin_name {din[895]} -layer metal10 -location {1004.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[0]} 1
place_pin -pin_name {dout[0]} -layer metal10 -location {988.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[1]} 1
place_pin -pin_name {dout[1]} -layer metal10 -location {992.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[2]} 1
place_pin -pin_name {dout[2]} -layer metal10 -location {996.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[3]} 1
place_pin -pin_name {dout[3]} -layer metal10 -location {1000.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[4]} 1
place_pin -pin_name {dout[4]} -layer metal10 -location {1004.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[5]} 1
place_pin -pin_name {dout[5]} -layer metal10 -location {1008.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[6]} 1
place_pin -pin_name {dout[6]} -layer metal10 -location {1012.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[7]} 1
place_pin -pin_name {dout[7]} -layer metal10 -location {1016.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[8]} 1
place_pin -pin_name {dout[8]} -layer metal10 -location {1020.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[9]} 1
place_pin -pin_name {dout[9]} -layer metal10 -location {1024.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[10]} 1
place_pin -pin_name {dout[10]} -layer metal10 -location {1028.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[11]} 1
place_pin -pin_name {dout[11]} -layer metal10 -location {1032.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[12]} 1
place_pin -pin_name {dout[12]} -layer metal10 -location {1036.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[13]} 1
place_pin -pin_name {dout[13]} -layer metal10 -location {1040.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[14]} 1
place_pin -pin_name {dout[14]} -layer metal10 -location {1044.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[15]} 1
place_pin -pin_name {dout[15]} -layer metal10 -location {1048.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[16]} 1
place_pin -pin_name {dout[16]} -layer metal10 -location {800.095 1000.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[17]} 1
place_pin -pin_name {dout[17]} -layer metal10 -location {804.095 1004.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[18]} 1
place_pin -pin_name {dout[18]} -layer metal10 -location {800.095 1008.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[19]} 1
place_pin -pin_name {dout[19]} -layer metal10 -location {804.095 1012.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[20]} 1
place_pin -pin_name {dout[20]} -layer metal10 -location {800.095 1016.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[21]} 1
place_pin -pin_name {dout[21]} -layer metal10 -location {804.095 1020.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[22]} 1
place_pin -pin_name {dout[22]} -layer metal10 -location {800.095 1024.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[23]} 1
place_pin -pin_name {dout[23]} -layer metal10 -location {804.095 1028.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[24]} 1
place_pin -pin_name {dout[24]} -layer metal10 -location {800.095 1032.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[25]} 1
place_pin -pin_name {dout[25]} -layer metal10 -location {804.095 1036.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[26]} 1
place_pin -pin_name {dout[26]} -layer metal10 -location {800.095 1040.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[27]} 1
place_pin -pin_name {dout[27]} -layer metal10 -location {804.095 1044.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[28]} 1
place_pin -pin_name {dout[28]} -layer metal10 -location {800.095 1048.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[29]} 1
place_pin -pin_name {dout[29]} -layer metal10 -location {804.095 1052.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[30]} 1
place_pin -pin_name {dout[30]} -layer metal10 -location {800.095 1056.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[31]} 1
place_pin -pin_name {dout[31]} -layer metal10 -location {804.095 1060.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[32]} 1
place_pin -pin_name {dout[32]} -layer metal10 -location {2400.095 1000.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[33]} 1
place_pin -pin_name {dout[33]} -layer metal10 -location {2396.095 1004.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[34]} 1
place_pin -pin_name {dout[34]} -layer metal10 -location {2400.095 1008.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[35]} 1
place_pin -pin_name {dout[35]} -layer metal10 -location {2396.095 1012.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[36]} 1
place_pin -pin_name {dout[36]} -layer metal10 -location {2400.095 1016.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[37]} 1
place_pin -pin_name {dout[37]} -layer metal10 -location {2396.095 1020.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[38]} 1
place_pin -pin_name {dout[38]} -layer metal10 -location {2400.095 1024.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[39]} 1
place_pin -pin_name {dout[39]} -layer metal10 -location {2396.095 1028.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[40]} 1
place_pin -pin_name {dout[40]} -layer metal10 -location {2400.095 1032.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[41]} 1
place_pin -pin_name {dout[41]} -layer metal10 -location {2396.095 1036.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[42]} 1
place_pin -pin_name {dout[42]} -layer metal10 -location {2400.095 1040.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[43]} 1
place_pin -pin_name {dout[43]} -layer metal10 -location {2396.095 1044.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[44]} 1
place_pin -pin_name {dout[44]} -layer metal10 -location {2400.095 1048.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[45]} 1
place_pin -pin_name {dout[45]} -layer metal10 -location {2396.095 1052.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[46]} 1
place_pin -pin_name {dout[46]} -layer metal10 -location {2400.095 1056.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[47]} 1
place_pin -pin_name {dout[47]} -layer metal10 -location {2396.095 1060.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[48]} 1
place_pin -pin_name {dout[48]} -layer metal10 -location {1008.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[49]} 1
place_pin -pin_name {dout[49]} -layer metal10 -location {1012.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[50]} 1
place_pin -pin_name {dout[50]} -layer metal10 -location {1016.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[51]} 1
place_pin -pin_name {dout[51]} -layer metal10 -location {1020.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[52]} 1
place_pin -pin_name {dout[52]} -layer metal10 -location {1024.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[53]} 1
place_pin -pin_name {dout[53]} -layer metal10 -location {1028.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[54]} 1
place_pin -pin_name {dout[54]} -layer metal10 -location {1032.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[55]} 1
place_pin -pin_name {dout[55]} -layer metal10 -location {1036.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[56]} 1
place_pin -pin_name {dout[56]} -layer metal10 -location {1040.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[57]} 1
place_pin -pin_name {dout[57]} -layer metal10 -location {1044.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[58]} 1
place_pin -pin_name {dout[58]} -layer metal10 -location {1048.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[59]} 1
place_pin -pin_name {dout[59]} -layer metal10 -location {1052.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[60]} 1
place_pin -pin_name {dout[60]} -layer metal10 -location {1056.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[61]} 1
place_pin -pin_name {dout[61]} -layer metal10 -location {1060.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[62]} 1
place_pin -pin_name {dout[62]} -layer metal10 -location {1064.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[63]} 1
place_pin -pin_name {dout[63]} -layer metal10 -location {1068.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[64]} 1
place_pin -pin_name {dout[64]} -layer metal10 -location {1052.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[65]} 1
place_pin -pin_name {dout[65]} -layer metal10 -location {1056.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[66]} 1
place_pin -pin_name {dout[66]} -layer metal10 -location {1060.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[67]} 1
place_pin -pin_name {dout[67]} -layer metal10 -location {1064.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[68]} 1
place_pin -pin_name {dout[68]} -layer metal10 -location {1068.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[69]} 1
place_pin -pin_name {dout[69]} -layer metal10 -location {1072.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[70]} 1
place_pin -pin_name {dout[70]} -layer metal10 -location {1076.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[71]} 1
place_pin -pin_name {dout[71]} -layer metal10 -location {1080.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[72]} 1
place_pin -pin_name {dout[72]} -layer metal10 -location {1084.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[73]} 1
place_pin -pin_name {dout[73]} -layer metal10 -location {1088.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[74]} 1
place_pin -pin_name {dout[74]} -layer metal10 -location {1092.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[75]} 1
place_pin -pin_name {dout[75]} -layer metal10 -location {1096.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[76]} 1
place_pin -pin_name {dout[76]} -layer metal10 -location {1100.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[77]} 1
place_pin -pin_name {dout[77]} -layer metal10 -location {1104.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[78]} 1
place_pin -pin_name {dout[78]} -layer metal10 -location {1108.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[79]} 1
place_pin -pin_name {dout[79]} -layer metal10 -location {1112.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[80]} 1
place_pin -pin_name {dout[80]} -layer metal10 -location {800.095 1064.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[81]} 1
place_pin -pin_name {dout[81]} -layer metal10 -location {804.095 1068.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[82]} 1
place_pin -pin_name {dout[82]} -layer metal10 -location {800.095 1072.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[83]} 1
place_pin -pin_name {dout[83]} -layer metal10 -location {804.095 1076.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[84]} 1
place_pin -pin_name {dout[84]} -layer metal10 -location {800.095 1080.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[85]} 1
place_pin -pin_name {dout[85]} -layer metal10 -location {804.095 1084.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[86]} 1
place_pin -pin_name {dout[86]} -layer metal10 -location {800.095 1088.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[87]} 1
place_pin -pin_name {dout[87]} -layer metal10 -location {804.095 1092.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[88]} 1
place_pin -pin_name {dout[88]} -layer metal10 -location {800.095 1096.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[89]} 1
place_pin -pin_name {dout[89]} -layer metal10 -location {804.095 1100.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[90]} 1
place_pin -pin_name {dout[90]} -layer metal10 -location {800.095 1104.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[91]} 1
place_pin -pin_name {dout[91]} -layer metal10 -location {804.095 1108.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[92]} 1
place_pin -pin_name {dout[92]} -layer metal10 -location {800.095 1112.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[93]} 1
place_pin -pin_name {dout[93]} -layer metal10 -location {804.095 1116.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[94]} 1
place_pin -pin_name {dout[94]} -layer metal10 -location {800.095 1120.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[95]} 1
place_pin -pin_name {dout[95]} -layer metal10 -location {804.095 1124.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[96]} 1
place_pin -pin_name {dout[96]} -layer metal10 -location {2400.095 1064.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[97]} 1
place_pin -pin_name {dout[97]} -layer metal10 -location {2396.095 1068.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[98]} 1
place_pin -pin_name {dout[98]} -layer metal10 -location {2400.095 1072.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[99]} 1
place_pin -pin_name {dout[99]} -layer metal10 -location {2396.095 1076.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[100]} 1
place_pin -pin_name {dout[100]} -layer metal10 -location {2400.095 1080.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[101]} 1
place_pin -pin_name {dout[101]} -layer metal10 -location {2396.095 1084.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[102]} 1
place_pin -pin_name {dout[102]} -layer metal10 -location {2400.095 1088.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[103]} 1
place_pin -pin_name {dout[103]} -layer metal10 -location {2396.095 1092.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[104]} 1
place_pin -pin_name {dout[104]} -layer metal10 -location {2400.095 1096.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[105]} 1
place_pin -pin_name {dout[105]} -layer metal10 -location {2396.095 1100.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[106]} 1
place_pin -pin_name {dout[106]} -layer metal10 -location {2400.095 1104.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[107]} 1
place_pin -pin_name {dout[107]} -layer metal10 -location {2396.095 1108.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[108]} 1
place_pin -pin_name {dout[108]} -layer metal10 -location {2400.095 1112.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[109]} 1
place_pin -pin_name {dout[109]} -layer metal10 -location {2396.095 1116.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[110]} 1
place_pin -pin_name {dout[110]} -layer metal10 -location {2400.095 1120.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[111]} 1
place_pin -pin_name {dout[111]} -layer metal10 -location {2396.095 1124.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[112]} 1
place_pin -pin_name {dout[112]} -layer metal10 -location {1072.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[113]} 1
place_pin -pin_name {dout[113]} -layer metal10 -location {1076.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[114]} 1
place_pin -pin_name {dout[114]} -layer metal10 -location {1080.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[115]} 1
place_pin -pin_name {dout[115]} -layer metal10 -location {1084.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[116]} 1
place_pin -pin_name {dout[116]} -layer metal10 -location {1088.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[117]} 1
place_pin -pin_name {dout[117]} -layer metal10 -location {1092.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[118]} 1
place_pin -pin_name {dout[118]} -layer metal10 -location {1096.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[119]} 1
place_pin -pin_name {dout[119]} -layer metal10 -location {1100.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[120]} 1
place_pin -pin_name {dout[120]} -layer metal10 -location {1104.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[121]} 1
place_pin -pin_name {dout[121]} -layer metal10 -location {1108.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[122]} 1
place_pin -pin_name {dout[122]} -layer metal10 -location {1112.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[123]} 1
place_pin -pin_name {dout[123]} -layer metal10 -location {1116.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[124]} 1
place_pin -pin_name {dout[124]} -layer metal10 -location {1120.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[125]} 1
place_pin -pin_name {dout[125]} -layer metal10 -location {1124.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[126]} 1
place_pin -pin_name {dout[126]} -layer metal10 -location {1128.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {dout[127]} 1
place_pin -pin_name {dout[127]} -layer metal10 -location {1132.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[0]} 1
place_pin -pin_name {ready[0]} -layer metal10 -location {1116.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[1]} 1
place_pin -pin_name {ready[1]} -layer metal10 -location {1120.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[2]} 1
place_pin -pin_name {ready[2]} -layer metal10 -location {1124.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[3]} 1
place_pin -pin_name {ready[3]} -layer metal10 -location {1128.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[4]} 1
place_pin -pin_name {ready[4]} -layer metal10 -location {1132.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[5]} 1
place_pin -pin_name {ready[5]} -layer metal10 -location {1136.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {ready[6]} 1
place_pin -pin_name {ready[6]} -layer metal10 -location {1140.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {req[0]} 1
place_pin -pin_name {req[0]} -layer metal10 -location {800.095 1128.07} -pin_size {2.0 2.0}
dict set planned_pins {req[1]} 1
place_pin -pin_name {req[1]} -layer metal10 -location {804.095 1132.07} -pin_size {2.0 2.0}
dict set planned_pins {req[2]} 1
place_pin -pin_name {req[2]} -layer metal10 -location {800.095 1136.07} -pin_size {2.0 2.0}
dict set planned_pins {req[3]} 1
place_pin -pin_name {req[3]} -layer metal10 -location {804.095 1140.07} -pin_size {2.0 2.0}
dict set planned_pins {req[4]} 1
place_pin -pin_name {req[4]} -layer metal10 -location {800.095 1144.07} -pin_size {2.0 2.0}
dict set planned_pins {req[5]} 1
place_pin -pin_name {req[5]} -layer metal10 -location {804.095 1148.07} -pin_size {2.0 2.0}
dict set planned_pins {req[6]} 1
place_pin -pin_name {req[6]} -layer metal10 -location {800.095 1152.07} -pin_size {2.0 2.0}
dict set planned_pins {reset} 1
place_pin -pin_name {reset} -layer metal10 -location {2400.095 1128.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[0]} 1
place_pin -pin_name {s_addr[0]} -layer metal10 -location {2396.095 1132.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[1]} 1
place_pin -pin_name {s_addr[1]} -layer metal10 -location {2400.095 1136.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[2]} 1
place_pin -pin_name {s_addr[2]} -layer metal10 -location {2396.095 1140.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[3]} 1
place_pin -pin_name {s_addr[3]} -layer metal10 -location {2400.095 1144.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[4]} 1
place_pin -pin_name {s_addr[4]} -layer metal10 -location {2396.095 1148.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[5]} 1
place_pin -pin_name {s_addr[5]} -layer metal10 -location {2400.095 1152.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[6]} 1
place_pin -pin_name {s_addr[6]} -layer metal10 -location {2396.095 1156.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[7]} 1
place_pin -pin_name {s_addr[7]} -layer metal10 -location {2400.095 1160.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[8]} 1
place_pin -pin_name {s_addr[8]} -layer metal10 -location {2396.095 1164.07} -pin_size {2.0 2.0}
dict set planned_pins {s_addr[9]} 1
place_pin -pin_name {s_addr[9]} -layer metal10 -location {2400.095 1168.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[0]} 1
place_pin -pin_name {s_din[0]} -layer metal10 -location {1136.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[1]} 1
place_pin -pin_name {s_din[1]} -layer metal10 -location {1140.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[2]} 1
place_pin -pin_name {s_din[2]} -layer metal10 -location {1144.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[3]} 1
place_pin -pin_name {s_din[3]} -layer metal10 -location {1148.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[4]} 1
place_pin -pin_name {s_din[4]} -layer metal10 -location {1152.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[5]} 1
place_pin -pin_name {s_din[5]} -layer metal10 -location {1156.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[6]} 1
place_pin -pin_name {s_din[6]} -layer metal10 -location {1160.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[7]} 1
place_pin -pin_name {s_din[7]} -layer metal10 -location {1164.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[8]} 1
place_pin -pin_name {s_din[8]} -layer metal10 -location {1168.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[9]} 1
place_pin -pin_name {s_din[9]} -layer metal10 -location {1172.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[10]} 1
place_pin -pin_name {s_din[10]} -layer metal10 -location {1176.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[11]} 1
place_pin -pin_name {s_din[11]} -layer metal10 -location {1180.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[12]} 1
place_pin -pin_name {s_din[12]} -layer metal10 -location {1184.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[13]} 1
place_pin -pin_name {s_din[13]} -layer metal10 -location {1188.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[14]} 1
place_pin -pin_name {s_din[14]} -layer metal10 -location {1192.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[15]} 1
place_pin -pin_name {s_din[15]} -layer metal10 -location {1196.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[16]} 1
place_pin -pin_name {s_din[16]} -layer metal10 -location {1144.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[17]} 1
place_pin -pin_name {s_din[17]} -layer metal10 -location {1148.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[18]} 1
place_pin -pin_name {s_din[18]} -layer metal10 -location {1152.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[19]} 1
place_pin -pin_name {s_din[19]} -layer metal10 -location {1156.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[20]} 1
place_pin -pin_name {s_din[20]} -layer metal10 -location {1160.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[21]} 1
place_pin -pin_name {s_din[21]} -layer metal10 -location {1164.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[22]} 1
place_pin -pin_name {s_din[22]} -layer metal10 -location {1168.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[23]} 1
place_pin -pin_name {s_din[23]} -layer metal10 -location {1172.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[24]} 1
place_pin -pin_name {s_din[24]} -layer metal10 -location {1176.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[25]} 1
place_pin -pin_name {s_din[25]} -layer metal10 -location {1180.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[26]} 1
place_pin -pin_name {s_din[26]} -layer metal10 -location {1184.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[27]} 1
place_pin -pin_name {s_din[27]} -layer metal10 -location {1188.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[28]} 1
place_pin -pin_name {s_din[28]} -layer metal10 -location {1192.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[29]} 1
place_pin -pin_name {s_din[29]} -layer metal10 -location {1196.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[30]} 1
place_pin -pin_name {s_din[30]} -layer metal10 -location {1200.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[31]} 1
place_pin -pin_name {s_din[31]} -layer metal10 -location {1204.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[32]} 1
place_pin -pin_name {s_din[32]} -layer metal10 -location {804.095 1156.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[33]} 1
place_pin -pin_name {s_din[33]} -layer metal10 -location {800.095 1160.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[34]} 1
place_pin -pin_name {s_din[34]} -layer metal10 -location {804.095 1164.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[35]} 1
place_pin -pin_name {s_din[35]} -layer metal10 -location {800.095 1168.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[36]} 1
place_pin -pin_name {s_din[36]} -layer metal10 -location {804.095 1172.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[37]} 1
place_pin -pin_name {s_din[37]} -layer metal10 -location {800.095 1176.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[38]} 1
place_pin -pin_name {s_din[38]} -layer metal10 -location {804.095 1180.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[39]} 1
place_pin -pin_name {s_din[39]} -layer metal10 -location {800.095 1184.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[40]} 1
place_pin -pin_name {s_din[40]} -layer metal10 -location {804.095 1188.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[41]} 1
place_pin -pin_name {s_din[41]} -layer metal10 -location {800.095 1192.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[42]} 1
place_pin -pin_name {s_din[42]} -layer metal10 -location {804.095 1196.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[43]} 1
place_pin -pin_name {s_din[43]} -layer metal10 -location {800.095 1200.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[44]} 1
place_pin -pin_name {s_din[44]} -layer metal10 -location {804.095 1204.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[45]} 1
place_pin -pin_name {s_din[45]} -layer metal10 -location {800.095 1208.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[46]} 1
place_pin -pin_name {s_din[46]} -layer metal10 -location {804.095 1212.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[47]} 1
place_pin -pin_name {s_din[47]} -layer metal10 -location {800.095 1216.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[48]} 1
place_pin -pin_name {s_din[48]} -layer metal10 -location {2396.095 1172.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[49]} 1
place_pin -pin_name {s_din[49]} -layer metal10 -location {2400.095 1176.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[50]} 1
place_pin -pin_name {s_din[50]} -layer metal10 -location {2396.095 1180.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[51]} 1
place_pin -pin_name {s_din[51]} -layer metal10 -location {2400.095 1184.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[52]} 1
place_pin -pin_name {s_din[52]} -layer metal10 -location {2396.095 1188.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[53]} 1
place_pin -pin_name {s_din[53]} -layer metal10 -location {2400.095 1192.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[54]} 1
place_pin -pin_name {s_din[54]} -layer metal10 -location {2396.095 1196.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[55]} 1
place_pin -pin_name {s_din[55]} -layer metal10 -location {2400.095 1200.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[56]} 1
place_pin -pin_name {s_din[56]} -layer metal10 -location {2396.095 1204.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[57]} 1
place_pin -pin_name {s_din[57]} -layer metal10 -location {2400.095 1208.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[58]} 1
place_pin -pin_name {s_din[58]} -layer metal10 -location {2396.095 1212.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[59]} 1
place_pin -pin_name {s_din[59]} -layer metal10 -location {2400.095 1216.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[60]} 1
place_pin -pin_name {s_din[60]} -layer metal10 -location {2396.095 1220.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[61]} 1
place_pin -pin_name {s_din[61]} -layer metal10 -location {2400.095 1224.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[62]} 1
place_pin -pin_name {s_din[62]} -layer metal10 -location {2396.095 1228.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[63]} 1
place_pin -pin_name {s_din[63]} -layer metal10 -location {2400.095 1232.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[64]} 1
place_pin -pin_name {s_din[64]} -layer metal10 -location {1200.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[65]} 1
place_pin -pin_name {s_din[65]} -layer metal10 -location {1204.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[66]} 1
place_pin -pin_name {s_din[66]} -layer metal10 -location {1208.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[67]} 1
place_pin -pin_name {s_din[67]} -layer metal10 -location {1212.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[68]} 1
place_pin -pin_name {s_din[68]} -layer metal10 -location {1216.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[69]} 1
place_pin -pin_name {s_din[69]} -layer metal10 -location {1220.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[70]} 1
place_pin -pin_name {s_din[70]} -layer metal10 -location {1224.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[71]} 1
place_pin -pin_name {s_din[71]} -layer metal10 -location {1228.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[72]} 1
place_pin -pin_name {s_din[72]} -layer metal10 -location {1232.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[73]} 1
place_pin -pin_name {s_din[73]} -layer metal10 -location {1236.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[74]} 1
place_pin -pin_name {s_din[74]} -layer metal10 -location {1240.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[75]} 1
place_pin -pin_name {s_din[75]} -layer metal10 -location {1244.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[76]} 1
place_pin -pin_name {s_din[76]} -layer metal10 -location {1248.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[77]} 1
place_pin -pin_name {s_din[77]} -layer metal10 -location {1252.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[78]} 1
place_pin -pin_name {s_din[78]} -layer metal10 -location {1256.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[79]} 1
place_pin -pin_name {s_din[79]} -layer metal10 -location {1260.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[80]} 1
place_pin -pin_name {s_din[80]} -layer metal10 -location {1208.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[81]} 1
place_pin -pin_name {s_din[81]} -layer metal10 -location {1212.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[82]} 1
place_pin -pin_name {s_din[82]} -layer metal10 -location {1216.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[83]} 1
place_pin -pin_name {s_din[83]} -layer metal10 -location {1220.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[84]} 1
place_pin -pin_name {s_din[84]} -layer metal10 -location {1224.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[85]} 1
place_pin -pin_name {s_din[85]} -layer metal10 -location {1228.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[86]} 1
place_pin -pin_name {s_din[86]} -layer metal10 -location {1232.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[87]} 1
place_pin -pin_name {s_din[87]} -layer metal10 -location {1236.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[88]} 1
place_pin -pin_name {s_din[88]} -layer metal10 -location {1240.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[89]} 1
place_pin -pin_name {s_din[89]} -layer metal10 -location {1244.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[90]} 1
place_pin -pin_name {s_din[90]} -layer metal10 -location {1248.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[91]} 1
place_pin -pin_name {s_din[91]} -layer metal10 -location {1252.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[92]} 1
place_pin -pin_name {s_din[92]} -layer metal10 -location {1256.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[93]} 1
place_pin -pin_name {s_din[93]} -layer metal10 -location {1260.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[94]} 1
place_pin -pin_name {s_din[94]} -layer metal10 -location {1264.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[95]} 1
place_pin -pin_name {s_din[95]} -layer metal10 -location {1268.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[96]} 1
place_pin -pin_name {s_din[96]} -layer metal10 -location {804.095 1220.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[97]} 1
place_pin -pin_name {s_din[97]} -layer metal10 -location {800.095 1224.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[98]} 1
place_pin -pin_name {s_din[98]} -layer metal10 -location {804.095 1228.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[99]} 1
place_pin -pin_name {s_din[99]} -layer metal10 -location {800.095 1232.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[100]} 1
place_pin -pin_name {s_din[100]} -layer metal10 -location {804.095 1236.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[101]} 1
place_pin -pin_name {s_din[101]} -layer metal10 -location {800.095 1240.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[102]} 1
place_pin -pin_name {s_din[102]} -layer metal10 -location {804.095 1244.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[103]} 1
place_pin -pin_name {s_din[103]} -layer metal10 -location {800.095 1248.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[104]} 1
place_pin -pin_name {s_din[104]} -layer metal10 -location {804.095 1252.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[105]} 1
place_pin -pin_name {s_din[105]} -layer metal10 -location {800.095 1256.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[106]} 1
place_pin -pin_name {s_din[106]} -layer metal10 -location {804.095 1260.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[107]} 1
place_pin -pin_name {s_din[107]} -layer metal10 -location {800.095 1264.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[108]} 1
place_pin -pin_name {s_din[108]} -layer metal10 -location {804.095 1268.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[109]} 1
place_pin -pin_name {s_din[109]} -layer metal10 -location {800.095 1272.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[110]} 1
place_pin -pin_name {s_din[110]} -layer metal10 -location {804.095 1276.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[111]} 1
place_pin -pin_name {s_din[111]} -layer metal10 -location {800.095 1280.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[112]} 1
place_pin -pin_name {s_din[112]} -layer metal10 -location {2396.095 1236.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[113]} 1
place_pin -pin_name {s_din[113]} -layer metal10 -location {2400.095 1240.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[114]} 1
place_pin -pin_name {s_din[114]} -layer metal10 -location {2396.095 1244.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[115]} 1
place_pin -pin_name {s_din[115]} -layer metal10 -location {2400.095 1248.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[116]} 1
place_pin -pin_name {s_din[116]} -layer metal10 -location {2396.095 1252.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[117]} 1
place_pin -pin_name {s_din[117]} -layer metal10 -location {2400.095 1256.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[118]} 1
place_pin -pin_name {s_din[118]} -layer metal10 -location {2396.095 1260.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[119]} 1
place_pin -pin_name {s_din[119]} -layer metal10 -location {2400.095 1264.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[120]} 1
place_pin -pin_name {s_din[120]} -layer metal10 -location {2396.095 1268.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[121]} 1
place_pin -pin_name {s_din[121]} -layer metal10 -location {2400.095 1272.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[122]} 1
place_pin -pin_name {s_din[122]} -layer metal10 -location {2396.095 1276.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[123]} 1
place_pin -pin_name {s_din[123]} -layer metal10 -location {2400.095 1280.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[124]} 1
place_pin -pin_name {s_din[124]} -layer metal10 -location {2396.095 1284.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[125]} 1
place_pin -pin_name {s_din[125]} -layer metal10 -location {2400.095 1288.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[126]} 1
place_pin -pin_name {s_din[126]} -layer metal10 -location {2396.095 1292.07} -pin_size {2.0 2.0}
dict set planned_pins {s_din[127]} 1
place_pin -pin_name {s_din[127]} -layer metal10 -location {2400.095 1296.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[0]} 1
place_pin -pin_name {s_dout[0]} -layer metal10 -location {1264.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[1]} 1
place_pin -pin_name {s_dout[1]} -layer metal10 -location {1268.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[2]} 1
place_pin -pin_name {s_dout[2]} -layer metal10 -location {1272.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[3]} 1
place_pin -pin_name {s_dout[3]} -layer metal10 -location {1276.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[4]} 1
place_pin -pin_name {s_dout[4]} -layer metal10 -location {1280.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[5]} 1
place_pin -pin_name {s_dout[5]} -layer metal10 -location {1284.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[6]} 1
place_pin -pin_name {s_dout[6]} -layer metal10 -location {1288.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[7]} 1
place_pin -pin_name {s_dout[7]} -layer metal10 -location {1292.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[8]} 1
place_pin -pin_name {s_dout[8]} -layer metal10 -location {1296.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[9]} 1
place_pin -pin_name {s_dout[9]} -layer metal10 -location {1300.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[10]} 1
place_pin -pin_name {s_dout[10]} -layer metal10 -location {1304.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[11]} 1
place_pin -pin_name {s_dout[11]} -layer metal10 -location {1308.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[12]} 1
place_pin -pin_name {s_dout[12]} -layer metal10 -location {1312.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[13]} 1
place_pin -pin_name {s_dout[13]} -layer metal10 -location {1316.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[14]} 1
place_pin -pin_name {s_dout[14]} -layer metal10 -location {1320.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[15]} 1
place_pin -pin_name {s_dout[15]} -layer metal10 -location {1324.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[16]} 1
place_pin -pin_name {s_dout[16]} -layer metal10 -location {1272.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[17]} 1
place_pin -pin_name {s_dout[17]} -layer metal10 -location {1276.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[18]} 1
place_pin -pin_name {s_dout[18]} -layer metal10 -location {1280.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[19]} 1
place_pin -pin_name {s_dout[19]} -layer metal10 -location {1284.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[20]} 1
place_pin -pin_name {s_dout[20]} -layer metal10 -location {1288.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[21]} 1
place_pin -pin_name {s_dout[21]} -layer metal10 -location {1292.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[22]} 1
place_pin -pin_name {s_dout[22]} -layer metal10 -location {1296.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[23]} 1
place_pin -pin_name {s_dout[23]} -layer metal10 -location {1300.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[24]} 1
place_pin -pin_name {s_dout[24]} -layer metal10 -location {1304.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[25]} 1
place_pin -pin_name {s_dout[25]} -layer metal10 -location {1308.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[26]} 1
place_pin -pin_name {s_dout[26]} -layer metal10 -location {1312.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[27]} 1
place_pin -pin_name {s_dout[27]} -layer metal10 -location {1316.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[28]} 1
place_pin -pin_name {s_dout[28]} -layer metal10 -location {1320.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[29]} 1
place_pin -pin_name {s_dout[29]} -layer metal10 -location {1324.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[30]} 1
place_pin -pin_name {s_dout[30]} -layer metal10 -location {1328.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[31]} 1
place_pin -pin_name {s_dout[31]} -layer metal10 -location {1332.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[32]} 1
place_pin -pin_name {s_dout[32]} -layer metal10 -location {804.095 1284.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[33]} 1
place_pin -pin_name {s_dout[33]} -layer metal10 -location {800.095 1288.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[34]} 1
place_pin -pin_name {s_dout[34]} -layer metal10 -location {804.095 1292.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[35]} 1
place_pin -pin_name {s_dout[35]} -layer metal10 -location {800.095 1296.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[36]} 1
place_pin -pin_name {s_dout[36]} -layer metal10 -location {804.095 1300.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[37]} 1
place_pin -pin_name {s_dout[37]} -layer metal10 -location {800.095 1304.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[38]} 1
place_pin -pin_name {s_dout[38]} -layer metal10 -location {804.095 1308.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[39]} 1
place_pin -pin_name {s_dout[39]} -layer metal10 -location {800.095 1312.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[40]} 1
place_pin -pin_name {s_dout[40]} -layer metal10 -location {804.095 1316.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[41]} 1
place_pin -pin_name {s_dout[41]} -layer metal10 -location {800.095 1320.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[42]} 1
place_pin -pin_name {s_dout[42]} -layer metal10 -location {804.095 1324.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[43]} 1
place_pin -pin_name {s_dout[43]} -layer metal10 -location {800.095 1328.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[44]} 1
place_pin -pin_name {s_dout[44]} -layer metal10 -location {804.095 1332.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[45]} 1
place_pin -pin_name {s_dout[45]} -layer metal10 -location {800.095 1336.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[46]} 1
place_pin -pin_name {s_dout[46]} -layer metal10 -location {804.095 1340.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[47]} 1
place_pin -pin_name {s_dout[47]} -layer metal10 -location {800.095 1344.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[48]} 1
place_pin -pin_name {s_dout[48]} -layer metal10 -location {2396.095 1300.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[49]} 1
place_pin -pin_name {s_dout[49]} -layer metal10 -location {2400.095 1304.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[50]} 1
place_pin -pin_name {s_dout[50]} -layer metal10 -location {2396.095 1308.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[51]} 1
place_pin -pin_name {s_dout[51]} -layer metal10 -location {2400.095 1312.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[52]} 1
place_pin -pin_name {s_dout[52]} -layer metal10 -location {2396.095 1316.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[53]} 1
place_pin -pin_name {s_dout[53]} -layer metal10 -location {2400.095 1320.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[54]} 1
place_pin -pin_name {s_dout[54]} -layer metal10 -location {2396.095 1324.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[55]} 1
place_pin -pin_name {s_dout[55]} -layer metal10 -location {2400.095 1328.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[56]} 1
place_pin -pin_name {s_dout[56]} -layer metal10 -location {2396.095 1332.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[57]} 1
place_pin -pin_name {s_dout[57]} -layer metal10 -location {2400.095 1336.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[58]} 1
place_pin -pin_name {s_dout[58]} -layer metal10 -location {2396.095 1340.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[59]} 1
place_pin -pin_name {s_dout[59]} -layer metal10 -location {2400.095 1344.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[60]} 1
place_pin -pin_name {s_dout[60]} -layer metal10 -location {2396.095 1348.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[61]} 1
place_pin -pin_name {s_dout[61]} -layer metal10 -location {2400.095 1352.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[62]} 1
place_pin -pin_name {s_dout[62]} -layer metal10 -location {2396.095 1356.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[63]} 1
place_pin -pin_name {s_dout[63]} -layer metal10 -location {2400.095 1360.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[64]} 1
place_pin -pin_name {s_dout[64]} -layer metal10 -location {1328.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[65]} 1
place_pin -pin_name {s_dout[65]} -layer metal10 -location {1332.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[66]} 1
place_pin -pin_name {s_dout[66]} -layer metal10 -location {1336.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[67]} 1
place_pin -pin_name {s_dout[67]} -layer metal10 -location {1340.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[68]} 1
place_pin -pin_name {s_dout[68]} -layer metal10 -location {1344.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[69]} 1
place_pin -pin_name {s_dout[69]} -layer metal10 -location {1348.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[70]} 1
place_pin -pin_name {s_dout[70]} -layer metal10 -location {1352.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[71]} 1
place_pin -pin_name {s_dout[71]} -layer metal10 -location {1356.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[72]} 1
place_pin -pin_name {s_dout[72]} -layer metal10 -location {1360.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[73]} 1
place_pin -pin_name {s_dout[73]} -layer metal10 -location {1364.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[74]} 1
place_pin -pin_name {s_dout[74]} -layer metal10 -location {1368.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[75]} 1
place_pin -pin_name {s_dout[75]} -layer metal10 -location {1372.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[76]} 1
place_pin -pin_name {s_dout[76]} -layer metal10 -location {1376.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[77]} 1
place_pin -pin_name {s_dout[77]} -layer metal10 -location {1380.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[78]} 1
place_pin -pin_name {s_dout[78]} -layer metal10 -location {1384.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[79]} 1
place_pin -pin_name {s_dout[79]} -layer metal10 -location {1388.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[80]} 1
place_pin -pin_name {s_dout[80]} -layer metal10 -location {1336.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[81]} 1
place_pin -pin_name {s_dout[81]} -layer metal10 -location {1340.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[82]} 1
place_pin -pin_name {s_dout[82]} -layer metal10 -location {1344.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[83]} 1
place_pin -pin_name {s_dout[83]} -layer metal10 -location {1348.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[84]} 1
place_pin -pin_name {s_dout[84]} -layer metal10 -location {1352.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[85]} 1
place_pin -pin_name {s_dout[85]} -layer metal10 -location {1356.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[86]} 1
place_pin -pin_name {s_dout[86]} -layer metal10 -location {1360.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[87]} 1
place_pin -pin_name {s_dout[87]} -layer metal10 -location {1364.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[88]} 1
place_pin -pin_name {s_dout[88]} -layer metal10 -location {1368.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[89]} 1
place_pin -pin_name {s_dout[89]} -layer metal10 -location {1372.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[90]} 1
place_pin -pin_name {s_dout[90]} -layer metal10 -location {1376.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[91]} 1
place_pin -pin_name {s_dout[91]} -layer metal10 -location {1380.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[92]} 1
place_pin -pin_name {s_dout[92]} -layer metal10 -location {1384.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[93]} 1
place_pin -pin_name {s_dout[93]} -layer metal10 -location {1388.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[94]} 1
place_pin -pin_name {s_dout[94]} -layer metal10 -location {1392.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[95]} 1
place_pin -pin_name {s_dout[95]} -layer metal10 -location {1396.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[96]} 1
place_pin -pin_name {s_dout[96]} -layer metal10 -location {804.095 1348.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[97]} 1
place_pin -pin_name {s_dout[97]} -layer metal10 -location {800.095 1352.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[98]} 1
place_pin -pin_name {s_dout[98]} -layer metal10 -location {804.095 1356.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[99]} 1
place_pin -pin_name {s_dout[99]} -layer metal10 -location {800.095 1360.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[100]} 1
place_pin -pin_name {s_dout[100]} -layer metal10 -location {804.095 1364.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[101]} 1
place_pin -pin_name {s_dout[101]} -layer metal10 -location {800.095 1368.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[102]} 1
place_pin -pin_name {s_dout[102]} -layer metal10 -location {804.095 1372.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[103]} 1
place_pin -pin_name {s_dout[103]} -layer metal10 -location {800.095 1376.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[104]} 1
place_pin -pin_name {s_dout[104]} -layer metal10 -location {804.095 1380.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[105]} 1
place_pin -pin_name {s_dout[105]} -layer metal10 -location {800.095 1384.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[106]} 1
place_pin -pin_name {s_dout[106]} -layer metal10 -location {804.095 1388.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[107]} 1
place_pin -pin_name {s_dout[107]} -layer metal10 -location {800.095 1392.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[108]} 1
place_pin -pin_name {s_dout[108]} -layer metal10 -location {804.095 1396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[109]} 1
place_pin -pin_name {s_dout[109]} -layer metal10 -location {800.095 1400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[110]} 1
place_pin -pin_name {s_dout[110]} -layer metal10 -location {804.095 1404.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[111]} 1
place_pin -pin_name {s_dout[111]} -layer metal10 -location {800.095 1408.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[112]} 1
place_pin -pin_name {s_dout[112]} -layer metal10 -location {2396.095 1364.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[113]} 1
place_pin -pin_name {s_dout[113]} -layer metal10 -location {2400.095 1368.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[114]} 1
place_pin -pin_name {s_dout[114]} -layer metal10 -location {2396.095 1372.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[115]} 1
place_pin -pin_name {s_dout[115]} -layer metal10 -location {2400.095 1376.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[116]} 1
place_pin -pin_name {s_dout[116]} -layer metal10 -location {2396.095 1380.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[117]} 1
place_pin -pin_name {s_dout[117]} -layer metal10 -location {2400.095 1384.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[118]} 1
place_pin -pin_name {s_dout[118]} -layer metal10 -location {2396.095 1388.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[119]} 1
place_pin -pin_name {s_dout[119]} -layer metal10 -location {2400.095 1392.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[120]} 1
place_pin -pin_name {s_dout[120]} -layer metal10 -location {2396.095 1396.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[121]} 1
place_pin -pin_name {s_dout[121]} -layer metal10 -location {2400.095 1400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[122]} 1
place_pin -pin_name {s_dout[122]} -layer metal10 -location {2396.095 1404.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[123]} 1
place_pin -pin_name {s_dout[123]} -layer metal10 -location {2400.095 1408.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[124]} 1
place_pin -pin_name {s_dout[124]} -layer metal10 -location {2396.095 1412.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[125]} 1
place_pin -pin_name {s_dout[125]} -layer metal10 -location {2400.095 1416.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[126]} 1
place_pin -pin_name {s_dout[126]} -layer metal10 -location {2396.095 1420.07} -pin_size {2.0 2.0}
dict set planned_pins {s_dout[127]} 1
place_pin -pin_name {s_dout[127]} -layer metal10 -location {2400.095 1424.07} -pin_size {2.0 2.0}
dict set planned_pins {s_ready} 1
place_pin -pin_name {s_ready} -layer metal10 -location {1392.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_req} 1
place_pin -pin_name {s_req} -layer metal10 -location {1396.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {s_take} 1
place_pin -pin_name {s_take} -layer metal10 -location {1400.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {s_valid} 1
place_pin -pin_name {s_valid} -layer metal10 -location {1400.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {s_wr} 1
place_pin -pin_name {s_wr} -layer metal10 -location {1404.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {take[0]} 1
place_pin -pin_name {take[0]} -layer metal10 -location {1404.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {take[1]} 1
place_pin -pin_name {take[1]} -layer metal10 -location {1408.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {take[2]} 1
place_pin -pin_name {take[2]} -layer metal10 -location {1412.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {take[3]} 1
place_pin -pin_name {take[3]} -layer metal10 -location {1416.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {take[4]} 1
place_pin -pin_name {take[4]} -layer metal10 -location {1420.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {take[5]} 1
place_pin -pin_name {take[5]} -layer metal10 -location {1424.095 2400.07} -pin_size {2.0 2.0}
dict set planned_pins {take[6]} 1
place_pin -pin_name {take[6]} -layer metal10 -location {1428.095 2396.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[0]} 1
place_pin -pin_name {valid[0]} -layer metal10 -location {1408.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[1]} 1
place_pin -pin_name {valid[1]} -layer metal10 -location {1412.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[2]} 1
place_pin -pin_name {valid[2]} -layer metal10 -location {1416.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[3]} 1
place_pin -pin_name {valid[3]} -layer metal10 -location {1420.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[4]} 1
place_pin -pin_name {valid[4]} -layer metal10 -location {1424.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[5]} 1
place_pin -pin_name {valid[5]} -layer metal10 -location {1428.095 804.07} -pin_size {2.0 2.0}
dict set planned_pins {valid[6]} 1
place_pin -pin_name {valid[6]} -layer metal10 -location {1432.095 800.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[0]} 1
place_pin -pin_name {wr[0]} -layer metal10 -location {804.095 1412.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[1]} 1
place_pin -pin_name {wr[1]} -layer metal10 -location {800.095 1416.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[2]} 1
place_pin -pin_name {wr[2]} -layer metal10 -location {804.095 1420.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[3]} 1
place_pin -pin_name {wr[3]} -layer metal10 -location {800.095 1424.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[4]} 1
place_pin -pin_name {wr[4]} -layer metal10 -location {804.095 1428.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[5]} 1
place_pin -pin_name {wr[5]} -layer metal10 -location {800.095 1432.07} -pin_size {2.0 2.0}
dict set planned_pins {wr[6]} 1
place_pin -pin_name {wr[6]} -layer metal10 -location {804.095 1436.07} -pin_size {2.0 2.0}
set actual_pins {}
foreach p [[ord::get_db_block] getBTerms] {if {[$p getSigType] ni {POWER GROUND}} {lappend actual_pins [$p getName]}}
if {[lsort $actual_pins] ne [lsort [dict keys $planned_pins]]} {error "Exact macro pin inventory mismatch"}
