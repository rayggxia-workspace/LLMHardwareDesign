from pathlib import Path
import json,hashlib,subprocess,time,tarfile
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');old=b/'source-1772';new=b/'source-1830';out=b/'r256-current-pin-source-audit-1832';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=json.loads((old/'source-manifest.json').read_text());z=json.loads((new/'source-manifest.json').read_text());changed={'project/experiments/control_v1/'+name for name in ['boundary_links.py','current_pin_groups.py','reset_link_banks.py','topology.py']};assert z['commit']=='18438174258a932ef7b348045e210e6dcc334c28'and len(z['files'])==1030 and len(a['files'])==1029 and{p for p,v in z['files'].items()if a['files'].get(p)!=v}==changed
digest='394976659976aa7503d837ab69c4499a76ee4a451b8a0e94591de536efa0e431';archive=b/'source1830.tar.gz';assert sha(archive)==digest and json.loads((new/'freeze-import.json').read_text())['archive_sha256']==digest and all(sha(new/p)==v for p,v in z['files'].items())
with tarfile.open(str(archive))as stream:
 members={m.name:stream.extractfile(m).read()for m in stream.getmembers()};assert set(members)==set(z['files'])|{'source-manifest.json'}and all(hashlib.sha256(members[p]).hexdigest()==v for p,v in z['files'].items())
out.mkdir();scratch=out/'reverse-copies'
for name in changed:
 p=scratch/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((new/name).read_bytes())
patch=b/'control162-backout1830.patch';subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=str(scratch),check=True);subprocess.run(['git','apply','--reverse',str(patch)],cwd=str(scratch),check=True)
for name in changed:
 if name in a['files']:assert(scratch/name).read_bytes()==(old/name).read_bytes()
 else:assert not(scratch/name).exists()
unchanged=[p for p in z['files']if p not in changed];assert len(unchanged)==1026 and all(z['files'][p]==a['files'][p]for p in unchanged)
contract=b/'control162-contract1831.json';r=json.loads(contract.read_text());assert r['passed']and r['default_topology_raw_bytes_exact']and r['default_complete_linkproof_serialization_exact']and len(r['malformed_profiles_rejected'])==9
for name,digest in r['source_sha256'].items():assert sha(new/'project/experiments/control_v1'/name)==digest
assert json.loads((b/'r256-link-grouping-source-audit-1774/receipt.json').read_text())['passed'];scope='1030source/archivefiles fullyverified,1026unchanged; threechangedproducerfiles plusonenewgrouphelper, scratchreversepatch returnsallthreeexactoldfiles andremovesnewfile. AllRTL/nativephysical/router/finalgeometryPG/RC300MHz acceptors unchanged. Defaultfulltopologyrawbytes/linkproofserialization replay and9malformedcontexts rejected. Optionalcurrentnativepins chooseLANEneighbours, oldreference onlycountinventory316links25banks; all23types345owners/state/latency unchanged. New passivewiringrequiresfreshrealprograms/nativeRC/fullphysicalgates; no qualificationtransfer.'
(out/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,source_files=1030,unchanged_files=1026,changed_files=sorted(changed),scratch_backout_exact=True,archive_sha256=sha(archive),inputs={str(new/'source-manifest.json'):sha(new/'source-manifest.json'),str(patch):sha(patch),str(contract):sha(contract)},scope=scope),indent=2));print(json.dumps(dict(passed=True,files=1030,unchanged=1026,backout=True)))
