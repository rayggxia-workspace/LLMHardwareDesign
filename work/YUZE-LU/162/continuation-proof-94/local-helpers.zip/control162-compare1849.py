from pathlib import Path
import json
b=Path(__file__).parent;repo=b/'LLMHardwareDesign-worktrees/issue-162-control';work=repo/'work/YUZE-LU/162';old=json.loads((work/'block-delivery-r256-current363/index.json').read_bytes());s=json.loads((work/'block-delivery-s1350/index.json').read_bytes());bound=json.loads((b/'control162-current1848/source-binding-audit/receipt.json').read_bytes())
for top,row in bound['leaves'].items():
 oldrow=old['leaves'].get(top);six=row['final_files'];same=oldrow is not None and {n:r['sha256']for n,r in six.items()}=={n:r['sha256']for n,r in oldrow['six_files'].items()}
 if not same:
  match=[x for x in s['leaves']if x['top']==top and {n:r['sha256']for n,r in six.items()}=={n:r['sha256']for n,r in x['final_files'].items()}]
  print(top,'matches_s1350',len(match),'oldkeys',list(oldrow)if oldrow else None)
print('root1350keys',list(s));print('oldtypes',len(old['leaves']),'newtypes',len(bound['leaves']))
