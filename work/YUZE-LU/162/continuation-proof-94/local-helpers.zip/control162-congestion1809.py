import subprocess,shlex
q=r'''from pathlib import Path
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-composition-453/upper-candidates/17170/route/openroad-search/case-0/openroad.log'
lines=p.read_text().splitlines();print('OLDGRT','\n'.join(lines[45:155]))
for i,l in enumerate(lines):
 if any(w in l.lower()for w in ['overflow','capacity','resource','congestion','utilization','congested']):print(i,l)
root=b/'r256-arbiter-composition-1773/upper-candidates/18040/route';print('NEWroute',root.exists())
if root.exists():
 print('ROOTFILES',[(p.name,p.stat().st_size)for p in root.iterdir()if p.is_file()])
 p=root/'openroad-search/case-0/openroad.log'
 if p.exists():print('NEWLOG',p.read_text()[-1800:])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35).decode())
