import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-current-pin-composition-1834'
for name in ['native-sta/receipt.json','native-sta/native-system-audit.json','cap-initial-necessary/native-pin-load/native-pin-load.json','cap-candidates/18390/receipt.json','cap-necessary-1839/18390/native-pin-load/native-pin-load.json']:
 p=r/name
 if not p.exists():continue
 d=json.loads(p.read_text());print(name)
 if 'placements'in d:print([{k:x.get(k)for k in ['placement','violations']}for x in d['placements']])
 else:print({k:v for k,v in d.items()if not isinstance(v,(list,dict))})
p=r/'cap-candidates/18390'
for f in sorted(p.glob('electrical-placement-*.log'),key=lambda x:x.stat().st_mtime)[-2:]:
 with f.open('rb')as s:s.seek(max(0,f.stat().st_size-1000));print(f.name,s.read().decode(errors='replace'))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45).decode())
