from pathlib import Path
import subprocess
b=Path(__file__).parent;host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';data=remote+'/r256-cluster-proposal-data-1812'
subprocess.run(['ssh',host,'mkdir',data],check=True)
for name in ['proposal.json','receipt.json']:subprocess.run(['scp',str(b/'control162-milp1810'/name),host+':'+data+'/'+name],check=True)
for name in ['control162-milp1810.py','control162-queue1813-remote.py']:subprocess.run(['scp',str(b/name),host+':'+data+'/'+name],check=True)
subprocess.run(['ssh',host,'python3',data+'/control162-queue1813-remote.py'],check=True)
