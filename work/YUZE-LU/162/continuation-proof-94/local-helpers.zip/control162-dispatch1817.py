from pathlib import Path
import subprocess
p=Path(__file__).parent/'control162-actual1817-remote.py';h='yuzelu@10.129.166.172';r='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'+p.name
subprocess.run(['scp',str(p),h+':'+r],check=True);subprocess.run(['ssh',h,'python3',r],check=True)
