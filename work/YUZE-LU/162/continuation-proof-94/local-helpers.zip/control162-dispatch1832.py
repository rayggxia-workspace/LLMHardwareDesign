from pathlib import Path
import subprocess
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';host='yuzelu@10.129.166.172';names=['project/experiments/control_v1/'+name for name in ['boundary_links.py','current_pin_groups.py','reset_link_banks.py','topology.py']];patch=b/'control162-backout1830.patch';patch.write_bytes(subprocess.check_output(['git','diff','f3fd1ac0791a1254fbb9971d0a5c989ac2312987','18438174258a932ef7b348045e210e6dcc334c28','--',*names],cwd=r))
for path,name in [(patch,patch.name),(b/'control162-groupcheck1831/receipt.json','control162-contract1831.json'),(b/'control162-audit1832-remote.py','control162-audit1832-remote.py')]:subprocess.run(['scp',str(path),host+':'+remote+'/'+name],check=True)
subprocess.run(['ssh',host,'python3',remote+'/control162-audit1832-remote.py'],check=True)
