from pathlib import Path
import subprocess
b=Path(__file__).parent;remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';host='yuzelu@10.129.166.172'
for p,name in [(b/'control162-actual-steiner1829/receipt.json','control162-actual-steiner1829.json'),(b/'control162-retire1833-remote.py','control162-retire1833-remote.py')]:subprocess.run(['scp',str(p),host+':'+remote+'/'+name],check=True)
subprocess.run(['ssh',host,'python3',remote+'/control162-retire1833-remote.py'],check=True)
