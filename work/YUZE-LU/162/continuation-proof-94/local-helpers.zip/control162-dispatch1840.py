from pathlib import Path
import subprocess
p=Path(__file__).parent/'control162-pack1840-remote.py';host='yuzelu@10.129.166.172';r='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'+p.name
compile(p.read_text(encoding='utf-8'),str(p),'exec');subprocess.run(['scp',str(p),host+':'+r],check=True);subprocess.run(['ssh',host,'python3',r],check=True)
