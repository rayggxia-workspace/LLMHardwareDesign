from pathlib import Path
import subprocess,shlex,hashlib
b=Path(__file__).parent;host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
p=b/'control162-strong1847/receipt.json';digest=hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['scp',str(p),host+':'+remote+'/stronger-necessary-1847-received.json'],check=True)
q="""from pathlib import Path
import json,hashlib
b=Path(%r);p=b/'stronger-necessary-1847-received.json';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(p)==%r
d=json.loads(p.read_text());assert d['passed']and d['violations']==dict(low=0,base=0,high=0)and d['rows_checked']==10930
for row in d['inputs'].values():assert Path(row['path']).stat().st_size==row['bytes']and sha(row['path'])==row['sha256']
out=b/'r256-current-pin-composition-1834/stronger-necessary-1847';assert not out.exists();out.mkdir();(out/'receipt.json').write_bytes(p.read_bytes());print('Actual input hashes rechecked; local necessary diagnostic received, no physical qualification.')
"""%(remote,digest)
subprocess.run(['ssh','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(q)],check=True,timeout=45)
p=b/'control162-full1846-remote.py';subprocess.run(['scp',str(p),host+':'+remote+'/'],check=True)
subprocess.run(['ssh','-o','ConnectTimeout=10',host,'python3',remote+'/'+p.name],check=True,timeout=50)
