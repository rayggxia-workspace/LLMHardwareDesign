import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'dynamic-03/node5/00-c-sready1834-initial-placement.log';print(p.read_text()[-5000:]);p=b/'r256-current-pin-composition-1834/cap-initial/receipt.json';print(p.read_text()[-5000:])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35).decode())
