from pathlib import Path
import subprocess,shlex,json,hashlib
h=Path(__file__).parent;out=h/'control162-math-data1790';assert not out.exists();out.mkdir();base='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-arbiter-composition-1773';files={n:'cap-candidates/17750/'+n for n in ['placement.json','placement-search.json','electrical-placement-input.txt','physical-graph.json']};files.update({'physical.json':'selected/physical.json','boundary-graph.json':'topology/boundary-graph.json','native-pin-load.json':'cap-necessary-1775/17750/native-pin-load/native-pin-load.json'})
q="from pathlib import Path;import json,hashlib;files="+repr({k:base+'/'+v for k,v in files.items()})+";print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))"
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50);index=json.loads(raw)
for n,row in index.items():
 subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(out/n)],check=True);data=(out/n).read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'reception.json').write_bytes(raw);print(json.dumps(dict(passed=True,files=len(files),bytes=sum(v['bytes']for v in index.values()),scope='Metadataonly localmathematical inputs; no physicalacceptance')))
