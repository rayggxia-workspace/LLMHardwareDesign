from pathlib import Path
import subprocess,shlex,json,hashlib
b=Path(__file__).parent;out=b/'control162-topology-data1825';assert not out.exists();out.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
q="from pathlib import Path;import json,hashlib;b=Path("+repr(remote)+");m=json.loads((b/'r256-composition-359/selected/physical.json').read_text());files={'original-topology.json':str(b/'r256-arbiter-composition-1773/topology/original-topology.json'),'topology.json':str(b/'r256-arbiter-composition-1773/topology/topology.json'),'old-s-port-pins.json':m['leaves']['control_s_arbiter_r7']['pins'],'old-physical.json':str(b/'r256-composition-359/selected/physical.json')};print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))"
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35);index=json.loads(raw)
for name,row in index.items():subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(out/name)],check=True);data=(out/name).read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'reception.json').write_bytes(raw);print(json.dumps(dict(passed=True,files=len(index),bytes=sum(r['bytes']for r in index.values()))))
