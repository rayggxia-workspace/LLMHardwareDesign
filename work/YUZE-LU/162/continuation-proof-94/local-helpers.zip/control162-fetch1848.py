from pathlib import Path
import subprocess,shlex,json,hashlib
b=Path(__file__).parent;out=b/'control162-current1848';assert not out.exists();out.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';root=remote+'/r256-current-pin-composition-1834'
files={n:root+'/'+n for n in ['selected/physical.json','selected/functions.json','selected/receipt.json','topology/boundary-graph.json','topology/receipt.json','source-binding-audit/receipt.json','final-chain-binding-audit-1846/receipt.json']}
q='from pathlib import Path;import json,hashlib;files='+repr(files)+';print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))'
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);idx=json.loads(raw)
for name,row in idx.items():
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(p)],check=True);data=p.read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'RECEPTION.json').write_bytes(raw);print('Received seven current selection, graph and binding inputs, exact bytes/SHA verified.')
