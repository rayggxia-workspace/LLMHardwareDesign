from pathlib import Path
import json,collections,math
b=Path(__file__).parent/'control162-math-data1790';g=json.loads((b/'boundary-graph.json').read_bytes());p=json.loads((b/'placement.json').read_bytes());sx,sy=p['placements_um']['s_port'];points={}
for bit,c in g['connections'].items():
 if c['driver']['instance']=='s_port':
  xy=p['terminals']['net_'+bit][0];x,y=xy[0]*4+.095-sx,xy[1]*4+.07-sy;points[c['driver']['pin']]=(x,y)
rows=[r for r in g['boundary_links']['links']if r['source_instance']=='s_port'];counts=collections.Counter();groupcost=[]
for row in rows:
 xy=[points[l['source_pin']]for l in row['lanes']];sides=[min(range(4),key=lambda s:[x,3200-x,y,3200-y][s])for x,y in xy];counts.update(sides);span=max(x for x,y in xy)-min(x for x,y in xy)+max(y for x,y in xy)-min(y for x,y in xy);groupcost.append((span,row['instance']))
print('Actual_source_sides',dict(counts));print('Current_worst_group_internal_spans_um',sorted(groupcost,reverse=True)[:12])
for target in sorted({r['fanout_branch']for r in rows}):
 lanes=[l for r in rows if r['fanout_branch']==target for l in r['lanes']];groups=collections.defaultdict(list)
 for lane in lanes:
  x,y=points[lane['source_pin']];side=min(range(4),key=lambda s:[x,3200-x,y,3200-y][s]);groups[side].append((y if side<2 else x,lane))
 chunks=[v[j:j+8]for side in sorted(groups)for v in [sorted(groups[side],key=lambda v:v[0])]for j in range(0,len(v),8)]
 print(target,'new actualpin groups',len(chunks),'sizes',[len(v)for v in chunks])
