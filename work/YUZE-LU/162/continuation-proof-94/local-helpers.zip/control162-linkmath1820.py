from pathlib import Path
import json,sys,math,time,hashlib
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
b=Path(__file__).parent;root=b/'control162-math-data1790';repo=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-linkmath1820';assert not out.exists();out.mkdir();sys.path.insert(0,str(repo/'project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
p=json.loads((root/'placement.json').read_bytes());g=json.loads((root/'physical-graph.json').read_bytes());m=json.loads((root/'physical.json').read_bytes());names=sorted(n for n in g['instances']if n.startswith('link_s_port_'));assert len(names)==80;ids={n:i for i,n in enumerate(names)};nvar=2*len(names);rows=json.loads((root/'native-pin-load.json').read_bytes())['placements'][0]['rows'];nets=[]
for r in rows:
 name=r['net'];con=g['connections'][name[4:]];ends=[con['driver'],*con['sinks']];coords=p['terminals'][name];bound=grid_tree_bound(coords)['necessary_wire_grid_edges'];wire=r['optimistic_total_ff']['high']-r['native_ground_cap_ff'];budget=(r['max_capacitance_ff']-r['native_ground_cap_ff']-r['minimum_input_pin_cap_ff'])*bound/wire
 nets.append((name,[(ids.get(end['instance']),*xy)for end,xy in zip(ends,coords)],budget))
var=nvar+1+4*len(nets);rr=[];cc=[];vv=[];ub=[];binary=[]
def add(items,limit):
 idx=len(ub);ub.append(limit)
 for k,v in items:rr.append(idx);cc.append(k);vv.append(v)
for i in range(nvar):add([(i,1),(nvar,-1)],0);add([(i,-1),(nvar,-1)],0)
rects=[(ids.get(name),name,xy,m['leaves'][g['instances'][name]]['die_um'])for name,xy in p['placements_um'].items()]
for i,(a,name,xy,wh)in enumerate(rects):
 for z,other,zz,zh in rects[:i]:
  if a is None and z is None:continue
  maximum=128*((a is not None)+(z is not None));choices=[(a,z,axis,(zz[axis]-xy[axis]-wh[axis])/4)for axis in range(2)]+[(z,a,axis,(xy[axis]-zz[axis]-zh[axis])/4)for axis in range(2)]
  if any(gap>=maximum for _,_,_,gap in choices):continue
  possible=[v for v in choices if v[3]>=-maximum];assert possible;flags=[]
  for first,second,axis,gap in possible:
   terms=[]
   if first is not None:terms.append((2*first+axis,1))
   if second is not None:terms.append((2*second+axis,-1))
   if len(possible)==1:add(terms,gap);continue
   k=var;var+=1;binary.append(k);flags.append((k,-1));add(terms+[(k,10000)],gap+10000)
  if flags:add(flags,-1)
mst_axes=0
for i,(name,ends,budget)in enumerate(nets):
 lo_x,hi_x,lo_y,hi_y=[nvar+1+4*i+j for j in range(4)]
 for parent,x,y in ends:
  for axis,v,l,h in [(0,x,lo_x,hi_x),(1,y,lo_y,hi_y)]:add([(l,1)]+([]if parent is None else[(2*parent+axis,-1)]),v);add([(h,-1)]+([]if parent is None else[(2*parent+axis,1)]),-v)
 margin=2 if name in ['net_8936','net_8939']else 0;add([(hi_x,1),(lo_x,-1),(hi_y,1),(lo_y,-1)],math.floor(budget+1e-8)-margin)
 if len(ends)>2 and any(v[0]is not None for v in ends):
  used={0};edges=[]
  while len(used)<len(ends):
   _,a,z=min((abs(ends[a][1]-ends[z][1])+abs(ends[a][2]-ends[z][2]),a,z)for a in used for z in range(len(ends))if z not in used);used.add(z);edges.append((a,z))
  total=[]
  for a,z in edges:
   for axis in range(2):
    aa,zz=ends[a],ends[z];constant=aa[axis+1]-zz[axis+1];terms=[]
    if aa[0]is not None:terms.append((2*aa[0]+axis,1))
    if zz[0]is not None:terms.append((2*zz[0]+axis,-1))
    k=var;var+=1;add(terms+[(k,-1)],-constant);add([(u,-v)for u,v in terms]+[(k,-1)],constant);total.append((k,1));mst_axes+=1
  add(total,1.5*(math.floor(budget+1e-8)-margin))
lower=np.zeros(var);upper=np.full(var,np.inf);lower[:nvar]=-128;upper[:nvar]=128;upper[nvar]=128;upper[binary]=1
for name,i in ids.items():
 for axis,extent in [(0,p['width_um']),(1,p['height_um'])]:
  x=p['placements_um'][name][axis];w=m['leaves'][g['instances'][name]]['die_um'][axis];lower[2*i+axis]=max(-128,math.ceil((128-x)/4));upper[2*i+axis]=min(128,math.floor((extent-128-x-w)/4))
c=np.zeros(var);c[nvar]=1;integrality=np.zeros(var);integrality[:nvar]=1;integrality[binary]=1;A=coo_matrix((vv,(rr,cc)),shape=(len(ub),var)).tocsc();started=time.time();res=milp(c,integrality=integrality,bounds=Bounds(lower,upper),constraints=LinearConstraint(A,np.full(len(ub),-np.inf),ub),options=dict(time_limit=45,mip_rel_gap=0));receipt=dict(status=int(res.status),message=res.message,variables=var,constraints=len(ub),mst_edge_axes=mst_axes,seconds=time.time()-started,whole_system_qualified=False,feasible=False,scope='Local mathematical proposal ONLY;80 existing s_port Link8s independently translated, all other265rectangles fixed. All main/native block interiors,345instances,316links,netlist/graph,die andexternalpins unchanged. Original all10930 native/pin highRC budgets plus stronger2/3MST necessary bound, no gate/threshold change. Production proposalvalidator andactualpinreconstruction notyetimplemented; no physicalproof.')
if res.x is not None:
 x=res.x;assert np.max(A@x-np.array(ub))<1e-5 and max(abs(x[:nvar]-np.round(x[:nvar])))<1e-5;shifts={name:[int(round(v))*4 for v in x[2*i:2*i+2]]for name,i in ids.items()};candidate=json.loads(json.dumps(p))
 for name in names:candidate['placements_um'][name]=[p['placements_um'][name][axis]+shifts[name][axis]for axis in range(2)]
 for name,con in g['connections'].items():
  net='net_'+name;ends=[con['driver'],*con['sinks']];candidate['terminals'][net]=[[xy[axis]+shifts.get(end['instance'],[0,0])[axis]//4 for axis in range(2)]for end,xy in zip(ends,p['terminals'][net])]
 for i,(a,name,_,wh)in enumerate(rects):
  xx,yy=candidate['placements_um'][name]
  for z,other,_,zh in rects[:i]:
   xz,yz=candidate['placements_um'][other];assert xx+wh[0]<=xz or xz+zh[0]<=xx or yy+wh[1]<=yz or yz+zh[1]<=yy,(name,other)
 points=[tuple(xy)for coords in candidate['terminals'].values()for xy in coords];assert len(points)==len(set(points));margins=[]
 for name,ends,budget in nets:
  bounds=grid_tree_bound(candidate['terminals'][name]);length=max(bounds['hpwl_grid_edges'],math.ceil(2*bounds['metric_mst_grid_edges']/3));assert length<=budget+1e-6,(name,length,budget);margins.append((budget-length)*4)
 receipt.update(feasible=True,shifts_um=shifts,max_shift_um=max(abs(v)for xy in shifts.values()for v in xy),stronger_minimum_margin_um=min(margins));(out/'candidate-math-only.json').write_text(json.dumps(candidate))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
