from pathlib import Path
import json,sys,hashlib,time
b=Path(r'D:\Data\电路实验');root=b/'control162-math-data1790';repo=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-math1791';assert not out.exists();out.mkdir()
for name,rec in json.loads((root/'reception.json').read_bytes()).items():
 data=(root/name).read_bytes();assert len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256']
sys.path.insert(0,str(repo/'project/experiments/control_v1'))
from steiner_wire_bound import grid_tree_bound
from cluster_shift_proposal import apply
p=json.loads((root/'placement.json').read_bytes());g=json.loads((root/'physical-graph.json').read_bytes());m=json.loads((root/'physical.json').read_bytes());search=json.loads((root/'placement-search.json').read_bytes());clusters=search['electrical_refinement']['clusters'];parents={n:v['parent']for n,v in clusters['members'].items()};rows=json.loads((root/'native-pin-load.json').read_bytes())['placements'][0]['rows'];by={r['net']:r for r in rows};affected={name for name,c in g['connections'].items()if any(e['instance']=='reset_distribution'for e in[c['driver'],*c['sinks']])};affected={'net_'+x for x in affected};prepared=[]
for name in affected:
 if name not in by:continue
 r=by[name];con=g['connections'][name[4:]];ends=[con['driver'],*con['sinks']];coords=p['terminals'][name];bound=grid_tree_bound(coords)['necessary_wire_grid_edges'];assert bound>0
 coeff={v:(r['optimistic_total_ff'][v]-r['native_ground_cap_ff'])/bound for v in ['low','base','high']}
 prepared.append((name,ends,coords,r,coeff))
rects=[]
for name,xy in p['placements_um'].items():rects.append((name,*xy,*m['leaves'][g['instances'][name]]['die_um']))
rx,ry=p['placements_um']['reset_distribution'];rw,rh=m['leaves'][g['instances']['reset_distribution']]['die_um'];attempts=[];solution=None;started=time.time()
# Smallest grid translations first; individual block motion only, all other rigid groups fixed.
candidates=sorted([(x,y)for x in range(-128,129)for y in range(-128,129)],key=lambda z:(abs(z[0])+abs(z[1]),max(abs(z[0]),abs(z[1])),z))
for dx,dy in candidates:
 x,y=rx+dx*4,ry+dy*4
 if min(x,y)<128 or x+rw+128>p['width_um']or y+rh+128>p['height_um']:continue
 if any(not(x+rw<=xx or xx+w<=x or y+rh<=yy or yy+h<=y)for name,xx,yy,w,h in rects if name!='reset_distribution'):continue
 worst=-1e30;bad=False
 for name,ends,coords,r,coeff in prepared:
  new=[[xy[0]+(dx if e['instance']=='reset_distribution'else 0),xy[1]+(dy if e['instance']=='reset_distribution'else 0)]for e,xy in zip(ends,coords)]
  bound=grid_tree_bound(new)['necessary_wire_grid_edges'];excess=max(r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+coeff[v]*bound-r['max_capacitance_ff']for v in coeff);worst=max(worst,excess)
  if excess>1e-7:bad=True;break
 if not bad:
  shifts={n:[0,0]for n in clusters['dimensions']};shifts['reset_distribution']=[dx*4,dy*4]
  proposal=dict(schema='control162-rigid-cluster-shifts/1',candidate_only=True,whole_system_qualified=False,base_sha256=hashlib.sha256((root/'placement.json').read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256((root/'physical.json').read_bytes()).hexdigest(),graph_sha256=hashlib.sha256((root/'boundary-graph.json').read_bytes()).hexdigest(),shifts_um=shifts)
  pp=out/'proposal.json';pp.write_text(json.dumps(proposal,indent=2))
  try:candidate,proof,bindings=apply(pp,root/'placement.json',root/'physical.json',root/'boundary-graph.json',p,m,g)
  except AssertionError as exc:attempts.append(dict(shift_um=[dx*4,dy*4],rejected=str(exc)));continue
  solution=dict(shift_um=[dx*4,dy*4],worst_affected_excess_ff=worst,proof=proof,bindings=bindings);break
assert solution,dict(failed=True,attempts=attempts,seconds=time.time()-started)
violations={v:[]for v in ['low','base','high']};minimum={v:1e30 for v in violations}
for r in rows:
 name=r['net'];old=grid_tree_bound(p['terminals'][name])['necessary_wire_grid_edges'];new=grid_tree_bound(candidate['terminals'][name])['necessary_wire_grid_edges']
 for v in violations:
  wire=r['optimistic_total_ff'][v]-r['native_ground_cap_ff'];value=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+wire*new/old if old else r['optimistic_total_with_minimum_pin_ff'][v];margin=r['max_capacitance_ff']-value;minimum[v]=min(minimum[v],margin)
  if margin < -1e-7:violations[v].append(name)
assert not any(violations.values()),violations
(out/'candidate-math-only.json').write_text(json.dumps(candidate))
receipt=dict(passed=True,whole_system_qualified=False,solution=solution,all_actual_rows=len(rows),violations=violations,minimum_necessary_margin_ff=minimum,elapsed_seconds=time.time()-started,rejected_terminal_overlap_candidates=attempts,scope='Bounded local mathematical proposal only. New1773 3200um arbiter and17750 nativeRC/pin budgets. One existing reset block translated, other28 groups unchanged; no source/gate/mask change. Actual source1772 native-pin reconstruction, original3RC cap preflight and full7stage physical acceptance still required.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
