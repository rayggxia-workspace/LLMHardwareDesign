from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');out=b/'r256-sarbiter3200-local-reception-1840';assert not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();manifest=b/'r256-current-pin-composition-1834/selected/physical.json';m=json.loads(manifest.read_text());row=m['leaves']['control_s_arbiter_r7'];delivery=Path(row['fixed_pg_delivery']['path']);receipt=Path(row['fixed_pg_delivery']['receipt']);d=json.loads(delivery.read_text());r=json.loads(receipt.read_text());assert sha(delivery)==row['fixed_pg_delivery']['sha256']and sha(receipt)==row['fixed_pg_delivery']['receipt_sha256']and r['passed']and r['native_leaf_qualified']and d['passed']and d['native_leaf_accepted']and d['die_um']==[3200,3200]and d['final_files']==row['final_files'];names={'6_final.v','6_final.sdc','6_final.def','6_final.odb','6_final.spef','6_final.gds'};assert set(d['final_files'])==names;members={}
for name,v in d['final_files'].items():p=Path(v['path']);assert sha(p)==v['sha256'];members[name]=p
members.update({'layout.png':delivery.parent/'layout.png','delivery.json':delivery,'receipt.json':receipt,'original-native-delivery.json':Path(d['original_delivery'])})
for sub in ['wrapper','checks/physical','checks/timing']:
 p=b/'r256-arbiter-fixed-pg-1741/17380'/sub/'receipt.json';assert json.loads(p.read_text())['passed'];members['gates/'+sub.replace('/','-')+'.json']=p
native=json.loads(Path(d['original_delivery']).read_text());assert native['passed']and native['native_leaf_accepted']
for name,value in native.get('gate_receipts',{}).items():
 if isinstance(value,dict)and'path'in value:
  p=Path(value['path']);assert sha(p)==value['sha256']and json.loads(p.read_text())['passed'];members['native-gates/'+name+'.json']=p
assert all(p.exists()and p.is_file()for p in members.values());out.mkdir();archive=out/'control_s_arbiter_r7-3200um-final.zip';index={name:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for name,p in members.items()}
with zipfile.ZipFile(str(archive),'w',zipfile.ZIP_DEFLATED,allowZip64=True)as stream:
 for name,p in members.items():stream.write(str(p),name)
result=dict(passed=True,time=time.time(),whole_system_qualified=False,physical_type='control_s_arbiter_r7',die_um=[3200,3200],selected_manifest=str(manifest),selected_manifest_sha256=sha(manifest),members=index,archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Actual qualified3200umSarbiter sixfinalfiles plusrealPG/nativeacceptance receipts andactualGDS layout forlocalreception. Packaging only; no rerun/no filemodification and no wholecompositionqualification. Consumer mustverifyarchiveCRC andeverymember bytes/SHA againstthisindex.')
(out/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,members=len(index),six_files=6,archive=result['archive'])))
