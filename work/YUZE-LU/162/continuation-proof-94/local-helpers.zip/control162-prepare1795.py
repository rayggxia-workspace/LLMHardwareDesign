from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-milp1794.py').read_text(encoding='utf-8').replace("out=b/'control162-milp1794'","out=b/'control162-milp1795'")
s=s.replace('if len(ends)>2:',"if name in {'net_8939'}:")
s=s.replace('math.floor(budget+1e-8)-2','math.floor(budget+1e-8)-(2 if name==\'net_8939\'else 0)')
s=s.replace('assert length<=budget-2+1e-6,(name,length,budget);margins.append','assert length<=budget+1e-6,(name,length,budget);margins.append')
(b/'control162-milp1795.py').write_text(s,encoding='utf-8')
