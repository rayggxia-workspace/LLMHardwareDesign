from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-milp1795.py').read_text(encoding='utf-8').replace("out=b/'control162-milp1795'","out=b/'control162-milp1796'")
old="for axis,extent in [(0,p['width_um']),(1,p['height_um'])]:lower[2*i+axis]=max(-128,math.ceil((128-origins[i,axis])/4));upper[2*i+axis]=min(128,math.floor((extent-128-origins[i,axis]-dims[i,axis])/4))"
new="""for axis,extent in [(0,p['width_um']),(1,p['height_um'])]:
  members=[n for n in g['instances']if parents[n]==i];minimum=min(p['placements_um'][n][axis]for n in members);maximum=max(p['placements_um'][n][axis]+m['leaves'][g['instances'][n]]['die_um'][axis]for n in members)
  lower[2*i+axis]=max(-128,math.ceil((128-minimum)/4));upper[2*i+axis]=min(128,math.floor((extent-128-maximum)/4))"""
assert old in s;s=s.replace(old,new);(b/'control162-milp1796.py').write_text(s,encoding='utf-8')
