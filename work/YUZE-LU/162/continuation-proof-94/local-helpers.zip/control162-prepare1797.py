from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-milp1796.py').read_text(encoding='utf-8').replace("out=b/'control162-milp1796'","out=b/'control162-milp1797'")
# Debug ONLY: drop offending net from MILP, retain all others; no candidate acceptance if actual violation persists.
s=s.replace("nets.append((name,", "if name=='net_8939':continue\n nets.append((name,")
(b/'control162-milp1797.py').write_text(s,encoding='utf-8')
