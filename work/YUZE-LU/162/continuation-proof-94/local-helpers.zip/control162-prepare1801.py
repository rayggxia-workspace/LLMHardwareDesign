from pathlib import Path
b=Path(r'D:\Data\电路实验');s=(b/'control162-milp1796.py').read_text(encoding='utf-8').replace("out=b/'control162-milp1796'","out=b/'control162-milp1801'")
start=s.index('for i in range(29):\n for j in range(i):');end=s.index('mst_edges=0',start)
s=s[:start]+'''binary=[];rects=[]
for name,xy in p['placements_um'].items():rects.append((parents[name],xy,m['leaves'][g['instances'][name]]['die_um']))
for i,(a,xy,wh)in enumerate(rects):
 for z,zz,zh in rects[:i]:
  if a==z:continue
  choices=[(a,z,axis,(zz[axis]-xy[axis]-wh[axis])/4)for axis in range(2)]+[(z,a,axis,(xy[axis]-zz[axis]-zh[axis])/4)for axis in range(2)]
  if any(gap>=256 for _,_,_,gap in choices):continue
  possible=[v for v in choices if v[3]>=-256]
  assert possible
  flags=[]
  for first,second,axis,gap in possible:
   if len(possible)==1:add([(2*first+axis,1),(2*second+axis,-1)],gap);continue
   k=var;var+=1;binary.append(k);flags.append((k,-1));add([(2*first+axis,1),(2*second+axis,-1),(k,10000)],gap+10000)
  if flags:add(flags,-1)
''' + s[end:]
s=s.replace('integrality[:58]=1;', 'integrality[:58]=1;integrality[binary]=1;upper[binary]=1;')
(b/'control162-milp1801.py').write_text(s,encoding='utf-8')
