from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-full1787-remote.py').read_text(encoding='utf-8').replace('sready1787','sready1804').replace('17870','18040').replace('cap-candidates/17750','cap-candidates/18020').replace('cap-necessary-1775/17750','cap-necessary-1803/18020')
# Remap the old17130 placement directly to the accepted fresh reconstruction.
s=s.replace("'/cap-candidates/17750'","'/cap-candidates/18020'")
compile(s,'full1804','exec');(b/'control162-full1804-remote.py').write_text(s,encoding='utf-8')
