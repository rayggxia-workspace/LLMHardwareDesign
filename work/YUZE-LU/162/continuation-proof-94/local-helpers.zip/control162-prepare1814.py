from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-full1804-remote.py').read_text(encoding='utf-8').replace('sready1804','sready1814').replace('18040','18140').replace('cap-candidates/18020','cap-candidates/18120').replace('cap-necessary-1803/18020','cap-necessary-1813/18120').replace("audit=root/'final-chain-binding-audit'","audit=root/'final-chain-binding-audit-1814'")
s=s.replace("a[a.index('--seed')+1]=str(seed)","a[a.index('--seed')+1]=str(seed);a[a.index('--openroad-global-router')+1]='fastroute'")
s=s.replace("a[a.index('--openroad-global-router')+1]=='cugr'","a[a.index('--openroad-global-router')+1]=='fastroute'")
s=s.replace("folder='dynamic-05/node4'if spec['script']=='system_sta.py'else'dynamic-03/node5'","folder='dynamic-05/node4'if spec['script']in ['system_sta.py','system_upper.py']else'dynamic-03/node5'")
s=s.replace('original7stage backendCUGR','original7stage existingFastRoute backend').replace('Existingnode5naturallyfreeddiagnosticslot andnode4STA','Existingnode4naturallyfreeddiagnosticslot forroute andSTAwithactualmemoryadmission')
compile(s,'full1814','exec');(b/'control162-full1814-remote.py').write_text(s,encoding='utf-8')
w=(b/'control162-watch1806.py').read_text(encoding='utf-8').replace('watch1806','watch1815').replace('18020','18120').replace('cap-necessary-1803','cap-necessary-1813').replace('sready1803','sready1813').replace('full1804','full1814').replace('18040','18140');compile(w,'watch1815','exec');(b/'control162-watch1815.py').write_text(w,encoding='utf-8')
