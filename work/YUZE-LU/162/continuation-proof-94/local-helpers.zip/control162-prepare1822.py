from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-linkmath1821.py').read_text(encoding='utf-8').replace("out=b/'control162-linkmath1821'","out=b/'control162-linkmath1822'")
start=s.index('  possible=[v for v in choices');end=s.index('mst_axes=0',start)
s=s[:start]+'''  first,second,axis,gap=max(choices,key=lambda v:v[3]);assert gap>=0;terms=[]
  if first is not None:terms.append((2*first+axis,1))
  if second is not None:terms.append((2*second+axis,-1))
  add(terms,gap)
''' + s[end:]
(b/'control162-linkmath1822.py').write_text(s,encoding='utf-8')
