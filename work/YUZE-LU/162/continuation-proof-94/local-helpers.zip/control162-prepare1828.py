from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-groupcheck1827.py').read_text(encoding='utf-8').replace("out=b/'control162-groupcheck1827'","out=b/'control162-groupcheck1828'")
needle="(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))"
extra="""from current_pin_groups import balance,spatial_reset_order
rejections=[]
def reject(name,call):
 try:call()
 except (AssertionError,KeyError):rejections.append(name)
 else:raise AssertionError('Malformed profile accepted: '+name)
chunks=[(0,'dest',[(0,'p0',1,[]),(4,'p1',2,[])])]
reject('too_few_reference_groups',lambda:balance('s',chunks,{('s','dest'):0}))
reject('more_groups_than_lanes',lambda:balance('s',chunks,{('s','dest'):3}))
reject('missing_destination',lambda:balance('s',chunks,{}))
reject('extra_destination',lambda:balance('s',chunks,{('s','dest'):1,('s','other'):1}))
reject('missing_reference_link',lambda:reference_counts(lp['links'][:-1]))
bad=copy.deepcopy(lp['links']);next(r for r in bad if r['source_instance']=='s_port')['fanout_branch']='invalid';reject('changed_reference_target',lambda:reference_counts(bad))
sr=[r for r in proof['links']if r['source_instance']=='s_port'];reject('missing_spatial_load',lambda:spatial_reset_order(sr[:-1]))
bad=copy.deepcopy(sr);bad[0]['source_pin_die_um']=[1470,1470];reject('wrong_native_die',lambda:spatial_reset_order(bad))
bad=copy.deepcopy(sr);bad[0]['source_instance']='macro_s';reject('wrong_spatial_owner',lambda:spatial_reset_order(bad))
receipt['malformed_profiles_rejected']=rejections;assert len(rejections)==9
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))"""
assert needle in s;s=s.replace(needle,extra);(b/'control162-groupcheck1828.py').write_text(s,encoding='utf-8')
