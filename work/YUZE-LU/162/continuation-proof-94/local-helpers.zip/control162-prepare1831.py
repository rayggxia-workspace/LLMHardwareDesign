from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-groupcheck1828.py').read_text(encoding='utf-8').replace("out=b/'control162-groupcheck1828'","out=b/'control162-groupcheck1831'")
s=s.replace("prior.pop('grouping_reference');assert lp==prior,'Default grouping proof changed'","prior.pop('grouping_reference');assert lp==prior,'Default grouping proof changed';assert json.dumps(lp,indent=2)==json.dumps(prior,indent=2);legacy_document=json.loads((t/'original-topology.json').read_bytes());legacy_document['modules']['control_system']=legacy;assert (json.dumps(legacy_document,indent=2)+'\\n').encode()==(t/'topology.json').read_bytes(),'Default full topology rawbytes changed'")
s=s.replace('default_topology_and_complete_linkproof_byte_equivalent=True','default_topology_raw_bytes_exact=True,default_complete_linkproof_serialization_exact=True')
(b/'control162-groupcheck1831.py').write_text(s,encoding='utf-8')
