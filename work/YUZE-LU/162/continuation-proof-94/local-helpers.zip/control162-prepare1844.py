from pathlib import Path
b=Path(__file__).parent
for old,new in [('functionaudit1780-remote','functionaudit1843-remote'),('traces1780-remote','traces1843-remote')]:
 s=(b/('control162-'+old+'.py')).read_text(encoding='utf-8').replace('r256-arbiter-composition-1773','r256-current-pin-composition-1834').replace('source-1772','source-1830').replace('sready1780','sready1843').replace('r256-link-grouping-source-audit-1774','r256-current-pin-source-audit-1832').replace('dynamic-02/node3','dynamic-03/node5').replace('candidate1757','actual-pin-balanced316 scene1834').replace('New1757actualcompiled','New1834actualcompiled')
 compile(s,new,'exec');(b/('control162-'+new+'.py')).write_text(s,encoding='utf-8')
w=(b/'control162-watch1785.py').read_text(encoding='utf-8').replace('watch1785','watch1844').replace('r256-arbiter-composition-1773','r256-current-pin-composition-1834').replace('dynamic-02/node3','dynamic-03/node5').replace('sready1773-function','sready1834-function').replace('fresh1773','fresh1834').replace('Actual1773','Actual1834').replace('functionaudit1780','functionaudit1843').replace('traces1780','traces1843').replace('existingnode3','existingnode5')
compile(w,'watch1844','exec');(b/'control162-watch1844.py').write_text(w,encoding='utf-8')
