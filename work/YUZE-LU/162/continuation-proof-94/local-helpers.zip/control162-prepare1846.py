from pathlib import Path
import difflib
b=Path(__file__).parent
old=(b/'control162-full1804-remote.py').read_text(encoding='utf-8')
s=old.replace('r256-arbiter-composition-1773','r256-current-pin-composition-1834').replace('source-1772','source-1830').replace('sready1804','sready1846').replace("audit=root/'final-chain-binding-audit'","audit=root/'final-chain-binding-audit-1846'").replace('sready1773-arbiter-qualified-scene','sready1842-current-scene-parallel-refill').replace('cap-candidates/18020','cap-candidates/18390').replace('cap-necessary-1803/18020','cap-necessary-1839/18390').replace('r256-link-grouping-source-audit-1774','r256-current-pin-source-audit-1832').replace('seed=18040','seed=18460').replace('/upper-candidates/18040/','/upper-candidates/18460/').replace('acceptance-18040.json','acceptance-18460.json')
s=s.replace("'project/experiments/control_v1/topology.py'}","'project/experiments/control_v1/topology.py','project/experiments/control_v1/boundary_links.py','project/experiments/control_v1/reset_link_banks.py','project/experiments/control_v1/current_pin_groups.py'}")
s=s.replace("folder='dynamic-05/node4'if spec['script']=='system_sta.py'else'dynamic-03/node5'","folder='dynamic-05/node4'")
s=s.replace("binding=root/'source-binding-audit/receipt.json';assert", "binding=root/'source-binding-audit/receipt.json';assert")
anchor="placement=json.loads((place/'placement.json').read_text());"
extra="""strong=root/'stronger-necessary-1847/receipt.json';sr=json.loads(strong.read_text());assert sr['passed']and sr['whole_system_qualified']is False and sr['violations']==dict(low=0,base=0,high=0)
assert sr['placement_sha256']==sha(place/'placement.json')and sr['native_pin_load_sha256']==sha(pin)
assert sr['rows_checked']==len(pd['placements'][0]['rows'])
"""
assert anchor in s;s=s.replace(anchor,extra+anchor)
s=s.replace("binding,place/'receipt.json',b/'r256-current-pin-source-audit-1832/receipt.json'", "binding,strong,place/'receipt.json',b/'r256-current-pin-source-audit-1832/receipt.json'")
s=s.replace('functions,fsp,binding,pin,','functions,fsp,binding,strong,pin,')
s=s.replace('source1690_only_four_nonrouter_changes','source1690_only_seven_nonrouter_changes').replace('fourchangesoutside','sevenchangesoutside').replace('fourchanges','sevenchanges').replace('Strictfresh1773','Strictfresh1834').replace('fresh3initial8programs','fresh1834threeinitialeightprograms').replace('Onefreshfullcandidate18040','Onefreshfullcandidate18460').replace('Existingnode5naturallyfreeddiagnosticslot andnode4STA','Existingnode4naturallyfreedplacementslot andnode4STA')
assert '18020'not in s and '1772'not in s and '18040'not in s
compile(s,'full1846','exec');(b/'control162-full1846-remote.py').write_text(s,encoding='utf-8')
(b/'control162-full1846-review.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='template1804',tofile='current1846')),encoding='utf-8')
print('Prepared reviewable seven-stage chain; NOT queued; actual original and stronger necessary checks required.')
