import subprocess,shlex
q=r'''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-arbiter-composition-1773';obj=r/'function/obj'
if obj.exists():
 sub=obj/'Vblock_feed_s_macro';print('Scompile',len(list(sub.glob('*.cpp'))),'cpp',len(list(sub.glob('*.o'))),'objects')
p=r/'function/build.log'
with p.open('rb')as f:f.seek(max(0,p.stat().st_size-450));print('FUNCTION',f.read().decode(errors='replace'))
for sub in ['function','function-audit','internal-program-traces','upper-candidates/18040/route','upper-candidates/18040/geometry','upper-candidates/18040/pg-audit','upper-candidates/18040/delivery']:
 p=r/sub/'receipt.json'
 if p.exists():d=json.loads(p.read_text());print('RECEIPT',sub,{k:d.get(k)for k in ['passed','stage','whole_system_qualified','execution_passed']})
for candidate in [18040,18140]:
 p=r/('upper-candidates/'+str(candidate)+'/route/openroad-search/case-0/openroad.log')
 if p.exists():
  lines=p.read_text().splitlines();print('ROUTETAIL',candidate,'\n'.join(lines[-5:]));print('GRT',candidate,[l for l in lines if any(w in l for w in ['Total congestion:','Total wirelength:','CUGR congestion','Number of violations =','metal11   H','metal12   V','overflow'])][-10:])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35).decode())
