from pathlib import Path
import subprocess,json,hashlib,zipfile,time
b=Path(__file__).parent;out=b/'control162-final-sarbiter3200-1841';assert not out.exists();out.mkdir();host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-sarbiter3200-local-reception-1840';receipt=out/'remote-receipt.json';subprocess.run(['scp',host+':'+remote+'/receipt.json',str(receipt)],check=True);d=json.loads(receipt.read_bytes());assert d['passed']and not d['whole_system_qualified'];archive=out/Path(d['archive']['path']).name;subprocess.run(['scp',host+':'+d['archive']['path'],str(archive)],check=True)
def digest(stream):
 h=hashlib.sha256();size=0
 while True:
  data=stream.read(1024*1024)
  if not data:break
  size+=len(data);h.update(data)
 return size,h.hexdigest()
with archive.open('rb')as stream:size,sha=digest(stream)
assert size==d['archive']['bytes']and sha==d['archive']['sha256'];received={}
with zipfile.ZipFile(archive)as stream:
 assert set(stream.namelist())==set(d['members'])and len(stream.infolist())==len(d['members'])
 for name,r in d['members'].items():
  assert not Path(name).is_absolute()and'..'not in Path(name).parts
  with stream.open(name)as f:count,sha=digest(f)
  assert count==r['bytes']==stream.getinfo(name).file_size and sha==r['sha256'];received[name]=dict(bytes=count,sha256=sha,crc_verified=True)
 layout=stream.read('layout.png');assert hashlib.sha256(layout).hexdigest()==d['members']['layout.png']['sha256'];(out/'layout.png').write_bytes(layout)
names={'6_final.'+suffix for suffix in ['v','sdc','def','odb','spef','gds']};assert names<=set(received);result=dict(passed=True,time=time.time(),whole_system_qualified=False,physical_type=d['physical_type'],die_um=d['die_um'],archive=dict(path=str(archive.resolve()),bytes=d['archive']['bytes'],sha256=d['archive']['sha256']),remote_receipt_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest(),actual_six_files_verified=6,members=received,scope='Actualnew3200um S-arbiter finalV/SDC/DEF/ODB/SPEF/GDS pluslayout andgateproofs locallyreceived. EveryZIPmember uncompressedCRC/bytes/SHA verified againstactualremoteacceptedselectedlibrary. Individualleafdelivery only; freshwholecombinationphysical/function/RCqualification stillrequired.')
(out/'RECEPTION.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(passed=True,six_files=6,members=len(received),archive_bytes=d['archive']['bytes'],raw_bytes=sum(v['bytes']for v in received.values()),whole_system_qualified=False)))
