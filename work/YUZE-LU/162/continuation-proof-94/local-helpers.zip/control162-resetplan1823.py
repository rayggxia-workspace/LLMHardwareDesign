from pathlib import Path
import json,sys,math,hashlib,collections
b=Path(__file__).parent;root=b/'control162-math-data1790';repo=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-resetplan1823';assert not out.exists();out.mkdir();sys.path.insert(0,str(repo/'project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
g=json.loads((root/'boundary-graph.json').read_bytes());p=json.loads((root/'placement.json').read_bytes());links=g['boundary_links'];banks=[row for row in links['reset_banks']['banks']if row['source_instance']=='s_port'];assert len(banks)==7;names=[name for bank in banks for name in bank['link_instances']];assert len(names)==102 and len(set(names))==102;endpoint={}
for bit,con in g['connections'].items():
 for end,xy in zip([con['driver'],*con['sinks']],p['terminals']['net_'+bit]):endpoint[(end['instance'],end['pin'])]=xy
rows={r['instance']:r for r in links['links']};sx,sy=p['placements_um']['s_port'];cx,cy=sx+1600,sy+1600;ordered=sorted(names,key=lambda n:math.atan2(p['placements_um'][n][1]+50-cy,p['placements_um'][n][0]+50-cx));best=None
for reverse in [False,True]:
 sequence=ordered[::-1]if reverse else ordered
 for offset in range(len(sequence)):
  rotated=sequence[offset:]+sequence[:offset];chunks=[];start=0
  for bank in banks:
   n=len(bank['link_instances']);chunks.append(rotated[start:start+n]);start+=n
  metrics=[]
  for bank,chunk in zip(banks,chunks):
   points=[endpoint[('reset_distribution','reset_out['+str(bank['output'])+']')]]
   for n in chunk:points.append(endpoint[(n,'reset')]);points.extend(endpoint[(n,'in_data['+str(lane)+']')]for lane in range(len(rows[n]['lanes']),8))
   bounds=grid_tree_bound(points);metrics.append(max(bounds['hpwl_grid_edges'],math.ceil(2*bounds['metric_mst_grid_edges']/3))*4)
  score=(max(metrics),sum(metrics),reverse,offset)
  if best is None or score<best[0]:best=(score,chunks,metrics)
proposal=dict(schema='control162-reset-bank-membership/1',candidate_only=True,whole_system_qualified=False,source_instance='s_port',reference_graph_sha256=hashlib.sha256((root/'boundary-graph.json').read_bytes()).hexdigest(),reference_manifest_sha256=hashlib.sha256((root/'physical.json').read_bytes()).hexdigest(),reference_placement_sha256=hashlib.sha256((root/'placement.json').read_bytes()).hexdigest(),banks=[dict(output=bank['output'],link_instances=chunk)for bank,chunk in zip(banks,best[1])])
(out/'proposal.json').write_text(json.dumps(proposal,indent=2));receipt=dict(passed=True,whole_system_qualified=False,method='204 deterministic angular rotations, preserve original7 bank sizes/102Link8 instances, original53 equivalent reset outputs, all payloadconnections/types/native masks unchanged. Candidate reset wire reassignment ONLY, actual graph/nativeRC/pins/function/fullphysical requalification required. No new state or logic in M11/M12.',selected_score=best[0],stronger_necessary_wire_lengths_um=best[2],proposal_sha256=hashlib.sha256((out/'proposal.json').read_bytes()).hexdigest(),scope='Local geometric proposal, not implementation or acceptance; native/inputcaps for changedresetloads must be freshly joined. Existing uncontrolled lowerbound0 never grants physicalpass. All originalfinalgates remain.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
