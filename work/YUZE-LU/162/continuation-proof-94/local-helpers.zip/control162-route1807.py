import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453/upper-candidates/17170/route/openroad-search/case-0'
for p in root.iterdir():
 if p.is_file():print('FILE',p.name,p.stat().st_size)
for name in ['openroad.log','router.log','run.log','route.log']:
 p=root/name
 if p.exists():
  with p.open('rb')as f:f.seek(max(0,p.stat().st_size-12000));print('TAIL',name,f.read().decode(errors='replace'))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35).decode())
