import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-current-pin-composition-1834'
for sub in ['upper-candidates/18460/route','function']:
 p=root/sub;print('STATE',sub)
 if(p/'receipt.json').exists():print(json.loads((p/'receipt.json').read_text()))
 for f in sorted(p.glob('*.log'),key=lambda x:x.stat().st_mtime)[-1:]:
  with f.open('rb')as s:s.seek(max(0,f.stat().st_size-1000));print(f.name,s.read().decode(errors='replace'))
 f=p/'openroad-search/case-0/openroad.log'
 if f.exists():
  with f.open('rb')as s:s.seek(max(0,f.stat().st_size-1600));print(s.read().decode(errors='replace'))
p=b/'dynamic-05/node4';d=json.loads((p/'queue-state.json').read_text());print('ACTIVE',d['active'])
for f in(p/'commands').glob('*1846*'):print('ADMISSION',f.name,json.loads(f.read_text()).get('admission'))
for f in(p/'results').glob('*1846*'):print('RESULT',f.name,json.loads(f.read_text()))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45).decode())
