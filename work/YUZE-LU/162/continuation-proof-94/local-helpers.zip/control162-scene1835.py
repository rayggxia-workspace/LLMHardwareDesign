import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-current-pin-composition-1834'
for sub in ['selected','topology','function','native-sta','cap-initial','cap-initial-1837','cap-candidates/18390','cap-initial-necessary/native-pin-load','cap-necessary-1839/18390/native-pin-load']:
 p=root/sub
 if not p.exists():continue
 if(p/'receipt.json').exists():
  d=json.loads((p/'receipt.json').read_text());print(sub,{k:d.get(k)for k in ['passed','execution_passed','stage','physical_instances','actual_final_leaf_count']})
 for f in sorted(p.glob('*.log'),key=lambda f:f.stat().st_mtime)[-1:]:
  with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-400));print(sub,f.name,stream.read().decode(errors='replace'))
for folder in ['dynamic-05/node4','dynamic-02/node3','dynamic-03/node5']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print(folder,d.get('active'))
 for f in(p/'results').glob('*183[479]*'):print('RESULT',f.name,json.loads(f.read_text()).get('returncode'))
 for f in p.glob('*1837*.log'):
  with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-1600));print('RETRYLOG',f.name,stream.read().decode(errors='replace'))
 for f in(p/'commands').glob('*1834*'):print('ADMISSION',f.name,json.loads(f.read_text()).get('admission'))
old=b/'r256-arbiter-composition-1773/function/receipt.json'
print('BASELINEFUNCTION',json.loads(old.read_text()).get('passed')if old.exists()else'RUNNING')
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45).decode())
