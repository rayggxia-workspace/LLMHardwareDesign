from pathlib import Path
import subprocess,shlex
b=Path(__file__).parent
s=(b/'control162-refine1775.py').read_text(encoding='utf-8');start=s.index("q=r'''")+6;end=s.index("'''",start);q=s[start:end]
q=q.replace('sready1775-arbiter-native-aware-placement','sready1798-arbiter-independent-placement')
start=q.index("add('00-d-sready1775-initial-residual'");end=q.index("place=root/'cap-candidates/17750'",start);q=q[:start]+q[end:]
q=q.replace('17750','17980').replace('sready1775-refined','sready1798-refined').replace('4610,','4611,').replace('/cap-necessary-1775/','/cap-necessary-1798/').replace("root/'cap-necessary-1775/","root/'cap-necessary-1798/")
q=q.replace("queued=5","queued=3").replace('Onefreshcandidate17980 only','Onefreshindependentcandidate17980 only').replace('original4610RNG','independent4611RNG')
compile(q,'queue1798','exec');(b/'control162-search1798-remote.py').write_text(q,encoding='utf-8');print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
q=q.replace('sready1798','sready1799').replace('17980','17990').replace('cap-necessary-1798','cap-necessary-1799').replace('4611','4612').replace('dynamic-03/node5','dynamic-05/node4');compile(q,'queue1799','exec');(b/'control162-search1799-remote.py').write_text(q,encoding='utf-8');print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=50).decode())
