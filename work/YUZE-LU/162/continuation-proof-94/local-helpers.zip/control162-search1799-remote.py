from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-composition-1773';record=b/'route-selection-102/sready1799-arbiter-independent-placement';source=b/'source-1772'
assert not record.exists();assert json.loads((root/'topology/receipt.json').read_text())['passed'];record.mkdir();rows=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();manifest=root/'selected/physical.json';graph=root/'topology/boundary-graph.json'
def add(name,args,deps,out,memory=32):
 p=b/'dynamic-05/node4/pending'/(name+'.json');assert not p.exists()and not out.exists()
 spec=dict(script='system_upper.py',source_root=str(source),forecast_gib=memory,requires=list(map(str,deps)),args=list(map(str,['--manifest',manifest,'--graph',graph,*args,'--out',out])))
 t=p.with_suffix('.tmp');t.write_text(json.dumps(spec));t.rename(p);rows.append(dict(path=str(p),sha256=sha(p),spec=spec))
initial=root/'cap-initial';base=root/'cap-initial-necessary';res=base/'native-residual';pin=base/'native-pin-load'
cfg=record/'native-cap-initial.json';cfg.write_text(json.dumps(dict(native_sta=str(root/'native-sta'),placements=[str(initial)]),indent=2))
place=root/'cap-candidates/17990'
add('00-f-sready1799-refined-placement',['--pg-wrappers',root/'fixed-pg-wrappers','--cap-lower-bound-only','--pin-aware-placement','--seed',4612,'--channel-gap-um',64,'--electrical-placement-report',initial/'wire-cap-lower-bound.json','--placement-residual-budget',pin/'native-pin-load.json','--placement-capacity-target','.35','--placement-local-density-weight',1000000000,'--placement-local-density-model','exact'],[pin/'receipt.json'],place,64)
cfg=record/'native-cap-17990.json';cfg.write_text(json.dumps(dict(native_sta=str(root/'native-sta'),placements=[str(place)]),indent=2));base=root/'cap-necessary-1799/17990';res=base/'native-residual';pin=base/'native-pin-load'
add('00-g-sready1799-refined-residual',['--native-cap-residual-config',cfg],[place/'receipt.json',root/'native-sta/native-system-audit.json'],res)
add('00-h-sready1799-refined-pin',['--native-pin-load-residual',res/'native-cap-residual.json'],[res/'receipt.json'],pin)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,scope='Onefreshindependentcandidate17990 only, existingoriginal exactdensity floorplanner sixteen independent trials inside16CPU. Reuseoriginal16100 objective weights1e9densityand1e9budget, independent4612RNG/gap64/target.35; actualnew3200Sarbiter nativecap/pins/area/graph drivefreshsearch. Originalnative/minpin lowbasehigh necessary tests unmodified. Needinspectallthree zero violation reportsbeforefull7stage actualroute andstrictnativeXOR/PG/threeRC300MHz. No oldplacement/qualificationtransfer; no addedblocks, noreserveversions.'),indent=2));print(json.dumps(dict(queued=3,candidate=17990)))
