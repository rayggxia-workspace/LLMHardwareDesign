from pathlib import Path
import json,hashlib,subprocess
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/current-pin1830';assert not out.exists();out.mkdir();files={'contract1831.json':b/'control162-groupcheck1831/receipt.json','actual-stronger-bound1829.json':b/'control162-actual-steiner1829/receipt.json','actual-inputs1829.json':b/'control162-actual-steiner1829/reception.json'}
for name,p in files.items():(out/name).write_bytes(p.read_bytes())
(out/'local-source-contract-check.py').write_bytes((b/'control162-groupcheck1831.py').read_bytes());(out/'local-actual-stronger-bound-check.py').write_bytes((b/'control162-fetch1829.py').read_bytes())
(out/'README.md').write_text('''# Issue #162：按当前原生引脚分组，保留既有物理宏和数量

对应 [Issue #162](https://github.com/rayggxia-workspace/LLMHardwareDesign/issues/162) / [PR #163](https://github.com/rayggxia-workspace/LLMHardwareDesign/pull/163)。本提交是默认关闭的候选连线修复；完整组合仍未通过，不合并。

原3200um S仲裁器已通过全部独立原生及固定PG验收，其他22物理类型和main六宏/R保留。source1772用旧1470um引脚保持原Link8分组，导致同组当前原生源引脚最大跨度2612um。原17750及平移18020/18120即使通过较弱必要电容检查，也不能据此认定可布通。

实际18020/18120的全部11149接点数组及345位置已下载并与本地候选逐项核对。原net_8939仅接收端的L1 MST为2853格；按[Hwang1976直角Steiner下界](https://epubs.siam.org/doi/abs/10.1137/0130013)，线长至少1902格。在现有同一RC模型和实际native/pin负载下，high总电容至少1934.569892fF，超过原1904.3fF上限30.269892fF。此结论只排除该固定接收端相对位置与复位分组；不表示项目或其他摆放不可行。没有修改任何电气门槛。

新增 `--link-current-pin-groups` 必须同时使用原R256、本地复位padding和已绑定的旧参考清单。参考坐标仅决定各source/destination组数；当前合格3200um原生引脚决定邻接lane，必要时把相邻组拆为小组以保持原数量。S仲裁器等价的复位负载沿当前源引脚周长排列，所有53路仍来自同一M1–M10复位状态、同一拍延迟。M11/M12只改变被动连线。

保持23物理类型、345实例、316个Link8、25复位bank和所有数据/控制/host载荷功能。没有新增物理块实现、没有修改native版图或RTL。局部对照最大源引脚跨度从2612um降至32um。新增分组会改变组合的连线，必须重跑实际Yosys、三初态八程序、内部/外部任务轨迹、native RC、所有最终M11/M12几何/XOR/PG及三档RC300MHz联合验收；旧组合资格不转移。

已执行：`python control162-groupcheck1831.py`，默认完整topology原字节及完整link证明序列化精确回放、新模式原始载荷精确收缩、原物理类型/数量不变、九项非法profile拒绝通过；四文件语法检查通过；`python scripts/check_project.py`通过。它们是源合同检查，不是布局布线或系统通过。

本地大输入保存在授权工作区 `D:\\Data\\电路实验\\control162-math-data1790`、`control162-topology-data1825`、`control162-actual-steiner1829`；实际远程输入位置/字节/SHA见随附JSON。检查脚本为当时实际执行原件，内含本机路径，移机重跑需按收据重新实收输入并改工作区根。新的远程源码冻结、全文件/反向补丁审计及运行回执将在后续实际结果中补齐，不宣称已经执行。

规则rayggxia-project-collab1.0.0；登记PR5 pending；缺board.json，看板unverified/同步pending；审查人待指定；Issue in_progress / PR Draft。
''',encoding='utf-8')
attr=r/'.gitattributes';s=attr.read_text(encoding='utf-8');s+='\nwork/YUZE-LU/162/current-pin1830/*.json -text\n';attr.write_text(s,encoding='utf-8',newline='\n')
line='Issue162新增默认关闭的当前引脚分组候选：[源合同与实际下界](../work/YUZE-LU/162/current-pin1830/README.md)。保持23类型/345实例/316Link8/25bank，main六宏/R及全部native版图不变；S仲裁器组内当前pin跨度2612→32um。旧模式完整topology原字节与link证明精确回放、九项拒绝通过；实际固定reset分组high必要1934.57fF>原1904.3fF，需新组合重验，尚无联合物理通过。\n\n'
for name,text in [('docs/STATUS.md',line),('docs/CONTROL_V1.md',line),('progress/YUZE-LU/STATUS.md',line.replace('../work/','../../work/'))]:
 p=r/name;p.write_text(text+p.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
p=r/'docs/ARCHITECTURE.md';p.write_text('''## Issue162：当前原生引脚的等数量Link8分组候选

在原topology命令的 `--r256-scene --link-padding-local-reset --link-grouping-reference <已验1470清单>` 上追加 `--link-current-pin-groups`。仅在新3200um S仲裁器已独立全部验收的场景启用；默认行为保留。旧坐标仅决定原316组的数量，当前原生pin决定lane邻接及同状态复位bank的被动连线。实际新组合尚待重验；见[源合同与边界](../work/YUZE-LU/162/current-pin1830/README.md)。宏RTL/内部版图和所有最终几何/PG/RC/300MHz门保持。

'''+p.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
names=['project/experiments/control_v1/'+name for name in ['boundary_links.py','reset_link_banks.py','topology.py','current_pin_groups.py']]+['.gitattributes','docs/STATUS.md','docs/CONTROL_V1.md','docs/ARCHITECTURE.md','progress/YUZE-LU/STATUS.md','work/YUZE-LU/162/current-pin1830']
for name in names[:4]:p=r/name;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['git','add','--',*names],cwd=r,check=True);subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True)
for name in names[:4]:assert subprocess.check_output(['git','show',':'+name],cwd=r)==(r/name).read_bytes()
for name in files:assert subprocess.check_output(['git','show',':work/YUZE-LU/162/current-pin1830/'+name],cwd=r)==(out/name).read_bytes()
print(json.dumps(dict(staged=True,raw_json_blobs_verified=len(files),production_files=4)))
