import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-arbiter-composition-1773'
for num,tag in [(17980,1798),(17990,1799),(18020,1803)]:
 for sub in ['cap-candidates/'+str(num),'cap-necessary-'+str(tag)+'/'+str(num)+'/native-residual','cap-necessary-'+str(tag)+'/'+str(num)+'/native-pin-load']:
  p=root/sub;r=p/'receipt.json'
  if r.exists():print(sub,'RECEIPT',r.read_text()[:380])
  if(p/'native-pin-load.json').exists():
   d=json.loads((p/'native-pin-load.json').read_text());print(sub,'COUNTS',[r['violations']for r in d['placements']])
  if p.exists():
   for f in sorted(p.glob('*.log'),key=lambda f:f.stat().st_mtime)[-1:]:print(sub,f.name,f.read_text(errors='replace')[-220:])
fn=root/'function';r=fn/'receipt.json';print('FUNCTION',r.read_text()[:1000]if r.exists()else'RUNNING')
f=fn/'build.log';print('BUILD',f.read_text(errors='replace')[-380:])
for folder in ['dynamic-05/node4','dynamic-02/node3','dynamic-03/node5']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print(folder,d.get('active'))
 for f in(p/'results').glob('*18[0-9][0-9]*'):
  d=json.loads(f.read_text());print('TASK',f.name,d.get('returncode'))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
