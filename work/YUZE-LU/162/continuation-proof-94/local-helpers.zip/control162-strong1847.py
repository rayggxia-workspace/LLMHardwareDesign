from pathlib import Path
import subprocess,shlex,json,hashlib,sys,math
b=Path(__file__).parent;out=b/'control162-strong1847';assert not out.exists();out.mkdir()
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-current-pin-composition-1834'
files={'placement.json':remote+'/cap-candidates/18390/placement.json','native-pin-load.json':remote+'/cap-necessary-1839/18390/native-pin-load/native-pin-load.json'}
q='from pathlib import Path;import json,hashlib;files='+repr(files)+';print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))'
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);idx=json.loads(raw)
for name,row in idx.items():
 subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(out/name)],check=True);data=(out/name).read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'reception.json').write_bytes(raw);sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
p=json.loads((out/'placement.json').read_bytes());pd=json.loads((out/'native-pin-load.json').read_bytes());assert pd['passed']and len(pd['placements'])==1
rows=pd['placements'][0]['rows'];violations={v:[]for v in ['low','base','high']}
for r in rows:
 bound=grid_tree_bound(p['terminals'][r['net']]);edges=bound['necessary_wire_grid_edges'];strong=max(bound['hpwl_grid_edges'],math.ceil(2*bound['metric_mst_grid_edges']/3))
 assert strong>=edges
 for v in violations:
  wire=r['optimistic_total_ff'][v]-r['native_ground_cap_ff'];assert wire>=-1e-7
  if edges==0:assert abs(wire)<1e-7;total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']
  else:total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+wire*strong/edges
  if total>r['max_capacitance_ff']+1e-7:violations[v].append(dict(net=r['net'],driver=r['driver'],necessary_total_ff=total,max_capacitance_ff=r['max_capacitance_ff'],excess_ff=total-r['max_capacitance_ff'],stronger_edges=strong,original_edges=edges))
receipt=dict(passed=True,whole_system_qualified=False,rows_checked=len(rows),placement_sha256=idx['placement.json']['sha256'],native_pin_load_sha256=idx['native-pin-load.json']['sha256'],violations={v:len(x)for v,x in violations.items()},details=violations,inputs=idx,theorem_source='https://epubs.siam.org/doi/abs/10.1137/0130013',scope='Fetched actual18390 placement and fresh1834 native/minimum-pin original3RC inputs; local bounded necessary-condition diagnostic using max(HPWL,ceil(2*L1-MST/3)). Does not change any original gate or qualify routing, timing, geometry or system.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
