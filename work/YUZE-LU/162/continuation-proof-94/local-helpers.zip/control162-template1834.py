import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d=json.loads((b/'route-selection-102/sready1773-arbiter-qualified-scene/tasks.json').read_text());print(json.dumps(d['tasks'],indent=2))
'''
print(subprocess.check_output(['ssh','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35).decode())
