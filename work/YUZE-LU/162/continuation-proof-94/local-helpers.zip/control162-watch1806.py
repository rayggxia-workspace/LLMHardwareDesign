from pathlib import Path
import json,subprocess,shlex,time
b=Path(__file__).parent;host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';journal=b/'control162-watch1806.jsonl';assert not journal.exists()
def record(**d):
 d['time']=time.time()
 with journal.open('a',encoding='utf-8')as f:f.write(json.dumps(d)+'\n')
 print(json.dumps(d),flush=True)
q="from pathlib import Path;import json;b=Path("+repr(remote)+");r=b/'r256-arbiter-composition-1773/cap-necessary-1803/18020/native-pin-load/native-pin-load.json';p=b/'dynamic-05/node4/results/00-a-sready1803-pin.json';print(json.dumps(dict(ready=True,counts=json.loads(r.read_text())['placements'][0]['violations'])if r.exists()else dict(failed=json.loads(p.read_text()).get('returncode')!=0)if p.exists()else dict(waiting=True)))"
try:
 record(waiting='Actualsource1772 pin reconstruction andall3necessarycapzero18020')
 for _ in range(240):
  try:d=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(q)],timeout=35))
  except(subprocess.SubprocessError,OSError)as exc:record(connection_retry=str(exc));time.sleep(30);continue
  if d.get('failed'):raise RuntimeError('Actual reconstruction/cap task failed')
  if d.get('ready'):
   assert d['counts']==dict(low=0,base=0,high=0),d
   record(actual_necessary_counts=d['counts']);break
  time.sleep(30)
 else:raise TimeoutError('Actual18020 nativepinpreflight')
 p=b/'control162-full1804-remote.py';subprocess.run(['scp',str(p),host+':'+remote+'/'+p.name],check=True);subprocess.run(['ssh',host,'python3',remote+'/'+p.name],check=True);record(completed=True,queued_actual_full7stage=18040,whole_system_qualified=False)
except BaseException as exc:record(failed=True,error=str(exc));raise
