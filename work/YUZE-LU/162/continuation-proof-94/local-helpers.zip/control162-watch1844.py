"""Local dependency observation and exact metadata dispatch; EDA stays in Slurm."""
from pathlib import Path
import subprocess,shlex,json,time,sys
h=Path(__file__).parent;b='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';host='yuzelu@10.129.166.172';journal=h/'control162-watch1844.jsonl';assert not journal.exists()
def record(**row):
 row['time']=time.time()
 with journal.open('a',encoding='utf-8')as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
 print(json.dumps(row,ensure_ascii=False),flush=True)
q="from pathlib import Path;import json;p=Path("+repr(b+'/r256-current-pin-composition-1834/function/receipt.json')+");r=Path("+repr(b+'/dynamic-03/node5/results/00-c-sready1834-function.json')+");print(json.dumps(json.loads(p.read_text())['passed'] if p.exists()else(False if r.exists()and json.loads(r.read_text())['returncode']!=0 else None)))"
try:
 record(waiting='fresh1834actual3initial8programs')
 for _ in range(360):
  try:s=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(q)],timeout=35))
  except (subprocess.SubprocessError,OSError)as e:record(connection_retry=type(e).__name__);time.sleep(30);continue
  if s is False:raise RuntimeError('Actual1834finalcellprograms failed')
  if s is True:break
  time.sleep(30)
 else:raise TimeoutError('fresh1834function')
 record(passed='fresh1834actualfunctionreceipt')
 for n in ['functionaudit1843-remote','traces1843-remote']:
  p=h/('control162-'+n+'.py');subprocess.run(['scp',str(p),host+':'+b+'/'],check=True);record(dispatch_metadata=str(p));subprocess.run(['ssh',host,'python3',b+'/'+p.name],check=True)
 record(completed=True,scope='Freshindependentfunctionauditpassed andfreshinternal/externaltrace96GiBtaskqueued inexistingnode5naturalvacancy. No wholephysicalpassclaimed.')
except BaseException as e:record(failed=True,error=str(e));raise
