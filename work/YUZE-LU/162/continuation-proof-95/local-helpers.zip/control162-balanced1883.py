"""Candidate grouping only; constant same-state reset outputs remain native."""
import itertools

def balanced_groups(rows):
 assert rows and len({r['source_instance']for r in rows})==1
 assert all(len(r['lanes'])in range(1,9)for r in rows)
 count=(len(rows)+15)//16;small,extra=divmod(len(rows),count)
 sizes=sorted(set(itertools.permutations([small+1]*extra+[small]*(count-extra))))
 def perimeter(row):
  x,y=row['source_pin_anchor_um'];w,h=row['source_pin_die_um'];assert w>0 and h>0 and 0<=x<=w and 0<=y<=h
  return {2:x,1:w+y,3:2*w+h-x,0:2*(w+h)-y}[row['side']]
 sequence=sorted(rows,key=lambda row:(perimeter(row),row['instance']));options=[]
 for offset in range(len(sequence)):
  rotated=sequence[offset:]+sequence[:offset]
  for lengths in sizes:
   chunks=[];costs=[];spans=[];start=0
   for size in lengths:
    chunk=rotated[start:start+size];start+=size;points=[r['source_pin_anchor_um']for r in chunk];span=sum(max(p[a]for p in points)-min(p[a]for p in points)for a in (0,1));pads=sum(8-len(r['lanes'])for r in chunk)
    # Finite placement-search proxy only: native input load and wiring
    # are remeasured by original cap/STA/physical gates after reassignment.
    chunks.append(chunk);spans.append(span);costs.append(span+32*(pads+size))
   options.append(((max(costs),sum(costs),max(spans),sum(spans),offset,lengths),chunks))
 result=min(options,key=lambda row:row[0])[1]
 assert len(result)==count and sorted(r['instance']for c in result for r in c)==sorted(r['instance']for r in rows)
 assert all(1<=len(c)<=16 for c in result)and max(map(len,result))-min(map(len,result))<=1
 return result
