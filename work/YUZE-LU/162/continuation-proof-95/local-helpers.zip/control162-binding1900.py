from pathlib import Path
import subprocess,shlex,json,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';w=r/'work/YUZE-LU/162'
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888/source-binding-audit/receipt.json';target=w/'source-binding-current1888.json';assert not target.exists()
q='from pathlib import Path;import hashlib,json;p=Path('+repr(remote)+');v=p.read_bytes();print(json.dumps(dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest())))'
d=json.loads(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40));subprocess.run(['scp','yuzelu@10.129.166.172:'+remote,str(target)],check=True);raw=target.read_bytes();assert len(raw)==d['bytes']and hashlib.sha256(raw).hexdigest()==d['sha256'];a=json.loads(raw)
assert a['passed']and a['physical_types']==23 and a['instances']==345 and a['only_reset_and_unused_padding_wires_changed']and a['all345_state_owners_exact_old1834']
old=json.loads((w/'state-ownership-current1834.json').read_bytes());descs={v['instance']:v for v in old['owners']};owners=[]
for row in a['owners']:
 previous=descs[row['instance']];assert previous['physical_type']==row['physical_type'];v=dict(previous,**row);v['canonical_leaf_ref']='source-binding-current1888.json#/leaves/'+row['physical_type'];owners.append(v)
old.update(owners=owners,inputs=a['inputs'],captured_at=a['time'],scope=a['scope'],source_binding='source-binding-current1888.json',ownership_rule=a['state_ownership_rule'],whole_system_qualified=False)
(w/'state-ownership-current1888.json').write_bytes(json.dumps(old,indent=2,ensure_ascii=False).encode())
prior=json.loads((w/'source-binding-current1834.json').read_bytes());assert a['leaves']==prior['leaves']
delivery=w/'block-delivery-current1850/index.json';v=dict(passed=True,whole_system_qualified=False,scene='r256-balanced-reset-composition-1888',source_commit='8d55501a05dc008781e00efa7655893650a59f6b',source_binding=dict(path='source-binding-current1888.json',sha256=d['sha256']),delivery_index=dict(path='block-delivery-current1850/index.json',sha256=hashlib.sha256(delivery.read_bytes()).hexdigest()),physical_types=23,instances=345,final_files=138,all23_qualified_six_file_identities_exact_prior1834=True,scope='New actual connected graph source ownership independently verified; same23 qualified native/PG physical rows and138 finalfiles already locallyreceived. Only reset/padding wiring changed. No new whole-composition qualification; fresh function/traces/M11-M12/geometry/PG/lowbasehigh300MHz mandatory.')
(w/'current-delivery-binding1888.json').write_bytes(json.dumps(v,indent=2).encode())
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/source-binding-current1888.json -text\nwork/YUZE-LU/162/state-ownership-current1888.json -text\nwork/YUZE-LU/162/current-delivery-binding1888.json -text\n')
print(json.dumps(dict(passed=True,actual_source_binding_reception=d,owners=len(owners),physical_types=23,final_files=138,whole_system_qualified=False)))
