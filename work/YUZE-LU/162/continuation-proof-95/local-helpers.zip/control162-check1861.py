from pathlib import Path
import json,math,sys,hashlib
b=Path(__file__).parent;root=b/'control162-math-data1858';out=b/'control162-strong1861';assert not out.exists();out.mkdir();sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
old=json.loads((root/'placement.json').read_bytes());p=json.loads((b/'control162-milp1860/candidate-math-only.json').read_bytes());rows=json.loads((root/'native-pin-load.json').read_bytes())['placements'][0]['rows'];violations={v:[]for v in ['low','base','high']}
for r in rows:
 base=grid_tree_bound(old['terminals'][r['net']]);new=grid_tree_bound(p['terminals'][r['net']]);edges=max(new['hpwl_grid_edges'],math.ceil(2*new['metric_mst_grid_edges']/3))
 for v in violations:
  total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+(r['optimistic_total_ff'][v]-r['native_ground_cap_ff'])*edges/base['necessary_wire_grid_edges']
  if total>r['max_capacitance_ff']+1e-7:violations[v].append(dict(net=r['net'],driver=r['driver'],necessary_total_ff=total,max_capacitance_ff=r['max_capacitance_ff'],excess_ff=total-r['max_capacitance_ff']))
receipt=dict(passed=True,whole_system_qualified=False,rows_checked=len(rows),violations={v:len(x)for v,x in violations.items()},details=violations,proposal_sha256=hashlib.sha256((b/'control162-milp1860/proposal.json').read_bytes()).hexdigest(),scope='Local math-only rigid29cluster candidate; same actual18390 measured native/minpin budgets. All originalweakbounds independently checked byMILPhelper; this is stronger2/3MST check. Actual native-pin reconstruction and originalthreeRC plusfullphysical300MHz stillrequired. No acceptance gates changed.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
