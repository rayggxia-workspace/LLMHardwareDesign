from pathlib import Path
import json,hashlib,subprocess,sys,copy,collections
b=Path(__file__).parent;repo=b/'LLMHardwareDesign-worktrees/issue-162-control';source=repo/'project/experiments/control_v1';out=b/'control162-contract1884';assert not out.exists();out.mkdir()
for name in ['current_pin_groups.py','boundary_links.py','reset_link_banks.py','topology.py']:
 p=source/name;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
s=(b/'control162-groupcheck1831.py').read_text(encoding='utf-8').replace("out=b/'control162-groupcheck1831'","out=b/'control162-legacy1884'");p=b/'control162-legacy1884.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True,stdout=subprocess.DEVNULL)
sys.path.insert(0,str(source));from boundary_links import insert;from current_pin_groups import reference_counts,balanced_reset_groups
legacy=b/'control162-legacy1884';m=json.loads((b/'control162-math-data1790/physical.json').read_bytes());original=json.loads((b/'control162-topology-data1825/original-topology.json').read_bytes())['modules']['control_system'];pins=json.loads((legacy/'pins-derived-actual.json').read_bytes());v1=json.loads((legacy/'module-current-groups.json').read_bytes());proof1=json.loads((legacy/'links-current-groups.json').read_bytes());oldv1=json.loads((b/'control162-groupcheck1831/module-current-groups.json').read_bytes());oldproof1=json.loads((b/'control162-groupcheck1831/links-current-groups.json').read_bytes());assert v1==oldv1 and proof1==oldproof1
sources=list(dict.fromkeys(r['source_instance']for r in proof1['links']if r['source_instance'].startswith('macro_')));fanout=['s_port:dout','controller:task_data','controller:task_last'];counts=reference_counts(proof1['links']);new=copy.deepcopy(original);proof=insert(new,m,pins,sources,fanout,local_reset_padding=True,reference_group_counts=counts,balanced_reset_banks=True)
assert len(new['cells'])==345 and len(proof['links'])==316 and len(proof['reset_banks']['banks'])==25;assert new['ports']==original['ports'];assert proof['reset_banks']['partition_profile']=='spatial-balanced-link-counts/1';assert collections.Counter((r['source_instance'],r['fanout_branch'])for r in proof['links'])==counts
reverse={lane['output_bit']:lane['input_bit']for row in proof['links']for lane in row['lanes']};contracted=copy.deepcopy(new)
for row in proof['links']:del contracted['cells'][row['instance']]
for cell in contracted['cells'].values():
 for port,bits in cell['connections'].items():cell['connections'][port]=[reverse.get(bit,bit)for bit in bits]
for port in contracted['ports'].values():port['bits']=[reverse.get(bit,bit)for bit in port['bits']]
assert contracted==original
for row,prior in zip(proof['links'],proof1['links']):
 for key in ['instance','source_instance','side','lanes','fanout_branch','padded_input_lanes','clock_bit','state_owner','state_bits','payload_register_bits','source_pin_anchor_um','source_pin_die_um']:assert row[key]==prior[key]
groups=collections.defaultdict(list)
for row in proof['links']:groups[row['source_instance']].append(row)
sizes={};banks=proof['reset_banks']['banks']
for source_name,rows in groups.items():
 chunks=balanced_reset_groups(rows);assert chunks==balanced_reset_groups(list(reversed(rows)));sizes[source_name]=[len(c)for c in chunks];assert max(sizes[source_name])-min(sizes[source_name])<=1
 assert [[r['instance']for r in c]for c in chunks]==[bank['link_instances']for bank in banks if bank['source_instance']==source_name]
for source_name in ['macro_1','macro_2','macro_3']:assert sizes[source_name]==[9,9]
assert sorted(sizes['s_port'])==[14,14,14,15,15,15,15]and sizes['macro_r']==[14]*6 and sorted(sizes['macro_t'])==[10,11]
rejections=[]
def reject(label,fn):
 try:fn()
 except (AssertionError,KeyError):rejections.append(label)
 else:raise AssertionError('Malformed accepted: '+label)
reject('balanced_without_current_reference',lambda:insert(copy.deepcopy(original),m,pins,sources,fanout,local_reset_padding=True,balanced_reset_banks=True))
sample=groups['macro_1'];reject('empty_group',lambda:balanced_reset_groups([]));reject('duplicate_instance',lambda:balanced_reset_groups(sample+[sample[0]]))
for label,key,value in [('mixed_source','source_instance','other'),('wrong_die','source_pin_die_um',[1,1]),('bad_side','side',9),('outside_pin','source_pin_anchor_um',[-1,0]),('empty_payload','lanes',[])]:
 bad=copy.deepcopy(sample);bad[0][key]=value;reject(label,lambda:balanced_reset_groups(bad))
assert len(rejections)==8
(out/'balanced-module.json').write_text(json.dumps(new));(out/'balanced-links.json').write_text(json.dumps(proof));receipt=dict(passed=True,whole_system_qualified=False,legacy_original_topology_raw_bytes_exact=True,legacy9malformed_rejections_passed=True,current_v1_module_and_complete_proof_exact=True,independent_payload_and_original29_contraction_exact=True,all345physical_types_and_316lane_paths_unchanged=True,physical_instances=345,links=316,reset_banks=25,balanced_sizes=sizes,balanced_malformed_rejections=rejections,deterministic_under_input_order=True,source_sha256={name:hashlib.sha256((source/name).read_bytes()).hexdigest()for name in ['current_pin_groups.py','boundary_links.py','reset_link_banks.py','topology.py']},scope='Pure source contract on exact previously fetched actual native/reference inputs. New default-off option changes only passive reset/padding wires among same53registered-equivalent outputs. Payload/clock/original29 cells exact; 25bank counts retained with balanced nearby loads. All23fixednative masks and actualfinal views reused, but newconnected graph must freshly pass actualYosys/threeinitial eightprograms/traces/nativeRC/fullM11-M12geometryPG/threeRC300MHz. No qualification transfer.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
