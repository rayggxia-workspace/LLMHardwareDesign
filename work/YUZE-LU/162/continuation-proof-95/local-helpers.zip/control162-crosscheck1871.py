from pathlib import Path
import ast,json,hashlib,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
b=Path(__file__).parent;out=b/'control162-crosscheck1871';assert not out.exists();out.mkdir()
for filename,name in [('control162-hanan1869.py','solve'),('control162-subset1870.py','exact')]:
 tree=ast.parse((b/filename).read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name==name);exec(compile(ast.Module(body=[fn],type_ignores=[]),filename,'exec'))
import math
proof=json.loads((b/'control162-subset1870/receipt.json').read_bytes());checks=[]
for row in proof['results']:
 result=solve(row['subset'],3);value=exact(row['subset']);assert value==row['exact_subset_steiner_edges']
 if result['lower_edges']is not None:assert result['lower_edges']<=value
 if result['upper_edges']is not None:assert result['upper_edges']>=value
 if result['status']==0:assert result['lower_edges']==result['upper_edges']==value
 checks.append(dict(placement=row['placement'],net=row['net'],exact_dp=value,independent_flow_mip=result,exact_equal=result['status']==0))
square=[(0,0),(4,0),(0,3),(4,3),(2,1)];assert exact(square)==10;v=solve(square);assert v['status']==0 and v['lower_edges']==v['upper_edges']==10
receipt=dict(passed=True,whole_system_qualified=False,source_subset_receipt_sha256=hashlib.sha256((b/'control162-subset1870/receipt.json').read_bytes()).hexdigest(),five_point_oracle=dict(passed=True,dp=10,independent_mip=v),checks=checks,all_six_exact_equal=all(v['exact_equal']for v in checks),scope='Independent subset DP and binary-edge/per-terminal-flow MIP compared on allsix actual8terminal selected subsets. For proved reset failures, exact subset length exceeds unchanged original highRC maximum. No full physical pass, no gate modification.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
