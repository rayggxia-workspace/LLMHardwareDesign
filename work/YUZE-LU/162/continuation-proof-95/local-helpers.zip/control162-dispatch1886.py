from pathlib import Path
import subprocess
b=Path(__file__).parent;host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
for path,name in [(b/'control162-backout1885.patch','control162-backout1885.patch'),(b/'control162-contract1884/receipt.json','control162-contract1884.json'),(b/'control162-audit1886-remote.py','control162-audit1886-remote.py')]:subprocess.run(['scp',str(path),host+':'+remote+'/'+name],check=True)
subprocess.run(['ssh',host,'python3',remote+'/control162-audit1886-remote.py'],check=True)
