from pathlib import Path
import subprocess
b=Path(__file__).parent;host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
for name in ['control162-proven-reset1887.json','control162-retire1887-remote.py','control162-queue1888-remote.py']:subprocess.run(['scp',str(b/name),host+':'+remote+'/'+name],check=True)
subprocess.run(['ssh',host,'python3',remote+'/control162-queue1888-remote.py'],check=True)
subprocess.run(['ssh',host,'python3',remote+'/control162-retire1887-remote.py'],check=True)
