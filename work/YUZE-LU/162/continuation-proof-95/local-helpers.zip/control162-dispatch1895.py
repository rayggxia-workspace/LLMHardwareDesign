from pathlib import Path
import subprocess
b=Path(__file__).parent;p=b/'control162-refill1895-remote.py';host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';subprocess.run(['scp',str(p),host+':'+remote+'/'],check=True);subprocess.run(['ssh',host,'python3',remote+'/'+p.name],check=True)
