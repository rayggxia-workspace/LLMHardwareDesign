from pathlib import Path
import subprocess,shlex,json,hashlib,shutil
b=Path(__file__).parent;out=b/'control162-math-data1877';assert not out.exists();out.mkdir();root='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-current-pin-composition-1834';files={'physical-graph.json':root+'/cap-candidates/18620/physical-graph.json','placement-search.json':root+'/cap-candidates/18390/placement-search.json'}
q='from pathlib import Path;import json,hashlib;files='+repr(files)+';print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))';raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);idx=json.loads(raw)
for name,row in idx.items():
 p=out/name;subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(p)],check=True);data=p.read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
for name,src in [('physical.json','control162-current1848/selected/physical.json'),('boundary-graph.json','control162-current1848/topology/boundary-graph.json'),('placement.json','control162-strong1867/placement.json'),('native-pin-load.json','control162-strong1867/native-pin-load.json')]:shutil.copyfile(b/src,out/name)
(out/'RECEPTION.json').write_bytes(raw);print('Fresh18620 with unchanged18390 rigid-cluster definitions math-only inputs received with actual hash-bound native budgets.')
