"""Bounded local mathematical diagnostic; never a P&R acceptance gate."""
from pathlib import Path
import json,math,time,sys,hashlib
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
b=Path(__file__).parent;out=b/'control162-hanan1869';assert not out.exists();out.mkdir();sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
def solve(raw,limit=3):
 pts=sorted(set(map(tuple,raw)));assert all(type(v)is int for xy in pts for v in xy)
 if len(pts)==1:return dict(lower_edges=0,upper_edges=0,status=0)
 xs=sorted({p[0]for p in pts});ys=sorted({p[1]for p in pts});nodes=[(x,y)for x in xs for y in ys];ids={xy:i for i,xy in enumerate(nodes)};edges=[]
 for i,x in enumerate(xs):
  for j,y in enumerate(ys):
   if i+1<len(xs):edges.append((ids[(x,y)],ids[(xs[i+1],y)],xs[i+1]-x))
   if j+1<len(ys):edges.append((ids[(x,y)],ids[(x,ys[j+1])],ys[j+1]-y))
 ne=len(edges);nv=len(nodes);n=ne+(len(pts)-1)*2*ne;rr=[];cc=[];vv=[];lo=[];hi=[]
 def row(items,lower,upper):
  z=len(lo);lo.append(lower);hi.append(upper)
  for k,v in items:rr.append(z);cc.append(k);vv.append(v)
 for k,sink in enumerate(pts[1:]):
  base=ne+k*2*ne;balances=[[]for _ in nodes]
  for e,(u,v,cost)in enumerate(edges):
   forward=base+2*e;back=forward+1;row([(forward,1),(e,-1)],-np.inf,0);row([(back,1),(e,-1)],-np.inf,0);balances[u]+=[(forward,1),(back,-1)];balances[v]+=[(forward,-1),(back,1)]
  for v,items in enumerate(balances):
   balance=1 if v==ids[pts[0]]else(-1 if v==ids[sink]else 0);row(items,balance,balance)
 c=np.zeros(n);c[:ne]=[x[2]for x in edges];integer=np.zeros(n);integer[:ne]=1;A=coo_matrix((vv,(rr,cc)),shape=(len(lo),n)).tocsc();started=time.time();res=milp(c,integrality=integer,bounds=Bounds(np.zeros(n),np.ones(n)),constraints=LinearConstraint(A,lo,hi),options=dict(time_limit=limit,mip_rel_gap=0));lower=getattr(res,'mip_dual_bound',None);upper=None
 if res.x is not None:
  assert np.max(A@res.x-np.array(hi))<1e-5 and np.max(np.array(lo)-A@res.x)<1e-5
  selected=[e for i,e in enumerate(edges)if res.x[i]>.5];assert max(abs(res.x[:ne]-np.round(res.x[:ne])))<1e-5;reach={ids[pts[0]]}
  while True:
   more={v for u,v,_ in selected if u in reach}|{u for u,v,_ in selected if v in reach}
   if more<=reach:break
   reach|=more
  assert all(ids[xy]in reach for xy in pts);upper=sum(e[2]for e in selected);assert abs(upper-res.fun)<1e-5
 return dict(status=int(res.status),message=res.message,lower_edges=None if lower is None else math.ceil(float(lower)-1e-6),upper_edges=upper,seconds=time.time()-started,nodes=nv,edges=ne,terminals=len(pts),scope='Only certified MIP dual lower bound is used as necessary length; feasible primal is an upper bound and never an impossibility proof.')
selfchecks=[]
for pts,expected in [([(0,0),(4,0),(0,3),(4,3)],10),([(0,0),(1,1),(2,2),(3,3)],6),([(0,0),(4,0),(2,2)],6)]:
 r=solve(pts);assert r['status']==0 and r['lower_edges']==r['upper_edges']==expected;selfchecks.append(r)
results=[]
for label,folder in [('18390','control162-strong1847'),('18620','control162-strong1867')]:
 p=json.loads((b/folder/'placement.json').read_bytes());rows=json.loads((b/folder/'native-pin-load.json').read_bytes())['placements'][0]['rows']
 for net in ['net_8920','net_8922','net_8924']:
  r=next(r for r in rows if r['net']==net);bound=grid_tree_bound(p['terminals'][net]);sol=solve(p['terminals'][net]);coefficient=(r['optimistic_total_ff']['high']-r['native_ground_cap_ff'])/bound['necessary_wire_grid_edges'];total=None if sol['lower_edges']is None else r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+coefficient*sol['lower_edges'];results.append(dict(placement=label,net=net,driver=r['driver'],solver=sol,high_necessary_total_ff=total,max_capacitance_ff=r['max_capacitance_ff'],high_necessary_violation=total is not None and total>r['max_capacitance_ff']+1e-7))
receipt=dict(passed=True,whole_system_qualified=False,diagnostic_only=True,selfchecks=selfchecks,results=results,theorem_source='https://epubs.siam.org/doi/10.1137/0114025',scope='Hanan theorem reduces obstacle-free planar rectilinear Steiner optimum to grid through terminal coordinates. Integer selected edges with per-terminal commodity flows yield connected-grid minimum; only solver-certified dual lower bound used. Projection of actual two-layer wires has at least that obstacle-free length. Native/pin highRC budgets and actual input hashes remain unchanged; not P&R/geometry/timing or system acceptance. Raw original fixed masks/whole-system gates unchanged.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
