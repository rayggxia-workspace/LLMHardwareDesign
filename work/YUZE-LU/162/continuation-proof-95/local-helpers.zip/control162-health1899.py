import subprocess,shlex
q=r'''from pathlib import Path
import json,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888'
p=b/'dynamic-05/node4/commands/00-c-sready1888-native-sta.json';d=json.loads(p.read_text());print('COMMAND',json.dumps(d)[:7000]);print('AGE_SECONDS',time.time()-p.stat().st_mtime)
raw=subprocess.check_output(['srun','--jobid=95391','--overlap','-n1','-c1','ps','-u','10011','-o','pid,ppid,etimes,pcpu,rss,args'],universal_newlines=True)
for line in raw.splitlines():
 if '1888'in line or('openroad'in line.lower()and'ps -u'not in line):print('PROCESS',line[:900])
for name in ['sta.log','stitched-native.spef','combined.v','native-system-audit.json','receipt.json']:
 p=r/'native-sta'/name
 if p.exists():print('FILE',name,p.stat().st_size,'age',time.time()-p.stat().st_mtime)
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
