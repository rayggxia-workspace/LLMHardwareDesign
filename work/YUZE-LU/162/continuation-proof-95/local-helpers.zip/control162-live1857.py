import subprocess,shlex
q=r'''from pathlib import Path
import json,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-current-pin-composition-1834'
for seed in [18460,18530]:
 p=root/'upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log';print('ROUTE',seed)
 if f.exists():
  text=f.read_text(errors='replace');print([s for s in text.splitlines()if any(v in s for v in ['Total congestion:','Total wirelength:','Number of violations','Start extra iteration','Completing 100%','End iteration'])][-8:]);print('TAIL',text[-350:])
 if(p/'receipt.json').exists():print('RECEIPT',json.loads((p/'receipt.json').read_text()))
for base in ['r256-arbiter-composition-1773','r256-current-pin-composition-1834']:
 p=b/base/'function';print('FUNCTION',base)
 for f in p.glob('initial-*.json'):
  try:d=json.loads(f.read_text());print(f.name,d.get('passed'))
  except ValueError:print(f.name,'IN_PROGRESS',f.stat().st_size)
 for f in p.glob('*.log'):
  if f.name=='build.log':continue
  with f.open('rb')as s:s.seek(max(0,f.stat().st_size-250));print(f.name,s.read().decode(errors='replace'))
 if(p/'receipt.json').exists():print('RECEIPT',json.loads((p/'receipt.json').read_text()).get('passed'))
p=b/'dynamic-04/node25'
for f in(p/'results').glob('*1622*'):print('OLDRESULT',f.name,json.loads(f.read_text()))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45).decode())
