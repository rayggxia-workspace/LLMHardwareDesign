from pathlib import Path
import json,sys,math
b=Path(__file__).parent;r=b/'control162-math-data1858';sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
base=json.loads((r/'placement.json').read_bytes());rows=json.loads((r/'native-pin-load.json').read_bytes())['placements'][0]['rows']
for tag in [1860,1864]:
 p=json.loads((b/('control162-milp'+str(tag))/'candidate-math-only.json').read_bytes());margins=[]
 for row in rows:
  old=grid_tree_bound(base['terminals'][row['net']]);new=grid_tree_bound(p['terminals'][row['net']]);edges=max(new['hpwl_grid_edges'],math.ceil(2*new['metric_mst_grid_edges']/3));wire=row['optimistic_total_ff']['high']-row['native_ground_cap_ff'];budget=(row['max_capacitance_ff']-row['native_ground_cap_ff']-row['minimum_input_pin_cap_ff'])*old['necessary_wire_grid_edges']/wire;margins.append(((budget-edges)*4,row['net'],row['driver'],edges*4,budget*4))
 print(tag,sorted(margins)[:7])
