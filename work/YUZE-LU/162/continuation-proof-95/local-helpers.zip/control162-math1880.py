from pathlib import Path
import json,math,time,sys,hashlib
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
b=Path(r'D:\Data\电路实验');root=b/'control162-math-data1877';repo=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-math1880';assert not out.exists();out.mkdir();sys.path.insert(0,str(repo/'project/experiments/control_v1'))
from steiner_wire_bound import grid_tree_bound
from cluster_shift_proposal import apply
p=json.loads((root/'placement.json').read_bytes());g=json.loads((root/'physical-graph.json').read_bytes());m=json.loads((root/'physical.json').read_bytes());s=json.loads((root/'placement-search.json').read_bytes());e=s['electrical_refinement'];cl=e['clusters'];names=sorted(cl['dimensions']);ids={n:i for i,n in enumerate(names)};parents={n:ids[v['parent']]for n,v in cl['members'].items()};dims=np.array([cl['dimensions'][n]for n in names]);origins=np.array([p['placements_um'][n]for n in names]);rows=json.loads((root/'native-pin-load.json').read_bytes())['placements'][0]['rows'];nets=[]
for r in rows:
 name=r['net'];con=g['connections'][name[4:]];ends=[con['driver'],*con['sinks']];coords=p['terminals'][name];bound=grid_tree_bound(coords)['necessary_wire_grid_edges'];wire=r['optimistic_total_ff']['high']-r['native_ground_cap_ff'];assert wire>0 and bound>0;budget=(r['max_capacitance_ff']-r['native_ground_cap_ff']-r['minimum_input_pin_cap_ff'])*bound/wire
 nets.append((name,[(None if end['instance']=='TOP'else parents[end['instance']],*xy)for end,xy in zip(ends,coords)],budget))
origins=np.array([[p['placements_um'][n][axis]-cl['members'][n]['offset_um'][axis]for axis in range(2)]for n in names])
var=59+4*len(nets);rr=[];cc=[];vv=[];ub=[]
def add(items,limit):
 idx=len(ub);ub.append(limit)
 for k,v in items:rr.append(idx);cc.append(k);vv.append(v)
for i in range(58):add([(i,1),(58,-1)],0);add([(i,-1),(58,-1)],0)
binary=[];rects=[]
for name,xy in p['placements_um'].items():rects.append((parents[name],xy,m['leaves'][g['instances'][name]]['die_um']))
for i,(a,xy,wh)in enumerate(rects):
 for z,zz,zh in rects[:i]:
  if a==z:continue
  choices=[(a,z,axis,(zz[axis]-xy[axis]-wh[axis])/4)for axis in range(2)]+[(z,a,axis,(xy[axis]-zz[axis]-zh[axis])/4)for axis in range(2)]
  if any(gap>=1024 for _,_,_,gap in choices):continue
  first,second,axis,gap=max(choices,key=lambda v:v[3]);assert gap>=-1e-6;add([(2*first+axis,1),(2*second+axis,-1)],max(0,gap))
reset_nets={r['net']for r in rows if r['driver']['instance']=='reset_distribution'}
mst_edges=0
for i,(name,ends,budget)in enumerate(nets):
 lo_x,hi_x,lo_y,hi_y=[59+4*i+j for j in range(4)]
 for parent,x,y in ends:
  for axis,v,l,h in [(0,x,lo_x,hi_x),(1,y,lo_y,hi_y)]:add([(l,1)]+([]if parent is None else[(2*parent+axis,-1)]),v);add([(h,-1)]+([]if parent is None else[(2*parent+axis,1)]),-v)
 add([(hi_x,1),(lo_x,-1),(hi_y,1),(lo_y,-1)],math.floor(budget+1e-8)-(2 if name=='net_8939'else 0))
 # A fixed existing metric spanning tree gives a conservative upper bound
 # on the new optimum MST. Its absolute edge lengths constrain MST/2 too.
 if name in reset_nets:
  used={0};edges=[]
  while len(used)<len(ends):
   _,a,z=min((abs(ends[a][1]-ends[z][1])+abs(ends[a][2]-ends[z][2]),a,z)for a in used for z in range(len(ends))if z not in used);used.add(z);edges.append((a,z))
  total=[]
  for a,z in edges:
   for axis in range(2):
    aa,zz=ends[a],ends[z];constant=aa[axis+1]-zz[axis+1];terms=[]
    if aa[0]is not None:terms.append((2*aa[0]+axis,1))
    if zz[0]is not None:terms.append((2*zz[0]+axis,-1))
    k=var;var+=1;add(terms+[(k,-1)],-constant);add([(u,-v)for u,v in terms]+[(k,-1)],constant);total.append((k,1));mst_edges+=1
  add(total,math.floor(1.0*budget+1e-8))
lower=np.zeros(var);upper=np.full(var,np.inf);lower[:58]=-512;upper[:58]=512;upper[58]=512
for i in range(29):
 for axis,extent in [(0,p['width_um']),(1,p['height_um'])]:
  members=[n for n in g['instances']if parents[n]==i];minimum=min(p['placements_um'][n][axis]for n in members);maximum=max(p['placements_um'][n][axis]+m['leaves'][g['instances'][n]]['die_um'][axis]for n in members)
  lower[2*i+axis]=max(-512,math.ceil((128-minimum)/4));upper[2*i+axis]=min(512,math.floor((extent-128-maximum)/4))
c=np.zeros(var);c[58]=0.001;
for i in range(len(nets)):c[59+4*i:59+4*i+4]=[-1,1,-1,1]
integrality=np.zeros(var);integrality[:58]=1;integrality[binary]=1;upper[binary]=1;A=coo_matrix((vv,(rr,cc)),shape=(len(ub),var)).tocsc();started=time.time();res=milp(c,integrality=integrality,bounds=Bounds(lower,upper),constraints=LinearConstraint(A,np.full(len(ub),-np.inf),ub),options=dict(time_limit=45,mip_rel_gap=0));receipt=dict(status=int(res.status),message=res.message,variables=var,constraints=len(ub),mst_edge_axes=mst_edges,reset_tree_search_budget_fraction=1.0,seconds=time.time()-started,whole_system_qualified=False,feasible=False)

if res.x is not None:
 x=res.x;assert np.max(A@x-np.array(ub))<1e-5 and max(abs(x[:58]-np.round(x[:58])))<1e-5
 shifts={n:[int(round(v))*4 for v in x[2*i:2*i+2]]for i,n in enumerate(names)}
 target=json.loads(json.dumps(p))
 for name,xy in target['placements_um'].items():
  delta=shifts[names[parents[name]]];target['placements_um'][name]=[xy[axis]+delta[axis]for axis in range(2)]
 for net,coords in target['terminals'].items():
  connection=g['connections'][net[4:]];ends=[connection['driver'],*connection['sinks']]
  for endpoint,xy in zip(ends,coords):
   if endpoint['instance']=='TOP':continue
   delta=shifts[names[parents[endpoint['instance']]]]
   for axis in range(2):xy[axis]+=delta[axis]//4
 rectangles=[(name,*target['placements_um'][name],*m['leaves'][g['instances'][name]]['die_um'])for name in g['instances']]
 for i,(name,x,y,w,h)in enumerate(rectangles):
  assert x>=0 and y>=0 and x+w<=p['width_um']and y+h<=p['height_um']
  for other,xx,yy,ww,hh in rectangles[:i]:assert x+w<=xx+1e-7 or xx+ww<=x+1e-7 or y+h<=yy+1e-7 or yy+hh<=y+1e-7,(name,other)
 weak=[];strong=[];mstreset=[]
 for name,ends,budget in nets:
  bound=grid_tree_bound(target['terminals'][name]);lower=max(bound['hpwl_grid_edges'],math.ceil(2*bound['metric_mst_grid_edges']/3))
  if bound['necessary_wire_grid_edges']>budget+1e-6:weak.append(name)
  if lower>budget+1e-6:strong.append(name)
  if name in reset_nets and bound['metric_mst_grid_edges']>budget+1e-6:mstreset.append(name)
 receipt.update(feasible=not weak and not strong and not mstreset,weak_violations=weak,stronger_violations=strong,reset_metric_mst_upper_violations=mstreset,maximum_total_shift_um=max(abs(v)for d in shifts.values()for v in d),minimum_required_bounded_steps=math.ceil(max(abs(v)for d in shifts.values()for v in d)/512),shifts_um=shifts,actual_nooverlap345verified=True,die_unchanged=True,scope='Local GLOBAL TARGET ONLY, not an executable proposal or physical qualification. Each actual cluster_shift_proposal remains <=512um under unchanged source guard. Target can be reached only by separately validated incremental steps with real current-base hashes and actual pin reconstruction after every step; all final RC/geometry/PG/300MHz gates remain mandatory. Conservative fixed reset spanning-tree upper search budget1.0 and exact rectangle separating-axis constraints; target all345physical rectangles independently checked. No macro/source/gate modified.')
 (out/'target-math-only.json').write_text(json.dumps(target));(out/'target-shifts-not-executable.json').write_text(json.dumps(dict(candidate_only=True,not_an_executable_proposal=True,shifts_um=shifts,whole_system_qualified=False),indent=2))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
