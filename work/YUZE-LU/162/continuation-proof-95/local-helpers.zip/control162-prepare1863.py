from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-milp1859.py').read_text(encoding='utf-8').replace('control162-milp1859','control162-milp1863')
start=s.index('  possible=[v for v in choices');end=s.index('mst_edges=0',start)
s=s[:start]+"  first,second,axis,gap=max(choices,key=lambda v:v[3]);assert gap>=-1e-6;add([(2*first+axis,1),(2*second+axis,-1)],max(0,gap))\n"+s[end:]
s=s.replace("assert length<=budget+1e-6,(name,length,budget);margins.append", "margins.append")
s=s.replace("receipt.update(feasible=True,", "receipt.update(feasible=min(margins)>=-1e-6,")
s=s.replace('exact all345rectangle disjunctions','exact all345rectangle nonoverlap retained via one baseline-separating axis per relevant pair; conservative local search restriction, not project gate').replace('All actual pin reconstruction/3RC/fullP&R300MHz required.','Baseline-separation restriction keeps a feasible origin but may exclude better arrangements. All actual pin reconstruction/3RC/fullP&R300MHz required.')
compile(s,'milp1863','exec');(b/'control162-milp1863.py').write_text(s,encoding='utf-8');print('Prepared bounded mathematical LP/MILP with fixed baseline separating axes; no physical acceptance.')
