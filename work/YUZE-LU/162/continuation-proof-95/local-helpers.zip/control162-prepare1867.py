from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-strong1847.py').read_text(encoding='utf-8').replace('control162-strong1847','control162-strong1867').replace('/cap-candidates/18390/','/cap-candidates/18620/').replace('/cap-necessary-1839/18390/','/cap-necessary-1862/18620/').replace('actual18390','actual18620')
anchor="rows=pd['placements'][0]['rows'];"
extra="math_candidate=json.loads((b/'control162-milp1860/candidate-math-only.json').read_bytes());assert p['terminals']==math_candidate['terminals']and p['placements_um']==math_candidate['placements_um'];"
assert anchor in s;s=s.replace(anchor,extra+anchor);compile(s,'strong1867','exec');p=b/'control162-strong1867.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
