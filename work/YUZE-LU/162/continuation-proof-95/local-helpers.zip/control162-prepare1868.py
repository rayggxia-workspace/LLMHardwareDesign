from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-full1846-remote.py').read_text(encoding='utf-8').replace('sready1846','sready1868').replace('audit-1846','audit-1868').replace('18460','18680').replace('cap-candidates/18390','cap-candidates/18620').replace('cap-necessary-1839/18390','cap-necessary-1862/18620').replace('stronger-necessary-1847','stronger-necessary-1867')
compile(s,'full1868','exec');(b/'control162-full1868-remote.py').write_text(s,encoding='utf-8')
d=(b/'control162-dispatch1846.py').read_text(encoding='utf-8').replace('control162-strong1847','control162-strong1867').replace('stronger-necessary-1847','stronger-necessary-1867').replace('control162-full1846','control162-full1868');compile(d,'dispatch1868','exec');p=b/'control162-dispatch1868.py';p.write_text(d,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
