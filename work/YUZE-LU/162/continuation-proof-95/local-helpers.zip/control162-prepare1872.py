from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-milp1864.py').read_text(encoding='utf-8').replace('control162-milp1864','control162-milp1872')
s=s.replace("mst_edges=0", "reset_nets={r['net']for r in rows if r['driver']['instance']=='reset_distribution'}\nmst_edges=0")
s=s.replace("if name in {'net_8939'}:","if name in reset_nets:")
s=s.replace("add(total,2*(math.floor(budget+1e-8)-(2 if name=='net_8939'else 0)))","add(total,math.floor(.95*budget+1e-8))")
s=s.replace('HPWL constraints all and conservative fixed metric MST bound for8939','HPWL constraints all and conservative fixed existing metric spanning-tree UPPER-bound budget95percent for allreset-drivennets; this is only a local search restriction, no gate threshold changes')
s=s.replace('mst_edge_axes=mst_edges','mst_edge_axes=mst_edges,reset_tree_search_budget_fraction=.95')
compile(s,'milp1872','exec');p=b/'control162-milp1872.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
