from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-milp1860.py').read_text(encoding='utf-8').replace('control162-milp1860','control162-milp1874')
s=s.replace('mst_edges=0',"reset_nets={r['net']for r in rows if r['driver']['instance']=='reset_distribution'}\nmst_edges=0")
s=s.replace("if name in {'net_8939'}:",'if name in reset_nets:').replace("add(total,2*(math.floor(budget+1e-8)-(2 if name=='net_8939'else 0)))",'add(total,math.floor(budget+1e-8))')
s=s.replace('c[58]=0.001','c[58]=0').replace('c[59+4*i:59+4*i+4]=[-1,1,-1,1]','c[59+4*i:59+4*i+4]=[0,0,0,0]')
s=s.replace('HPWL constraints all and conservative fixed metric MST bound for8939','HPWL constraints all plus conservative fixed metric spanningtree upper search limit for allreset nets; no project gate changes').replace('Objective minimizes totalbudgetedHPWL withmaxshift tiebreak','Feasibility-only objective zero; objective_budgeted_hpwl_um is not a wirelength measurement in this run')
compile(s,'milp1874','exec');p=b/'control162-milp1874.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
