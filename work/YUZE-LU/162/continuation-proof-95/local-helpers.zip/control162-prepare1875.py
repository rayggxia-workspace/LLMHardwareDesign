from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-fetch1858.py').read_text(encoding='utf-8').replace('control162-math-data1858','control162-math-data1875').replace('/cap-candidates/18390/','/cap-candidates/18620/').replace('control162-strong1847','control162-strong1867').replace('Fresh18390','Fresh18620')
compile(s,'fetch1875','exec');p=b/'control162-fetch1875.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
s=(b/'control162-milp1873.py').read_text(encoding='utf-8').replace('control162-math-data1858','control162-math-data1875').replace('control162-milp1873','control162-milp1876')
s=s.replace('Local mathematical feasibility only,','Local iterative mathematical feasibility only; base is actual18620, each new translation <=512um is checked by original unchanged proposal guard; cumulative from18390 may reach1024um and is NOT claimed <=512um. Fixed die, all345actual rectangles/nonoverlap/masks remain mandatory,')
compile(s,'milp1876','exec');p=b/'control162-milp1876.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
