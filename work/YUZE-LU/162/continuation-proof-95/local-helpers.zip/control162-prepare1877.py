from pathlib import Path
import subprocess,sys,json
b=Path(__file__).parent;(b/'control162-math-data1875/failure.json').write_text(json.dumps(dict(passed=False,diagnostic_only=True,reason='Read-only metadata discovery: rigid reuse output has no placement-search.json. No EDA task queued. Subsequent1877 explicitly binds unchanged base18390 cluster offsets plus actual18620 placement.')),encoding='utf-8')
s=(b/'control162-fetch1858.py').read_text(encoding='utf-8').replace('control162-math-data1858','control162-math-data1877').replace('/cap-candidates/18390/physical-graph.json','/cap-candidates/18620/physical-graph.json').replace('control162-strong1847','control162-strong1867').replace('Fresh18390','Fresh18620 with unchanged18390 rigid-cluster definitions')
compile(s,'fetch1877','exec');p=b/'control162-fetch1877.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
s=(b/'control162-milp1873.py').read_text(encoding='utf-8').replace('control162-math-data1858','control162-math-data1877').replace('control162-milp1873','control162-milp1878')
s=s.replace('Local mathematical feasibility only,','Local iterative mathematical feasibility only; actual18620 base with unchanged18390 rigid-member offsets, each new translation <=512um checked by original unchanged proposal guard; cumulative from18390 may reach1024um and is NOT claimed <=512um. Fixed die, all345actual rectangles/nonoverlap/masks mandatory,')
compile(s,'milp1878','exec');p=b/'control162-milp1878.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
