from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-milp1878.py').read_text(encoding='utf-8').replace('control162-milp1878','control162-math1880')
s=s.replace('gap>=256','gap>=1024').replace('lower[:58]=-128;upper[:58]=128;upper[58]=128','lower[:58]=-512;upper[:58]=512;upper[58]=512').replace('max(-128,','max(-512,').replace('min(128,','min(512,')
s=s[:s.index('if res.x is not None:')]+r'''
if res.x is not None:
 x=res.x;assert np.max(A@x-np.array(ub))<1e-5 and max(abs(x[:58]-np.round(x[:58])))<1e-5
 shifts={n:[int(round(v))*4 for v in x[2*i:2*i+2]]for i,n in enumerate(names)}
 target=json.loads(json.dumps(p))
 for name,xy in target['placements_um'].items():
  delta=shifts[names[parents[name]]];target['placements_um'][name]=[xy[axis]+delta[axis]for axis in range(2)]
 for net,coords in target['terminals'].items():
  connection=g['connections'][net[4:]];ends=[connection['driver'],*connection['sinks']]
  for endpoint,xy in zip(ends,coords):
   if endpoint['instance']=='TOP':continue
   delta=shifts[names[parents[endpoint['instance']]]]
   for axis in range(2):xy[axis]+=delta[axis]//4
 rectangles=[(name,*target['placements_um'][name],*m['leaves'][g['instances'][name]]['die_um'])for name in g['instances']]
 for i,(name,x,y,w,h)in enumerate(rectangles):
  assert x>=0 and y>=0 and x+w<=p['width_um']and y+h<=p['height_um']
  for other,xx,yy,ww,hh in rectangles[:i]:assert x+w<=xx+1e-7 or xx+ww<=x+1e-7 or y+h<=yy+1e-7 or yy+hh<=y+1e-7,(name,other)
 weak=[];strong=[];mstreset=[]
 for name,ends,budget in nets:
  bound=grid_tree_bound(target['terminals'][name]);lower=max(bound['hpwl_grid_edges'],math.ceil(2*bound['metric_mst_grid_edges']/3))
  if bound['necessary_wire_grid_edges']>budget+1e-6:weak.append(name)
  if lower>budget+1e-6:strong.append(name)
  if name in reset_nets and bound['metric_mst_grid_edges']>budget+1e-6:mstreset.append(name)
 receipt.update(feasible=not weak and not strong and not mstreset,weak_violations=weak,stronger_violations=strong,reset_metric_mst_upper_violations=mstreset,maximum_total_shift_um=max(abs(v)for d in shifts.values()for v in d),minimum_required_bounded_steps=math.ceil(max(abs(v)for d in shifts.values()for v in d)/512),shifts_um=shifts,actual_nooverlap345verified=True,die_unchanged=True,scope='Local GLOBAL TARGET ONLY, not an executable proposal or physical qualification. Each actual cluster_shift_proposal remains <=512um under unchanged source guard. Target can be reached only by separately validated incremental steps with real current-base hashes and actual pin reconstruction after every step; all final RC/geometry/PG/300MHz gates remain mandatory. Conservative fixed reset spanning-tree upper search budget1.0 and exact rectangle separating-axis constraints; target all345physical rectangles independently checked. No macro/source/gate modified.')
 (out/'target-math-only.json').write_text(json.dumps(target));(out/'target-shifts-not-executable.json').write_text(json.dumps(dict(candidate_only=True,not_an_executable_proposal=True,shifts_um=shifts,whole_system_qualified=False),indent=2))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
'''
compile(s,'math1880','exec');p=b/'control162-math1880.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
