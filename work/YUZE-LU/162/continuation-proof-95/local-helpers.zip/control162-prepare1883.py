from pathlib import Path
import subprocess,sys
b=Path(__file__).parent;s=(b/'control162-preview1882.py').read_text(encoding='utf-8').replace('control162-preview1882','control162-preview1883');start=s.index('def order(group):');end=s.index('groups=collections.defaultdict(list)',start);helper=(b/'control162-balanced1883.py').read_text(encoding='utf-8');s=s[:start]+helper+'\n'+s[end:]
s=s.replace('seq=order(groups[source])\n for start in range(0,len(seq),16):\n  output=28+len(banks);chunk=seq[start:start+16];points=[]','chunks=balanced_groups(groups[source])\n for chunk in chunks:\n  output=28+len(banks);points=[]')
s=s.replace('General allsource perimeter-only reset reassignment','Balanced allsource cyclic-perimeter reset reassignment with fixed bankcount, rowcounts differ<=1; finite32um/padding-lane search proxy')
compile(s,'preview1883','exec');p=b/'control162-preview1883.py';p.write_text(s,encoding='utf-8');subprocess.run([sys.executable,str(p)],check=True)
