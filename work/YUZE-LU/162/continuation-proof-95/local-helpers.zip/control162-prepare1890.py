from pathlib import Path
b=Path(__file__).parent
s=(b/'control162-binding1838-remote.py').read_text(encoding='utf-8').replace("root=b/'r256-current-pin-composition-1834';old=b/'r256-arbiter-composition-1773'","root=b/'r256-balanced-reset-composition-1888';old=b/'r256-current-pin-composition-1834'").replace('source-1830','source-1885').replace('r256-current-pin-source-audit-1832','r256-balanced-reset-source-audit-1886').replace("['profile']=='actual-pin-balanced316/1'","['profile']=='actual-pin-balanced316/reset-balanced-v2'").replace('_old1773','_old1834').replace('Actual1834','Actual1888').replace('exactold1773','exactold1834')
anchor="out.mkdir();(out/'receipt.json')"
extra="""assert g['boundary_links']['reset_banks']['partition_profile']=='spatial-balanced-link-counts/1'
sizes={}
for bank in g['boundary_links']['reset_banks']['banks']:sizes.setdefault(bank['source_instance'],[]).append(len(bank['link_instances']))
for name in ['macro_1','macro_2','macro_3']:assert sizes[name]==[9,9]
assert sizes['macro_r']==[14]*6 and sorted(sizes['s_port'])==[14,14,14,15,15,15,15]
prior_module=json.loads((old/'topology/topology.json').read_text())['modules']['control_system']
for name,cell in module['cells'].items():
 prior_cell=prior_module['cells'][name];assert all(cell[k]==prior_cell[k]for k in ['type','parameters','port_directions'])
 if name not in {r['instance']for r in g['boundary_links']['links']}:assert cell['connections']==prior_cell['connections']
 else:
  row=next(r for r in g['boundary_links']['links']if r['instance']==name);n=len(row['lanes']);assert cell['connections']['clk']==prior_cell['connections']['clk']and cell['connections']['out_data']==prior_cell['connections']['out_data']and cell['connections']['in_data'][:n]==prior_cell['connections']['in_data'][:n]
  assert cell['connections']['in_data'][n:]==cell['connections']['reset']*(8-n)
"""
assert anchor in s;s=s.replace(anchor,extra+anchor).replace("physical_types=23,instances=345,links=316,reset_banks=25,","physical_types=23,instances=345,links=316,reset_banks=25,balanced_bank_sizes=sizes,only_reset_and_unused_padding_wires_changed=True,")
compile(s,'binding1890','exec');(b/'control162-binding1890-remote.py').write_text(s,encoding='utf-8')
for oldname,newname in [('functionaudit1843-remote','functionaudit1891-remote'),('traces1843-remote','traces1891-remote')]:
 s=(b/('control162-'+oldname+'.py')).read_text(encoding='utf-8').replace('r256-current-pin-composition-1834','r256-balanced-reset-composition-1888').replace('source-1830','source-1885').replace('r256-current-pin-source-audit-1832','r256-balanced-reset-source-audit-1886').replace('sready1843','sready1891').replace('dynamic-03/node5','dynamic-05/node4').replace('scene1834','balanced-reset scene1888').replace('New1834','New1888')
 compile(s,newname,'exec');(b/('control162-'+newname+'.py')).write_text(s,encoding='utf-8')
s=(b/'control162-watch1844.py').read_text(encoding='utf-8').replace('control162-watch1844','control162-watch1892').replace('r256-current-pin-composition-1834','r256-balanced-reset-composition-1888').replace('dynamic-03/node5','dynamic-05/node4').replace('sready1834','sready1888').replace('functionaudit1843','functionaudit1891').replace('traces1843','traces1891').replace('1834','1888').replace('node5','node4')
compile(s,'watch1892','exec');(b/'control162-watch1892.py').write_text(s,encoding='utf-8');print('Fresh1888 state/source binding and actual numerical/trace continuation prepared.')
