from pathlib import Path
import subprocess,shlex
b=Path(__file__).parent;s=(b/'control162-refine1839-remote.py').read_text(encoding='utf-8').replace('r256-current-pin-composition-1834','r256-balanced-reset-composition-1888').replace('sready1839','sready1893').replace('source-1830','source-1885').replace("initial=root/'cap-initial-1837'","initial=root/'cap-initial'").replace('18390','18930').replace('cap-necessary-1839','cap-necessary-1893')
s=s.replace("p=b/'dynamic-03/node5/pending'/(name+'.json')","folder='dynamic-05/node4'if memory==64 else'dynamic-04/node25';p=b/folder/'pending'/(name+'.json')")
s=s.replace('actualnew3200Sarbiter actual-pin-balanced316 nativecap/pins/area andfresh1834graph drivefreshsearch','actual balanced-reset1888 graph, same3200Sarbiter/currentpin lanes and balanced25same-cycle resetbanks drivefreshnativecap search')
s=s.replace("assert not record.exists();assert json.loads", "assert json.loads((b/'r256-balanced-reset-source-audit-1886/receipt.json').read_text())['passed'];assert not record.exists();assert json.loads")
compile(s,'refine1893','exec');(b/'control162-refine1893-remote.py').write_text(s,encoding='utf-8');print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(s)],timeout=45).decode())
