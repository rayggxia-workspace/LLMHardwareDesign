from pathlib import Path
b=Path(__file__).parent
s=(b/'control162-full1846-remote.py').read_text(encoding='utf-8')
s=s.replace('r256-current-pin-composition-1834','r256-balanced-reset-composition-1888').replace('source-1830','source-1885').replace('sready1846','sready1898').replace('audit-1846','audit-1898').replace('18460','18980').replace('18390','18930').replace('cap-necessary-1839','cap-necessary-1893').replace('sready1842-current-scene-parallel-refill','sready1895-measured-initial-refill').replace('r256-current-pin-source-audit-1832','r256-balanced-reset-source-audit-1886').replace('stronger-necessary-1847','stronger-necessary-1897')
s=s.replace("assert sr['placement_sha256']==sha(place/'placement.json')and sr['native_pin_load_sha256']==sha(pin)","assert sr['inputs']['placement.json']['sha256']==sha(place/'placement.json')and sr['inputs']['native-pin-load.json']['sha256']==sha(pin);assert sr['reset_nets_checked']==53")
s=s.replace('Strictfresh1834','Strictfresh1888balancedreset').replace('fresh1834','fresh1888').replace('Onefreshfullcandidate','Onefreshbalancedresetfullcandidate')
# Only final joining depends on numerical simulation; all physical acceptance remains original.
assert "root/'cap-candidates/18930'"in s and "source=b/'source-1885'"in s and "seed=18980"in s
compile(s,'full1898','exec');(b/'control162-full1898-remote.py').write_text(s,encoding='utf-8')
print('Prepared only; no remote submission. Requires actual18930 all3RC and all53reset subset necessary diagnostics.')
