from pathlib import Path
import json,collections,ast,sys
import numpy as np
b=Path(__file__).parent;out=b/'control162-preview1882';assert not out.exists();out.mkdir();g=json.loads((b/'control162-current1848/topology/boundary-graph.json').read_bytes());p=json.loads((b/'control162-strong1867/placement.json').read_bytes());rows=g['boundary_links']['links'];native=json.loads((b/'control162-strong1867/native-pin-load.json').read_bytes())['placements'][0]['rows'];tree=ast.parse((b/'control162-subset1870.py').read_text(encoding='utf-8'))
for name in ['exact','subset']:
 fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name==name);exec(compile(ast.Module(body=[fn],type_ignores=[]),'subset1870','exec'))
lookup={}
for net,c in g['connections'].items():
 if c['driver']['instance']!='reset_distribution':continue
 for end,point in zip([c['driver'],*c['sinks']],p['terminals']['net_'+net]):lookup[(end['instance'],end['pin'])]=point
def order(group):
 def perimeter(row):
  x,y=row['source_pin_anchor_um'];w,h=row['source_pin_die_um'];return {2:x,1:w+y,3:2*w+h-x,0:2*(w+h)-y}[row['side']]
 seq=sorted(group,key=lambda row:(perimeter(row),row['instance']));options=[]
 for offset in range(len(seq)):
  rotated=seq[offset:]+seq[:offset];spans=[]
  for start in range(0,len(seq),16):
   points=[row['source_pin_anchor_um']for row in rotated[start:start+16]];spans.append(sum(max(p[a]for p in points)-min(p[a]for p in points)for a in (0,1)))
  options.append(((max(spans),sum(spans),offset),rotated))
 return min(options,key=lambda row:row[0])[1]
groups=collections.defaultdict(list)
for r in rows:groups[r['source_instance']].append(r)
results=[];banks=[]
for source in sorted(groups):
 seq=order(groups[source])
 for start in range(0,len(seq),16):
  output=28+len(banks);chunk=seq[start:start+16];points=[]
  for row in chunk:
   points.append(lookup[(row['instance'],'reset')]);points.extend(lookup[(row['instance'],'in_data['+str(i)+']')]for i in range(len(row['lanes']),8))
  driver=lookup[('reset_distribution','reset_out['+str(output)+']')];chosen=subset([driver,*points]);length=exact(chosen);old=next(r for r in native if r['driver']==dict(instance='reset_distribution',pin='reset_out['+str(output)+']',direction='output'));entry=dict(output=output,source=source,links=[r['instance']for r in chunk],padded_lanes=sum(8-len(r['lanes'])for r in chunk),exact_subset_steiner_edges=length,old_net=old['net']);banks.append(entry)
  if output in [31,33,35,47,48,50]:results.append(entry)
(out/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,diagnostic_only=True,banks=banks,scope='General allsource perimeter-only reset reassignment geometric preview with exact current18620 actual Link8 reset/padding coordinates. Same316links/25banks/53samecycle outputs, payload unchanged. Native inputcap/ground sums change with grouping; this preview makes no electrical or physical pass claim.'),indent=2));print(json.dumps(dict(counts={s:len(v)for s,v in groups.items()},selected=results)))
