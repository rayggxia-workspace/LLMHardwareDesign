from pathlib import Path
import json,collections,ast,sys
import numpy as np
b=Path(__file__).parent;out=b/'control162-preview1883';assert not out.exists();out.mkdir();g=json.loads((b/'control162-current1848/topology/boundary-graph.json').read_bytes());p=json.loads((b/'control162-strong1867/placement.json').read_bytes());rows=g['boundary_links']['links'];native=json.loads((b/'control162-strong1867/native-pin-load.json').read_bytes())['placements'][0]['rows'];tree=ast.parse((b/'control162-subset1870.py').read_text(encoding='utf-8'))
for name in ['exact','subset']:
 fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name==name);exec(compile(ast.Module(body=[fn],type_ignores=[]),'subset1870','exec'))
lookup={}
for net,c in g['connections'].items():
 if c['driver']['instance']!='reset_distribution':continue
 for end,point in zip([c['driver'],*c['sinks']],p['terminals']['net_'+net]):lookup[(end['instance'],end['pin'])]=point
"""Candidate grouping only; constant same-state reset outputs remain native."""
import itertools

def balanced_groups(rows):
 assert rows and len({r['source_instance']for r in rows})==1
 assert all(len(r['lanes'])in range(1,9)for r in rows)
 count=(len(rows)+15)//16;small,extra=divmod(len(rows),count)
 sizes=sorted(set(itertools.permutations([small+1]*extra+[small]*(count-extra))))
 def perimeter(row):
  x,y=row['source_pin_anchor_um'];w,h=row['source_pin_die_um'];assert w>0 and h>0 and 0<=x<=w and 0<=y<=h
  return {2:x,1:w+y,3:2*w+h-x,0:2*(w+h)-y}[row['side']]
 sequence=sorted(rows,key=lambda row:(perimeter(row),row['instance']));options=[]
 for offset in range(len(sequence)):
  rotated=sequence[offset:]+sequence[:offset]
  for lengths in sizes:
   chunks=[];costs=[];spans=[];start=0
   for size in lengths:
    chunk=rotated[start:start+size];start+=size;points=[r['source_pin_anchor_um']for r in chunk];span=sum(max(p[a]for p in points)-min(p[a]for p in points)for a in (0,1));pads=sum(8-len(r['lanes'])for r in chunk)
    # Finite placement-search proxy only: native input load and wiring
    # are remeasured by original cap/STA/physical gates after reassignment.
    chunks.append(chunk);spans.append(span);costs.append(span+32*(pads+size))
   options.append(((max(costs),sum(costs),max(spans),sum(spans),offset,lengths),chunks))
 result=min(options,key=lambda row:row[0])[1]
 assert len(result)==count and sorted(r['instance']for c in result for r in c)==sorted(r['instance']for r in rows)
 assert all(1<=len(c)<=16 for c in result)and max(map(len,result))-min(map(len,result))<=1
 return result

groups=collections.defaultdict(list)
for r in rows:groups[r['source_instance']].append(r)
results=[];banks=[]
for source in sorted(groups):
 chunks=balanced_groups(groups[source])
 for chunk in chunks:
  output=28+len(banks);points=[]
  for row in chunk:
   points.append(lookup[(row['instance'],'reset')]);points.extend(lookup[(row['instance'],'in_data['+str(i)+']')]for i in range(len(row['lanes']),8))
  driver=lookup[('reset_distribution','reset_out['+str(output)+']')];chosen=subset([driver,*points]);length=exact(chosen);old=next(r for r in native if r['driver']==dict(instance='reset_distribution',pin='reset_out['+str(output)+']',direction='output'));entry=dict(output=output,source=source,links=[r['instance']for r in chunk],padded_lanes=sum(8-len(r['lanes'])for r in chunk),exact_subset_steiner_edges=length,old_net=old['net']);banks.append(entry)
  if output in [31,33,35,47,48,50]:results.append(entry)
(out/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,diagnostic_only=True,banks=banks,scope='Balanced allsource cyclic-perimeter reset reassignment with fixed bankcount, rowcounts differ<=1; finite32um/padding-lane search proxy geometric preview with exact current18620 actual Link8 reset/padding coordinates. Same316links/25banks/53samecycle outputs, payload unchanged. Native inputcap/ground sums change with grouping; this preview makes no electrical or physical pass claim.'),indent=2));print(json.dumps(dict(counts={s:len(v)for s,v in groups.items()},selected=results)))
