from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready1888-balanced-reset-scene';root=b/'r256-balanced-reset-composition-1888';old=b/'r256-current-pin-composition-1834';assert not record.exists()and not root.exists();audit=b/'r256-balanced-reset-source-audit-1886/receipt.json';assert json.loads(audit.read_text())['passed'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();root.mkdir();record.mkdir();(root/'configurations.json').write_bytes((old/'configurations.json').read_bytes());template=json.loads((b/'route-selection-102/sready1834-current-native-pin-scene/tasks.json').read_text())['tasks'];assert len(template)==5;rows=[]
for t in template:
 spec=json.loads(json.dumps(t['spec']));spec['source_root']=str(b/'source-1885')
 def remap(x):return x.replace('/r256-current-pin-composition-1834/','/r256-balanced-reset-composition-1888/')
 spec['args']=[remap(x)for x in spec['args']];spec['requires']=[remap(x)for x in spec['requires']if 'source-audit-1832'not in x]+[str(audit)]
 if spec['script']=='topology.py':spec['args'].insert(0,'--link-balanced-reset-banks');assert '--link-current-pin-groups'in spec['args']
 if spec['script']=='system_upper.py':
  a=spec['args'];a[a.index('--seed')+1]='18880';spec['requires']+=list(map(str,[root/'native-sta/native-system-audit.json',root/'qualified-pg-inventory/receipt.json']))
 if spec['script']=='final_composition.py':spec['requires'].append(str(root/'native-sta/native-system-audit.json'))
 if spec['script']=='system_sta.py':assert spec['forecast_gib']==224
 if spec['script']in ['select.py','select_qualified.py','qualified_selection.py']:pass
 folder='dynamic-05/node4'if spec['script']in ['system_sta.py','final_composition.py','system_upper.py']else'dynamic-04/node25'
 if not rows:spec['requires'].append(str(b/'route-selection-102/sready1887-proven-reset-subset-replacement/receipt.json'))
 p=b/folder/'pending'/Path(t['path']).name.replace('sready1834','sready1888');assert not p.exists();rows.append(dict(path=str(p),spec=spec))
assert sum(r['spec']['script']=='topology.py'for r in rows)==1 and sum(r['spec']['script']=='final_composition.py'for r in rows)==1
for row in rows:
 p=Path(row['path']);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(row['spec']));tmp.rename(p);row['sha256']=sha(p)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,configurations_sha256=sha(root/'configurations.json'),scope='Fresh1888 samequalified23physicaltypes345instances316Link8/25resetbanks and53same-state/same-cycle outputs, optionalbalancedreset only passivewiring changes; payload/currentpinlanes/native masks/views unchanged. Source1885 full1030/archive/backoutaudit1886passed beforequeue; newselection gatedon exactown3invalidroute retirement1887. Selection/topology32GiBnode25 consumeverifiednatural16CPUvacancy; nativeSTA224node4 withtwo64oldsearches needs438.4GiB. Function128 andinitial64 dependon nativeaudit forresource ordering: co-run afterSTA withold128aggregate becomes320GiB needs400GiB, originalmemoryguards unchanged. Functionindependentfreshthreeinitial/eightprograms; no oldqualificationtransfer. InitialrequiresactualqualifiedPGinventory receipt beforeadmission. Freshgraph/sourceowners/function/traces/fullM11M12native-XOR/PG/threeRC300MHz stillmandatory. No newparent/foreignR/otherjob operations, no system pass.'),indent=2));print(json.dumps(dict(queued=5,scene=str(root),whole_system_qualified=False)))
