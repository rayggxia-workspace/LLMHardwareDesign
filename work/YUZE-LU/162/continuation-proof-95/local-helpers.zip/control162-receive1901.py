from pathlib import Path
import subprocess,json,zipfile,hashlib,re,datetime
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';w=r/'work/YUZE-LU/162';out=w/'continuation-proof-95';assert not out.exists();out.mkdir();sha=lambda v:hashlib.sha256(v).hexdigest()
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-95/** -text\n')
remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-95/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
d=json.loads((out/'index.json').read_bytes());assert sha((out/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='2e77d9d8bd1f48912f26882206572e43b6d03691e946809fdad4456384d33783'
with zipfile.ZipFile(out/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==206
 for v in d['files'].values():raw=z.read(v['zip_entry']);assert len(raw)==v['bytes']and sha(raw)==v['sha256']
 for name in ['r256-balanced-reset-source-audit-1886/receipt.json','r256-balanced-reset-composition-1888/source-binding-audit/receipt.json','r256-balanced-reset-composition-1888/cap-initial/receipt.json','route-selection-102/sready1887-proven-reset-subset-replacement/receipt.json','route-selection-102/sready1895-measured-initial-refill/receipt.json']:assert json.loads(z.read(name))['passed']
files={}
for p in b.glob('control162-*.py'):
 m=re.search(r'([0-9]+)(?:-remote)?\.py$',p.name)
 if m and 1856<=int(m.group(1))<=1901:files[p.name]=p.read_bytes()
for folder,names in [('control162-git-data-publish-1855',['receipt.json']),('control162-git-data-publish-1885',['receipt.json']),('control162-subset1870',['receipt.json']),('control162-crosscheck1871',['receipt.json']),('control162-strong1867',['receipt.json','reception.json']),('control162-contract1884',['receipt.json']),('control162-preview1883',['receipt.json'])]:
 for n in names:
  p=b/folder/n
  if p.exists():files[folder+'/'+n]=p.read_bytes()
for n in ['control162-watch1892.jsonl','control162-proven-reset1887.json','control162-online1856-verified.json']:
 p=b/n
 if p.exists():files[n]=p.read_bytes()
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,raw in files.items():z.writestr(n,raw)
with zipfile.ZipFile(out/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==raw for n,raw in files.items())
(out/'local-index.json').write_bytes(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(out/'local-helpers.zip').stat().st_size,sha256=sha((out/'local-helpers.zip').read_bytes()))),indent=2).encode())
(out/'reception.json').write_bytes(json.dumps(dict(passed=True,remote_entries=206,local_entries=len(files),all_actual_member_crc_bytes_sha256=True,whole_system_qualified=False),indent=2).encode())
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter='''# Issue162：均衡既有复位分支，继续完整组合物理验收

更新时间：{now}。Issue #162 / Draft PR #163。源码 `8d55501a05dc008781e00efa7655893650a59f6b` 已实际发布并精确读回；新增物理块的单块资格保留，**完整组合尚未通过，任务继续，不合并。**

旧18390与18620摆放虽然原始三档RC及更强2/3-MST必要检查均为零违规，独立精确Steiner子集DP与独立流MIP仍证明部分复位分支超过原1904.3 fF电容上限：18390的out31至少2097.513416 fF，18620的out35至少2086.572528 fF。对应证明均有独立MIP最优值精确匹配；其他未求得最优值的MIP只报告上下界。必要条件零违规不能称为实际通过。

冻结源1885仅增加默认关闭的均衡复位分组，M1/M2/M3各18个Link8由16+2改为9+9；保留23类型/345实例/316Link8/25bank、全部固定M1–M10宏和同拍复位状态。1030项源码、归档、精确反向补丁审计1886通过。默认旧模式、v1及新合同回放/拒绝通过，路由器及最终验收器相对1690原字节不变。

新1888实际选择、Yosys拓扑、独立完整载荷收缩、23项合格PG库存与源绑定1890通过。345项状态拥有者、全部23项物理行与旧1834完全相同；仅复位及未使用padding连线改变。main六宏、S内部788驱动和R保留，不操作外部R修订。

只在UID/job/PID/spec/source/实际输入证明/无最终输出逐项核验后，退役18460、18530、18680三个已证明超原电容门的本任务路由子步骤，保留全部部分输出；18项未启动后继原字节归档。旧3751、所有父作业、其他任务及旧功能实验不动。

新初始放置实际通过。唯一匹配旧同流程完成步骤95155.243的MaxRSS=516252 KiB，约0.492 GiB；23项物理行及初始代码相同，据此把仅初始放置内存预测64降至32 GiB，仍超过实测60倍。迁入node25第六个16CPU槽，实测426.215 GiB可用高于原汇总内存门400 GiB；只移除无数据依赖的资源排序前置。原生STA224 GiB、功能128 GiB及全部物理门保持。8父节点，c96六×16独立任务动态补位。

截至本快照，新原生STA运行，初始放置完成；1893五项真实原生残余/引脚负载/新摆放检查已入队，功能仿真在真实内存依赖后执行，再进行独立审计及代表任务轨迹。新摆放须检查全部53个复位输出精确子集下界，再提交完整七阶段物理链；下界通过仍须实际零冲突M11/M12、native几何XOR、PG、low/base/high分布RC下300MHz setup/hold/电气全部通过。

证据：[206项实际原件及资源/队列快照]({prefix}work/YUZE-LU/162/continuation-proof-95/index.json)、[实收校验]({prefix}work/YUZE-LU/162/continuation-proof-95/reception.json)、[新图源绑定]({prefix}work/YUZE-LU/162/source-binding-current1888.json)、[345项状态归属]({prefix}work/YUZE-LU/162/state-ownership-current1888.json)、[新图与23类138文件绑定]({prefix}work/YUZE-LU/162/current-delivery-binding1888.json)。原23类六文件及版图继续使用已实收索引；新图需要自己的全部组合资格。

规则rayggxia-project-collab 1.0.0。登记PR5 pending；缺board.json，看板unverified/同步pending；审查人待指定。不能以文档/排队/单块通过代替完整物理交付。
'''
(w/'continuation-checkpoint-95.md').write_text(chapter.format(now=now,prefix='../../../..'+'/'),encoding='utf-8')
for path,prefix in [('docs/STATUS.md','../'),('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;brief='[Checkpoint95]('+prefix+'work/YUZE-LU/162/continuation-checkpoint-95.md)：旧两摆放精确Steiner子集DP/独立MIP证明复位高RC超限，保留原件只退役三条已证失败子步骤。新1888均衡既有bank，23类型/345实例/316Link8/25bank和全部固定宏保留；1030源审计/实际Yosys/独立源绑定/PG库存/初始放置通过。原生STA及新放置/功能/轨迹与完整M11/M12/几何PG/三RC300MHz继续，尚无组合通过。节点25按实测同流程RSS调整仅初始预测32GiB，第六×16槽实际400GiB准入通过。\n\n';p.write_bytes(brief.encode()+p.read_bytes())
p=r/'docs/ARCHITECTURE.md';p.write_bytes(p.read_bytes()+('\n\nIssue162均衡复位新图：[Checkpoint95](../work/YUZE-LU/162/continuation-checkpoint-95.md)，[源/状态/最终文件绑定](../work/YUZE-LU/162/current-delivery-binding1888.json)。实际重放命令、冻结源、原字节任务规格与资源证据在proof95 ZIP索引；原最终门保持，不能从旧组合继承物理或功能资格。\n').encode())
print(json.dumps(dict(passed=True,remote_entries=206,local_entries=len(files),whole_system_qualified=False)))
