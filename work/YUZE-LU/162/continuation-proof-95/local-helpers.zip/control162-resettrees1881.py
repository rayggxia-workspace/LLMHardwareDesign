"""Construct and independently check finite rectilinear reset trees, math only."""
from pathlib import Path
import json,collections
b=Path(__file__).parent;out=b/'control162-resettrees1881';assert not out.exists();out.mkdir()
p=json.loads((b/'control162-strong1867/placement.json').read_bytes());rows=json.loads((b/'control162-strong1867/native-pin-load.json').read_bytes())['placements'][0]['rows'];g=json.loads((b/'control162-current1848/topology/boundary-graph.json').read_bytes());cl=json.loads((b/'control162-math-data1858/placement-search.json').read_bytes())['electrical_refinement']['clusters']
def merge(segments):
 lines=collections.defaultdict(list)
 for x,y,xx,yy in segments:
  if (x,y)==(xx,yy):continue
  assert x==xx or y==yy
  key=(0,y)if y==yy else(1,x);a,z=sorted((x,xx)if y==yy else(y,yy));lines[key].append((a,z))
 result=[]
 for (axis,c),spans in sorted(lines.items()):
  current=None
  for a,z in sorted(spans):
   if current is not None and a<=current[1]:current[1]=max(current[1],z)
   else:
    if current is not None:result.append((current[0],c,current[1],c)if axis==0 else(c,current[0],c,current[1]))
    current=[a,z]
  if current is not None:result.append((current[0],c,current[1],c)if axis==0 else(c,current[0],c,current[1]))
 return result
def length(tree):return sum(abs(x-xx)+abs(y-yy)for x,y,xx,yy in tree)
def projection(point,tree,start):
 x,y=point;options=[start]
 for a,c,z,d in tree:options.append((min(max(x,min(a,z)),max(a,z)),c)if c==d else(a,min(max(y,min(c,d)),max(c,d))))
 return min(options,key=lambda q:(abs(q[0]-x)+abs(q[1]-y),q))
def construct(points,start):
 tree=[];remaining=set(points)-{start}
 while remaining:
  options=[]
  for point in remaining:
   anchor=projection(point,tree,start);options.append((abs(point[0]-anchor[0])+abs(point[1]-anchor[1]),point,anchor))
  _,point,anchor=min(options);x,y=point;a,c=anchor
  candidates=[merge(tree+[(x,y,a,y),(a,y,a,c)]),merge(tree+[(x,y,x,c),(x,c,a,c)])];tree=min(candidates,key=lambda t:(length(t),t));remaining.remove(point)
 return tree
def verify(points,tree):
 assert merge(tree)==tree;vertices=set(points)
 for x,y,a,c in tree:vertices.update([(x,y),(a,c)])
 for x,y,a,c in tree:
  for xx,yy,aa,cc in tree:
   if y==c and xx==aa and min(x,a)<=xx<=max(x,a)and min(yy,cc)<=y<=max(yy,cc):vertices.add((xx,y))
 graph=collections.defaultdict(set);edge_length=0
 for x,y,a,c in tree:
  pts=sorted(q for q in vertices if(y==c and q[1]==y and min(x,a)<=q[0]<=max(x,a))or(x==a and q[0]==x and min(y,c)<=q[1]<=max(y,c)))
  for u,v in zip(pts,pts[1:]):graph[u].add(v);graph[v].add(u);edge_length+=abs(u[0]-v[0])+abs(u[1]-v[1])
 reach={points[0]}
 while True:
  more=set().union(*(graph[v]for v in reach))
  if more<=reach:break
  reach|=more
 assert set(points)<=reach and edge_length==length(tree)
results=[]
for row in rows:
 if row['driver']['instance']!='reset_distribution':continue
 points=sorted(set(map(tuple,p['terminals'][row['net']][1:])));parents={cl['members'][s['instance']]['parent']for s in g['connections'][row['net'][4:]]['sinks']};assert len(parents)==1
 starts={points[0],points[-1],min(points,key=lambda q:q[1]),max(points,key=lambda q:q[1])};trees=[construct(points,start)for start in sorted(starts)];tree=min(trees,key=lambda t:(length(t),t));verify(points,tree);anchor=projection(tuple(p['terminals'][row['net']][0]),tree,points[0]);assert anchor in points or any((y==c==anchor[1]and min(x,a)<=anchor[0]<=max(x,a))or(x==a==anchor[0]and min(y,c)<=anchor[1]<=max(y,c))for x,y,a,c in tree)
 results.append(dict(net=row['net'],driver=row['driver'],sink_parent=next(iter(parents)),sink_tree_grid_edges=length(tree),attachment_grid=anchor,segments=tree,sink_points=points,independent_connectivity_and_union_length_passed=True))
(out/'receipt.json').write_text(json.dumps(dict(passed=True,whole_system_qualified=False,diagnostic_only=True,results=results,scope='Finite constructed obstacle-free rectilinear sink tree plus fixed attachment. Independent graph split/connectivity and union-length checks prove valid tree UPPER bound, not necessary bound or physical acceptance. Only used as conservative placement-search restriction; all original physical/electrical gates unchanged.'),indent=2));print([(r['net'],r['sink_tree_grid_edges']*4)for r in results if r['net']in ['net_8920','net_8922','net_8924','net_8936']])
