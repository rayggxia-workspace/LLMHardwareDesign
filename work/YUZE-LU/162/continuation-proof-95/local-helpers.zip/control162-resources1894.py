import subprocess,shlex
q=r'''from pathlib import Path
import json,subprocess,datetime,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888'
for sub in ['selected','topology','source-binding-audit','qualified-pg-inventory','native-sta','cap-initial','function']:
 p=r/sub/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print('RECEIPT',sub,{k:d.get(k)for k in ['passed','execution_passed','typed_native_timing_passed','minimum_setup_ns','minimum_hold_ns','whole_system_qualified']})
for folder in ['dynamic-05/node4','dynamic-04/node25']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print('QUEUE',folder,d['active'])
 for f in(p/'commands').glob('*1888*'):print('ADMISSION',f.name,json.loads(f.read_text()).get('admission'))
p=b/'dynamic-03/node5';name='00-c-sready1837-initial-placement.json';cmd=p/'commands'/name;result=json.loads((p/'results'/name).read_text());start=cmd.stat().st_mtime;end=result['finished'];print('OLD_INITIAL_WINDOW',datetime.datetime.fromtimestamp(start).isoformat(),datetime.datetime.fromtimestamp(end).isoformat())
raw=subprocess.check_output(['sacct','-j','95155','--format=JobIDRaw,JobName,State,Start,End,MaxRSS','-n','-P'],universal_newlines=True);matches=[]
for line in raw.splitlines():
 fields=line.split('|')
 if len(fields)<6:continue
 try:a=datetime.datetime.strptime(fields[3],'%Y-%m-%dT%H:%M:%S').timestamp();z=datetime.datetime.strptime(fields[4],'%Y-%m-%dT%H:%M:%S').timestamp()
 except ValueError:continue
 if abs(z-end)<20 and abs(a-start)<120:matches.append(fields)
print('RESOURCE_MATCHES',matches)
out=b/'resource-evidence-1894';assert not out.exists();out.mkdir();(out/'sacct-95155.txt').write_text(raw);(out/'receipt.json').write_text(json.dumps(dict(time=time.time(),diagnostic_only=True,whole_system_qualified=False,original_task=name,command_sha256=json.loads(cmd.read_text())['spec_sha256'],command_mtime=start,result=result,matched_accounting_rows=matches,scope='Read-only own completed initial1837 actual Slurm resource accounting. No forecast or concurrency changed; adjustment requires unique completed step with usableMaxRSS plus current admission memory measurement.'),indent=2))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45).decode())
