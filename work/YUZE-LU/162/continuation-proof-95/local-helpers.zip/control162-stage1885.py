from pathlib import Path
import json,hashlib,subprocess,zipfile
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/balanced-reset1885';assert not out.exists();out.mkdir()
files={'contract1884.json':b/'control162-contract1884/receipt.json','actual-subset1870.json':b/'control162-subset1870/receipt.json','independent-crosscheck1871.json':b/'control162-crosscheck1871/receipt.json','geometric-preview1883.json':b/'control162-preview1883/receipt.json','online1856-verified.json':b/'control162-online1856-verified.json'}
for name,p in files.items():(out/name).write_bytes(p.read_bytes())
helpers={p.name:p.read_bytes()for p in [b/'control162-contract1884.py',b/'control162-subset1870.py',b/'control162-crosscheck1871.py',b/'control162-hanan1869.py',b/'control162-preview1883.py']}
with zipfile.ZipFile(out/'actual-local-checks.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name,data in helpers.items():z.writestr(name,data)
with zipfile.ZipFile(out/'actual-local-checks.zip')as z:assert z.testzip()is None and all(z.read(n)==d for n,d in helpers.items())
(out/'local-checks-index.json').write_bytes(json.dumps(dict(files={n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest())for n,d in helpers.items()},archive_sha256=hashlib.sha256((out/'actual-local-checks.zip').read_bytes()).hexdigest()),indent=2).encode())
(out/'README.md').write_bytes('''# Issue #162：保留固定宏，均衡现有 reset bank

对应 Issue #162 / PR #163。默认关闭的被动连线候选；全部 23 个物理类型、345 个实例、316 个 Link8、25 个 bank、53 路同状态同周期 reset 输出保留。main 六宏、S 内驱动、R 及其外部并行修改不动。不修改 RTL、native 版图、路由器或最终电气/几何/PG/300MHz 验收器。

实际 18390 / 18620 的原始三档最小线容及更强 2/3-MST 预检均为零违规，但仍有遗漏。对真实接点取八个实际存在的接点子集，按 Hanan 网格做精确整数 Steiner DP；又用独立多商品流 MIP 对照：18390 的 reset_out[31]/[33]/[35]，以及 18620 的 reset_out[35]，DP 与独立 MIP 最优值精确相等，必要高RC电容超过原 1904.3fF。18620 reset_out[33] 的独立 MIP 在3秒内仅得到界，但 DP 结果不依赖它，已区分记录。只证明这些固定摆放不满足原门槛，不表示项目不可行，不把先前预检零违规当成系统通过。

根因之一是 M1/M2/M3 各18个 Link8 被切成16+2，重分支几乎绕满周边。新增 `--link-balanced-reset-banks`，必须同时启用既有当前pin分组/R256/local-reset-padding/reference清单。按源周长邻近顺序轮转，在固定 bank 数量内均衡各 bank 的 Link8 数；M1/M2/M3 变成9+9，R为六组14，T为10+11，S仲裁器为四组15及三组14。代价中的32um负载项仅为搜索代理，不能代替真实电容验收。既有模式与 current-pin-v1 不启用新选项时保持原结果。

已实际执行：旧完整 topology 原字节与九项拒绝回放；v1 模块/完整 link 证明精确回放；新模式独立收缩回原29个载荷单元和端口；全部345类型、316条lane路径和时钟不变；25 bank、53同周期输出、所有padding归属检查；八项坏输入拒绝、输入顺序确定性检查。四文件语法与管理检查通过。几何预演仅说明分组改善，不是新电气或布局布线通过；S仲裁器等分组仍需新摆放与真实门槛修正。

下一步是冻结精确源码并完成全文件/归档/反向补丁审计，生成真实新图、重新检查原生RC/功能/代表轨迹，继续全部M11/M12物理链及三档RC300MHz。不继承旧组合资格、不在本次提交处停工、不自行合并。原始大输入及实际远程路径/SHA见随附JSON；本机诊断脚本包含本机路径，移机时须按原件收据重新实收数据。

规则 rayggxia-project-collab 1.0.0；登记PR5 pending；看板缺配置，unverified/同步pending；审查待指定；Issue in_progress / PR Draft。
'''.encode())
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/balanced-reset1885/*.json -text\n')
line='Issue162新候选：[均衡既有reset bank](../work/YUZE-LU/162/balanced-reset1885/README.md)。独立精确Steiner子集DP/MIP证明18390/18620若干reset分支仍超原电容门槛，先前必要条件零违规不是物理通过。新增默认关闭的均衡分组，将M1/M2/M3各18个Link8由16+2改为9+9；保持23类型/345实例/316Link8/25bank及全部固定宏/同拍reset状态。旧路径与v1精确回放、新合同/八项拒绝通过；新组合待实际冻结、Yosys/功能/轨迹及完整M11/M12/PG/native-XOR/三档RC300MHz重验。继续任务，不合并。\n\n'
for name in ['docs/STATUS.md','docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md']:
 p=r/name;p.write_bytes(((line.replace('../work/','../../work/')if name.startswith('progress/')else line)+p.read_text(encoding='utf-8')).encode())
p=r/'docs/ARCHITECTURE.md';p.write_bytes(('''## Issue162：固定25个reset bank的均衡分组候选

在既有当前pin分组命令上追加 `--link-balanced-reset-banks`；只改变同一53路固定、同状态、同拍输出之间的被动reset/padding连接，不增加状态、周期或物理实现。按源周长空间邻接并均衡 Link8 数量，保留25bank/316Link8；原模式默认不变。负载32um项只用于选组，不改任何实际电容/RC门槛。见[实际失败证据与源合同](../work/YUZE-LU/162/balanced-reset1885/README.md)。必须新图、全功能/轨迹与最终物理/三档RC300MHz全部重验。

'''+p.read_text(encoding='utf-8')).encode())
names=['project/experiments/control_v1/'+n for n in ['current_pin_groups.py','boundary_links.py','reset_link_banks.py','topology.py']]+['.gitattributes','docs/STATUS.md','docs/CONTROL_V1.md','docs/ARCHITECTURE.md','progress/YUZE-LU/STATUS.md','work/YUZE-LU/162/balanced-reset1885']
for name in names[:-1]:p=r/name;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*names],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:
  name=raw.decode();assert subprocess.check_output(['git','show',':'+name],cwd=r)==(r/name).read_bytes(),name
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Balance fixed reset bank loads while retaining the complete macro inventory'],cwd=r,check=True);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip())
