import subprocess,shlex
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888'
for sub in ['native-sta','cap-initial','cap-initial-necessary/native-pin-load','cap-candidates/18930','cap-necessary-1893/18930/native-pin-load','function','internal-program-traces']:
 p=r/sub/'receipt.json'
 if p.exists():
  d=json.loads(p.read_text());print('RECEIPT',sub,{k:v for k,v in d.items()if k in ['passed','execution_passed','typed_native_timing_passed','minimum_setup_ns','minimum_hold_ns','whole_system_qualified','error']})
 else:print('WAIT',sub)
for folder in ['dynamic-05/node4','dynamic-04/node25']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print('ACTIVE',folder,d.get('active'))
 for key in ['memory_admissions','waiting_for_complete_receipts']:
  print(key,str(d.get(key))[:2200])
 for f in (p/'results').glob('*1893*'):print('RESULT',f.name,f.read_text()[:700])
 for f in (p/'logs').glob('*1888*'):print('LOG',f.name,f.read_text(errors='replace')[-1600:])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
