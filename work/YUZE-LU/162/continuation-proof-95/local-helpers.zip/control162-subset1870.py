"""Exact integer Steiner DP on <=8 actual terminals: local diagnostic only."""
from pathlib import Path
import numpy as np
import json,math,hashlib,time
b=Path(__file__).parent;out=b/'control162-subset1870';assert not out.exists();out.mkdir()
def exact(points):
 pts=sorted(set(map(tuple,points)));assert len(pts)<=8 and all(type(v)is int for p in pts for v in p)
 nodes=[(x,y)for x in sorted({p[0]for p in pts})for y in sorted({p[1]for p in pts})];a=np.array(nodes,dtype=np.int64);dist=np.abs(a[:,None,:]-a[None,:,:]).sum(axis=2);dp={}
 for mask in range(1,1<<len(pts)):
  if mask&(mask-1)==0:row=np.abs(a-np.array(pts[mask.bit_length()-1])).sum(axis=1)
  else:
   row=np.full(len(nodes),10**12,dtype=np.int64);sub=(mask-1)&mask
   while sub:
    other=mask^sub
    if sub<other:row=np.minimum(row,dp[sub]+dp[other])
    sub=(sub-1)&mask
   row=(row[:,None]+dist).min(axis=0)
  dp[mask]=row
 return int(dp[(1<<len(pts))-1].min())
checks=[]
for pts,value in [([(0,0),(4,0),(0,3),(4,3)],10),([(0,0),(1,1),(2,2),(3,3)],6),([(0,0),(4,0),(2,2)],6),([(0,0),(4,0),(4,3),(0,3),(2,1)],11)]:
 actual=exact(pts)
 if len(pts)==5:
  # Independent exact flow-MIP comparison supplies this fifth-terminal oracle below.
  checks.append(dict(points=pts,value=actual,independent_mip_check_pending=True))
 else:assert actual==value;checks.append(dict(points=pts,value=actual,passed=True))
def subset(raw):
 pts=sorted(set(map(tuple,raw)));selected=[tuple(raw[0])]
 for key in [lambda p:p[0],lambda p:p[1],lambda p:p[0]+p[1],lambda p:p[0]-p[1]]:
  for p in [min(pts,key=key),max(pts,key=key)]:
   if p not in selected and len(selected)<8:selected.append(p)
 while len(selected)<min(8,len(pts)):
  p=max((p for p in pts if p not in selected),key=lambda p:min(abs(p[0]-q[0])+abs(p[1]-q[1])for q in selected));selected.append(p)
 return selected
results=[];inputs={}
for label,folder in [('18390','control162-strong1847'),('18620','control162-strong1867')]:
 for n in ['placement.json','native-pin-load.json']:
  p=b/folder/n;inputs[str(p)]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 p=json.loads((b/folder/'placement.json').read_bytes());rows=json.loads((b/folder/'native-pin-load.json').read_bytes())['placements'][0]['rows']
 for net in ['net_8920','net_8922','net_8924']:
  r=next(r for r in rows if r['net']==net);chosen=subset(p['terminals'][net]);length=exact(chosen);xs,ys=zip(*p['terminals'][net]);weak=max(xs)-min(xs)+max(ys)-min(ys)
  # In these actual rows the original weak lower bound is HPWL, independently checked.
  import sys
  sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
  original=grid_tree_bound(p['terminals'][net])['necessary_wire_grid_edges'];coefficient=(r['optimistic_total_ff']['high']-r['native_ground_cap_ff'])/original;total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+coefficient*length
  results.append(dict(placement=label,net=net,driver=r['driver'],subset=chosen,terminals_total=len(p['terminals'][net]),exact_subset_steiner_edges=length,high_necessary_total_ff=total,max_capacitance_ff=r['max_capacitance_ff'],high_necessary_violation=total>r['max_capacitance_ff']+1e-7))
receipt=dict(passed=True,whole_system_qualified=False,diagnostic_only=True,inputs=inputs,selfchecks=checks,results=results,theorem_source='https://epubs.siam.org/doi/10.1137/0114025',scope='Independent Dreyfus-Wagner subset merge/Manhattan-shortest-path DP on Hanan grid for at most8 actually present terminals; exact integer optimum for subset is a necessary lower bound for all actual terminals. No time-limited MIP dual used. Actual native/pin capacitance budgets unchanged; no P&R or timing acceptance, no gate/source/mask changes.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
