from pathlib import Path
import subprocess,shlex,json,time
b=Path(__file__).parent;host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';journal=b/'control162-watch1889.jsonl';assert not journal.exists()
def record(**d):
 d['time']=time.time()
 with journal.open('a',encoding='utf-8')as f:f.write(json.dumps(d)+'\n')
 print(json.dumps(d),flush=True)
try:
 for path,helper in [('selected/receipt.json','control162-pg1889-remote.py'),('topology/receipt.json','control162-binding1890-remote.py')]:
  record(waiting=path)
  for _ in range(720):
   q='from pathlib import Path;import json;p=Path('+repr(remote+'/r256-balanced-reset-composition-1888/'+path)+');print(json.dumps(json.loads(p.read_text())["passed"] if p.exists()else None))'
   try:r=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(q)],timeout=35))
   except (subprocess.SubprocessError,OSError)as e:record(connection_retry=type(e).__name__);time.sleep(15);continue
   if r is False:raise RuntimeError('Actual1888stage failed: '+path)
   if r is True:break
   time.sleep(15)
  else:raise TimeoutError(path)
  subprocess.run(['scp',str(b/helper),host+':'+remote+'/'+helper],check=True);subprocess.run(['ssh',host,'python3',remote+'/'+helper],check=True);record(completed=helper)
 record(completed_all=True,whole_system_qualified=False)
except BaseException as e:record(failed=True,error=str(e));raise
