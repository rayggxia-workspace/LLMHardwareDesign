from pathlib import Path
import subprocess,json,zipfile,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/continuation-proof-95';sha=lambda v:hashlib.sha256(v).hexdigest()
assert subprocess.check_output(['gh','api','user','--jq','.login'],cwd=r).decode().strip()=='YUZE-LU'
assert subprocess.check_output(['git','branch','--show-current'],cwd=r).decode().strip()=='task/162-programmable-control'
files=['.gitattributes','docs/STATUS.md','docs/ARCHITECTURE.md','docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md','work/YUZE-LU/162/continuation-checkpoint-95.md','work/YUZE-LU/162/continuation-proof-95','work/YUZE-LU/162/source-binding-current1888.json','work/YUZE-LU/162/state-ownership-current1888.json','work/YUZE-LU/162/current-delivery-binding1888.json']
p=r/files[5];p.write_bytes(p.read_bytes().replace(b'../../../../work/',b'../../../work/'))
for name in files[:6]:p=r/name;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*files],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:p=raw.decode();assert subprocess.check_output(['git','show',':'+p],cwd=r)==(r/p).read_bytes(),p
for archive,index in [('selected-originals.zip','index.json'),('local-helpers.zip','local-index.json')]:
 d=json.loads((out/index).read_bytes());assert sha((out/archive).read_bytes())==d['archive']['sha256']
 with zipfile.ZipFile(out/archive)as z:
  assert z.testzip()is None
  for v in d['files'].values():a=z.read(v['zip_entry']);assert len(a)==v['bytes']and sha(a)==v['sha256']
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Bind balanced-reset scene and preserve exact failure and resource evidence'],cwd=r,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip())
p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');assert "'1885')"in s;s=s.replace("'1885')","'1885','1902')");p.write_text(s,encoding='utf-8')
