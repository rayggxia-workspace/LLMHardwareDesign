from pathlib import Path
import subprocess,shlex,json,hashlib
b=Path(__file__).parent;out=b/'control162-math-data1907';assert not out.exists();out.mkdir();root='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888'
files={n:root+p for n,p in [('physical-graph.json','/cap-candidates/18930/physical-graph.json'),('placement-search.json','/cap-candidates/18930/placement-search.json'),('physical.json','/selected/physical.json'),('boundary-graph.json','/topology/boundary-graph.json'),('placement.json','/cap-candidates/18930/placement.json'),('native-pin-load.json','/cap-necessary-1893/18930/native-pin-load/native-pin-load.json')]}
q='from pathlib import Path;import json,hashlib;files='+repr(files)+';print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))';raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);idx=json.loads(raw)
for name,row in idx.items():
 p=out/name;subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(p)],check=True);data=p.read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'RECEPTION.json').write_bytes(raw);print('All6 actual18930 math inputs received/hashverified; no physical qualification.')
for origin,dest,old,new in [('control162-sinkscan1879.py','control162-sinkscan1908.py','1879','1908'),('control162-milp1878.py','control162-milp1909.py','1878','1909')]:
 s=(b/origin).read_text(encoding='utf-8').replace(old,new).replace('control162-math-data1877','control162-math-data1907').replace('control162-strong1867','control162-math-data1907').replace('control162-current1848/topology','control162-math-data1907').replace('control162-math-data1858','control162-math-data1907');(b/dest).write_text(s,encoding='utf-8')
