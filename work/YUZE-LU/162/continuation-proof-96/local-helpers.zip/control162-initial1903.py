import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time
r=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888')
p=json.loads((r/'cap-initial/placement.json').read_text());print('COUNTS',len(p['placements_um']),len(p['terminals']),sum(map(len,p['terminals'].values())))
d=json.loads((r/'cap-initial-necessary/native-pin-load/native-pin-load.json').read_text());print('INITIAL_ORIGINAL_3RC',d['placements'][0]['violations']);print('INITIAL_RESET_ROWS',sum('reset'in str(x['driver']).lower()for x in d['placements'][0]['rows']))
f=r/'function'
for p in f.glob('*'): 
 if p.is_file()and p.name in ['build.log','receipt.json','initial-1-162.json','initial-2-162.json','initial-2-163.json','hierarchical-inputs.json']:print('FUNCTION_FILE',p.name,p.stat().st_size,time.time()-p.stat().st_mtime)
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
