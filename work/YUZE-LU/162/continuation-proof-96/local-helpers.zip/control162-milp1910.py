from pathlib import Path
import json,math,time,sys,hashlib
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
b=Path(r'D:\Data\电路实验');root=b/'control162-math-data1907';repo=b/'LLMHardwareDesign-worktrees/issue-162-control';out=b/'control162-milp1910';assert not out.exists();out.mkdir();sys.path.insert(0,str(repo/'project/experiments/control_v1'))
from steiner_wire_bound import grid_tree_bound
from cluster_shift_proposal import apply
p=json.loads((root/'placement.json').read_bytes());g=json.loads((root/'physical-graph.json').read_bytes());m=json.loads((root/'physical.json').read_bytes());s=json.loads((root/'placement-search.json').read_bytes());e=s['electrical_refinement'];cl=e['clusters'];names=sorted(cl['dimensions']);ids={n:i for i,n in enumerate(names)};parents={n:ids[v['parent']]for n,v in cl['members'].items()};dims=np.array([cl['dimensions'][n]for n in names]);origins=np.array([p['placements_um'][n]for n in names]);rows=json.loads((root/'native-pin-load.json').read_bytes())['placements'][0]['rows'];nets=[]
for r in rows:
 name=r['net'];con=g['connections'][name[4:]];ends=[con['driver'],*con['sinks']];coords=p['terminals'][name];bound=grid_tree_bound(coords)['necessary_wire_grid_edges'];wire=r['optimistic_total_ff']['high']-r['native_ground_cap_ff'];assert wire>0 and bound>0;budget=(r['max_capacitance_ff']-r['native_ground_cap_ff']-r['minimum_input_pin_cap_ff'])*bound/wire
 nets.append((name,[(None if end['instance']=='TOP'else parents[end['instance']],*xy)for end,xy in zip(ends,coords)],budget))
origins=np.array([[p['placements_um'][n][axis]-cl['members'][n]['offset_um'][axis]for axis in range(2)]for n in names])
var=59+4*len(nets);rr=[];cc=[];vv=[];ub=[]
def add(items,limit):
 idx=len(ub);ub.append(limit)
 for k,v in items:rr.append(idx);cc.append(k);vv.append(v)
for i in range(58):add([(i,1),(58,-1)],0);add([(i,-1),(58,-1)],0)
binary=[];rects=[]
for name,xy in p['placements_um'].items():rects.append((parents[name],xy,m['leaves'][g['instances'][name]]['die_um']))
for i,(a,xy,wh)in enumerate(rects):
 for z,zz,zh in rects[:i]:
  if a==z:continue
  choices=[(a,z,axis,(zz[axis]-xy[axis]-wh[axis])/4)for axis in range(2)]+[(z,a,axis,(xy[axis]-zz[axis]-zh[axis])/4)for axis in range(2)]
  if any(gap>=256 for _,_,_,gap in choices):continue
  first,second,axis,gap=max(choices,key=lambda v:v[3]);assert gap>=-1e-6;add([(2*first+axis,1),(2*second+axis,-1)],max(0,gap))
reset_nets={r['net']for r in rows if r['driver']['instance']=='reset_distribution'}
import collections
def merge(segments):
    lines = collections.defaultdict(list)
    for x, y, xx, yy in segments:
        if (x, y) == (xx, yy):
            continue
        assert x == xx or y == yy
        key = (0, y) if y == yy else (1, x)
        a, z = sorted((x, xx) if y == yy else (y, yy))
        lines[key].append((a, z))
    result = []
    for (axis, c), spans in sorted(lines.items()):
        current = None
        for a, z in sorted(spans):
            if current is not None and a <= current[1]:
                current[1] = max(current[1], z)
            else:
                if current is not None:
                    result.append((current[0], c, current[1], c) if axis == 0 else (c, current[0], c, current[1]))
                current = [a, z]
        if current is not None:
            result.append((current[0], c, current[1], c) if axis == 0 else (c, current[0], c, current[1]))
    return result
def length(tree):
    return sum((abs(x - xx) + abs(y - yy) for x, y, xx, yy in tree))
def projection(point, tree, start):
    x, y = point
    options = [start]
    for a, c, z, d in tree:
        options.append((min(max(x, min(a, z)), max(a, z)), c) if c == d else (a, min(max(y, min(c, d)), max(c, d))))
    return min(options, key=lambda q: (abs(q[0] - x) + abs(q[1] - y), q))
def construct(points, start):
    tree = []
    remaining = set(points) - {start}
    while remaining:
        options = []
        for point in remaining:
            anchor = projection(point, tree, start)
            options.append((abs(point[0] - anchor[0]) + abs(point[1] - anchor[1]), point, anchor))
        _, point, anchor = min(options)
        x, y = point
        a, c = anchor
        candidates = [merge(tree + [(x, y, a, y), (a, y, a, c)]), merge(tree + [(x, y, x, c), (x, c, a, c)])]
        tree = min(candidates, key=lambda t: (length(t), t))
        remaining.remove(point)
    return tree
def verify(points, tree):
    assert merge(tree) == tree
    vertices = set(points)
    for x, y, a, c in tree:
        vertices.update([(x, y), (a, c)])
    for x, y, a, c in tree:
        for xx, yy, aa, cc in tree:
            if y == c and xx == aa and (min(x, a) <= xx <= max(x, a)) and (min(yy, cc) <= y <= max(yy, cc)):
                vertices.add((xx, y))
    graph = collections.defaultdict(set)
    edge_length = 0
    for x, y, a, c in tree:
        pts = sorted((q for q in vertices if y == c and q[1] == y and (min(x, a) <= q[0] <= max(x, a)) or (x == a and q[0] == x and (min(y, c) <= q[1] <= max(y, c)))))
        for u, v in zip(pts, pts[1:]):
            graph[u].add(v)
            graph[v].add(u)
            edge_length += abs(u[0] - v[0]) + abs(u[1] - v[1])
    reach = {points[0]}
    while True:
        more = set().union(*(graph[v] for v in reach))
        if more <= reach:
            break
        reach |= more
    assert set(points) <= reach and edge_length == length(tree)
mst_edges=0
for i,(name,ends,budget)in enumerate(nets):
 lo_x,hi_x,lo_y,hi_y=[59+4*i+j for j in range(4)]
 for parent,x,y in ends:
  for axis,v,l,h in [(0,x,lo_x,hi_x),(1,y,lo_y,hi_y)]:add([(l,1)]+([]if parent is None else[(2*parent+axis,-1)]),v);add([(h,-1)]+([]if parent is None else[(2*parent+axis,1)]),-v)
 add([(hi_x,1),(lo_x,-1),(hi_y,1),(lo_y,-1)],math.floor(budget+1e-8)-(2 if name=='net_8939'else 0))
 # A fixed existing metric spanning tree gives a conservative upper bound
 # on the new optimum MST. Its absolute edge lengths constrain MST/2 too.
 if name in reset_nets:
  points=sorted(set((e[1],e[2])for e in ends[1:]));sinkparents={e[0]for e in ends[1:]};assert len(sinkparents)==1
  starts={points[0],points[-1],min(points,key=lambda q:q[1]),max(points,key=lambda q:q[1])};trees=[construct(points,start)for start in sorted(starts)];tree=min(trees,key=lambda t:(length(t),t));verify(points,tree)
  driver=ends[0];anchor=projection((driver[1],driver[2]),tree,points[0]);target=(next(iter(sinkparents)),*anchor);total=[]
  for axis in range(2):
   aa,zz=driver,target;constant=aa[axis+1]-zz[axis+1];terms=[]
   if aa[0]is not None:terms.append((2*aa[0]+axis,1))
   if zz[0]is not None:terms.append((2*zz[0]+axis,-1))
   k=var;var+=1;add(terms+[(k,-1)],-constant);add([(u,-v)for u,v in terms]+[(k,-1)],constant);total.append((k,1));mst_edges+=1
  add(total,math.floor(budget-length(tree)+1e-8))

lower=np.zeros(var);upper=np.full(var,np.inf);lower[:58]=-128;upper[:58]=128;upper[58]=128
for i in range(29):
 for axis,extent in [(0,p['width_um']),(1,p['height_um'])]:
  members=[n for n in g['instances']if parents[n]==i];minimum=min(p['placements_um'][n][axis]for n in members);maximum=max(p['placements_um'][n][axis]+m['leaves'][g['instances'][n]]['die_um'][axis]for n in members)
  lower[2*i+axis]=max(-128,math.ceil((128-minimum)/4));upper[2*i+axis]=min(128,math.floor((extent-128-maximum)/4))
c=np.zeros(var);c[58]=0.001;
for i in range(len(nets)):c[59+4*i:59+4*i+4]=[-1,1,-1,1]
integrality=np.zeros(var);integrality[:58]=1;integrality[binary]=1;upper[binary]=1;A=coo_matrix((vv,(rr,cc)),shape=(len(ub),var)).tocsc();started=time.time();res=milp(c,integrality=integrality,bounds=Bounds(lower,upper),constraints=LinearConstraint(A,np.full(len(ub),-np.inf),ub),options=dict(time_limit=45,mip_rel_gap=0));receipt=dict(status=int(res.status),message=res.message,variables=var,constraints=len(ub),mst_edge_axes=mst_edges,reset_tree_search_budget_fraction=1.0,seconds=time.time()-started,whole_system_qualified=False,feasible=False)
if res.x is not None:
 x=res.x;assert np.max(A@x-np.array(ub))<1e-5 and max(abs(x[:58]-np.round(x[:58])))<1e-5;shifts={n:[int(round(v))*4 for v in x[2*i:2*i+2]]for i,n in enumerate(names)};sha=lambda name:hashlib.sha256((root/name).read_bytes()).hexdigest();proposal=dict(schema='control162-rigid-cluster-shifts/1',candidate_only=True,whole_system_qualified=False,base_sha256=sha('placement.json'),manifest_sha256=sha('physical.json'),graph_sha256=sha('boundary-graph.json'),shifts_um=shifts);pp=out/'proposal.json';pp.write_text(json.dumps(proposal,indent=2));candidate,proof,bindings=apply(pp,root/'placement.json',root/'physical.json',root/'boundary-graph.json',p,m,g);margins=[]
 for name,ends,budget in nets:
  length=grid_tree_bound(candidate['terminals'][name])['necessary_wire_grid_edges'];margins.append((budget-length)*4)
 receipt.update(feasible=min(margins)>=-1e-6,objective_budgeted_hpwl_um=float(res.fun-x[58]*0.001)*4,baseline_budgeted_hpwl_um=sum((max(v[1]for v in ends)-min(v[1]for v in ends)+max(v[2]for v in ends)-min(v[2]for v in ends))*4 for _,ends,_ in nets),shifts_um=shifts,max_shift_um=max(abs(v)for xy in shifts.values()for v in xy),minimum_necessary_margin_um=min(margins),proof=proof,bindings=bindings,scope='Local iterative mathematical feasibility only; actual balanced18930 base with unchanged18930 rigid-member offsets, each new translation <=512um checked by original unchanged proposal guard; cumulative from18930 may reach1024um and is NOT claimed <=512um. Fixed die, all345actual rectangles/nonoverlap/masks mandatory, all10930 original measured native/pin highRC budgets; HPWL constraints all and independentlyverified finite rectilinear sink-tree plus fixed on-tree attachment UPPER search bound for all53reset outputs; this is only a local search restriction, no gate threshold changes, actual grid_tree_bound independently rechecked for all. Objective minimizes totalbudgetedHPWL withmaxshift tiebreak, exact all345rectangle nonoverlap retained via one baseline-separating axis per relevant pair; conservative local search restriction, not project gate, integer4um <=512um rigid29cluster shifts, all345rectangles fixed die/orientations/externalpins verified. Baseline-separation restriction keeps a feasible origin but may exclude better arrangements. All actual pin reconstruction/3RC/fullP&R300MHz required. No electrical thresholds changed.')
 (out/'candidate-math-only.json').write_text(json.dumps(candidate))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
