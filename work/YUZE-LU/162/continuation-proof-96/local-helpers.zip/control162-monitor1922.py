from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888';d=dict(time=time.time(),whole_system_qualified=False,routes=[])
for seed in [19160,19210]:
 p=r/'upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log';row=dict(candidate=seed,route_receipt_exists=(p/'receipt.json').exists(),actual_final_trees_exist=(p/'trees.json').exists())
 if (p/'receipt.json').exists():row['receipt']=json.loads((p/'receipt.json').read_text())
 if f.exists():row.update(log_bytes=f.stat().st_size,log_age=time.time()-f.stat().st_mtime,tail=f.read_text(errors='replace')[-2200:])
 d['routes'].append(row)
for folder in ['dynamic-05/node4','dynamic-04/node25']:
 p=b/folder;st=json.loads((p/'queue-state.json').read_text());d[folder]=dict(active=st['active'],slots=st['slots'])
 for sub in ['commands','results']:
  for f in(p/sub).glob('*1921*'):
   x=json.loads(f.read_text());d[str(f)]={k:x[k]for k in ['admission','returncode']if k in x}
for label in ['function','internal-program-traces']:
 p=r/label/'receipt.json'
 if p.exists():d[label]=json.loads(p.read_text())
 else:
  p=r/label/'build.log'
  if p.exists():d[label]=dict(build_bytes=p.stat().st_size,build_age=time.time()-p.stat().st_mtime)
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);d=json.loads(raw);print(json.dumps(d,indent=2));(Path(__file__).parent/'control162-monitor1922-latest.json').write_bytes(raw)
