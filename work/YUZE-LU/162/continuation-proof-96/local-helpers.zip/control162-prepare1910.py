from pathlib import Path
import ast
b=Path(__file__).parent;s=(b/'control162-milp1909.py').read_text(encoding='utf-8').replace('control162-milp1909','control162-milp1910')
tree=ast.parse((b/'control162-resettrees1881.py').read_text(encoding='utf-8'));code='import collections\n'+'\n'.join(ast.unparse(x)for x in tree.body if isinstance(x,ast.FunctionDef))+'\n'
s=s.replace('mst_edges=0\n',code+'mst_edges=0\n')
a=s.index('  used={0};edges=[]');z=s.index('\nlower=np.zeros(var)',a)
block='''  points=sorted(set((e[1],e[2])for e in ends[1:]));sinkparents={e[0]for e in ends[1:]};assert len(sinkparents)==1
  starts={points[0],points[-1],min(points,key=lambda q:q[1]),max(points,key=lambda q:q[1])};trees=[construct(points,start)for start in sorted(starts)];tree=min(trees,key=lambda t:(length(t),t));verify(points,tree)
  driver=ends[0];anchor=projection((driver[1],driver[2]),tree,points[0]);target=(next(iter(sinkparents)),*anchor);total=[]
  for axis in range(2):
   aa,zz=driver,target;constant=aa[axis+1]-zz[axis+1];terms=[]
   if aa[0]is not None:terms.append((2*aa[0]+axis,1))
   if zz[0]is not None:terms.append((2*zz[0]+axis,-1))
   k=var;var+=1;add(terms+[(k,-1)],-constant);add([(u,-v)for u,v in terms]+[(k,-1)],constant);total.append((k,1));mst_edges+=1
  add(total,math.floor(budget-length(tree)+1e-8))
'''
s=s[:a]+block+s[z:];s=s.replace('HPWL constraints all and conservative fixed existing metric spanning-tree UPPER-bound budget100percent for allreset-drivennets','HPWL constraints all and independentlyverified finite rectilinear sink-tree plus fixed on-tree attachment UPPER search bound for all53reset outputs');s=s.replace('actual18620','actual balanced18930').replace('18390','18930');compile(s,'1910','exec');(b/'control162-milp1910.py').write_text(s,encoding='utf-8')
