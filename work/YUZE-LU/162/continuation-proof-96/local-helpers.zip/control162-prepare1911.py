from pathlib import Path
import ast
b=Path(__file__).parent;s=(b/'control162-milp1910.py').read_text(encoding='utf-8').replace('control162-milp1910','control162-milp1911')
t=ast.parse((b/'control162-subset1870.py').read_text(encoding='utf-8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='subset');s=s.replace('mst_edges=0\n',ast.unparse(fn)+'\n'+'''def attachment(points,driver):
 pts=sorted(set(points));nodes=[(x,y)for x in sorted({p[0]for p in pts})for y in sorted({p[1]for p in pts})];a=np.array(nodes,dtype=np.int64);dist=np.abs(a[:,None,:]-a[None,:,:]).sum(axis=2);dp={}
 for mask in range(1,1<<len(pts)):
  if mask&(mask-1)==0:row=np.abs(a-np.array(pts[mask.bit_length()-1])).sum(axis=1)
  else:
   row=np.full(len(nodes),10**12,dtype=np.int64);sub=(mask-1)&mask
   while sub:
    other=mask^sub
    if sub<other:row=np.minimum(row,dp[sub]+dp[other])
    sub=(sub-1)&mask
   row=(row[:,None]+dist).min(axis=0)
  dp[mask]=row
 row=dp[(1<<len(pts))-1];idx=int((row+np.abs(a-np.array(driver)).sum(axis=1)).argmin());return nodes[idx],int(row[idx])
mst_edges=0
''')
a=s.index('  points=sorted(set((e[1],e[2])');z=s.index('  driver=ends[0];anchor=',a)
end=s.index(';target=',z)
s=s[:a]+'''  raw=[(e[1],e[2])for e in ends];chosen=subset(raw);driver=ends[0];points=[v for v in chosen if v!=raw[0]];assert len(points)<=7
  sinkparents={e[0]for e in ends[1:]};assert len(sinkparents)==1
  anchor,treelength=attachment(points,raw[0])
  driver=ends[0]'''+s[end:]
s=s.replace('budget-length(tree)','budget-treelength').replace('independentlyverified finite rectilinear sink-tree plus fixed on-tree attachment UPPER search bound for all53reset outputs','independentlycrosschecked exact<=7sink Steiner DP plus fixed attachment subset-tree UPPER search restriction for all53reset outputs; subset is only necessary, independent actualall53 diagnostic mandatory')
compile(s,'1911','exec');(b/'control162-milp1911.py').write_text(s,encoding='utf-8')
