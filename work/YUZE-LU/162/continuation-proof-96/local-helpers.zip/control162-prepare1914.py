from pathlib import Path
import subprocess,shlex
b=Path(__file__).parent
s=(b/'control162-queue1862-remote.py').read_text(encoding='utf-8').replace('r256-current-pin-composition-1834','r256-balanced-reset-composition-1888').replace('sready1862','sready1914').replace('proposal-data-1862','proposal-data-1914').replace('source-1830','source-1885').replace('cap-necessary-1862','cap-necessary-1914').replace('18620','19140').replace('18390','18930').replace('sready1839','sready1893').replace('cap-necessary-1839','cap-necessary-1893').replace('r256-current-pin-source-audit-1832','r256-balanced-reset-source-audit-1886')
s=s.replace("p=b/'dynamic-05/node4/pending'","p=b/'dynamic-04/node25/pending'")
a=s.index("scope='Fresh1834/");z=s.index("'),indent=2)",a)
s=s[:a]+"scope='Fresh1888 actual18930 native/minpin original budgets. Exact all345 rectangle disjunction math feasibility,29rigidgroups4um <=512um, fixed die/orientations/native masks. All10930 stronger2/3MST plusall53 exactsubset necessary diagnostic all0 onmathematicalcandidate; actualnativepinreconstruction andfresh3RC mandatory now, thenactual53reset andfullphysical. Objective zero feasibility only; no wirelengthimprovement/physicaloptimality claim, rawinterpretation retained. Node25natural sixth16CPUslot andoriginalmemoryguard, no parent/cancel/foreignR/gatesource changes.'"+s[z+1:]
s=s.replace("math['max_shift_um']==512 and strong['violations']","math['max_shift_um']==512 and strong['reset_nets_checked']==53 and strong['violations']")
compile(s,'queue1914','exec');(b/'control162-queue1914-remote.py').write_text(s,encoding='utf-8')
host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-cluster-proposal-data-1914'
subprocess.run(['ssh',host,'mkdir','-p',remote],check=True)
for p,name in [(b/'control162-milp1912/proposal.json','proposal.json'),(b/'control162-milp1912/receipt.json','receipt.json'),(b/'control162-check1913/receipt.json','stronger-local.json'),(b/'control162-check1913/raw1912-interpretation.json','raw1912-interpretation.json')]:subprocess.run(['scp',str(p),host+':'+remote+'/'+name],check=True)
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(s)],timeout=45).decode())
