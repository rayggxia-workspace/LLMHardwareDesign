from pathlib import Path
b=Path(__file__).parent
s=(b/'control162-subset1897.py').read_text(encoding='utf-8').replace('control162-subset1897','control162-subset1915').replace('/cap-candidates/18930','/cap-candidates/19140').replace('/cap-necessary-1893/18930/','/cap-necessary-1914/19140/').replace('balanced-reset18930','balanced-reset actual19140')
s=s.replace("rows=pd['placements'][0]['rows'];results=[]", "predicted=json.loads((b/'control162-milp1912/candidate-math-only.json').read_bytes());assert p['terminals']==predicted['terminals']and p['placements_um']==predicted['placements_um'],'Actualall345placements/all11149pinarrays mustmatchmathproposal';rows=pd['placements'][0]['rows'];results=[]")
(b/'control162-subset1915.py').write_text(s,encoding='utf-8')
s=(b/'control162-full1898-remote.py').read_text(encoding='utf-8').replace('sready1898','sready1916').replace('audit-1898','audit-1916').replace('18980','19160').replace('cap-candidates/18930','cap-candidates/19140').replace('cap-necessary-1893/18930','cap-necessary-1914/19140').replace('stronger-necessary-1897','stronger-necessary-1915')
compile(s,'full1916','exec');(b/'control162-full1916-remote.py').write_text(s,encoding='utf-8')
s=(b/'control162-watch1904.py').read_text(encoding='utf-8').replace('watch1904','watch1917').replace('cap-necessary-1893/18930','cap-necessary-1914/19140').replace("glob('*1893*')","glob('*1914*')").replace('actual18930','actual19140').replace('subset1897','subset1915').replace('stronger-necessary-1897','stronger-necessary-1915').replace('full1898','full1916')
compile(s,'watch1917','exec');(b/'control162-watch1917.py').write_text(s,encoding='utf-8')
print('Prepared fresh actual19140 allpin/all53reset proof and strict sevenstage19160; no fullchain submitted yet.')
