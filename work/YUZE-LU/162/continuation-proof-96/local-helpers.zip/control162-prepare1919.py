from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-milp1918.py').read_text(encoding='utf-8').replace('control162-milp1918','control162-milp1919');a=s.index('  driver=ends[0];anchor=');z=s.index('\nlower=np.zeros(var)',a)
block='''  driver=ends[0];targetparent=next(iter(sinkparents));radius=math.floor(budget-length(tree)+1e-8);flags=[]
  for segment in tree:
   x,y,xx,yy=segment;k=var;var+=1;binary.append(k);flags.append((k,-1))
   # Exact distance-to-segment diamond facets. Choosing any segment yields
   # a real attachment to the same independently verified finite sink tree.
   ax=0 if y==yy else 1;other=1-ax;lo=min(segment[ax],segment[ax+2]);hi=max(segment[ax],segment[ax+2]);cross=segment[other]
   for sign in [-1,1]:
    for along,border in [(0,0),(-1,lo),(1,-hi)]:
     items=[];constant=sign*(driver[other+1]-cross)+along*driver[ax+1]+border
     for axis,coef in [(other,sign),(ax,along)]:
      if coef:
       if driver[0]is not None:items.append((2*driver[0]+axis,coef))
       if targetparent is not None:items.append((2*targetparent+axis,-coef))
     add(items+[(k,10000)],radius-constant+10000)
   mst_edges+=1
  if not flags:
   # Degenerate one-point sink tree.
   assert len(points)==1
   for sx in [-1,1]:
    for sy in [-1,1]:
     items=[];constant=sx*(driver[1]-points[0][0])+sy*(driver[2]-points[0][1])
     for axis,coef in [(0,sx),(1,sy)]:
      if driver[0]is not None:items.append((2*driver[0]+axis,coef))
      if targetparent is not None:items.append((2*targetparent+axis,-coef))
     add(items,radius-constant)
  else:add(flags,-1)
'''
s=s[:a]+block+s[z:];s=s.replace('fixed on-tree attachment','exact selectable on-tree segment attachment');compile(s,'1919','exec');(b/'control162-milp1919.py').write_text(s,encoding='utf-8')
