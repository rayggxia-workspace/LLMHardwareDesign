from pathlib import Path
import subprocess,shlex
b=Path(__file__).parent;s=(b/'control162-full1916-remote.py').read_text(encoding='utf-8').replace('sready1916','sready1921').replace('audit-1916','audit-1921').replace('19160','19210')
s=s.replace('import json,hashlib,time','import json,hashlib,time,subprocess')
extra="""node=b/'dynamic-04/node25';state=json.loads((node/'queue-state.json').read_text());assert state['job']=='95204'and state['slots']==6 and len(state['active'])<6
forecast=sum(json.loads((node/'pending'/(name+'.json')).read_text())['forecast_gib']for name in state['active'])
memory=json.loads(subprocess.check_output(['srun','--jobid=95204','--overlap','-n1','-c1','python3','-c',\"import json;print(json.dumps({k:int(v.split()[0])for k,v in [l.split(':',1)for l in open('/proc/meminfo')]if k=='MemAvailable'}))\"],universal_newlines=True));available=memory['MemAvailable']/1048576;required=(forecast+32)*1.2+16;assert available>required
refill_memory=dict(time=time.time(),actual_node25_available_gib=available,current_forecast_gib=forecast,added_route_forecast_gib=32,required_gib=required,active_before=state['active'],slots=6,scope='IndependentFastRoute sameactual19140/source1885/23qualifiedtypes/all53resetnecessaryzeros; natural sixth16CPUslot withoriginalmemoryguard. No newparent/cancel/foreignR/gatechanges.')
"""
s=s.replace("graph=root/'topology/boundary-graph.json';",extra+"graph=root/'topology/boundary-graph.json';")
s=s.replace("a=spec['args'];a[a.index('--seed')+1]=str(seed)","a=spec['args'];a[a.index('--seed')+1]=str(seed);a[a.index('--openroad-global-router')+1]='fastroute'")
s=s.replace("folder='dynamic-05/node4'","folder='dynamic-05/node4'if spec['script']=='system_sta.py'else'dynamic-04/node25'")
s=s.replace("a[a.index('--openroad-global-router')+1]=='cugr'","a[a.index('--openroad-global-router')+1]=='fastroute'")
s=s.replace("'strict_binding_audit'","'strict_binding_audit'")
s=s.replace("record.mkdir()\n", "record.mkdir();(record/'resource-refill.json').write_text(json.dumps(refill_memory,indent=2))\n")
s=s.replace('backendCUGR','backendFastRoute').replace('Existingnode4naturallyfreedplacementslot','Existingnode25natural sixth16CPUslot')
compile(s,'1921','exec');(b/'control162-full1921-remote.py').write_text(s,encoding='utf-8');print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(s)],timeout=45).decode())
