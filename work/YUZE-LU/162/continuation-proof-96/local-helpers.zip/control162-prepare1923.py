from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-proof95-remote.py').read_text(encoding='utf-8').replace('continuation-proof-95','continuation-proof-96')
s=s.replace("'stronger-necessary-1897'","'stronger-necessary-1897','cap-candidates/19140','cap-necessary-1914','stronger-necessary-1915','final-chain-binding-audit-1916','final-chain-binding-audit-1921'")
s=s.replace("'sready1895-measured-initial-refill'","'sready1895-measured-initial-refill','sready1914-current-rigid-preflight','sready1916-arbiter-fullchain','sready1921-arbiter-fullchain'")
s=s.replace("['1887','1888','1891','1893','1895']","['1887','1888','1891','1893','1895','1914','1916','1921']")
a=s.index('files={};archive=');s=s[:a]+"""for seed in [19160,19210]:
 p=root/'upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log'
 if f.exists():to=live/(str(seed)+'-active-route.log');to.write_bytes(f.read_bytes());add(to)
for f in (b/'r256-cluster-proposal-data-1914').glob('*'):add(f)
"""+s[a:]
a=s.index("scope='New balanced-reset1888");z=s.index("')\n(out/'index.json')",a)
s=s[:a]+"scope='Actual1888 nativeSTA execution/typedcoverage passed diagnostic only, genericpassedFalse; freshfunction running. Actual18930 original3RCzeros butnew independentall53reset exactsubset reveals6highviolations, full1898 neverqueued. Local1912 exactall345rectangledisjunction feasibility proposal fixed29groups/max512um, all10930stronger and53exactsubset mathzeros; inheritedwrongobjective/scope corrected inrawinterpretation retainingraw. Actual19140 actualpinreconstruction all345placements/all11149terminalarrays exactlymatchmath; originalfresh3RC and10930stronger/all53exactsubset allzero. Strictsevenstage19160CUGR and19210FastRoute actualqueued/routeadmitted, alloriginalnativeXOR/PG/lowbasehigh300MHz finalgates unchanged. Node25actualmemory457175592960bytes>400GiB, real sixth16CPUslot used. Wholecomposition jointacceptance/function/traces stillpending, no qualification or gate relaxation, preserveallfailedmathmodels andrawreports.'"+s[z+1:]
compile(s,'proof96','exec');p=b/'control162-proof96-remote.py';p.write_text(s,encoding='utf-8');remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/control162-proof96-remote.py';subprocess.run(['scp',str(p),remote],check=True);subprocess.run(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3','/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/control162-proof96-remote.py'],check=True)
