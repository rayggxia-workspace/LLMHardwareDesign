from pathlib import Path
import subprocess,json,zipfile,hashlib,re,datetime
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';w=r/'work/YUZE-LU/162';out=w/'continuation-proof-96';assert not out.exists();out.mkdir();sha=lambda v:hashlib.sha256(v).hexdigest()
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-96/** -text\n')
remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-96/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
d=json.loads((out/'index.json').read_bytes());assert sha((out/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='0ee9ef459a8ea0d2f9aeb05fc6b8b0b5259ffcdd9843d1610a414032e86323b7'
with zipfile.ZipFile(out/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==823
 for v in d['files'].values():raw=z.read(v['zip_entry']);assert len(raw)==v['bytes']and sha(raw)==v['sha256']
 root='r256-balanced-reset-composition-1888/'
 native=json.loads(z.read(root+'native-sta/receipt.json'));assert native['execution_passed']and native['typed_native_timing_passed']and native['native_coverage_audit_passed']and not native['passed']and not native['whole_system_qualified']
 actual=json.loads(z.read(root+'stronger-necessary-1915/receipt.json'));assert actual['violations']==dict(low=0,base=0,high=0)and actual['reset_nets_checked']==53 and actual['rows_checked']==10930
 for label in ['1916','1921']:assert json.loads(z.read(root+'final-chain-binding-audit-'+label+'/receipt.json'))['passed']
files={}
for p in b.glob('control162-*.py'):
 m=re.search(r'([0-9]+)(?:-remote)?\.py$',p.name)
 if m and 1896<=int(m.group(1))<=1924:files[p.name]=p.read_bytes()
for folder in ['control162-subset1897','control162-subset1905','control162-sinkscan1908','control162-milp1909','control162-milp1910','control162-milp1911','control162-milp1912','control162-check1913','control162-subset1915','control162-milp1918','control162-milp1919','control162-git-data-publish-1902']:
 for n in ['receipt.json','reception.json','RECEPTION.json','proposal.json','raw1912-interpretation.json']:
  p=b/folder/n
  if p.exists():files[folder+'/'+n]=p.read_bytes()
for n in ['control162-watch1904.jsonl','control162-watch1917.jsonl','control162-online1906-verified.json','control162-monitor1922-latest.json']:
 p=b/n
 if p.exists():files[n]=p.read_bytes()
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,raw in files.items():z.writestr(n,raw)
with zipfile.ZipFile(out/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==raw for n,raw in files.items())
(out/'local-index.json').write_bytes(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(out/'local-helpers.zip').stat().st_size,sha256=sha((out/'local-helpers.zip').read_bytes()))),indent=2).encode())
(out/'reception.json').write_bytes(json.dumps(dict(passed=True,remote_entries=823,local_entries=len(files),all_actual_member_crc_bytes_sha256=True,whole_system_qualified=False),indent=2).encode())
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter=f'''# Issue162：新摆放真实引脚与53路复位下界通过，完整双后端物理链运行

更新时间：{now}。Issue #162 / Draft PR #163。main六宏、S内部驱动及外部R修订保留，源1885及全部原验收门保持。**完整组合仍未通过，继续任务，不合并。**

新1888原生STA完成，执行/分类/覆盖审计通过；零上层RC min setup +0.010286ns、hold +0.000194ns。通用passed=False是实际原件，不能当成最终300MHz通过。新组合功能仿真在node4独立运行，最终仍需三初态八程序、独立审计及真实内部/外部任务轨迹。

实际18930原三档必要条件零违规，但新增全部53复位精确子集检查发现6条high超限34.284～302.014fF，完整1898链没有提交。失败原件保留。保守固定分离轴/固定树搜索无解只代表该受限数学模型，不是物理不可行证明。

数学1912改用全部345矩形的完整非重叠析取，得到29宏组每轴整数4um、最大512um的平移提案，die、方向、宏内版图及成员相对位置不变；原提案guard不改。零目标仅求可行解，不宣称线长或物理最优。原报告继承了旧模板objective_budgeted_hpwl_um=-0.512和部分搜索描述，均不能解释成线长；保留原字节并以raw1912-interpretation明确更正。提案独立复查10930网更强2/3MST及53精确子集诊断全0。

19140在真实服务器从合格宏重建全部native signal/PG pin，通过原诊断。独立实收逐项比较345位置/11149完整接点数组与提案精确相等；新actual native/minpin三RC、10930更强下界及全部53复位精确子集均0。它们仍是必要条件，不能替代实际布线或STA。

实际严格七阶段19160 CUGR与19210 FastRoute各已提交、路由已准入。每链均包括route、完整geometry/native XOR、PG、low/base/high分布RC下300MHz原生覆盖setup/hold/电气、最终联合交付；最终join还需新1888功能审计及轨迹。source1885全23类/345实例绑定、验收六键、12项真实输入SHA及七项非router变更独立审计通过，全部路由器和最终门保持。

CUGR真实日志为11149网、24760接点；metal1–metal10信号资源0，仅metal11/metal12非零。node4为c64四×16槽，功能与CUGR独立并发；node25 c96六×16，FastRoute动态补位准入实测457175592960bytes，高于原汇总400GiB要求。8父节点保留，不取消其他任务，不修改并行R。

原件与校验：[823项实际原件](continuation-proof-96/index.json)、[实收CRC/字节/SHA](continuation-proof-96/reception.json)、[本地数学/失败/实际53项诊断与辅助源](continuation-proof-96/local-index.json)。继续使用[23类型138六文件与新图绑定](current-delivery-binding1888.json)、[345项状态归属](state-ownership-current1888.json)。所有有状态逻辑在固定M1–M10；M11/M12没有新增活动单元。未授予系统物理资格。

实际check_project通过，只代表管理结构。规则1.0.0；登记PR5 pending；缺board.json，看板unverified/同步pending；审查待指定。下一步持续检查两条真实物理链，定位实际失败并迭代，最终交付所有声明组合的版图/六文件/300MHz/任务轨迹/源绑定。
'''
(w/'continuation-checkpoint-96.md').write_text(chapter,encoding='utf-8')
for path,prefix in [('docs/STATUS.md','../'),('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;brief=f'[Checkpoint96]({prefix}work/YUZE-LU/162/continuation-checkpoint-96.md)：18930全部53复位检查发现6high超限，未提交完整1898；19140经真实345位置/11149接点重建、原三RC/10930更强及53精确子集必要诊断全0。19160 CUGR与19210 FastRoute完整七阶段实际准入，node25六×16/实测内存门通过；新功能独立运行。原生STA零上层RC仅诊断，完整M11/M12/几何PG/三RC300MHz/功能轨迹仍未联合通过，任务继续。\n\n';p.write_bytes(brief.encode()+p.read_bytes())
print(json.dumps(dict(passed=True,remote_entries=823,local_entries=len(files),whole_system_qualified=False)))
