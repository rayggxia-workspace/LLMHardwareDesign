from pathlib import Path
import ast,json,math,sys
import numpy as np
b=Path(__file__).parent;out=b/'control162-sinkscan1908';assert not out.exists();out.mkdir()
tree=ast.parse((b/'control162-subset1870.py').read_text(encoding='utf-8'))
for name in ['exact','subset']:
 fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name==name);exec(compile(ast.Module(body=[fn],type_ignores=[]),'subset1870','exec'))
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
p=json.loads((b/'control162-math-data1907/placement.json').read_bytes());rows=json.loads((b/'control162-math-data1907/native-pin-load.json').read_bytes())['placements'][0]['rows'];g=json.loads((b/'control162-math-data1907/boundary-graph.json').read_bytes());cl=json.loads((b/'control162-math-data1907/placement-search.json').read_bytes())['electrical_refinement']['clusters'];results=[]
for r in rows:
 if r['driver']['instance']!='reset_distribution':continue
 points=p['terminals'][r['net']];full=grid_tree_bound(points);sink=grid_tree_bound(points[1:]);wire=r['optimistic_total_ff']['high']-r['native_ground_cap_ff'];budget=(r['max_capacitance_ff']-r['native_ground_cap_ff']-r['minimum_input_pin_cap_ff'])*full['necessary_wire_grid_edges']/wire;chosen=subset(points[1:]);lower=exact(chosen);parents=sorted({cl['members'][s['instance']]['parent']for s in g['connections'][r['net'][4:]]['sinks']});results.append(dict(net=r['net'],driver=r['driver'],sink_parents=parents,budget_edges=budget,sink_mst_edges=sink['metric_mst_grid_edges'],exact_sink_subset_edges=lower,necessary_invariant_failure=len(parents)==1 and lower>budget+1e-7,tree_upper_search_invariant_infeasible=sink['metric_mst_grid_edges']>budget+1e-7))
receipt=dict(passed=True,diagnostic_only=True,whole_system_qualified=False,results=results,scope='Actual18620 allreset fixed sink-only MST and independent exact8terminal subset diagnostic. Single-parent sink-only failures cannot be fixed by rigid parent or driver translation; MST>budget only disproves conservative MST search restriction, not actual routing.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps([r for r in results if r['tree_upper_search_invariant_infeasible']or r['necessary_invariant_failure']]))
