import subprocess,shlex
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();p=b/'route-selection-102/sready1916-arbiter-fullchain/tasks.json';d=json.loads(p.read_text());assert len(d['tasks'])==7
for row in d['tasks']:
 p=Path(row['path']);assert sha(p)==row['sha256'];s=row['spec'];assert s['source_root']==str(b/'source-1885');a=s['args'];out=a[a.index('--out')+1];assert '/upper-candidates/19160/'in out
 print('STAGE',s['script'],s['forecast_gib'],out)
 if s['script']=='system_sta.py':assert s['forecast_gib']==224 and '--stitch-native-access'in a and '--audit-native-coverage'in a
audit=json.loads((r/'final-chain-binding-audit-1916/receipt.json').read_text());assert audit['passed'];print('FULLCHAIN_BINDING_PASS',len(audit['inputs']))
for folder in ['dynamic-05/node4','dynamic-04/node25']:
 p=b/folder;d=json.loads((p/'queue-state.json').read_text());print('ACTIVE',folder,d['active'])
 for sub in ['commands','results']:
  for f in (p/sub).glob('*1916*'):
   x=json.loads(f.read_text());print(sub,f.name,{k:x[k]for k in ['admission','returncode','finished']if k in x})
f=r/'upper-candidates/19160/route/openroad-search/case-0/openroad.log'
if f.exists():print('ROUTE_LOG',f.stat().st_size,f.read_text(errors='replace')[-3000:])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
