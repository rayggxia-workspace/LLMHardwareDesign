set_thread_count 16
read_db {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-fixed-pg-235/2292/delivery/6_final.odb}
set f [open {/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888/cap-necessary-1893/18930/native-pin-load/control_route_r8/pins.tsv} w]

foreach port [[ord::get_db_block] getBTerms] {
 if {[$port getSigType] in {POWER GROUND}} {continue}
 set net [$port getNet];if {$net eq "NULL"} {error "Disconnected actual boundary"}
 puts $f "PORT\t[$port getName]"
 foreach term [$net getITerms] {
  set pin [$term getMTerm]
  if {[$pin getSigType] in {POWER GROUND}} {continue}
  if {[$pin getIoType] ne "INPUT"} {continue}
  set inst [$term getInst]
  puts $f "PIN\t[$port getName]\t[$inst getName]\t[[$inst getMaster] getName]\t[$pin getName]"
 }
}
close $f
