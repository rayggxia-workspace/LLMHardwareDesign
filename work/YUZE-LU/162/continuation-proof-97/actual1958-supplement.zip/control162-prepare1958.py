from pathlib import Path
import subprocess,shlex
b=Path(__file__).parent;s=(b/'control162-full1931-remote.py').read_text(encoding='utf-8').replace('1931','1958').replace('19310','19580').replace('19290','19540').replace('cap-necessary-1929','cap-necessary-1954').replace('stronger-necessary-1930','stronger-necessary-1955')
old="folder='dynamic-05/node4'if spec['script']=='system_sta.py'else'dynamic-03/node5'";assert old in s
s=s.replace(old,"folder={'low':'dynamic-09/node3','base':'dynamic-06/node26','high':'dynamic-08/node6'}[spec['args'][spec['args'].index('--rc-variant')+1]]if spec['script']=='system_sta.py'else'dynamic-08/node6'")
s=s.replace('Existingnode5naturallyfreedslot withseparateoriginalnode4STA andnode4STA withoriginalmemoryguard','Existingnode6naturallyfreedslot after1954actualnativepins; low/base/high assignedfromoutset acrosssource1885node3/source236actualnode24/source269node6, unchanged224GiBforecasts andoriginalaggregate memoryguard')
p=b/'control162-full1958-remote.py';assert not p.exists();p.write_text(s,encoding='utf-8');compile(s,'full1958','exec');host='yuzelu@10.129.166.172';subprocess.run(['scp',str(p),host+':/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'+p.name],check=True);print(subprocess.check_output(['ssh','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(s)],timeout=45).decode())
