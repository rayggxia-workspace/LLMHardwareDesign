from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,hashlib,re,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=root/'cap-candidates/5380/placement.json';bp=json.loads(base.read_text());rp=root/'cap-necessary-538/5380/native-pin-load/receipt.json';receipt=json.loads(rp.read_text());print('PIN_INPUTS',list(receipt.get('inputs',{})))
proof=b/'control162-proven-reset5380-1937.json';known={12560,12840,13120,10711,12100,13560,12561,13121,11400,11920,12220,10710,10900,12101,14310,11401,11921,12221,11204,13240,13320,13460,15220,5494,5495,11205,13321,15340,15341};rows=[]
for folder in ['dynamic-05/node2','dynamic-02/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 node=b/folder;state=json.loads((node/'queue-state.json').read_text())
 for name in state['active']:
  specpath=node/'pending'/(name+'.json');s=json.loads(specpath.read_text());a=s['args']
  if s['script']!='system_upper.py'or'--out'not in a:continue
  out=Path(a[a.index('--out')+1]);parent=out.parent.name
  if not parent.isdigit()or int(parent)not in known:continue
  if '--reuse-placement'not in a or a[a.index('--reuse-placement')+1]!=str(base.parent):continue
  if any(v in a for v in ['--cluster-translation-proposal','--s-translation-proposal','--expand-routing-halo-um']):continue
  assert out==root/'upper-candidates'/parent/'route';actual=out/'placement.json';p=json.loads(actual.read_text());equal_positions=p['placements_um']==bp['placements_um'];equal_terms=p['terminals']==bp['terminals'];budget=a[a.index('--route-residual-budget')+1]if'--route-residual-budget'in a else None
  if not(equal_positions and equal_terms and budget==str(root/'cap-necessary-538/5380/native-pin-load/native-pin-load.json')):print('EXCLUDED',parent,dict(equal_positions=equal_positions,equal_terms=equal_terms,budget=budget));continue
  source=Path(s['source_root']);manifest=json.loads((source/'source-manifest.json').read_text());cmd=node/'commands'/(name+'.json');command=json.loads(cmd.read_text());assert command['spec_sha256']==sha(specpath)
  rows.append(dict(candidate=int(parent),name=name,folder=folder,job=state['job'],spec_path=str(specpath),spec_sha256=sha(specpath),command_path=str(cmd),source_root=str(source),source_manifest_sha256=sha(source/'source-manifest.json'),source_manifest_keys=list(manifest),source_commit=manifest.get('commit',manifest.get('commit_sha')),actual_placement_path=str(actual),actual_placement_sha256=sha(actual),exact_all345_positions_and11149_terminal_arrays=True,no_route_receipt=not(out/'receipt.json').exists(),no_final_trees=not(out/'trees.json').exists(),wire_bound_source_sha256=sha(source/'project/experiments/control_v1/steiner_wire_bound.py')))
out=b/'reset5380-target-discovery-1938';assert not out.exists();out.mkdir();d=dict(time=time.time(),read_only=True,whole_system_qualified=False,base_placement_path=str(base),base_placement_sha256=sha(base),native_pin_receipt_inputs=receipt.get('inputs',{}),current_wire_bound_source_sha256=sha(b/'source-1885/project/experiments/control_v1/steiner_wire_bound.py'),targets=rows,scope='Read-only discovery only; no task altered. Known own Issue162 candidates only, protected3751/functions/new19160/19210 and foreignR excluded. Allcandidates actualall345positions/all11149terminalarrays exactsame original5380 and exactsame originalnative/minpin budget. Independent mathproof andfreshUID/job/PID/source ancestry/checks required before any retirement.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));print('TARGETS',json.dumps([dict(candidate=r['candidate'],folder=r['folder'],commit=r['source_commit'],same_wire_bound=r['wire_bound_source_sha256']==d['current_wire_bound_source_sha256'])for r in rows]));print('MANIFEST_KEYS',rows[0]['source_manifest_keys']if rows else[])
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=60).decode());subprocess.run(['scp','yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/reset5380-target-discovery-1938/receipt.json',str(Path(__file__).parent/'control162-audit1938.json')],check=True)
