from pathlib import Path
import json,sys,ast,hashlib,math
import numpy as np
b=Path(__file__).parent;out=b/'control162-check1953';assert not out.exists();out.mkdir();root=b/'control162-math-data1950-recovered';p=json.loads((b/'control162-milp1951/candidate-math-only.json').read_bytes());base=json.loads((root/'placement.json').read_bytes());rows=json.loads((root/'native-pin-load.json').read_bytes())['placements'][0]['rows']
t=ast.parse((b/'control162-subset1870.py').read_text(encoding='utf-8'))
for name in ['exact','subset']:fn=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name==name);exec(compile(ast.Module(body=[fn],type_ignores=[]),'crosschecked-subset','exec'))
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
v={k:[]for k in ['low','base','high']};checked=0
for r in rows:
 pts=p['terminals'][r['net']];bound=grid_tree_bound(pts);old=grid_tree_bound(base['terminals'][r['net']])['necessary_wire_grid_edges'];length=max(bound['necessary_wire_grid_edges'],math.ceil(2*bound['metric_mst_grid_edges']/3))
 if r['driver']['instance']=='reset_distribution':length=max(length,exact(subset(pts)));checked+=1
 for k in v:
  wire=r['optimistic_total_ff'][k]-r['native_ground_cap_ff'];assert old>0 or abs(wire)<1e-7;total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+(wire*length/old if old else 0)
  if total>r['max_capacitance_ff']+1e-7:v[k].append(dict(net=r['net'],driver=r['driver'],total_ff=total,max_ff=r['max_capacitance_ff']))
assert checked==53
d=dict(passed=True,diagnostic_only=True,whole_system_qualified=False,proposal_sha256=hashlib.sha256((b/'control162-milp1951/proposal.json').read_bytes()).hexdigest(),rows_checked=len(rows),reset_nets_checked=53,violations={k:len(x)for k,x in v.items()},details=v,scope='Mathematical candidate1951 only, alloriginal19290native/minpin budgets and wire coefficients used. All10930 stronger2/3MST and53exactnew subset necessary checks. No actual reconstructed pin, routing, geometry, timing or system acceptance.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));print(json.dumps(d))
