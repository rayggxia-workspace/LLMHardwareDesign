from pathlib import Path
import json,collections
b=Path(__file__).parent;out=b/'control162-collisions1945';assert not out.exists();out.mkdir();results=[]
for label,folder in [('19140','control162-subset1915'),('19290','control162-subset1930')]:
 p=json.loads((b/folder/'placement.json').read_bytes());points=collections.defaultdict(set)
 for name,ends in p['terminals'].items():
  for xy in ends:points[tuple(xy)].add(name)
 collisions=[dict(grid_xy=xy,nets=sorted(names))for xy,names in points.items()if len(names)>1];r=dict(candidate=label,terminals=sum(map(len,p['terminals'].values())),unique_points=len(points),different_net_coincident_landings=len(collisions),examples=collisions[:25]);results.append(r)
d=dict(passed=True,diagnostic_only=True,whole_system_qualified=False,results=results,scope='Actualnative reconstructed M11landing center coincidence only; exactintegergrid. Does not check route shorts, spacing or legal final geometry. No gates/input/source changes. Zero collisions does not imply legalrouting.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));print(json.dumps(d))
