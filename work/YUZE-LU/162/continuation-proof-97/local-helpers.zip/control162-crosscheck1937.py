from pathlib import Path
import ast,json,math,time,hashlib
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
b=Path(__file__).parent;out=b/'control162-crosscheck1937';assert not out.exists();out.mkdir();tree=ast.parse((b/'control162-hanan1869.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='solve');exec(compile(ast.Module(body=[fn],type_ignores=[]),'independent-flow-MIP','exec'))
d=json.loads((b/'control162-subset1936/receipt.json').read_bytes());r=next(x for x in d['reset_subset_results']if x['net']=='net_8920');v=solve(r['subset'],limit=10);assert v['status']==0 and v['lower_edges']==v['upper_edges']==r['necessary_edges']==1923
native=json.loads((b/'control162-subset1936/native-pin-load.json').read_bytes());row=next(x for x in native['placements'][0]['rows']if x['net']==r['net']);failure=next(x for x in d['details']['high']if x['net']==r['net']);assert failure['excess_ff']>36
receipt=dict(passed=True,whole_system_qualified=False,diagnostic_only=True,actual_placement='453/5380',subset=r,independent_mip=v,exact_equal=True,actual_native_cap_row=row,failure=failure,inputs=d['inputs'],scope='Independent exact connected-grid flowMIP matches8terminal subsetDP1923edges foractual old453/5380 reset_out31. Original native/minpin1904.3fF high gate exceeded36.579292fF. Mathematical impossibility of this fixed-placement branch, not claim of oldfunction failure. Task membership/source/actualPID and exactsame baseplacements must be freshlyverified before any ownchildretirement; no job modified by this script.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(dict(passed=True,exact_edges=1923,excess_ff=failure['excess_ff'],row_keys=list(row))))
