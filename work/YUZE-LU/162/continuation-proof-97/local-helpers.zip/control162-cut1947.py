from pathlib import Path
import json,hashlib
b=Path(__file__).parent;out=b/'control162-cut1947';assert not out.exists();out.mkdir();results=[]
for label,folder in [('19140','control162-subset1915'),('19290','control162-subset1930')]:
 f=b/folder/'placement.json';p=json.loads(f.read_bytes());terms=p['terminals'];w=p['width_um']/4;h=p['height_um']/4;rows=[]
 for axis,n in [(0,w),(1,h)]:
  events={}
  for net,pts in terms.items():
   lo=min(t[axis]for t in pts);hi=max(t[axis]for t in pts)
   if lo<hi:events[lo]=events.get(lo,0)+1;events[hi]=events.get(hi,0)-1
  demand=0;maximum=0;location=None
  for x,delta in sorted(events.items()):
   demand+=delta
   if demand>maximum:maximum=demand;location=x+.5
  capacity=int((h if axis==0 else w)-8)
  rows.append(dict(axis=axis,maximum_spanning_nets=maximum,cut_grid_coordinate=location,preferred_direction_track_capacity=capacity,excess=max(0,maximum-capacity)))
 results.append(dict(candidate=label,width_um=p['width_um'],height_um=p['height_um'],placement_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),cuts=rows))
d=dict(diagnostic_only=True,whole_system_qualified=False,results=results,scope='Necessary full-die straight bisection bound from exact actual native-reconstructed terminal grid: each spanning net needs at least one track crossing. Capacity uses original four-cell margins and preferred H M11/V M12. Zero excess is not routability or final electrical/physical qualification. No source/input/gate mutation.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));print(json.dumps(d))
