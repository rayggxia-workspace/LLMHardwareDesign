from pathlib import Path
import subprocess,shlex,json,hashlib,re,collections
b=Path(__file__).parent;out=b/'control162-drc1949';assert not out.exists();out.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-cugr-snapshot-19350'
files=['receipt.json','snapshot.json','drc.rpt','openroad.log','snapshot.def']
q='from pathlib import Path;import json,hashlib;b=Path('+repr(remote)+');files='+repr(files)+';print(json.dumps({n:dict(path=str(b/n),bytes=(b/n).stat().st_size,sha256=hashlib.sha256((b/n).read_bytes()).hexdigest())for n in files}))'
idx=json.loads(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40));(out/'reception.json').write_text(json.dumps(idx,indent=2))
for n,row in idx.items():
 subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(out/n)],check=True);raw=(out/n).read_bytes();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
raw=(out/'drc.rpt').read_text();pattern=r'violation type: ([^\n]+)\n\s*srcs: ([^\n]+)\n\s*bbox = \(([^,]+), ([^)]+)\) - \(([^,]+), ([^)]+)\) on Layer ([^\n]+)';rows=[];count=collections.Counter()
for m in re.finditer(pattern,raw):
 kind,nets,x,y,xx,yy,layer=m.groups();row=dict(type=kind,layer=layer,nets=re.findall(r'net:(net_[0-9]+|net_PG_[A-Z]+)',nets),bbox=list(map(float,[x,y,xx,yy])));rows.append(row);count[kind+'/'+layer]+=1
assert len(rows)==raw.count('violation type:')
d=dict(diagnostic_only=True,whole_system_qualified=False,reported_records=len(rows),classes=dict(count),reported_extent=[min(r['bbox'][0]for r in rows),min(r['bbox'][1]for r in rows),max(r['bbox'][2]for r in rows),max(r['bbox'][3]for r in rows)],snapshot=json.loads((out/'snapshot.json').read_text()),scope='Exact bounded19350 actual diagnostic outputs; DRC report contains reported records only, not proven complete violations/map. No source/pin/gate changes. Noncheckerboard via and nonempty DRC reject qualification. Does not identify global causal hotspots from capped/ordered records.')
(out/'analysis.json').write_text(json.dumps(d,indent=2));(out/'reported-records.json').write_text(json.dumps(rows));print(json.dumps(d))
