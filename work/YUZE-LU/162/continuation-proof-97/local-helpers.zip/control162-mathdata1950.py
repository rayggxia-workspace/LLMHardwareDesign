from pathlib import Path
import subprocess,shlex,json,hashlib,shutil
b=Path(__file__).parent;out=b/'control162-math-data1950-recovered';assert not out.exists();out.mkdir();remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888/cap-candidates/19290'
files={n:remote+'/'+n for n in ['physical-graph.json']}
q='from pathlib import Path;import json,hashlib;files='+repr(files)+';print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))';idx=json.loads(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40))
for n,row in idx.items():
 subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(out/n)],check=True);raw=(out/n).read_bytes();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
for n,src in [('placement-search.json',b/'control162-math-data1907/placement-search.json'),('placement.json',b/'control162-subset1930/placement.json'),('native-pin-load.json',b/'control162-subset1930/native-pin-load.json'),('physical.json',b/'control162-math-data1907/physical.json'),('boundary-graph.json',b/'control162-math-data1907/boundary-graph.json')]:
 shutil.copyfile(src,out/n);idx[n]=dict(local_source=str(src),bytes=src.stat().st_size,sha256=hashlib.sha256(src.read_bytes()).hexdigest())
p=json.loads((out/'placement.json').read_bytes());cl=json.loads((out/'placement-search.json').read_bytes())['electrical_refinement']['clusters'];origins={}
for name,row in cl['members'].items():
 origin=tuple(p['placements_um'][name][axis]-row['offset_um'][axis]for axis in range(2));parent=row['parent'];assert origins.setdefault(parent,origin)==origin
assert len(origins)==29
(out/'reception.json').write_text(json.dumps(idx,indent=2));print(json.dumps(dict(received_files=len(idx),rigid_cluster_offsets_independently_rechecked=len(cl['members']),groups=len(origins),diagnostic_only=True)))
