from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888';rows=[]
for label,p in [('19310',r/'upper-candidates/19310/route/openroad-search/case-0'),('19350',b/'r256-balanced-cugr-snapshot-19350')]:
 row=dict(label=label,path=str(p),files=[])
 if p.exists():
  for f in p.iterdir():
   if f.is_file():row['files'].append(dict(name=f.name,bytes=f.stat().st_size,age=time.time()-f.stat().st_mtime))
  f=p/'openroad.log'
  if f.exists():row['tail']=f.read_text(errors='replace')[-3500:]
  for n in ['snapshot.json','receipt.json']:
   f=p/n
   if f.exists():row[n]=json.loads(f.read_text())
 rows.append(row)
print(json.dumps(rows))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40)
(Path(__file__).parent/'control162-monitor1946-latest.json').write_bytes(raw)
for row in json.loads(raw):print(json.dumps(row))
