from pathlib import Path
import json,collections
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.collections import PatchCollection
b=Path(__file__).parent;out=b/'control162-congestion1933';p=json.loads((b/'control162-subset1915/placement.json').read_bytes());root=b/'control162-math-data1907';g=json.loads((root/'physical-graph.json').read_bytes());m=json.loads((root/'physical.json').read_bytes());cells=json.loads((out/'cells.json').read_bytes());names=json.loads((root/'placement-search.json').read_bytes())['electrical_refinement']['clusters']['dimensions']
fig,axs=plt.subplots(1,2,figsize=(16,8),layout='constrained');last=None
for ax,layer in zip(axs,['metal11','metal12']):
 patches=[];colors=[]
 for c in cells:
  if c['layer']!=layer:continue
  x,y,xx,yy=c['bbox'];patches.append(Rectangle((x/1000,y/1000),(xx-x)/1000,(yy-y)/1000));colors.append(c['congestion'])
 last=PatchCollection(patches,cmap='YlOrRd',clim=(0,31),alpha=.85);last.set_array(colors);ax.add_collection(last)
 for n,xy in p['placements_um'].items():
  w,h=m['leaves'][g['instances'][n]]['die_um'];x,y=xy;ax.add_patch(Rectangle((x/1000,y/1000),w/1000,h/1000,fill=False,lw=.4,edgecolor='#364152'))
  if n in names:ax.text((x+w/2)/1000,(y+h/2)/1000,n,ha='center',va='center',fontsize=5,color='#122332')
 ax.set(xlim=(0,p['width_um']/1000),ylim=(0,p['height_um']/1000),xlabel='x (mm)',ylabel='y (mm)',title=layer+' / actual candidate 19160');ax.set_aspect('equal')
fig.colorbar(last,ax=axs,label='Congestion reported per cell (overlapping report entries)')
fig.suptitle('Actual global-route report over fixed macro placement 19140\nExactly 10,000 reported cells per direction; no claim of full-map coverage or final routing acceptance',fontsize=12)
fig.savefig(out/'global-congestion.png',dpi=180);plt.close(fig)
(out/'interpretation.json').write_text(json.dumps(dict(report_limit_observation='Exactly10000 horizontal and10000vertical reported entries. Potential report truncation/selection; cannot infer full-map totals or full-map ownership rankings from this report. No unique-net/DRC counts inferred.',plot='global-congestion.png',scope='Actual macro physical rectangles and actual global report only; not final layout or acceptance.'),indent=2))
print(str(out/'global-congestion.png'))
