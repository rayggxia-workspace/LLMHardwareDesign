from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-prepare1914.py').read_text(encoding='utf-8').replace('1914','1929').replace('control162-milp1912','control162-milp1926').replace('control162-check1913','control162-check1928').replace('19140','19290')
s=s.replace("p=b/'dynamic-04/node25/pending'","p=b/'dynamic-03/node5/pending'")
s=s.replace(",(b/'control162-check1928/raw1912-interpretation.json','raw1912-interpretation.json')",'')
s=s.replace('zero feasibility only; no wirelengthimprovement/physicaloptimality claim, rawinterpretation retained','45second bounded totalHPWLminimization feasibleincumbent notoptimum; mathematicalHPWL36.798132m->30.214220m; actualwirelength/routability notclaimed')
s=s.replace('Node25natural sixth16CPUslot','Node5natural c64fourth16CPUslot afterownoldfunction finishes')
compile(s,'prepare1929exec','exec');exec(compile(s,'prepare1929exec','exec'))
