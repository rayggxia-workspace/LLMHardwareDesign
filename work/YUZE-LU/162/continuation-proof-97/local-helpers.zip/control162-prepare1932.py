from pathlib import Path
b=Path(__file__).parent
s=(b/'control162-subset1915.py').read_text(encoding='utf-8').replace('control162-subset1915','control162-subset1930').replace('19140','19290').replace('cap-necessary-1914','cap-necessary-1929').replace('control162-milp1912','control162-milp1926');compile(s,'1930','exec');(b/'control162-subset1930.py').write_text(s,encoding='utf-8')
s=(b/'control162-full1916-remote.py').read_text(encoding='utf-8').replace('sready1916','sready1931').replace('audit-1916','audit-1931').replace('19160','19310').replace('19140','19290').replace('cap-necessary-1914','cap-necessary-1929').replace('stronger-necessary-1915','stronger-necessary-1930')
s=s.replace("folder='dynamic-05/node4'","folder='dynamic-05/node4'if spec['script']=='system_sta.py'else'dynamic-03/node5'")
s=s.replace('Existingnode4naturallyfreedplacementslot','Existingnode5naturallyfreedslot withseparateoriginalnode4STA')
compile(s,'1931','exec');(b/'control162-full1931-remote.py').write_text(s,encoding='utf-8')
s=(b/'control162-watch1917.py').read_text(encoding='utf-8').replace('watch1917','watch1932').replace('19140','19290').replace('cap-necessary-1914','cap-necessary-1929').replace("glob('*1914*')","glob('*1929*')").replace('subset1915','subset1930').replace('stronger-necessary-1915','stronger-necessary-1930').replace('full1916','full1931')
s=s.replace("['dynamic-05/node4','dynamic-04/node25']","['dynamic-05/node4','dynamic-04/node25','dynamic-03/node5']")
compile(s,'1932','exec');(b/'control162-watch1932.py').write_text(s,encoding='utf-8');print('Preparedactual19290 allpins/all53diagnostic; strict19310 only afterallfreshnecessarychecks. Node5natural vacancy, no cancellation.')
