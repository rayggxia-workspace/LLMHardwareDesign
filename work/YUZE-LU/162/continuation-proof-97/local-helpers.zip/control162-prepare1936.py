from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-subset1897.py').read_text(encoding='utf-8').replace('control162-subset1897','control162-subset1936').replace('r256-balanced-reset-composition-1888','r256-composition-453').replace('/cap-candidates/18930','/cap-candidates/5380').replace('/cap-necessary-1893/18930','/cap-necessary-538/5380')
s=s.replace('Actual fresh1888 balanced-reset18930 placement with fresh native/minpin3RC.','Actual existing453/5380 fixed placement with its own original native/minpin3RC. Read-only audit of own earlier Issue162 searches; no task modified.')
compile(s,'1936','exec');p=b/'control162-subset1936.py';p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p)],check=True)
