from pathlib import Path
import json,hashlib
b=Path(__file__).parent;root=b/'control162-math-data1950-recovered';cl=json.loads((root/'placement-search.json').read_bytes())['electrical_refinement']['clusters'];g=json.loads((root/'boundary-graph.json').read_bytes());p=json.loads((root/'placement.json').read_bytes());parent={n:n for n in g['instances']}
for row in g['boundary_links']['links']:parent[row['instance']]=row['source_instance']
assert all(parent[n]==row['parent']for n,row in cl['members'].items())
assert len(set(parent.values()))==29
proof=dict(diagnostic_only=True,whole_system_qualified=False,groups=29,members=345,correction='Old placement-search offsets describe earlier search and need not equal later electrically refined placement offsets. Solver only uses parent identities and actual current345 positions for rectangle and electrical equations; unused origin expression is removed. Production unchanged proposal apply independently checks actual345 relative offsets after shifts. Previous helper failure is retained; no remote source or outputs modified.',inputs={n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in ['placement.json','physical-graph.json','placement-search.json','native-pin-load.json','physical.json','boundary-graph.json']})
(root/'parent-binding1951.json').write_text(json.dumps(proof,indent=2))
src=(b/'control162-milp1926.py').read_text(encoding='utf-8');assert "root=b/'control162-math-data1907'"in src and "out=b/'control162-milp1926'"in src
src=src.replace("root=b/'control162-math-data1907'","root=b/'control162-math-data1950-recovered'").replace("out=b/'control162-milp1926'","out=b/'control162-milp1951'")
line="origins=np.array([[p['placements_um'][n][axis]-cl['members'][n]['offset_um'][axis]for axis in range(2)]for n in names])"
assert line in src;src=src.replace(line,'# Parent membership verified by independent1951 graph binding; use actual native placements throughout.')
src=src.replace('time_limit=45','time_limit=55').replace('actual balanced18930 base with unchanged18930 rigid-member offsets','actual balanced19290 base; all345actual rigid-member offsets independently preserved').replace('cumulative from18930 may reach1024um and is NOT claimed <=512um','each step <=512um relative19290; cumulative from18930 may exceed512um').replace('each new translation <=512um','each new translation <=512um').replace('fixed die/orientations/externalpins verified. Selected','fixed die/orientations/externalpins verified. Selected')
target=b/'control162-milp1951.py';assert not target.exists();target.write_text(src,encoding='utf-8');print(json.dumps(dict(prepared=str(target),diagnostic_only=True)))
