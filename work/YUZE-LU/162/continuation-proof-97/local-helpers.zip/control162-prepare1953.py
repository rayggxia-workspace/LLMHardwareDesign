from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-check1928.py').read_text(encoding='utf-8').replace('control162-check1928','control162-check1953').replace('control162-math-data1907','control162-math-data1950-recovered').replace('control162-milp1926','control162-milp1951').replace('candidate1926','candidate1951').replace('alloriginal18930native','alloriginal19290native');p=b/'control162-check1953.py';assert not p.exists();p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p)],check=True)
