from pathlib import Path
import subprocess,shlex
b=Path(__file__).parent;s=(b/'control162-queue1929-remote.py').read_text(encoding='utf-8').replace('sready1929','sready1954').replace('proposal-data-1929','proposal-data-1954').replace('cap-necessary-1929','cap-necessary-1954').replace('19290','19540').replace('18930/placement.json','19290/placement.json').replace("root/'cap-candidates/18930'","root/'cap-candidates/19290'").replace('Fresh1888 actual18930','Fresh1888 actual19290').replace('Objective 45second bounded','Objective 55second bounded').replace('36.798132m->30.214220m','30.214220m->27.753060m').replace("dynamic-03/node5/pending","dynamic-08/node6/pending").replace('Node5natural c64fourth16CPUslot afterownoldfunction finishes','Node6natural c64four independent16CPUslots afterprovenoldroute retirement')
s=s.replace("root/'cap-candidates/18930/receipt.json'","root/'cap-candidates/19290/receipt.json'")
assert "root/'cap-candidates/19290/receipt.json'"in s
p=b/'control162-queue1954-remote.py';assert not p.exists();p.write_text(s,encoding='utf-8');compile(s,'queue1954','exec')
host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-cluster-proposal-data-1954';subprocess.run(['ssh',host,'mkdir','-p',remote],check=True)
for f,n in [(b/'control162-milp1951/proposal.json','proposal.json'),(b/'control162-milp1951/receipt.json','receipt.json'),(b/'control162-check1953/receipt.json','stronger-local.json')]:subprocess.run(['scp',str(f),host+':'+remote+'/'+n],check=True)
subprocess.run(['scp',str(p),host+':/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'+p.name],check=True)
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10',host,'python3 -c '+shlex.quote(s)],timeout=45).decode())
