from pathlib import Path
import subprocess,json,zipfile,hashlib,re,datetime
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';w=r/'work/YUZE-LU/162';out=w/'continuation-proof-97';assert not out.exists();out.mkdir();sha=lambda v:hashlib.sha256(v).hexdigest();attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/continuation-proof-97/** -text\n')
remote='yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-97/'
for n in ['index.json','selected-originals.zip']:subprocess.run(['scp',remote+n,str(out/n)],check=True)
d=json.loads((out/'index.json').read_bytes());assert sha((out/'selected-originals.zip').read_bytes())==d['archive']['sha256']=='b73358a1ce92f640e22cb2629df60b951ff8deb2c11d25b29a41fc924e73f921'
with zipfile.ZipFile(out/'selected-originals.zip')as z:
 assert z.testzip()is None and len(z.infolist())==d['copied_files']==580
 for v in d['files'].values():raw=z.read(v['zip_entry']);assert len(raw)==v['bytes']and sha(raw)==v['sha256']
 old=z.read('route-selection-102/sready1940-proven-old5380-retirement/receipt.json');ret=json.loads(old);assert ret['passed']and len(ret['retired_steps'])==25 and len(ret['archived_unstarted_successors'])==150
 for row in ret['archived_unstarted_successors']:assert row['original_pending_unchanged']
 assert json.loads(z.read('route-selection-102/sready1942-node3-controller-recovery/receipt.json'))['new_job']=='97247'
 assert len(json.loads(z.read('route-selection-102/sready1944-parallel-threeRC/receipt.json'))['moves'])==9
 snap=json.loads(z.read('r256-balanced-cugr-snapshot-19350/snapshot.json'));assert snap['execution_passed']and not snap['actual_router_drc_empty']and not snap['independent_original_grid_check']['passed']
 assert json.loads(z.read('r256-current-pin-composition-1834/internal-program-traces/receipt.json'))['passed']
files={}
for p in b.glob('control162-*.py'):
 m=re.search(r'([0-9]+)(?:-remote)?\.py$',p.name)
 if m and 1925<=int(m.group(1))<=1959:files[p.name]=p.read_bytes()
for folder in ['control162-milp1926','control162-check1928','control162-subset1930','control162-congestion1933','control162-subset1936','control162-crosscheck1937','control162-collisions1945','control162-cut1947','control162-drc1949','control162-math-data1950-recovered','control162-milp1951','control162-check1953','control162-git-data-publish-1925']:
 for n in ['receipt.json','reception.json','RECEPTION.json','proposal.json','analysis.json','interpretation.json','parent-binding1951.json','global-congestion.png','snapshot.json']:
  p=b/folder/n
  if p.exists():files[folder+'/'+n]=p.read_bytes()
for n in ['control162-watch1932.jsonl','control162-resources1943.txt','control162-monitor1922-latest.json','control162-monitor1946-latest.json','control162-route1948-latest.json','control162-status1956-latest.json','control162-ancestry1939.json']:
 p=b/n
 if p.exists():files[n]=p.read_bytes()
files['online1927-readback.json']=json.dumps(dict(issueBodyExact=True,prBodyExact=True,head='ef0a6506498707339e4874cf5333c82c12a21c5f',draft=True,merged=False,scope='Actual authenticated connector readback1927 previously verified; fresh1952 readback retains same own section. Does not imply board sync or physical acceptance.'),indent=2).encode()
with zipfile.ZipFile(out/'local-helpers.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,raw in files.items():z.writestr(n,raw)
with zipfile.ZipFile(out/'local-helpers.zip')as z:assert z.testzip()is None and all(z.read(n)==raw for n,raw in files.items())
(out/'local-index.json').write_bytes(json.dumps(dict(files={n:dict(bytes=len(v),sha256=sha(v),zip_entry=n)for n,v in files.items()},archive=dict(path='local-helpers.zip',bytes=(out/'local-helpers.zip').stat().st_size,sha256=sha((out/'local-helpers.zip').read_bytes()))),indent=2).encode());(out/'reception.json').write_bytes(json.dumps(dict(passed=True,remote_entries=580,local_entries=len(files),all_actual_member_crc_bytes_sha256=True,whole_system_qualified=False),indent=2).encode())
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
chapter=f'''# Issue162：实际拥塞定位、资源恢复与三档RC并行准备

更新时间：{now}。Issue #162 / Draft PR #163。**组合最终物理验收未通过，继续任务，不合并。** 已验收23类型、138六文件、345项固定状态归属沿用当前绑定；main六宏、S内部驱动、R及并行修改保留。源1885和全部原验收门不变。

实际19290的345位置/11149完整接点数组与数学提案精确相等；原三RC、10930更强下界及全部53复位精确子集必要条件均0。第三条19310 CUGR完整七阶段已通过严格源绑定并实际运行，与19160 CUGR、19210 FastRoute并行。必要条件零违规仍不能替代布线。

19160/19310首轮实际详细布线分别约165万/161万DRC，主要是不同网络短路，尚无合法最终线。两套实际24760接点无不同网同中心重合。较短HPWL未显著减少详细违例；CUGR全局资源报告19310平均使用98.31%，仍有约49.6万拥塞。它是该搜索器的资源模型，不是物理不可行性证明。全局报告各方向恰10000条，未证明覆盖全图，局部频次不能当全局热点或因果。

19350 SHA绑定真实19140 preDB/guide的一轮有界诊断已执行完：DRC非空，独立原网格检查在net_10001发现不合棋盘格的通孔。报告17123记录，包括M11 Short10000、Cut Short6241等；记录可能受报告上限影响，不能声称是全部违例。它的passed仅指诊断执行，不授予布线或系统资格。原始DEF/ODB、DRC、日志保留。

全宽直线切分诊断1947的初稿错误地把首选方向轨道当作必要容量上限。原解析器允许两层各自双方向曼哈顿线，故19140的首选方向excess90不能证明不可行。原件与interpretation更正同时保存；没有据此退役任务或放宽门槛。

另对旧453/5380原摆放完成实际345位置/11149接点、原native/minpin预算逐项绑定；reset_out31的8接点子集精确Steiner需1923边，独立流MIP同得1923最优。high必要1940.879292fF超过原1904.3fF、差36.579292fF。28个已知本人候选及11个源commit祖先核验后，仅退役25个本人实际Slurm路由子步骤；3个在已失败父作业上的陈旧条目跳过。150份未启动后继原字节仅复制归档，在线pending保持原件且仍被缺失/失败route依赖挡住；没有声称移除。3751、15220、17170、全部父节点、新组合功能/物理链、并行R及其他任务未被取消。

发现旧node3父95098早在2026-11-05 06:55:45已经FAILED：旧source62队列在先前任务迁移时读不到pending文件，FileNotFoundError退出。其陈旧active不代表实际运行；此前1773功能“仍运行”的观察需更正为中断、未验收，部分输出保留。没有把中断结果当成功。仅替换这个已失败父节点，新97247使用已冻结审计1885的read-once/missing-file保护控制器，保持最多8个实际本任务父作业。

9份尚未启动的low/base/high STA在确认源/目标控制器均有读取保护、实际geometry依赖缺失后，按原字节分配至node6、actual node24及新node3。canonical入口为sready1944-parallel-threeRC；源1885、224GiB预测、全部参数/输出/门不变。每条组合的三档在依赖满足后可跨节点并行，两个224GiB并发需要原汇总553.6GiB，未降低预测绕过准入。c96六×16/c64四×16独立任务动态补位；空槽目前主要受真实几何依赖限制。

旧1834组合独立最终单元功能与真实内部任务轨迹已通过，验证C/八队列/适配器完成握手及外部搬运事件；新1888必须完成自己的三初态八程序、独立审计和轨迹，仍在编译验证，未转移资格。

1951在真实19290基础做下一步有界数学摆放：保留die/方向/全部固定宏，每步29组各轴最多512um；55秒可行解将预算HPWL30.214220m降至27.753060m，不是最优或实际布线长度。10930更强/53精确子集数学必要条件均0；19540三阶段实际重建已提交node6，尚待实际全部接点及预算复核。旧placement-search偏移是早期搜索元数据，不能代替当前实际偏移；辅助准备失败与修正保留，生产提案guard始终独立检查当前345个宏。

证据：[580项实际原件](continuation-proof-97/index.json)、[实收CRC/字节/SHA](continuation-proof-97/reception.json)、[本地诊断/失败/数学/辅助源](continuation-proof-97/local-index.json)。规范交付仍见[23类138文件与当前图绑定](current-delivery-binding1888.json)、[345项状态归属](state-ownership-current1888.json)。**完整M11/M12、native-XOR/PG、low/base/high下300MHz setup/hold/电气、当前功能轨迹必须联合通过。**

规则1.0.0；登记PR5 pending；缺board.json，看板unverified/同步pending，审查待指定。后续持续定位实际拥塞/非法通孔并迭代，不能以单块或必要诊断宣布系统通过。
'''
(w/'continuation-checkpoint-97.md').write_text(chapter,encoding='utf-8')
for path,prefix in [('docs/STATUS.md','../'),('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;brief=f'[Checkpoint97]({prefix}work/YUZE-LU/162/continuation-checkpoint-97.md)：三条真实物理链仍有大量短路；19350有界诊断DRC非空/棋盘格拒绝。25条已证明旧摆放电容失败的本人子步骤退役，150后继仅复制归档、原pending保留；旧95098实际FAILED、1773功能中断更正，97247替换已失败节点恢复8父作业。9份未来三RC STA按原字节跨节点并行准备，19540新摆放进入实际检查；旧1834功能/内部任务轨迹通过不转移新1888资格。23类单块保留，完整组合仍未验收，继续。\n\n';p.write_bytes(brief.encode()+p.read_bytes())
print(json.dumps(dict(passed=True,remote_entries=580,local_entries=len(files),whole_system_qualified=False)))
