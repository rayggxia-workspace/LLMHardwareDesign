from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,hashlib,subprocess,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162')
for n in [62,83,93,133,136,236,269,1885]:
 p=b/('source-'+str(n))/'project/experiments/control_v1/dynamic_queue.py';s=p.read_text();print('CONTROLLER',n,dict(read_once='try:raw=path.read_bytes()'in s,missing_file_guard='except FileNotFoundError' in s,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
for folder in ['dynamic-05/node2','dynamic-09/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 p=b/folder/'queue-state.json'
 if p.exists():d=json.loads(p.read_text());print('QUEUE',folder,dict(job=d['job'],active=d['active'],age=time.time()-d['time']))
 else:print('QUEUE_WAIT',folder)
r=b/'r256-balanced-reset-composition-1888'
for label in ['cap-candidates/19290','cap-necessary-1929/19290/native-pin-load']:
 p=r/label/'receipt.json'
 if p.exists():d=json.loads(p.read_text());print('NEWCANDIDATE',label,d.get('passed'))
raw=subprocess.check_output(['squeue','-u','yuzelu','-h','-o','%i|%j|%T|%N'],universal_newlines=True);print('ACTUAL_TASK_PARENTS',[line for line in raw.splitlines()if'|yzl-ctl162-'in line])
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);print(raw.decode());(Path(__file__).parent/'control162-resources1943.txt').write_bytes(raw)
