from pathlib import Path
import json,hashlib,subprocess,re,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-composition-453';record=b/'route-selection-102/sready1940-proven-old5380-retirement';assert not record.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=b/'control162-proven-reset5380-1937.json';d=json.loads(proof.read_text());ancestry_path=b/'control162-ancestry1939.json';ancestry=json.loads(ancestry_path.read_text());discovery_path=b/'reset5380-target-discovery-1938/receipt.json';discovery=json.loads(discovery_path.read_text());assert ancestry['passed']and ancestry['proof_sha256']==sha(proof)and ancestry['discovery_sha256']==sha(discovery_path)
assert d['passed']and d['exact_equal']and d['independent_mip']['status']==0 and d['independent_mip']['lower_edges']==d['independent_mip']['upper_edges']==d['subset']['necessary_edges']==1923 and d['failure']['excess_ff']>36 and d['failure']['max_capacitance_ff']==1904.3
for row in d['inputs'].values():assert Path(row['path']).stat().st_size==row['bytes']and sha(row['path'])==row['sha256']
base=Path(discovery['base_placement_path']);bp=json.loads(base.read_text());assert sha(base)==discovery['base_placement_sha256'];assert all(p in bp['terminals']['net_8920']for p in d['subset']['subset']);pin=root/'cap-necessary-538/5380/native-pin-load/native-pin-load.json';actual=json.loads(pin.read_text());assert d['actual_native_cap_row']==next(r for r in actual['placements'][0]['rows']if r['net']=='net_8920')
graph=root/'topology/boundary-graph.json';assert bp['graph_sha256']==sha(graph);pinreceipt=json.loads((pin.parent/'receipt.json').read_text());assert pinreceipt['inputs'][str(graph)]==sha(graph)
for name,output in [('cap-candidates/5380','placement.json'),('cap-necessary-538/5380/native-pin-load','native-pin-load.json')]:
 p=root/name;receipt=json.loads((p/'receipt.json').read_text());assert receipt['passed']and receipt['outputs'][output]==sha(p/output)
expected=sha(b/'source-1885/project/experiments/control_v1/steiner_wire_bound.py');assert sha(b/'source-537/project/experiments/control_v1/steiner_wire_bound.py')==expected
assert json.loads((b/'r256-balanced-reset-source-audit-1886/receipt.json').read_text())['passed'];targets=[];skipped=[];jobs={}
for row in discovery['targets']:
 candidate=row['candidate'];assert candidate in ancestry['targets']and candidate!=3751;node=b/row['folder'];state=json.loads((node/'queue-state.json').read_text());p=Path(row['spec_path']);s=json.loads(p.read_text());a=s['args'];out=Path(a[a.index('--out')+1]);assert out==root/'upper-candidates'/str(candidate)/'route'
 if row['name']not in state['active']or any((out/n).exists()for n in ['receipt.json','trees.json','router-output.txt']):skipped.append(dict(candidate=candidate,reason='Notactive or alreadyproduced possible finalrouteartifact; preserved'));continue
 assert state['job']==row['job']and sha(p)==row['spec_sha256'];source=Path(s['source_root']);assert str(source)==row['source_root']and sha(source/'source-manifest.json')==row['source_manifest_sha256'];manifest=json.loads((source/'source-manifest.json').read_text());assert manifest['commit']==row['source_commit']and manifest['commit']in ancestry['commits']and sha(source/'project/experiments/control_v1/steiner_wire_bound.py')==expected
 assert '--reuse-placement'in a and a[a.index('--reuse-placement')+1]==str(base.parent)and a[a.index('--route-residual-budget')+1]==str(pin)and a[a.index('--graph')+1]==str(root/'topology/boundary-graph.json');placed=Path(row['actual_placement_path']);assert sha(placed)==row['actual_placement_sha256'];pp=json.loads(placed.read_text());assert pp['placements_um']==bp['placements_um']and pp['terminals']==bp['terminals'];assert json.loads(Path(row['command_path']).read_text())['spec_sha256']==sha(p)
 job=row['job']
 if job not in jobs:
  check=subprocess.run(['scontrol','show','job',job,'-o'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
  if check.returncode:jobs[job]=None;skipped.append(dict(candidate=candidate,reason='ActualSlurm parent absent; stalequeue state preserved, no cancellation'));continue
  details=check.stdout;assert 'UserId=yuzelu(10011)'in details and 'JobName=yzl-ctl162-'in details;host=re.search(r' NodeList=([^ ]+)',details).group(1);steps=subprocess.check_output(['scontrol','show','step',job,'-o'],universal_newlines=True);found=[m.groups()for m in re.finditer(r'StepId=('+job+r'\.[0-9]+).*?SrunHost:Pid=(node[0-9]+):([0-9]+)',steps)]
  code="import os,json;d={}"+chr(10)+"for p in "+repr([r[2]for r in found])+":"+chr(10)+" try:"+chr(10)+"  assert os.stat('/proc/'+p).st_uid==10011;d[p]=open('/proc/'+p+'/cmdline','rb').read().decode().split(chr(0))"+chr(10)+" except OSError:pass"+chr(10)+"print(json.dumps(d))"
  procs=json.loads(subprocess.check_output(['srun','--jobid='+job,'--overlap','-n1','-c1','python3','-c',code],universal_newlines=True));jobs[job]=dict(details=details,host=host,steps=found,procs=procs)
 info=jobs[job]
 if info is None:skipped.append(dict(candidate=candidate,reason='ActualSlurm parent absent; stalequeue state preserved, no cancellation'));continue
 matched=[]
 for step,host,pid in info['steps']:
  cmd=info['procs'].get(pid,[])
  if '--out'in cmd and cmd[cmd.index('--out')+1]==str(out)and str(source/'project/experiments/control_v1/system_upper.py')in cmd:matched.append(dict(step=step,host=host,pid=pid,command=cmd))
 assert len(matched)==1 and matched[0]['host']==info['host'];targets.append(dict(discovery=row,spec=s,process=matched[0],actual_graph_sha256=sha(root/'topology/boundary-graph.json'),job_details=info['details']))
assert targets;ids={t['discovery']['candidate']for t in targets};successors=[]
for folder in ['dynamic-05/node2','dynamic-02/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 node=b/folder;st=json.loads((node/'queue-state.json').read_text())
 for p in(node/'pending').glob('*.json'):
  s=json.loads(p.read_text());a=s['args']
  if s['script']not in ['system_sta.py','system_geometry.py']or'--out'not in a:continue
  out=Path(a[a.index('--out')+1]);parts=out.parts
  if str(root/'upper-candidates')+'/'not in str(out):continue
  candidate=out.relative_to(root/'upper-candidates').parts[0]
  if not candidate.isdigit()or int(candidate)not in ids:continue
  if p.stem in st['active']or p.stem in st.get('finished',{})or(node/'commands'/p.name).exists()or(node/'results'/p.name).exists():continue
  assert not out.exists()and str(s['source_root']).startswith(str(b/'source-'));successors.append(dict(path=str(p),sha256=sha(p),spec=s,queue=folder))
reason='Only known own Issue162 old453/5380 fixed-placement route children: actual all345positions/all11149terminalarrays and originalnative/minpin budget exact; independent subsetDP and exact flowMIP1923edges force originalhighcap1940.879292fF>1904.3fF. All11sourcecommits ancestors of ownPRhead, originalwirebound code exactsource537/current1885, fullfrozen/source/spec/UID/job/PID matched. No gate relaxation. Protected3751, allparents/functions/new1888physicalchains, excludedold15220 andforeignR/otherjobs unchanged. Rawpartials/logs preserved; neverstarted downstream originalbytes COPIED to archive, originalpendingfiles unchanged to avoid legacycontroller glob/read races. These future tasks remain blocked by missing/failedroute receipts; not claimed removed.'
record.mkdir();(record/'verified-before.json').write_text(json.dumps(dict(time=time.time(),proof_path=str(proof),proof_sha256=sha(proof),ancestry_path=str(ancestry_path),ancestry_sha256=sha(ancestry_path),targets=targets,skipped=skipped,unstarted_successors=successors,whole_system_qualified=False,reason=reason),indent=2));archived=[];dest=record/'unstarted';dest.mkdir()
for row in successors:
 p=Path(row['path']);node=p.parent.parent;st=json.loads((node/'queue-state.json').read_text());assert p.stem not in st['active']and not(node/'commands'/p.name).exists()and sha(p)==row['sha256'];to=dest/(row['queue'].replace('/','-')+'-'+p.name);assert not to.exists();to.write_bytes(p.read_bytes());archived.append(dict(original=row,archived_path=str(to),sha256=sha(to),original_pending_unchanged=True));(record/'archive-progress.json').write_text(json.dumps(archived,indent=2))
retired=[]
for row in targets:
 drow=row['discovery'];node=b/drow['folder'];st=json.loads((node/'queue-state.json').read_text());assert drow['name']in st['active']and sha(drow['spec_path'])==drow['spec_sha256'];subprocess.run(['scancel',row['process']['step']],check=True);retired.append(dict(candidate=drow['candidate'],step=row['process']['step']));(record/'retire-progress.json').write_text(json.dumps(retired,indent=2))
(record/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,retired_steps=retired,archived_unstarted_successors=archived,skipped=skipped,scope=reason),indent=2));print(json.dumps(dict(passed=True,retired=retired,archived_unstarted=len(archived),skipped=skipped)))
