from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888';d={}
for seed in [19160,19310]:
 p=r/'upper-candidates'/str(seed)/'route/openroad-search/case-0/openroad.log';lines=p.read_text().splitlines();d[str(seed)]=dict(head=lines[:250],global_summary=[s for s in lines if any(t in s.lower()for t in ['overflow','wirelength','wire length','demand','capacity','congestion'])][:100])
p=b/'r256-balanced-cugr-snapshot-19350';d['snapshot_files']=[dict(name=f.name,bytes=f.stat().st_size)for f in p.iterdir()if f.is_file()];f=p/'drc.rpt'
if f.exists():
 with f.open()as stream:d['drc_head']=[next(stream,'')for _ in range(48)]
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);d=json.loads(raw);(Path(__file__).parent/'control162-route1948-latest.json').write_bytes(raw)
for k,v in d.items():
 if isinstance(v,dict):print(k,json.dumps(v['global_summary']))
 else:print(k,json.dumps(v))
