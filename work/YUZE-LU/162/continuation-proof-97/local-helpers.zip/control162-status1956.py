from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d={}
for scene,sub in [('r256-current-pin-composition-1834','internal-program-traces'),('r256-balanced-reset-composition-1888','function'),('r256-balanced-reset-composition-1888','cap-necessary-1954/19540/native-pin-load')]:
 p=b/scene/sub/'receipt.json';row=dict(exists=p.exists())
 if p.exists():
  x=json.loads(p.read_text());row.update({k:v for k,v in x.items()if k in ['passed','whole_system_qualified','scope','stage','cases','programs','initials','checks','cycles','source_root']})
 d[scene+'/'+sub]=row
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-status1956-latest.json').write_bytes(raw);print(raw.decode()[:3500])
