"""Bounded local necessary-condition diagnostic; never physical acceptance."""
from pathlib import Path
import subprocess,shlex,json,hashlib,sys,math,time
import numpy as np
b=Path(__file__).parent;out=b/'control162-subset1955';assert not out.exists();out.mkdir()
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-balanced-reset-composition-1888'
files={'placement.json':remote+'/cap-candidates/19540/placement.json','native-pin-load.json':remote+'/cap-necessary-1954/19540/native-pin-load/native-pin-load.json'}
q='from pathlib import Path;import json,hashlib;files='+repr(files)+';print(json.dumps({k:dict(path=v,bytes=Path(v).stat().st_size,sha256=hashlib.sha256(Path(v).read_bytes()).hexdigest())for k,v in files.items()}))'
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);idx=json.loads(raw)
for name,row in idx.items():
 subprocess.run(['scp','yuzelu@10.129.166.172:'+row['path'],str(out/name)],check=True);data=(out/name).read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'reception.json').write_bytes(raw)
# Reuse the independently cross-checked mathematical functions only, no prior results.
src=(b/'control162-subset1870.py').read_text(encoding='utf-8')
ns={'np':np};exec(src[src.index('def exact('):src.index('checks=[]')],ns);exec(src[src.index('def subset('):src.index('results=[];inputs={}')],ns)
exact=ns['exact'];subset=ns['subset']
for pts,value in [([(0,0),(4,0),(0,3),(4,3)],10),([(0,0),(1,1),(2,2),(3,3)],6),([(0,0),(4,0),(2,2)],6),([(0,0),(4,0),(4,3),(0,3),(2,1)],10)]:assert exact(pts)==value
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
p=json.loads((out/'placement.json').read_bytes());pd=json.loads((out/'native-pin-load.json').read_bytes());assert pd['passed']and len(pd['placements'])==1
predicted=json.loads((b/'control162-milp1951/candidate-math-only.json').read_bytes());assert p['terminals']==predicted['terminals']and p['placements_um']==predicted['placements_um'],'Actualall345placements/all11149pinarrays mustmatchmathproposal';rows=pd['placements'][0]['rows'];results=[];violations={v:[]for v in ['low','base','high']};reset=[]
for r in rows:
 bound=grid_tree_bound(p['terminals'][r['net']]);original=bound['necessary_wire_grid_edges'];length=max(original,math.ceil(2*bound['metric_mst_grid_edges']/3))
 if 'reset' in str(r['driver']).lower():
  pts=subset(p['terminals'][r['net']]);length=max(length,exact(pts));reset.append(r['net']);results.append(dict(net=r['net'],driver=r['driver'],subset=pts,necessary_edges=length,original_edges=original))
 for v in violations:
  wire=r['optimistic_total_ff'][v]-r['native_ground_cap_ff'];assert wire>=-1e-7
  if original==0:assert abs(wire)<1e-7;total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']
  else:total=r['native_ground_cap_ff']+r['minimum_input_pin_cap_ff']+wire*length/original
  if total>r['max_capacitance_ff']+1e-7:violations[v].append(dict(net=r['net'],driver=r['driver'],necessary_total_ff=total,max_capacitance_ff=r['max_capacitance_ff'],excess_ff=total-r['max_capacitance_ff']))
assert len(reset)==53,len(reset)
receipt=dict(time=time.time(),passed=True,whole_system_qualified=False,diagnostic_only=True,inputs=idx,rows_checked=len(rows),reset_nets_checked=53,violations={v:len(x)for v,x in violations.items()},details=violations,reset_subset_results=results,scope='Actual fresh1888 balanced-reset actual19540 placement with fresh native/minpin3RC. All10930 rows stronger2/3MST; all53 actual reset outputs exact at-most8-terminal subset Steiner DP. Necessary conditions only; actual routing/nativeXOR/PG/3RC300MHz gates remain mandatory and unchanged.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items()if k not in ['details','reset_subset_results','inputs']}))
