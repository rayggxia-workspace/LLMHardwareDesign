from pathlib import Path
import subprocess,shlex,json,time,sys
b=Path(__file__).parent;j=b/'control162-watch1957.jsonl';assert not j.exists()
def log(d):
 d['time']=time.time();s=json.dumps(d);print(s,flush=True)
 with j.open('a',encoding='utf-8')as f:f.write(s+'\n')
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888'
p=r/'cap-necessary-1954/19540/native-pin-load/receipt.json';d={'ready':p.exists()}
if p.exists():d['receipt']=json.loads(p.read_text())
d['failures']=[]
for folder in ['dynamic-05/node4','dynamic-04/node25','dynamic-03/node5','dynamic-08/node6']:
 for f in (b/folder/'results').glob('*1954*'):
  row=json.loads(f.read_text())
  if row['returncode']!=0:d['failures'].append(dict(path=str(f),result=row))
print(json.dumps(d))
'''
while True:
 try:d=json.loads(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35))
 except (subprocess.SubprocessError,ValueError)as e:log(dict(connection_retry=str(e)));time.sleep(30);continue
 if d['failures']:log(dict(failed=d));sys.exit(2)
 if d['ready']:
  assert d['receipt']['passed'];break
 log(dict(waiting='actual19540 freshnativepin'));time.sleep(30)
subprocess.run([sys.executable,str(b/'control162-subset1955.py')],check=True)
p=b/'control162-subset1955/receipt.json';d=json.loads(p.read_text());assert d['passed']and d['reset_nets_checked']==53 and not d['whole_system_qualified']
log(dict(necessary_diagnostic=d['violations'],all53reset_checked=True))
if any(d['violations'].values()):sys.exit(3)
subprocess.run(['ssh','yuzelu@10.129.166.172','mkdir','-p',remote+'/r256-balanced-reset-composition-1888/stronger-necessary-1955'],check=True)
subprocess.run(['scp',str(p),'yuzelu@10.129.166.172:'+remote+'/r256-balanced-reset-composition-1888/stronger-necessary-1955/receipt.json'],check=True)
log(dict(actual_all53_native_diagnostic_complete=True,whole_system_qualified=False))
