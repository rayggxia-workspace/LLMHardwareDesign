from pathlib import Path
import subprocess,tarfile,io,json,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();assert head=='7068ef6ee8e24b13de1bef0b9ee456357a1d2e84';sha=lambda raw:hashlib.sha256(raw).hexdigest()
with tarfile.open(b/'control162-source1976.tar.gz')as z:old=json.loads(z.extractfile('source-manifest.json').read())
names=sorted(old['files']);assert len(names)==1030;raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(head+':'+n+'\n'for n in names).encode(),cwd=r);stream=io.BytesIO(raw);files={}
for n in names:
 header=stream.readline().split();assert len(header)==3 and header[1]==b'blob';data=stream.read(int(header[2]));assert stream.read(1)==b'\n';files[n]=data
assert not stream.read();changed=[n for n,data in files.items()if sha(data)!=old['files'][n]];assert changed==['project/experiments/control_v1/router_conflict_snapshot.py','project/experiments/control_v1/test_router_conflict_snapshot.py'],changed
manifest=dict(commit=head,files={n:sha(raw)for n,raw in files.items()});archive=b/'control162-source1983.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as z:
 for n,data in list(files.items())+[('source-manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;z.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as z:assert all(sha(z.extractfile(n).read())==digest for n,digest in manifest['files'].items())
patch=subprocess.check_output(['git','diff','--binary',old['commit'],head,'--',*changed],cwd=r);(b/'control162-backout1983.patch').write_bytes(patch);receipt=dict(passed=True,commit=head,source_files=1030,unchanged_files=1028,changed_files=changed,archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,patch_sha256=sha(patch),whole_system_qualified=False);(b/'control162-archive1984.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
host='yuzelu@10.129.166.172';remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/'
for p,n in [(archive,'source1983.tar.gz'),(b/'control162-backout1983.patch','control162-backout1983.patch'),(b/'control162-archive1984.json','control162-archive1984.json'),(b/'control162-contract1975/receipt.json','control162-contract1975.json')]:subprocess.run(['scp',str(p),host+':'+remote+n],check=True)
