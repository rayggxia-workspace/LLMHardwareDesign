from pathlib import Path
import subprocess,shlex,json,time
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888';p=r/'upper-candidates/19700/route';d=dict(time=time.time(),whole_system_qualified=False,route_receipt_exists=(p/'receipt.json').exists())
if(p/'placement.json').exists():
 a=json.loads((p/'placement.json').read_text());c=json.loads((r/'cap-candidates/19540/placement.json').read_text());d['all345positions_and11149terminal_arrays_exact']=a['placements_um']==c['placements_um']and a['terminals']==c['terminals']
d['trial_count']=len([t for t in p.glob('trial-*')if t.is_dir()]);d['tails']=[]
if(p/'receipt.json').exists():d['route_passed']=json.loads((p/'receipt.json').read_text())['passed']
for t in sorted(p.glob('trial-*')):
 if not t.is_dir():continue
 row=dict(trial=t.name)
 for n in ['router.log','output.txt.native-prefix.log']:
  f=t/n
  if f.exists():
   with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-1100));row[n]=dict(bytes=f.stat().st_size,age=time.time()-f.stat().st_mtime,tail=stream.read().decode(errors='replace').splitlines()[-2:])
 d['tails'].append(row)
for folder in ['dynamic-06/node26','dynamic-09/node3']:
 f=b/folder/'queue-state.json';s=json.loads(f.read_text());d[folder]=dict(job=s['job'],active=s['active'],slots=s['slots'])
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-current1973-latest.json').write_bytes(raw);d=json.loads(raw);print(json.dumps({k:v for k,v in d.items()if k!='tails'}));print(json.dumps(d['tails'][:3]))
