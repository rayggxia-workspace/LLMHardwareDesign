from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';source=b/'source-1885';record=b/'route-selection-102/sready1970-arbiter-fullchain';audit=root/'final-chain-binding-audit-1970';assert not record.exists()and not audit.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
graph=root/'topology/boundary-graph.json';topology=root/'topology/topology.json';physical=root/'selected/physical.json';functions=root/'selected/functions.json';g=json.loads(graph.read_text());m=json.loads(physical.read_text());assert len(g['instances'])==345 and len(m['leaves'])==23 and g['instances']['s_port']=='control_s_arbiter_r7'and m['leaves']['control_s_arbiter_r7']['die_um']==[3200,3200]
assert g['instances']==json.loads((b/'r256-composition-453/topology/boundary-graph.json').read_text())['instances']
assert g['inputs'][str(physical)]==sha(physical)
fn=root/'function';fa=root/'function-audit/receipt.json';trace=root/'internal-program-traces/receipt.json'
function_task=next(t for t in json.loads((b/'route-selection-102/sready1895-measured-initial-refill/tasks.json').read_text())['tasks']if t['spec']['script']=='final_composition.py')
fsp=Path(function_task['path']);assert sha(fsp)==function_task['sha256'];fs=function_task['spec'];assert fs['source_root']==str(source)
for flag,value in [('--manifest',functions),('--physical',physical),('--graph',graph),('--topology',topology),('--out',fn)]:assert fs['args'][fs['args'].index(flag)+1]==str(value)
if(fn/'receipt.json').exists():assert json.loads((fn/'receipt.json').read_text())['passed'],'Actualfunctionfailed; repairbeforecontinuingphysicalsearch'
binding=root/'source-binding-audit/receipt.json';assert json.loads(binding.read_text())['passed']
place=root/'cap-candidates/19540';pr=json.loads((place/'receipt.json').read_text());assert pr['passed']and pr['stage']=='wire-cap-lower-bound-only'
necessary=root/'cap-necessary-1954/19540';pin=necessary/'native-pin-load/native-pin-load.json';pd=json.loads(pin.read_text());assert pd['passed']and len(pd['placements'])==1 and pd['placements'][0]['placement']==str(place)and pd['placements'][0]['violations']==dict(low=0,base=0,high=0)
for s in ['native-residual','native-pin-load']:assert json.loads((necessary/s/'receipt.json').read_text())['passed']
strong=root/'stronger-necessary-1955/receipt.json';sr=json.loads(strong.read_text());assert sr['passed']and sr['whole_system_qualified']is False and sr['violations']==dict(low=0,base=0,high=0)
assert sr['inputs']['placement.json']['sha256']==sha(place/'placement.json')and sr['inputs']['native-pin-load.json']['sha256']==sha(pin);assert sr['reset_nets_checked']==53
assert sr['rows_checked']==len(pd['placements'][0]['rows'])
placement=json.loads((place/'placement.json').read_text());assert placement['graph_sha256']==sha(graph)and len(placement['placements_um'])==345 and len(placement['terminals'])==11149 and sum(map(len,placement['terminals'].values()))==24760
for n in ['r256-balanced-reset-source-audit-1886','r256-cut-keepout-source-audit-1691','r256-cut-keepout-preflight-16920']:assert json.loads((b/n/'receipt.json').read_text())['passed']
original=json.loads((b/'source-1690/source-manifest.json').read_text());current=json.loads((source/'source-manifest.json').read_text());changed={p for p,v in current['files'].items()if original['files'].get(p)!=v};assert changed=={'project/experiments/block_v2/physical.py','project/experiments/control_v1/physical_only.py','project/experiments/control_v1/run.py','project/experiments/control_v1/topology.py','project/experiments/control_v1/boundary_links.py','project/experiments/control_v1/reset_link_banks.py','project/experiments/control_v1/current_pin_groups.py'}
reg=b/'r256-current-cpp-reuse-regression-19660';assert json.loads((reg/'receipt.json').read_text())['passed'];rr=json.loads((reg/'coarse-refine/receipt.json').read_text());assert rr['passed']and rr['guided_present_growth']==4 and len(rr['cases'])==20 and sum(not c['failed']for c in rr['cases'])==16 and len(rr['defaults'])==18 and len(rr['guided_disabled_defaults'])==16 and any(c['refined_after_original_cutoff']for c in rr['cases'])
oldpath=b/'dynamic-06/node26/pending/00-g-sready1534-r256-route-15340.json';assert sha(oldpath)=='762b1a036102403c25de5a249c0cba3ef48343f0769a0eebfc9d6f4611419971';oldcpp=json.loads(oldpath.read_text())['args']
template=json.loads((b/'route-selection-102/sready1717-hpwl-keepout-fullchain/tasks.json').read_text())['tasks'];assert len(template)==7;seed=19700;scene=root/'upper-candidates'/str(seed);config=root/('acceptance-'+str(seed)+'.json');assert not config.exists();cfg=dict(geometry=str(scene/'geometry'),pg_audit=str(scene/'pg-audit'),function_run=str(fn),topology=str(topology),signal_graph=str(graph),timing={v:str(scene/'timing'/v)for v in ['low','base','high']});config.write_text(json.dumps(cfg,indent=2));rows=[]
for old in template:
 spec=json.loads(json.dumps(old['spec']));spec['source_root']=str(source)
 def remap(x):return x.replace('/r256-composition-359/selected/', '/r256-balanced-reset-composition-1888/selected/').replace('/r256-composition-359/fixed-pg-wrappers','/r256-balanced-reset-composition-1888/fixed-pg-wrappers').replace('/r256-composition-453/','/r256-balanced-reset-composition-1888/').replace('/upper-candidates/17170/','/upper-candidates/19700/').replace('acceptance-17170.json','acceptance-19700.json').replace('/cap-candidates/17130','/cap-candidates/19540')
 spec['args']=[remap(x)for x in spec['args']]
 if spec['script']=='system_upper.py':
  a=list(oldcpp)
  for flag,value in [('--manifest',physical),('--graph',graph),('--pg-wrappers',root/'fixed-pg-wrappers'),('--reuse-placement',place),('--seed',seed),('--out',scene/'route'),('--route-residual-budget',necessary/'native-pin-load/native-pin-load.json')]:a[a.index(flag)+1]=str(value)
  k=a.index('--route-native-prefix-input');del a[k:k+2];a+=['--router','cpp'];spec['args']=a;spec['forecast_gib']=65
  spec['requires']=list(map(str,[necessary/'native-pin-load/receipt.json',root/'topology/receipt.json',binding,strong,place/'receipt.json',b/'r256-balanced-reset-source-audit-1886/receipt.json',b/'r256-cut-keepout-source-audit-1691/receipt.json',b/'r256-cut-keepout-preflight-16920/receipt.json',audit/'receipt.json',reg/'receipt.json']))
 else:spec['requires']=[remap(x)for x in spec['requires']]
 if '--acceptance'in spec['args']:spec['requires']+=list(map(str,[fa,trace,binding]))
 folder={'low':'dynamic-08/node6','base':'dynamic-09/node3','high':'dynamic-06/node26'}[spec['args'][spec['args'].index('--rc-variant')+1]]if spec['script']=='system_sta.py'else'dynamic-06/node26'
 p=b/folder/'pending'/(Path(old['path']).stem.replace('sready1717','sready1970').replace('17170',str(seed))+'.json');assert not p.exists();rows.append(dict(path=str(p),spec=spec))
# Validate the complete reviewable seven-stage chain before exposing any task.
assert set(cfg)=={'geometry','pg_audit','function_run','topology','signal_graph','timing'}and set(cfg['timing'])=={'low','base','high'}
for row in rows:
 s=row['spec'];a=s['args'];out=Path(a[a.index('--out')+1]);assert scene in out.parents and s['source_root']==str(source)
 assert a[a.index('--manifest')+1]==str(physical)
 if s['script']=='system_sta.py':
  v=a[a.index('--rc-variant')+1];assert s['forecast_gib']==224 and out==scene/'timing'/v and a[a.index('--graph')+1]==str(graph)and a[a.index('--functional-views')+1]==str(functions)and a[a.index('--upper-geometry')+1]==cfg['geometry']and '--stitch-native-access'in a and '--audit-native-coverage'in a
 elif s['script']=='system_upper.py':assert out==scene/'route'and a[a.index('--graph')+1]==str(graph)and a[a.index('--reuse-placement')+1]==str(place)and a[a.index('--router')+1]=='cpp'and '--route-residual-budget'in a and a[a.index('--route-residual-budget')+1]==str(necessary/'native-pin-load/native-pin-load.json')and '--route-native-prefix-input'not in a and '--route-native-prefix-first'in a and '--route-native-prefix-flexible'in a and a[a.index('--route-ordinary-present-growth')+1]=='4'and a[a.index('--route-trials')+1]=='16'and a[a.index('--route-ordinary-coarse-rounds')+1]=='16' and '--lock-native-output-routes'in a and '--defer-access-vias'in a
 else:
  assert a[a.index('--route')+1]==str(scene/'route')and a[a.index('--graph')+1]==str(scene/'route/physical-graph.json')
  if '--acceptance'in a:assert a[a.index('--acceptance')+1]==str(config)and out==scene/'delivery'
  elif '--pg-audit'in a:assert a[a.index('--pg-audit')+1]==cfg['geometry']and out==scene/'pg-audit'
  else:assert out==scene/'geometry'
audit.mkdir();inputs={str(p):sha(p)for p in [graph,topology,physical,functions,fsp,binding,strong,pin,place/'receipt.json',place/'placement.json',config,source/'source-manifest.json',reg/'receipt.json',reg/'coarse-refine/receipt.json',oldpath]}
(audit/'receipt.json').write_text(json.dumps(dict(passed=True,time=time.time(),whole_system_qualified=False,inputs=inputs,specifications=rows,source1690_only_seven_nonrouter_changes=sorted(changed),scope='Strictfresh1888balancedresetselected23types345instances,new3200Sarbiteractualpins/area andnecessaryall3zero. Physicalroute runsindependentlywhilefreshactualfunctioncompiles. Finaljointrequiresfresh1888threeinitialeightprograms,functionindependentaudit andfreshinternal/externaltracereceipts, plusowngeometryPGnativeXORall3RC300MHz. Futurefunctionspec/currentphysicalandgraphhashesboundnow; actualfuturefunction/traces mustpassbeforejoint. No oldfunctionqualificationinherited. Existingfullgates unchanged; no fullqualification untilactualjoin. Source1690routing/finalgates byteexact; sevenchangesoutside routers/gates explicitlylisted; oldscenequalifications notinherited.'),indent=2))
record.mkdir()
for row in rows:
 p=Path(row['path']);t=p.with_suffix('.tmp');t.write_text(json.dumps(row['spec']));t.rename(p);row['sha256']=sha(p)
(record/'tasks.json').write_text(json.dumps(dict(time=time.time(),tasks=rows,whole_system_qualified=False,strict_binding_audit=str(audit/'receipt.json'),scope='Onefreshbalancedresetfullcandidate19700 existingCPP comparison onexactactual19540placement only; physicalsearch andnumericalsimulation have no datadependency, finaljointstillrequiresactualfreshfunction/audit/traces andallphysicalgates, original7stage backendCPPexistingpresentgrowth4, original65GiBforecast/16CPU16independenttrials, allcriticalnativefinite/residualpinbudgets preserved, freshnativeprefix no obsolete5380prefix inherited/geometryPG/XOR/lowbasehigh224GiB300MHz/jointdelivery. Existingactualnode24naturallyfreedslot afterprovenoldretirement; low/base/high assignedfromoutset acrosssource269node6/source1885node3/source236actualnode24, unchanged224GiBforecasts andoriginalaggregate memoryguard, no newparent orcancel. No singleblock/necessarycap/functionpass substitutedforactualjointacceptance.'),indent=2));print(json.dumps(dict(queued=7,candidate=seed,whole_system_qualified=False)))
