from pathlib import Path
import json,sys,hashlib,collections,time,heapq
b=Path(__file__).parent;root=b/'control162-receive1988';out=b/'control162-joint1993';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from router_conflict_snapshot import inputs,inspect
h,nets,limits=inputs(root/'input.txt');locked=list(nets)[:h[6]];paths={};raws={}
with(root/'prefix.txt').open()as f:
 header=f.readline();assert int(header)==len(locked)==1229
 for name in locked:
  line=f.readline();actual,n=line.split();assert actual==name;raw=[line];branches=[]
  for _ in range(int(n)):
   line=f.readline();raw.append(line);row=list(map(int,line.split()));assert len(row)==1+3*row[0];branches.append([tuple(row[j:j+3])for j in range(1,len(row),3)])
  paths[name]=branches;raws[name]=''.join(raw)
 assert not f.read().strip()
pin_owner={(x,y,0):name for name,ends in nets.items()for x,y in ends};assert len(pin_owner)==24760
def points(branches):return set(v for branch in branches for v in branch)
def wires(branches):return {tuple(sorted((v,w)))for branch in branches for v,w in zip(branch,branch[1:])if v[2]==w[2]}
owners=collections.defaultdict(set)
for name,branches in paths.items():
 for v in points(branches):owners[v].add(name)
conflicts=[v for v,ns in owners.items()if len(ns)>1];assert len(conflicts)==2;targets={n for v in conflicts for n in owners[v]};g=json.loads((b/'control162-math-data1950-recovered/physical-graph.json').read_bytes());sinkgroups={g['connections'][n[4:]]['sinks'][0]['instance']for n in targets};groups={n for n in locked if any(v['instance']in sinkgroups for v in g['connections'][n[4:]]['sinks'])};trials=[];answer=None;started=time.time()
near=groups|{n for v,ns in owners.items()if any(abs(v[0]-c[0])<=6 and abs(v[1]-c[1])<=6 for c in conflicts)for n in ns if len(nets[n])==2}
for cohort in [targets,groups,near]:
 assert all(len(nets[n])==2 for n in cohort);frozen={v:ns-cohort for v,ns in owners.items()if ns-cohort};cache={};stats=dict(cohort=sorted(cohort),lowlevel_calls=0,expanded=0,highlevel_nodes=0,root_missing=[]);deadline=time.time()+25
 originals={n:points(paths[n])for n in cohort}
 def search(name,forbidden):
  key=name,forbidden
  if key in cache:return cache[key]
  stats['lowlevel_calls']+=1;start=(*nets[name][0],0);goal=(*nets[name][1],0);budget=limits[name]
  if start in forbidden or goal in forbidden:return None
  def heur(v):return abs(v[0]-goal[0])+abs(v[1]-goal[1])
  labels={start:{0:0}};parent={};queue=[(heur(start),0,0,start)];expanded=0
  while queue:
   _,cost,wire,v=heapq.heappop(queue)
   if labels.get(v,{}).get(wire)!=cost:continue
   if v==goal:
    path=[v];state=v,wire
    while state!=(start,0):state=parent[state];path.append(state[0])
    result=path[::-1];cache[key]=result;stats['expanded']+=expanded;return result
   expanded+=1
   if expanded>250000 or(expanded%2048==0 and time.time()>deadline):break
   x,y,l=v;neighbors=[(x-1,y,l),(x+1,y,l),(x,y-1,l),(x,y+1,l)]
   if(x+y)%2==0:neighbors.append((x,y,1-l))
   for zz in neighbors:
    if not(4<=zz[0]<h[0]-4 and 4<=zz[1]<h[1]-4)or zz in forbidden or zz in frozen:continue
    if zz[2]==0 and pin_owner.get(zz,name)!=name:continue
    nw=wire+int(zz[2]==l);nc=cost+int(zz[2]==l)+3*int(zz[2]!=l)+100*int(zz not in originals[name])
    if nw+heur(zz)>budget:continue
    rows=labels.setdefault(zz,{})
    if any(w<=nw and c<=nc for w,c in rows.items()):continue
    rows={w:c for w,c in rows.items()if not(nw<=w and nc<=c)};rows[nw]=nc;labels[zz]=rows;parent[(zz,nw)]=(v,wire);heapq.heappush(queue,(nc+heur(zz),nc,nw,zz))
  stats['expanded']+=expanded;cache[key]=None;return None
 constraints={n:frozenset()for n in cohort};initial={n:(paths[n][-1]if paths[n][-1][0]==(*nets[n][0],0)else paths[n][-1][::-1])for n in sorted(cohort)};stats['root_missing']=[n for n,p in initial.items()if p is None]
 if stats['root_missing']:trials.append(stats);print(json.dumps(stats),flush=True);continue
 def score(ps):
  counts=collections.Counter(v for p in ps.values()for v in set(p));conflict_count=sum(c>1 for c in counts.values())
  value=sum(sum(int(v[2]==w[2])+3*int(v[2]!=w[2])+100*int(w not in originals[n])for v,w in zip(p,p[1:]))for n,p in ps.items())
  return conflict_count,value
 serial=0;queue=[(score(initial),serial,constraints,initial)];seen=set()
 while queue and stats['highlevel_nodes']<5000 and time.time()<deadline:
  cost,_,cs,ps=heapq.heappop(queue);stats['highlevel_nodes']+=1;uses=collections.defaultdict(list)
  for n,p in sorted(ps.items()):
   for v in set(p):uses[v].append(n)
  conflict=next(((v,ns[:2])for v,ns in sorted(uses.items())if len(ns)>1),None)
  if conflict is None:answer=ps;break
  v,ns=conflict
  for n in ns:
   cc=dict(cs);cc[n]=cc[n]|{v};key=tuple((a,tuple(sorted(z)))for a,z in sorted(cc.items()))
   if key in seen:continue
   seen.add(key);p=search(n,cc[n])
   if p is None:continue
   pp=dict(ps);pp[n]=p;serial+=1;heapq.heappush(queue,(score(pp),serial,cc,pp))
 stats['solved']=answer is not None;trials.append(stats);print(json.dumps(stats),flush=True)
 if answer is not None:break
receipt=dict(passed=False,candidate_only=True,whole_system_qualified=False,trials=trials,seconds=time.time()-started,scope='Bounded puredata near-original jointvertex-disjunction search (greedy conflict-count first, weighteddeviation paths with pervertex wire/cost Pareto labels): originalunitgrid/budgets andall24760foreignM11landings; othernative paths fixed. Failure is only boundedsearch failure, never impossibility. Does not qualify nativegeometry/PG/RC300MHz; existing warmimport andallfinalgates mandatory.')
if answer is not None:
 changed=[]
 for n,p in answer.items():paths[n]=[[(*nets[n][0],0)],p];changed.append(dict(net=n,wire_edges=len(wires(paths[n])),wire_budget=limits[n]))
 prefix=out/'prefix.txt'
 with prefix.open('w',newline='\n')as f:
  f.write(header)
  for n in locked:
   if n not in answer:f.write(raws[n]);continue
   f.write(n+' '+str(len(paths[n]))+'\n')
   for p in paths[n]:f.write(str(len(p))+' '+' '.join(str(v)for point in p for v in point)+'\n')
 proof=inspect(prefix,{n:nets[n]for n in locked},h[0],h[1],limits);assert proof['conflict_nodes']==0 and proof['all_trees_flood_verified']and proof['all_wire_budgets_verified'];assert all(pin_owner.get(v,n)==n for n,bs in paths.items()for v in points(bs)if v[2]==0)
 receipt.update(passed=True,changed=changed,unchanged_native_nets=1229-len(answer),repaired_prefix_sha256=sha(prefix),input_sha256=sha(root/'input.txt'),original_prefix_sha256=sha(root/'prefix.txt'),independent_prefix_proof=proof)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items()if k not in ['independent_prefix_proof','trials']}))
