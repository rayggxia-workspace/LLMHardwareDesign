from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time,subprocess
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');r=b/'r256-balanced-reset-composition-1888';d=dict(time=time.time(),whole_system_qualified=False,routes=[])
for seed in [19160,19210,19310,19580]:
 p=r/'upper-candidates'/str(seed)/'route';f=p/'openroad-search/case-0/openroad.log';row=dict(candidate=seed,route_receipt_exists=(p/'receipt.json').exists(),actual_final_trees_exist=(p/'trees.json').exists())
 if f.exists():
  with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-1600));row.update(log_bytes=f.stat().st_size,log_age=time.time()-f.stat().st_mtime,tail=stream.read().decode(errors='replace').splitlines()[-5:])
 d['routes'].append(row)
for label in ['function','internal-program-traces']:
 p=r/label;row=dict(receipt_exists=(p/'receipt.json').exists())
 if(p/'receipt.json').exists():row['passed']=json.loads((p/'receipt.json').read_text())['passed']
 for n in ['build.log','initial-1-162.json','initial-2-162.json','initial-2-163.json']:
  f=p/n
  if f.exists():
   with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-250));row[n]=dict(bytes=f.stat().st_size,age=time.time()-f.stat().st_mtime,tail=stream.read().decode(errors='replace'))
 d[label]=row
d['actual_node4_steps']=subprocess.check_output(['sstat','-j','95391','--allsteps','-P','--format=JobID,AveCPU,MaxRSS,AveRSS,NTasks','-n'],universal_newlines=True)
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-monitor1962-latest.json').write_bytes(raw);d=json.loads(raw)
for row in d['routes']:print(json.dumps(row))
for k in ['function','internal-program-traces','actual_node4_steps']:print(k,json.dumps(d[k]))
