from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-current-native-snapshot-19860';d={}
for f in [p/'receipt.json',p/'native-prefix/receipt.json',b/'dynamic-09/node3/results/00-a-sready1986-current-native-snapshot-19860.json']:
 if f.exists():d[str(f)]=json.loads(f.read_text())
q=b/'dynamic-09/node3'
for f in q.glob('*1986*'):
 if f.is_file():d[str(f)]=f.read_text(errors='replace')[-3500:]
for sub in ['logs','commands']:
 for f in (q/sub).glob('*1986*'):
  if f.is_file():d[str(f)]=f.read_text(errors='replace')[-3500:]
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-native1987-latest.json').write_bytes(raw);d=json.loads(raw)
for k,v in d.items():
 if isinstance(v,dict):v={a:c for a,c in v.items()if a not in ['inputs','outputs','spec','command','args']}
 print(k,json.dumps(v)[:4000])
