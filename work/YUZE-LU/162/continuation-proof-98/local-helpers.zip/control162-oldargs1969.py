from pathlib import Path
import subprocess,shlex,json
p='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/dynamic-06/node26/pending/00-g-sready1534-r256-route-15340.json';q='from pathlib import Path;print(Path('+repr(p)+').read_text())';raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-oldargs1969.json').write_bytes(raw);print(json.dumps(json.loads(raw)['args']))
