from pathlib import Path
import json,sys,collections
b=Path(__file__).parent;sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from router_conflict_snapshot import inputs
root=b/'control162-receive1988';h,nets,limits=inputs(root/'input.txt');paths={}
with(root/'prefix.txt').open()as f:
 count=int(f.readline())
 for _ in range(count):
  name,n=f.readline().split();branches=[]
  for i in range(int(n)):
   row=list(map(int,f.readline().split()));assert len(row)==1+3*row[0];branches.append([tuple(row[j:j+3])for j in range(1,len(row),3)])
  paths[name]=branches
 assert not f.read().strip()
g=json.loads((b/'control162-math-data1950-recovered/physical-graph.json').read_bytes());conflicts=json.loads((root/'diagnostic.json').read_bytes())['conflict_cells'];rows=[]
for c in conflicts:
 point=(c['x'],c['y'],c['layer'])
 for name in c['nets']:
  branches=paths[name];edges={tuple(sorted((a,z)))for branch in branches for a,z in zip(branch,branch[1:])if a[2]==z[2]};hits=[]
  for bi,branch in enumerate(branches):
   for i,v in enumerate(branch):
    if v==point:hits.append(dict(branch=bi,index=i,neighbors=branch[max(0,i-5):i+6]))
  con=g['connections'][name[4:]];rows.append(dict(net=name,terminals=nets[name],wire_budget=limits[name],wire_edges=len(edges),branches=len(branches),hits=hits,driver=con['driver'],sinks=con['sinks']))
out=b/'control162-prefix1989';assert not out.exists();out.mkdir();(out/'receipt.json').write_text(json.dumps(dict(diagnostic_only=True,whole_system_qualified=False,grid=h[:2],locked=count,rows=rows),indent=2));print(json.dumps(rows))
