from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-wire1963.py').read_text(encoding='utf-8').replace('control162-wire1963','control162-wire1967');s=s.replace('offgrid=0','offgrid=0;intervals=collections.defaultdict(list)');s=s.replace('  prev=None','  prev=None;layer=chunk.split()[0]');old="   if prev is not None:assert x==prev[0]or y==prev[1];length+=abs(x-prev[0])+abs(y-prev[1]);segments+=1;zero+=int((x,y)==prev)";assert old in s;s=s.replace(old,"""   if prev is not None:
    assert x==prev[0]or y==prev[1];length+=abs(x-prev[0])+abs(y-prev[1]);segments+=1;zero+=int((x,y)==prev)
    if x!=prev[0]:intervals[(layer,0,y)].append(tuple(sorted((x,prev[0]))))
    if y!=prev[1]:intervals[(layer,1,x)].append(tuple(sorted((y,prev[1]))))""")
target=" pts=term[name];hpwl=";assert target in s
s=s.replace(target,""" unique=0
 for key,spans in intervals.items():
  end=None
  for lo,hi in sorted(spans):
   if end is None or lo>end:unique+=hi-lo;end=hi
   elif hi>end:unique+=hi-end;end=hi
 pts=term[name];hpwl=""")
s=s.replace('segments=segments,zero_length_segments','unique_collinear_centerline_um=unique/2000,segments=segments,zero_length_segments');s=s.replace("seconds=time.time()-started,by_driver=","unique_collinear_centerline_um=sum(v['unique_collinear_centerline_um']for v in rows),seconds=time.time()-started,by_driver=");s=s.replace('Actual failed bounded19350 DEF canonical segment L1 lengths; duplicate/overlapping wire segments are counted and this is not unique conductive union or RC extraction.','Actual failed bounded19350 DEF canonical segment L1 lengths plus independently merged pernet/perlayer collinear centerline intervals. Segment sum counts duplicates; unique_collinear_centerline removes collinear overlap only, not polygonunion or RC extraction.');p=b/'control162-wire1967.py';assert not p.exists();p.write_text(s,encoding='utf-8');compile(s,'wire1967','exec');subprocess.run(['python',str(p)],check=True)
