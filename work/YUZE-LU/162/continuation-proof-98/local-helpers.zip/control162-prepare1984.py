from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-archive1977.py').read_text(encoding='utf-8').replace('control162-source1885.tar.gz','control162-source1976.tar.gz').replace('514fdf3c78d6088451e6fc1dd52e04fd2c2d8ea1','7068ef6ee8e24b13de1bef0b9ee456357a1d2e84').replace('source1976.tar.gz','source1983.tar.gz').replace('backout1976.patch','backout1983.patch').replace('archive1977.json','archive1984.json')
# The previous archive remains1976, while only the new output is1983.
s=s.replace("b/'control162-source1983.tar.gz')as z:old=","b/'control162-source1976.tar.gz')as z:old=")
s=s.replace("['project/experiments/control_v1/native_prefix_snapshot.py'],changed","['project/experiments/control_v1/router_conflict_snapshot.py','project/experiments/control_v1/test_router_conflict_snapshot.py'],changed").replace("'--',changed[0]","'--',*changed").replace('unchanged_files=1029','unchanged_files=1028')
p=b/'control162-archive1984.py';assert not p.exists();compile(s,'archive1984','exec');p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p)],check=True)
