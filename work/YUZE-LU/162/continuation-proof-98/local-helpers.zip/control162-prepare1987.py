from pathlib import Path
import subprocess
b=Path(__file__).parent;s=(b/'control162-native1980.py').read_text(encoding='utf-8').replace('1979','1986').replace('19790','19860').replace('control162-native1980-latest','control162-native1987-latest');p=b/'control162-native1987.py';assert not p.exists();p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p)],check=True)
