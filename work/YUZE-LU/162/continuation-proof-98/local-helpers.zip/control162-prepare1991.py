from pathlib import Path
import json,subprocess
b=Path(__file__).parent;(b/'control162-repair1990/failure.json').write_text(json.dumps(dict(passed=False,candidate_only=True,whole_system_qualified=False,error='No local window repair found; no prefix file or acceptance receipt emitted, original inputs untouched.'),indent=2));s=(b/'control162-repair1990.py').read_text(encoding='utf-8').replace('control162-repair1990','control162-repair1991').replace('import json,sys,hashlib,collections,time,copy','import json,sys,hashlib,collections,time,copy,heapq')
start=s.index('while conflicts():')
code='''def astar(name):
 assert len(nets[name])==2
 start=(*nets[name][0],0);goal=(*nets[name][1],0);budget=limits[name]
 def heuristic(v):return abs(v[0]-goal[0])+abs(v[1]-goal[1])
 dist={start:(0,0)};parent={};heap=[(heuristic(start),0,0,start)];expanded=0
 while heap:
  _,nv,nw,v=heapq.heappop(heap)
  if dist[v]!=(nw,nv):continue
  if v==goal:
   path=[v]
   while v!=start:v=parent[v];path.append(v)
   return path[::-1],expanded
  expanded+=1
  if expanded>250000:return None,expanded
  x,y,l=v;neighbors=[(x-1,y,l),(x+1,y,l),(x,y-1,l),(x,y+1,l)]
  if(x+y)%2==0:neighbors.append((x,y,1-l))
  for z in neighbors:
   if not(4<=z[0]<h[0]-4 and 4<=z[1]<h[1]-4):continue
   if owners.get(z,set())-{name}:continue
   if z[2]==0 and pin_owner.get(z,name)!=name:continue
   value=(nw+int(z[2]==l),nv+int(z[2]!=l))
   if value[0]+heuristic(z)>budget:continue
   if z not in dist or value<dist[z]:dist[z]=value;parent[z]=v;heapq.heappush(heap,(value[0]+heuristic(z),value[1],value[0],z))
 return None,expanded
'''
s=s[:start]+code+s[start:]
needle=" assert options,'No local window repair found; original evidence retained'";assert needle in s
s=s.replace(needle,''' if not options:
  for name in sorted({n for v in before for n in owners[v]}):
   path,expanded=astar(name)
   if path is None:continue
   candidate=[[(*nets[name][0],0)],path];old=paths[name];oldpoints=points(old);newpoints=points(candidate);affected=oldpoints|newpoints
   oldbad=sum(len(owners[v])>1 for v in affected);newbad=sum(len((owners[v]-{name})|({name}if v in newpoints else set()))>1 for v in affected);remaining=len(before)-oldbad+newbad
   assert len(wires(candidate))<=limits[name]
   if remaining<len(before):options.append(((remaining,vias(candidate)-vias(old),len(oldpoints^newpoints),name,1,path),name,1,candidate,'bounded-shortest-wire-astar-'+str(expanded),len(wires(old)),vias(old)))
 assert options,'No bounded repair found; original evidence retained' ''')
s=s.replace('localM11/M12 window lifts/via slides, two conflictingpairs repaired without increasing any modifiednet wireedges or originalbudget.','localM11/M12 window lifts/via slides or bounded250000state two-terminal shortestwire Astar using original wirebudget. Actual pernet wire/via changes recorded, no originalbudget increased.').replace("out/'receipt.json'","out/'receipt.json'")
p=b/'control162-repair1991.py';assert not p.exists();compile(s,'repair1991','exec');p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p)],check=True)
