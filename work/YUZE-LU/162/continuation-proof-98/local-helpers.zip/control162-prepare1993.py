from pathlib import Path
import subprocess,json
b=Path(__file__).parent;(b/'control162-repair1991/failure.json').write_text(json.dumps(dict(passed=False,whole_system_qualified=False,scope='Bounded single-net repair failed, no prefix emitted; no infeasibility claim.'),indent=2));s=(b/'control162-joint1992.py').read_text(encoding='utf-8').replace('control162-joint1992','control162-joint1993')
s=s.replace('for cohort in [targets,groups]:',"near=groups|{n for v,ns in owners.items()if any(abs(v[0]-c[0])<=6 and abs(v[1]-c[1])<=6 for c in conflicts)for n in ns if len(nets[n])==2}\nfor cohort in [targets,groups,near]:")
a=s.index(' def search(name,forbidden):');z=s.index(' constraints=',a)
new=''' originals={n:points(paths[n])for n in cohort}
 def search(name,forbidden):
  key=name,forbidden
  if key in cache:return cache[key]
  stats['lowlevel_calls']+=1;start=(*nets[name][0],0);goal=(*nets[name][1],0);budget=limits[name]
  if start in forbidden or goal in forbidden:return None
  def heur(v):return abs(v[0]-goal[0])+abs(v[1]-goal[1])
  labels={start:{0:0}};parent={};queue=[(heur(start),0,0,start)];expanded=0
  while queue:
   _,cost,wire,v=heapq.heappop(queue)
   if labels.get(v,{}).get(wire)!=cost:continue
   if v==goal:
    path=[v];state=v,wire
    while state!=(start,0):state=parent[state];path.append(state[0])
    result=path[::-1];cache[key]=result;stats['expanded']+=expanded;return result
   expanded+=1
   if expanded>250000 or(expanded%2048==0 and time.time()>deadline):break
   x,y,l=v;neighbors=[(x-1,y,l),(x+1,y,l),(x,y-1,l),(x,y+1,l)]
   if(x+y)%2==0:neighbors.append((x,y,1-l))
   for zz in neighbors:
    if not(4<=zz[0]<h[0]-4 and 4<=zz[1]<h[1]-4)or zz in forbidden or zz in frozen:continue
    if zz[2]==0 and pin_owner.get(zz,name)!=name:continue
    nw=wire+int(zz[2]==l);nc=cost+int(zz[2]==l)+3*int(zz[2]!=l)+100*int(zz not in originals[name])
    if nw+heur(zz)>budget:continue
    rows=labels.setdefault(zz,{})
    if any(w<=nw and c<=nc for w,c in rows.items()):continue
    rows={w:c for w,c in rows.items()if not(nw<=w and nc<=c)};rows[nw]=nc;labels[zz]=rows;parent[(zz,nw)]=(v,wire);heapq.heappush(queue,(nc+heur(zz),nc,nw,zz))
  stats['expanded']+=expanded;cache[key]=None;return None
'''
s=s[:a]+new+s[z:]
s=s.replace("initial={n:search(n,frozenset())for n in sorted(cohort)}","initial={n:(paths[n][-1]if paths[n][-1][0]==(*nets[n][0],0)else paths[n][-1][::-1])for n in sorted(cohort)}")
old="def score(ps):return sum(sum(v[2]==w[2]for v,w in zip(p,p[1:]))for p in ps.values())";assert old in s
s=s.replace(old,"""def score(ps):
  counts=collections.Counter(v for p in ps.values()for v in set(p));conflict_count=sum(c>1 for c in counts.values())
  value=sum(sum(int(v[2]==w[2])+3*int(v[2]!=w[2])+100*int(w not in originals[n])for v,w in zip(p,p[1:]))for n,p in ps.items())
  return conflict_count,value""")
s=s.replace('Bounded puredata jointvertex-disjunction search:','Bounded puredata near-original jointvertex-disjunction search (greedy conflict-count first, weighteddeviation paths with pervertex wire/cost Pareto labels):')
p=b/'control162-joint1993.py';assert not p.exists();compile(s,'joint1993','exec');p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p)],check=True)
