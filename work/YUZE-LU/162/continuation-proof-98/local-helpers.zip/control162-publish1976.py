from pathlib import Path
import subprocess
b=Path(__file__).parent;p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');assert "'1961')"in s;s=s.replace("'1961')","'1961','1976')");p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p),'1976'],check=True)
