from pathlib import Path
import subprocess
b=Path(__file__).parent;p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');assert "'1976')"in s;s=s.replace("'1976')","'1976','1983')");p.write_text(s,encoding='utf-8');subprocess.run(['python',str(p),'1983'],check=True)
