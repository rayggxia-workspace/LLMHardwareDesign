from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');d={};p=b/'r256-current-cpp-reuse-regression-19660'
for f in [p/'receipt.json',p/'coarse-refine/receipt.json',b/'dynamic-09/node3/results/00-a-sready1966-current-cpp-regression-19660.json']:
 if f.exists():
  x=json.loads(f.read_text());d[str(f)]={k:v for k,v in x.items()if k in ['passed','returncode','guided_present_growth','guided_adaptive','guided_history_product','guided_global_batch','scope']}
  if 'cases'in x:d[str(f)]['cases']=len(x['cases']);d[str(f)]['zero']=sum(not c['failed']for c in x['cases'])
  if 'defaults'in x:d[str(f)]['defaults']=len(x['defaults'])
f=b/'r256-balanced-reset-composition-1888/upper-candidates/19580/route/openroad-search/case-0/openroad.log';d['19580_global']=[s for s in f.read_text().splitlines()if any(t in s for t in ['congestion remaining','Wire length:','Total congestion:','metal11   H','metal12   V','Total wirelength:'])]
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-read1968-latest.json').write_bytes(raw);print(raw.decode()[:3500])
