from pathlib import Path
import subprocess
r=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control');bad=[]
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:
  name=raw.decode()
  if subprocess.check_output(['git','show',':'+name],cwd=r)!=(r/name).read_bytes():bad.append(name)
assert bad==['work/YUZE-LU/162/current-native-replay1976/README.md'],bad
for name in bad:p=r/name;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'));subprocess.run(['git','add','--',name],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:name=raw.decode();assert subprocess.check_output(['git','show',':'+name],cwd=r)==(r/name).read_bytes(),name
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Replay current native-prefix failures with exact source-bound diagnostic flags'],cwd=r,check=True);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip())
