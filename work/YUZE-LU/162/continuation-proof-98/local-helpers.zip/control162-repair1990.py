from pathlib import Path
import json,sys,hashlib,collections,time,copy
b=Path(__file__).parent;root=b/'control162-receive1988';out=b/'control162-repair1990';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();idx=json.loads((root/'reception.json').read_bytes());assert all(sha(root/n)==v['sha256']for n,v in idx['files'].items());sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from router_conflict_snapshot import inputs,inspect
h,nets,limits=inputs(root/'input.txt');locked=list(nets)[:h[6]];paths={};raws={}
with(root/'prefix.txt').open()as f:
 header=f.readline();assert int(header)==len(locked)==1229
 for name in locked:
  line=f.readline();actual,n=line.split();assert actual==name;raw=[line];branches=[]
  for _ in range(int(n)):
   line=f.readline();raw.append(line);row=list(map(int,line.split()));assert len(row)==1+3*row[0];branches.append([tuple(row[j:j+3])for j in range(1,len(row),3)])
  paths[name]=branches;raws[name]=''.join(raw)
 assert not f.read().strip()
pin_owner={(x,y,0):name for name,ends in nets.items()for x,y in ends};assert len(pin_owner)==24760
def points(branches):return set(v for branch in branches for v in branch)
def wires(branches):return {tuple(sorted((v,w)))for branch in branches for v,w in zip(branch,branch[1:])if v[2]==w[2]}
def vias(branches):return sum(v[2]!=w[2]for branch in branches for v,w in zip(branch,branch[1:]))
owners=collections.defaultdict(set)
for name,branches in paths.items():
 for v in points(branches):owners[v].add(name)
conflicts=lambda:sorted(v for v,ns in owners.items()if len(ns)>1)
assert len(conflicts())==2;changes=[];started=time.time();attempts=0
def variants(branch,at):
 for reverse in [False,True]:
  row=branch[::-1]if reverse else branch;pos=len(row)-1-at if reverse else at
  # Lift a same-layer interior window, using original even via sites only.
  for lo in range(max(0,pos-12),pos):
   for hi in range(pos+1,min(len(row),pos+13)):
    part=row[lo:hi+1]
    if part[0][2]!=0 or any(v[2]!=0 for v in part)or any((v[0]+v[1])%2 for v in [part[0],part[-1]]):continue
    new=row[:lo+1]+[(x,y,1)for x,y,_ in part]+row[hi:]
    yield ('lift',new[::-1]if reverse else new)
  # Slide an existing1->0 via beyond the conflict, retaining wire/via counts.
  for lo in range(max(0,pos-12),pos):
   if row[lo][2]!=1 or row[lo+1]!=(row[lo][0],row[lo][1],0):continue
   for hi in range(pos+1,min(len(row),pos+13)):
    part=row[lo+1:hi+1]
    if any(v[2]!=0 for v in part)or(sum(row[hi][:2])%2):continue
    new=row[:lo+1]+[(x,y,1)for x,y,_ in row[lo+2:hi+1]]+row[hi:]
    yield ('slide-via',new[::-1]if reverse else new)
while conflicts():
 before=conflicts();options=[]
 for target in before:
  for name in sorted(owners[target]):
   old=paths[name];oldpoints=points(old);oldwire=len(wires(old));oldvia=vias(old)
   for bi,branch in enumerate(old):
    for pos,v in enumerate(branch):
     if v!=target:continue
     for kind,newbranch in variants(branch,pos):
      attempts+=1;assert attempts<50000
      candidate=old[:bi]+[newbranch]+old[bi+1:];newpoints=points(candidate)
      if target in newpoints or len(wires(candidate))>min(limits[name],oldwire):continue
      if any(pin_owner.get(v,name)!=name for v in newpoints if v[2]==0):continue
      if any(not(4<=x<h[0]-4 and 4<=y<h[1]-4)for x,y,l in newpoints):continue
      affected=oldpoints|newpoints;oldbad=sum(len(owners[v])>1 for v in affected);newbad=sum(len((owners[v]-{name})|({name}if v in newpoints else set()))>1 for v in affected);remaining=len(before)-oldbad+newbad
      if remaining>=len(before):continue
      score=(remaining,vias(candidate)-oldvia,len(oldpoints^newpoints),name,bi,newbranch)
      options.append((score,name,bi,candidate,kind,oldwire,oldvia))
 assert options,'No local window repair found; original evidence retained'
 score,name,bi,candidate,kind,oldwire,oldvia=min(options,key=lambda v:v[0]);oldpoints=points(paths[name]);newpoints=points(candidate)
 for v in oldpoints:owners[v].discard(name)
 for v in newpoints:owners[v].add(name)
 paths[name]=candidate;changes.append(dict(net=name,branch=bi,kind=kind,old_wire_edges=oldwire,new_wire_edges=len(wires(candidate)),wire_budget=limits[name],old_vias=oldvia,new_vias=vias(candidate),remaining_conflicts=len(conflicts())))
changed={v['net']for v in changes};prefix=out/'prefix.txt'
with prefix.open('w',newline='\n')as f:
 f.write(header)
 for name in locked:
  if name not in changed:f.write(raws[name]);continue
  f.write(name+' '+str(len(paths[name]))+'\n')
  for branch in paths[name]:f.write(str(len(branch))+' '+' '.join(str(v)for point in branch for v in point)+'\n')
proof=inspect(prefix,{n:nets[n]for n in locked},h[0],h[1],limits);assert proof['conflict_nodes']==0 and proof['all_trees_flood_verified']and proof['all_wire_budgets_verified'];assert all(pin_owner.get(v,name)==name for name,branches in paths.items()for v in points(branches)if v[2]==0)
d=dict(passed=True,candidate_only=True,whole_system_qualified=False,seconds=time.time()-started,attempts=attempts,changes=changes,unchanged_native_nets=1229-len(changed),all11149_landings_checked=24760,original_input=idx['files']['input.txt'],original_prefix=idx['files']['prefix.txt'],repaired_prefix_sha256=sha(prefix),independent_prefix_proof=proof,scope='Puredata candidate from exact19860 replay case14 only; localM11/M12 window lifts/via slides, two conflictingpairs repaired without increasing any modifiednet wireedges or originalbudget. All1229trees independently originalunit-edge/via-parity/flood/wire/occupancy checked andall24760actualM11foreignlandings guarded. Original inputs/source/masks/gates untouched; does NOT qualify actualgeometry/PG/nativeRC300MHz. Existing fullCPP warm import andallfinal gates mandatory next. No original failed file overwritten.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));print(json.dumps({k:v for k,v in d.items()if k not in ['independent_prefix_proof','original_input','original_prefix']}))
