from pathlib import Path
import ast,json,collections,math,time,sys
b=Path(__file__).parent;out=b/'control162-reset1972';assert not out.exists();out.mkdir();p=json.loads((b/'control162-subset1955/placement.json').read_bytes());rows=json.loads((b/'control162-subset1955/native-pin-load.json').read_bytes())['placements'][0]['rows'];ns=dict(collections=collections)
t=ast.parse((b/'control162-milp1926.py').read_text(encoding='utf-8'))
for name in ['merge','length','projection','construct','verify']:
 fn=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name==name);exec(compile(ast.Module(body=[fn],type_ignores=[]),'full-terminal-constructive-diagnostic','exec'),ns)
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from steiner_wire_bound import grid_tree_bound
result=[]
for r in rows:
 if r['driver']['instance']!='reset_distribution':continue
 pts=list(map(tuple,p['terminals'][r['net']]));bound=grid_tree_bound(pts)['necessary_wire_grid_edges'];wire=r['optimistic_total_ff']['high']-r['native_ground_cap_ff'];budget=(r['max_capacitance_ff']-r['native_ground_cap_ff']-r['minimum_input_pin_cap_ff'])*bound/wire
 tree=min((ns['construct'](pts,v)for v in sorted(set(pts))),key=lambda v:(ns['length'](v),v));ns['verify'](pts,tree);edges=ns['length'](tree);result.append(dict(net=r['net'],terminals=len(pts),upper_edges=edges,budget_edges=budget,upper_excess_edges=max(0,edges-budget),tree=tree))
assert len(result)==53
d=dict(diagnostic_only=True,whole_system_qualified=False,reset_nets=53,constructive_full_terminal_tree_over_search_budget=sum(v['upper_excess_edges']>1e-7 for v in result),worst_upper_excess_edges=max(v['upper_excess_edges']for v in result),results=result,scope='Full actual19540 reset terminals, greedy rectilinear tree from every terminal start independently flood/length checked, minimum constructive UPPER bound only. Upper>budget is NOT infeasibility and cannot retire tasks. Ignores layer assignment/via/collision cost and is not route/RC acceptance. All original actualnative/minpin high wire budgets unchanged. No source/gate changes.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));print(json.dumps({k:v for k,v in d.items()if k!='results'}));print(json.dumps([v for v in result if v['upper_excess_edges']>0])[:1600])
