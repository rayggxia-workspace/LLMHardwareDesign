from pathlib import Path
import json,hashlib,subprocess
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/current-native-replay1976';assert not out.exists();out.mkdir();p=out/'contract.json';p.write_bytes((b/'control162-contract1975/receipt.json').read_bytes());d=json.loads(p.read_bytes());assert d['passed']and d['current_flags_exact_actual_wrapper']
source=r/'project/experiments/control_v1/native_prefix_snapshot.py';source.write_bytes(source.read_bytes().replace(b'\r\n',b'\n'));assert hashlib.sha256(source.read_bytes()).hexdigest()==d['source_sha256']['native_prefix_snapshot.py']
(out/'README.md').write_text('''# Issue162：当前原生网格失败的精确观察回放

对应 Issue #162 / Draft PR #163。完整组合仍未通过，不合并。source1885的当前19540实际摆放/19700原生网格对照中，首批16个受限原生前缀在80轮后仍有少量冲突；不能以少量冲突或单块通过替代系统资格。

只扩展现有 `native_prefix_snapshot.py` 的诊断配置白名单，接受当前已通过组件回归的19项完整CPP CLI；原9项after-native白名单保留。两组必须精确匹配，不开放任意命令。当前选择避开trial-0（它另有global-snapshot参数），取trial-1至16的真实完整失败。不能删除普通阶段选项来伪称原命令回放，因为即使普通阶段未执行，这些选项也会出现在原生阶段的诊断计数行。

现有观察器/worker/编译反向校验/全部80轮原生计数及主失败日志逐字比较不变；内核、搜索、真实引脚、布线、几何、PG、原生覆盖、300MHz三RC门均不变。观察用C++副本仅在原失败决定后导出路径，原CPP源及正在运行的source1885作业不修改。这一提交没有新硬件或版图。

本地已验证旧选择精确恢复、19项与实际wrapper生成顺序逐字相等、6种坏配置不在白名单、仅诊断选择块改变。实际16组服务器回放仍待冻结/全1030源与归档/反向补丁审计后运行。诊断通过也不授予路由或系统资格。

登记PR5 pending；看板缺配置unverified/同步pending；审查待指定。继续定位真实冲突并完成所有声明组合的最终P&R与300MHz验收，不在此检查点停工。
''',encoding='utf-8')
attr=r/'.gitattributes';attr.write_bytes(attr.read_bytes()+b'\nwork/YUZE-LU/162/current-native-replay1976/*.json -text\n')
for path,prefix in [('docs/CONTROL_V1.md','../'),('progress/YUZE-LU/STATUS.md','../../')]:
 p=r/path;p.write_bytes((f'Issue162：[当前原生网格失败的精确观察回放]({prefix}work/YUZE-LU/162/current-native-replay1976/README.md)仅扩展诊断CLI白名单，原worker/内核/全部验收门不变；本地合同通过，真实16组回放待冻结审计，组合仍未验收，继续。\n\n').encode()+p.read_bytes())
names=['project/experiments/control_v1/native_prefix_snapshot.py','.gitattributes','docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md','work/YUZE-LU/162/current-native-replay1976']
for name in names[:-1]:p=r/name;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*names],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:name=raw.decode();assert subprocess.check_output(['git','show',':'+name],cwd=r)==(r/name).read_bytes()
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Replay current native-prefix failures with exact source-bound diagnostic flags'],cwd=r,check=True);print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip())
