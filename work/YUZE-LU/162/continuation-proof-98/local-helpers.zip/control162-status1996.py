from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-balanced-reset-composition-1888/upper-candidates/19950/route';d=dict(time=time.time(),whole_system_qualified=False)
for n in ['receipt.json','trial-index.json','native-prefix-proof.json']:
 f=p/n
 if f.exists():d[n]=json.loads(f.read_text())
for f in [p/'router.log']+sorted(p.glob('trial-*/router.log'))[:4]+sorted(p.glob('trial-*/*.log'))[:6]:
 if f.exists():
  with f.open('rb')as s:s.seek(max(0,f.stat().st_size-2000));d[str(f.relative_to(p))]=s.read().decode(errors='replace')
queue=b/'dynamic-06/node26'
d['route_children']=[str(f.relative_to(p))for f in p.glob('*')]
for f in queue.glob('*1995*'):
 if f.is_file():d[str(f)]=f.read_text(errors='replace')[-2500:]
for sub in ['logs','results']:
 for f in (queue/sub).glob('*1995*'):
  if f.is_file():d[str(f)]=f.read_text(errors='replace')[-2000:]
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40)
(Path(__file__).parent/'control162-status1996-latest.json').write_bytes(raw)
for k,v in json.loads(raw).items():print(k,json.dumps(v)[:3500])
