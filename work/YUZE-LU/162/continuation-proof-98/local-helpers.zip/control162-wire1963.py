from pathlib import Path
import sys,re,json,hashlib,collections,time
b=Path(__file__).parent;out=b/'control162-wire1963';assert not out.exists();out.mkdir();sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/block_v1'));from native_escape import records
p=json.loads((b/'control162-subset1915/placement.json').read_bytes());term=p['terminals'];rows=[];started=time.time();pattern=re.compile(r'\(\s*(-?[0-9]+|\*)\s+(-?[0-9]+|\*)(?:\s+(-?[0-9]+))?\s*\)')
for record in records(b/'control162-drc1949/snapshot.def'):
 name=record.split()[1];assert name in term;raw=record.split('+ ROUTED ',1)[1];length=0;segments=0;zero=0;vias=raw.count('BV1_via11');offgrid=0
 for chunk in re.split(r'\s+NEW\s+',raw):
  prev=None
  for m in pattern.finditer(chunk):
   xx,yy,ext=m.groups();x=prev[0]if xx=='*'else int(xx);y=prev[1]if yy=='*'else int(yy)
   if (x-190)%8000 or(y-140)%8000:offgrid+=1
   if prev is not None:assert x==prev[0]or y==prev[1];length+=abs(x-prev[0])+abs(y-prev[1]);segments+=1;zero+=int((x,y)==prev)
   prev=(x,y)
 pts=term[name];hpwl=(max(x for x,y in pts)-min(x for x,y in pts)+max(y for x,y in pts)-min(y for x,y in pts))*4
 rows.append(dict(net=name,hpwl_um=hpwl,route_segment_length_um=length/2000,segments=segments,zero_length_segments=zero,vias=vias,offgrid_points=offgrid,terminals=len(pts)))
assert len(rows)==11149
g=json.loads((b/'control162-math-data1907/physical-graph.json').read_bytes());groups=collections.defaultdict(lambda:dict(nets=0,hpwl_um=0,route_segment_length_um=0))
for row in rows:
 owner=g['connections'][row['net'][4:]]['driver']['instance'];a=groups[owner];a['nets']+=1;a['hpwl_um']+=row['hpwl_um'];a['route_segment_length_um']+=row['route_segment_length_um']
d=dict(diagnostic_only=True,whole_system_qualified=False,source_def_sha256=json.loads((b/'control162-drc1949/reception.json').read_bytes())['snapshot.def']['sha256'],nets=len(rows),hpwl_um=sum(v['hpwl_um']for v in rows),route_segment_length_um=sum(v['route_segment_length_um']for v in rows),seconds=time.time()-started,by_driver=sorted(groups.items(),key=lambda kv:-kv[1]['route_segment_length_um']),largest_detours=sorted(rows,key=lambda v:v['route_segment_length_um']-v['hpwl_um'],reverse=True)[:25],scope='Actual failed bounded19350 DEF canonical segment L1 lengths; duplicate/overlapping wire segments are counted and this is not unique conductive union or RC extraction. Actual HPWL all11149 nets includes unconstrained/TOP/PG. Full report already rejected for shorts/noncheckerboard via; no route accepted, no gates/source changed.')
(out/'receipt.json').write_text(json.dumps(d,indent=2));(out/'all-net-lengths.json').write_text(json.dumps(rows));print(json.dumps({k:v for k,v in d.items()if k not in ['by_driver','largest_detours']}));print(json.dumps(d['by_driver'][:8]));print(json.dumps(d['largest_detours'][:5]))
