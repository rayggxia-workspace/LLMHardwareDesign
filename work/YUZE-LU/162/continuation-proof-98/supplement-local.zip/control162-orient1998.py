from pathlib import Path
import json,sys,hashlib
b=Path(__file__).parent;out=b/'control162-oriented1998';assert not out.exists();out.mkdir()
sys.path.insert(0,str(b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'));from router_conflict_snapshot import inputs,inspect
h,nets,limits=inputs(b/'control162-receive1988/input.txt');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=b/'control162-joint1993/prefix.txt';changed=[]
with before.open()as f,(out/'prefix.txt').open('w',newline='\n')as z:
 header=f.readline();z.write(header)
 for _ in range(int(header)):
  line=f.readline();name,count=line.split();z.write(line);seen=set()
  for j in range(int(count)):
   line=f.readline();row=list(map(int,line.split()));points=[tuple(row[k:k+3])for k in range(1,len(row),3)]
   if j==0:assert points==[(*nets[name][0],0)]
   elif points[-1]not in seen:
    assert points[0]in seen;points.reverse();changed.append(name);line=str(len(points))+' '+' '.join(str(v)for p in points for v in p)+'\n'
   seen.update(points);z.write(line)
 assert not f.read().strip()
assert len(changed)==4
proof=inspect(out/'prefix.txt',{n:nets[n]for n in list(nets)[:h[6]]},h[0],h[1],limits);assert proof['conflict_nodes']==0 and proof['all_trees_flood_verified']and proof['all_wire_budgets_verified']
r=json.loads((b/'control162-joint1993/receipt.json').read_bytes());r.update(repaired_prefix_sha256=sha(out/'prefix.txt'),orientation_only=True,oriented_nets=changed,prior_prefix_sha256=sha(before),independent_prefix_proof=proof)
(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(passed=True,orientation_changed=changed,geometry_edges_unchanged=True,whole_system_qualified=False)))
s=(b/'control162-prepare1994.py').read_text(encoding='utf-8').replace('control162-joint1993','control162-oriented1998').replace('1994','1999').replace('19950','20000').replace('1995','2000')
# The base full-chain template remains the immutable original1970.
script=b/'control162-prepare1999.py';assert not script.exists();compile(s,'prepare1999','exec');script.write_text(s,encoding='utf-8')
