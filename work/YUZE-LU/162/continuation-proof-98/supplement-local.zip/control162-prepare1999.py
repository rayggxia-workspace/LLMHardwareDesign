from pathlib import Path
import json,hashlib,subprocess,shlex
b=Path(__file__).parent
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
data=remote+'/r256-current-prefix-data-1999'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=b/'control162-oriented1998/prefix.txt';receipt=b/'control162-oriented1998/receipt.json'
r=json.loads(receipt.read_text());assert r['passed'] and not r['whole_system_qualified'] and r['independent_prefix_proof']['conflict_nodes']==0
assert sha(p)==r['repaired_prefix_sha256']
original=json.loads((b/'control162-receive1988/reception.json').read_text())['files']['input.txt']
assert original['sha256']==r['input_sha256']
cfg=dict(prefix=data+'/prefix.txt',prefix_sha256=sha(p),input=original['path'],input_sha256=original['sha256'])
config=b/'control162-warm1999.json';assert not config.exists();config.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
s=(b/'control162-full1970-remote.py').read_text(encoding='utf-8').replace('19700','20000').replace('1970','2000')
needle="graph=root/'topology/boundary-graph.json';"
intro="""warm=b/'r256-current-prefix-data-1999/config.json';wc=json.loads(warm.read_text());wp=Path(wc['prefix']);wi=Path(wc['input']);wr=json.loads((warm.parent/'repair-receipt.json').read_text());assert set(wc)=={'prefix','prefix_sha256','input','input_sha256'}and sha(wp)==wc['prefix_sha256']==wr['repaired_prefix_sha256']and sha(wi)==wc['input_sha256']==wr['input_sha256']and wr['passed']and wr['independent_prefix_proof']['conflict_nodes']==0 and not wr['whole_system_qualified']
assert json.loads((root/'function-audit/receipt.json').read_text())['passed']and json.loads((root/'internal-program-traces/receipt.json').read_text())['passed']
"""
assert needle in s;s=s.replace(needle,intro+needle)
needle="a+=['--router','cpp'];";assert needle in s;s=s.replace(needle,"a+=['--router','cpp','--route-native-prefix-input',str(warm)];")
needle="'--route-native-prefix-input'not in a";assert needle in s;s=s.replace(needle,"a[a.index('--route-native-prefix-input')+1]==str(warm)")
s=s.replace("reg/'coarse-refine/receipt.json',oldpath]}","reg/'coarse-refine/receipt.json',oldpath,warm,wp,wi,warm.parent/'repair-receipt.json']}")
s=s.replace('freshnativeprefix no obsolete5380prefix inherited','actual19540nativeprefix joint4net repair1993 withall1229flood/wire/zerooccupancy independentlychecked andall24760foreignpinlandings checked; originalactualtrial14input body binding recheckedbyexistingwarmwrapper; no old5380prefix; flexiblewarmsearch muststillpassalloriginalgates')
s=s.replace('existingCPP comparison onexactactual19540placement only','existingCPP actual19540warmrepairedprefix search')
script=b/'control162-full2000-remote.py';assert not script.exists();compile(s,'full2000','exec');script.write_text(s,encoding='utf-8')
create="from pathlib import Path; p=Path("+repr(data)+"); assert not p.exists(); p.mkdir()"
subprocess.run(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(create)],check=True,timeout=30)
for local,name in [(p,'prefix.txt'),(receipt,'repair-receipt.json'),(config,'config.json'),(script,'queue-full2000.py')]:
 subprocess.run(['scp','-q',str(local),'yuzelu@10.129.166.172:'+data+'/'+name],check=True,timeout=40)
subprocess.run(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 '+shlex.quote(data+'/queue-full2000.py')],check=True,timeout=45)
print(json.dumps(dict(candidate=20000,config=cfg,full_chain_queued=True,whole_system_qualified=False)))
