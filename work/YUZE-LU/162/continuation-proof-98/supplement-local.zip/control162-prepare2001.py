from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-status1996.py').read_text(encoding='utf-8').replace('19950','20000').replace('1995','2000').replace('1996','2001')
s=s.replace("for k,v in json.loads(raw).items():print(k,json.dumps(v)[:3500])","for k,v in json.loads(raw).items():\n if k=='trial-index.json':v={a:c for a,c in v.items()if a!='records'}\n if k=='receipt.json':v={a:c for a,c in v.items()if a not in ['inputs','outputs']}\n if k=='route_children':v={'count':len(v)}\n print(k,json.dumps(v)[:2000])")
p=b/'control162-status2001.py';assert not p.exists();p.write_text(s,encoding='utf-8')
