from pathlib import Path
import subprocess,shlex,json,zipfile,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/continuation-proof-98';sha=lambda v:hashlib.sha256(v).hexdigest()
q=r'''from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');files={};sha=lambda v:hashlib.sha256(v).hexdigest()
for name in ['r256-current-prefix-data-1999','route-selection-102/sready2000-arbiter-fullchain','r256-balanced-reset-composition-1888/final-chain-binding-audit-2000']:
 for p in(b/name).rglob('*'):
  if p.is_file():files[str(p.relative_to(b))]=p.read_bytes()
root=b/'r256-balanced-reset-composition-1888'
for name in ['upper-candidates/19950/route/receipt.json','upper-candidates/19950/route/trial-index.json','upper-candidates/19950/route/trial-0/router.log','upper-candidates/20000/route/trial-0/output.txt.native-prefix.log','upper-candidates/20000/route/router-input.txt','acceptance-20000.json']:
 p=root/name;assert p.is_file(),name;files[str(p.relative_to(b))]=p.read_bytes()
assert 'seed native branch disconnected'in files[str((root/'upper-candidates/19950/route/trial-0/router.log').relative_to(b))].decode()
native=files[str((root/'upper-candidates/20000/route/trial-0/output.txt.native-prefix.log').relative_to(b))].decode();assert '"conflict_nodes":0'in native
out=b/'continuation-proof-98';p=out/'supplement.zip';assert not p.exists()
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED)as z:
 for n,v in sorted(files.items()):z.writestr(n,v)
idx=dict(time=time.time(),whole_system_qualified=False,files={n:dict(zip_entry=n,bytes=len(v),sha256=sha(v))for n,v in sorted(files.items())},archive=dict(path='supplement.zip',bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
(out/'supplement-index.json').write_text(json.dumps(idx,indent=2));print(json.dumps(dict(files=len(files),archive=idx['archive'])))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode())
for n in ['supplement.zip','supplement-index.json']:subprocess.run(['scp','-q','yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/continuation-proof-98/'+n,str(out/n)],check=True,timeout=40)
idx=json.loads((out/'supplement-index.json').read_bytes());assert sha((out/'supplement.zip').read_bytes())==idx['archive']['sha256']
with zipfile.ZipFile(out/'supplement.zip')as z:
 assert z.testzip()is None
 for v in idx['files'].values():a=z.read(v['zip_entry']);assert len(a)==v['bytes']and sha(a)==v['sha256']
files={}
for n in ['control162-orient1998.py','control162-prepare1999.py','control162-full2000-remote.py','control162-prepare2001.py','control162-status2001.py','control162-doc2002.py','control162-supplement2003.py','control162-status1996-latest.json','control162-status2001-latest.json']:
 files[n]=(b/n).read_bytes()
files['control162-oriented1998/receipt.json']=(b/'control162-oriented1998/receipt.json').read_bytes()
with zipfile.ZipFile(out/'supplement-local.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,v in files.items():z.writestr(n,v)
(out/'supplement-local-index.json').write_bytes(json.dumps(dict(files={n:dict(zip_entry=n,bytes=len(v),sha256=sha(v))for n,v in files.items()},archive=dict(path='supplement-local.zip',bytes=(out/'supplement-local.zip').stat().st_size,sha256=sha((out/'supplement-local.zip').read_bytes()))),indent=2).encode())
p=r/'work/YUZE-LU/162/continuation-checkpoint-98.md';s=p.read_text(encoding='utf-8').replace('在实际node24启动。','在实际node24启动。实际C++导入及关键阶段零冲突已通过，普通网络搜索已启动；它不是全网通过。');p.write_bytes(s.encode())
print('Actual failure and successful native import supplement verified')
