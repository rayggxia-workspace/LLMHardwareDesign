from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');queue=b/'dynamic-06/node26';s=json.loads((queue/'queue-state.json').read_text());d=dict(time=time.time(),job=s['job'],slots=s['slots'],active=s['active'],memory_admissions=s['memory_admissions'],cases=[])
for seed in range(20000,20900,100):
 p=b/'r256-balanced-reset-composition-1888/upper-candidates'/str(seed)/'route';row=dict(seed=seed)
 if(p/'receipt.json').exists():row['route_passed']=json.loads((p/'receipt.json').read_text())['passed']
 for n in ['trial-0']:
  f=p/n/'router.log'
  if not f.exists():continue
  with f.open('rb')as stream:stream.seek(max(0,f.stat().st_size-1000000));lines=stream.read().decode(errors='replace').splitlines()
  records=[]
  for line in lines:
   try:v=json.loads(line)
   except ValueError:continue
   if 'conflict_nodes'in v:records.append(v)
  row[n]=dict(age=time.time()-f.stat().st_mtime,last_completed_round=records[-1:]if records else[])
 d['cases'].append(row)
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(Path(__file__).parent/'control162-all2013-latest.json').write_bytes(raw);d=json.loads(raw);print(json.dumps(d)[:20000])
