from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,hashlib,time,re
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];defaults=None;forecast={};actual={};queues={}
for folder in ['dynamic-05/node2','dynamic-09/node3','dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-07/node7','dynamic-04/node25','dynamic-06/node26']:
 q=b/folder;s=json.loads((q/'queue-state.json').read_text());queues[folder]=dict(job=s['job'],slots=s['slots'],active=s['active'],memory_admissions=s['memory_admissions'])
for seed in range(20000,23400,100):
 tag=seed//10;record=b/('route-selection-102/sready'+str(tag)+'-arbiter-fullchain');tasks=json.loads((record/'tasks.json').read_text())['tasks'];assert len(tasks)==7
 audit=root/('final-chain-binding-audit-'+str(tag))/'receipt.json';assert json.loads(audit.read_text())['passed']
 spec=next(t['spec']for t in tasks if t['spec']['script']=='system_upper.py');a=spec['args'];d={}
 for flag in ['--seed','--route-heuristic-weight','--route-nonpreferred-cost','--route-ordinary-coarse','--route-ordinary-present-growth','--route-trials','--route-trial-attempts']:d[flag]=a[a.index(flag)+1]
 assert d['--seed']==str(seed)and d['--route-trials']=='16'and d['--route-trial-attempts']=='64'and d['--route-ordinary-present-growth']=='4'
 for t in tasks:
  forecast.setdefault(t['spec']['script'],set()).add(t['spec']['forecast_gib']);p=Path(t['path'])
  if seed==20500 and t['spec']['script']=='system_upper.py':p=b/'dynamic-09/node3/pending'/p.name
  assert p.is_file()and sha(p)==t['sha256']and t['spec']['source_root']==str(b/'source-1885')
  assert json.loads(p.read_text())==t['spec'];q=p.parent.parent;result=q/'results'/p.name
  if result.exists():
   rr=json.loads(result.read_text());assert not rr.get('rejected_before_admission'),str(result)
  if t['spec']['script']=='system_upper.py'and(q/'commands'/p.name).exists():
   cmd=json.loads((q/'commands'/p.name).read_text());assert cmd['spec_sha256']==t['sha256'];actual[str(seed)]=dict(queue=str(q.relative_to(b)),admission=cmd['admission'],source_manifest_sha256=cmd['source_manifest_sha256'])
 rows.append(dict(seed=seed,parameters=d,strict_binding_receipt_sha256=sha(audit)))
matrix={(int(r['parameters']['--route-heuristic-weight']),int(r['parameters']['--route-nonpreferred-cost']),int(r['parameters']['--route-ordinary-coarse']))for r in rows};wanted={(w,c,s)for w in [1,8,32]for c in [2,8,32]for s in [8,16,32]};assert wanted<=matrix and len(rows)==34
out=dict(passed=True,time=time.time(),whole_system_qualified=False,candidates=rows,complete_27_case_supported_matrix=True,forecasts={k:sorted(v)for k,v in forecast.items()},actual_admissions=actual,actual_queues=queues,scope='All34 strict sevenstage specifications SHA/source/parameter/data binding rechecked includingcanonical20500migration; existing6baseline256/cost8/stride16 plus256/cost2control and27case matrix. Futurephysicalgates notpassedbythisaudit. Originalforecasts andaggregate memoryadmission retained, node25max128 acceptsroute/geometry forecasts belowitscap; allSTA224onmodern256cap nodes.')
p=b/'route-selection-102/sready2017-supported-matrix-audit';assert not p.exists();p.mkdir();(p/'receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=45);(b/'control162-audit2017-receipt.json').write_bytes(raw);d=json.loads(raw);print(json.dumps({k:v for k,v in d.items()if k not in ['candidates','actual_admissions','actual_queues']}));print('admitted',len(d['actual_admissions']));print(json.dumps(d['actual_queues'])[:6000])
