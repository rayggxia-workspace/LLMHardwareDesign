from pathlib import Path
import subprocess,json,zipfile,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/continuation-proof-98';sha=lambda v:hashlib.sha256(v).hexdigest()
# Authenticated GitHub connector get_profile at refresh1994 returned YUZE-LU.
# The redundant gh identity query hung; only that exact helper process was stopped.
assert subprocess.check_output(['git','branch','--show-current'],cwd=r).decode().strip()=='task/162-programmable-control'
files=['.gitattributes','docs/STATUS.md','docs/CONTROL_V1.md','progress/YUZE-LU/STATUS.md','work/YUZE-LU/162/continuation-checkpoint-98.md','work/YUZE-LU/162/continuation-proof-98']
for n in files[:-1]:p=r/n;p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
for arc,idx in [('selected-originals.zip','index.json'),('local-helpers.zip','local-index.json'),('supplement.zip','supplement-index.json'),('supplement-local.zip','supplement-local-index.json')]:
 d=json.loads((out/idx).read_bytes());assert sha((out/arc).read_bytes())==d['archive']['sha256']
 with zipfile.ZipFile(out/arc)as z:
  assert z.testzip()is None
  for v in d['files'].values():a=z.read(v['zip_entry']);assert len(a)==v['bytes']and sha(a)==v['sha256']
subprocess.run(['python','scripts/check_project.py'],cwd=r,check=True);subprocess.run(['git','add','--',*files],cwd=r,check=True)
for raw in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).split(b'\0'):
 if raw:p=raw.decode();assert subprocess.check_output(['git','show',':'+p],cwd=r)==(r/p).read_bytes(),p
subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','commit','-m','Repair actual critical routing seed and verify current programmable task traces'],cwd=r,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip())
p=b/'control162-publish-exact.py';s=p.read_text(encoding='utf-8');assert "'1976','1983')"in s;s=s.replace("'1976','1983')","'1976','1983','2004')");p.write_text(s,encoding='utf-8')
