from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent;remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';template=(b/'control162-full2000-remote.py').read_text(encoding='utf-8');rows=[]
cases=[(2090,20900,256,2,16,'dynamic-05/node4'),(2100,21000,32,2,16,'dynamic-05/node4'),(2110,21100,8,2,16,'dynamic-03/node5'),(2120,21200,32,8,8,'dynamic-03/node5'),(2130,21300,32,8,32,'dynamic-08/node6'),(2140,21400,32,32,16,'dynamic-08/node6')]
for tag,seed,weight,cost,stride,folder in cases:
 s=template.replace('20000',str(seed)).replace('sready2000','sready'+str(tag)).replace('audit-2000','audit-'+str(tag));needle="k=a.index('--route-native-prefix-input');";assert needle in s
 assignments=''.join("a[a.index('"+flag+"')+1]='"+str(value)+"';"for flag,value in [('--route-heuristic-weight',weight),('--route-nonpreferred-cost',cost),('--route-ordinary-coarse',stride)])
 s=s.replace(needle,assignments+needle).replace("else'dynamic-06/node26'","else'"+folder+"'")
 needle="a[a.index('--router')+1]=='cpp'";assert needle in s;s=s.replace(needle,needle+''.join("and a[a.index('"+flag+"')+1]=='"+str(value)+"'"for flag,value in [('--route-heuristic-weight',weight),('--route-nonpreferred-cost',cost),('--route-ordinary-coarse',stride)]))
 s=s.replace('existingCPP actual19540warmrepairedprefix search','existingCPP actual19540warmrepairedprefix originalsupported weight'+str(weight)+' cost'+str(cost)+' coarse'+str(stride)+' search')
 p=b/('control162-full'+str(tag)+'-remote.py');assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8');target=remote+'/r256-current-prefix-data-1999/'+p.name
 subprocess.run(['scp','-q',str(p),'yuzelu@10.129.166.172:'+target],check=True,timeout=35);raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 '+shlex.quote(target)],timeout=35)
 rows.append(dict(weight=weight,cost=cost,stride=stride,queue=folder,actual=json.loads(raw)));print(raw.decode().strip(),flush=True)
(b/'control162-grid2014-receipt.json').write_text(json.dumps(dict(candidates=rows,whole_system_qualified=False,source_unchanged=True,scope='Originalsupportedsoftwaresearchparameters only: cost2 permitslessdirectionpenalty withoutchanginglegalbothdirectionM11/M12 geometry; cost32oppositecontrol, coarse8/32vs16. Sameactual19540placement/prefix1998/11149nets/budgets andall7stage gates; two16CPU jobsperexistingownednode4/5/6 subjectoriginal65GiBaggregateguard; no parent/foreign/R changes.'),indent=2))
