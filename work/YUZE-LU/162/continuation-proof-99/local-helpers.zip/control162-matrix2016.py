from pathlib import Path
import subprocess,shlex,json,itertools
b=Path(__file__).parent;remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';template=(b/'control162-full2000-remote.py').read_text(encoding='utf-8');rows=[]
existing={(32,8,16),(8,8,16),(1,8,16),(32,2,16),(8,2,16),(32,8,8),(32,8,32),(32,32,16)}
cases=[v for v in itertools.product([1,8,32],[2,8,32],[8,16,32])if v not in existing];assert len(cases)==19
folders=['dynamic-05/node2']*3+['dynamic-07/node7']*3+['dynamic-04/node25']*4+['dynamic-05/node4','dynamic-03/node5','dynamic-08/node6','dynamic-06/node26']+['dynamic-05/node2','dynamic-07/node7','dynamic-04/node25','dynamic-04/node25','dynamic-05/node2'];assert len(folders)==len(cases)
for i,((weight,cost,stride),folder)in enumerate(zip(cases,folders)):
 tag=2150+i*10;seed=tag*10;s=template.replace('20000',str(seed)).replace('sready2000','sready'+str(tag)).replace('audit-2000','audit-'+str(tag));needle="k=a.index('--route-native-prefix-input');";assert needle in s
 params=[('--route-heuristic-weight',weight),('--route-nonpreferred-cost',cost),('--route-ordinary-coarse',stride)]
 s=s.replace(needle,''.join("a[a.index('"+f+"')+1]='"+str(v)+"';"for f,v in params)+needle).replace("else'dynamic-06/node26'","else'"+folder+"'")
 needle="a[a.index('--router')+1]=='cpp'";assert needle in s;s=s.replace(needle,needle+''.join("and a[a.index('"+f+"')+1]=='"+str(v)+"'"for f,v in params))
 s=s.replace('existingCPP actual19540warmrepairedprefix search','existingCPP actual19540warmrepairedprefix bounded27case parameter matrix weight'+str(weight)+' cost'+str(cost)+' coarse'+str(stride))
 p=b/('control162-full'+str(tag)+'-remote.py');assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8');target=remote+'/r256-current-prefix-data-1999/'+p.name
 subprocess.run(['scp','-q',str(p),'yuzelu@10.129.166.172:'+target],check=True,timeout=35);raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 '+shlex.quote(target)],timeout=35)
 rows.append(dict(weight=weight,cost=cost,stride=stride,queue=folder,actual=json.loads(raw)));print(json.dumps(rows[-1]),flush=True)
 (b/'control162-matrix2016-progress.json').write_text(json.dumps(dict(rows=rows,whole_system_qualified=False),indent=2))
(b/'control162-matrix2016-receipt.json').write_text(json.dumps(dict(candidates=rows,whole_system_qualified=False,source_unchanged=True,complete27case_matrix_including_existing8=True,scope='Bounded27case originalsupportedparameters weight1/8/32 xdirectioncost2/8/32 xcoarsestride8/16/32. Existing8casesreused, only19missing combinations queued. Sameactual19540placement/prefix1998/11149nets/budgets andall7stage gates. Existing8ownedparents only, original16CPU slots/65GiBaggregateguard remains; memory/dependencylimitedworkstayspendingandrefillsdynamically. No newhardware/source/gates/parentcancel/foreign/R changes.'),indent=2))
