from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent;remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';template=(b/'control162-full2000-remote.py').read_text(encoding='utf-8');rows=[]
for tag,seed in [(2010,20100),(2020,20200),(2030,20300),(2040,20400),(2050,20500)]:
 s=template.replace('20000',str(seed)).replace('sready2000','sready'+str(tag)).replace('audit-2000','audit-'+str(tag))
 assert "seed="+str(seed)in s and '/r256-current-prefix-data-1999/'not in s # path uses Path concatenation
 s=s.replace('existingCPP actual19540warmrepairedprefix search','existingCPP actual19540warmrepairedprefix independent seed '+str(seed)+' search')
 p=b/('control162-full'+str(tag)+'-remote.py');assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8')
 target=remote+'/r256-current-prefix-data-1999/'+p.name
 subprocess.run(['scp','-q',str(p),'yuzelu@10.129.166.172:'+target],check=True,timeout=35)
 result=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 '+shlex.quote(target)],timeout=35)
 rows.append(json.loads(result));print(result.decode().strip(),flush=True)
(b/'control162-parallel2006-receipt.json').write_text(json.dumps(dict(candidates=rows,whole_system_qualified=False,source_unchanged=True,parameters_unchanged_except_seed=True,original_memory_guard=True,scope='Six independent16CPU candidate searches including20000 queued onactualnode24 c96, eachsixfinaldependentgatesunchanged; slots andoriginal65GiBaggregateguard decideactualconcurrency, completionrefillwithoutbatchbarrier. No othertaskchanges.'),indent=2))
