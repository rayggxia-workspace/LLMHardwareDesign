from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-six2007.py').read_text(encoding='utf-8').replace('range(20000,20600,100)','range(20000,20900,100)').replace("for n in ['trial-0','trial-1','trial-2']:","for n in ['trial-0']:").replace('control162-six2007-latest','control162-all2013-latest')
s=s.replace("print(json.dumps(d)[:11000])","print(json.dumps(d)[:20000])")
p=b/'control162-all2013.py';assert not p.exists();p.write_text(s,encoding='utf-8')
