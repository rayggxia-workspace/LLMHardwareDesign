from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-all2013.py').read_text(encoding='utf-8').replace('range(20000,20900,100)','range(20000,21500,100)').replace('control162-all2013-latest','control162-all2015-latest')
s=s.replace("last_completed_round=records[-1:]if records else[])","last_completed_round=records[-1:]if records else[],last_line=lines[-1][:120]if lines else'')")
s=s.replace("print(json.dumps(d)[:20000])","print(json.dumps(d)[:20000])")
p=b/'control162-all2015.py';assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8')
