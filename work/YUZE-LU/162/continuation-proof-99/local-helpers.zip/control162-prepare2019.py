from pathlib import Path
b=Path(__file__).parent;s=(b/'control162-all2015.py').read_text(encoding='utf-8').replace('range(20000,21500,100)','range(20000,23400,100)').replace('control162-all2015-latest','control162-all2019-latest')
old="print(json.dumps(d)[:20000])";assert old in s;s=s.replace(old,"\nsummary=[]\nfor row in d['cases']:\n v=row.get('trial-0',{});last=v.get('last_completed_round',[])\n summary.append(dict(seed=row['seed'],route_passed=row.get('route_passed'),last=last[-1]if last else None,tail=v.get('last_line')))\nprint(json.dumps(summary))")
p=b/'control162-all2019.py';assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8')
