from pathlib import Path
import subprocess,shlex,json
q=r'''from pathlib import Path
import json,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');root=b/'r256-balanced-reset-composition-1888';p=root/'upper-candidates/20000/route';d=dict(time=time.time(),whole_system_qualified=False,trials=[])
if(p/'receipt.json').exists():d['route_passed']=json.loads((p/'receipt.json').read_text())['passed']
for f in sorted(p.glob('trial-*/router.log'))[:16]:
 with f.open('rb')as s:s.seek(max(0,f.stat().st_size-4000000));lines=s.read().decode(errors='replace').splitlines()
 rows=[]
 for line in lines:
  try:v=json.loads(line)
  except ValueError:continue
  if 'routing_phase_event'not in v:rows.append(v)
 conflicts=[r for r in rows if 'conflict_nodes'in r]
 d['trials'].append(dict(trial=f.parent.name,bytes=f.stat().st_size,age=time.time()-f.stat().st_mtime,last=rows[-1:],last_conflict=conflicts[-1:]if conflicts else[],best_conflict=min((r['conflict_nodes']for r in conflicts),default=None)))
for n in ['function','function-audit','internal-program-traces']:
 f=root/n/'receipt.json';d[n]=json.loads(f.read_text())['passed']if f.exists()else None
print(json.dumps(d))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=35);(Path(__file__).parent/'control162-progress2005-latest.json').write_bytes(raw);d=json.loads(raw)
for row in d.pop('trials'):print(json.dumps(row))
print(json.dumps(d))
