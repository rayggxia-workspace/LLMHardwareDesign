from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent
q=r'''from pathlib import Path
import json,hashlib,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');record=b/'route-selection-102/sready2008-memory-refill';assert not record.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
task=next(t for t in json.loads((b/'route-selection-102/sready2050-arbiter-fullchain/tasks.json').read_text())['tasks']if t['spec']['script']=='system_upper.py');p=Path(task['path']);oldqueue=p.parent.parent;targetqueue=b/'dynamic-09/node3';target=targetqueue/'pending'/p.name
for n in [236,1885]:
 s=(b/('source-'+str(n))/'project/experiments/control_v1/dynamic_queue.py').read_text();assert 'try:raw=path.read_bytes()'in s and 'except FileNotFoundError:continue'in s
def state():return json.loads((oldqueue/'queue-state.json').read_text())
st=state();assert p.stem not in st['active']and p.stem not in st['finished']and not(oldqueue/'commands'/p.name).exists()and not target.exists()and sha(p)==task['sha256']
decision=next(r for r in st['memory_admissions']if r['name']==p.stem);assert not decision['admitted']and decision['available_bytes']<decision['required_bytes'];assert task['spec']['forecast_gib']==65
record.mkdir();archived=record/p.name;raw=p.read_bytes();p.rename(archived);moved_at=time.time()
# Allow an already-read iterator to finish before exposing a duplicate elsewhere.
for _ in range(20):
 st=state()
 if st['time']>moved_at+3:break
 time.sleep(1)
assert st['time']>moved_at+3
assert p.stem not in st['active']and p.stem not in st['finished']and not(oldqueue/'commands'/p.name).exists(),'Source admitted during migration; do not expose duplicate'
tmp=target.with_suffix('.tmp');tmp.write_bytes(raw);tmp.rename(target);assert sha(target)==task['sha256']
result=dict(passed=True,time=time.time(),whole_system_qualified=False,source_path=str(p),archived_original=str(archived),canonical_path=str(target),spec_sha256=task['sha256'],spec=task['spec'],original_memory_denial=decision,source_controller_post_move_time=st['time'],scope='Onlyneveradmitted20500 moves fromactualnode24 toexistingidleownednode3 because originalsix65GiBaggregate requirement484GiB exceedsactualavailable. Originalspec/source/args/output/65GiB/finalgates byteexact; all8parents andotherjobs untouched. Waitednewsourcecontrollercycle afterrename andverifiednoactualsourcecommand/admission beforetargetexposure.')
(record/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
'''
raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40);(b/'control162-relocate2008-receipt.json').write_bytes(raw);print(raw.decode()[:1800])
