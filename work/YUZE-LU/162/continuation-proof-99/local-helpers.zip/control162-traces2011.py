from pathlib import Path
import subprocess,shlex,json,zipfile,hashlib
b=Path(__file__).parent;r=b/'LLMHardwareDesign-worktrees/issue-162-control';out=r/'work/YUZE-LU/162/program-trace-current1888';assert not out.exists()
q=r'''from pathlib import Path
import json,hashlib,zipfile,time
b=Path('/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162');p=b/'r256-balanced-reset-composition-1888/internal-program-traces';r=json.loads((p/'receipt.json').read_text());assert r['passed']and r['stage']=='actual-final-cell-internal-program-trace-only';out=b/'program-trace-current1888';assert not out.exists();out.mkdir();sha=lambda v:hashlib.sha256(v).hexdigest();files={}
for name,want in r['outputs'].items():
 if name.endswith(('.json','.jsonl','.cpp')):
  raw=(p/name).read_bytes();assert sha(raw)==want;files[name]=raw
files['receipt.json']=(p/'receipt.json').read_bytes();graph=b/'r256-balanced-reset-composition-1888/topology/boundary-graph.json';physical=b/'r256-balanced-reset-composition-1888/selected/physical.json';functions=b/'r256-balanced-reset-composition-1888/selected/functions.json'
for f in [graph,physical,functions]:assert r['inputs'][str(f)]==sha(f.read_bytes())
with zipfile.ZipFile(out/'traces.zip','w',zipfile.ZIP_DEFLATED)as z:
 for n,v in sorted(files.items()):z.writestr(n,v)
idx=dict(passed=True,time=time.time(),whole_system_qualified=False,source_commit='8d55501a05dc008781e00efa7655893650a59f6b',source_root=str(b/'source-1885'),actual_graph=str(graph),actual_graph_sha256=sha(graph.read_bytes()),actual_physical_sha256=sha(physical.read_bytes()),actual_functions_sha256=sha(functions.read_bytes()),files={n:dict(zip_entry=n,remote_path=str(p/n),bytes=len(v),sha256=sha(v))for n,v in sorted(files.items())},archive=dict(path='traces.zip',bytes=(out/'traces.zip').stat().st_size,sha256=sha((out/'traces.zip').read_bytes())),scope='Complete actualthreeinitialization internalC/eightqueue/adapter completion observations plus externalAXI payload/host plan events, original8numericalprograms andgoldenchecks. Notpercyclewaveform orphysicalRCqualification.')
(out/'index.json').write_text(json.dumps(idx,indent=2));print(json.dumps(dict(files=len(files),archive=idx['archive'])))
'''
print(subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 -c '+shlex.quote(q)],timeout=40).decode());out.mkdir();a=r/'.gitattributes';a.write_bytes(a.read_bytes()+b'\nwork/YUZE-LU/162/program-trace-current1888/** -text\n')
for n in ['index.json','traces.zip']:subprocess.run(['scp','-q','yuzelu@10.129.166.172:/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/program-trace-current1888/'+n,str(out/n)],check=True,timeout=40)
sha=lambda v:hashlib.sha256(v).hexdigest();d=json.loads((out/'index.json').read_bytes());assert sha((out/'traces.zip').read_bytes())==d['archive']['sha256']
with zipfile.ZipFile(out/'traces.zip')as z:
 assert z.testzip()is None
 for v in d['files'].values():raw=z.read(v['zip_entry']);assert len(raw)==v['bytes']and sha(raw)==v['sha256']
(out/'reception.json').write_bytes(json.dumps(dict(passed=True,entries=len(d['files']),all_member_crc_bytes_sha256=True,whole_system_qualified=False),indent=2).encode());print('Complete current actual traces received and verified')
