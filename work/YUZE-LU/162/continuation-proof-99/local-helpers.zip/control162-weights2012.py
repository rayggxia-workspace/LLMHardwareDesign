from pathlib import Path
import subprocess,shlex,json
b=Path(__file__).parent;remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162';template=(b/'control162-full2000-remote.py').read_text(encoding='utf-8');rows=[]
for tag,seed,weight in [(2060,20600,32),(2070,20700,8),(2080,20800,1)]:
 s=template.replace('20000',str(seed)).replace('sready2000','sready'+str(tag)).replace('audit-2000','audit-'+str(tag))
 needle="k=a.index('--route-native-prefix-input');";assert needle in s
 s=s.replace(needle,"a[a.index('--route-heuristic-weight')+1]='"+str(weight)+"';"+needle)
 s=s.replace("else'dynamic-06/node26'","else'dynamic-09/node3'")
 needle="a[a.index('--router')+1]=='cpp'";assert needle in s;s=s.replace(needle,needle+"and a[a.index('--route-heuristic-weight')+1]=='"+str(weight)+"'")
 s=s.replace('existingCPP actual19540warmrepairedprefix search','existingCPP actual19540warmrepairedprefix originalsupportedweight'+str(weight)+' independentseed search')
 p=b/('control162-full'+str(tag)+'-remote.py');assert not p.exists();compile(s,p.name,'exec');p.write_text(s,encoding='utf-8')
 target=remote+'/r256-current-prefix-data-1999/'+p.name;subprocess.run(['scp','-q',str(p),'yuzelu@10.129.166.172:'+target],check=True,timeout=35)
 raw=subprocess.check_output(['ssh','-o','ConnectTimeout=10','yuzelu@10.129.166.172','python3 '+shlex.quote(target)],timeout=35);rows.append(dict(weight=weight,actual=json.loads(raw)));print(raw.decode().strip(),flush=True)
(b/'control162-weights2012-receipt.json').write_text(json.dumps(dict(candidates=rows,whole_system_qualified=False,source_unchanged=True,scope='Existingoriginalsupportedheuristicweights32/8/1 comparison, actualsame19540placement/prefix1998/11149nets/originalallbudgets, full7stage each. Four16CPU searchesincluding20500 intendedonowned64CPU node3, original65GiBaggregate admissionunchanged. No otherjobs/parentscancelled.'),indent=2))
