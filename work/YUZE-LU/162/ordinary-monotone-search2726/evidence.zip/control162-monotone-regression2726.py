from pathlib import Path
import hashlib
import json
import subprocess
import sys

b = Path.cwd()
work = b / 'LLMHardwareDesign-worktrees/issue-162-control'
code = work / 'project/experiments/control_v1'
out = Path('control162-monotone-regression2726')
out.mkdir()
host = 'yuzelu@10.129.166.172'
root = '/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162/r256-ordinary-refresh-regression-20920/coarse-refine'
source = 'project/experiments/control_v1/tree_router.cpp'
baseline = out / 'baseline.cpp'
baseline.write_bytes(subprocess.check_output(['git','-C',str(work),'show','HEAD:'+source],timeout=20))
for p, name in ((baseline,'baseline'),(work/source,'candidate')):
    subprocess.run(['g++','-O3','-std=c++17','-DNOMINMAX','-I',str(code),str(p),'-o',str(out/(name+'.exe'))],check=True,timeout=35)
sys.path.insert(0,str(code))
from global_snapshot_analysis import inputs
from router_conflict_snapshot import inspect

def run(name, executable, inp, flags):
    p=out/(name+'.route')
    proc=subprocess.run([str(out/(executable+'.exe')),str(inp),str(p),*flags],capture_output=True,timeout=90)
    (out/(name+'.log')).write_bytes(proc.stdout+proc.stderr)
    rows=[json.loads(l)for l in proc.stdout.splitlines()if l.startswith(b'{')]
    return proc.returncode, p, rows

commands=['--critical-first','--ordinary-zero-pattern','--weighted-settle-once',
 '--weighted-bidirectional','--ordinary-endpoint-escape','--ordinary-zero-maze=16384',
 '--native-prefix-first','--pin-access=none','--native-prefix-flexible','--ordinary-coarse=8',
 '--ordinary-coarse-access','--ordinary-coarse-static','--ordinary-coarse-multicast',
 '--ordinary-coarse-zero','--ordinary-coarse-rounds=16','--ordinary-coarse-refine','--ordinary-present-growth=4']
records=[]
for label in ('guided-cost-2-seed-971','guided-cost-8-seed-973','guided-cost-32-seed-975',
              'dense-guided-cost-2-seed-1300','pressure-guided-cost-2-seed-1302','pressure-guided-cost-8-seed-1303'):
    d=out/label;d.mkdir()
    remote=root+'/'+label
    prev=Path('control162-monotone-regression2724')/label
    if (prev/'router-input.txt').exists() and (prev/'router-output.txt.native-prefix-paths.txt').exists():
        for f in ('router-input.txt','router-output.txt.native-prefix-paths.txt'):(d/f).write_bytes((prev/f).read_bytes())
    else:
        subprocess.run(['scp','-q',host+':'+remote+'/router-input.txt',host+':'+root+'/unchanged-default/router-output.txt.native-prefix-paths.txt',str(d)],check=True,timeout=22)
    inp=d/'router-input.txt';native=d/'router-output.txt.native-prefix-paths.txt'
    h,nets,limits=inputs(inp)
    flags=[*commands,'--native-prefix-input='+str(native)]
    a,p,x=run(label+'-base','baseline',inp,flags)
    c,q,y=run(label+'-off','candidate',inp,flags)
    assert a==c and x==y and p.is_file()==q.is_file()
    if p.exists():assert p.read_bytes()==q.read_bytes()
    np=p.with_suffix('.route.native-prefix-paths.txt'); nq=q.with_suffix('.route.native-prefix-paths.txt')
    assert np.exists()==nq.exists() and (not np.exists() or np.read_bytes()==nq.read_bytes())
    g,t,z=run(label+'-on','candidate',inp,[*flags,'--ordinary-monotone-after=8'])
    key=lambda rows:[e for e in rows if 'conflict_nodes'in e]
    assert [r for r in key(y) if r['round']<8]==[r for r in key(z) if r['round']<8]
    nt=t.with_suffix('.route.native-prefix-paths.txt')
    assert nt.exists()==nq.exists() and (not nt.exists() or nt.read_bytes()==nq.read_bytes())
    if c==0: assert g==0, ('guard regressed a formerly passing fixture', label)
    if g==0:
        proof=inspect(t,nets,*h[:2],limits)
        assert proof['conflict_nodes']==0 and proof['all_trees_flood_verified'] and proof['all_wire_budgets_verified']
    else:assert not t.exists()
    trace=[r for r in z if 'ordinary_monotone_active'in r]
    assert all(e['ordinary_monotone_active']==(e['round']>=8 and (e['round']-8)%4!=3 and e['ordinary_monotone_previous_conflicts']>max(len(nets),2*(h[0]-8)*(h[1]-8)//100)) for e in trace)
    rec=dict(fixture=label,default_exact=True,active_rounds=sum(r['ordinary_monotone_active']for r in trace),
             restored=sum(r['ordinary_monotone_restored']for r in trace),improved=sum(r['ordinary_monotone_improved']for r in trace),
             default_rc=c,guard_rc=g,ordinary_before_eight_unchanged=True,native_exact=True,
             original_best=min((r['conflict_nodes']for r in key(y)),default=None),
             guarded_best=min((r['conflict_nodes']for r in key(z)),default=None),
             source_input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),native_sha256=hashlib.sha256(native.read_bytes()).hexdigest())
    records.append(rec)
    print(rec,flush=True)
assert sum(r['restored'] for r in records)>0 and sum(r['improved'] for r in records)>0
for label,flags,msg in (
 ('duplicate',[*flags,'--ordinary-monotone-after=8','--ordinary-monotone-after=16'],b'duplicate ordinary monotone option'),
 ('no-growth',[f for f in flags if f!='--ordinary-present-growth=4']+['--ordinary-monotone-after=8'],b'ordinary monotone refinement requires flexible guided growth'),
):
    ret,p,_=run(label,'candidate',inp,flags)
    assert ret and not p.exists() and msg in (out/(label+'.log')).read_bytes()
receipt={'passed':True,'whole_system_qualified':False,'regression_only':True,'records':records,
         'source_sha256':hashlib.sha256((work/source).read_bytes()).hexdigest(),
         'baseline_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'negative_options':2}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
