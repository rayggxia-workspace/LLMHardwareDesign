from pathlib import Path
import hashlib,json
b=Path(__file__).parent;inp=b/'control162-endpoint2088/input.txt';pref=b/'control162-oriented1998/prefix.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(inp)=='48310e605f2d99279593be50529f24236d46239bdcbc59ce725bdac04f1783e0'
assert sha(pref)=='1e5577486391d8cc6a9e80b6be2434b5702652651396a191312abc07fd511371'
lines=inp.read_text().splitlines();nx,ny,count=map(int,lines[0].split()[:3]);plane=nx*ny;locked=1229
def vid(p):x,y,l=p;return x+nx*y+plane*l
lands={};nets=[]
for n,ln in enumerate(lines[1:]):
 a=ln.split();ps=[(int(a[i]),int(a[i+1]),0)for i in range(2,len(a)-1,2)]
 for p in ps:assert vid(p)not in lands;lands[vid(p)]=n
 nets.append((a[0],ps))
base=bytearray(2*plane)
with pref.open()as f:
 assert int(f.readline())==locked
 for n,(name,ps)in enumerate(nets[:locked]):
  a=f.readline().split();assert a[0]==name
  for _ in range(int(a[1])):
   a=list(map(int,f.readline().split()));assert len(a)==1+a[0]*3
   for p in zip(a[1::3],a[2::3],a[3::3]):base[vid(p)]=1
assert sum(base)==109862 and len(lands)==24760
def path(pts):
 yield pts[0]
 for p,q in zip(pts,pts[1:]):
  d=[q[i]-p[i]for i in range(3)];axis=[i for i in range(3)if d[i]]
  if not axis:continue
  assert len(axis)==1
  i=axis[0]
  if i==2:assert abs(d[i])==1 and (p[0]+p[1])%2==0
  for j in range(1,abs(d[i])+1):yield tuple(p[k]+(j*(1 if d[i]>0 else -1)if k==i else 0)for k in range(3))
cases=[]
for f in sorted(b.glob('control162-vhv243[45]-*.txt')):
 occ=base[:];seen=set();wire=via=0
 for line in f.read_text().splitlines():
  a=list(map(int,line.split()));n=a[0];assert n>=locked and n not in seen;seen.add(n);p,q=nets[n][1];x,y,_=p;u,v,_=q
  if len(a)==5:
   _,c,d,e,k=a
   pts=[p,q]if k==0 else[p,(x,d,0),(c,d,0),(c,d,1),(c,e,1),(c,e,0),(u,e,0),q]
  else:
   _,c,a1,a2,a3,b1,b2,b3=a
   pts=[p,(a1,a2,0),(a1,a2,1),(a1,a3,1),(a1,a3,0),(c,a3,0),(c,a3,1),(c,b3,1),(c,b3,0),(b1,b3,0),(b1,b3,1),(b1,b2,1),(b1,b2,0),q]
  now=list(path(pts));assert now[0]==p and now[-1]==q
  for i in range(len(now)-1):
   if now[i][2]==now[i+1][2]:wire+=1
   else:via+=1
  for pt in now:
   xx,yy,ll=pt;v=vid(pt);assert 4<=xx<nx-4 and 4<=yy<ny-4 and ll in [0,1]
   assert not occ[v] and (ll or lands.get(v,n)==n),(f.name,n,pt)
   occ[v]=1
 cases.append(dict(file=f.name,sha256=sha(f),routes=len(seen),unit_wires=wire,valid_vias=via))
r=dict(passed=True,whole_system_qualified=False,route_qualified=False,cases=cases,inputs={str(p):sha(p)for p in [inp,pref,Path(__file__)]},scope='Independent unit-grid flood-by-path witnesses on subset of ordinary 2-pin nets only. All true M11 landings and exact native prefix remain; each witness owns legal checkerboard vias and has no overlap with any other witness/native/foreign terminal. Not a full route, not generated mask geometry, no RC or performance qualification.')
out=Path(__file__).with_suffix('.json');assert not out.exists();out.write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(cases))
