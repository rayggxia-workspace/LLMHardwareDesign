from pathlib import Path
import subprocess,zipfile,json,hashlib,sys
p=Path(__file__).parent;r=p/'control162-seed2442';w=p/'LLMHardwareDesign-worktrees/issue-162-control';o=r/'actual-small-fixture';assert not o.exists();o.mkdir()
z=zipfile.ZipFile(w/'work/YUZE-LU/162/continuation-proof-103/selected-originals.zip')
cfg=json.loads(z.read('config21130.json'));host='yuzelu@10.129.166.172'
native=json.loads(subprocess.check_output(['ssh',host,'cat '+cfg['fixture_manifest']],timeout=20))
for k in ['prefix','input']:
 dest=o/(k+'.txt');subprocess.run(['scp','-q',host+':'+native[k],str(dest)],check=True,timeout=25);native[k]=str(dest)
(o/'native-config.json').write_text(json.dumps(native));sys.path[:0]=[str(r),str(w/'project/experiments/control_v1')]
from tree_router_cpp import verify_ordinary_seed
from router_conflict_snapshot import inputs
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(native[k])==native[k+'_sha256']for k in ['prefix','input'])
h,tm,lm=inputs(native['input']);locked=list(tm)[:h[6]]
prefix='r256-ordinary-refresh-regression-21130/coarse-refine/'
oldpaths=z.read(prefix+'guided-cost-2-seed-972/router-output.txt').decode().splitlines(keepends=True)
assert int(oldpaths[0])==len(tm)
paths=o/'ordinary.txt';c=o/'ordinary-config.json';lines=[];i=1
for n,ps in tm.items():
 name,k=oldpaths[i].split();assert n==name;k=int(k)
 record=''.join(oldpaths[i:i+k+1]);i+=k+1
 if n in locked or len(ps)!=2 or k!=2:continue
 next=lines+[record];paths.write_text(str(len(next))+'\n'+''.join(next))
 c.write_text(json.dumps(dict(paths=str(paths),paths_sha256=sha(paths),input_sha256=native['input_sha256'],native_prefix_sha256=native['prefix_sha256'])))
 try:proof=verify_ordinary_seed(c,native,tm,40,40,locked,lm)
 except AssertionError:continue
 lines=next
 if len(lines)==5:break
assert len(lines)==5
print(json.dumps(proof))
