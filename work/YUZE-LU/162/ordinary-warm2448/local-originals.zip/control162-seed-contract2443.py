from pathlib import Path
import hashlib,json,subprocess,concurrent.futures,os
b=Path(__file__).parent;r=b/'control162-seed2442';o=r/'small-contract';assert not o.exists();o.mkdir()
reference=b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1/tree_router.cpp'
subprocess.run(['g++','-O3','-std=c++17',str(reference),'-o',str(r/'baseline.exe')],check=True,timeout=60)
def row(points):return str(len(points))+' '+' '.join(str(k)for p in points for k in p)+'\n'
def net(n,ps):return n+' 2\n'+row([ps[-1]])+row(ps)
native=[(x,4,0)for x in range(10,4,-1)]
(o/'native.txt').write_text('1\n'+net('N',native))
real=[(x,12,0)for x in range(22,5,-1)]
paths={'good':'1\n'+net('X',real),'wrong_order':'2\n'+net('Z',[(x,24,0)for x in range(30,5,-1)])+net('X',real),'dup':'2\n'+net('X',real)*2,'wrong_sink':'1\n'+net('X',[(x,12,0)for x in range(21,5,-1)]),'edge':'1\n'+net('X',[real[0],*real[2:]]),'trailing':'1\n'+net('X',real)+'Oops\n','foreign':'1\n'+net('X',[(22,12,0),(22,13,0),(22,14,0),*( (x,14,0)for x in range(21,5,-1)),(6,13,0),(6,12,0)]),'bad_via':'1\n'+net('X',[(22,12,0),(21,12,0),(21,12,1),(21,12,0),*real[2:]]),'native_name':'1\n'+net('N',native)}
for n,p in paths.items():(o/(n+'.txt')).write_text(p)
flags=['--native-prefix-first','--native-prefix-flexible','--pin-access=none','--native-prefix-input='+str(o/'native.txt')]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def test(case):
 name,seed,extra,expected=case;f=o/name;f.mkdir();i=f/'input.txt'
 i.write_text(f'40 40 4 {seed} 80 1 1 1 1 1 1 0 0 1 0 2 1\nN 2 5 4 10 4 5\nX 2 6 12 22 12 -1\nY 2 6 14 22 14 -1\nZ 2 6 24 30 24 -1\n')
 last='';records={}
 for kind in (['baseline','router'] if name.startswith('default') else ['router']):
  of=f/(kind+'.paths');command=[str(r/(kind+'.exe')),str(i),str(of),*flags,*extra]
  result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20);l=result.stdout;last=l.decode().splitlines()[-1]
  (f/(kind+'.log')).write_bytes(l)
  assert result.returncode==expected and of.exists()==(expected==0),(name,kind,last)
  if name.startswith('valid'):
   rows=[json.loads(x)for x in l.decode().splitlines()if 'ordinary_seed_loaded'in x]
   assert rows==[dict(ordinary_seed_loaded=True,ordinary_seed_nets=1,ordinary_seed_vertices=17,ordinary_seed_frozen=False)]
  elif name.startswith('reject'):assert 'ordinary seed' in last
  if not expected:
   records[kind]={v:sha(p)for v,p in [('out',of),('log',f/(kind+'.log')),('native',Path(str(of)+'.native-prefix-paths.txt')),('native_log',Path(str(of)+'.native-prefix.log'))]}
 if len(records)>1:assert records['baseline']==records['router']
 return dict(name=name,code=expected,records=records,last=last)
def option(n):return '--ordinary-seed-input='+str(o/(n+'.txt'))
cases=[('default-'+str(i),i,[],0)for i in range(18)]
cases+=[('valid-'+str(i),i,[option('good')],0)for i in range(8)]
cases += [('reject-'+n,87,[option(n)],1)for n in paths if n!='good']
cases += [('reject-duplicate-flag',87,[option('good'),option('good')],1)]
with concurrent.futures.ThreadPoolExecutor(8)as p:rows=list(p.map(test,cases))
res=dict(passed=True,whole_system_qualified=False,case_count=len(rows),disabled_byte_exact=18,accepted_seed=8,rows=rows,baseline_source_sha256=sha(reference),new_source_sha256=sha(r/'tree_router.cpp'))
(o/'receipt.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items()if k!='rows'}))
