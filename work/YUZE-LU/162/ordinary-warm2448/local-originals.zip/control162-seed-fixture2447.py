from pathlib import Path
import json,subprocess,sys,concurrent.futures
b=Path(__file__).parent;r=b/'control162-seed2442';o=r/'actual-small-fixture';w=b/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1';sys.path.insert(0,str(w))
from router_conflict_snapshot import inputs,inspect
h,nets,limits=inputs(o/'input.txt');data=(o/'input.txt').read_bytes().split(b'\n',1)[1]
flags=['--critical-first','--weighted-bidirectional','--ordinary-zero-pattern','--weighted-settle-once','--ordinary-coarse-refine','--native-prefix-first','--native-prefix-flexible','--pin-access=none','--ordinary-coarse=16','--ordinary-coarse-access','--ordinary-coarse-rounds=16','--ordinary-coarse-static','--ordinary-coarse-multicast','--ordinary-coarse-zero','--native-prefix-input='+str(o/'prefix.txt'),'--ordinary-seed-input='+str(o/'ordinary.txt')]
def test(a):
 c,s=a;f=o/f'cost{c}-seed{s}';f.mkdir();i=f/'input.txt';z=f/'out.txt';hh=[40,40,len(nets),s,80,256,h[6],1,1,1,1,0,0,1,1,c,1];i.write_bytes((' '.join(map(str,hh))+'\n').encode()+data)
 p=subprocess.run([str(r/'router.exe'),str(i),str(z),*flags],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
 (f/'router.log').write_bytes(p.stdout)
 rows=[json.loads(x)for x in p.stdout.decode().splitlines()if 'ordinary_seed_'in x]
 assert rows[0]['ordinary_seed_nets']==5 and rows[1]['ordinary_seed_round_skipped']==5
 if z.exists():assert inspect(z,nets,40,40,limits)['conflict_nodes']==0
 return dict(cost=c,seed=s,pass_full_small=z.exists(),rerouted=sum(x.get('ordinary_seed_round_rerouted',0)for x in rows))
with concurrent.futures.ThreadPoolExecutor(8)as x:cases=list(x.map(test,[(c,s)for c in [2,8]for s in range(971,979)]))
assert any(x['rerouted']for x in cases)and all(any(x['cost']==c and x['pass_full_small']for x in cases)for c in [2,8])
(o/'local-actual-regression.json').write_text(json.dumps(cases,indent=2));print(json.dumps(cases))
