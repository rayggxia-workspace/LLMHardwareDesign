from pathlib import Path
from bisect import bisect_left,bisect_right
import hashlib,json,collections,time
b=Path(__file__).parent;inp=b/'control162-endpoint2088/input.txt';pref=b/'control162-oriented1998/prefix.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(pref)=='1e5577486391d8cc6a9e80b6be2434b5702652651396a191312abc07fd511371'
assert sha(inp)=='48310e605f2d99279593be50529f24236d46239bdcbc59ce725bdac04f1783e0'
raw=inp.read_text().splitlines();nx,ny,num=map(int,raw[0].split()[:3]);lock=int(raw[0].split()[6]);assert(nx,ny,num,lock)==(3070,3252,11149,1229)
nets=[]
for line in raw[1:]:
 s=line.split();k=int(s[1]);nets.append((s[0],[tuple(map(int,s[2+2*i:4+2*i]))for i in range(k)]))
blocks={0:[set()for _ in range(ny)],1:[set()for _ in range(nx)]}
for n,ps in nets:
 for x,y in ps:blocks[0][y].add(x)
with pref.open()as f:
 assert int(f.readline())==lock
 for name,ends in nets[:lock]:
  n,k=f.readline().split();assert n==name
  for _ in range(int(k)):
   a=list(map(int,f.readline().split()));assert len(a)==3*a[0]+1
   for x,y,l in zip(a[1::3],a[2::3],a[3::3]):blocks[l][x if l else y].add(y if l else x)
 assert not f.read().strip()
blocks={l:[sorted(s)for s in blocks[l]]for l in (0,1)}
pair=[(n,*p)for n,p in nets[lock:]if len(p)==2]; nonpair=len(nets)-lock-len(pair)
def solve(mode,order):
 assigned={0:[[]for _ in range(ny)],1:[[]for _ in range(nx)]};details=[];miss=[];checks=0
 def options(n,a,c,l):
  if l:x1,x2=a[1],c[1];y1,y2=a[0],c[0];limit=nx
  else:x1,x2=a[0],c[0];y1,y2=a[1],c[1];limit=ny
  if x1==x2:return
  lo,hi=max(4,min(x1,x2)-1),min((ny if l else nx)-5,max(x1,x2)+1)
  mid=(y1+y2)//2
  for step in range(limit):
   for t in ([mid]if not step else [mid-step,mid+step]):
    if 4<=t<limit-4:yield t,lo,hi,abs(t-y1)+abs(t-y2)
 def allocate(n,a,c,l):
  nonlocal checks
  for t,lo,hi,d in options(n,a,c,l):
   checks+=1;forbid=blocks[l][t];j=bisect_left(forbid,lo)
   if j<len(forbid)and forbid[j]<=hi:continue
   A=assigned[l][t];j=bisect_left(A,(lo,-1))
   if(j and A[j-1][1]>=lo)or(j<len(A)and A[j][0]<=hi):continue
   A.insert(j,(lo,hi));details.append((n,l,t,lo,hi,d));return True
  return False
 def key(r):
  n,a,c=r;dx,dy=abs(a[0]-c[0]),abs(a[1]-c[1])
  if order=='long':return -max(dx,dy),n
  return min(a[1],c[1]) if mode==1 else min(a[0],c[0]),n
 for n,a,c in sorted(pair,key=key):
  pref=1 if abs(a[1]-c[1])>=abs(a[0]-c[0])else 0
  layers=[mode]if mode in (0,1)else[pref,1-pref]
  if not any(allocate(n,a,c,l)for l in layers):miss.append(n)
 seen=set()
 for n,l,t,lo,hi,d in details:
  assert n not in seen and bisect_left(blocks[l][t],lo)==bisect_right(blocks[l][t],hi);seen.add(n)
 for l in (0,1):
  for track in assigned[l]:assert all(a[1]<c[0]for a,c in zip(track,track[1:]))
 return dict(mode=mode,order=order,assigned=len(details),missing=len(miss),layer_counts=dict(collections.Counter(d[1]+11 for d in details)),checked_candidates=checks,trunk_grid_edges=sum(x[4]-x[3]for x in details),stub_displacement_grid=sum(x[5]for x in details),max_stub_displacement_grid=max(x[5]for x in details),first_missing=miss[:20])
cases=[solve(l,o)for l in (0,1,2)for o in ('long','sweep')]
r=dict(passed=True,whole_system_qualified=False,route_qualified=False,ordinary_pairs=len(pair),ordinary_multiterminal_or_single=nonpair,cases=cases,inputs={str(p):sha(p)for p in [inp,pref,Path(__file__)]},scope='Trunk-only feasibility diagnostic. Assign distinct in-layer unit-grid intervals per actual ordinary two-pin net, both axes/long-first/sweep/mixed, retaining all actual M11 landings and native warm tree occupancy as obstacles. Strictly verifies complete pairwise disjoint selected trunks and native/pin disjointness. Does not build any stub/via, join endpoints, place multicast, satisfy RC, or qualify physical routing.')
out=Path(__file__).with_suffix('.json');assert not out.exists();out.write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r)[:4300])
