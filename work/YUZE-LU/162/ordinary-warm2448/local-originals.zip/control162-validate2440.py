from pathlib import Path
import hashlib,json
b=Path(__file__).parent;inp=b/'control162-endpoint2088/input.txt';pref=b/'control162-oriented1998/prefix.txt'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(inp)=='48310e605f2d99279593be50529f24236d46239bdcbc59ce725bdac04f1783e0'
assert sha(pref)=='1e5577486391d8cc6a9e80b6be2434b5702652651396a191312abc07fd511371'
lines=inp.read_text().splitlines();nx,ny,count=map(int,lines[0].split()[:3]);plane=nx*ny;locked=1229
def vid(p):x,y,l=p;return x+nx*y+plane*l
lands={};nets=[]
for n,ln in enumerate(lines[1:]):
 a=ln.split();ps=[(int(a[i]),int(a[i+1]),0)for i in range(2,len(a)-1,2)]
 for p in ps:assert vid(p)not in lands;lands[vid(p)]=n
 nets.append((a[0],ps))
base=bytearray(2*plane)
with pref.open()as f:
 assert int(f.readline())==locked
 for n,(name,ps)in enumerate(nets[:locked]):
  a=f.readline().split();assert a[0]==name
  for _ in range(int(a[1])):
   a=list(map(int,f.readline().split()));assert len(a)==1+a[0]*3
   for p in zip(a[1::3],a[2::3],a[3::3]):base[vid(p)]=1
assert sum(base)==109862 and len(lands)==24760
def path(pts):
 yield pts[0]
 for p,q in zip(pts,pts[1:]):
  d=[q[i]-p[i]for i in range(3)];axis=[i for i in range(3)if d[i]]
  if not axis:continue
  assert len(axis)==1
  i=axis[0]
  if i==2:assert abs(d[i])==1 and (p[0]+p[1])%2==0
  for j in range(1,abs(d[i])+1):yield tuple(p[k]+(j*(1 if d[i]>0 else -1)if k==i else 0)for k in range(3))
from array import array
files=[b/'control162-vhv2434-sweep-1024.txt',b/'control162-vhv2438-sweep-512.txt',b/'control162-vhv2439-sweep-1024.txt']
occ=base[:];owner=array('i',[-1])*(2*plane);seen={};wire=via=0
for f in files:
 for line in f.read_text().splitlines():
  a=list(map(int,line.split()));n=a[0];assert n>=locked and n not in seen;p,q=nets[n][1];x,y,_=p;u,v,_=q
  if len(a)==5:
   _,c,d,e,k=a
   pts=[p,q]if k==0 else[p,(x,d,0),(c,d,0),(c,d,1),(c,e,1),(c,e,0),(u,e,0),q]
  elif len(a)==6:
   _,r,a1,a2,b1,b2=a
   pts=[p,(a1,a2,0),(a1,a2,1),(a1,r,1),(a1,r,0),(b1,r,0),(b1,r,1),(b1,b2,1),(b1,b2,0),q]
  else:
   _,c,a1,a2,a3,b1,b2,b3=a
   pts=[p,(a1,a2,0),(a1,a2,1),(a1,a3,1),(a1,a3,0),(c,a3,0),(c,a3,1),(c,b3,1),(c,b3,0),(b1,b3,0),(b1,b3,1),(b1,b2,1),(b1,b2,0),q]
  now=list(path(pts));assert now[0]==p and now[-1]==q
  for i in range(len(now)-1):
   if now[i][2]==now[i+1][2]:wire+=1
   else:via+=1
  for pt in now:
   xx,yy,ll=pt;v=vid(pt);assert 4<=xx<nx-4 and 4<=yy<ny-4 and ll in [0,1]
   assert not occ[v] and (ll or lands.get(v,n)==n),(f.name,n,pt)
   occ[v]=1;owner[v]=n
  seen[n]=now
assert len(seen)==3123
def neighbors(v):
 x=v%nx;y=(v%plane)//nx;l=v//plane
 if x>4:yield v-1
 if x<nx-5:yield v+1
 if y>4:yield v-nx
 if y<ny-5:yield v+nx
 if(x+y)%2==0:yield v+(plane if not l else-plane)
def blocked(active,base_only=False):
 ans=[];remset=set(active)
 for n,(name,pins) in enumerate(nets):
  if n<locked or n in remset:continue
  for p in pins:
   x,y,_=p;start=vid(p);q=[start];got={start};hit=False;foreign=set()
   for v in q:
    if max(abs(v%nx-x),abs((v%plane)//nx-y))>=4:hit=True;break
    for w in neighbors(v):
     if w in got or lands.get(w,n)!=n or base[w]:continue
     if not base_only and owner[w] in remset:foreign.add(owner[w]);continue
     got.add(w);q.append(w)
   if not hit and any(vid(t)not in got for t in pins):ans.append((n, start, foreign))
 return ans
baseline=blocked(set(seen),True);active=set(seen);cycles=[]
for k in range(10):
 closed=blocked(active)
 new=[z for z in closed if z[2]]
 blockers=set().union(*(z[2]for z in new)) if new else set()
 cycles.append(dict(cycle=k,active=len(active),closed=len(closed),closed_with_candidate_blockers=len(new),removed=len(blockers)))
 if not blockers:break
 active-=blockers
else:raise AssertionError('Prune did not settle')
left=blocked(active);control=blocked(active,True)
assert {(n,v)for n,v,_ in left}=={(n,v)for n,v,_ in control}
out=b/'control162-vhv-safe2440';assert not out.exists();out.mkdir()
def write(target,choices):
 with target.open('w',encoding='ascii',newline='\n')as f:
  f.write(str(len(choices))+'\n')
  for n in sorted(choices):
   pts=seen[n];f.write(f'{nets[n][0]} 2\n1 '+' '.join(map(str,pts[0]))+'\n'+str(len(pts))+' '+' '.join(str(k)for p in reversed(pts)for k in p)+'\n')
write(out/'pruned-ordinary-prefix.txt',active)
res=dict(passed=True,route_qualified=False,whole_system_qualified=False,selected_unpruned=len(seen),unpruned_wires=wire,unpruned_vias=via,native_vertices=sum(base),prune_cycles=cycles,selected_pruned=len(active),final_closed=len(left),final_native_baseline_closed=len(control),inputs={str(p):sha(p)for p in [inp,pref,Path(__file__),*files]},outputs={'pruned-ordinary-prefix.txt':sha(out/'pruned-ordinary-prefix.txt')},scope='Three actual greedy subset witnesses independently verified at original unit grid: intact native paths, all foreign landings, vias, endpoints, no own or cross-net repeats. Iteratively release candidate wires on the boundary of closed unseeded endpoints, retaining actual landings; compared at fixed active subset to the exact native-only baseline. Local radius4 condition only; all physical gates still needed. Diagnostic package; never used in any live route.')
(out/'receipt.json').write_text(json.dumps(res,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in res.items()if k not in ['inputs','scope']}))
