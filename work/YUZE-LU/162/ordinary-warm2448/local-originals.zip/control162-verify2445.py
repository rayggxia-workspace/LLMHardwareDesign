from pathlib import Path
import sys,hashlib,json
p=Path.cwd();r=p/'control162-seed2442';w=p/'LLMHardwareDesign-worktrees/issue-162-control/project/experiments/control_v1'
sys.path.insert(0,str(w));sys.path.insert(0,str(r))
from tree_router_cpp import verify_ordinary_seed
from router_conflict_snapshot import inputs
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=p/'control162-receive1988/input.txt';seed=p/'control162-vhv-safe2440/pruned-ordinary-prefix.txt';native=p/'control162-oriented1998/prefix.txt'
d=json.loads((seed.parent/'receipt.json').read_bytes());assert sha(seed)==d['outputs'][seed.name]
assert sha(source)=='94dc48894b54cfd9ccb6533c72e32e35f0c5bad7be1186ab5b0c2ebec97aec37'
alternate=p/'control162-endpoint2088/input.txt';assert source.read_bytes().split(b'\n',1)[1]==alternate.read_bytes().split(b'\n',1)[1]
h,terminals,limits=inputs(source);locked=list(terminals)[:h[6]]
config=r/'full-local-config.json';config.write_text(json.dumps(dict(paths=str(seed),paths_sha256=sha(seed),input_sha256=sha(source),native_prefix_sha256=sha(native))))
f=verify_ordinary_seed(config,dict(prefix=str(native),prefix_sha256=sha(native),input_sha256=sha(source)),terminals,*h[:2],locked,limits);assert f['nets']==1586 and f['all_true_landings_checked']
(r/'full-local-preflight.json').write_text(json.dumps(f,indent=2));print(json.dumps(f))
