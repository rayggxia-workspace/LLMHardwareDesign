#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
struct P { int x,y; };
struct Net{string name;vector<P> p;int budget;};
struct Bits {
 int step;vector<uint64_t> b;
 Bits(int tracks,int length):step((length+63)/64),b(size_t(tracks)*step){}
 static uint64_t low(int j){return j==63?~uint64_t(0):((uint64_t(1)<<(j+1))-1);}
 bool clear(int track,int lo,int hi)const{
  auto v=b.begin()+size_t(track)*step;int x=lo/64,y=hi/64;
  if(x==y)return !(v[x]&(low(hi%64)&(~uint64_t(0)<<(lo%64))));
  if(v[x]&(~uint64_t(0)<<(lo%64)))return false;
  if(v[y]&low(hi%64))return false;
  for(int i=x+1;i<y;++i)if(v[i])return false;
  return true;
 }
 void use(int track,int lo,int hi){
  auto v=b.begin()+size_t(track)*step;int x=lo/64,y=hi/64;
  if(x==y){v[x]|=low(hi%64)&(~uint64_t(0)<<(lo%64));return;}
  v[x]|=~uint64_t(0)<<(lo%64);v[y]|=low(hi%64);for(int i=x+1;i<y;++i)v[i]=~uint64_t(0);
 }
};
int main(int argc,char**argv){
 if(argc!=6)throw runtime_error("input prefix order window witness");
 ifstream in(argv[1]);int nx,ny,n,k,rounds,weight,locked;in>>nx>>ny>>n>>k>>rounds>>weight>>locked;string line;getline(in,line);
 if(nx!=3070||ny!=3252||n!=11149||locked!=1229)throw runtime_error("input context");
 vector<Net> nets(n);Bits fixed(ny,nx),m11(ny,nx),m12(nx,ny);
 for(auto& a:nets){in>>a.name>>k;a.p.resize(k);for(auto& x:a.p){in>>x.x>>x.y;fixed.use(x.y,x.x,x.x);}in>>a.budget;}
 ifstream pref(argv[2]);pref>>k;if(k!=locked)throw runtime_error("prefix count");
 for(int j=0;j<locked;++j){string s;pref>>s>>k;if(s!=nets[j].name)throw runtime_error("prefix net");while(k--){int l;pref>>l;while(l--){int x,y,z;pref>>x>>y>>z;if(z)m12.use(x,y,y);else m11.use(y,x,x);}}}
 vector<int> q;for(int j=locked;j<n;++j)if(nets[j].p.size()==2)q.push_back(j);
 auto length=[&](int j){auto a=nets[j].p[0],b=nets[j].p[1];return abs(a.x-b.x)+abs(a.y-b.y);};
 string mode=argv[3];int window=stoi(argv[4]);ofstream out(argv[5]);
 if(mode=="sweep")stable_sort(q.begin(),q.end(),[&](int a,int b){return min(nets[a].p[0].y,nets[a].p[1].y)<min(nets[b].p[0].y,nets[b].p[1].y);});
 else if(mode=="long"||mode=="short")stable_sort(q.begin(),q.end(),[&](int a,int b){return mode=="long"?length(a)>length(b):length(a)<length(b);});
 else if(mode=="random"){mt19937 rng(249129);shuffle(q.begin(),q.end(),rng);}
 else throw runtime_error("order");
 auto range=[&](P p,int y,int col){
  if(y==p.y){
   if(!m11.clear(y,min(p.x,col),max(p.x,col)))return false;
   if(p.x==col)return true;
   return col<p.x?fixed.clear(y,col,p.x-1):fixed.clear(y,p.x+1,col);
  }
  return m11.clear(y,min(p.x,col),max(p.x,col))&&fixed.clear(y,min(p.x,col),max(p.x,col))&&m11.clear(p.y,p.x,p.x);
 };
 auto add=[&](P p,int y,int col){m11.use(y,min(p.x,col),max(p.x,col));m11.use(p.y,p.x,p.x);};
 int yes=0,straight=0;uint64_t tests=0,wires=0,via=0;
 for(auto j:q){
  auto a=nets[j].p[0],b=nets[j].p[1];int mid=(a.x+b.x)/2;bool ok=false;
  if(a.y==b.y&&m11.clear(a.y,min(a.x,b.x),max(a.x,b.x))&&fixed.clear(a.y,min(a.x,b.x)+1,max(a.x,b.x)-1)){
   m11.use(a.y,min(a.x,b.x),max(a.x,b.x));++yes;++straight;wires+=abs(a.x-b.x);out<<j<<" "<<a.x<<" "<<a.y<<" "<<b.y<<" 0\n";continue;
  }
  for(int delta=0;delta<=window&&!ok;++delta)for(int s:{-1,1}){
   if(!delta&&s==1)continue;int c=mid+s*delta;if(c<4||c>=nx-4)continue;
   vector<int> ys,zs;
   for(int d:{0,-1,1}){if(a.y+d>=4&&a.y+d<ny-4&&((a.y+d+c)%2==0))ys.push_back(a.y+d);
                         if(b.y+d>=4&&b.y+d<ny-4&&((b.y+d+c)%2==0))zs.push_back(b.y+d);}
   for(int y:ys)for(int z:zs){
    ++tests;if(y==z||!m12.clear(c,min(y,z),max(y,z))||!range(a,y,c)||!range(b,z,c))continue;
    if((a.x>=min(b.x,c)&&a.x<=max(b.x,c)&&a.y==z)||(b.x>=min(a.x,c)&&b.x<=max(a.x,c)&&b.y==y))continue;
    add(a,y,c);add(b,z,c);m12.use(c,min(y,z),max(y,z));++yes;via+=2;
    wires+=abs(a.y-y)+abs(b.y-z)+abs(a.x-c)+abs(b.x-c)+abs(y-z);out<<j<<" "<<c<<" "<<y<<" "<<z<<" 1\n";ok=true;break;
   }
   if(ok)break;
  }
 }
 cout<<"{\"pairs\":"<<q.size()<<",\"routes\":"<<yes<<",\"straight\":"<<straight<<",\"wires\":"<<wires<<",\"vias\":"<<via<<",\"candidates\":"<<tests<<"}\n";
}
