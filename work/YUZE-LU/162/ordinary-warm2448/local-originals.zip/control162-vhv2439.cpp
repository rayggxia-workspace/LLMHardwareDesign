#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
struct P { int x,y; };
struct Net{string name;vector<P> p;int budget;};
struct Bits {
 int step;vector<uint64_t> b;
 Bits(int tracks,int length):step((length+63)/64),b(size_t(tracks)*step){}
 static uint64_t low(int j){return j==63?~uint64_t(0):((uint64_t(1)<<(j+1))-1);}
 bool clear(int track,int lo,int hi)const{
  auto v=b.begin()+size_t(track)*step;int x=lo/64,y=hi/64;
  if(x==y)return !(v[x]&(low(hi%64)&(~uint64_t(0)<<(lo%64))));
  if(v[x]&(~uint64_t(0)<<(lo%64)))return false;
  if(v[y]&low(hi%64))return false;
  for(int i=x+1;i<y;++i)if(v[i])return false;
  return true;
 }
 void use(int track,int lo,int hi){
  auto v=b.begin()+size_t(track)*step;int x=lo/64,y=hi/64;
  if(x==y){v[x]|=low(hi%64)&(~uint64_t(0)<<(lo%64));return;}
  v[x]|=~uint64_t(0)<<(lo%64);v[y]|=low(hi%64);for(int i=x+1;i<y;++i)v[i]=~uint64_t(0);
 }
};
int main(int argc,char**argv){
 if(argc!=6)throw runtime_error("input prefix order window witness");
 ifstream in(argv[1]);int nx,ny,n,k,rounds,weight,locked;in>>nx>>ny>>n>>k>>rounds>>weight>>locked;string line;getline(in,line);
 if(nx!=3070||ny!=3252||n!=11149||locked!=1229)throw runtime_error("input context");
 vector<Net> nets(n);Bits fixed(ny,nx),m11(ny,nx),m12(nx,ny);
 for(auto& a:nets){in>>a.name>>k;a.p.resize(k);for(auto& x:a.p){in>>x.x>>x.y;fixed.use(x.y,x.x,x.x);}in>>a.budget;}
 ifstream pref(argv[2]);pref>>k;if(k!=locked)throw runtime_error("prefix count");
 for(int j=0;j<locked;++j){string s;pref>>s>>k;if(s!=nets[j].name)throw runtime_error("prefix net");while(k--){int l;pref>>l;while(l--){int x,y,z;pref>>x>>y>>z;if(z)m12.use(x,y,y);else m11.use(y,x,x);}}}
 vector<int> q;for(int j=locked;j<n;++j)if(nets[j].p.size()==2)q.push_back(j);
 auto length=[&](int j){auto a=nets[j].p[0],b=nets[j].p[1];return abs(a.x-b.x)+abs(a.y-b.y);};
 string mode=argv[3];int window=stoi(argv[4]);ofstream out(argv[5]);
 if(mode=="sweep")stable_sort(q.begin(),q.end(),[&](int a,int b){return min(nets[a].p[0].y,nets[a].p[1].y)<min(nets[b].p[0].y,nets[b].p[1].y);});
 else if(mode=="long"||mode=="short")stable_sort(q.begin(),q.end(),[&](int a,int b){return mode=="long"?length(a)>length(b):length(a)<length(b);});
 else if(mode=="random"){mt19937 rng(249129);shuffle(q.begin(),q.end(),rng);}
 else throw runtime_error("order");
 struct A{int col,via_y,row;};
 auto options=[&](P p,int radi){
  vector<A> out;
  for(int r=0;r<=radi;++r)for(int d:{-1,1}){
   if(!r&&d==1)continue;int row=p.y+r*d;if(row<4||row>=ny-4)continue;
   for(auto shift:array<P,5>{{{0,0},{-1,0},{1,0},{0,-1},{0,1}}}){
    int x=p.x+shift.x,y=p.y+shift.y;
    if(x<4||x>=nx-4||y<4||y>=ny-4||((x+y)&1)||((x+row)&1))continue;
    if(!m11.clear(y,x,x)||!m11.clear(p.y,p.x,p.x))continue;
    if((x!=p.x||y!=p.y)&&!fixed.clear(y,x,x))continue;
    if(row!=y&&(!m11.clear(row,x,x)||!fixed.clear(row,x,x)))continue;
    if(row==y||!m12.clear(x,min(row,y),max(row,y)))continue;
    out.push_back({x,y,row});
   }
  }
  return out;
 };
 auto hclear=[&](P p,A a,int col){
  int lo=min(a.col,col),hi=max(a.col,col);
  if(!m11.clear(a.row,lo,hi))return false;
  if(a.row==p.y&&a.col==p.x)return (lo==p.x||fixed.clear(a.row,lo,p.x-1))&&(hi==p.x||fixed.clear(a.row,p.x+1,hi));
  return fixed.clear(a.row,lo,hi);
 };
 auto samecol=[](A a,A b){
  return a.col==b.col&&max(min(a.row,a.via_y),min(b.row,b.via_y))<=min(max(a.row,a.via_y),max(b.row,b.via_y));
 };
 auto overlap=[&](P p,A a,P q,A b,int t){
  if(a.row==b.row||samecol(a,b))return true;
  // Upper vertical portions cannot meet the central trunk.
  if(a.col==t||b.col==t)return true;
  auto on=[&](int x,int y,A v){return y==v.row&&min(v.col,t)<=x&&x<=max(v.col,t);};
  if(on(p.x,p.y,b)||on(a.col,a.via_y,b)||on(q.x,q.y,a)||on(b.col,b.via_y,a))return true;
  return a.col==b.col&&a.via_y==b.via_y;
 };
 auto commit=[&](P p,A a,int col){
  m11.use(p.y,p.x,p.x);m11.use(a.via_y,a.col,a.col);
  m11.use(a.row,min(a.col,col),max(a.col,col));m12.use(a.col,min(a.row,a.via_y),max(a.row,a.via_y));
 };
 vector<bool> seeded(n,false);
 const string oldname=string(argv[5])+".seed";
 ifstream seed(oldname);
 if(!seed)throw runtime_error("baseline subset missing");
 for(int j,c,d,e,k;seed>>j>>c>>d>>e>>k;){
  if(j<locked||j>=n||seeded[j]||nets[j].p.size()!=2)throw runtime_error("baseline subset net");
  seeded[j]=true;
  auto a=nets[j].p[0],b=nets[j].p[1];
  if(!k){m11.use(a.y,min(a.x,b.x),max(a.x,b.x));continue;}
  m11.use(d,min(a.x,c),max(a.x,c));m11.use(a.y,a.x,a.x);
  m11.use(e,min(b.x,c),max(b.x,c));m11.use(b.y,b.x,b.x);
  m12.use(c,min(d,e),max(d,e));
 }
 const string extra=string(argv[5])+".extra";ifstream more(extra);if(!more)throw runtime_error("second subset missing");
 for(int j,t,a1,a2,a3,b1,b2,b3;more>>j>>t>>a1>>a2>>a3>>b1>>b2>>b3;){
  if(j<locked||j>=n||seeded[j]||nets[j].p.size()!=2)throw runtime_error("second subset net");
  seeded[j]=true;commit(nets[j].p[0],{a1,a2,a3},t);commit(nets[j].p[1],{b1,b2,b3},t);m12.use(t,min(a3,b3),max(a3,b3));
 }
 auto vias=[&](P p){
  vector<P> a;for(auto d:array<P,5>{{{0,0},{-1,0},{1,0},{0,-1},{0,1}}}){
   int x=p.x+d.x,y=p.y+d.y;if(x<4||x>=nx-4||y<4||y>=ny-4||((x+y)&1))continue;
   if(!m11.clear(y,x,x)||!m11.clear(p.y,p.x,p.x))continue;
   if((x!=p.x||y!=p.y)&&!fixed.clear(y,x,x))continue;
   a.push_back({x,y});
  }return a;
 };
 auto vclear=[&](P p,P a,int row){
  if(!m12.clear(a.x,min(a.y,row),max(a.y,row)))return false;
  return m11.clear(row,a.x,a.x)&&(row==p.y&&a.x==p.x||fixed.clear(row,a.x,a.x));
 };
 int yes=0,straight=0;uint64_t tests=0,wires=0,via=0;
 for(auto j:q){
  if(seeded[j])continue;auto a=nets[j].p[0],b=nets[j].p[1];auto as=vias(a),bs=vias(b);int mid=(a.y+b.y)/2;bool ok=false;
  if(as.empty()||bs.empty())continue;
  for(int delta=0;delta<=window&&!ok;++delta)for(int s:{-1,1}){
   if(!delta&&s==1)continue;int row=mid+s*delta;if(row<4||row>=ny-4)continue;
   for(auto v:as){
    if((v.x+row)&1||row==v.y||!vclear(a,v,row))continue;
    for(auto w:bs){
     ++tests;
     if(v.x==w.x||(w.x+row)&1||row==w.y||!vclear(b,w,row))continue;
     int lo=min(v.x,w.x),hi=max(v.x,w.x);
     if(!m11.clear(row,lo,hi))continue;
     // Exclude actual M11 endpoint/escape self-overlap. Only unused
     // non-landing trunk intervals are accepted in this diagnostic.
     if(!fixed.clear(row,lo,hi))continue;
     if(v.x==w.x&&v.y==w.y||v.x==b.x&&v.y==b.y||w.x==a.x&&w.y==a.y)continue;
     m11.use(row,lo,hi);m11.use(a.y,a.x,a.x);m11.use(b.y,b.x,b.x);m11.use(v.y,v.x,v.x);m11.use(w.y,w.x,w.x);
     m12.use(v.x,min(row,v.y),max(row,v.y));m12.use(w.x,min(row,w.y),max(row,w.y));
     out<<j<<" "<<row<<" "<<v.x<<" "<<v.y<<" "<<w.x<<" "<<w.y<<"\n";++yes;via+=4;wires+=abs(a.x-v.x)+abs(a.y-v.y)+abs(b.x-w.x)+abs(b.y-w.y)+abs(v.x-w.x)+abs(v.y-row)+abs(w.y-row);ok=true;break;
    }
    if(ok)break;
   }
   if(ok)break;
  }
 }
 cout<<"{\"pairs\":"<<q.size()<<",\"routes\":"<<yes<<",\"straight\":"<<straight<<",\"wires\":"<<wires<<",\"vias\":"<<via<<",\"candidates\":"<<tests<<"}\n";
}
