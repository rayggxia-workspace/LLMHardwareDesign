from pathlib import Path
import hashlib,json,subprocess,zipfile,io
root=Path(r'D:\Data\电路实验\LLMHardwareDesign-worktrees\issue-162-control')
base=Path(r'D:\Data\电路实验')
remote='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-162'
out=root/'work/YUZE-LU/162/sta-resource-correction1544'
assert not out.exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
def read(path):
    return subprocess.check_output(['ssh','-o','ConnectTimeout=15','yuzelu@10.129.166.172','cat '+path],timeout=45)
index=read(remote+'/r256-sta-resource-correction-1544/index.json')
audit=read(remote+'/r256-sta-resource-audit-1545/receipt.json')
d=json.loads(index);a=json.loads(audit)
assert d['passed'] and a['passed'] and len(d['rows'])==9
files={remote+'/r256-sta-resource-correction-1544/index.json':index,
       remote+'/r256-sta-resource-audit-1545/receipt.json':audit,
       remote+'/r256-sta-resource-correction-1544/verified-before.json':read(remote+'/r256-sta-resource-correction-1544/verified-before.json')}
for row in d['rows']:
    for key,hashkey in [('held_path','old_sha256'),('new_path','new_sha256')]:
        data=read(row[key]);assert sha(data)==row[hashkey]
        files[row[key]]=data
    assert row['new_spec']['forecast_gib']==224
    assert row['old_spec']['args']==row['new_spec']['args']
helpers={name:(base/name).read_bytes() for name in ['control162-correct1544-remote.py','control162-audit1545-remote.py','control162-bind1546.py']}
out.mkdir()
archive=out/'originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path,data in files.items():z.writestr('remote/'+path[len(remote)+1:],data)
    for name,data in helpers.items():z.writestr('helpers/'+name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for path,data in files.items():assert z.read('remote/'+path[len(remote)+1:])==data
    for name,data in helpers.items():assert z.read('helpers/'+name)==data
(out/'correction.json').write_bytes(index)
(out/'audit.json').write_bytes(audit)
binding=dict(passed=True,whole_system_qualified=False,
    files={p:dict(bytes=len(v),sha256=sha(v),zip_entry='remote/'+p[len(remote)+1:]) for p,v in files.items()},
    helpers={p:dict(bytes=len(v),sha256=sha(v),zip_entry='helpers/'+p) for p,v in helpers.items()},
    archive=dict(path='originals.zip',bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),
    source_archive_and_physical_gates_unchanged=True,
    scope='Supplement to checkpoint86: only nine never-admitted future STA task specs for 15220/15340/15341 changed outer forecast128->224GiB and added exact audit dependency. Old specs retained; args, frozen source, outputs, RC variants and final physical gates unchanged. Actual aggregate224GiB admission still required when real route/geometry dependencies finish. No STA or system pass claimed.')
(out/'index.json').write_text(json.dumps(binding,indent=2),encoding='utf-8')
para='九个未启动的后继STA任务（15220/15340/15341各low/base/high）已按原脚本内部128+96GiB需求，将外层预测128修正为224GiB，增加独立核验依赖；旧规格保留，源/参数/输出/物理门不变。[修正与逐字源绑定]({link})补充Checkpoint86。实际准入仍需按节点汇总预测执行1.2倍加16GiB门；此修正不表示STA执行或系统通过。\n\n'
for path,link in [('docs/CONTROL_V1.md','../work/YUZE-LU/162/sta-resource-correction1544/index.json'),('docs/ARCHITECTURE.md','../work/YUZE-LU/162/sta-resource-correction1544/index.json')]:
    p=root/path;text=p.read_text(encoding='utf-8');first,rest=text.split('\n',1)
    p.write_text(first+'\n\n'+para.format(link=link)+rest.lstrip('\n'),encoding='utf-8')
print(json.dumps(dict(passed=True,remote_files=len(files),helpers=len(helpers),archive_bytes=archive.stat().st_size)))
