#!/bin/bash
set -euo pipefail
cache=/mnt/c/Users/wine10/AppData/Local/Codex/issue219-round7-tile
root=/tmp/yzl-issue219-tile-round7-checkpoint-20261109
mkdir "$root"
cd "$root"
tar -xf "$cache/source-checkpoint.tar"
/tmp/yzl-issue219-python3128-20261109/install/bin/python3.12 -B -m unittest discover -s . -p "test_*.py" > "$cache/linux-checkpoint-tests.log" 2>&1
echo PASS
