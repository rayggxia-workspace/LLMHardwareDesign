import json,sys
from pathlib import Path
sys.path.insert(0,str(Path('project/experiments/block_synthesis').resolve()))
sys.path.insert(0,str(Path('work/YUZE-LU/219/throughput-opt').resolve()))
from analyse_resident_traffic import audit
from verify_resident_batch import replay
root=Path('D:/Data/电路实验/issue219-runtime-round23');data=json.loads((root/'scatter-r2-width2/programs.json').read_text());out={}
for name,p in data['programs'].items():
 for f in data['fixtures']:replay(data['tile'],p,{(t,i):v for t,i,v in f['inputs']})
 groups={}
 for e in p['events']:
  if e['op']=='ROW_M_FINAL':groups.setdefault(tuple(e['native']),[]).append(e)
 rowgroups=[events for events in groups.values() if len(events)>1]
 scattered=[events for events in rowgroups if any(e['address']!=events[0]['address']+e['row'] for e in events)]
 out[name]={'traffic':audit(data['tile'],p),'multirow_contexts':len(rowgroups),'scattered_final_contexts':len(scattered)}
result={'passed':True,'numeric_traces':len(data['fixtures'])*len(data['programs']),'plans':out,
 'scope':'independent finite-S execution and physical-address observation, not actual weights or RTL/system qualification'}
(root/'scatter-address-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({n:{k:v for k,v in r.items() if k!='traffic'}|{'ticks':r['traffic']['total_ticks'],'words':r['traffic']['external_words']} for n,r in out.items()}))
