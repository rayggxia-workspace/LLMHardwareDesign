import json,random
from pathlib import Path
rng=random.Random(219240);values=[-(1<<31),-65537,-65536,-32769,-32768,-1,0,1,32767,32768,65535,65536,(1<<31)-1]
values += [rng.randrange(-(1<<31),1<<31) for _ in range(100000)]
def s16(x):
 x=x&65535
 return x-65536 if x&32768 else x
for raw in values:
 old=s16((raw&0xffffffff)>>16)
 # Native K=2 dot over raw [low16,high16], B [0,1].
 new=s16(raw)*0+s16(raw>>16)*1
 assert old==new
 for coefficient in (-32768,-1,1,32767):
  for shift in (0,16,31):assert old*coefficient*(1<<shift)==new*coefficient*(1<<shift)
out={'passed':True,'raw_values':len(values),'integer_equalities':len(values)*12,
 'identity':'signed_high16(raw) * 1 == native_dot_K2(raw, basis_[0,1])',
 'scope':'integer identity only; does not prove changed-K accumulator protocol, source rewrite, full program timing, RTL or whole-model qualification'}
Path('D:/Data/电路实验/issue219-runtime-round23/high-folding-math.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
