import collections,json
from pathlib import Path
d=json.loads(Path('D:/Data/电路实验/issue219-runtime-round23/scatter-r2-width2/programs.json').read_text());g=d['tile']['graph'];obj=g['objects']
ns={n['id']:n for n in g['operations'] if 'reuse_of' not in n};writers={n['output']:n for n in ns.values()};users=collections.defaultdict(list)
for n in ns.values():
 for value in n['inputs']:users[value].append(n)
eligible=[];high=[]
for n in ns.values():
 if n['kind']!='M' or n['width']!=16 or n['shift']!=0 or n['k']!=2 or len(n['terms'])!=1:continue
 t=n['terms'][0]
 if obj[t['b']].get('literal')!=65536 or t['coefficient']!=1 or t['scale_shift']!=0:continue
 high.append(n['id']);consumers=users[n['output']]
 if not consumers:continue
 ok=True;uses=[]
 for c in consumers:
  if c['kind']!='M':ok=False;break
  for term in c['terms']:
   if n['output'] not in (term['a'],term['b']):continue
   if term['a']!=n['output'] or obj[term['b']].get('literal')!=1:ok=False;break
   uses.append(c['id'])
 if ok:eligible.append({'extract':n['id'],'raw':t['a'],'consumers':uses})
r={'high_extracts':len(high),'all_uses_constant_one':len(eligible),'eligible':eligible,
 'scope':'structural opportunity only, no rewrite, profile or performance qualification; high lane can be consumed with K2 basis [0,1], other terms must independently remain numerically valid at K2'}
Path('D:/Data/电路实验/issue219-runtime-round23/high-extract-opportunities.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
