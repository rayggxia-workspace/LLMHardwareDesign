import json,sys
from pathlib import Path
sys.path.insert(0,str(Path('project/experiments/block_synthesis').resolve()))
from resident_scatter_survey import run
run('D:/Data/电路实验/issue219-runtime-round22/masked-v209-r2-width2/programs.json',
 json.loads(Path('D:/Data/电路实验/issue219-runtime-round18/cover-compare-v1/conditional_reuse/ir.json').read_text()),
 'D:/Data/电路实验/issue219-runtime-round23/scatter-r2-width2',width=2)
