from copy import deepcopy
import random
import unittest
from native_lane_cover import candidates,cover,verify
from native_pointwise import execute
from resident_batch import plan
from resident_batch_graph import verify as verify_tile
from test_resident_batch import case
from test_resident_operand_mask import contract
from verify_resident_batch import replay


class TestNativeLaneCover(unittest.TestCase):
    def test_dynamic_cover_preserves_S32_and_static_sources_are_excluded(self):
        _,tile,actors,q,scalar=case();options=candidates(tile)
        self.assertTrue(options)
        self.assertTrue(all('literal' not in tile['graph']['objects'][r['raw']] for r in options.values()))
        folded=cover(tile);self.assertEqual(verify_tile(folded)['covered_dynamic_extractions'],len(options))
        self.assertLess(len(folded['graph']['operations']),len(tile['graph']['operations']))
        variants=[plan(folded,actors,1000,q,scalar,width=w,schedule=s,operand_contract=contract(q))
                  for w,s in ((1,'fixed'),(2,'fixed'),(1,'ready'))]
        rng=random.Random(21924)
        for edge in (-2147483648,-65537,-32769,-32768,-1,0,32768,65535,65536,2147483647):
            values={('x',i):edge for i in range(3)}|{('y',i):rng.randrange(-(1<<31),1<<31) for i in range(3)}|{('one',0):1}
            for program in variants:
                got=replay(folded,program,values)['observed_native_outputs']
                for rr,g in enumerate(tile['graphs']):
                    gold=execute(g,values)
                    for primitive,key in g['primitive_outputs'].items():
                        self.assertEqual(got[folded['graph']['primitive_outputs'][f'{rr}:{primitive}']],gold[key])
        self.assertTrue(any(e['k']==2 for p in variants for e in p['events'] if e['op']=='ROW_M_TERM'))

    def test_cover_rejects_changed_source_terms_outputs_and_wrong_K(self):
        _,tile,actors,q,scalar=case();good=cover(tile)
        for fault in ('basis','K','coefficient','output','order','source','static'):
            bad=deepcopy(good)
            n=next(n for n in bad['graph']['operations'] if n['kind']=='M' and any(t.get('k')==2 for t in n['terms']))
            term=next(t for t in n['terms'] if t.get('k')==2)
            if fault=='basis':term['b']=term['a']
            elif fault=='K':term['k']=1
            elif fault=='coefficient':term['coefficient']+=1
            elif fault=='output':bad['graph']['primitive_outputs'].pop(next(iter(bad['graph']['primitive_outputs'])))
            elif fault=='order':bad['graph']['operations'].reverse()
            elif fault=='source':bad['operand_cover']['source_sha256']='0'*64
            else:bad['operand_cover']['selected'].append('constant:65536')
            with self.subTest(fault=fault),self.assertRaises(ValueError):verify(bad)
        p=plan(good,actors,1000,q,scalar,width=1,operand_contract=contract(q))
        bad=deepcopy(p);term=next(e for e in bad['events'] if e['op']=='ROW_M_TERM' and e['k']==2);term['k']=1
        with self.assertRaises(ValueError):replay(good,bad,{('x',i):32768 for i in range(3)}|{('y',i):-65537 for i in range(3)}|{('one',0):1})


if __name__=='__main__':unittest.main()
