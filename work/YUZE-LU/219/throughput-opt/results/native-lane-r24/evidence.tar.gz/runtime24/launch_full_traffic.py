import importlib.util,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd();base=m.BASE
name='algorithm-fix-307-full-traffic-audit'
sys.argv=['launch_fix.py',name,'traffic-accounting.sbatch',
 base+'/algorithm-fix-286-resident-cover-full/generated/ir.json',base+'/algorithm-fix-286-resident-cover-full/generated/selected.json']
m.main();source=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json')
Path('D:/Data/电路实验/issue219-runtime-round24',source.name).write_bytes(source.read_bytes())
