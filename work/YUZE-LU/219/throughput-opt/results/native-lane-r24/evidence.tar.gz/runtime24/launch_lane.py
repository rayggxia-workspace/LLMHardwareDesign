import importlib.util,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd();base=m.BASE
name='algorithm-fix-305-native-high16-cover-r2'
sys.argv=['launch_fix.py',name,'native-lane.sbatch',
 base+'/algorithm-fix-304-resident-scatter-r2/generated/programs.json',base+'/resident-overlap-r19-inputs/ir.json']
m.main();source=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json')
Path('D:/Data/电路实验/issue219-runtime-round24',source.name).write_bytes(source.read_bytes())
