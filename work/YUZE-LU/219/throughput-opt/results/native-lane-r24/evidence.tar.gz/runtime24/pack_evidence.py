import hashlib,io,json,tarfile
from pathlib import Path
root=Path.cwd();work=root/'work/YUZE-LU/219/throughput-opt';runtime=Path('D:/Data/电路实验/issue219-runtime-round24')
out=work/'results/native-lane-r24';out.mkdir(exist_ok=False);files={}
def add(folder,prefix):
    assert folder.is_dir(),folder
    for p in sorted(folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.vvp'):
            files[prefix+'/'+p.relative_to(folder).as_posix()]=p
add(runtime,'runtime24')
add(Path('D:/Data/电路实验/issue219-runtime-round23'),'runtime23')
for name in ('resident-scatter-terminal-r24','native-lane-terminal-r24','native-lane-r4-terminal-r24','full-traffic-failed-r24','full-traffic-terminal-r24'):
    add(work/'results'/name,name)
for name in ('algorithm-fix-305-native-high16-cover-r2','algorithm-fix-306-native-high16-cover-r4',
             'algorithm-fix-307-full-traffic-audit','algorithm-fix-308-full-traffic-cover-audit'):
    p=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.tar');assert p.is_file();files['frozen/'+p.name]=p
members={};aliases={};stored={};archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for name,p in files.items():
        data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();members[name]={'sha256':sha,'bytes':len(data)}
        if sha in stored:aliases[name]=stored[sha];continue
        stored[sha]=name;entry=tarfile.TarInfo(name);entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
manifest={'issue':219,'pr':220,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes':archive.stat().st_size,'members':members,'aliases':aliases,
    'scope':'round23 native row-address placement, round24 source-bound dynamic lane cover; 48 old +84 synthetic+36 saved actual-boundary native RTL programs; full selected logical traffic audit; no new full-model numerical/SystemC/DRAM/energy/token/s qualification'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for src,dst in (('audit-v2.json','audit.json'),('actual-audit.json','actual-audit.json')):
    (out/dst).write_bytes((runtime/src).read_bytes())
traffic=work/'results/full-traffic-terminal-r24/traffic-accounting.json'
(out/'traffic-accounting.json').write_bytes(traffic.read_bytes())
with tarfile.open(archive) as tar:
    seen=set()
    for entry in tar:
        assert hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==members[entry.name]['sha256'];seen.add(entry.name)
    assert seen==set(members)-set(aliases)
print(json.dumps({'sha256':manifest['archive_sha256'],'bytes':manifest['archive_bytes'],'members':len(members),'aliases':len(aliases)}))
