import json
from pathlib import Path
root=Path.cwd();directory=root/'work/YUZE-LU/219/throughput-opt/results/resident-batch-terminal-r21/generated'
rows=[]
for file in sorted(directory.glob('region-*.json')):
    data=json.loads(file.read_text());live={c['record'] for c in data['tile']['graph']['external_commits']}
    for name,p in data['programs'].items():
        future=set();dead=[]
        for at in range(len(p['events'])-1,-1,-1):
            e=p['events'][at]
            if e['op']=='ROW_M_TERM':future.update(e['a_records']);future.add(e['b_record'])
            elif e['op']=='E':future.update(e['input_records'])
            elif e['op']=='STORE' and e['record'] not in future and e['record'] not in live:
                dead.append({'event':at,'record':e['record'],'ticks':p['actors'][e['actor']]['store_ticks']})
        rows.append({'file':file.name,'plan':name,'ticks':p['total_ticks'],'external_words':p['external_words'],
                     'dead_spill_count':len(dead),'dead_spill_ticks':sum(e['ticks'] for e in dead),'events':dead})
out=Path('D:/Data/电路实验/issue219-runtime-round21/dead-spill-analysis.json');out.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'plans':len(rows),'with_dead_spills':sum(bool(r['events']) for r in rows),'max_dead_spills':max(r['dead_spill_count'] for r in rows)}))
for r in rows:
    if r['events'] and r['plan']=='scalar_greedy':print(json.dumps({k:v for k,v in r.items() if k!='events'}))
