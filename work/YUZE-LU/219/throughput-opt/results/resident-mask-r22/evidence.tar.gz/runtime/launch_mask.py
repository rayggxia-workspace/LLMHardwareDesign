import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd();base=m.BASE
q=Path('D:/Data/电路实验/issue219-runtime-round22/mask-services-v2/qualification.json')
inputs=base+'/resident-mask-r22-inputs'
subprocess.run(['ssh',m.REMOTE,'mkdir',inputs],check=True,timeout=30)
subprocess.run(['scp',str(q),m.REMOTE+':'+inputs+'/qualification.json'],check=True,timeout=30)
got=subprocess.check_output(['ssh',m.REMOTE,'sha256sum',inputs+'/qualification.json'],timeout=30).decode().split()[0]
assert got==hashlib.sha256(q.read_bytes()).hexdigest()
Path('D:/Data/电路实验/issue219-runtime-round22/staged-input.json').write_text(json.dumps({'server':inputs+'/qualification.json','sha256':got},indent=2)+'\n')
name='algorithm-fix-303-resident-active-prefix'
sys.argv=['launch_fix.py',name,'resident-mask.sbatch',base+'/algorithm-fix-298-resident-batch-survey/generated',
          base+'/resident-overlap-r19-inputs/ir.json',inputs+'/qualification.json']
m.main();source=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json')
Path('D:/Data/电路实验/issue219-runtime-round22',source.name).write_bytes(source.read_bytes())
