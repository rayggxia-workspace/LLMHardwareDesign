import hashlib,io,json,tarfile
from pathlib import Path
root=Path.cwd();work=root/'work/YUZE-LU/219/throughput-opt';runtime=Path('D:/Data/电路实验/issue219-runtime-round22')
out=work/'results/resident-mask-r22';out.mkdir(exist_ok=False);files={}
def add(folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.vvp'):
            files[prefix+'/'+p.relative_to(folder).as_posix()]=p
add(runtime,'runtime')
add(work/'results/resident-layout-terminal-r22','layout-terminal')
add(work/'results/resident-mask-partial-r22','mask-partial')
for file in ('algorithm-fix-303-resident-active-prefix.tar',):
    p=Path('D:/Data/电路实验/issue219-runtime-round15')/file;assert p.is_file();files['frozen/'+p.name]=p
for file in ('analyse_dead_spills.py','dead-spill-analysis.json'):
    p=Path('D:/Data/电路实验/issue219-runtime-round21')/file;assert p.is_file();files['previous-audit/'+file]=p
members={};aliases={};stored={};archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for name,p in files.items():
        data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();members[name]={'sha256':sha,'bytes':len(data)}
        if sha in stored:aliases[name]=stored[sha];continue
        stored[sha]=name;entry=tarfile.TarInfo(name);entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
manifest={'issue':219,'pr':220,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes':archive.stat().st_size,'members':members,'aliases':aliases,
    'scope':'qualified active-prefix services and 48 synthetic complete cold programs; immutable rows2 partial output from running 101683; terminal old layout survey; not whole-model/DRAM/SystemC/energy/token/s'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for f in ('audit.json','layout-terminal-audit.json','traffic-audit-width2.json','traffic-audit-width8.json'):
    (out/f).write_bytes((runtime/f).read_bytes())
with tarfile.open(archive) as tar:
    seen=set()
    for entry in tar:
        assert hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==members[entry.name]['sha256'];seen.add(entry.name)
    assert seen==set(members)-set(aliases)
print(json.dumps({'sha256':manifest['archive_sha256'],'bytes':manifest['archive_bytes'],'members':len(members),'aliases':len(aliases)}))
