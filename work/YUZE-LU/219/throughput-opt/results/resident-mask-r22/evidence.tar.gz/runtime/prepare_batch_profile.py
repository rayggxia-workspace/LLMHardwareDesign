import sys
from pathlib import Path
sys.path.insert(0,str(Path('project/experiments/block_synthesis').resolve()))
from resident_batch_probe import prepare
m=prepare(Path('D:/Data/电路实验/issue219-runtime-round19/overlap-rtl-v2'),
    Path('D:/Data/电路实验/issue219-runtime-round22/masked-v209-r2-width2/programs.json'),
    Path('D:/Data/电路实验/issue219-runtime-round22/batch-programs-v2-profile'),
    ['scalar_greedy','masked_scalar_greedy','masked_layout_dp'])
print({'prepared':True,'cases':len(m['cases'])})
