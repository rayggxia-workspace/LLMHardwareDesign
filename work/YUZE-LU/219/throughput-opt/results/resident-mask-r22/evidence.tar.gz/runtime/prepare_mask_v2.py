import json,sys
from pathlib import Path
sys.path.insert(0,str(Path('project/experiments/block_synthesis').resolve()))
from resident_mask_probe import prepare
origin=Path('D:/Data/电路实验/issue219-runtime-round20/row-services-v1');m=json.loads((origin/'manifest.json').read_text())
prepare(origin,origin/'s_sram_256x128_freepdk45.v',Path('D:/Data/电路实验/issue219-runtime-round22/mask-services-v2'),m['formats'])
print(json.dumps({'prepared':True,'cases':len(m['cases'])}))
