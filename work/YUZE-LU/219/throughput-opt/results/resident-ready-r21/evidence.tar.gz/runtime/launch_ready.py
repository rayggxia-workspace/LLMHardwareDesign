import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd();base=m.BASE
name='algorithm-fix-301-resident-ready-r2'
sys.argv=['launch_fix.py',name,'resident-ready.sbatch',base+'/algorithm-fix-298-resident-batch-survey/generated/region-v209-rows-2.json',
          base+'/resident-overlap-r19-inputs/ir.json']
m.main()
source=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json')
Path('D:/Data/电路实验/issue219-runtime-round21',source.name).write_bytes(source.read_bytes())
