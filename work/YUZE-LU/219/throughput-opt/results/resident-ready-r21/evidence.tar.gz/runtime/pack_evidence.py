import hashlib,io,json,tarfile
from pathlib import Path
root=Path.cwd();work=root/'work/YUZE-LU/219/throughput-opt';runtime=Path('D:/Data/电路实验/issue219-runtime-round21')
out=work/'results/resident-ready-r21';out.mkdir(exist_ok=False)
files={}
def add(folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.vvp'):
            files[prefix+'/'+p.relative_to(folder).as_posix()]=p
add(work/'results/resident-batch-terminal-r21','batch-terminal')
add(runtime,'runtime')
# Freeze both sources and receipts, not mutable live remote logs.
for num,name in ((301,'resident-ready-r2'),(302,'resident-ready-strict-r2')):
    p=Path('D:/Data/电路实验/issue219-runtime-round15')/f'algorithm-fix-{num}-{name}.tar'
    files['frozen/'+p.name]=p
members={};aliases={};stored={};archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for name,p in files.items():
        data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();members[name]={'sha256':sha,'bytes':len(data)}
        if sha in stored:aliases[name]=stored[sha];continue
        stored[sha]=name;entry=tarfile.TarInfo(name);entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
manifest={'issue':219,'pr':220,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes':archive.stat().st_size,'members':members,'aliases':aliases,
    'scope':'terminal 18 cold tiles; pending ready searches and preserved failures; no new whole-model/RTL/system qualification'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'batch-terminal-audit.json').write_bytes((runtime/'batch-terminal-audit.json').read_bytes())
with tarfile.open(archive) as tar:
    seen=set()
    for entry in tar:
        assert hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==members[entry.name]['sha256'];seen.add(entry.name)
    assert seen==set(members)-set(aliases)
print(json.dumps({'archive_sha256':manifest['archive_sha256'],'archive_bytes':manifest['archive_bytes'],
                  'members':len(members),'aliases':len(aliases)}))
