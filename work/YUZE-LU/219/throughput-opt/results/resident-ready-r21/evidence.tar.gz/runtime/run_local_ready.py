import json,sys
from pathlib import Path
sys.path.insert(0,str(Path('project/experiments/block_synthesis').resolve()))
from resident_ready_survey import run
source=Path('work/YUZE-LU/219/throughput-opt/results/resident-batch-partial-r20/generated/region-v209-rows-2.json')
ir=json.loads(Path('D:/Data/电路实验/issue219-runtime-round18/cover-compare-v1/conditional_reuse/ir.json').read_text())
run(source,ir,Path('D:/Data/电路实验/issue219-runtime-round21/local-v209-r2-width2'),width=2)
