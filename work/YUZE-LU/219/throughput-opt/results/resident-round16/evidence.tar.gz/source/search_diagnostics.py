"""Certified optimistic bounds for the current candidate/action family.

These bounds do not limit future tiling, residency or finer service calendars.
They help distinguish a search failure from an excessively rigid action model.
"""
import argparse
import json
import math
from pathlib import Path
from verify_loop_dp import verify
from column_shards import leaves
from dynamic_columns import coefficients
from service_bounds import optimistic_ticks


def minimum_resource_time(binding,members):
    children=leaves(binding)
    if 'phase_execution' in binding:
        return max(c.get('warm_ticks',c['ticks']) for c in children)*len(set(binding['resources'])&members)
    if 'frontier_partition' not in binding:
        # A materialized service holds its primary resources throughout, but
        # the auxiliary resources only for their actual fixed-offset phase.
        # Charging every resource for the whole service is not a lower bound.
        work=0
        for child in children:
            duration=optimistic_ticks(child)
            offsets=child.get('materialized_tile',{}).get('resource_offsets',{})
            if set(offsets)-set(child['resources']):raise ValueError('unknown diagnostic window resource')
            for resource in set(child['resources'])&members:
                lo,hi=offsets.get(resource,(0,duration))
                if not 0<=lo<hi<=duration:raise ValueError('invalid diagnostic resource window')
                work+=hi-lo
        return work
    spec=binding['parallel_shards'];weighted=[];base=0
    for child in spec['children']:
        b=child['binding'];slope,_=coefficients(child);weight=len(set(b['resources'])&members)
        fixed=b['read_cache']['load_ticks'] if b.get('read_cache') else 0
        base+=weight*(slope+fixed);weighted.append(weight*slope)
    # Every selected child has at least one column. For an optimistic bound,
    # give all remaining columns to the cheapest resource-weighted slope.
    return base+(spec['columns']-len(children))*min(weighted)


def relaxation(tasks,hardware):
    """Lower bound for a supplied action pool, without assuming a schedule."""
    # Prefix reuse can only reduce a binding as far as its all-hit endpoint.
    lower={t['id']:min(optimistic_ticks(b) for b in t['bindings']) for t in tasks}
    resources={}; mandatory={}
    for t in tasks:
        required=set.intersection(*(set(b['resources']) for b in t['bindings']))
        for resource in required:
            mandatory.setdefault(resource,[]).append(t)
    for resource,assigned in mandatory.items():
        capacity=hardware['resources'][resource]
        work=sum(min(minimum_resource_time(b,{resource}) for b in t['bindings']) for t in assigned)
        resources[resource]={'mandatory_tasks':len(assigned),'minimum_reserved_work':work,
            'capacity':capacity,'completion_lower_bound':(work+capacity-1)//capacity}
    finish={};pending={t['id']:t for t in tasks}
    while pending:
        ready=[t for t in pending.values() if all(p in finish for p in t.get('after',[]))]
        if not ready:raise ValueError('diagnostic dependency cycle')
        for t in ready:
            finish[t['id']]=lower[t['id']]+max((finish[p] for p in t.get('after',[])),default=0)
            del pending[t['id']]
    critical=max(finish.values(),default=0)
    # A task may require some M without requiring a particular M instance.
    # Per-instance intersections miss this unavoidable pooled occupancy.
    # Each bound counts resource-units*time, then divides by total capacity.
    pools={name:set(members) for name,members in hardware.get('resource_pools',{}).items()}
    for group,meta in hardware.get('leaf_inventory',{}).items():
        for macro in meta['macros']:
            resource=group+'.'+macro
            if resource in hardware['resources']:pools.setdefault('native.'+macro,set()).add(resource)
    channels={r for r in hardware['resources'] if r.startswith('virtual-memory.channel.')}
    if channels:pools.setdefault('virtual-memory.channels',channels)
    pooled={}
    for name,members in pools.items():
        if not members or not members<=hardware['resources'].keys():raise ValueError('invalid resource pool')
        capacity=sum(hardware['resources'][r] for r in members)
        work=sum(min(minimum_resource_time(b,members) for b in t['bindings']) for t in tasks)
        pooled[name]={'resources':sorted(members),'capacity':capacity,'minimum_resource_time':work,
                      'completion_lower_bound':(work+capacity-1)//capacity}
    best=max([critical]+[r['completion_lower_bound'] for r in resources.values()]+
             [r['completion_lower_bound'] for r in pooled.values()])
    return {'critical_path_lower_bound':critical,
        'mandatory_resource_bounds':resources,'completion_lower_bound':best,
        'resource_pool_bounds':pooled,
        'assumptions':'same declared serial/cooperative/native-tile candidates and fixed auxiliary windows, optimistic all-hit endpoints; no new hardware',
        'scope':'proof within current declared action family; not a physical performance or global hardware bound'}


def bounds(tasks,hardware,plan):
    verify(tasks,hardware,plan)
    result=relaxation(tasks,hardware);best=result['completion_lower_bound']
    if best>plan['makespan']:raise ValueError('invalid lower bound exceeds verified schedule')
    return {'verified_plan_makespan':plan['makespan'],**result,
        'maximum_time_reduction_fraction_with_current_actions':1-best/plan['makespan']}


def main():
    p=argparse.ArgumentParser();p.add_argument('ir',type=Path);p.add_argument('plan',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();ir=json.loads(a.ir.read_text());plan=json.loads(a.plan.read_text())
    result=bounds(ir['tasks'],ir['hardware'],plan)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('verified_plan_makespan','completion_lower_bound','maximum_time_reduction_fraction_with_current_actions')}))


if __name__=='__main__':main()
