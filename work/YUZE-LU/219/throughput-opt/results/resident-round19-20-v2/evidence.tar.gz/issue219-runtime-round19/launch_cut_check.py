"""Freeze failing/current algorithms for an independent-machine cut check."""
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd()
runtime=Path('D:/Data/电路实验/issue219-runtime-round19');name='algorithm-fix-294-resident-overlap-cut-check'
old=runtime/'failed-v3-source.tar'
with tarfile.open(old,'w') as t:
    for f in sorted((runtime/'overlap-cover-dp-v3/source').glob('*.py')):
        data=f.read_text(encoding='utf-8').encode();entry=tarfile.TarInfo(f.name);entry.size=len(data);t.addfile(entry,io.BytesIO(data))
# Source inputs are immutable copies under the authorized common directory.
inputs=m.BASE+'/resident-overlap-r19-inputs'
subprocess.run(['ssh',m.REMOTE,'mkdir',inputs],check=True,timeout=30)
for source,target in ((Path('D:/Data/电路实验/issue219-runtime-round18/cover-compare-v1/conditional_reuse/ir.json'),'ir.json'),
    (Path('D:/Data/电路实验/issue219-runtime-round18/cover-compare-v1/conditional_reuse/selected.json'),'selected.json'),(old,'failed-v3-source.tar')):
    subprocess.run(['scp',str(source),m.REMOTE+':'+inputs+'/'+target],check=True,timeout=120)
sys.argv=['launch_fix.py',name,'resident-overlap-cut-check.sbatch',inputs+'/ir.json',inputs+'/selected.json',inputs+'/failed-v3-source.tar']
m.main()
receipt=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json')
(runtime/receipt.name).write_bytes(receipt.read_bytes())
