"""Submit the new full-graph stage only after the current source pool succeeds."""
import importlib.util
import json
from pathlib import Path
import sys

spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd()
original=m.subprocess.check_output
def dependent(command,*args,**kwargs):
    if command[:3]==['ssh',m.REMOTE,'sbatch']:command=command[:3]+['--dependency=afterok:101626:101646']+command[3:]
    return original(command,*args,**kwargs)
m.subprocess.check_output=dependent
base=m.BASE+'/algorithm-fix-292-resident-reuse-full-tailfix/generated/'
sys.argv=['launch_fix.py','algorithm-fix-295-resident-overlap-full-live-frontier','resident-overlap.sbatch',base+'ir.json',base+'selected.json']
m.main()
source=Path('D:/Data/电路实验/issue219-runtime-round15/algorithm-fix-295-resident-overlap-full-live-frontier.json')
r=json.loads(source.read_text());r['dependency']='afterok:101626:101646'
Path('D:/Data/电路实验/issue219-runtime-round19/algorithm-fix-295-resident-overlap-full-live-frontier.json').write_text(json.dumps(r,indent=2)+'\n')
