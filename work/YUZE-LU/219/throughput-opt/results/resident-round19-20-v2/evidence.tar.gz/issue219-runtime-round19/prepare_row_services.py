import json
from pathlib import Path
import sys

root=Path.cwd();sys.path.insert(0,str(root/'project/experiments/block_synthesis'))
from resident_row_probe import prepare

runtime=Path('D:/Data/电路实验/issue219-runtime-round20');runtime.mkdir(exist_ok=True)
ir=json.loads(Path('D:/Data/电路实验/issue219-runtime-round18/cover-compare-v1/conditional_reuse/ir.json').read_text())
formats={(op['width'],op['shift']) for recipe in ir['resident_recipes'].values() for op in recipe['graph']['operations'] if op['kind']=='M'}
origin=Path('D:/Data/电路实验/issue219-runtime-round19/overlap-rtl-v2')
bank=next(p for p in origin.glob('*.v') if 's_sram' in p.name)
manifest=prepare(origin,bank,runtime/'row-services-v1',formats)
print(json.dumps({'cases':len(manifest['cases']),'formats':manifest['formats']}))
