import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

name='algorithm-fix-295-resident-overlap-full-live-frontier'
host='yuzelu@10.129.166.172';base='/public/home/yuzelu/project-circuit/LLMHardwareDesign/issue-219-block-search'
root=base+'/'+name;runtime=Path('D:/Data/电路实验/issue219-runtime-round19')
archive=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.tar')
def remote(command):return subprocess.check_output(['ssh',host,command],timeout=30).decode().strip()
gate=remote('sacct -j 101646 --format=JobID,State,ExitCode -n -P')
if '101646|COMPLETED|0:0' not in gate:raise ValueError('independent cut check is not accepted')
if remote('sha256sum '+shlex.quote(root+'/source.tar')).split()[0]!=hashlib.sha256(archive.read_bytes()).hexdigest():
    raise ValueError('unsubmitted frozen archive changed')
remote('test ! -e '+shlex.quote(root+'/slurm.log'))
queued=remote("squeue -u yuzelu --name=yzl-resident-overlap -h -o '%i %j %E'")
if queued:raise ValueError('an overlap job already exists: '+queued)
state=remote("squeue -j 101626 -h -o '%T'")
dependency='afterok:101626' if state else None
if not dependency:
    prior=remote('sacct -j 101626 --format=JobID,State,ExitCode -n -P')
    if '101626|COMPLETED|0:0' not in prior:raise ValueError('full source pool is not accepted')
parts=['sbatch','--parsable','--output='+root+'/slurm.log']
if dependency:parts+=['--dependency='+dependency]
parts+=[root+'/resident-overlap.sbatch',root,base+'/algorithm-fix-292-resident-reuse-full-tailfix/generated/ir.json',
        base+'/algorithm-fix-292-resident-reuse-full-tailfix/generated/selected.json']
job=remote(' '.join(map(shlex.quote,parts)))
with tarfile.open(archive) as tar:manifest={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile()}
receipt={'directory':root,'job':job,'source_sha256':manifest,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'dependency':dependency,'accepted_completed_gate':gate,
    'prior_submission':'No job created: afterok on already-purged completed gate 101646 was rejected. Same untouched frozen source submitted after sacct confirmed COMPLETED 0:0.'}
(runtime/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'job':job,'directory':root,'dependency':dependency}))
