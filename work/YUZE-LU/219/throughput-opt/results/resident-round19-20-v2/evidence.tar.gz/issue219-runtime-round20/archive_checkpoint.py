import hashlib
import json
from pathlib import Path
import shutil
import tarfile

root=Path.cwd();work=root/'work/YUZE-LU/219/throughput-opt';out=work/'results/resident-round19-20'
out.mkdir(exist_ok=False)
archive=out/'evidence.tar.gz';members={}
inputs=[(Path('D:/Data/电路实验/issue219-runtime-round19'),'issue219-runtime-round19'),
        (Path('D:/Data/电路实验/issue219-runtime-round20'),'issue219-runtime-round20')]
for name in ('resident-overlap-cut-terminal-r19','resident-overlap-stress-first-r20',
             'resident-overlap-stress-terminal-r20','resident-batch-partial-r20'):
    inputs.append((work/'results'/name,'server/'+name))
def keep(path,relative):
    if any(x in ('__pycache__','temp') for x in relative.parts):return False
    return path.is_file() and path.suffix not in ('.vvp','.pyc','.pyo','.dmp')
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for directory,prefix in inputs:
        for file in sorted(directory.rglob('*')):
            rel=file.relative_to(directory)
            if not keep(file,rel):continue
            name=prefix+'/'+rel.as_posix();data=file.read_bytes()
            members[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
            tar.add(file,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
    checked=set()
    for member in tar:
        if not member.isfile():raise ValueError('non-file archive member')
        data=tar.extractfile(member).read();expected=members[member.name]
        if len(data)!=expected['bytes'] or hashlib.sha256(data).hexdigest()!=expected['sha256']:raise ValueError('archive member differs')
        checked.add(member.name)
    if checked!=members.keys():raise ValueError('archive index is incomplete')
for src,dst in ((Path('D:/Data/电路实验/issue219-runtime-round19/audit-final.json'),'overlap-audit.json'),
                (Path('D:/Data/电路实验/issue219-runtime-round20/audit-v1.json'),'row-audit.json'),
                (Path('D:/Data/电路实验/issue219-runtime-round20/row-services-v1/qualification.json'),'row-qualification.json')):
    shutil.copyfile(src,out/dst)
manifest={'schema':1,'issue':219,'pr':220,'stage':'partial; active goal; not 20%/system qualification',
    'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,
    'members':members,'scope':'raw successful/failed frozen sources, native probes, logs, finite-S certificates and verified server files',
    'excluded':'simulator binaries, caches, temp; previous round18 evidence remains a separately indexed dependency',
    'previous_round18_archive_sha256':'e5cc481e76b61fc79cb0f66dfe91d069deb933154dd4dc32bfe8a9b0b9ada93b'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(members),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']}))
