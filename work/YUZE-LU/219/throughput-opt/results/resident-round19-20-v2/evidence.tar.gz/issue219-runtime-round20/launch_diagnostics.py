import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd()
runtime=Path('D:/Data/电路实验/issue219-runtime-round20');base=m.BASE
inputs=base+'/resident-row-r20-inputs'
subprocess.run(['ssh',m.REMOTE,'mkdir',inputs],check=True,timeout=30)
files={'row-timing.json':runtime/'row-services-v1/qualification.json',
       'stress-case.json':Path('D:/Data/电路实验/issue219-runtime-round19/overlap-survey-v2/region-1-alternate-declared-binding-program-0.json'),
       'stress_overlap.py':m.ROOT/'work/YUZE-LU/219/throughput-opt/stress_overlap.py'}
staged={}
for name,file in files.items():
    subprocess.run(['scp',str(file),m.REMOTE+':'+inputs+'/'+name],check=True,timeout=60)
    actual=subprocess.check_output(['ssh',m.REMOTE,'sha256sum',inputs+'/'+name],timeout=30).decode().split()[0]
    expected=hashlib.sha256(file.read_bytes()).hexdigest()
    if actual!=expected:raise ValueError('staged source differs')
    staged[name]={'local':str(file),'server':inputs+'/'+name,'sha256':actual}
(runtime/'staged-inputs.json').write_text(json.dumps(staged,indent=2)+'\n')
original=m.subprocess.check_output
def dependent(command,*args,**kwargs):
    if command[:3]==['ssh',m.REMOTE,'sbatch']:command=command[:3]+['--dependency=afterok:101626']+command[3:]
    return original(command,*args,**kwargs)
m.subprocess.check_output=dependent
sys.argv=['launch_fix.py','algorithm-fix-296-resident-reuse-full-numeric','resident-model-loops.sbatch',
    base+'/algorithm-fix-277-phased-tile-full/generated/ir.json',
    base+'/algorithm-fix-292-resident-reuse-full-tailfix/generated/ir.json',
    base+'/algorithm-fix-292-resident-reuse-full-tailfix/generated/selected.json',
    base+'/resident-profile-r15-553051e41105.tar.gz',
    base+'/algorithm-fix-43-calibration/generated/calibration.json',
    base+'/algorithm-fix-53-values/generated/activation-calibration.json',
    base+'/algorithm-fix-43-calibration/generated/logits.npz',
    base+'/algorithm-fix-284-future-selected-numeric/generated/report.json',
    base+'/algorithm-fix-38-final/inputs/blocks']
m.main()
receipt=Path('D:/Data/电路实验/issue219-runtime-round15/algorithm-fix-296-resident-reuse-full-numeric.json')
r=json.loads(receipt.read_text());r['dependency']='afterok:101626';(runtime/receipt.name).write_text(json.dumps(r,indent=2)+'\n')
m.subprocess.check_output=original
for name,script,args in (
    ('algorithm-fix-297-overlap-pure-stress','resident-overlap-stress.sbatch',[inputs+'/stress-case.json',inputs+'/stress_overlap.py']),
    ('algorithm-fix-298-resident-batch-survey','resident-batch.sbatch',[
        base+'/resident-overlap-r19-inputs/ir.json',base+'/resident-overlap-r19-inputs/selected.json',inputs+'/row-timing.json'])):
    sys.argv=['launch_fix.py',name,script,*args];m.main()
    receipt=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json');(runtime/receipt.name).write_bytes(receipt.read_bytes())
