import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd()
runtime=Path('D:/Data/电路实验/issue219-runtime-round20');base=m.BASE;inputs=base+'/resident-row-r20-inputs'
source=m.ROOT/'work/YUZE-LU/219/throughput-opt/stress_overlap.py';target=inputs+'/stress_overlap_v2.py'
subprocess.run(['ssh',m.REMOTE,'test','!','-e',target],check=True,timeout=30)
subprocess.run(['scp',str(source),m.REMOTE+':'+target],check=True,timeout=60)
expected=hashlib.sha256(source.read_bytes()).hexdigest()
if subprocess.check_output(['ssh',m.REMOTE,'sha256sum',target],timeout=30).decode().split()[0]!=expected:raise ValueError('stress driver stage differs')
for name,script,args in (
    ('algorithm-fix-299-overlap-pure-stress-metadata','resident-overlap-stress.sbatch',[inputs+'/stress-case.json',target]),
    ('algorithm-fix-300-resident-batch-layout','resident-batch.sbatch',[
        base+'/resident-overlap-r19-inputs/ir.json',base+'/resident-overlap-r19-inputs/selected.json',inputs+'/row-timing.json','--first','v209'])):
    sys.argv=['launch_fix.py',name,script,*args];m.main()
    receipt=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json');(runtime/receipt.name).write_bytes(receipt.read_bytes())
