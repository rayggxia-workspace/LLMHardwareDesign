import importlib.util
from pathlib import Path
import sys

spec=importlib.util.spec_from_file_location('owned_launcher',Path('D:/Data/电路实验/issue219-runtime-round15/launch_fix.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=Path.cwd();base=m.BASE
name='algorithm-fix-300-resident-batch-layout'
sys.argv=['launch_fix.py',name,'resident-batch.sbatch','--',base+'/resident-overlap-r19-inputs/ir.json',
    base+'/resident-overlap-r19-inputs/selected.json',base+'/resident-row-r20-inputs/row-timing.json','--first','v209']
m.main()
source=Path('D:/Data/电路实验/issue219-runtime-round15')/(name+'.json')
Path('D:/Data/电路实验/issue219-runtime-round20',source.name).write_bytes(source.read_bytes())
