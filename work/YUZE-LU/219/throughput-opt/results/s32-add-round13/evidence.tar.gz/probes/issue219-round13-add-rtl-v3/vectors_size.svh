localparam integer VECTOR_WORDS=12816;
