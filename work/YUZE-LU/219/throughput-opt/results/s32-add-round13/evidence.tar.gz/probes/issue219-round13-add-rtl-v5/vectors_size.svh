localparam integer VECTOR_WORDS=41040;
