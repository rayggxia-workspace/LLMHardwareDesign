"""Derive finite nine-peer SRAM regression without touching old testbench."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OLD=ROOT/'project/experiments/mother_control_v1'
HERE=Path(__file__).resolve().parent
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
wires=(OLD/'tb_wires.svh').read_text()
wires=replace(wires,'reg [31:0] local_image_id0_i;\nreg [31:0] local_image_id1_i;\nreg [1:0] local_enabled_i;', 'reg [287:0] local_image_ids_i;\nreg [8:0] local_enabled_i;')
wires=wires.replace('[7:0] trace_live_tokens_o','[15:0] trace_live_tokens_o')
for sig in ('trace_block_active_o','trace_terminal_full_o','trace_READY_full_o'):
    wires=wires.replace('[1:0] '+sig,'[8:0] '+sig)
wires=replace(wires,'mother_control_64 dut(.*);','reg recover_valid_i;\nwire recover_ready_o;\nwire [31:0] protocol_fault_count_o;\nmother_control_native64 dut(.*);')
(HERE/'tb_native_wires.svh').write_text(wires)
init=(OLD/'tb_init.svh').read_text()
init=replace(init,'local_image_id0_i=0;\nlocal_image_id1_i=0;', 'local_image_ids_i=0;recover_valid_i=0;')
(HERE/'tb_native_init.svh').write_text(init)
tb=(OLD/'tb_mother.sv').read_text().replace('module tb_mother;','module tb_mc_native;')
tb=tb.replace('tb_wires.svh','tb_native_wires.svh').replace('tb_init.svh','tb_native_init.svh')
tb=tb.replace('[0:1]','[0:8]').replace('[1:0] child_busy','[8:0] child_busy').replace('k<2','k<9')
start=tb.index('  reg ret_locked=')
end=tb.index('  integer k;',start)
tb=tb[:start]+'''  reg ret_locked=0;
  reg [3:0] ret_lock_source=0,ret_rr=0;
  reg [3:0] selected_source;
  integer scan,choice;
  integer min_active=1,max_active=0,active_count;
  integer ready_mask=0;
  reg [511:0] held_result,held_task;
  reg previous_result_stall=0,previous_task_stall=0;
  always @* begin
    selected_source=ret_lock_source;choice=0;
    if(!ret_locked) begin
      selected_source=ret_rr;
      for(scan=8;scan>=0;scan=scan-1) begin
        choice=int'(ret_rr)+scan;
        if(choice>=9) choice=choice-9;
        if(child_return_valid[choice]) selected_source=4'(choice);
      end
    end
  end
'''+tb[end:]
tb=replace(tb,'child_return[b][0+:16]<=1;', 'child_return[b][0+:16]<=2;')
tb=replace(tb,'child_call[b][32+:32]+(bad_return!=0 ? 1 : 0)', 'child_call[b][32+:32]+(bad_return!=0 ? 1 : 0)')
tb=replace(tb,'child_return[b][136+:8]<=kind<2 ? 0 : 255;', 'child_return[b][136+:8]<=kind<2 ? 8\'(b) : 255;\n      child_return[b][352+:32]<=child_call[b][224+:32];child_return[b][384+:32]<=child_call[b][192+:32];')
tb=replace(tb,'ret_rr<=!selected_source;', "ret_rr<=selected_source==8 ? 0 : selected_source+1'b1;")
tb=replace(tb,'task_target_o>=2', 'task_target_o>=9')
tb=replace(tb,'task_packet_o[0+:16]!=1', 'task_packet_o[0+:16]!=2')
tb=replace(tb,'(task_target_o==0 ? local_image_id0_i : local_image_id1_i)', 'local_image_ids_i[32*task_target_o+:32] || task_packet_o[224+:32]!=start_generation_i')
tb=tb.replace('task_target_o[0]', 'task_target_o[3:0]')
tb=replace(tb,'if(task_target_o==1 && ready1!=0 && error_target!=1) begin peer_phase[1]<=1; peer_timer[1]<=ready_delay; end', 'if(ready_mask[task_target_o[4:0]] && error_target!=int\'(task_target_o)) begin peer_phase[task_target_o[3:0]]<=1; peer_timer[task_target_o[3:0]]<=ready_delay; end')
tb=replace(tb,'rst_ni && deploy_valid_i && task_target_o<2', 'rst_ni && task_target_o<9')
tb=replace(tb,"32'h01930001", "32'h02500002")
tb=replace(tb,"32'h17630001", "32'h02590001")
tb=replace(tb,'local_image_id0_i=100; local_image_id1_i=101; local_enabled_i=3;', "for(n=0;n<9;n=n+1) local_image_ids_i[32*n+:32]=32'(100+n);local_enabled_i=9'h1ff;")
tb=replace(tb, 'n=$value$plusargs("READY1=%d",ready1);', 'n=$value$plusargs("READY1=%d",ready1);n=$value$plusargs("READY_MASK=%d",ready_mask);n=$value$plusargs("MIN_ACTIVE=%d",min_active);')
tb=replace(tb, 'if(result_valid_o && result_ready_i) begin', '''active_count=$countones(trace_block_active_o);
      if(active_count>max_active) max_active=active_count;
      if(previous_result_stall) assert(result_valid_o && held_result=={230'b0,result_job_o,result_epoch_o,result_sequence_o,result_status_o,result_error_pc_o,result_source_o,result_child_error_pc_o,result_failed_task_sequence_o,result_confirmed_read_bytes_o,result_confirmed_write_bytes_o,result_counter_overflow_o,result_saturated_o}) else $fatal(1,"native mother result changed under backpressure");
      previous_result_stall<=result_valid_o&&!result_ready_i;
      held_result<={230'b0,result_job_o,result_epoch_o,result_sequence_o,result_status_o,result_error_pc_o,result_source_o,result_child_error_pc_o,result_failed_task_sequence_o,result_confirmed_read_bytes_o,result_confirmed_write_bytes_o,result_counter_overflow_o,result_saturated_o};
      if(previous_task_stall) assert(task_valid_o&&held_task==task_packet_o) else $fatal(1,"native mother task withdrew/changed");
      previous_task_stall<=task_valid_o&&!task_ready_i;held_task<=task_packet_o;
      if(result_valid_o && result_ready_i) begin''')
tb=replace(tb, '    $display("PASS mother calls=', '    assert(max_active>=min_active) else $fatal(1,"native resident concurrency was not exercised");\n    $display("PASS mother calls=')
tb=replace(tb, '    $finish;\n  end', '    $display("PASS native residents=%0d protocol_faults=%0d",max_active,protocol_fault_count_o);\n    $finish;\n  end')
(HERE/'tb_mc_native.sv').write_text(tb)
