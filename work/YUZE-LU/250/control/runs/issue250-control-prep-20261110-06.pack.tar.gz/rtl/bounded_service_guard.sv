`timescale 1ns/1ps
// Candidate service adapter boundary. Not a controller ISA decoder or a M/G core.
// Two slots include active+prepared. One provider operation and one S write
// may be outstanding. Full tickets are never narrowed to the pool's 8bit epoch.
module bounded_service_guard #(
  parameter logic [31:0] ABI_ID = 32'h02500001,
  parameter logic [31:0] TOPOLOGY = 32'd25001,
  parameter logic [31:0] CAPACITY = 32'd1,
  parameter logic [31:0] NUMERIC_ID = 32'h53333251,
  parameter logic [31:0] LAYOUT_ID = 32'h4b313633
)(
  input logic clk, reset,
  input logic cmd_valid, output logic cmd_ready,
  input logic [511:0] cmd_ticket,
  input logic [127:0] cmd_job_key,
  input logic [31:0] cmd_abi, cmd_topology, cmd_capacity, cmd_numeric, cmd_layout,
  input logic [7:0] cmd_resource, cmd_service,
  input logic [7:0] cmd_provider, cmd_function,
  input logic [15:0] cmd_native_op,
  input logic [255:0] cmd_payload,
  input logic cmd_stored,
  input logic [1:0] cmd_store_words,
  input logic [9:0] cmd_destination,
  output logic native_valid, input logic native_ready,
  output logic [511:0] native_ticket,
  output logic [7:0] native_resource, native_service,
  output logic [255:0] native_payload,
  input logic result_valid, output logic result_ready,
  input logic [511:0] result_ticket,
  input logic [255:0] result_data,
  input logic result_error,
  output logic s_valid, input logic s_ready,
  output logic [511:0] s_ticket,
  output logic s_word,
  output logic [9:0] s_address,
  output logic [127:0] s_data,
  input logic ack_valid, output logic ack_ready,
  input logic [511:0] ack_ticket,
  input logic ack_word, ack_error,
  output logic terminal_valid, input logic terminal_ready,
  output logic [511:0] terminal_ticket,
  output logic [7:0] terminal_error,
  output logic terminal_stored, terminal_partial,
  output logic [255:0] terminal_data,
  input logic cancel_valid,
  input logic [127:0] cancel_job_key,
  input logic timeout_valid, clear_quarantine, resume_after_drain,
  output logic halted, quarantine, quiescent,
  output logic [1:0] occupied_slots,
  output logic [31:0] rejected_protocol_events, committed_words
);
  typedef struct packed {
    logic [511:0] ticket;
    logic [127:0] job_key;
    logic [31:0] abi_id, topology, capacity, numeric_id, layout_id;
    logic [7:0] resource_id, service_id;
    logic [7:0] provider_id, function_id;
    logic [15:0] native_op;
    logic [255:0] payload;
    logic stored;
    logic [1:0] store_words;
    logic [9:0] destination;
  } command_t;
  command_t slots[2];
  logic head, tail;
  logic [1:0] count;
  typedef enum logic [2:0] {IDLE, CHECK, ISSUE, WAIT_RESULT,
                            STORE_REQUEST, STORE_ACK, TERMINAL} state_t;
  state_t state;
  logic [255:0] held_result;
  logic piece;
  logic [7:0] error_q;
  logic stored_q, partial_q;
  wire push = cmd_valid && cmd_ready;
  wire pop = terminal_valid && terminal_ready;
  wire cancel_match = cancel_valid && count != 0 &&
                      cancel_job_key == slots[head].job_key;
  wire stop_now = halted || cancel_match;
  wire bad_cancel = cancel_valid && !cancel_match;
  wire bad_timeout = timeout_valid && !stop_now;
  wire bad_clear = clear_quarantine && !quiescent;
  wire bad_resume = resume_after_drain && !(quiescent && !quarantine);
  wire bad_result = result_valid && result_ready &&
      (state != WAIT_RESULT || result_ticket != slots[head].ticket);
  wire bad_ack = ack_valid && ack_ready &&
      (state != STORE_ACK || ack_ticket != slots[head].ticket || ack_word != piece);
  wire [2:0] rejected_now = {2'b0,bad_cancel} + {2'b0,bad_timeout} +
      {2'b0,bad_clear} + {2'b0,bad_resume} + {2'b0,bad_result} + {2'b0,bad_ack};
  wire registered_service =
      (slots[head].resource_id == 8'd0 && slots[head].service_id == 8'd32) ||
      (slots[head].resource_id == 8'd2 && slots[head].service_id == 8'd32) ||
      (slots[head].resource_id == 8'd5 &&
       (slots[head].service_id == 8'd32 || slots[head].service_id == 8'd33));
  wire header_ok = slots[head].abi_id == ABI_ID &&
      slots[head].topology == TOPOLOGY && slots[head].capacity == CAPACITY &&
      slots[head].numeric_id == NUMERIC_ID && slots[head].layout_id == LAYOUT_ID &&
      slots[head].native_op == 0 && registered_service &&
      slots[head].provider_id == 1 && slots[head].function_id == 0 &&
      ((!slots[head].stored && slots[head].store_words == 0) ||
       (slots[head].stored && (slots[head].store_words == 1 ||
                              slots[head].store_words == 2) &&
        ({1'b0,slots[head].destination} + {9'd0,slots[head].store_words}) <= 11'd1024));
  assign cmd_ready = !reset && !stop_now && !quarantine && count < 2 &&
      (count == 0 || cmd_job_key == slots[head].job_key);
  assign native_valid = !reset && state == ISSUE;
  assign native_ticket = slots[head].ticket;
  assign native_resource = slots[head].resource_id;
  assign native_service = slots[head].service_id;
  assign native_payload = slots[head].payload;
  // Foreign responses are consumed and counted, never used to retire owner.
  assign result_ready = !reset;
  assign ack_ready = !reset;
  assign s_valid = !reset && state == STORE_REQUEST;
  assign s_ticket = slots[head].ticket;
  assign s_word = piece;
  assign s_address = slots[head].destination + {9'd0,piece};
  assign s_data = piece ? held_result[255:128] : held_result[127:0];
  assign terminal_valid = !reset && state == TERMINAL;
  assign terminal_ticket = slots[head].ticket;
  assign terminal_error = error_q;
  assign terminal_stored = stored_q;
  assign terminal_partial = partial_q;
  assign terminal_data = held_result;
  assign occupied_slots = count;
  assign quiescent = count == 0 && state == IDLE;

  always_ff @(posedge clk) begin
    if (reset) begin
      head <= 0; tail <= 0; count <= 0; state <= IDLE;
      halted <= 0; quarantine <= 0;
      held_result <= 0; piece <= 0; error_q <= 0;
      stored_q <= 0; partial_q <= 0;
      rejected_protocol_events <= 0; committed_words <= 0;
      slots[0] <= '0; slots[1] <= '0;
    end else begin
      case ({push,pop})
        2'b10: count <= count + 1'b1;
        2'b01: count <= count - 1'b1;
        default: ;
      endcase
      if (push) begin
        slots[tail] <= '{cmd_ticket,cmd_job_key,cmd_abi,cmd_topology,cmd_capacity,
          cmd_numeric,cmd_layout,cmd_resource,cmd_service,cmd_provider,cmd_function,cmd_native_op,
          cmd_payload,cmd_stored,cmd_store_words,cmd_destination};
        tail <= !tail;
      end
      if (pop) head <= !head;
      if (cancel_match) halted <= 1;
      if (rejected_now != 0)
        rejected_protocol_events <= rejected_protocol_events + {29'd0,rejected_now};
      if (timeout_valid) begin
        if (stop_now) quarantine <= 1;
      end
      if (clear_quarantine) begin
        if (quiescent) quarantine <= 0;
      end
      if (resume_after_drain) begin
        if (quiescent && !quarantine) halted <= 0;
      end
      case (state)
        IDLE: if (count != 0) state <= CHECK;
        CHECK: begin
          held_result <= 0; piece <= 0; stored_q <= 0; partial_q <= 0;
          if (stop_now) begin error_q <= 8'd5; state <= TERMINAL; end
          else if (!header_ok) begin error_q <= 8'd1; state <= TERMINAL; end
          else begin error_q <= 0; state <= ISSUE; end
        end
        // A proposed valid is retained through cancel until the receiver accepts.
        ISSUE: if (native_valid && native_ready) state <= WAIT_RESULT;
        WAIT_RESULT: if (result_valid && result_ready && result_ticket == slots[head].ticket) begin
          held_result <= result_data;
          if (result_error) begin error_q <= 8'd2; state <= TERMINAL; end
          else if (stop_now) begin error_q <= 8'd5; state <= TERMINAL; end
          else if (slots[head].stored) state <= STORE_REQUEST;
          else state <= TERMINAL;
        end
        STORE_REQUEST: if (s_valid && s_ready) state <= STORE_ACK;
        STORE_ACK: if (ack_valid && ack_ready && ack_ticket == slots[head].ticket && ack_word == piece) begin
          if (ack_error) begin error_q <= 8'd3; state <= TERMINAL; end
          else begin
            committed_words <= committed_words + 1'b1;
            partial_q <= 1;
            if (stop_now) begin error_q <= 8'd5; state <= TERMINAL; end
            else if ((!piece && slots[head].store_words == 1) || piece) begin
              stored_q <= 1; partial_q <= 0; state <= TERMINAL;
            end else begin piece <= 1; state <= STORE_REQUEST; end
          end
        end
        TERMINAL: if (pop) state <= IDLE;
        default: state <= IDLE;
      endcase
    end
  end
endmodule
