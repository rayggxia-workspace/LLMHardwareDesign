#!/usr/bin/env bash
#SBATCH --job-name=yzl-dyn32-proof
#SBATCH --partition=c64
#SBATCH --nodes=1
#SBATCH --ntasks=6
#SBATCH --cpus-per-task=10
#SBATCH --time=0
set -euo pipefail
root=$SLURM_SUBMIT_DIR
cd "$root"
sha256sum -c source.sha256 > source-check.log
scontrol show job "$SLURM_JOB_ID" > allocation.txt
pids=()
for seed in 25001 25002 25003 25004 25005 25006; do
 srun --exact -n1 -c10 --cpu-bind=cores bash \
  "$root/source/project/experiments/w8a16_dynamic/rank.sh" "$root" "$seed" \
  > "seed-$seed.log" 2>&1 &
 pids+=("$!")
done
failed=0
for pid in "${pids[@]}"; do wait "$pid" || failed=1; done
exit "$failed"
