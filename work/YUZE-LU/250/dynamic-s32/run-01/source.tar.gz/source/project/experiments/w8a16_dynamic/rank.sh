#!/usr/bin/env bash
set -euo pipefail
root=$1
seed=$2
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=10 OPENBLAS_NUM_THREADS=10
export PYTHONPATH=/public/home/yuzelu/project-circuit/LLMHardwareDesign/operator-graphs-20261026/deps
python=/public/home/yuzelu/RuizhiLiang/issue61-server-models-20261023/venv-modern/bin/python
"$python" -B "$root/source/project/experiments/w8a16_dynamic/oracle.py" \
 --seed "$seed" --out "$root/seed-$seed/oracle.json"
if [[ "$seed" == 25001 ]]; then
 "$python" -B "$root/source/project/experiments/w8a16_dynamic/extract_checkpoint.py" \
  --out "$root/checkpoint"
fi
