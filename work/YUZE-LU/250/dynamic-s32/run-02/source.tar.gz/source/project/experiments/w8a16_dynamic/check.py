"""Independent model vectors and strict Verilator full-K merge/raw checks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
from oracle import a_digits, b_digits, finish, partials, S32_MIN, S32_MAX


def pack(values, bits):
    return sum((int(v) & ((1 << bits) - 1)) << (i * bits) for i, v in enumerate(values))


def generate(out, seed, checkpoint):
    rng = random.Random(seed); vectors = []; raw_vectors = []; tag = 0
    def emit(kind, key=1, full=128, kk=0, length=128, n=8, ai=0, bi=0,
             shift=16, raw=None, error=0, done=0, result=None):
        nonlocal tag
        raw = [0] * 8 if raw is None else raw + [0] * (8-len(raw))
        result = [0] * 8 if result is None else result + [0] * (8-len(result))
        fields = [kind, key, tag, full, kk, length, n, ai, bi, shift, pack(raw, 32),
                  error, done, pack(result, 32)]
        vectors.append(' '.join(format(int(v), 'x') for v in fields)); tag += 1

    samples = []
    for i, k in enumerate((1, 2, 16, 127, 128, 129, 512)):
        n = i % 8 + 1
        edges = [S32_MIN, S32_MAX, -1, 0, 1, 127, 128, 32768, -32769]
        a = [rng.choice(edges) if j % 2 else rng.randrange(S32_MIN, S32_MAX+1) for j in range(k)]
        b = [[rng.choice(edges) if (j+c) % 2 else rng.randrange(S32_MIN, S32_MAX+1)
              for c in range(n)] for j in range(k)]
        samples.append(dict(A=a, B=b, shift=(0, 1, 16, 31, 47, 63, 32)[i], role='boundary'))
    if checkpoint:
        for sample in json.loads(checkpoint.read_text()):
            samples.append(dict(A=sample['A'], B=sample['B'],
                                shift=sample['node']['attributes']['shift'], role=sample['role']))
    for index, sample in enumerate(samples):
        a, b, shift = sample['A'], sample['B'], sample['shift']; n = len(b[0]); key = (seed << 64) + index
        emit(0, key, len(a), n=n, shift=shift)
        emit(0, key+1, len(a), n=n, error=1)
        packets = list(partials(a, b))
        for j, packet in enumerate(packets):
            args = dict(key=key, full=len(a), kk=packet['kk'], length=packet['length'], n=n,
                        ai=packet['ai'], bi=packet['bi'], raw=packet['raw'])
            if j % 13 == 0:
                emit(1, **dict(args, key=key+1), error=1)
                emit(1, **dict(args, ai=3), error=1)
                emit(1, **dict(args, raw=[S32_MIN]*n), error=1)
            final = j == len(packets)-1
            result = [finish(sum(x*row[c] for x,row in zip(a,b)), shift) for c in range(n)] if final else None
            emit(1, **args, done=int(final), result=result)
            # Existing native M computes one zero-padded K128 signed digit.
            if len(raw_vectors) < 360:
                aa = [a_digits(x)[packet['ai']] for x in a[packet['kk']:packet['kk']+packet['length']]]
                bb = [[b_digits(x)[packet['bi']] for x in row] for row in b[packet['kk']:packet['kk']+packet['length']]]
                aa += [0] * (128-len(aa)); bb += [[0]*n for _ in range(128-len(bb))]
                # Beat-major, then N-major sixteen K bytes matches M port.
                payload = [bb[beat*16+k][c] if c<n else 0
                           for beat in range(8) for c in range(8) for k in range(16)]
                raw_vectors.append(' '.join(format(v, 'x') for v in
                    [len(raw_vectors), n, pack(aa,16), pack(payload,8), pack(packet['raw']+[0]*(8-n),32)]))
        emit(1, key, len(a), n=n, error=1)
    # Invalid/cancel/reuse must not retain hidden live owners.
    emit(0, full=0, error=1); emit(0, n=0, error=1); emit(0, n=9, error=1)
    emit(0, key=99); emit(2, key=100, error=1); emit(2, key=99, done=1)
    emit(2, key=99, error=1); emit(3, error=1)
    (out/'merge.txt').write_text('\n'.join(vectors)+'\n')
    (out/'raw.txt').write_text('\n'.join(raw_vectors)+'\n')
    return dict(merge_commands=len(vectors), raw_groups=len(raw_vectors), samples=len(samples),
                checkpoint_roles=sorted({v['role'] for v in samples if v['role']!='boundary'}),
                vectors_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'merge.txt',out/'raw.txt')})


def main(args):
    assert os.environ.get('SLURM_JOB_ID'), 'simulation requires Slurm compute allocation'
    args.out.mkdir(exist_ok=False, parents=True)
    report = generate(args.out, args.seed, args.checkpoint)
    rtl = args.source/'project/rtl/w8a16_v1'; exp=args.source/'project/experiments/w8a16_dynamic'
    for name, files in [('merge',[rtl/'dynamic_s32_merge.sv']),
                        ('raw',[rtl/'m_group_s32.sv',rtl/'scale_group_s32.sv'])]:
        build=args.out/('obj-'+name)
        cmd=[str(args.verilator),'--binary','--timing','--assert','--x-initial','unique','--x-assign','unique',
             '--Wall','-Wno-BLKSEQ','-Wno-TIMESCALEMOD',
             '--top-module','tb_'+name,'--Mdir',str(build),'-j','10',str(exp/('tb_'+name+'.sv'))]+[str(p) for p in files]
        with (args.out/(name+'-build.log')).open('w') as log:
            subprocess.run(cmd,check=True,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
        for initial in (0,1,2):
            with (args.out/(name+'-'+str(initial)+'.log')).open('w') as log:
                subprocess.run([str(build/('Vtb_'+name)),'+vectors='+str(args.out/(name+'.txt')),
                                '+verilator+seed+'+str(args.seed),'+verilator+rand+reset+'+str(initial)],
                               check=True,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    report.update(passed=True, seed=args.seed, slurm_job=os.environ.get('SLURM_JOB_ID'),
                  scope='independent merge and existing raw M/scale-one RTL; not complete S provider')
    (args.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True);parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--checkpoint',type=Path);parser.add_argument('--verilator',type=Path,required=True)
    main(parser.parse_args())
