`timescale 1ns/1ps
module tb_packer;
 reg clk;initial begin clk=0;forever #5 clk=~clk;end
 reg reset=1,cmd_valid=0,out_ready=0;
 wire cmd_ready,s_valid,r_ready,out_valid,out_weight,out_error;
 reg [31:0] cmd_tag,cmd_scalar_base,cmd_k_stride,cmd_n_stride;
 reg cmd_weight,cmd_k_major;reg [2:0] cmd_digit,cmd_n_count;reg [4:0] cmd_k_count;
 wire [31:0] s_address,s_tag,out_tag;
 reg s_ready,r_valid,r_error;reg [31:0] r_tag;reg [127:0] r_data;
 wire [511:0] out_data;
 dynamic_s32_packer dut(.*);
 reg pending;integer delay_left,requests,reads_before;
 reg [31:0] saved_address,saved_tag;reg [1:0] inject;
 function automatic [31:0] scalar(input [33:0] index);
  reg [31:0] raw;reg [3:0] rem11;
  begin
   raw=index[31:0]*32'd1103515245+32'd12345;rem11=4'(index%34'd11);
   case(rem11)
    0:scalar=32'h80000000;1:scalar=32'h7fffffff;2:scalar=32'hffffffff;
    3:scalar=0;4:scalar=127;5:scalar=32768;6:scalar=-32'd32769;
    default:scalar=raw;
   endcase
  end
 endfunction
 always @(posedge clk)begin
  if(reset)requests=0;
  else begin
   if(s_valid && s_ready)begin
    if(pending)$fatal(1,"more than one outstanding read");
    pending=1;saved_address=s_address;saved_tag=s_tag;
    delay_left=1+int'($urandom_range(0,6));requests=requests+1;
    $display("PACK_REQ cycle=%0t tag=%0d addr=%0d",$time/10,s_tag,s_address);
   end
   if(r_valid && r_ready)begin
    if(!pending)$fatal(1,"orphan read return");
    pending=0;
   end
  end
 end
 always @(negedge clk)begin
  if(reset)begin pending=0;r_valid=0;s_ready=0;r_error=0;delay_left=0;end
  else begin
   s_ready=!pending && $urandom_range(0,3)!=0;
   if(!pending)r_valid=0;
   else if(delay_left>0)begin delay_left=delay_left-1;r_valid=0;end
   else begin
    r_valid=1;r_tag=saved_tag^(inject==1 ? 32'd1 : 32'd0);r_error=inject==2;
    for(integer j=0;j<4;j=j+1)r_data[j*32+:32]=scalar({saved_address,2'b0}+34'(j));
   end
  end
 end
 string path;integer fd,got,count=0,expected_reads;reg expected_error;reg [511:0] expected,held;
 initial begin
  if(!$value$plusargs("vectors=%s",path))$fatal(1,"vectors missing");
  fd=$fopen(path,"r");if(fd==0)$fatal(1,"vectors unreadable");
  repeat(4)@(negedge clk);reset=0;
  // Drive commands away from the memory peer's negedge activity.
  @(posedge clk);#1;
  while(!$feof(fd))begin
   got=$fscanf(fd,"%h %h %h %h %h %h %h %h %h %h %h %h %h\n",cmd_tag,cmd_weight,
     cmd_k_major,cmd_digit,cmd_scalar_base,cmd_k_stride,cmd_n_stride,cmd_k_count,
     cmd_n_count,inject,expected_error,expected,expected_reads);
   if(got!=13)$fatal(1,"bad packer vector");
   reads_before=requests;cmd_valid=1;
   do @(posedge clk);while(!cmd_ready);
   #1;cmd_valid=0;
   while(!out_valid)begin @(posedge clk);#1;end
   if(out_tag!==cmd_tag || out_weight!==cmd_weight || out_error!==expected_error || out_data!==expected)
    $fatal(1,"packer mismatch cmd%0d tag%0d goterr%0d experr%0d",count,cmd_tag,out_error,expected_error);
   if(pending || requests-reads_before!=expected_reads)$fatal(1,"packer real read count mismatch");
   held=out_data;
   repeat($urandom_range(0,6))begin
    @(posedge clk);#1;if(!out_valid || out_data!==held || cmd_ready)$fatal(1,"held packet changed");
   end
   out_ready=1;@(posedge clk);#1;out_ready=0;count=count+1;
  end
  $display("PASS packer commands=%0d requests=%0d",count,requests);$finish;
 end
 initial begin #1000000000;$fatal(1,"watchdog");end
endmodule
