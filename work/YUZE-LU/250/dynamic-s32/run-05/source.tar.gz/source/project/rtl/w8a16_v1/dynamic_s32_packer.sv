// Finite S128 -> existing A32B / W64B packer. No SRAM and no DDR shortcut.
// S contains dense little-endian S32 scalars. W output is four N columns,
// each sixteen K bytes, matching one existing weight_records 64B fill beat.
// Source traversal may be K-major to avoid rereading a word in AV layout.
module dynamic_s32_packer (
 input wire clk, reset,
 input wire cmd_valid, output wire cmd_ready,
 input wire [31:0] cmd_tag,
 input wire cmd_weight, cmd_k_major,
 input wire [2:0] cmd_digit,
 input wire [31:0] cmd_scalar_base, cmd_k_stride, cmd_n_stride,
 input wire [4:0] cmd_k_count,
 input wire [2:0] cmd_n_count,
 output wire s_valid, input wire s_ready,
 output wire [31:0] s_address, s_tag,
 input wire r_valid, output wire r_ready,
 input wire [31:0] r_tag,
 input wire [127:0] r_data,
 input wire r_error,
 output reg out_valid, input wire out_ready,
 output reg [31:0] out_tag,
 output reg out_weight, out_error,
 output reg [511:0] out_data
);
 localparam [1:0] IDLE=0, WALK=1, WAIT_R=2;
 reg [1:0] state;
 reg weight, k_major;
 reg [2:0] digit, n_count;
 reg [4:0] k_count;
 reg [31:0] base, k_stride, n_stride;
 reg [5:0] element;
 reg [31:0] generation, pending_tag;
 reg [31:0] cached_address;
 reg cache_valid;
 reg [127:0] cache_data;
 wire [5:0] total_elements=weight ? 6'd0 : 6'd16; // zero encodes 64
 wire [3:0] k_index=weight && k_major ? element[5:2] : element[3:0];
 wire [1:0] n_index=!weight ? 2'd0 : (k_major ? element[1:0] : element[5:4]);
 wire [63:0] scalar_index={32'd0,base}+{60'd0,k_index}*{32'd0,k_stride}+
  {62'd0,n_index}*{32'd0,n_stride};
 wire [31:0] address=scalar_index[33:2];
 wire address_bad=|scalar_index[63:34];
 wire inactive={1'b0,k_index}>=k_count || {1'b0,n_index}>=n_count;
 wire hit=cache_valid && cached_address==address;
 wire [31:0] scalar=cache_data[{scalar_index[1:0],5'd0}+:32];
 wire [15:0] a_digit=digit==0 ? {1'b0,scalar[14:0]} :
  digit==1 ? {1'b0,scalar[29:15]} : {{14{scalar[31]}},scalar[31:30]};
 wire [7:0] w_digit=digit==0 ? {1'b0,scalar[6:0]} :
  digit==1 ? {1'b0,scalar[13:7]} : digit==2 ? {1'b0,scalar[20:14]} :
  digit==3 ? {1'b0,scalar[27:21]} : {{4{scalar[31]}},scalar[31:28]};
 wire last_element=weight ? element==63 : element==total_elements-1'b1;
 wire [5:0] destination=weight ? {n_index,k_index} : element;
 assign cmd_ready=!reset && state==IDLE && (!out_valid || out_ready);
 assign s_valid=!reset && state==WALK && !inactive && !hit && !address_bad;
 assign s_address=address;
 assign s_tag=generation;
 assign r_ready=!reset && state==WAIT_R;
 always @(posedge clk) begin
  if(reset)begin
   state<=IDLE;weight<=0;k_major<=0;digit<=0;n_count<=0;k_count<=0;
   base<=0;k_stride<=0;n_stride<=0;element<=0;generation<=0;pending_tag<=0;
   cached_address<=0;cache_valid<=0;cache_data<=0;
   out_valid<=0;out_tag<=0;out_weight<=0;out_error<=0;out_data<=0;
  end else begin
   if(out_valid && out_ready)out_valid<=0;
   case(state)
    IDLE: if(cmd_valid && cmd_ready)begin
     out_tag<=cmd_tag;out_weight<=cmd_weight;out_error<=0;out_data<=0;
     if(cmd_k_count==0 || cmd_k_count>16 || cmd_n_count==0 || cmd_n_count>4 ||
        (!cmd_weight && (cmd_n_count!=1 || cmd_digit>2)) || (cmd_weight && cmd_digit>4)) begin
      out_valid<=1;out_error<=1;
     end else begin
      weight<=cmd_weight;k_major<=cmd_k_major;digit<=cmd_digit;
      n_count<=cmd_n_count;k_count<=cmd_k_count;
      base<=cmd_scalar_base;k_stride<=cmd_k_stride;n_stride<=cmd_n_stride;
      element<=0;cache_valid<=0;state<=WALK;
     end
    end
    WALK: begin
     if(address_bad && !inactive)begin
      out_valid<=1;out_error<=1;out_data<=0;state<=IDLE;
     end else if(inactive || hit)begin
      if(weight)out_data[destination*8+:8]<=inactive ? 8'd0 : w_digit;
      else out_data[element*16+:16]<=inactive ? 16'd0 : a_digit;
      if(last_element)begin out_valid<=1;state<=IDLE;end
      else element<=element+1'b1;
     end else if(s_valid && s_ready)begin
      pending_tag<=generation;generation<=generation+1'b1;
      cached_address<=address;state<=WAIT_R;
     end
    end
    WAIT_R: if(r_valid && r_ready)begin
     if(r_error || r_tag!=pending_tag)begin
      out_valid<=1;out_error<=1;out_data<=0;cache_valid<=0;state<=IDLE;
     end else begin cache_data<=r_data;cache_valid<=1;state<=WALK;end
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
