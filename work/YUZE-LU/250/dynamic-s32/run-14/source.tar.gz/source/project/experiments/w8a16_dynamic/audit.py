"""Read recovered artifacts only; no numerical generation or simulation."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
from recover import receipts


def audit(run):
    recovery,files=receipts(run)
    assert 'FAILED' not in recovery['sacct'] and 'COMPLETED' in recovery['sacct']
    raw=(run/'source.tar.gz').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==recovery['source_archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
        sources={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
    assert sources['source-commit.txt'].decode().strip()==recovery['source_commit']
    time_divisor=1000 if b'PACK_CMD cycle=%0t' in sources['source/project/experiments/w8a16_dynamic/tb_packer.sv'] else 1
    for line in sources['source.sha256'].decode().splitlines():
        sha,path=line.split('  ',1);assert hashlib.sha256(sources[path]).hexdigest()==sha
    checkpoint=json.loads(files['checkpoint/checkpoint-report.json'])
    assert checkpoint['passed'] and checkpoint['vectors']==12
    assert checkpoint['shapes']==[['AV',2,8],['QK',128,2]]
    assert hashlib.sha256(files['checkpoint/checkpoint-vectors.json']).hexdigest()==checkpoint['vector_sha256']
    results=[];timings=[]
    for seed in range(25001,25007):
        math=json.loads(files[f'seed-{seed}/oracle.json']);assert math['passed'] and math['cases']==187
        prefix=f'rtl-{seed}/';result=json.loads(files[prefix+'result.json'])
        assert result['passed'] and result['merge_commands']==536 and result['raw_groups']==345 and result['packer_commands']==55
        assert result['checkpoint_roles']==['AV','QK']
        for path,sha in result['vectors_sha256'].items():
            assert hashlib.sha256(files[prefix+path]).hexdigest()==sha
        for unit,count in [('merge','commands=536'),('raw','groups=345'),('packer','commands=55')]:
            assert b'%Warning' not in files[prefix+unit+'-build.log']
            for initial in range(3):
                log=files[prefix+unit+f'-{initial}.log'].decode()
                assert 'PASS ' in log and count in log and '%Error' not in log
        real=prefix+'real-packer-build.log' in files
        if real:
            assert b'%Warning' not in files[prefix+'real-packer-build.log']
            expected=[int(line.split()[-1],16) for line in files[prefix+'real-packer.txt'].decode().splitlines()]
            for initial in range(3):
                for ideal in (0,1):
                    log=files[prefix+f'real-packer-{initial}-{ideal}.log'].decode()
                    assert 'PASS packer commands=54' in log and '%Error' not in log
                    done=re.findall(r'PACK_DONE cycle=(\d+) tag=(\d+) reads=(\d+) error=(\d+)',log)
                    assert len(done)==54 and [int(row[2]) for row in done]==expected
                    req=re.findall(r'PACK_REQ cycle=(\d+) tag=(\d+) addr=(\d+)',log)
                    rsp=re.findall(r'PACK_RSP cycle=(\d+) tag=(\d+)',log)
                    assert len(req)==len(rsp)==sum(expected)
                    assert all(int(row[2])<1024 for row in req)
                    assert all(int(b[0])>=int(a[0])+2*time_divisor for a,b in zip(req,rsp))
                    if seed==25001 and initial==0 and ideal==1:
                        commands={int(tag):int(cycle) for cycle,tag in re.findall(r'PACK_CMD cycle=(\d+) tag=(\d+)',log)}
                        timings=[dict(tag=int(tag),command_cycle=commands[int(tag)]//time_divisor,done_cycle=int(cycle)//time_divisor,
                                      cycles=(int(cycle)-commands[int(tag)])//time_divisor,reads=int(reads),error=int(error))
                                 for cycle,tag,reads,error in done]
        if prefix+'weight-source-build.log' in files:
            assert result['local_source_records']==30
            assert b'%Warning' not in files[prefix+'weight-source-build.log']
            for initial in range(3):
                log=files[prefix+f'weight-source-{initial}.log'].decode()
                assert 'PASS local_source records=30' in log and 'DDRbytes=0' in log and '%Error' not in log
                # If the newer held-offer/quarantine tests are in the source,
                # they must have reached their final successful assertions.
                if b'held_cancel=1' in sources['source/project/experiments/w8a16_dynamic/tb_weight_source.sv']:
                    assert 'held_cancel=1 quarantine=1' in log
                mc_returns=re.findall(r'LOCAL_MC_RETURN cycle=(\d+) tag=(\d+)',log)
                if mc_returns:
                    assert len(mc_returns)==512  # 30*17 + two canceled true returns
                    assert [int(v[1]) for v in mc_returns[:510]]==[0x8000+r*32+b for r in range(30) for b in range(17)]
        results.append(dict(seed=seed,merge_runs=3,raw_runs=3,host_packer_runs=3,
                            real_S_packer_runs=6 if real else 0,math_cases=187))
    return dict(passed=True,job=int(recovery['job']),source_commit=recovery['source_commit'],
                archive_sha256=recovery['archive_sha256'],results=results,
                real_S_ideal_first_seed_timings=timings,
                qualification='component arithmetic/real-S packing only; no complete product control/physical/wholemodel claim')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);args=parser.parse_args()
    result=audit(args.run);(args.run/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(passed=result['passed'],job=result['job'],seeds=len(result['results']))))
