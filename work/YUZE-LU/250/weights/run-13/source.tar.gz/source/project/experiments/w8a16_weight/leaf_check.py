"""Physical-port M leaf strict checks on an allocated compute node."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from generate_leaf import generate


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--verilator', required=True)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    r = a.source / 'project/rtl/w8a16_v1'
    assert (r / 'm_native_leaf_s32.sv').read_text() == generate()
    names = ['m_native_leaf_s32.sv', 'm_native_s32.sv', 'weight_records.sv', 'm_group_s32.sv', 'projection_context_s32.sv', 'scale_group_s32.sv']
    with (a.out / 'lint.log').open('w') as output:
        subprocess.run([a.verilator, '--lint-only', '--Wall', '--top-module', 'm_native_leaf_s32'] + [str(r / name) for name in names], stdout=output, stderr=subprocess.STDOUT, check=True)
    (a.out / 'result.json').write_text(json.dumps(dict(passed=True, lint_only=True, sources={name:hashlib.sha256((r / name).read_bytes()).hexdigest() for name in names}), indent=2) + '\n')


if __name__ == '__main__':
    main()
