module m_leaf_test_top (
 input wire clk,reset,
 input wire lc_valid,output wire lc_ready,input wire lc_sop,lc_eop,input wire [127:0] lc_data,
 output wire lr_valid,input wire lr_ready,output wire lr_sop,lr_eop,output wire [127:0] lr_data,
 input wire a_valid,output wire a_ready,input wire [255:0] a_data,
 input wire [31:0] a_session,input wire [2:0] a_beat,
 output wire mc_req_valid,input wire mc_req_ready,output wire [63:0] mc_req_address,
 output wire [31:0] mc_req_tag,output wire mc_req_channel,output wire [4:0] mc_req_record_beats,
 output wire mc_close_valid,input wire mc_close_ready,output wire [31:0] mc_close_tag_base,
 input wire mc_rsp_valid,output wire mc_rsp_ready,input wire [31:0] mc_rsp_tag,input wire [511:0] mc_rsp_data,
 output wire mc_fence_req_valid,input wire mc_fence_req_ready,
 output wire [31:0] mc_fence_req_cookie,output wire [8:0] mc_fence_req_epoch,
 input wire mc_fence_done_valid,output wire mc_fence_done_ready,
 input wire [31:0] mc_fence_done_cookie,input wire [8:0] mc_fence_done_epoch,
 output wire fault_interrupt,
 input wire gu_cmd_valid,output wire gu_cmd_ready,
 input wire [511:0] gu_cmd_ticket,input wire [127:0] gu_cmd_key,
 input wire gu_cmd_stored,input wire [9:0] gu_cmd_destination,
 output wire gu_native_valid,input wire gu_native_ready,
 input wire gu_result_valid,output wire gu_result_ready,
 input wire [511:0] gu_result_ticket,input wire [255:0] gu_result_data,input wire gu_result_error,
 output wire gu_s_valid,input wire gu_s_ready,output wire [511:0] gu_s_ticket,
 output wire gu_s_word,output wire [9:0] gu_s_address,output wire [127:0] gu_s_data,
 input wire gu_ack_valid,output wire gu_ack_ready,input wire [511:0] gu_ack_ticket,
 input wire gu_ack_word,gu_ack_error,
 output wire gu_terminal_valid,input wire gu_terminal_ready,
 output wire [511:0] gu_terminal_ticket,output wire [7:0] gu_terminal_error,
 output wire gu_terminal_stored,gu_terminal_partial,output wire [255:0] gu_terminal_data,
 output wire [1:0] gu_count,gu_result_count,
 output wire [31:0] gu_rejected,gu_committed,
 output wire dbg_exec_fire,dbg_control_fire,dbg_input_valid,dbg_rf_valid,
 output wire [31:0] dbg_exec_session,dbg_control_session,dbg_input_session,dbg_rf_ticket,
 output wire [31:0] dbg_rf_record,output wire [2:0] dbg_control_kind
);
 m_native_leaf_s32 dut(.*);
 assign dbg_exec_fire=dut.n_exec_valid&&dut.n_exec_ready;
 assign dbg_control_fire=dut.n_control_valid&&dut.n_control_ready;
 assign dbg_exec_session=dut.session;assign dbg_control_session=dut.session;
 assign dbg_control_kind=dut.n_control_kind;
 assign dbg_input_valid=dut.n_input_done_valid;assign dbg_input_session=dut.exec_session;
 assign dbg_rf_valid=dut.n_rsp_valid;assign dbg_rf_ticket=dut.n_rsp_ticket;assign dbg_rf_record=dut.n_rsp_record;
 wire [511:0] unused_native_ticket;wire [7:0] unused_native_resource,unused_native_service;
 wire [255:0] unused_native_payload;
 wire unused_halted,unused_quarantine,unused_quiescent;
 bounded_service_guard guard(.clk(clk),.reset(reset),
  .cmd_valid(gu_cmd_valid),.cmd_ready(gu_cmd_ready),.cmd_ticket(gu_cmd_ticket),.cmd_job_key(gu_cmd_key),
  .cmd_abi(32'h02500001),.cmd_topology(32'd25001),.cmd_capacity(32'd1),
  .cmd_numeric(32'h53333251),.cmd_layout(32'h4b313633),.cmd_resource(8'd0),.cmd_service(8'd32),
  .cmd_provider(8'd1),.cmd_function(8'd0),.cmd_native_op(16'd0),.cmd_payload(256'd0),
  .cmd_stored(gu_cmd_stored),.cmd_store_words(gu_cmd_stored?2'd2:2'd0),.cmd_destination(gu_cmd_destination),
  .native_valid(gu_native_valid),.native_ready(gu_native_ready),.native_ticket(unused_native_ticket),
  .native_resource(unused_native_resource),.native_service(unused_native_service),.native_payload(unused_native_payload),
  .result_valid(gu_result_valid),.result_ready(gu_result_ready),.result_ticket(gu_result_ticket),.result_data(gu_result_data),.result_error(gu_result_error),
  .s_valid(gu_s_valid),.s_ready(gu_s_ready),.s_ticket(gu_s_ticket),.s_word(gu_s_word),.s_address(gu_s_address),.s_data(gu_s_data),
  .ack_valid(gu_ack_valid),.ack_ready(gu_ack_ready),.ack_ticket(gu_ack_ticket),.ack_word(gu_ack_word),.ack_error(gu_ack_error),
  .terminal_valid(gu_terminal_valid),.terminal_ready(gu_terminal_ready),.terminal_ticket(gu_terminal_ticket),
  .terminal_error(gu_terminal_error),.terminal_stored(gu_terminal_stored),.terminal_partial(gu_terminal_partial),.terminal_data(gu_terminal_data),
  .cancel_valid(1'b0),.cancel_job_key(128'd0),.timeout_valid(1'b0),.clear_quarantine(1'b0),.resume_after_drain(1'b0),
  .halted(unused_halted),.quarantine(unused_quarantine),.quiescent(unused_quiescent),
  .occupied_slots(gu_count),.result_slots_occupied(gu_result_count),.rejected_protocol_events(gu_rejected),.committed_words(gu_committed));
endmodule
