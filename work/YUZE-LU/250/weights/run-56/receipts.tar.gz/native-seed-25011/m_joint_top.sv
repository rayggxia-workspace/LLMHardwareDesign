module m_joint_top #(
 parameter integer KEY_W=128,
 parameter integer MC_CREDITS=32,
 // Product ABI has one runtime normalization shift per K128 A tile.
 // The default logical API also permits independent directed head shifts.
 parameter bit COMMON_A_SHIFT=1'b0
)(
 input wire clk, reset,
 input wire alloc_valid, output wire alloc_ready,
 input wire [KEY_W-1:0] alloc_key, input wire [31:0] alloc_record,
 input wire alloc_head16, input wire [3:0] alloc_n,
 output wire alloc_ack_valid, input wire alloc_ack_ready,
 output wire alloc_ack_error, output wire [1:0] alloc_ack_bank,
 output wire [15:0] alloc_ack_generation,
 output wire [KEY_W-1:0] alloc_ack_key, output wire [31:0] alloc_ack_record,
 input wire issue_valid, output wire issue_ready,
 input wire [1:0] issue_bank, input wire [15:0] issue_generation,
 input wire [KEY_W-1:0] issue_key, input wire [31:0] issue_record,
 input wire [4:0] issue_beat,
 input wire fill_valid, output wire fill_ready,
 input wire [1:0] fill_bank, input wire [15:0] fill_generation,
 input wire [KEY_W-1:0] fill_key, input wire [31:0] fill_record,
 input wire [4:0] fill_beat, input wire fill_last,
 input wire [511:0] fill_data,
 output wire fill_ack_valid, input wire fill_ack_ready,
 output wire [1:0] fill_ack_bank, output wire [15:0] fill_ack_generation,
 output wire [KEY_W-1:0] fill_ack_key, output wire [31:0] fill_ack_record,
 output wire fill_ack_error,
 input wire cancel_valid, output wire cancel_ready,
 input wire [1:0] cancel_bank, input wire [15:0] cancel_generation,
 input wire [KEY_W-1:0] cancel_key, input wire [31:0] cancel_record,
 input wire drain_valid, output wire drain_ready,
 input wire [1:0] drain_bank, input wire [15:0] drain_generation,
 input wire [KEY_W-1:0] drain_key, input wire [31:0] drain_record,
 output wire drain_done_valid, input wire drain_done_ready,
 output wire [1:0] drain_done_bank, output wire [15:0] drain_done_generation,
 output wire [KEY_W-1:0] drain_done_key, output wire [31:0] drain_done_record,
 output wire fault_valid, input wire fault_ready,
 output wire [3:0] fault_op,
 output wire [1:0] fault_bank, output wire [15:0] fault_generation,
 output wire [KEY_W-1:0] fault_key, output wire [31:0] fault_record,
 output wire [6:0] outstanding, output wire [3:0] free_mask, ready_mask,
 // One native record in execution; other W banks may fill/reuse meanwhile.
 input wire exec_valid, output wire exec_ready,
 input wire [KEY_W-1:0] exec_key, input wire [31:0] exec_record,
 input wire [1:0] exec_bank, input wire [15:0] exec_generation, exec_use,
 input wire [31:0] exec_raw_tag, exec_ticket,
 input wire [127:0] exec_owner, input wire [3:0] exec_context,
 input wire [15:0] exec_full_k, exec_k_offset, exec_kk,
 input wire exec_a_slot, input wire [15:0] exec_a_generation,
 input wire [47:0] exec_a_shifts, input wire [255:0] exec_bias,
 input wire a_valid, output wire a_ready,
 input wire [KEY_W-1:0] a_key, input wire [31:0] a_record,
 input wire a_slot, input wire [15:0] a_generation, a_kk, a_use,
 input wire [2:0] a_beat, input wire [255:0] a_data,
 // Actual final operand event. Acceptance releases W input ownership only.
 output wire input_done_valid, input wire input_done_ready,
 output wire [KEY_W-1:0] input_done_key, output wire [31:0] input_done_record,
 output wire [1:0] input_done_bank, output wire [15:0] input_done_generation, input_done_use,
 output wire input_done_a_slot, output wire [15:0] input_done_a_generation,
 // Cancel reports the actual completed head prefix; no atomic rollback.
 output wire abort_done_valid, input wire abort_done_ready,
 output wire [KEY_W-1:0] abort_done_key, output wire [31:0] abort_done_record,
 output wire [127:0] abort_done_owner, output wire [3:0] abort_done_context,
 output wire [15:0] abort_done_next_k,
 // CREATE/RESTORE/SPILL/DROP. STEP is reserved for actual raw results.
 input wire control_valid, output wire control_ready,
 input wire [2:0] control_kind, input wire [3:0] control_context,
 input wire [127:0] control_owner, input wire [31:0] control_ticket,
 input wire [15:0] control_full_k, control_k_offset,
 input wire [7:0] control_group_k, input wire [3:0] control_n,
 input wire [255:0] control_previous,
 // Proof produced by the finite external two-slot S-write guard only after
 // BOTH actual 128-bit destination writes ACK. A request bit is not proof.
 input wire [31:0] control_snapshot_ticket,
 input wire restore_commit_valid,
 input wire [127:0] restore_commit_owner,
 input wire [3:0] restore_commit_context,
 input wire [31:0] restore_commit_ticket,
 input wire [15:0] restore_commit_next_k, restore_commit_full_k,
 input wire [7:0] restore_commit_group_k, input wire [3:0] restore_commit_n,
 // One held RF response. FINAL/SPILL capture into the external 2x32B guard
 // releases the RF; actual S ACK is later and has an independent identity.
 output wire rsp_valid, output wire rsp_ready,
 output wire [2:0] rsp_kind, output wire [3:0] rsp_context,
 output wire [127:0] rsp_owner, output wire [31:0] rsp_tag, rsp_ticket,
 output wire [KEY_W-1:0] rsp_key, output wire [31:0] rsp_record,
 output wire [1:0] rsp_bank, output wire [15:0] rsp_generation, rsp_use,
 output wire [15:0] rsp_next_k, rsp_full_k,
 output wire [7:0] rsp_group_k, output wire [3:0] rsp_n,
 output wire rsp_final, rsp_snapshot, output wire [255:0] rsp_data,
 output wire rsp_error,
 output reg native_fault_valid, input wire native_fault_ready,
 output reg [2:0] native_fault_kind,
 output reg [KEY_W-1:0] native_fault_key, output reg [31:0] native_fault_record,
 output wire busy, output wire [2:0] scale_count,
 input wire guard_enable,allow_capture,
 input wire gu_cmd_valid,output wire gu_cmd_ready,
 input wire [511:0] gu_cmd_ticket,input wire [127:0] gu_cmd_key,
 input wire gu_cmd_stored,input wire [9:0] gu_cmd_destination,
 output wire gu_native_valid,input wire gu_native_ready,
 output wire gu_s_valid,input wire gu_s_ready,output wire [511:0] gu_s_ticket,
 output wire gu_s_word,output wire [9:0] gu_s_address,output wire [127:0] gu_s_data,
 input wire gu_ack_valid,output wire gu_ack_ready,input wire [511:0] gu_ack_ticket,
 input wire gu_ack_word,gu_ack_error,
 output wire gu_terminal_valid,input wire gu_terminal_ready,
 output wire [511:0] gu_terminal_ticket,output wire [7:0] gu_terminal_error,
 output wire gu_terminal_stored,gu_terminal_partial,output wire [255:0] gu_terminal_data,
 output wire [1:0] gu_count,gu_result_count,
 output wire [31:0] gu_rejected,gu_committed,
 output wire dbg_raw_fire,dbg_rf_retire,
 output wire [15:0] dbg_raw_offset,dbg_rf_next,
 output wire [31:0] dbg_raw_tag,
 output wire dbg_rf_error
);
 m_native_s32 #(.KEY_W(KEY_W),.MC_CREDITS(MC_CREDITS),.COMMON_A_SHIFT(COMMON_A_SHIFT)) dut(.*);
 assign dbg_raw_fire=dut.raw_valid&&dut.raw_ready;
 assign dbg_rf_retire=dut.rf_rsp_valid&&dut.rf_rsp_ready&&dut.rsp_from_raw;
 assign dbg_raw_offset=dut.step_offset;assign dbg_raw_tag=dut.raw_tag;
 assign dbg_rf_next=dut.rf_rsp_next_k;assign dbg_rf_error=dut.rf_rsp_error;
 wire guard_result_ready;
 wire [511:0] result_ticket={185'd0,rsp_owner,rsp_key,rsp_ticket,rsp_record,rsp_context,rsp_kind};
 assign rsp_ready=allow_capture&&(!guard_enable||guard_result_ready);
 wire [511:0] unused_native_ticket;wire [7:0] unused_native_resource,unused_native_service;
 wire [255:0] unused_native_payload;
 wire unused_halted,unused_quarantine,unused_quiescent;
 bounded_service_guard guard(.clk(clk),.reset(reset),
  .cmd_valid(gu_cmd_valid),.cmd_ready(gu_cmd_ready),.cmd_ticket(gu_cmd_ticket),.cmd_job_key(gu_cmd_key),
  .cmd_abi(32'h02500001),.cmd_topology(32'd25001),.cmd_capacity(32'd1),
  .cmd_numeric(32'h53333251),.cmd_layout(32'h4b313633),.cmd_resource(8'd0),.cmd_service(8'd32),
  .cmd_provider(8'd1),.cmd_function(8'd0),.cmd_native_op(16'd0),.cmd_payload(256'd0),
  .cmd_stored(gu_cmd_stored),.cmd_store_words(gu_cmd_stored?2'd2:2'd0),.cmd_destination(gu_cmd_destination),
  .native_valid(gu_native_valid),.native_ready(gu_native_ready),.native_ticket(unused_native_ticket),
  .native_resource(unused_native_resource),.native_service(unused_native_service),.native_payload(unused_native_payload),
  .result_valid(guard_enable&&rsp_valid&&allow_capture),.result_ready(guard_result_ready),
  .result_ticket(result_ticket),.result_data(rsp_data),.result_error(rsp_error),
  .s_valid(gu_s_valid),.s_ready(gu_s_ready),.s_ticket(gu_s_ticket),.s_word(gu_s_word),.s_address(gu_s_address),.s_data(gu_s_data),
  .ack_valid(gu_ack_valid),.ack_ready(gu_ack_ready),.ack_ticket(gu_ack_ticket),.ack_word(gu_ack_word),.ack_error(gu_ack_error),
  .terminal_valid(gu_terminal_valid),.terminal_ready(gu_terminal_ready),.terminal_ticket(gu_terminal_ticket),
  .terminal_error(gu_terminal_error),.terminal_stored(gu_terminal_stored),.terminal_partial(gu_terminal_partial),.terminal_data(gu_terminal_data),
  .cancel_valid(1'b0),.cancel_job_key(128'd0),.timeout_valid(1'b0),.clear_quarantine(1'b0),.resume_after_drain(1'b0),
  .halted(unused_halted),.quarantine(unused_quarantine),.quiescent(unused_quiescent),
  .occupied_slots(gu_count),.result_slots_occupied(gu_result_count),.rejected_protocol_events(gu_rejected),.committed_words(gu_committed));
endmodule
